# escalation-003 — Coherence-Law Worked Example: Lane Hits an Authorization Boundary

> **Purpose:** neutral case study illustrating the escalation SHAPE when a module lane reaches a
> coherence/authorization boundary it cannot resolve autonomously. Uses placeholder names throughout.
> No real project operation is revealed. Self-contained — no `../` references.
> Marked as: DETAIL-LIGHT EXAMPLE (not a real incident report).

---

## Context

`{{PROJECT_NAME}}` is a multi-lane project. The active lanes at the time of this example:

- `foundation` — integrator; sole spine committer; routing hub.
- `module-a` — a module lane with `spine_write: DENY`; authors work in its own branch.
- `module-b` — a second module lane; same write boundary.

The coherence law (SPEC-COHERENCE, rule-stated) requires that any set of changes touching shared
substrate objects must clear a joint coherence check before any member merges. No single lane
can self-authorize a merge that touches objects owned or consumed by another lane.

---

## Incident shape

**What happened:** `module-a` completed a work-package (`WP-A-07`) that modified a shared contract
interface — specifically, a schema object used by both `module-a` and `module-b` as a read target.
`module-a`'s per-WP auditor PASS was clean. `module-a` submitted the branch for merge ratification.

**The boundary:** the set-level coherence check (C-RATIFICATION-PACKET §2 COHERENCE CHECKS) revealed
that `module-b` had an in-flight WP (`WP-B-03`) that read from the same schema object — and
`WP-B-03`'s branch carried a shape assumption now contradicted by `WP-A-07`'s delta.

**Why `module-a` could not resolve this autonomously:**
- `module-a` has `spine_write: DENY` — it cannot merge itself.
- The joint coherence check is a SET-level evaluation; it requires reading `module-b`'s in-flight
  branch state, which `module-a` does not author.
- Self-certifying the merge (marking the WP RATIFIED on the basis of the per-member PASS alone)
  would be a boundary bypass — the SUBSET RULE (C-RATIFICATION-PACKET §5) bars line-item
  ratification.

---

## Escalation path

```
module-a  →  SUBMIT WP-A-07 for set assembly (branch@<sha>, receipts attached)
             signals: "touches shared schema object; joint check required"

foundation  →  assembles SET-0042 packet
              MEMBERS: WP-A-07 (module-a) + WP-B-03 (module-b, in-flight)
              CONFLICT SWEEP: confirms the shape contradiction
              BRIEFING: two grounded alternatives drafted (see below)

foundation  →  ROUTES to architect
              reason: conflict is a HOW-class call (interface contract shape)
              not an operator-go/no-go (not an irreversible publish or auth grant)

architect  →  receives the packet; reads both branches at HEAD
              RULES: alternative (b) — WP-A-07 proceeds with a compatibility shim;
              WP-B-03 is RETURNED to module-b with the ruling and the shim spec;
              module-b re-authors WP-B-03 against the updated interface before the
              next set assembly
              RATIONALE CLASS: in-band (resolvable from system-of-record facts)

foundation  →  records the ruling in the packet (SET-0042 DECISION LINE: AMENDED)
              relays RETURNED to module-b inbox via doorbell (SPEC-DOORBELL §7 — ring is OBLIGATORY)
              WP-A-07 is cleared for merge (stated order: WP-A-07 first, WP-B-03 after re-author)
```

---

## Alternatives briefed

**(a) Hold both:** park the entire set until `module-b` completes `WP-B-03` under the OLD interface,
then rebuild `WP-A-07` against the new joint shape. Consequence: two WPs blocked; delays the
shared-object change.

**(b) Shim + sequence:** merge `WP-A-07` with a compatibility shim that preserves the old read shape
alongside the new one for one release cycle; RETURN `WP-B-03` to `module-b` to re-author against the
new interface. Consequence: one additional shim object in the schema (time-bounded); `module-b`
does one re-author pass; no blocking hold on `WP-A-07`.

Architect chose **(b)**.

---

## Key coherence-law properties exercised

| Property | Where it fired |
|---|---|
| SET-level authorization (not per-member) | C-RATIFICATION-PACKET §1 — merge gate blocked until packet decision |
| SUBSET RULE | §5 — AMENDED set is a NEW set; retained member re-enters joint validation |
| INDEPENDENCE | §5 — assembler (foundation) validated; operator ratified; architect ruled HOW; auditor reproduces post-merge |
| NO-CHERRY-PICK | §5 — RETURNED WP-B-03 reaches main only inside a future ratified set |
| LOOP GUARD | §5 — if WP-B-03 returns a second time, automatic architect escalation |
| Ring obligation | SPEC-DOORBELL §7 — foundation's RETURNED relay to module-b inbox triggers an obligatory doorbell ring |

---

## What this example does NOT show

- The content of the schema object or the interface (detail-light by design).
- Any real project's domain, tooling, or substrate.
- The operator's role here — this conflict was in-band (HOW-class), so it was routed to the architect,
  not the operator. The operator's scope is apex go/no-go, final publishes, and out-of-band decisions.

---

*This is a neutral WORKED EXAMPLE for the {{PROJECT_NAME}} engine. It illustrates the escalation
shape only. Adapt the lane names, WP ids, and substrate objects to the actual project.*
