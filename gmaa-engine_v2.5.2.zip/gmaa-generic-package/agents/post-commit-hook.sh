#!/usr/bin/env bash
# agents/post-commit-hook.sh — D1: lane-aware Auditor + GUARANTEED lane-stamped
# [audit] commit (reap-then-audit). Canonical source for .git/hooks/post-commit
# (installed via scripts/install_post_commit_hook.sh).
#
# GENERICIZATION NOTE: mechanism byte-unchanged (skip-guard · lane resolve · module
# marker+push · foundation reap+push+doorbell auto-fire · backgrounded Auditor). Stripped:
# architect-ruling attributions + real dates + project-specific issue/WP ids (→ rule-stated);
# the provider-specific `.env` key name + subscription-plan noun (→ keyless-on-subscription,
# generic); the audit-prompt compare-list's retired DAG file + named vendor surfaces (→ the
# generic work-package layer + generic "live surface you cannot reach"). KEPT as generic engine
# refs: COORDINATION.md §13 · SPEC-DOORBELL producer-ring · schema/verification.md §8.1/§8.3 ·
# agents/{auditor-contract,audit-system-prompt,standing-probes}. The committing lane is resolved
# from LOCATION (scripts/resolve-lane.sh); `foundation`/`main` are the base-census integrator +
# trunk (GENERIC-KEEP); module lanes ride audit-at-merge [C]. The `claude` runtime binary is the
# agent substrate the whole package runs on (kept, as in the launch scripts).
#
# Fires the code-Auditor on every non-[audit] commit per agents/auditor-contract.md.
#
# D1 (architect ruling): converts the separate-commit of the audit record from
# honor-system (a prior integrator-trigger-liveness gap) to GUARANTEED, while
# preserving single-writer (COORDINATION.md §13(1)) BY CONSTRUCTION:
#   - The audit record is produced ASYNC (backgrounded `claude -p`), so this commit
#     CANNOT commit its own audit synchronously. Instead, REAP-THEN-AUDIT:
#       (1) REAP: commit the PRIOR commit's now-COMPLETED audit as a lane-stamped
#           [audit] seal — done HERE, in the integrator's context. FOUNDATION ONLY
#           (foundation is the sole spine/ledger committer; D3 blocks a module from
#           committing ledger/). A module's audit record rides reap-at-merge [C],
#           committed by the integrator at merge — NOT self-committed.
#       (2) AUDIT: background the Auditor for THIS commit, lane-stamped; it writes
#           ledger/* + a completion sentinel, and NEVER self-commits.
#   - Bounds trailing uncommitted-audit <=1 on the foundation stream during activity
#     (this commit's audit is sealed by the NEXT foundation commit); a terminal
#     flush (explicit reap at EOD / next-session start) discharges the last one.
#     Module-stream audit bound = merge cadence, by construction.
#
# Preserved from prior contract: [audit]-subject skip-guard (no audit loop);
# --permission-mode bypassPermissions (operator-bound ruling — the Auditor needs
# live-surface Bash; do NOT regress to acceptEdits); explicit PATH hardening
# (integrator-trigger-liveness rule); conditional .env source (now keyless — .env
# carries no LLM API key, so the Auditor runs on the subscription, not metered API).

set -u

REPO_ROOT="$(git rev-parse --show-toplevel)"
COMMIT_HASH="$(git rev-parse HEAD)"
COMMIT_SHORT="$(git rev-parse --short HEAD)"
COMMIT_SUBJECT="$(git log -1 --pretty=%s)"
CHANGED_FILES="$(git diff-tree --no-commit-id --name-only -r HEAD 2>/dev/null || echo '<initial commit; all files>')"
# Merge commit ([C] audit-at-merge): diff-tree shows nothing for merges, so audit the
# INCOMING change vs the first parent — this is the module work the integrator merged.
if git rev-parse -q --verify HEAD^2 >/dev/null 2>&1; then
    CHANGED_FILES="$(git diff --name-only HEAD^1 HEAD 2>/dev/null)"
fi

# === Skip-guard: [audit] commits trigger neither reap nor audit (no loop) ===
# Match commit SUBJECT prefix only (body-text matching caused a false-skip regression).
if [[ "$COMMIT_SUBJECT" =~ ^\[audit\] ]]; then
    exit 0
fi

# === Resolve the COMMITTING worktree's lane (D1 lane-aware; §13(2)) ===
# Same resolver the §0 cold-boot seat + D3 pre-commit consume; resolves THIS
# worktree's root, never trunk/cwd.
LANE="UNRESOLVED"
if [[ -x "$REPO_ROOT/scripts/resolve-lane.sh" ]]; then
    if LANE_LINE="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>/dev/null)"; then
        eval "$LANE_LINE"          # -> lane= role= version= spine_write= blob=
        LANE="${lane:-UNRESOLVED}"
    fi
fi
# Post-commit cannot unwind a landed commit; an unresolved lane does NOT block, but
# the audit record is stamped UNRESOLVED so the gap is loud, not silent.

# Completion sentinels live in the SHARED common git-dir (never tracked, shared by
# all worktrees), one file per audited SHA, content = the producing lane.
GIT_COMMON="$(git rev-parse --git-common-dir)"
case "$GIT_COMMON" in /*) : ;; *) GIT_COMMON="$REPO_ROOT/$GIT_COMMON" ;; esac
DONE_DIR="$GIT_COMMON/audit-done"
mkdir -p "$DONE_DIR"

# === Module lanes (audit-at-merge [C]): lightweight lane MARKER ONLY — no reap, no
#     auditor, NO module-side audit record. A module commit is a PROPOSAL until merge;
#     it is not audited until it becomes real on the spine. The integrator re-audits
#     incoming module commits AT MERGE (scripts/reap_at_merge.sh) and emits the
#     lane-stamped [audit] seal on main. This keeps single-writer literal: nothing is
#     produced cross-boundary to transport or orphan. ===
if [[ "$LANE" != "foundation" ]]; then
    MARK_DIR="$GIT_COMMON/module-commits/$LANE"
    mkdir -p "$MARK_DIR"
    # TYPE the marker (integrator ruling): a currency-sync commit is a spine->module
    # ADOPTION (it adopts the trunk; identity-preserve + rules re-stamp), NOT a module->main merge
    # candidate. Typing it kind=currency-sync-adoption lets any marker-driven merge-candidate scan
    # exclude it BY CONSTRUCTION (correctness via correct typing, not via cleanup — the gate does NOT
    # clean its own marker). NOTE: reap_at_merge.sh currently merges via rev-list (no marker scan), so
    # the kind is forward-correctness today; whether reap-at-merge should consume the kind is tracked
    # [C]-seam hygiene (surface for ratify before adding a marker-scan predicate).
    case "$COMMIT_SUBJECT" in
        currency-sync:*|currency:*) MARK_KIND="currency-sync-adoption" ;;
        *)                          MARK_KIND="module-work" ;;
    esac
    { printf 'kind=%s\n' "$MARK_KIND"; date -u +%Y-%m-%dT%H:%M:%SZ; } > "$MARK_DIR/$COMMIT_HASH" 2>/dev/null || true
    echo "[post-commit] lane=${LANE} ${COMMIT_SHORT} MARKED kind=${MARK_KIND} (audit-at-merge [C]: re-audited by integrator at merge; no module-side audit record)."
    # === PUSH-AT-CLOSE (module lane; §13(5) cadence) ===
    # Keep the module branch origin-durable. Plain fast-forward; best-effort (a landed
    # commit cannot be unwound). NEVER --force (non-ff = STOP-and-surface, not retry).
    MBRANCH="$(git rev-parse --abbrev-ref HEAD 2>/dev/null)"
    if [[ -n "$MBRANCH" && "$MBRANCH" != "HEAD" ]]; then
        if env -u GIT_INDEX_FILE -u GIT_DIR -u GIT_WORK_TREE -u GIT_PREFIX git push origin "$MBRANCH" >/dev/null 2>&1; then
            echo "[post-commit] lane=${LANE} pushed ${MBRANCH} -> origin (module durability)."
        else
            echo "[post-commit] WARN lane=${LANE} push of ${MBRANCH} FAILED (commit is local-only; NOT unwound; do NOT --force). Drift surface will flag." >&2
        fi
    fi
    exit 0
fi

# === (1) REAP STEP — foundation only (sole spine/ledger committer) ===
# Seal every COMPLETED-but-unsealed FOUNDATION audit as one lane-stamped [audit]
# commit. Module-lane sentinels are left in place for reap-at-merge [C].
if [[ "$LANE" == "foundation" ]]; then
    (
        set +e
        SEALED=()
        for s in "$DONE_DIR"/*; do
            [[ -e "$s" ]] || continue
            SEAL_LANE="$(cat "$s" 2>/dev/null || echo '')"
            [[ "$SEAL_LANE" == "foundation" ]] || continue   # modules ride reap-at-merge
            SEALED+=("$(basename "$s")")
        done
        if [[ ${#SEALED[@]} -gt 0 ]]; then
            cd "$REPO_ROOT" || exit 0
            # nested-commit env hygiene: drop inherited GIT_* so the seal commits cleanly
            G() { env -u GIT_INDEX_FILE -u GIT_DIR -u GIT_WORK_TREE -u GIT_PREFIX -u GIT_AUTHOR_DATE -u GIT_COMMITTER_DATE git "$@"; }
            G add ledger/audit-runs.log ledger/audit-findings.md ledger/receipts.jsonl 2>/dev/null
            if ! G diff --cached --quiet 2>/dev/null; then
                SHALIST="$(printf '%s ' "${SEALED[@]}")"
                G commit -q -m "[audit] seal ${SHALIST}— lane=foundation reap-then-audit (guaranteed, code-Auditor output)" 2>/dev/null
            fi
            # remove only the sentinels we just processed (later-completing ones ride next reap)
            for sha in "${SEALED[@]}"; do rm -f "$DONE_DIR/$sha"; done
        fi
    ) || true

    # === (1b) PUSH-AT-CLOSE (foundation; §13(5) cadence) ===
    # "landed + sealed" must mean origin-durable. Push the just-closed work commit
    # (+ any [audit] seal the reap just made) to origin as a plain fast-forward.
    # Best-effort: a landed commit cannot be unwound, so a failed push warns loud and
    # is caught by the local-ahead-of-origin drift surface. NEVER --force (a non-ff
    # push failure is a STOP-and-surface event — history divergence — not a retry).
    BRANCH="$(git rev-parse --abbrev-ref HEAD 2>/dev/null)"
    if [[ -n "$BRANCH" && "$BRANCH" != "HEAD" ]]; then
        if env -u GIT_INDEX_FILE -u GIT_DIR -u GIT_WORK_TREE -u GIT_PREFIX git push origin "$BRANCH" >/dev/null 2>&1; then
            echo "[post-commit] lane=foundation pushed ${BRANCH} -> origin (fast-forward; origin-durable)."
        else
            echo "[post-commit] WARN lane=foundation push of ${BRANCH} FAILED (commit is local-only; NOT unwound; do NOT --force). Drift surface will flag." >&2
        fi
    fi

    # === (1c) DOORBELL AUTO-FIRE — SPEC-DOORBELL producer-ring enforcement (Ruling 2) ===
    # Judgment-free ENFORCEMENT of the producer-ring obligation (Ruling 1): for every
    # relay-inbox/<lane>/ path THIS commit touched, ring that lane so its first-action
    # INBOX-CHECK fires now (vs its next operator-spawned turn). The producer no longer
    # DECIDES whether to ring — the hook does it. Properties:
    #   - NON-BLOCKING: the commit already landed; this MUST NOT fail or hang the hook
    #     (subshell + set +e + `|| true`; the interactive R3 fail-loud path is separate).
    #   - SURFACE-UNRUNG-NEVER-SILENT: a lane that can't resolve to a live pane
    #     (not in tmux / session absent / ambiguous) OR is remote-control-active is
    #     recorded to ledger/doorbell.log — this IS the SPEC-DOORBELL "delays never loses"
    #     safety property operating VISIBLY (payload durable in git; the lane catches it via
    #     its obligatory INBOX-CHECK on its next turn; the unrung notice makes the deferred
    #     delivery visible so it is not forgotten).
    #   - RINGS ALL inbox writes (no "requires action" judgment — a redundant wake is a
    #     cheap no-op turn; INBOX-CHECK is idempotent) with per-lane dedupe.
    #   - Ruling 3: an EXPLICIT remote-control marker (tmux user-option @remote_control on
    #     the lane's session) SUPPRESSES+surfaces. MERE CLIENT-ATTACHMENT does NOT qualify
    #     — an attached-but-idle lane still needs its ring.
    (
        set +e
        DBELL="$REPO_ROOT/scripts/doorbell.sh"
        ULOG="$REPO_ROOT/ledger/doorbell.log"
        TS="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
        INBOX_LANES="$(printf '%s\n' "$CHANGED_FILES" \
            | sed -n 's#^_orchestration/relay-inbox/\([^/][^/]*\)/..*#\1#p' | sort -u)"
        for L in $INBOX_LANES; do
            [[ -n "$L" ]] || continue
            RC="$(tmux show-options -v -t "$L" @remote_control 2>/dev/null)"
            case "$RC" in
                1|on|true|yes)
                    printf 'unrung: %s (remote-control-active) %s %s\n' "$L" "$COMMIT_SHORT" "$TS" >> "$ULOG"
                    echo "[post-commit] doorbell auto-fire: SUPPRESSED ${L} (remote-control-active) -> ledger/doorbell.log." ;;
                *)
                    if RING_OUT="$("$DBELL" ring "$L" 2>&1)"; then
                        echo "[post-commit] doorbell auto-fire: rang ${L} (inbox-commit ${COMMIT_SHORT})."
                    else
                        REASON="$(printf '%s' "$RING_OUT" | tr '\n' ' ' | sed 's/  */ /g; s/^ *//; s/ *$//')"
                        printf 'unrung: %s (%s) %s %s\n' "$L" "${REASON:-ring-failed}" "$COMMIT_SHORT" "$TS" >> "$ULOG"
                        echo "[post-commit] doorbell auto-fire: UNRUNG ${L} -> ledger/doorbell.log (payload durable; next INBOX-CHECK catches it)."
                    fi ;;
            esac
        done
    ) || true
fi

# === (2) AUDIT STEP — background the Auditor for THIS commit; sentinel on done ===
if [[ ! -f "$REPO_ROOT/agents/audit-system-prompt.md" ]]; then
    echo "post-commit: agents/audit-system-prompt.md MISSING; commit succeeded but audit SKIPPED." >&2
    exit 0
fi

# Hooks run with a minimal env; set PATH explicitly so a minimal-env commit cannot
# silently SKIP the audit. $HOME-relative (portable across machines).
export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"

# Auditor binary — defaults to the real `claude` (the agent-runner substrate). AUDITOR_CMD
# overrides it for control-logic tests only (the PATH-hardening above intentionally
# prioritises the real claude dirs, so a test cannot shadow it via PATH; this env seam is
# the hook).
AUDITOR_CMD="${AUDITOR_CMD:-claude}"
if ! command -v "$AUDITOR_CMD" >/dev/null 2>&1; then
    echo "post-commit: auditor '$AUDITOR_CMD' not in PATH; commit succeeded but audit SKIPPED." >&2
    exit 0
fi

mkdir -p "$REPO_ROOT/ledger"

# Source .env if present (gitignored). Keyless by design — carries no LLM API key, so
# the Auditor runs on the subscription plan (not metered API). The env-var NAME for a
# metered key belongs only in a C-GATE slot, never here.
if [[ -f "$REPO_ROOT/.env" ]]; then
    set -a
    # shellcheck source=/dev/null
    source "$REPO_ROOT/.env"
    set +a
fi

AUDIT_PROMPT=$(cat <<EOF
Audit commit ${COMMIT_HASH} (${COMMIT_SHORT}). Committing lane: ${LANE}.

Changed files in this commit:
${CHANGED_FILES}

Read each changed file. For receipts added to ledger/receipts.jsonl in
this commit (compared to the prior commit), independently re-invoke
each receipt's probe_path; compare exit code + output hash; emit verdict
per agents/audit-system-prompt.md.

Compare against:
- contracts/ (the binding specs every work package verifies against)
- schema/ (work-package shape, receipt shape, state machine, verification rings)
- agents/ (role definitions; lane boundaries)
- docs/ (BUILD_ARCHITECTURE, PROTOCOL, UAT, FOUNDATION)
- CHECKLIST.md (the work-package / build-sequence layer)
- ledger/audit-findings.md (prior findings — avoid duplicates; detect recurrences)

Per AUDITOR INCREMENTAL (schema/verification.md §8.1): audit this commit's
artifacts the moment they land; no batching per wave.

Per SELF-HEALING (schema/verification.md §8.3): on DIVERGED, append a
finding-and-receipt; do NOT author corrections (worker reworks on its
own branch); do NOT close any WP (orc merges on REPRODUCED).

Per WAIVED-with-notes (agents/auditor-contract.md §Interim-cover): for
Ring 2/3 probes against any live surface you cannot reach (external DB,
HTTP API, a third-party console) — you do NOT have those credentials;
record WAIVED with explicit notes naming the unreached surface.

Per STANDING-PROBE runlist (agents/audit-system-prompt.md step 9 +
agents/standing-probes.yaml; the standing-probes wiring ruling): after
per-receipt reproduction work in steps 4-8, run each standing probe
configured in agents/standing-probes.yaml. Emit a Ring-2 standing-probe
receipt ONLY on (a) FAIL outside partial_fail_window / RUN_ERROR
(regression); (b) PASS<->FAIL state change vs prior receipt; (c)
cadence_emit_per_day boundary crossed; (d) wiring-init sentinel
(first-ever standing-probe receipt for that id). Otherwise PASS-on-PASS
emits no receipt — the ledger/audit-runs.log invocation entry is
sufficient liveness.

Output:
- Append a per-commit finding block to ledger/audit-findings.md (note the
  committing lane=${LANE}).
- Emit auditor-emitted receipt(s) to ledger/receipts.jsonl (one per
  worker receipt audited; actor=code-Auditor; supersedes_receipt_id set).
- Emit standing-probe receipt(s) per the rule above (actor=code-Auditor;
  standing_probe_id set; supersedes_receipt_id=null).

Be specific: file:line evidence required.
Be non-redundant: check prior findings first.
Be conservative: WAIVED is honest admission; never silently skip.

Trigger context: post-commit ${COMMIT_SHORT} (lane=${LANE})
EOF
)

# Invoke headlessly with audit-only system prompt; background + disown so the
# commit session never hangs. On completion, drop the per-SHA sentinel that
# licenses the NEXT foundation commit's reap to seal this audit.
cd "$REPO_ROOT"
(
    "$AUDITOR_CMD" -p "$AUDIT_PROMPT" \
        --append-system-prompt "$(cat "$REPO_ROOT/agents/audit-system-prompt.md")" \
        --permission-mode bypassPermissions \
        >> "$REPO_ROOT/ledger/audit-runs.log" 2>&1
    echo "$LANE" > "$DONE_DIR/$COMMIT_HASH"
) &
disown 2>/dev/null || true

echo "[post-commit] lane=${LANE} Auditor backgrounded for ${COMMIT_SHORT}; prior completed foundation audits reaped. Audit lands async at ledger/* + sentinel."

exit 0
