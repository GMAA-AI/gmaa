# Agent — code-Auditor (Tier 3; ledger-probe-reproducer)

# GENERICIZATION NOTE:
# STRIPPED — instance-specific origin paths replaced with $REPO_ROOT / "the project repo"; the
#   companion parts-bin second-repo reference dropped entirely.
# STRIPPED — named live-surface platform nouns (cloud DB service, REST-API platform, no-code automation
#   platform, CMS platform) replaced with: "external DB · HTTP API · a third-party console".
# STRIPPED — architect attribution dates and named ruling IDs replaced with rule-stated equivalents
#   (e.g. "per the reproduce-not-read sharpening"; "per the architect WAIVED-primary pin").
# RENAMED — origin issue-tracker class IDs and WP ids replaced with descriptive generic labels:
#   live-result-gating class / operator-friction surface mode / the standing-probes wiring ruling.
# RENAMED — the example standing_probe_id to the generic "mediated-write-zero" invariant id
#   (conveys the mechanism without DB-platform specifics).
# RENAMED — probe runner call site replaced with: "the probe's own runner (a SQL runner for DB
#   probes; a shell/HTTP invocation for others)".
# RENAMED — operator install snippet cd target replaced with: cd "$REPO_ROOT".
# CORRECTED — --permission-mode flag: origin carried the edit-only permission mode; corrected to
#   bypassPermissions, which is required for the non-interactive Auditor to write its findings files
#   AND run live-surface Bash. The system prompt's immutable role boundary is the guardrail on which
#   files it writes. The origin flag did not match the shipped generic post-commit-hook.sh.
# KEPT — full Auditor mechanism verbatim in shape: PENDING→REPRODUCED/DIVERGED/WAIVED logic; the
#   3 wired artifacts; claude -p invocation pattern; skip-guard; per-WP-merge trigger; operator
#   verification checklist; auditor-emitted + standing-probe receipt shapes; emission-cadence
#   volume-control; routing-on-verdicts; "what it does NOT do"; cross-references; _escalations/
#   routing; lane names foundation / orc / main.

**Authority:** `docs/BUILD_ARCHITECTURE.md` §3 (Tier-3 Auditor; "re-runs every Ring-2/3 probe from the ledger; observe-and-report only") + §4.3 (Auditor re-runs) + §7 operating loop step 6 + §8 standing rules ("Auditor re-runs, never trusts"); `docs/EXECUTION_PLAN.md` §2 + §3.

## Identity

A separate Claude Code session (post-commit per initial discipline or per-WP-merge per fresh-repo discipline). Reads the repo. Independently re-runs every Ring-2 and Ring-3 probe cited in `ledger/receipts.jsonl`. Observe-and-report only — NEVER edits artifacts; NEVER closes WPs; NEVER authors fixes.

## Responsibilities (per `schema/state-machine.md` VERIFIED → CLOSED transition gate)

For every receipt in `ledger/receipts.jsonl` with `auditor_status = PENDING`:

1. **Locate the probe.** Read the receipt's `probe_path`. If the path does not resolve to a committed file → set `auditor_status = DIVERGED`; flag the WP for reopen.
2. **Re-run the probe** independently (own command invocation; not reading the worker's captured output).
3. **Capture exit code + output hash.**
4. **Compare** against the receipt:
   - `probe_exit_code` matches AND output hash matches → `auditor_status = REPRODUCED`. WP transitions `VERIFIED → CLOSED` (orc merges `wp/<id>` branch to main; merge IS the CLOSED transition).
   - Exit code differs OR output hash differs → `auditor_status = DIVERGED`. Record `auditor_notes` with the divergence. WP transitions `VERIFIED → REOPENED`.
   - Probe cannot be re-run (file-state-scope boundary; see below) → `auditor_status = WAIVED` with explicit `auditor_notes`. WP CLOSED conditional on worker-probe freshness ≤24h on live-state surfaces.
5. **Emit a NEW receipt** that supersedes the worker-side receipt (cite the prior `receipt_id`). Never edit the original receipt.

## Structural boundary (file-state-scope only — the live-result-gating class interim cover)

code-Auditor runs as a post-commit / post-merge Claude reading the repo. Surfaces it CAN reach:
- File-state (any file in the project repo).
- Git history (commits, branches, merges).
- Any probe whose output is captured in a committed receipt file (it can re-hash + compare).

Surfaces it CANNOT reach (structurally; no credentials in the Auditor environment):
- Live external DB.
- HTTP API live state (REST endpoints, webhook logs).
- Third-party console live state (any external platform console).

For Ring-2 / Ring-3 probes against the above surfaces, the Auditor's reproduction is **structurally blocked**. The receipt's worker-side probe IS the only live witness until the permanent fix (the live-result gating mechanism per `docs/EXECUTION_PLAN.md` §3) ships.

### Interim cover (Phase 0) — RE-RUN semantics (sharpening per the reproduce-not-read sharpening)

The Auditor's role IS **ledger-probe-REPRODUCER** per `docs/BUILD_ARCHITECTURE.md` §3 + §4.3 + §8 ("the Auditor re-runs every Ring-2/3 probe from the ledger"). "Reproduction" = the Auditor **independently re-invokes the re-runnable probe** in its own session, captures the output, hashes it, compares to the receipt's `probe_output_hash`. It is NOT "reads the worker's captured output file and confirms it has the right hash" — that would only verify the worker's record-keeping, not the probe result against current live state.

Concrete protocol:

- Worker emits receipt citing `probe_path` (a committed re-runnable artifact). The probe's last-run output is captured at `probes/<scope>/<timestamp>.txt` for record + `probe_output_hash` is the sha256 of that captured output.
- Auditor independently **invokes** the probe (the probe's own runner — a SQL runner for DB probes; a shell/HTTP invocation for others), captures the new output, hashes it.
  - If hashes match → `auditor_status = REPRODUCED`. WP transitions `VERIFIED → CLOSED` (orc merges `wp/<id>` branch to main).
  - If hashes differ → `auditor_status = DIVERGED`. WP transitions `VERIFIED → REOPENED`. NEVER edit the receipt.
- The freshness of the live state is **proven by the Auditor's re-run**, not by trusting the worker's captured output to remain representative.
- For Ring-2/3 probes against a surface the Auditor structurally **cannot reach** (no credentials in the Auditor environment) → `auditor_status = WAIVED` with explicit `auditor_notes` naming the unreached surface. WAIVED is NOT a freshness substitute; it is an **honest admission** that the file-state-scope Auditor cannot complete the reproduction. WAIVED can license CLOSED only when:
  - The worker-side probe is a documented re-runnable artifact (anyone with credentials can reproduce);
  - The receipt records the worker invocation timestamp (a future credentialed Auditor invocation establishes the freshness — not "trust the captured output").
- The **permanent fix per the live-result-gating class** (`docs/EXECUTION_PLAN.md` §3 live-result gating mechanism): a `live-prober` agent in a credentialed environment that the Auditor reaches via a separation-of-powers interface — Auditor reads the live-prober's output but cannot author probes itself. This removes the WAIVED scenario for substrate probes.
- Operator catches discipline gaps by friction (the operator-friction surface mode). orc surfaces friction as Class A blockers + files NEW WPs.

### Permanent fix

`docs/EXECUTION_PLAN.md` §3 + `docs/BUILD_ARCHITECTURE.md` §4 contemplate a `live-prober` agent in a credentialed environment that the Auditor reaches. P0.4 designs the mechanism. Until then, the §interim-cover applies.

---

## §Wiring — concrete Auditor invocation

**Directive verbatim:** "Before the first merge-to-main, document in auditor-contract.md exactly how the code-Auditor runs as a SEPARATE session (the post-commit hook wiring, the audit-only prompt) so the operator can confirm it genuinely exists and re-runs probes — not reads committed outputs. The auditor's independence is operator-confirmed, not orc-asserted."

### The 3 wired artifacts (operator-installable)

1. **`agents/post-commit-hook.sh`** (committed file; the canonical content for `.git/hooks/post-commit`).
2. **`agents/audit-system-prompt.md`** (committed file; the audit-only system prompt that bounds `claude -p` role).
3. **`scripts/install_post_commit_hook.sh`** (committed file; installs the hook into the operator's `.git/hooks/post-commit` since git hooks aren't versioned).

### Invocation pattern (the actual claude command)

The hook fires `claude -p` (Claude Code's headless mode) with the audit-only system prompt + a per-commit prompt:

```bash
# Inside .git/hooks/post-commit (installed from agents/post-commit-hook.sh):
claude -p "$AUDIT_PROMPT" \
    --append-system-prompt "$(cat "$REPO_ROOT/agents/audit-system-prompt.md")" \
    --permission-mode bypassPermissions \
    >> "$REPO_ROOT/ledger/audit-runs.log" 2>&1
```

- `-p "$AUDIT_PROMPT"` — headless mode with the per-commit prompt (commit sha + changed files + audit-task framing).
- `--append-system-prompt "$(cat agents/audit-system-prompt.md)"` — bounds the role: this `claude` instance IS the code-Auditor, NOT orc; cannot author/fix; only emits findings.
- `--permission-mode bypassPermissions` — required for the non-interactive Auditor to write its findings files AND run live-surface Bash; the system prompt's immutable role boundary is the guardrail on WHICH file it writes.
- `>> ledger/audit-runs.log 2>&1` — append-only log of every Auditor invocation (operator-readable provenance trail).

The hook backgrounds + disowns the `claude -p` invocation so commits don't block on audit completion (audit-findings land asynchronously).

### Skip-guard (avoid self-trigger loop)

If commit message contains `[audit]` prefix → hook exits 0 immediately. Prevents the Auditor's own audit-findings commits from triggering another audit pass.

### Per-WP-merge auditor trigger (AUDITOR INCREMENTAL per `schema/verification.md` §8.1)

The post-commit hook fires on every commit (including WP-branch commits + main-branch commits). For WP branches:
- Commit on `wp/<wp_id>` lands → hook fires → Auditor reads the changed files + the receipt(s) in `ledger/receipts.jsonl` → re-runs the cited probe(s) (`probe_path` field) → writes verdict to `ledger/audit-findings.md` + emits a NEW receipt (auditor-emitted; `actor: code-Auditor`) with `auditor_status: REPRODUCED` or `DIVERGED`.
- orc reads `ledger/audit-findings.md` + new audit receipts to decide merge-to-main (REPRODUCED) vs rework-loop (DIVERGED → backward-edge per `schema/state-machine.md` §Self-healing-backward-edges).
- This is per-WP, not per-wave. WP #1's audit runs while WPs #2-4 still execute on their own branches.

### Operator verification (independence is operator-confirmed)

The operator confirms the Auditor genuinely exists + runs separately by:

1. **Hook installation:** `ls -la .git/hooks/post-commit` → file present + executable. `diff .git/hooks/post-commit agents/post-commit-hook.sh` → matches (no drift).
2. **System prompt:** `cat agents/audit-system-prompt.md` → audit-only role bounds visible.
3. **Audit-runs log:** `tail -50 ledger/audit-runs.log` → recent invocations visible per commit; timestamps + commit shas tracked.
4. **Findings file:** `tail -100 ledger/audit-findings.md` → per-commit findings landed; per-commit-sha digest visible.
5. **Auditor-emitted receipts:** `grep '"actor": "code-Auditor"' ledger/receipts.jsonl | wc -l` → count >0 after a few commits.
6. **Re-run independence:** operator runs the probe's own runner manually + compares to Auditor's most-recent invocation output for the same probe → outputs match (Auditor is invoking the probe, not reading the worker's captured output).
7. **Process trace (live):** during a commit, `ps -ef | grep 'claude -p'` → backgrounded Auditor process visible during its run window.

If any of these checks fails → Auditor wiring defect; reopen this WP; revise the wiring.

### Operator install procedure (one-time)

```bash
cd "$REPO_ROOT"
bash scripts/install_post_commit_hook.sh
# Confirms install + chmod +x + dry-run hook (no actual commit; just hook readiness).
# First real commit thereafter fires the hook; ledger/audit-runs.log accumulates first entries.
```

### Auditor-emitted receipt shape

When the Auditor reproduces a worker's receipt, it appends a NEW receipt (per `schema/receipt.md` rule 4 — never edit prior) with:
- `actor: "code-Auditor"`.
- `supersedes_receipt_id: "<prior worker receipt_id>"`.
- `auditor_status: "REPRODUCED" | "DIVERGED" | "WAIVED"`.
- `auditor_run_at_utc: "<ISO 8601>"`.
- `auditor_notes: "<text incl. side-by-side hash comparison + WAIVED reason if applicable>"`.
- All other fields mirror the worker receipt (artifact_paths, probe_path, etc.) for provenance.

This NEW receipt is what licenses the merge-to-main per `schema/state-machine.md` §Branch-discipline (the worker receipt alone is insufficient; the Auditor receipt is the close gate).

### Standing-probe receipt shape (per the standing-probes wiring ruling)

When the Auditor emits a receipt for a STANDING probe (per `agents/audit-system-prompt.md` step 9 + `agents/standing-probes.yaml`), the receipt has a distinct shape because standing probes are NOT superseding a worker receipt — they assert FROZEN-contract invariants independent of any worker:

- `actor: "code-Auditor"`.
- `auditor_status: "STANDING_PROBE_PASS" | "STANDING_PROBE_PARTIAL_FAIL_EXPECTED" | "STANDING_PROBE_REGRESSION" | "STANDING_PROBE_RUN_ERROR"`.
  - Routing-equivalence (per `Routing on Auditor verdicts` below): `STANDING_PROBE_PASS` + `STANDING_PROBE_PARTIAL_FAIL_EXPECTED` route as REPRODUCED (informational only; no WP transition). `STANDING_PROBE_REGRESSION` + `STANDING_PROBE_RUN_ERROR` route as DIVERGED — orc files a NEW WP for remediation or maps onto an in-flight WP per `schema/state-machine.md` §Self-healing-backward-edges.
- `standing_probe_id: "<id>"` — the yaml entry id (e.g., `mediated-write-zero`).
- `standing_probe_path: "<path>"` — the probe path from yaml.
- `probe_exit_code: <int>`.
- `probe_output_hash: "<sha256>"`.
- `probe_last_run_at_utc: "<ISO 8601>"`.
- `supersedes_receipt_id: null` — standing probes do not supersede a worker receipt.
- `auditor_notes: "<text>"` — cite the yaml entry's `asserts:` field; for PARTIAL_FAIL_EXPECTED name the window predicate + violation count + class; for REGRESSION name the new violations.
- `verification_ring: 2` — standing probes assert against live substrate (Ring-2 per `schema/verification.md`).
- `git_commit: "<sha>"` — the commit triggering the auditor invocation that surfaced this standing-probe verdict.

**Emission cadence (volume control):** the Auditor emits a standing-probe receipt ONLY when:
- (a) probe FAILs OUTSIDE the partial_fail_window (true regression) OR RUN_ERROR;
- (b) verdict transitions vs the prior recorded receipt for the same `standing_probe_id`;
- (c) `cadence_emit_per_day` boundary crossed (default: not set → no cadence emission);
- (d) wiring-init sentinel — first-ever receipt for that `standing_probe_id`.

Plain PASS-on-PASS with no state change and not on cadence boundary → NO receipt emitted. The `ledger/audit-runs.log` invocation record is the sufficient liveness signal for non-divergent runs. This volume-control rule is load-bearing per the standing-probes wiring ruling dispatch §"Emit only when".

## Routing on Auditor verdicts

Per `docs/BUILD_ARCHITECTURE.md` §7 operating loop step 6 + the WAIVED pin + CLOSED-PROVISIONAL fix (per the reproduce-not-read sharpening):

- `REPRODUCED` → orc merges `wp/<id>` to main → WP `VERIFIED → CLOSED`.
- `REPRODUCED` PRIMARY + `WAIVED-with-notes` SUB-PORTION (per the primary-REPRODUCED-licenses-CLOSED pattern) → REPRODUCED primary licenses plain CLOSED; WAIVED sub-portion documented for honest provenance (Auditor sandbox couldn't reach a specific tool/surface for the sub-portion; the primary REPRODUCED on other portions stands).
- `DIVERGED` → WP backward-edge `VERIFIED → IN_PROGRESS` per `schema/state-machine.md` §Self-healing-backward-edges; orc dispatches the correction immediately + autonomously per `schema/verification.md` §8.3 SELF-HEALING. NEVER edit the receipt; the divergence IS the finding.
- `WAIVED` PRIMARY verdict (not a REPRODUCED-with-WAIVED-sub-portion) on a live-surface probe → **NOT plain CLOSED** per `schema/verification.md` §4.1 (per the architect WAIVED-primary pin). orc transitions WP to `CLOSED-PROVISIONAL` per `schema/state-machine.md` + files `_escalations/NNN.md` routing to operator spot-audit (operator holds live credentials) per §4.2. CLOSED-PROVISIONAL → CLOSED on operator-spot-audit REPRODUCED; → IN_PROGRESS rework on operator-spot-audit DIVERGED.
- Missing probe path / invalid receipt → WP `VERIFIED → IN_PROGRESS` (rework loop); orc dispatches investigation per §8.3 SELF-HEALING.

## What code-Auditor does NOT do

- Author fixes.
- Edit any artifact (probes, contracts, schema, agents, work-packages, ledger, migrations).
- Close WPs directly (orc's merge-to-main IS the close transition).
- Surface ambiguity to operator (uses receipt + escalation routing instead).
- Run probes against live surfaces it cannot reach (uses WAIVED + notes).

## Cross-references

- `schema/state-machine.md` — VERIFIED → CLOSED transition gate (merge-to-main).
- `schema/receipt.md` — receipt shape incl. `auditor_status` / `auditor_run_at_utc` / `auditor_notes` fields.
- `schema/verification.md` — 3 rings + probe-guard rule + boundary §3.
- `ledger/receipts.jsonl` — receipts the Auditor reproduces.
- `docs/EXECUTION_PLAN.md` §3 — live-result gating mechanism (permanent fix).
- `docs/BUILD_ARCHITECTURE.md` §4 + §7 step 6 + §8 — Auditor scope verbatim.
