# Verification — four rings + probe-guard rule + acceptance function

# GENERICIZATION NOTE: Stripped external-platform instance refs, real SP/app/DB names, ruling-doc cites, live dates, site-specific probe paths. Seat/role tokens renamed per §2 rename map. §8.1 AUDITOR INCREMENTAL + §8.3 SELF-HEALING + §8.4 BOUNDED RETRY kept verbatim in shape — these are the engine heart; referenced by the auditor engine. Adopter-supplied toolchain examples added where instance tools were named.

**Authority:** `docs/BUILD_ARCHITECTURE.md` §4 (verbatim sections 4.1, 4.2, 4.3, 4.4); `docs/EXECUTION_PLAN.md` §3 ("Ring 3 IS the UAT"); `docs/UAT.md` (Ring 3 acceptance contract); architecture verification-spine-refinement relay (Ring 0 + AUDITOR INCREMENTAL + PILOT-THEN-SCALE + WAVE-HALT).

## §1 — Four rings (Ring 0 added per architecture relay)

| Ring | Scope | Allowed inputs | Mechanism |
|---|---|---|---|
| **0 — Static checks** | **Per artifact (continuous; every artifact)** | **Worker-run; deterministic; cheap** | **parse/lint/type: e.g., `py_compile` + `ruff` + `mypy` (Python); SQL parse-validation (e.g., sqlfluff or syntactic dry-run); adopter-supplied static-check toolchain per artifact class** |
| **1 — Unit** | Per work package | Fixtures / test doubles permitted | Adopter-supplied unit test runner (pytest, T-SQL harness, API mock, etc.) |
| **2 — Contract conformance** | Per subsystem | Live environment, read-only probes | Per-object existence + access-control grant probes; API shape assertions; data-source binding assertions |
| **3 — Live-data integration** | Canonical path end-to-end | **Live data only — no hand-INSERT** | One real entity walked through research → approval → promotion → publish → verified external state |

**Ring 0 binding rule (worker-side):** A worker MAY NOT emit a receipt for an artifact failing Ring 0 (per `agents/worker.md` §Ring-0-binding). The receipt's mandatory `ring0` block (per `schema/receipt.md` §JSON-shape) records the static-check results — every parse/lint/type tool's exit code per-tool. The Auditor RE-RUNS Ring 0 on reproduction (deterministic, cheap; no live-state surface needed; file-state-scope check).

Ring 3 = the UAT, scaled from one happy-path to the full §1 capability surface (per `docs/UAT.md`).

## §2 — Probe-guard rule (universal; from BUILD_ARCHITECTURE §4.2)

Every claim of "applied / done / live / verified" **must cite a committed, re-runnable probe by path**. If no probe is cited, the claim is downgraded to "asserted — NOT verified" and the work package does **not** close.

- **Per-object assertions only.** Named existence checks for each target object.
- **Aggregate proofs are forbidden.** Never `COUNT(*) FROM <catalog>`. An aggregate cannot distinguish *missing X* from *surplus Y*. This is precisely the defect that produced the false "27/27 PASS" in the parts-bin history.
- **GRANT proofs are per-object** rows from the access-control catalog, filtered to the expected grantee.
- Probes live at versioned paths (`probes/<scope>/probe_<name>_<v>.<ext>`), are runtime-credential-safe, and are committed in the same change as the artifact they verify.

## §3 — Boundary: existence-check functions conflate absence with no-permission

From non-owner runtime contexts (e.g., a workload application user `{{DB_APP_USER}}`), existence-check functions may return a null-equivalent for BOTH "object does not exist" AND "caller has no permission." Probes that test existence from a restricted runtime context risk false-MISSING verdicts on present-but-ungranted objects. Mitigations:

- For substrate existence: probe via per-named-object existence check from the restricted context, AND probe the access-control catalog per-grantee. If an access-control row exists but the existence check returns null → present-but-ungranted scenario; receipt records `WAIVED` with notes; follow-up WP files a GRANT migration (next free number) per the operator-confirmed pattern.
- For owner-context cross-check: if restricted-probe surfaces ambiguity AND no access-control row exists, escalate to operator-attended existence check from owner context for ground truth.

## §4 — Acceptance function

```
CLOSED              ⇔ receipt_exists ∧ probe_exit_0 ∧ auditor_REPRODUCED
CLOSED-PROVISIONAL  ⇔ receipt_exists ∧ probe_exit_0 ∧ auditor_WAIVED (live-surface)
                       ∧ verification_owed_to_operator_spot_audit (per §4.2)
```

`auditor_REPRODUCED` means `auditor_status = REPRODUCED` (Auditor independently re-invoked the probe + hashes match per `agents/auditor-contract.md` §Interim-cover RE-RUN semantics).

`probe_exit_0` means the probe's `probe_exit_code` field is 0 AND the probe's structural assertions all PASS (e.g., §5 SUMMARY = ALL_PRESENT for existence probes; per-section PASS for multi-section probes).

### §4.1 — WAIVED is NOT a pass (per architecture pin + fix)

**WAIVED CANNOT license CLOSED on the Auditor alone.** WAIVED is an honest admission that the Auditor structurally cannot complete a portion of the reproduction (per `agents/auditor-contract.md` §Interim-cover — credentialed surfaces the Auditor cannot reach).

**WAIVED licenses CLOSED-PROVISIONAL only** (per architecture pin): a new state added to `schema/state-machine.md` meaning *"closed on worker self-attestation, not independently verified."* CLOSED-PROVISIONAL WPs are tracked as a set; independent verification routes to operator spot-audit (operator holds the live credentials).

Rationale (architecture verbatim): *"WAIVED-licenses-CLOSED closes those WPs on the WORKER's self-attestation — the exact fake-closure-via-attestation pattern. The 24h freshness window guards staleness, not independence."* WAIVED is honest; WAIVED-licenses-plain-CLOSED is a fake-closure backdoor.

**Mixed verdicts** (per architecture pattern): a single Auditor-emitted receipt may carry `auditor_status = REPRODUCED` on a primary portion + `WAIVED-with-notes` on a sub-portion. REPRODUCED on the primary portion licenses plain CLOSED; the WAIVED sub-portion is documented for honest provenance (e.g., REPRODUCED on N/N file-state assertions + WAIVED-with-notes on a live-tool re-run the Auditor sandbox couldn't invoke). The primary REPRODUCED is the merge-license; the WAIVED sub is documented, never silently substituted.

### §4.2 — WAIVED routing (per architecture pin fix)

If an Auditor-emitted receipt's PRIMARY verdict is WAIVED (not a sub-portion):
1. Executor does NOT merge the WP branch to plain `CLOSED`.
2. Executor transitions the WP to `CLOSED-PROVISIONAL` per `schema/state-machine.md` (merge to main happens; WP is tracked in the CLOSED-PROVISIONAL set; independent verification is OWED).
3. Executor files an entry in `_escalations/NNN.md` per `docs/PROTOCOL.md` §2.2: surface to **operator spot-audit** queue (operator holds the live credentials and performs independent verification on their cadence; spot-confirmed → executor transitions CLOSED-PROVISIONAL → CLOSED; DIVERGED → rework backward-edge per `schema/state-machine.md` §Self-healing-backward-edges).
4. Operator spot-audit can be batched (multiple CLOSED-PROVISIONAL WPs in one operator session); cadence per operator discretion; does NOT block other build forward-movement.

The PRIOR rule (WAIVED + worker-probe freshness ≤24h licenses plain CLOSED) is **WITHDRAWN** as a fake-closure backdoor.

### §4.3 — Open question (operator-bound; routed to `_escalations/004`)

Whether to stand up a read-only credentialed verification path so live-surface probes get automated independent reproduction instead of operator spot-audit. This is a Phase-0+ design WP per `docs/EXECUTION_PLAN.md` §3 live-result gating mechanism. The interim is operator spot-audit per §4.2; the permanent design removes the operator-touchpoint for routine substrate verification.

## §5 — Self-proving exit gate (Phase 0)

Per `docs/BUILD_ARCHITECTURE.md` §6 Phase 0 exit gate: *"verification spine self-proves (a probe of a known-present object returns PRESENT; a probe of a deliberately-absent object returns MISSING — the framework is proven to detect drift before it is trusted)."*

The verification spine is operationally self-proved by:
- Re-running a positive-case probe against the live substrate → §5 SUMMARY = ALL_PRESENT validates positive case.
- Running a contrived probe of a deliberately-absent object → returns MISSING (validates negative case). This is a P0.4 WP-level deliverable.

## §6 — Live-result gating mechanism (live-scope-boundary class; v0.2 §3)

The parts-bin surfaced (see issues register) that the file-state-scope code-Auditor structurally cannot verify live state. The clean apparatus addresses this as a P0.4 deliverable: a live-substrate claim cannot be admitted to a canonical artifact without a probe RESULT (not merely a probe-shape-present check). The mechanism:

1. Probe runs at receipt-emit time → captures `probe_exit_code` + `probe_output_hash` in receipt.
2. Auditor reproduces by re-running probe → compares output hash; if match → REPRODUCED; if mismatch → DIVERGED.
3. For live-substrate probes the Auditor cannot reach: `WAIVED` with explicit notes; the worker-probe freshness window (24h) bounds receipt validity for the live surface.
4. Future enhancement (post-Phase-0): a service-account-credentialed `live-prober` agent runs in the Auditor's environment, removing the WAIVED scenario for substrate probes.

## §7 — Anti-fake-resolve discipline (from BUILD_ARCHITECTURE §8)

- **The receipt ledger is the single source of truth** for what is done. Every CLOSED package carries a receipt.
- **Probe-guard rule is universal.** Aggregate proofs forbidden.
- **Auditor re-runs, never trusts** — independent session, separation of powers, cannot author or fix.
- **No `IN_PROGRESS → CLOSED` edge** — structurally impossible to close without a green receipt.
- **LIVE-DATA-ONLY integration** — Ring 3 forbids hand-INSERT; Auditor scans for bypass INSERTs.
- **Forward-queue discipline** — build-time discoveries become new work packages, never silent scope changes.
- **Every fix increments a version** — no silent in-place patching of deployed artifacts.
- **Roles stay in lane** — the builder never signs off on its own build.

## §8 — Auditor cadence + pattern discipline + self-healing (per architecture relay)

The largest blast radius of any defect MUST = one work package. No "rewrite N WPs" event is permitted by the model. Defects are **work-generating events, never stop events** — the build never stops.

### §8.1 — AUDITOR INCREMENTAL

The Auditor reproduces a WP's checks **the moment that WP branch is receipt-ready** — per-WP, never batched per-wave. A wave's WP #1 is audited while WPs #2-4 still run. Wiring per `agents/auditor-contract.md` §Wiring (post-commit hook fires the auditor per-commit; receipt-ready = WP branch has a HEAD commit with a receipt landed in `ledger/receipts.jsonl`).

### §8.2 — PILOT-THEN-SCALE (reframed as DAG dependency, not halt)

The FIRST WP exercising a NEW PATTERN (new sproc call shape, new module type, first WP against a given contract) is a **DAG dependency** for the pattern's remaining WPs. The pilot runs SOLO and is fully verified (Rings 0-2 + Auditor reproduction REPRODUCED) before sibling WPs of the same pattern dispatch.

This is **normal dependency behavior**, NOT a halt. A dependent wave waiting on the pilot is the DAG operating-loop functioning correctly (`agents/orchestrator.md` §Operating-loop step 2 frontier computation respects deps). Executor dispatches OTHER tracks meanwhile — the frontier stays non-empty per `agents/orchestrator.md` §Operating-loop + cadence §2.2.

Already-proven patterns → straight to parallel waves. Executor judges per-track + records the pattern-pilot designation in the WP file (e.g., "pattern: <name>, pilot=WP-X-NNN" or "pattern-pilot: yes").

### §8.3 — SELF-HEALING (per architecture relay, supersedes prior WAVE-HALT framing)

**Defects are work-generating events, never stop events.** On an Auditor FAIL (`auditor_status = DIVERGED`):

- **Receipt the FAIL.** The failure is a tracked fact — Auditor emits a NEW receipt (per `schema/receipt.md` rule 4 — never edit prior receipts; new receipts supersede) with `probe_exit_code != 0` OR `auditor_status = DIVERGED` recorded.
- **The WP does NOT merge.** Per `schema/state-machine.md` §Branch-discipline, only REPRODUCED + freshness-met receipts license merge-to-main. `main` never receives a defective artifact — "move forward" never means merging known-bad code.
- **The WP loops to IN_PROGRESS (rework) ON ITS BRANCH.** Per `schema/state-machine.md` §Self-healing-backward-edges, this is a NORMAL FLOW transition (VERIFIED → IN_PROGRESS or AWAITING_RECEIPT → IN_PROGRESS), not a state-machine exception.
- **Executor dispatches the correction immediately + autonomously** (no operator surface per cadence §2.1 — not binding-class).
- **Shared-pattern propagation:** if the failure implicates a shared pattern across in-flight sibling WPs, executor fixes the pattern ONCE and propagates corrective commits to the sibling WP branches. Sibling WPs **rework, they do NOT freeze.**
- **All WPs not touching the defect continue at full speed.** The frontier stays non-empty per `agents/orchestrator.md` §Operating-loop. Executor never idles. **The BUILD never stops.**

### §8.4 — BOUNDED RETRY

A WP that fails → reworks → fails again past **2-3 attempts** STOPS self-looping and escalates as a genuine "cannot self-resolve" item (logged to `_escalations/`, batched per `docs/PROTOCOL.md` §2.2).

This is the guard against silent infinite correction loops. Executor tracks rework-attempt count per WP in the WP's `state_history` block (count of backward edges into IN_PROGRESS); on attempt 3+ → escalate.

### §8.5 — Ring 0 worker-binding (encoded as §1 binding rule)

Per §1 Ring 0 binding rule above + `agents/worker.md` §Ring-0-binding: a worker MAY NOT emit a receipt for an artifact failing Ring 0. The receipt's `ring0` block records each static-check tool's exit code per-tool (e.g., `{"py_compile": 0, "ruff": 0, "mypy": 0}` for a Python artifact; `{"sql_parse": 0}` for a SQL artifact).

The Auditor RE-RUNS Ring 0 on reproduction (cheap, deterministic, file-state-scope; no live credentials needed). If Ring 0 re-run divergent → `auditor_status = DIVERGED` → WP loops to IN_PROGRESS per §8.3 self-healing.
