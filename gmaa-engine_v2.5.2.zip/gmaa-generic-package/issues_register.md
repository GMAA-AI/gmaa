<!-- GENERICIZATION NOTE: genericized from origin issues_register.md; instance header text (project name, currency block, OPEN-ISSUE table with live entries) stripped; generic header, protocol statement, and empty register stub retained. Origin pin: a0929259. -->
<!-- skeleton -->
# issues_register.md — {{PROJECT_NAME}}

Open issues + named risks + discipline findings. Architect proposes ISSUE bodies; foundation
commits (governance-class per `contracts/BUILD_ARCHITECTURE.md §3.5`). No settled decision is
re-raised — run `scripts/governance.sh <topic>` (cite-before-raise / reopen) first. Evidence is
enumerated, not asserted (no-fake-closures invariant / `docs/FOUNDATION.md §8.2`).

---

> **Protocol:**
> - OPEN issues are live work items — owner + next-action required.
> - RESOLVED requires an evidence chain (SHA + re-runnable probe verdict). No fake closures.
> - RETRACTED when a premise was wrong (not when the issue was "fixed" with an incorrect explanation).
> - SCHEDULED issues fire on an explicit trigger (name the trigger); not tracked in the open table.
> - No settled decision is re-raised without a `governance.sh` cite-first check.

---

## OPEN-ISSUE CURRENCY (refreshed <date>-r0)

*(No open issues yet — initial skeleton.)*

| Issue | Sev | Owner | Next-action |
|---|---|---|---|
| *(issue id)* | P* | *(owner)* | *(next action — specific, not "investigate")* |

---

## Register

*(No issues filed yet. Use `scripts/append_issue.py` to file the first issue.)*

---

<!-- ISSUE TEMPLATE (copy when filing manually):

## ISSUE-### — SHORT-TITLE

- **Status:** Open
- **Severity:** P1 / P2 / P3
- **Filed:** <date>
- **Source:** <dispatch/sprint doc / probe finding / operator-observed>
- **Description:** <what the issue is — evidence enumerated, not asserted>
- **Hypothesis:** <what the suspected cause is — flagged as hypothesis, not ground truth>
- **Next action:** <specific next step to confirm or refute the hypothesis>
- **Evidence:** <artifact paths, SHAs, probe outputs — required for RESOLVED>

-->
