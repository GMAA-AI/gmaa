# STRIP-RECORD — GMAA generic engine (what was stripped / abstracted from origin)

**Consolidated account carried by the sealed artifact.** Pin: origin `a0929259`. Authored by foundation from
the P1/P2 genericization ruleset (`P2-GENERICIZATION-RULES.md`), the applied classification
(`CLASSIFICATION-APPLIED.md`), and the per-file genericization notes. **Method-level — no origin instance
token is reproduced here** (that would defeat the strip).

## Removed — never shipped
- **Low-disclosure MUST-NOT-SHIP:** all real connection / IMTCONN ids, cloud tenant / service-principal /
  subscription / resource ids, API-key values, site domains, CMS author / category / post ids, snippet ids,
  real UPNs / emails.
- **Instance operating record:** rulings / dispatch / orchestration history, session bootstraps, runbooks,
  site-lane and adopter-stack (automation / CMS / cloud-DB / data-provider) specifics, specialist
  deploy/team agent-defs, and the dual-track topology.
- **Real names:** project / program nouns, seat / lane names, service-principal and database-role
  identities, sproc names carrying project namespaces, real object counts / timestamps from a live
  extraction.

## Abstracted — kept as neutral generic (mechanism preserved)
- **Census renames:** origin seat / lane names → the generic census (`foundation` + `executor` +
  `{{MODULE_LANE}}…`, plus `dispatch-executor` / `build-worker` / optional `architect` / `designer`).
- **Declared slots:** `{{PROJECT_NAME}}`, `{{SCHEMA}}` / `{{REF_SCHEMA}}` / `{{PUBLISH_SCHEMA}}`,
  `{{DB_APP_USER}}`, `{{EXECUTE_MECHANISM}}`, `{{FUNCTION_APP}}`, the work-queue / publish-target /
  direct-seed / first-party sentinels, and `{{GATE_LABEL}}`.
- **Form-1 (2026-08-06 operator ruling):** the distinctive origin object / column names that survived earlier
  passes were abstracted to neutral generic names; the gate-label enumeration was relabeled to a continuous
  neutral scheme (`G1…G13`) that no longer mirrors origin's gate naming. The gate sequence/structure and the
  DB contract SHAPE are UNCHANGED — genericization of names / labels only, no re-architecture.

## Kept verbatim in shape — the method (the point of the engine)
The governance machinery (lane resolution, launch, sync, commit hooks, auditor, reaper, currency), the
coordination protocol, the gate-contract and DB-contract SHAPES (BINDING/INCIDENTAL model,
mediated-write-zero, evidence / halt-reject taxonomy, state machines), the canon (v1.5) and the
coherence-session-law addendum, and the boot chain (identity + boot-creed).

## Verification
Origin-grounded at pin `a0929259`: the distinctive-name sweep is 0 in deliverable files; replacement names
are confirmed 0-origin. **History note (2026-08-06):** the Form-1 gate-label relabel initially MISSED two
example/stub occurrences of origin gate-id tokens (one in `schema/work-package.md`'s wp_id example, one in
`docs/FOUNDATION.md`'s gate-stub table row) — caught by origin's XP-08 pre-seal review; both were
neutralized to the neutral G-scheme, and a full 68-deliverable sweep for origin gate-id tokens now returns 0.
The gate-label fingerprint is relabeled. Origin's XP-08 review also drove a residual-vocabulary scrub of C-GATE
(product-review/SEO terms → neutral) per the operator's 2026-08-06 ruling; the gate SEQUENCE/STRUCTURE is
byte-stable. Independent re-verify is origin's / the seat's — the packaging project does not sign its own
work.

— foundation, 2026-08-06. Strip-record for the v2.5.0 seal.
