<!-- GENERICIZATION NOTE: genericized from origin dispatch/LATEST.md pattern; instance state, real SHAs, active WP ids, and session-specific hand-off content stripped; generic live-pointer header + resume-handoff stub retained. Origin pin: a0929259. -->
<!-- skeleton -->
# dispatch/LATEST.md — live in-flight orchestrator state

**What this is.** The live pointer to the current orchestration state. Every seat reads this
**before any mutating action** (anti-stale; COORDINATION §3). This file REPLACES a legacy
`STATE.md` pattern — one canonical live pointer, not two competing state files.

**Revision:** r0 (initial skeleton — no active WP)

**Last updated by:** foundation · <utc-timestamp>

---

## Current state

**Active WP:** none

**In-flight lane:** none

**Last completed WP:** none

**Blocking:** none

---

## Resume handoff

> **Adopter instructions:** when a session closes mid-WP (pre-restart, context-boundary, or
> explicit B6.1 externalize), the closing seat writes a resume-handoff block here before ending
> the session. The reopening seat reads this block as its FIRST action after cold-boot + HEAD read.

### Resume handoff template (copy when writing a handoff)

```
## Resume handoff — <WP-id> pre-<session-close-reason>

**Written by:** <lane> · <utc-timestamp>
**WP:** <WP-id and short title>
**PASS reached:** PASS N (complete) / PASS N+1 (next)
**Last committed SHA:** <sha>
**In-flight file(s):** <paths that have unsaved WIP if any>
**Open receipts:** <receipt ids or "none">
**Next action:** <exact next step the resuming seat must take>
**Constraints / warnings:** <anything that would cause PASS-0 STOP-AND-SURFACE>
```

---

## §B6 RESTART-HANDSHAKE how-to (generic, binding)

1. **Signal restart:** operator says so, OR seat self-recognizes at ~70% context / a WP boundary.
2. **Externalize state:** commit or stash all WIP; update this file with the resume-handoff block;
   confirm "ready for restart" in chat.
3. **End the session** — operator runs the restart wrapper:
   `scripts/orc-restart.sh <lane> --force` (checkpoint-gate → kill → relaunch).
4. **Relaunch is ALWAYS via the launch script** (`scripts/launch-orc.sh <lane>` or
   `scripts/orc-up.sh <lane>`) which creates the NAMED tmux session (session-name == lane, the
   doorbell R1 key) at the worktree cwd and runs `claude --agent orc`.
   **NEVER a bare `claude --agent orc`** (no named tmux session means the doorbell cannot resolve
   the lane; this is a protocol, not an implementation detail).
5. Cold-boot grounds from HEAD (`CLAUDE.md §0`), not from any compact summary.
