# GENERICIZATION NOTE (FORM-1 ABSTRACTED per operator ruling 2026-08-06 — origin-grounded vs pin a0929259):
# The gate-label ENUMERATION was relabeled to a neutral continuous {{GATE_LABEL}}-class scheme (G1…G13) so the
# labels no longer mirror origin's gate naming one-to-one (the prior label set reproduced origin's letter
# scheme + skipped-letter). The gate SEQUENCE/structure is UNCHANGED (no re-architecture) — only the labels
# are genericized. Distinctive origin field names were abstracted to neutral generics (no origin-identifying
# field name remains). The direct-seed seed + {{DIRECT_SEED_SENTINEL}}/{{FIRSTPARTY_SENTINEL}} sentinels are slotted;
# {{EXECUTE_MECHANISM}} slots the execution wiring. Also stripped: domain-specific tool bindings,
# instance-specific integrations/identifiers and example values, and all
# MUST-NOT-SHIP tokens (real ids, domains, service names). The gate-sequence CONTRACT SHAPE —
# inputs/outputs/evidence/halt-reject taxonomy/state machine/cross-cutting invariants — is fully preserved
# and neutral. Slot {{EXECUTE_MECHANISM}} documents where the adopter wires execution.

# C-GATE — Pipeline Gate Sequence Interface Contract — v0.1

*One of the core interface contracts. The frozen contract the research/enrichment track builds against,
and the verification spine (Rings 1–2) probes against.*

**Status:** v0.1 — frozen-candidate. The gate sequence, per-gate I/O field sets, evidence requirements,
halt/reject conditions, and state transitions are authoritative. Physical column/table mapping defers to
**C-DB**. One region (post-gate quality summary + operator-surface amendment) is pending v0.2 reconciliation
— see §8.

---

## §0 — Contract scope and rules of use

C-GATE freezes the **gate interface**: the sequence, each gate's inputs and required outputs, the observable
evidence each gate must emit, its halt/reject conditions, and the state transition it triggers. A gate-module
worker builds against C-GATE — never against another gate's code. Field names here are **logical**; C-DB maps
them to physical columns/sprocs. Where C-GATE and live behavior diverge, the reconciliation pass surfaces it
and the contract or the build is corrected — never paraphrased over.

Each gate's **Required outputs** field set IS the Ring-1/Ring-2 verification checklist for that gate.

**Execute-mechanism slot:** every gate that fires an automated verification step dispatches via
`{{EXECUTE_MECHANISM}}`. The adopter fills this slot with their execution binding (an HTTP endpoint,
a function invocation, a queue consumer, etc.). The contract is neutral to that binding; the interface
shape (inputs, outputs, halt codes, receipt) is what this document specifies.

---

## §1 — The two entry paths

The pipeline has two co-equal entry paths that **converge at Gate G3** and run identically thereafter.

- **Discovery path.** Entry at Gate G1 (trend/candidate research) → candidate items → Gate G2 (human
  approval of candidate) → Gate G3. The native sequence.
- **Direct-seed path.** Operator quick-seeds a specific item. The item is attached to a permanent pre-approved
  sentinel record (`{{DIRECT_SEED_SENTINEL}}`; approval condition satisfied by construction). Because the sentinel
  is already approved, Gate G2 Branch A is satisfied; the item enters at Gate G3. Gate G1 is bypassed
  **by design** — not skipped.

Both paths run **G3 → G4–G6 → G7 → G8 → G9 → G10 → G11 → G12 → G13** identically. Gate G13 Branch B
is common to both.

**Gate-dependency DAG** (feeds the work-package DAG):
`G1 → G2 → G3 → G4 → {G5 ∥ G6} → G7 → G8 → G9 → G10 → G11 → G12 → G13`
(Direct-seed path enters at `G3` with `G2` pre-satisfied. `G5` and `G6` are a parallel sub-frontier
after `G4` establishes `canonical_name` + `model_identifier`.)

---

## §2 — Cross-cutting contract invariants

Every gate worker MUST satisfy these; they are also verification checks.

- **CC-1 Evidence, not intuition.** Every fact carries source URL + fetch timestamp + tool-call ID. Unsourced
  facts are invalid; the gate halts.
- **CC-2 Current, not cached.** Item/candidate/peer facts come from fetches in *this* run. Training
  knowledge and stale caches are not valid sources.
- **CC-3 Liveness.** Every evidence URL carries `last_verified_live`. Re-verified at content-gen, at publish,
  and periodically after (adopter sets cadence).
- **CC-4 Capture, not just cite.** The fetched content/excerpt is stored, not merely referenced.
- **CC-5 Halt on missing evidence.** Missing required output → gate halts. No best-effort advancement. Absolute.
- **CC-6 Separation of research from writing.** Research produces facts; content generation only transforms them.
- **CC-7 Two-tier.** Research outputs land in the research tier; Gate G13 promotes to the publish tier.
- **CC-8 Quality-branch.** Adopter defines quality-branch rules (e.g., regulated-content stricter evidence).
  Every gate should have a quality-branch configuration point. The base contract provides standard behavior;
  quality branches add evidence requirements.
- **CC-9 Per-item isolation + dossier reuse.** Gates run per-item. The most-stringent enforcement is at dossier
  level, so one dossier is reusable across multiple output formats without re-research.
- **CC-10 Live-doc verification for platform facts.** Platform/tool behavior verified against a current fetch
  of live documentation, not training knowledge.
- **CC-11 Anti-hallucination at content generation.** The publishing prompt uses ONLY dossier-supplied facts;
  never invents specs/measurements/features; emits `[INPUT_ERROR: field]` rather than filling an empty input.
- **CC-12 Compliance markers.** See §5.
- **CC-13 Voice guardrails.** Adopter-defined tone/style rules applied post-generation (phrase strips, length
  rules, etc.).

---

## §3 — The gate sequence

Template per gate: **Path · Prerequisites · Inputs · Required outputs (field set) · Evidence · Halt/Reject ·
Branches · State transition.**

### G1 — Candidate & Trend Research
- **Path:** Discovery only. **Prereq:** none (entry gate).
- **Inputs:** `(corpus, category)` pairs.
- **Required outputs:** ranked candidate items per `(corpus,category)`; per item — `query_text`,
  `demand_metric` (absolute if paid tool, else relative trajectory + signal strength), `visibility_pct`,
  `intent_class` ∈ {high,medium,low}, `format_fit` ∈ {comparison,single,guide,head_to_head,top_n},
  `seasonality_tag` ∈ {year_round, seasonal:{peak}}; an evidence block per item.
- **Evidence:** ≥2 source URLs from ≥2 distinct source classes per item; per-source fetch timestamps;
  captured signal artifact (trend curve, ranking page); seasonal-tag evidence.
- **Halt/Reject:** item with <2 source classes → **DROP**. Structurally-unreachable (e.g., all results
  first-party-controlled or equivalent) → **EXCLUDE**.
- **Branches:** adopter defines corpus-specific categories; regulated-content items screened per adopter
  compliance rules.
- **State:** emits candidate rows at `candidate_status = in_progress`, then `→ ready_for_approval`.

### G2 — Candidate Approval (human)
- **Path:** Discovery only. **Prereq:** G1 complete for the candidate.
- **Inputs:** candidates at `candidate_status = ready_for_approval`.
- **Required outputs:** decision ∈ {APPROVED, REJECTED, HOLD}; `candidate_status` set accordingly; decision
  timestamp + reviewer identity.
- **Evidence:** decision + timestamp + reviewer identity. REJECTED reason from the adopter-defined closed set.
- **Halt/Reject:** rejection blocks all downstream research under that candidate.
- **State:** `candidate_status: ready_for_approval → approved | rejected | hold`; `hold → ready_for_approval`
  on resume.

### G3 — Duplicate Check
- **Path:** both (convergence point). **Prereq:** discovery — G1 + G2 APPROVED; direct-seed — sentinel
  record (pre-approved).
- **Inputs:** candidate item under an approved candidate record.
- **Required outputs:** `duplicate_check_result` ∈ {CLEAR, DUPLICATE, REPLACEABLE, VARIANT}; for REPLACEABLE —
  prior row ID + replacement reason + supersede linkage.
- **Evidence:** query log of the item identity lookup against **both** tiers (research + publish). Zero
  "assumed clear" results.
- **Halt/Reject:** DUPLICATE → item halts, does not advance to G4. Status string read literally.
- **Branches:** per-corpus scoped. Cross-corpus dossier inheritance is an optimization (signal emitted,
  actuation deferred — not correctness-blocking).
- **State:** REPLACEABLE marks the prior row `superseded`.

### G4 — Primary Source Research
- **Path:** both. **Prereq:** G3 result CLEAR or REPLACEABLE.
- **Inputs:** candidate item identity.
- **Required outputs:** `canonical_name` (authoritative name + descriptor; marketing noise stripped,
  type noun kept), `model_identifier` (**the disambiguator** for G7 verification and wrong-item detection —
  capture failure halts the gate), `source_url`, structured spec data (verbatim from authoritative source),
  `included_components`, `usage_terms`, `source_emphasized_attributes`, `source_omitted_attributes`,
  `source_type` ∈ {primary_source, listing_detail, secondary_source, social, attachment}.
- **Evidence:** fetch record for the source URL (tool-call ID, timestamp, HTTP status); captured content
  sections (title, spec table, terms block); verbatim extraction trivially matchable to the capture;
  zero training-knowledge fields.
- **Halt/Reject:** source page 4xx/5xx → retry once → no-primary-source branch. Identity mismatch
  (supplied item identity's product ≠ source page's `model_identifier`) → item **rejected**.
- **Branches:** no-primary-source (listing fallback; `[NO PRIMARY SOURCE — specs from {source}]` note);
  quality-branch (third-party certifications, full disclosure, testing, references).
- **State:** item row created at `in_progress`.

### G5 — User Experience Research
- **Path:** both. **Prereq:** G4 complete.
- **Inputs:** `canonical_name`, `model_identifier`.
- **Required outputs:** user-experience research (real user reviews, reported usage, common praise/complaints —
  all sourced per CC-1); `[NEW ITEM]` determination (set when insufficient user reviews); `reviewer_notes`
  substantive content.
- **Evidence:** sourced user-review fetches (URLs, timestamps, captured excerpts) across multiple source
  classes; zero training-knowledge claims.
- **Halt/Reject:** insufficient real-user evidence with no `[NEW ITEM]` justification → halt per CC-5.
- **Branches:** quality-branch (reported issues, time-to-effect, interaction reports, verified-user
  flag).
- **State:** contributes to `in_progress` row.

### G6 — Competitive Landscape Research
- **Path:** both. **Prereq:** G4 complete (∥ G5).
- **Inputs:** `canonical_name`, item category.
- **Required outputs:** peer items — each `{name, identifier (URL-extracted), value}`; source citations
  — each a 7-field row `{source, author_if_attributed, date, url, methodology_excerpt, verdict_excerpt,
  rating_if_applicable}`; source coverage count.
- **Evidence:** every peer's listing page fetched, identifier by URL extraction (never typed); ≥1
  source citation per single-item dossier; **≥2 distinct sources per dossier** (CC-9).
  Per-citation 7-field validation, per-row.
- **Halt/Reject:** zero source citations → "emerging" downgrade (not exclude). <2 distinct sources →
  dossier is **single-format-only-eligible**, not comparison-eligible (adopter small-corpus override recorded
  in `completeness_overrides`).
- **Branches:** quality-branch — source classes ranked: primary-testing (primary) > synthesis
  (supporting) > opinion (secondary only).
- **State:** completes the G4–G6 sub-frontier; item eligible for G7.

### G7 — Listing Verification
- **Path:** both. **Prereq:** G4–G6 complete (G4+G5+G6 all valid).
- **Inputs:** `canonical_name`, `model_identifier` (search query + verification key).
- **Procedure:** A — search a listing source for `{model_identifier}`; extract candidate identifier
  (adopter-defined extraction pattern). B — fetch the candidate page; confirm checks: title contains
  `model_identifier` (substring, case-insensitive), category-match, available, retrievable. C — quality
  gates: minimum review count, minimum rating (or `[NEW ITEM]`). D — all pass → write `item_id`; any fail →
  discard, retry from A; after N retries (adopter-configured, default 3) → terminal rejection.
- **Required outputs (verified-success):** `item_id` (adopter-defined format), `listing_url`,
  `current_value`, `availability_status`, `feedback_count`, `rating`.
- **Evidence:** fetch records for every listing URL attempted incl. retries (tool-call ID, timestamp, HTTP
  status); captured success page; item-id-format assertion.
- **Halt/Reject:** item not found or unavailable → reject. Wrong-item after retries (`model_identifier` not
  in title) → reject (do NOT adapt research to the wrong item). Terminal rejection after N retries →
  `rejected`.
- **Branches:** quality-branch (certification flags, labeling-compliance checks).
- **PROHIBITED:** item_id from training knowledge; assuming an item exists; search-snippet-only confirmation;
  writing `item_id` when title lacks `model_identifier`; unverified comparison identifiers;
  browser-automation for item verification.
- **State:** verified-success keeps `in_progress`; terminal rejection → `rejected`.

### G8 — Item Verification Flag (Human)
- **Path:** both. **Prereq:** G7 verified-success (`item_id` written).
- **Inputs:** item row with `item_id`.
- **Required outputs:** `item_verified = TRUE`, `item_verified_by` (human identity), `item_verified_at`
  (timestamp).
- **Evidence:** human identity recorded; timestamp; optional reviewer note.
- **BINDING PROHIBITION:** automated steps — seeders, scripted agents, scheduled jobs — **MUST NOT** set
  `item_verified = TRUE`. Any automated step writing TRUE is a protocol violation and must be patched to
  leave it FALSE/blank. This invariant survives all refactors.
- **Halt/Reject:** stays FALSE until a human sets it; no downstream gate advances. Human revert → row
  reverts to research-in-progress, prior outputs preserved + flagged for re-review.
- **State:** human action renders the row eligible for G12 (no state field change; eligibility gate).

### G9 — Term / Signal Research
- **Path:** both. **Prereq:** G8 complete (`item_verified = TRUE`).
- **Inputs:** item dossier.
- **Required outputs:** `target_term` (2–5 words, query-intent), `demand_volume`, `visibility_pct`,
  `term_difficulty` (if available), `intent_class`, `alternates_rejected` (with reason),
  `region_terms` (adopter-configured count), `qa_prompts` (adopter-configured count), `focus_term`
  (2–5 words, lowercase), `summary_text` (adopter-configured max length, includes focus term,
  CTA ending).
- **Evidence:** paid-tool snapshot, OR on the manual path all three of {search-results screenshot with
  overview state, related-questions content, autocomplete} — mandatory; minimum one verified demand signal.
- **Halt/Reject:** demonstrable zero/near-zero volume → halt + retry. All candidates structurally
  unreachable → operator review.
- **Branches:** quality-branch — regulated-claim terms screened out; reframe to compliant phrasing or
  reject.
- **State:** keeps `in_progress`.

### G10 — Category & Author Assignment
- **Path:** both. **Prereq:** G9 complete.
- **Inputs:** item, target corpus.
- **Required outputs:** `category_slug` (valid slug for the corpus), `author_name` (matches the assignment map
  exactly), `author_bio`.
- **Evidence:** `category_slug` verified against the corpus's live category list (CC-10); `author_name`
  matches the adopter assignment map verbatim.
- **Assignment maps:** adopter-defined per corpus. The assignment map is authoritative; author disagreement → halt.
  See adopter configuration.
- **Halt/Reject:** category slug not matching a live category → halt (operator). Author disagreement with
  assignment map → halt (assignment map is authoritative).
- **Branches:** quality-branch — author credential requirements stricter; prohibited terms enforced;
  authors without disclosed relevant credentials cannot be assigned regulated content.
- **State:** keeps `in_progress`.

### G11 — Value / Signal Capture
- **Path:** both. **Prereq:** G10 complete.
- **Inputs:** G7's fetch record.
- **Required outputs:** `current_value` (from G7's live-page fetch), `value_tier`.
- **Evidence:** price sourced from G7's fetch record, not re-queried from memory.
- **Halt/Reject:** value outside adopter-configured band → flag for operator review (not auto-reject).
  Value missing → **halt** (G7 should have rejected the item).
- **State:** keeps `in_progress`.

### G12 — Completeness Check
- **Path:** both. **Prereq:** all of G1–G11 complete.
- **Inputs:** the full item row + all gate outputs.
- **Required outputs:** completeness validation report (every required output, per gate, marked
  PRESENT/MISSING); liveness verification result (every URL re-checked 200 OK + timestamp);
  `research_status` transition.
- **Enforcement split:** substrate-layer NOT NULL for G4 INSERT-time fields; `sp_check_completeness`
  validator for progressive-UPDATE fields (item_id, value, category_id, author_id, etc.); aggregate
  validator for cross-row cardinality (adopter-configured minimums for peers, source publications,
  feedback citations); CHECK/trigger for cross-tier semantic checks.
- **Halt/Reject:** `incomplete` → item returns to the failed gate (no retroactive completion); names which
  gate failed and why.
- **Branches:** completeness criteria differ by corpus and by output format (single, comparison, etc.).
- **State:** `in_progress → ready_for_approval` on pass; stays `in_progress` if incomplete.

### G13 — Item Approval & Promotion (human)
- **Path:** both. **Prereq:** G12 pass (`research_status = ready_for_approval`).
- **Inputs:** item rows at `ready_for_approval`.
- **Required outputs:** decision ∈ {APPROVED, REJECTED, HOLD}; on APPROVED — dossier promoted to the
  publish tier with `Status = Ready`, research row `→ promoted` (preserved, not deleted), bidirectional
  research↔publish link; on REJECTED — `rejected` + reason; on HOLD — `hold` + note.
- **Evidence:** decision + timestamp + reviewer identity. REJECTED reason from adopter-defined closed set.
- **Halt/Reject:** approval surface unavailable → research rows wait (publishing reads only the publish
  tier, so pending rows never leak into the pipeline).
- **State:** `ready_for_approval → approved → promoted`; or `→ rejected` / `→ hold`. Approval is
  **per-row** — no multi-select "approve all".

---

## §4 — Research-row state machine

| State | Meaning | Set by |
|---|---|---|
| `in_progress` | row created, not all gates passed | gate execution |
| `ready_for_approval` | G12 passed; Branch B pending | G12 on pass |
| `approved` | reviewer approved; promotion pending | reviewer (G13 APPROVED) |
| `promoted` | dossier copied to publish tier, linked | automatic promotion |
| `rejected` | reviewer rejected OR G7 terminal-rejection | reviewer / G7 auto-reject |
| `hold` | reviewer deferred, note recorded | reviewer (either branch HOLD) |
| `superseded` | replaced by a fresh row per G3 REPLACEABLE | automatic (G3) |

Transitions: `in_progress→ready_for_approval` (G12) · `in_progress→rejected` (G7 terminal) ·
`ready_for_approval→approved` (G13) · `approved→promoted` (auto) · `any→rejected` (reviewer) ·
`any→hold` (reviewer) · `hold→ready_for_approval` (resume) · `rejected→superseded` (G3 REPLACEABLE) ·
`promoted→` terminal in research tier.

Candidate rows use a parallel `candidate_status`: {in_progress, ready_for_approval, approved, rejected,
hold}.

Re-submission after rejection is a **new row** (the rejected row stays as audit trail), created via G3
REPLACEABLE, linked to the predecessor.

---

## §5 — Compliance markers (CC-12 contract element)

Two literal-string markers at the start of `reviewer_notes`, consumed by the publishing prompt for
voice-switching:

| Marker | Voice unlocked | Required evidence |
|---|---|---|
| `{{FIRSTPARTY_SENTINEL}}` | first-person testing voice + genuine measurements | a `firstparty_testing_notes` row populated at hands-on-test time |
| `[NEW ITEM]` | early-review transparency voice + mandatory disclosure sentence | insufficient user reviews; the disclosure substitutes for missing user-experience evidence |
| neither | analytical voice ("users report…", "research found…") | default; compliance-safe by construction |

Fabricating hands-on testing without the marker is an explicit compliance violation. The marker is
observable (literal string); presence unlocks the voice AND imposes the evidence requirement.

**§5.1 — FIRST-PARTY RENDERING (binding):** Unlocking the `{{FIRSTPARTY_SENTINEL}}` voice is NECESSARY but NOT SUFFICIENT.
The publishing composer MUST render the substance of `reviewer_notes` as a **visibly-attributed
first-person testimony section in the output body** — the notes are TESTIMONY (required OUTPUT), not
merely voice-selection CONTEXT (input). Rendering preserves substance + first-person voice such that the
source field's content is **mechanically identifiable in the rendered body** (presence, not similarity).
A hands-on-class draft that consumes the notes as prompt context but omits their content from the body
**voids the class's own definition** → publish-illegal.

---

## §6 — Publish-tier runtime contract handoff (seam to the publish-tier contract)

Gate G13 promotion must populate everything the publishing pipeline reads. This is the gate → publish-tier seam.

- **Content composer reads:** `canonical_name`, `item_id` (→ outbound link URL, never visible text),
  `value_range_display`, `specs_pipe_delimited`, `source_url`, lead `peer {name, identifier, value}`,
  `author_name`+`author_bio`, `reviewer_notes`, `category_slug`, `target_terms_csv`.
- **Metadata composer reads:** `target_terms_csv`, `region_terms`, `qa_prompts`, `category_slug`,
  `summary_text`, `focus_term`; fallbacks `canonical_name`+`source_url`+`specs_pipe_delimited`.
- **Multi-item formats:** per CC-9 every item in a group must have a comparison-eligible dossier; the
  aggregator cannot synthesize un-researched data.

---

## §7 — Halt / reject taxonomy (closed sets)

- **Drop/exclude (G1):** `candidate_dropped_insufficient_sources`, `structurally_unreachable`.
- **Halt (recoverable, gate re-runs):** `evidence_insufficient` (CC-5), `term_zero_volume` (G9),
  `value_missing` (G11), `completeness_incomplete` (G12), `category_invalid` (G10),
  `approval_surface_unavailable` (G13).
- **Reject (terminal for the row):** `item_unfindable_after_retry`, `wrong_item_after_retry`,
  `discontinued`, `unavailable_permanent`, `miscategorized` (G7); `identity_mismatch` (G4).
- **Operator-review flag (not auto-halt):** `demand_saturated` (G9), `value_outside_band` (G11),
  `insufficient_credibility` (G7 below-threshold feedback — downgrade).
- **Approval outcomes:** `APPROVED` / `REJECTED`(+closed-set reason per §3 G2/G13) / `HOLD`(+note).

---

## §8 — Open items / v0.2 reconciliation

1. **Quality-Gates summary** — post-gate operator-review-stage block-severity gates (adopter-specific
   schema-markup, stamping compliance) fold into v0.2 §9.
2. **C-DB physical mapping** — every logical field here maps to a physical column/sproc via C-DB; produced
   by the C-DB extraction work package.
3. **Comparison-format gate variations** — Format A (head-to-head, count=2) vs Format B (Top-N, count=3–5)
   differ at the metadata/schema layer; v0.2 adds a per-format completeness annex.
4. **C-CANVAS seam** — Gates G2, G13, and G8 are operator-surface gates; their interaction contract
   with the canvas belongs in C-CANVAS and cross-references §3 here.

---

*Where C-GATE and a live probe disagree, the reconciliation pass surfaces it and the contract or the build
is corrected. Logical field names here are authoritative for gate I/O; physical mapping is C-DB's.*
