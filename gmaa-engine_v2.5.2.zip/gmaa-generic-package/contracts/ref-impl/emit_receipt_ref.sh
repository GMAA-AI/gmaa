#!/usr/bin/env bash
# F4 RUNNABLE NEUTRAL REF-IMPL — emit_receipt_ref.sh
#
# PURPOSE: Emits a JSONL receipt line appended to a receipts file.
#   Demonstrates the generic receipt shape (C-GATE contract element).
#   The emitted line is a valid JSON object; verified with python json.loads.
#
# This script is the low-disclosure, no-adopter-infra proof that the
# free engine is RUNNABLE. No real ids, credentials, domains, or
# service bindings. Adopter wires to their own receipt ledger path.
#
# Usage:
#   bash emit_receipt_ref.sh <receipts_file>
#   bash emit_receipt_ref.sh /tmp/gmaa_receipts.jsonl
#
# The emitted receipt carries these generic fields (adopter may extend):
#   receipt_id    — generated token
#   gate          — gate that fired
#   item_id       — item processed
#   status        — PASS | FAIL | HALT
#   halt_code     — null or a halt taxonomy code from C-GATE §7
#   run_ts        — UTC timestamp of the run
#   actor         — the mechanism slot identifier

set -euo pipefail

RECEIPTS_FILE="${1:-}"
if [ -z "$RECEIPTS_FILE" ]; then
  echo "Usage: bash emit_receipt_ref.sh <receipts_file>" >&2
  exit 1
fi

GATE_ID="${GMAA_GATE_ID:-G7}"
ITEM_ID="${GMAA_ITEM_ID:-ITEM-REF-001}"
RUN_TS=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo "1970-01-01T00:00:00Z")
RECEIPT_ID="R-${RUN_TS//:/-}-REF"
STATUS="PASS"
HALT_CODE="null"

RECEIPT_LINE=$(printf \
  '{"receipt_id":"%s","gate":"%s","item_id":"%s","status":"%s","halt_code":%s,"run_ts":"%s","actor":"{{EXECUTE_MECHANISM}}"}' \
  "$RECEIPT_ID" "$GATE_ID" "$ITEM_ID" "$STATUS" "$HALT_CODE" "$RUN_TS")

echo "$RECEIPT_LINE" >> "$RECEIPTS_FILE"
echo "[emit_receipt_ref.sh] appended receipt to $RECEIPTS_FILE"
echo "  receipt_id : $RECEIPT_ID"
echo "  gate       : $GATE_ID"
echo "  status     : $STATUS"

python3 -c "
import json, sys
path = sys.argv[1]
lines = open(path).readlines()
for i, line in enumerate(lines, 1):
    line = line.strip()
    if not line:
        continue
    try:
        json.loads(line)
    except json.JSONDecodeError as e:
        print(f'JSONL PARSE ERROR on line {i}: {e}', file=sys.stderr)
        sys.exit(1)
print(f'[emit_receipt_ref.sh] JSONL verified ({len(lines)} line(s) in {path})')
" "$RECEIPTS_FILE"
