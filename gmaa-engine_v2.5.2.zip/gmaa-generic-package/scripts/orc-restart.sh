#!/usr/bin/env bash
# scripts/orc-restart.sh — checkpoint-gated restart of an orc lane.
# CHECKPOINT FIRST (the orc writes state forward) → kill → orc-up. Operator alias: orc-restart.
#
# GENERICIZATION NOTE: the hardcoded instance-lane validation list is dropped (folder-equals-lane;
# any lane is accepted — orc-up's fail-closed worktree/_boot guard validates it).
set -u

lane="${1:?usage: orc-restart.sh <lane> [--force]}"
force="${2:-}"

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "orc-restart: not in a git worktree" >&2; exit 2; }

# Gate: a restart kills the session; unwritten state is lost. Require an explicit --force acknowledging
# the operator ran /checkpoint (or the orc wrote its handoff) in the lane first.
if [[ "$force" != "--force" ]]; then
  echo "orc-restart: CHECKPOINT FIRST."
  echo "  In the '$lane' pane run /checkpoint (or confirm the orc wrote its state forward) BEFORE restarting —"
  echo "  a restart kills the session and any unwritten context is lost."
  echo "  Then re-run:  scripts/orc-restart.sh $lane --force"
  exit 1
fi

# Foundation cannot relaunch the session it runs inside.
project="$("$(dirname "$0")/resolve-project.sh")"; rp=$?
if [[ $rp -eq 0 && -n "$project" ]]; then session="${project}-${lane}"
elif [[ $rp -eq 10 ]]; then session="${lane}"   # legacy form (canon §7.3); warning already printed
else echo "orc-restart: program-token resolution failed (exit $rp)" >&2; exit 2; fi
if [[ "$lane" == "foundation" && -n "${TMUX:-}" ]] && tmux display-message -p '#S' 2>/dev/null | grep -qx "$session"; then
  echo "orc-restart: refusing to kill the foundation session from inside it (an orc cannot relaunch its own host)." >&2
  exit 2
fi

if tmux has-session -t "$session" 2>/dev/null; then
  tmux kill-session -t "$session" && echo "orc-restart: killed '$session'."
else
  echo "orc-restart: no live '$lane' session — proceeding to bring it up."
fi

exec "$REPO_ROOT/scripts/orc-up.sh" "$lane"
