#!/usr/bin/env bash
# Seeded-fault test for the folder-equals-lane resolver (spine-owned).
# PROVES the security property: a hand-created folder (no valid stamp, or a stamp
# that does not match the folder) MUST HALT with exit 3 and MUST NOT resolve as a
# lane. Includes a positive control so a resolver that halts on EVERYTHING also fails.
#
# Cases:
#   A (positive control) — folder 'integrator' + matching stamp lane:integrator -> exit 0, lane=integrator
#   B (stampless fault)  — folder 'rogue', no _boot/BOOTSTRAP.md              -> exit 3, LANE-UNRESOLVED, no lane= line
#   C (mis-stamp fault)  — folder 'rogue2', stamp lane:integrator (!=folder)  -> exit 3, LANE-MISMATCH, does NOT resolve
set -u

RESOLVER="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/resolve-lane.sh"
[[ -f "$RESOLVER" ]] || { echo "TEST-ERROR: resolver not found at $RESOLVER" >&2; exit 2; }

BASE="$(mktemp -d)"; trap 'rm -rf "$BASE"' EXIT
fails=0
pass(){ echo "PASS: $1"; }
fail(){ echo "FAIL: $1"; fails=$((fails+1)); }

mkstamp(){ # $1=dir  $2=lane-value ("" = no stamp)
  mkdir -p "$1"; ( cd "$1" && git init -q && git config user.email t@t && git config user.name t )
  if [[ -n "$2" ]]; then
    mkdir -p "$1/_boot"
    printf -- '---\nlane: %s\nrole: integrator\nspine_write: ALLOW\nbootstrap_version: test\n---\n' "$2" > "$1/_boot/BOOTSTRAP.md"
    ( cd "$1" && git add -A && git commit -q -m stamp )
  fi
}
run(){ ( cd "$1" && bash "$RESOLVER" ) 2>&1; }  # merges stderr; caller checks $?

# --- Case A: positive control ---------------------------------------------------
DA="$BASE/integrator"; mkstamp "$DA" integrator
outA="$(run "$DA")"; rcA=$?
if [[ $rcA -eq 0 && "$outA" == *"lane=integrator"* ]]; then pass "A control: folder==stamp resolves (exit 0, lane=integrator)"
else fail "A control: expected exit0 + lane=integrator, got rc=$rcA out=[$outA]"; fi

# --- Case B: stampless fault ----------------------------------------------------
DB="$BASE/rogue"; mkstamp "$DB" ""   # no stamp
outB="$(run "$DB")"; rcB=$?
if [[ $rcB -eq 3 && "$outB" == *"LANE-UNRESOLVED"* && "$outB" != *"lane=rogue"* ]]; then pass "B stampless: HALT exit3 LANE-UNRESOLVED, did not mint 'rogue'"
else fail "B stampless: expected exit3 + LANE-UNRESOLVED + no mint, got rc=$rcB out=[$outB]"; fi

# --- Case C: mis-stamp fault ----------------------------------------------------
DC="$BASE/rogue2"; mkstamp "$DC" integrator   # stamp says integrator, folder is rogue2
outC="$(run "$DC")"; rcC=$?
if [[ $rcC -eq 3 && "$outC" == *"LANE-MISMATCH"* && "$outC" != *"lane=integrator"$'\n'* && "$outC" != "lane=integrator"* ]]; then pass "C mis-stamp: HALT exit3 LANE-MISMATCH, did not resolve as integrator"
else fail "C mis-stamp: expected exit3 + LANE-MISMATCH + no resolve, got rc=$rcC out=[$outC]"; fi

echo "----"
if [[ $fails -eq 0 ]]; then echo "ALL PASS (3/3): folder-equals-lane security property holds"; exit 0
else echo "$fails CASE(S) FAILED"; exit 1; fi
