#!/usr/bin/env bash
# scripts/install_pre_commit_hook.sh
#
# One-time install of the D3 spine_write HARD gate.
# Git hooks aren't versioned; this script installs agents/pre-commit-hook.sh
# into .git/hooks/pre-commit and chmods it executable.
#
# Per COORDINATION.md §13(1) single-writer. Precedent: scripts/install_post_commit_hook.sh.
#
# GENERICIZATION NOTE: unchanged mechanism; dated architect-relay citation stripped.
#
# NOTE on worktrees: by default `.git/hooks/` is SHARED across a repo's worktrees
# (they resolve hooks via the common git-dir), so installing once covers main +
# all module worktrees. The hook resolves the COMMITTING worktree's lane at
# runtime, so one installed hook correctly gates every lane. If `core.hooksPath`
# is ever set per-worktree this must be re-run per worktree — verify with
# `git rev-parse --git-path hooks` in each worktree.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$REPO_ROOT/agents/pre-commit-hook.sh"
DST="$REPO_ROOT/.git/hooks/pre-commit"

if [[ ! -f "$SRC" ]]; then
    echo "ERROR: hook source missing at $SRC" >&2
    exit 1
fi

if [[ ! -x "$REPO_ROOT/scripts/resolve-lane.sh" ]]; then
    echo "ERROR: prerequisite scripts/resolve-lane.sh missing/not-executable; D3 cannot resolve lane." >&2
    exit 1
fi

if [[ ! -d "$REPO_ROOT/.git/hooks" ]]; then
    echo "ERROR: $REPO_ROOT/.git/hooks not a directory; is this a git repo?" >&2
    exit 1
fi

# Back up existing hook if any (operator review)
if [[ -e "$DST" ]]; then
    BACKUP="${DST}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
    cp "$DST" "$BACKUP"
    echo "Backed up existing hook to: $BACKUP"
fi

cp "$SRC" "$DST"
chmod +x "$DST"

if [[ -x "$DST" ]]; then
    echo "OK: pre-commit hook installed at $DST"
    echo ""
    echo "Verify:"
    echo "  1. ls -la $DST            (hook present + executable)"
    echo "  2. diff $DST $SRC         (no drift between installed + canonical)"
    echo "  3. (main)   touch a spine file, stage, commit  -> ALLOWED  (foundation = sole writer)"
    echo "  4. (module) touch a spine file, stage, commit  -> REJECTED (spine_write: DENY)"
    echo "  5. (module) touch a non-spine file, stage, commit -> ALLOWED"
    echo "  6. (no _boot / mismatch) -> REJECTED fail-closed (never defaults foundation)"
else
    echo "ERROR: install failed; $DST not executable after chmod" >&2
    exit 1
fi
