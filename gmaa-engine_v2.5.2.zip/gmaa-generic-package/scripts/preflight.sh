#!/bin/bash
# preflight.sh — substrate-floor verification (v2.5.1)
# The engine states its prerequisites in README ("Prerequisites — the substrate floor"); this
# script is the check that makes the statement testable: Claude Code CLI, git (with GitHub auth),
# and tmux. It provisions NOTHING — it reports and halts loud, per the floor ruling: v1 targets
# adopters who clear this floor; the engine does not install it for them.
# Exit 0 = floor clear. Exit 1 = one or more items missing (each named on its own line).
# bash-3.2 compatible (macOS /bin/bash): no arrays, no mapfile.

set -u

FAIL=0

check() {
  # $1 = label · $2 = command to probe
  if OUT=$(eval "$2" 2>&1); then
    echo "PASS: $1 ($(echo "$OUT" | head -1))"
  else
    echo "FAIL: $1 — '$2' did not succeed. Install/configure it before Phase 0."
    FAIL=1
  fi
}

check "Claude Code CLI" "claude --version"
check "git"             "git --version"
check "tmux"            "tmux -V"

# GitHub auth: gh is the common path; a configured git credential helper also satisfies the floor.
if command -v gh >/dev/null 2>&1; then
  check "GitHub auth (gh)" "gh auth status"
else
  if git config --get credential.helper >/dev/null 2>&1; then
    echo "PASS: GitHub auth (git credential helper configured; gh CLI not installed — optional)"
  else
    echo "FAIL: GitHub auth — neither 'gh' CLI nor a git credential helper found. Configure GitHub access before Phase 0."
    FAIL=1
  fi
fi

if [ "$FAIL" -eq 0 ]; then
  echo "FLOOR CLEAR: all substrate prerequisites respond."
  exit 0
else
  echo "FLOOR NOT CLEAR: fix the FAIL lines above, then re-run. (README: Prerequisites — the substrate floor.)"
  exit 1
fi
