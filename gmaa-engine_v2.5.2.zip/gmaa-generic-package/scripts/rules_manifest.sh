#!/usr/bin/env bash
# scripts/rules_manifest.sh — compute the SCOPED rules-manifest hash (R2).
#
# GENERICIZATION NOTE: unchanged mechanism (dated architect citation stripped); the hashed
# source set is engine-generic (this file · the D3 guard · the resolver · COORDINATION §13).
#
# A lane is RULE-CURRENT iff its `_boot` `rules_manifest` field == this hash. The currency
# gate computes this live and compares; a stale lane HALT-AND-RE-STAMPs (rule fields to HEAD,
# identity preserved). Replaces the honor-system hand-bumped `bootstrap_version` string —
# self-detecting + tamper-evident; the forgotten bump cannot silently pass.
#
# SCOPE FENCE (load-bearing): hash LANE-RELEVANT RULE surfaces ONLY. Do NOT fold in ledger/,
# the DB, or unrelated spine churn — that would fire HALT-AND-RE-STAMP on every commit and
# re-create workaround-downgrade pressure. Deterministic: fixed source order, sha256.
#
# Sources (ratified set):
#   (i)   this file itself — so adding/removing a rule source is itself a rule change
#   (ii)  the D3 guard (reject-set + adopt-from-trunk logic) — the guard's ACTUAL list, not a copy
#   (iii) the lane resolver
#   (iv)  COORDINATION.md §13 — spine/substrate-join + single-writer + per-track-boot
#         (identity-vs-rule split) + spine_write/bootstrap semantics
set -u
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
COORD="$ROOT/_knowledge/COORDINATION.md"

{
  echo "=== (i) manifest-def ==="
  cat "$ROOT/scripts/rules_manifest.sh"
  echo "=== (ii) D3 guard ==="
  cat "$ROOT/agents/pre-commit-hook.sh"
  echo "=== (iii) resolver ==="
  cat "$ROOT/scripts/resolve-lane.sh"
  echo "=== (iv) COORDINATION §13 ==="
  awk '/^## §13/{f=1} f{print} f&&/^\*Amendments/{exit}' "$COORD"
} | shasum -a256 | cut -d' ' -f1
