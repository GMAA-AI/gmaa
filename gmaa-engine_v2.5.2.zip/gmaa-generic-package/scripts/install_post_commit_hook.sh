#!/usr/bin/env bash
# scripts/install_post_commit_hook.sh
#
# One-time install of the code-Auditor post-commit hook.
# Git hooks aren't versioned; this script installs agents/post-commit-hook.sh
# into .git/hooks/post-commit and chmods it executable.
#
# Per agents/auditor-contract.md §Wiring §Operator-install-procedure.
#
# GENERICIZATION NOTE: unchanged mechanism; dated architect-relay citation stripped.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$REPO_ROOT/agents/post-commit-hook.sh"
DST="$REPO_ROOT/.git/hooks/post-commit"

if [[ ! -f "$SRC" ]]; then
    echo "ERROR: hook source missing at $SRC" >&2
    exit 1
fi

if [[ ! -d "$REPO_ROOT/.git/hooks" ]]; then
    echo "ERROR: $REPO_ROOT/.git/hooks not a directory; is this a git repo?" >&2
    exit 1
fi

# Back up existing hook if any (operator review)
if [[ -e "$DST" ]]; then
    BACKUP="${DST}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
    cp "$DST" "$BACKUP"
    echo "Backed up existing hook to: $BACKUP"
fi

cp "$SRC" "$DST"
chmod +x "$DST"

# Verify installation
if [[ -x "$DST" ]]; then
    echo "OK: post-commit hook installed at $DST"
    echo ""
    echo "Verify per agents/auditor-contract.md §Wiring §Operator-verification:"
    echo "  1. ls -la $DST            (hook present + executable)"
    echo "  2. diff $DST $SRC         (no drift between installed + canonical)"
    echo "  3. cat agents/audit-system-prompt.md   (audit-only role bounds)"
    echo "  4. (post-first-commit) tail -50 ledger/audit-runs.log"
    echo "  5. (post-first-commit) tail -100 ledger/audit-findings.md"
    echo "  6. (post-first-commit) grep '\"actor\": \"code-Auditor\"' ledger/receipts.jsonl | wc -l"
    echo "  7. (during a commit) ps -ef | grep 'claude -p'   (backgrounded Auditor process visible)"
    echo ""
    echo "Prerequisites:"
    echo "  - claude CLI in PATH (https://docs.anthropic.com/en/docs/agents-and-tools/claude-code)"
    echo "  - agents/audit-system-prompt.md present (committed file; this script verified it via SRC dep)"
    echo "  - operator-confirmed Auditor independence"

    # Dry-run readiness check: confirm claude CLI is available
    if command -v claude >/dev/null 2>&1; then
        echo ""
        echo "Auditor prerequisites: claude CLI FOUND at $(command -v claude)"
    else
        echo ""
        echo "Auditor prerequisites: claude CLI NOT FOUND in PATH"
        echo "  -> install Claude Code per docs; until then post-commit hook will SKIP audit with WARN."
    fi
else
    echo "ERROR: install failed; $DST not executable after chmod" >&2
    exit 1
fi
