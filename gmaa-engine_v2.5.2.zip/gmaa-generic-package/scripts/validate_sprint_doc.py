#!/usr/bin/env python3
"""
validate_sprint_doc.py -- Validate the most-recent sprint doc against minimum required sections.

GENERICIZATION NOTE: mechanism unchanged; the orchestrator log path is renamed to
dispatch-executor, the sprint-doc glob is genericized (drops a project-specific prefix),
and a project-specific migration cross-ref pattern is dropped.

Usage:
    python3 scripts/validate_sprint_doc.py --latest

Output:
    PASS/FAIL summary to stdout (appended to .claude/agent-memory/dispatch-executor/validation.log by stop-hook)

Exit: always 0 (advisory; fire-and-forget from stop-hook)
"""

import argparse
import datetime
import glob
import os
import re
import sys
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)


REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS_DIR = os.path.join(REPO_ROOT, "docs")

# Required section patterns (case-insensitive substring match against headings)
# Each entry: (label, list of alternative patterns — any match satisfies)
REQUIRED_SECTIONS = [
    ("§1 execution / PASS 0", [r"##\s+§1", r"##.*pass\s+0", r"##.*what was executed", r"##.*executed"]),
    ("§2 verification gates / gate walk", [r"##\s+§2", r"##.*gate\s+(walk|verification)", r"##.*verification"]),
    ("§3 files / sha256", [r"##\s+§3", r"##.*files", r"sha256", r"##.*authored"]),
    ("forward-queue items", [r"forward.queue", r"##.*§4", r"forward queue"]),
    ("commit SHA reference", [r"\b[0-9a-f]{7,40}\b"]),
]

# Cross-reference patterns (any of these appearing in the doc counts as a cross-ref)
CROSSREF_PATTERNS = [
    r"dispatch/",
    r"_orchestration/",
    r"ISSUE-",
    r"commit\s+`?[0-9a-f]{7}",
]


def find_latest_sprint_doc():
    """
    Find the most recently modified docs/*sprint*.md file.
    Returns the absolute path or None.
    """
    pattern = os.path.join(DOCS_DIR, "*sprint*.md")
    candidates = glob.glob(pattern)
    if not candidates:
        return None
    return max(candidates, key=os.path.getmtime)


def check_section(content, patterns):
    """Return True if any pattern matches (case-insensitive) anywhere in content."""
    for pat in patterns:
        if re.search(pat, content, re.IGNORECASE | re.MULTILINE):
            return True
    return False


def validate_sprint_doc(path):
    """
    Validate a sprint doc at `path`.
    Returns (pass_count, fail_count, findings) where findings is a list of (label, result, note) tuples.
    """
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
    except Exception as e:
        return 0, len(REQUIRED_SECTIONS) + 1, [("file read", "FAIL", str(e))]

    findings = []
    pass_count = 0
    fail_count = 0

    # Check required sections
    for label, patterns in REQUIRED_SECTIONS:
        if check_section(content, patterns):
            findings.append((label, "PASS", ""))
            pass_count += 1
        else:
            findings.append((label, "FAIL", f"none of: {patterns[:2]}..."))
            fail_count += 1

    # Check cross-references (any one is sufficient)
    has_crossref = any(re.search(pat, content, re.IGNORECASE) for pat in CROSSREF_PATTERNS)
    if has_crossref:
        findings.append(("cross-reference present", "PASS", ""))
        pass_count += 1
    else:
        findings.append(("cross-reference present", "FAIL", "no dispatch/, ISSUE-, _orchestration/, or commit SHA cross-refs found"))
        fail_count += 1

    return pass_count, fail_count, findings


def main():
    parser = argparse.ArgumentParser(description="Validate most-recent sprint doc")
    parser.add_argument("--latest", action="store_true", help="Validate most-recently-modified sprint doc")
    args = parser.parse_args()

    ts = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

    if not args.latest:
        print(f"[{ts}] validate_sprint_doc: no --latest flag; nothing to do.")
        return 0

    doc_path = find_latest_sprint_doc()
    if not doc_path:
        lines = [
            f"\n=== validate_sprint_doc [{ts}] ===\n",
            f"RESULT: SKIP — no docs/*sprint*.md files found\n",
            f"=== end validate_sprint_doc ===\n",
        ]
        sys.stdout.write("".join(lines))
        sys.stdout.flush()
        return 0

    doc_name = os.path.relpath(doc_path, REPO_ROOT)
    pass_count, fail_count, findings = validate_sprint_doc(doc_path)
    total = pass_count + fail_count
    overall = "PASS" if fail_count == 0 else "FAIL"

    lines = [
        f"\n=== validate_sprint_doc [{ts}] ===\n",
        f"Doc: {doc_name}\n",
        f"Result: {overall} ({pass_count}/{total} checks passed)\n",
        "\n",
    ]

    for label, result, note in findings:
        note_str = f"  -- {note}" if note else ""
        lines.append(f"  [{result}] {label}{note_str}\n")

    if fail_count > 0:
        lines.append(f"\n  Missing sections: {fail_count} check(s) failed (advisory only; does not block iter)\n")
    else:
        lines.append(f"\n  All required sections present.\n")

    lines.append(f"=== end validate_sprint_doc ===\n")

    summary = "".join(lines)
    sys.stdout.write(summary)
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
