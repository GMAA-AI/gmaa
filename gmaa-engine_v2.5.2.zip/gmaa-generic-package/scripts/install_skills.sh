#!/usr/bin/env bash
# scripts/install_skills.sh — install the in-repo skill HOME to ~/.claude/skills/.
#
# GENERICIZATION NOTE: the project-specific skill list is genericized to the single generic
# `code-build` skill; adopters extend SKILLS with their own. Dated ruling citation stripped.
#
# The repo `skill/<name>/` tree is the D3-protected version-control SOURCE. The live copy at
# `~/.claude/skills/<name>/` is BUILD OUTPUT — hand-editing it is PROHIBITED (same class as
# hand-editing a live deployed artifact); the `skill-install-integrity` standing probe catches
# any drift on every commit.
#
# Flow: edit repo skill/ -> run this -> live matches -> commit -> integrity probe PASS.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$REPO_ROOT/skill"
DST="$HOME/.claude/skills"
BAK="$HOME/.claude/.skills-bak"          # OUTSIDE the load path (loader ignores it)

# Skills to install (space-separated); adopters append their own skill folder names.
SKILLS="${SKILLS:-code-build}"

[[ -d "$SRC" ]] || { echo "ERROR: repo skill home missing at $SRC" >&2; exit 1; }
mkdir -p "$DST" "$BAK"

for s in $SKILLS; do
    [[ -d "$SRC/$s" ]] || { echo "ERROR: source $SRC/$s missing" >&2; exit 1; }
    if [[ -e "$DST/$s" ]]; then
        TS="$(date -u +%Y%m%dT%H%M%SZ)"
        mv "$DST/$s" "$BAK/$s.$TS"        # back up OUTSIDE skills/ so the loader can't see it
        echo "backed up live $s -> $BAK/$s.$TS"
    fi
    cp -R "$SRC/$s" "$DST/$s"
    find "$DST/$s" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
    echo "installed $s -> $DST/$s"
done

echo ""
echo "OK. Verify integrity: bash probes/c-skill/probe_skill_install_integrity_v1.sh"
