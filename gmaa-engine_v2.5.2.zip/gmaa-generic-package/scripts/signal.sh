#!/usr/bin/env bash
# scripts/signal.sh — durable operator↔integrator (+ any-lane) SIGNAL.
#
# GENERICIZATION NOTE: mechanism unchanged; the instance target list (site lanes) is genericized to the
# base census — `foundation | operator | executor | {{MODULE_LANE}}… | chat` (any relay-inbox/<target>/ dir).
#
# WHY: today's dropped GO. A directive typed into a pane that is mid-turn can silently drop. This makes
# the signal a COMMITTED inbox file (durable TRANSPORT — cannot drop) + an optional tmux doorbell (NOTIFY
# only). Delays-never-loses: a missed bell still lands in the git inbox, read on the reader's next
# INBOX-CHECK. This is the doorbell re-cut around the OPERATOR channel — the missing spoke↔hub half.
#
# Usage:
#   scripts/signal.sh <target> <payload...>     # write+commit+push a signal to relay-inbox/<target>/; ring if target is a live tmux lane
#   scripts/signal.sh ack <target> <ref...>     # write an ACK back to <target> (closes the required round-trip)
#
# Targets: foundation | operator | executor | {{MODULE_LANE}}… | chat  (any relay-inbox/<target>/ lane).
# Sender:  inferred from the worktree lane (resolve-lane.sh); override with SIGNAL_FROM=operator
#          (the operator alias sets this — the operator writes from the foundation seat but is not foundation).
# Run from the FOUNDATION worktree (main): foundation is sole spine committer; the inbox lives on the spine.
# Ack: a signal is not "delivered" until the reader acks — a missing ack surfaces loud in `status`/digest.
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "signal.sh: not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2

usage() { echo "usage: signal.sh <target> <payload...>   |   signal.sh ack <target> <ref...>" >&2; exit 2; }

mode="signal"
if [[ "${1:-}" == "ack" ]]; then mode="ack"; shift; fi
target="${1:-}"; shift || true
payload="$*"
[[ -n "$target" && -n "$payload" ]] || usage

INBOX="_orchestration/relay-inbox/${target}"
[[ -d "$INBOX" ]] || { echo "signal.sh: no inbox dir '$INBOX' (targets: foundation|operator|executor|{{MODULE_LANE}}|chat)" >&2; exit 2; }

# Sender: SIGNAL_FROM override, else the resolved worktree lane, else 'unknown'.
eval "$(scripts/resolve-lane.sh 2>/dev/null)" 2>/dev/null || true
from="${SIGNAL_FROM:-${lane:-unknown}}"

ts="$(date -u +%Y-%m-%d-%H%M%S)"
kind="signal"; [[ "$mode" == "ack" ]] && kind="ack"
file="${INBOX}/${ts}-${kind}.md"

{
  echo "FROM:    ${from}"
  echo "TO:      ${target}"
  echo "KIND:    ${kind}"
  echo "DATE:    $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "PAYLOAD: ${payload}"
} > "$file"

git add "$file" || { echo "signal.sh: git add failed" >&2; exit 2; }
git commit -q -m "[signal] ${from}→${target}: ${payload:0:60}" || { echo "signal.sh: commit failed (spine-write gate? run from the foundation worktree)" >&2; exit 2; }
git push -q 2>/dev/null && echo "[signal] pushed" || echo "[signal] push deferred (offline?) — committed locally, will ride the next push"

echo "[signal] delivered → ${file}"

# NOTIFY (best-effort; delays-never-loses). Human targets (operator/chat) have no Claude pane → no bell;
# they read the inbox / see it in \`status\`.
if [[ "$target" != "operator" && "$target" != "chat" ]]; then
  if scripts/doorbell.sh ring "$target" 2>/dev/null; then
    echo "[signal] rang ${target} (bell) — R4 ack pending"
  else
    echo "[signal] ${target} not a single live tmux lane — inbox delivery STANDS (bell skipped; delays-never-loses)"
  fi
fi
