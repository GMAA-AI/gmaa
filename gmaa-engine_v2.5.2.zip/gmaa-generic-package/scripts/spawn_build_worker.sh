#!/usr/bin/env bash
# scripts/spawn_build_worker.sh — spawn a backgrounded build-worker via claude -p
#
# GENERICIZATION NOTE: this is the build-worker spawner (F3); the project-specific sibling-repo
# prompt path and the failed-WP citation are stripped to the mechanism.
#
# Pattern source: agents/post-commit-hook.sh (the Auditor wiring). Same mechanism; different
# system prompt + different lane. The Agent-tool subagent registry doesn't pick up newly-authored
# agent definitions mid-session — this script bypasses that by invoking `claude -p` directly with
# build-worker.md as --append-system-prompt.
#
# The build-worker is the PARALLEL, one-WP-per-spawn worker (own branch; emits artifact+probe+receipt;
# NO ratification pauses) — distinct from dispatch-executor (sequential, multi-pass, ratification
# checkpoints). Do NOT use dispatch-executor for parallel build work: its sequential system prompt
# would keep overriding the build-worker instructions.
#
# Usage:
#   scripts/spawn_build_worker.sh <worker-id> <brief-file>
#
# Where:
#   <worker-id>  — short tag for the spawned worker (e.g., "p1-a-queue-contract")
#   <brief-file> — path to .md file containing the self-contained brief
#
# Output:
#   stdout/stderr → ledger/worker-runs.log (appended)
#   worker progress observable via ps -ef + tail of log

set -uo pipefail

REPO_ROOT="$(git rev-parse --show-toplevel)"
WORKER_ID="${1:?usage: $0 <worker-id> <brief-file>}"
BRIEF_FILE="${2:?usage: $0 <worker-id> <brief-file>}"

if [[ ! -f "$REPO_ROOT/$BRIEF_FILE" ]]; then
    echo "spawn_build_worker: brief file not found: $REPO_ROOT/$BRIEF_FILE" >&2
    exit 1
fi

# build-worker system prompt location candidates (agent-def first; fall back to a local prompt copy)
BUILD_WORKER_PROMPT=""
for candidate in \
    "$REPO_ROOT/.claude/agents/build-worker.md" \
    "$REPO_ROOT/agents/build-worker-prompt.md"
do
    if [[ -f "$candidate" ]]; then
        BUILD_WORKER_PROMPT="$candidate"
        break
    fi
done

if [[ -z "$BUILD_WORKER_PROMPT" ]]; then
    echo "spawn_build_worker: build-worker prompt not found in any candidate location" >&2
    exit 1
fi

if ! command -v claude >/dev/null 2>&1; then
    echo "spawn_build_worker: claude CLI not in PATH" >&2
    exit 1
fi

mkdir -p "$REPO_ROOT/ledger"

# === ISOLATED WORKTREE per worker ===
# Each worker gets its own git worktree under /tmp/build-worktrees/<id> so parallel workers
# don't race on the shared git index / receipts.jsonl. The branch is created in the main repo
# + checked out in the per-worker worktree. (Shared-worktree contention from parallel fan-out —
# multiple sibling sessions concurrently mutating the shared git index and ledger/receipts.jsonl —
# is the race class per-worker worktrees eliminate.)

WORKTREE_ROOT="/tmp/build-worktrees"
mkdir -p "$WORKTREE_ROOT"
WORKER_BRANCH="wp/${WORKER_ID}"
WORKER_WORKTREE="$WORKTREE_ROOT/${WORKER_ID}"

# Clean any existing worktree at this path (forced; safe because /tmp)
if [[ -d "$WORKER_WORKTREE" ]]; then
    cd "$REPO_ROOT"
    git worktree remove "$WORKER_WORKTREE" --force 2>/dev/null || rm -rf "$WORKER_WORKTREE"
fi

cd "$REPO_ROOT"

# Delete any stale branch from prior failed spawn
git branch -D "$WORKER_BRANCH" 2>/dev/null || true

# Create the worktree + branch off main (worker operates in isolation)
git worktree add -b "$WORKER_BRANCH" "$WORKER_WORKTREE" main 2>&1 | sed 's/^/[worktree-setup] /'

BRIEF_CONTENT="$(cat "$REPO_ROOT/$BRIEF_FILE")"

# Spawn backgrounded + disowned; CWD = isolated worktree.
(
    cd "$WORKER_WORKTREE"
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] [worker-${WORKER_ID}] SPAWNED — brief=${BRIEF_FILE} worktree=${WORKER_WORKTREE} branch=${WORKER_BRANCH}" >> "$REPO_ROOT/ledger/worker-runs.log"
    claude -p "$BRIEF_CONTENT

# WORKTREE NOTE
You are operating in an ISOLATED git worktree at $WORKER_WORKTREE on branch $WORKER_BRANCH.
The branch was pre-created off main. Do all your work in this worktree.
Run \`git push -u origin $WORKER_BRANCH\` OR (since no remote) simply commit on the branch in this worktree — orc will see it from the main repo.
Do NOT switch branches; do NOT cd back to $REPO_ROOT; do NOT touch the main worktree.
" \
        --append-system-prompt "$(cat "$BUILD_WORKER_PROMPT")" \
        --permission-mode bypassPermissions \
        >> "$REPO_ROOT/ledger/worker-runs.log" 2>&1
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] [worker-${WORKER_ID}] COMPLETED" >> "$REPO_ROOT/ledger/worker-runs.log"
) &
disown 2>/dev/null || true

echo "[spawn_build_worker] Worker ${WORKER_ID} backgrounded; worktree=${WORKER_WORKTREE}; branch=${WORKER_BRANCH}; output → ledger/worker-runs.log"
exit 0
