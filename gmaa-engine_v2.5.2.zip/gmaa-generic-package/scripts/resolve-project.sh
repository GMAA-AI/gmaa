#!/bin/bash
# scripts/resolve-project.sh — program-token resolver for the tmux SESSION NAMESPACE.
# CONFORMS TO CANON §7.3 (v1.5, U-17): session identity is program-qualified `{program}-{lane}`.
# The program token is STAMPED AT PROVISIONING (a `program:` field in the _boot/BOOTSTRAP.md
# frontmatter, per the §7.2 stamp set) and NEVER asserted or guessed at launch. The token comes
# from the device-wide registry the cross-program channel uses (one registry, two consumers);
# stamping it here is the provisioning act that fixes it.
#
# Behavior (canon-exact):
#   stamped   -> print the token; the launcher composes `<program>-<lane>`.
#   unstamped -> LEGACY single-program form: print NOTHING (exit 10) with a LOUD WARNING on
#                stderr; callers fall back to the bare lane name. On any device hosting two or
#                more programs the stamp is MANDATORY — an unqualified name there is ambiguous
#                by construction (§7.3) and the doorbell's exactly-one match will halt on it.
# NO directory-basename derivation: a token derived from an unstamped environment at launch is
# the assertion class §7.2 prohibits (identity fixed at creation, derived from the stamp at
# boot, never asserted) — and mis-derivation is a live failure mode, not a hypothetical.
set -u

WT_TOP="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "resolve-project: not in a git worktree" >&2; exit 3; }
BOOT="$WT_TOP/_boot/BOOTSTRAP.md"
[ -f "$BOOT" ] || { echo "resolve-project: missing $BOOT (charter-precedes-boot)" >&2; exit 3; }

# frontmatter-only read (between the first two '---'), same discipline as resolve-lane.sh
STAMP="$(awk '
  /^---[[:space:]]*$/ { d++; next }
  d==1 && index($0,"program:")==1 { s=$0; sub("^program:[[:space:]]*","",s); print s; exit }
' "$BOOT")"

if [ -n "$STAMP" ]; then
  echo "$STAMP"
  exit 0
fi

echo "resolve-project: WARNING — no \`program:\` stamp in _boot/BOOTSTRAP.md; booting LEGACY" >&2
echo "  single-program session form (bare lane name). On a device hosting two or more" >&2
echo "  programs this is AMBIGUOUS BY CONSTRUCTION (canon §7.3) — stamp \`program: <token>\`" >&2
echo "  at provisioning before running a second program on this machine." >&2
exit 10
