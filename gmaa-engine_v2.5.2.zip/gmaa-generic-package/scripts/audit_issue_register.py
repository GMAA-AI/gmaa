#!/usr/bin/env python3
"""
scripts/audit_issue_register.py — foundation-lane spine discipline tool.

GENERICIZATION NOTE: mechanism unchanged; dated citation stripped, seat-name genericized to
`architect`, and the project-specific milestone tokens genericized to release-generic.

TWO halves, in priority order:

  HALF 1 — PUSH-DRIFT FLAG (the safety net for the §13(5) best-effort push-at-close).
    The post-commit hook push is best-effort: a network/auth blip at close can seal a
    commit that did NOT reach origin. This is the backstop. It compares each local
    branch HEAD against its origin remote-tracking ref (origin/<branch>) and FLAGS when
    a branch is ahead of origin by more than --threshold (default 0 — a healthy
    push-at-close leaves 0). Uses the LOCAL remote-tracking ref (no network required):
    a successful push-at-close advances origin/<branch> locally, so a stale ref = a
    missed push = drift. Run --fetch to refresh refs from the remote first.
    DRIFT detected -> exit 2 (hard alert; this is the gate).

  HALF 2 — ISSUE-REGISTER BURN-DOWN.
    Parses issues_register.md into the (a)/(b)/(c)/(d) split and flags the real drift
    set: OPEN issues with NO named trigger AND NO owner. The register is NOT
    machine-uniform, so categorization is HEURISTIC and conservative — the tool
    surfaces CANDIDATES for human/architect confirmation, it does not adjudicate.
    Unowned-AND-no-trigger OPEN issues present -> exit 1 (warn; informational).

Exit codes: 2 = push drift (hard), 1 = unowned-no-trigger OPEN issues (warn), 0 = clean.
Usage: python3 scripts/audit_issue_register.py [--threshold N] [--register PATH]
                                               [--fetch] [--no-issues] [--json]
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path


# --------------------------------------------------------------------------
# HALF 1 — push-drift flag
# --------------------------------------------------------------------------

def _git(*args: str) -> str:
    return subprocess.run(
        ["git", *args], capture_output=True, text=True
    ).stdout.strip()


def _local_branches() -> list[str]:
    out = _git("for-each-ref", "--format=%(refname:short)", "refs/heads")
    return [b for b in out.splitlines() if b]


def _active_branches() -> list[str]:
    """The §13(5) push-cadence set: the spine trunk + the live module lanes.
    Stale wp/* work-package branches and salvage/* backups are NOT on the cadence
    → excluded from the drift net by default; use --all-branches to include everything."""
    return [b for b in _local_branches()
            if b == "main" or b.startswith("module/")]


def check_push_drift(threshold: int, do_fetch: bool, all_branches: bool) -> tuple[list[dict], bool]:
    """Return (rows, drift_found). rows: {branch, ahead, has_upstream}."""
    if do_fetch:
        subprocess.run(["git", "fetch", "--quiet", "origin"], capture_output=True)
    rows: list[dict] = []
    drift = False
    branches = _local_branches() if all_branches else _active_branches()
    for br in branches:
        upstream_ref = f"origin/{br}"
        # does the remote-tracking ref exist?
        exists = subprocess.run(
            ["git", "rev-parse", "--verify", "--quiet", upstream_ref],
            capture_output=True, text=True,
        ).returncode == 0
        if not exists:
            rows.append({"branch": br, "ahead": None, "has_upstream": False})
            # a local branch with no origin counterpart is its own (softer) drift
            # signal, but not the push-failure class — report, do not hard-fail.
            continue
        ahead_s = _git("rev-list", "--count", f"{upstream_ref}..{br}")
        ahead = int(ahead_s) if ahead_s.isdigit() else 0
        rows.append({"branch": br, "ahead": ahead, "has_upstream": True})
        if ahead > threshold:
            drift = True
    return rows, drift


# --------------------------------------------------------------------------
# HALF 2 — issue-register burn-down (heuristic)
# --------------------------------------------------------------------------

HEADER_RE = re.compile(r"^(#{2,4})\s+(.*)$")
STATUS_RE = re.compile(r"\*\*Status:\*\*\s*\**\s*([A-Za-z][A-Za-z /_-]*)", re.I)

OPEN_TOKENS = {"OPEN", "BLOCKED", "ACTIVE"}
DEFERRED_TOKENS = {"SCHEDULED", "DEFERRED", "PROPOSED", "STOPGAP-PROVEN-PENDING-PROPER-FIX"}
CLOSED_PREFIXES = ("RESOLVED", "CLOSED", "RETRACTED", "DUPLICATE", "SUPERSEDED",
                   "SPLIT", "RULED", "AMENDED")

TRIGGER_RE = re.compile(
    r"fires when|trigger\b|when .*?(spawns|lands|fires)|scheduled|close-criterion|"
    r"fires on|on ratif|upon ", re.I)
OWNER_RE = re.compile(
    r"\bOwner\b|owned by|architect-authored|architect designs|architect-class|"
    r"architect to rule|operator action|counsel-gated|orc builds|orc owns|"
    r"architect \(ratif|assigned to", re.I)
# "blocking" signal; the explicit NOT-blocking phrases win when present.
NOT_BLOCKING_RE = re.compile(
    r"NOT gating|not release-blocking|polish-quality|post-release|candidate; post-release|low-pri", re.I)
BLOCKING_RE = re.compile(r"\bblock|\bgat(e|es|ing)\b|critical path|release-blocking", re.I)


def _classify_status(header: str, body: str) -> str:
    h = header.upper()
    if h.startswith("OPEN") or h.startswith("BLOCKED"):
        # section-header form (no Status: line)
        return "OPEN"
    m = STATUS_RE.search(body)
    if not m:
        return "UNKNOWN"
    tok = m.group(1).strip().upper().split()[0]
    return tok


def _bucket(status: str) -> str:
    if status in OPEN_TOKENS:
        return "open"
    if status in DEFERRED_TOKENS:
        return "deferred"
    if any(status.startswith(p) for p in CLOSED_PREFIXES):
        return "closed"
    return "other"


def parse_register(path: Path) -> dict:
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    # split into issue blocks on headers that look like an issue/disc/wp/status section
    blocks: list[tuple[str, str]] = []
    cur_header: str | None = None
    cur_body: list[str] = []
    for ln in lines:
        m = HEADER_RE.match(ln)
        if m:
            title = m.group(2).strip()
            looks_issue = bool(
                re.search(r"\b(ISSUE|DISC|WP)-", title)
                or title.upper().startswith(("OPEN", "BLOCKED"))
            )
            if looks_issue:
                if cur_header is not None:
                    blocks.append((cur_header, "\n".join(cur_body)))
                cur_header = title
                cur_body = []
                continue
        if cur_header is not None:
            cur_body.append(ln)
    if cur_header is not None:
        blocks.append((cur_header, "\n".join(cur_body)))

    cats = {"a_blocking_owned": [], "b_blocking_unowned": [],
            "c_deferred_trigger": [], "d_standing_disc": [], "closed": [], "other": []}
    unowned_no_trigger: list[str] = []

    for header, body in blocks:
        status = _classify_status(header, body)
        bucket = _bucket(status)
        is_disc = "DISC-" in header.upper() or "standing" in (header + body).lower()
        short = (header[:80] + "…") if len(header) > 80 else header

        if bucket == "closed":
            cats["closed"].append(short)
            continue
        if bucket == "deferred":
            cats["c_deferred_trigger"].append(short)
            continue
        if bucket == "open":
            blob = header + "\n" + body
            has_trigger = bool(TRIGGER_RE.search(blob))
            has_owner = bool(OWNER_RE.search(blob))
            not_blocking = bool(NOT_BLOCKING_RE.search(blob))
            blocking = (not not_blocking) and bool(BLOCKING_RE.search(blob))
            if is_disc:
                cats["d_standing_disc"].append(short)
            elif blocking and has_owner:
                cats["a_blocking_owned"].append(short)
            elif blocking and not has_owner:
                cats["b_blocking_unowned"].append(short)
            else:
                # open but not clearly blocking — park in standing/other view
                cats["d_standing_disc"].append(short)
            if not has_trigger and not has_owner:
                unowned_no_trigger.append(short)
            continue
        if is_disc:
            cats["d_standing_disc"].append(short)
        else:
            cats["other"].append(short)

    return {"total_blocks": len(blocks), "cats": cats,
            "unowned_no_trigger": unowned_no_trigger}


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=int, default=0,
                    help="local-ahead-of-origin tolerance (default 0)")
    ap.add_argument("--register", default="issues_register.md")
    ap.add_argument("--fetch", action="store_true", help="git fetch origin first")
    ap.add_argument("--no-issues", action="store_true", help="drift flag only")
    ap.add_argument("--all-branches", action="store_true",
                    help="check every local branch, not just main + module/*")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    rows, drift = check_push_drift(args.threshold, args.fetch, args.all_branches)
    reg = None
    if not args.no_issues:
        p = Path(args.register)
        reg = parse_register(p) if p.exists() else {"error": f"{p} not found"}

    if args.json:
        print(json.dumps({"push_drift": {"rows": rows, "drift": drift},
                          "register": reg}, indent=2, default=str))
    else:
        print("=== HALF 1 — PUSH DRIFT (local ahead of origin) ===")
        for r in rows:
            if not r["has_upstream"]:
                print(f"  {r['branch']:<32} NO origin upstream (local-only)")
            else:
                mark = "  DRIFT!" if (r["ahead"] or 0) > args.threshold else ""
                print(f"  {r['branch']:<32} ahead={r['ahead']}{mark}")
        print(f"  => push_drift={'YES (exit 2)' if drift else 'no'}")
        if reg and "error" not in reg:
            c = reg["cats"]
            print("\n=== HALF 2 — ISSUE REGISTER (heuristic; confirm candidates) ===")
            print(f"  parsed blocks: {reg['total_blocks']}")
            print(f"  (a) blocking & OWNED ........ {len(c['a_blocking_owned'])}")
            print(f"  (b) blocking & UNOWNED ...... {len(c['b_blocking_unowned'])}  <- drift set")
            print(f"  (c) deferred w/ trigger ..... {len(c['c_deferred_trigger'])}")
            print(f"  (d) standing/DISC/other-open  {len(c['d_standing_disc'])}")
            print(f"  closed/resolved ............. {len(c['closed'])}")
            if c["b_blocking_unowned"]:
                print("  -- (b) blocking-and-UNOWNED:")
                for t in c["b_blocking_unowned"]:
                    print(f"       • {t}")
            if reg["unowned_no_trigger"]:
                print(f"  -- OPEN with NO trigger AND NO owner ({len(reg['unowned_no_trigger'])}):")
                for t in reg["unowned_no_trigger"]:
                    print(f"       • {t}")
        elif reg:
            print(f"\n[HALF 2 skipped] {reg.get('error')}")

    if drift:
        return 2
    if reg and "error" not in reg and reg.get("unowned_no_trigger"):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
