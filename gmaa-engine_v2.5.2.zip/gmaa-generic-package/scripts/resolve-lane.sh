#!/usr/bin/env bash
# Shared lane-identity resolver (spine-owned).
# IDENTITY COMES FROM LOCATION: lane = the worktree FOLDER name, cross-checked
# against the committed _boot/BOOTSTRAP.md stamp. This is the security property —
# a hand-created folder has no valid stamp, so it CANNOT mint a new seat.
# Consumers: (a) interactive seat cold-boot; (b) the post-commit hook.
# Resolves the COMMITTING/own WORKTREE root; never trunk-hardcoded, never cwd-assumed.
# Exit 0 = resolved (prints one KEY=VALUE line). Exit 3 = HALT (unresolved/mismatch);
#          caller MUST NOT default to the integrator lane on exit 3.
#
# GENERICIZATION NOTE (vs a branch-mapped origin resolver): such an origin derives the
# cross-check EXPECT from a hardcoded `case "$BRANCH"` map (one branch->lane entry per
# seat, e.g. main->foundation) plus a separate session `/rename` step. This generic
# resolver drops BOTH: (1) lane = basename of the worktree folder (no per-project
# branch->lane table to hand-edit; the tmux session is <project>-<lane> via resolve-project.sh); (2) the stamp
# cross-check is re-anchored from stamp-vs-branch to stamp-vs-FOLDER. The exit-3 /
# never-default-to-integrator behaviour on any mismatch is unchanged.
set -u

WT_ROOT="${GIT_WORK_TREE:-$(git rev-parse --show-toplevel 2>/dev/null)}"
[[ -z "$WT_ROOT" ]] && { echo "LANE-UNRESOLVED: no worktree root" >&2; exit 3; }

# ---- FOLDER-EQUALS-LANE: the resolved lane is the worktree folder name ----------
LANE="$(basename "$WT_ROOT")"
[[ -z "$LANE" || "$LANE" == "/" ]] && { echo "LANE-UNRESOLVED: cannot derive folder name from '$WT_ROOT'" >&2; exit 3; }

BOOT="$WT_ROOT/_boot/BOOTSTRAP.md"
[[ -f "$BOOT" ]] || { echo "LANE-UNRESOLVED: missing $BOOT (a folder without a committed stamp cannot mint a seat)" >&2; exit 3; }

# Read a KEY from the YAML frontmatter block ONLY (between the first two '---').
field() {
  awk -v k="$1" '
    /^---[[:space:]]*$/ { d++; next }
    d==1 && index($0, k":")==1 { s=$0; sub("^" k ":[[:space:]]*", "", s); print s; exit }
  ' "$BOOT"
}

STAMP=$(field lane); ROLE=$(field role); VERSION=$(field bootstrap_version); SPINE_WRITE=$(field spine_write)
[[ -z "$STAMP" ]] && { echo "LANE-UNRESOLVED: _boot present, lane: unset" >&2; exit 3; }

# ---- STAMP-VS-FOLDER cross-check (security property) ----------------------------
# The committed stamp MUST match the folder the worktree lives in. A stamp
# copied into the wrong folder (or a hand-made folder with no matching stamp)
# must NOT resolve clean -> HALT, never boot it as a lane.
if [[ "$STAMP" != "$LANE" ]]; then
  echo "LANE-MISMATCH: stamp lane='$STAMP' != folder '$LANE'" >&2
  exit 3
fi

# ---- CURRENCY GATE (non-fatal, fail-safe) --------------------------------------
# Emits currency=STALE-BOOT when CHECKLIST "Last refresh" is > 7d old OR inbound
# relays in dispatch/ are newer than CHECKLIST.md. Resolve already succeeded above;
# this NEVER blocks boot. On any doubt => CURRENT.
CURRENCY=CURRENT
CHK="$WT_ROOT/CHECKLIST.md"
if [[ -f "$CHK" ]]; then
  refresh_date=$(grep -m1 -iE '^\*\*Last refresh' "$CHK" 2>/dev/null | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}' | head -1)
  if [[ -n "$refresh_date" ]]; then
    refresh_epoch=$(date -j -f "%Y-%m-%d" "$refresh_date" +%s 2>/dev/null || date -d "$refresh_date" +%s 2>/dev/null || echo "")
    if [[ -n "$refresh_epoch" ]]; then
      age_days=$(( ( $(date +%s) - refresh_epoch ) / 86400 ))
      [[ "$age_days" -gt 7 ]] && CURRENCY=STALE-BOOT
    fi
  fi
  # INBOUND relays only — exclude OWN outbound (TO-*), else authoring an outbound
  # relay would falsely trip its own absorb loop.
  if [[ -d "$WT_ROOT/dispatch" ]] && find "$WT_ROOT/dispatch" -maxdepth 1 -name 'RELAY*.md' \
        ! -name 'RELAY-TO-*' -newer "$CHK" 2>/dev/null | grep -q .; then
    CURRENCY=STALE-BOOT
  fi
fi
if [[ "$CURRENCY" == STALE-BOOT ]]; then
  echo "STALE-BOOT: CHECKLIST stale / unabsorbed relays -> proceed, emit STALE-BOOT in BOOT-ACK." >&2
fi

# ---- SUBAGENT MODEL (declared slot) --------------------------------------------
# ALL subagents run on one declared model, emitted so every seat can CITE it in
# BOOT-ACK. Read from the BOOTSTRAP field `subagent_model` if present; else the
# {{SUBAGENT_MODEL}} slot default. PRIMARY enforcement = the agent-def frontmatter
# (`.claude/agents/*.md model:`), read by the CLI at spawn. This field documents
# the value + keeps it spine-current.
SUBAGENT_MODEL=$(field subagent_model); [[ -z "$SUBAGENT_MODEL" ]] && SUBAGENT_MODEL="{{SUBAGENT_MODEL}}"

BLOB=$(git hash-object "$BOOT")
printf 'lane=%s role=%s version=%s spine_write=%s blob=%s currency=%s subagent_model=%s\n' \
  "$LANE" "$ROLE" "$VERSION" "$SPINE_WRITE" "$BLOB" "$CURRENCY" "$SUBAGENT_MODEL"
