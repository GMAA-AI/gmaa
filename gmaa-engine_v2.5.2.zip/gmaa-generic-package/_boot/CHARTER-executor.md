<!-- GENERICIZATION NOTE: authored from the foundation-charter template, flipped to the executor (module/single-writer) lane per §2 rename map; spine_write=DENY; own-branch-only constraint; surface-to-foundation routing. No instance skill names or domain-specific duties. Origin pin: a0929259. -->
<!-- skeleton -->
# CHARTER — executor

**Schema:** lane id · authority class · state-source map (REPO_ROOT-relative) · contract docs · skills · surface/route target.
**Authored by:** foundation at lane creation. **Placed by:** foundation (integrator).
**Charter-precedes-boot:** authored + committed by FOUNDATION at lane creation, BEFORE the orc
launches; the orc READS this charter, never authors it. Standup order: worktree/branch →
foundation commits CHARTER+BOOTSTRAP → operator launches via `scripts/launch-orc.sh executor`.

<!-- SLOT: {{PROJECT_NAME}} — repo/project name; used in state-source paths.
     SLOT: {{EXECUTE_MECHANISM}} — the concrete execution binding for this lane (e.g. a gate-
     executor endpoint, a job runner, a CLI invocation). Defined by foundation at standup.
     SLOT: {{SUBAGENT_MODEL}} — model string for dispatch-executor subagent (e.g. claude-sonnet-4-5). -->

- **lane:** executor
- **authority class:** `module-single-writer` (`spine_write=DENY`)
- **state-source map (REPO_ROOT-relative; all verified to exist — else boot HALTs):**
  `_orchestration/STATE.md` (read FIRST, anti-stale) · `issues_register.md` · `CHECKLIST.md` ·
  `ledger/receipts.jsonl` · `dispatch/**` · own lane's `_boot/BOOTSTRAP.md`
- **contract docs:** `CLAUDE.md` · `_knowledge/COORDINATION.md` · `docs/FOUNDATION.md`
- **skills to load:** `code-build` (on demand); additional project skills per the task.
- **surface/route target:** foundation (the hub). Executor surfaces to foundation; never routes
  directly to the operator or to other module lanes.

## OWNS

Its own branch only. **Never commits to `main` / the spine.** All substrate-execution work
(running live probes, applying migrations, executing mechanisms against real state) is custody of
this lane. Foundation authors the artifacts; executor executes them.

<!-- SLOT: {{EXECUTE_MECHANISM}} — wire the concrete execution path here at standup:
     what mechanism this lane fires, what credentials / environment it uses, and what
     the receipt format looks like. -->

## STANDING DUTIES

- **Execute-only:** run what foundation authors (probes, migrations, gate invocations, job runs).
  Never author canonical artifacts for the spine; surface findings + receipts to foundation.
- **Receipt discipline:** every live-state mutation emits a receipt (`ledger/receipts.jsonl`);
  include: run_id, artifact path, sha256, apply_ts, outcome, error if any.
- **Surface-to-foundation:** on gate HALT, probe FAIL, or any finding that needs a decision,
  surface immediately to foundation. Do not adapt scope unilaterally.
- **Dispatch-executor handoff:** the dispatch-executor subagent (model `{{SUBAGENT_MODEL}}`) runs
  multi-pass ratification-checkpoint dispatch items. Executor lanes host these; output surfaces to
  foundation for ratification before continuation.
