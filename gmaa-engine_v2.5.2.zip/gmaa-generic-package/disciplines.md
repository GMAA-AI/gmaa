# disciplines.md — {{PROJECT_NAME}} standing disciplines

# GENERICIZATION NOTE: derived from an origin disciplines file. The §1 generic standing disciplines
# are kept verbatim in structure and principle (instance substrate details, domain nouns, ruling/issue
# citations, live dates, tool instance IDs stripped). The origin §2 (mechanism-platform blueprint
# patterns) is DROPPED as instance-specific and migrated to that project's skill; the pattern FRAME is
# preserved so an adopter adds their own §2 patterns. Seat/lane names renamed to the generic census.

Standing-class entries moved out of `issues_register.md`. The register taxonomy is kept clean as
`{Open, Scheduled, Resolved, Won't Fix, Duplicate, Retracted}`; STANDING semantics live here. Each
entry below is permanent — no Open/Closed semantics; closes only if the underlying discipline is
explicitly retracted by architect/operator.

---

## §1 — Standing disciplines (architect/operator-banked)

### DISC-SPEC-DOCS-FIRST
- **Rule:** Before treating anything as an open question, a decision to weigh, or a path to discover,
  **READ THE SPEC DOCS FIRST.** The default assumption is that it is already decided and the answer is
  written down.
- **Sources (in order):** `CLAUDE.md` / `_knowledge/COORDINATION.md` / `disciplines.md` (live contract)
  → the relevant `contracts/C-*` → `CHECKLIST.md` → the relevant `_boot/CHARTER-*`.
- **If the spec answers it** → proceed and CITE the doc. Do NOT surface it as a question, do NOT route
  it for a ruling, do NOT reason it out from scratch.
- **Only if the spec is genuinely SILENT or self-contradictory** → surface as a real open question
  (architect ruling for HOW, operator for WHAT).
- **Why:** re-litigating settled design burns turns, reads as not knowing the system, and risks
  re-deriving a WORSE answer than the one already banked (the spec-revision-repeats-the-bug class).
  Spec-docs-first is the cheap interrupt on the re-litigation reflex.
- **SCOPE (load-bearing distinction):** applies to DESIGN / architecture / path questions —
  *"is this DECIDED?"* → spec docs. Does NOT apply to LIVE-STATE — *"is this DEPLOYED / enabled /
  ON right now?"* → orc HEAD readback, never a spec assumption. Do not collapse the two.

### DISC-COST-AUTH-PROTOCOL
- **Rule:** COST-INCURRING-ACTION RULE — any action that signs up for / creates / upgrades / activates
  a paid resource requires BEFORE execution: (1) architect cost analysis (low/likely/high vs
  alternatives, reversibility, escalation triggers, vs code-only/do-nothing); (2) operator explicit
  pre-authorization naming the specific dollar figure; (3) re-confirmation prompt "to confirm $X for
  <resource>; confirm again to proceed?" — proceed only on second confirm.
- **Applies to:** plan/SKU changes, new function apps on paid plans, third-party API tier upgrades /
  NEW subscriptions, new hosting/monitoring services, one-time charges above the operator-set floor,
  spinning-up-to-test (perimeter is resource CREATION, not net residual cost).
- **Does NOT apply to:** per-request charges within already-authorized services at existing rate/ceiling,
  code-only usage adjustments, non-SKU infra changes (config tweaks, refactors).
- **Enforcement:** orc autonomous charters do NOT cover plan changes or new paid services regardless of
  operational judgment; architect cannot ratify cost-incurring actions without (1-3); operator silence
  is not consent on cost.

### DISC-AGENT-FLEET-GITIGNORE-PROTECTION
- **Invariant:** Any `.gitignore` edit that touches a `.claude/*` pattern requires architect surface
  BEFORE commit. The negation rule `!.claude/agents/` must remain in `.gitignore` for the fleet to
  survive working-tree reconstitution.
- **Pre-flight (mandatory before any .gitignore commit affecting .claude/*):**
  1. NEGATION RULE PRESENT — `grep -E '^!\.claude/agents/' .gitignore` must return ≥1 line (exit 0)
  2. CHECK-IGNORE VERIFIES — for each core agent def: `git check-ignore -q .claude/agents/<f>.md`
     must report NOT ignored; zero FAIL lines
  3. CORE DEFS ALL TRACKED — `git ls-files --error-unmatch .claude/agents/<f>.md` for all core defs;
     zero MISSING lines
- **If checks 1/2/3 fail on a proposed change:** STOP and surface to architect — do not commit.

### DISC-OPERATOR-INPUT-PRECEDENCE
- **Rule:** OPERATOR-INPUT-PRECEDENCE — any gate that writes to a field the operator can populate at
  submit-time MUST check existing value and skip the write if non-empty. Operator input is authoritative
  for fields the operator authored; automation can fill gaps, not override intent.

### DISC-COST-GOV-FULL-CHARGE-SURFACE
- **Rule:** Cost-governance projections at deploy ratification MUST include all charge axes — not just
  token costs but also any per-call / per-session / per-action charges from server-side tools or
  third-party services invoked by the mechanism.

### DISC-VERIFY-BEFORE-RULING
- **Rule:** ANY claim about specific tool use, routing, or behavior in mechanism code requires live
  readback of source BEFORE assertion. Architectural intuition is insufficient. Live readback is the
  evidence; a ruling without it is retractable without ceremony.

### DISC-OPERATOR-INPUT-PRECEDENCE-APPLIES-GATEWIDE
- **Rule:** Field clobber audit — when an OPERATOR-INPUT-PRECEDENCE fix lands for one gate, enumerate
  every gate's write statements against operator-populatable fields; apply the same fix uniformly. A
  class-level drift in one gate is evidence of the same class-level drift in siblings.

### DISC-CONTENT-READ-LIVE-VS-CACHE-MEDIATED
- **Rule:** A `web_fetch`/browser content reading is **cache-mediated, not origin**. Before treating
  any content finding from a browser read as live state OR moving a register status / authoring a fix
  dispatch, **confirm via a cache-MISS fetch or a REST `?context=edit` equivalent** (origin readback).
  Cache-mediated readings can disagree with origin by tens of minutes to hours depending on cache TTL.
- **Application:**
  1. Verification sweeps (adopter-defined: e.g. compliance, voice/persona, link/reference, output-quality audits) — origin-readback only.
  2. Status flips on register entries based on "looks clean on the page" — require a cache-MISS or
     REST origin confirmation before flip.
  3. Fix dispatches authored on a content-reading finding — same origin-readback precondition.

### DISC-OPERATOR-SURFACES-UI
- **Rule:** Operator-required state transitions (scenario activation, cost authorization, publish GO,
  and any act that rulings assign to the operator's door) are invoked through UI surfaces the operator
  owns (console, app UI) — never through shell workarounds or a seat acting "on the operator's behalf"
  at a terminal. **An apex decision gets an apex surface.** A seat that cannot proceed because the
  surface is missing HALTS and names the missing surface; building it becomes the work item.
- **Cross-ref:** CLAUDE.md discipline #3 (lane separation; never route plumbing to the operator — this
  is the mirror: never route the operator's act through plumbing).

### DISC-COST-NO-CROSS-PATH-EXTRAPOLATION
- **Rule:** Cost figures are never extrapolated from one execution path onto another. A measured cost
  binds only to the path that produced it (same seat class, same rail, same tool chain); a different
  path gets its own measurement or an explicitly-labeled estimate, never an inherited number.

### DISC-RECURRING-AUTOMATION-CADENCE-CEILING
- **Rule:** Every recurring / scheduled mechanism added to a production environment MUST surface its
  cost profile (frequency × per-cycle cost vector) at activation ratification, BEFORE deploy.
  Surfacing means: cadence × per-cycle cost = projected daily/monthly steady-state cost, listed in the
  receipt-back relay and ratified by architect.
- **Default cadence ceiling:** hourly. Sub-hourly and always-on polling require explicit architect
  justification at activation. Event-driven invocation (HTTP-triggered + manual fire / app-driven /
  webhook-from-upstream) is **preferred** for on-demand workloads.

### DISC-DISPATCH-VERIFY-LIVE-STATE
- **Rule:** Dispatch authoring MUST verify current state immediately before authoring any
  state-touching dispatch. Surface state from prior commit messages or chat memory is INSUFFICIENT —
  live state check OR closeout grep is mandatory.
- **Pattern:** part of the verify-before-rule family (premature ratification on stale assumption).

### DISC-LIVE-RENDER-IS-GROUND-TRUTH
- **Rule:** The rendered result of an automation mechanism → output-surface flow is the ONLY ground
  truth for its output quality. **Mechanism-correct ≠ prompt-correct ≠ output-correct.** The real
  rendered artifact — body, structure, metadata — CANNOT be predicted from the mechanism config, the
  prompt text, an upstream read, or any simulation. **NO output-quality claim may be marked Resolved
  on mechanism-state or prompt-state.** Closure requires inspecting the real rendered artifact via
  an authenticated origin read.
- **Scope:** any mechanism → output-surface quality issue. Does NOT downgrade LIVE-DATA-ONLY — that
  governs test-DATA provenance; THIS governs output-QUALITY closure evidence. The two are orthogonal
  and both binding.
- **Enforcement:** a "Resolved" whose only evidence is a mechanism/prompt diff is a fake closure
  (FOUNDATION §8.2 / CLAUDE.md inv #4) → reject; require a rendered-artifact receipt before close.

### DISC-NO-INHERITED-COUNT — a cohort number is a claim, not a receipt (all seats)
- **(1) Re-derive at the boundary.** Any cohort count entering a ruling/decision is RE-DERIVED at that
  boundary from a ruling or a receipt query. A count copied from memory/synopsis/relay MAY NOT be
  ruled on — re-derive or refuse.
- **(2) N-of-M prints M, or the relay does not ferry.** Any relay naming a subset ("the 16", "the
  near-term cohort") MUST print the denominator AND the disposition of the difference in the SAME
  artifact. A subset without a denominator is an incomplete set presentation → rejected at transport.
- **(3) A pre-digested number is a query trigger, not a fact.** Absence of a visible derivation is
  the signal to query.
- **(4) Binds the bootstrap author too.** Successor bootstraps print cohort counts WITH denominators
  + ruling citation, or omit them and force the query. Shorthand that cannot be safely inherited must
  not be written into a hand-off.
- **(5) Widened to ANY inherited proposition.** DISC-NO-INHERITED-COUNT covers ANY proposition
  inherited across a context boundary — counts, shapes, absences, asks, fixes, and premises. *An
  inherited ASK is re-derived against the register before it is raised.*

### DISC-ABSENCE-OF-RECORD — an absence is evidence ONLY when the recording mechanism is proven live (all seats)
- **(1) Name the mechanism, prove it was live.** Before inferring *"X never happened"* from *"no
  record of X,"* name the mechanism that would have recorded X and show it was operating at the moment
  in question. If unproven → the finding is **"NO RECORD"**, full stop — a weaker claim than "did not
  happen", carrying different confidence, routing differently.
- **(2) This binds relay PROSE, not just probes.** A receipt and its interpretation travel in the
  same relay — **label which sentence is the receipt and which is the inference.** The gap between
  "no execution logged" (receipt) and "it never fired" (inference) is where a multi-day mis-route
  lives.

### DISC-REGISTER-AT-DIAGNOSIS — read the defect register at DIAGNOSIS boundaries, not only at closure (all seats)
- **Before opening a new defect hunt, state which registered defects predict the observed signature
  and rule them in or out BY RECEIPT.** A new hunt is authorized only after the register is cleared.
  Cheap (a query), and it is the difference between a query and a week.
- The register is a **claim/hypothesis surface** — ruling a registered defect in or out still requires
  a live receipt, not the register entry alone. But the register tells you *which receipt to pull first*.

### DISC-EXHAUSTIVE-BRANCH — a discriminator probe must permit "neither," and the seat must report it (all seats)
- **(1) Every discriminator probe must permit "neither" — and the seat running it MUST report
  "neither" rather than route to the nearest branch.** Never bend an answer to fit the pre-ruling.
- **(2) A two-branch pre-rule is safe ONLY if exhaustiveness is DERIVED, not assumed.** Before
  pre-ruling branches, state *why* the branch set is complete. If you cannot, pre-rule `else →
  HALT and report` as a named branch, explicitly, in the relay.
- **(3) Pre-ruling is a latency device, not an epistemics device** — it removes a round trip, never
  substitutes for the query. When they collide, the query wins.

### DISC-CORPUS-IS-MEMORY — local snapshot files are MEMORY, never SUBSTRATE; read shape LIVE (all seats)
- **(1) Local snapshots are MEMORY, not SUBSTRATE** — a snapshot of unknown age. Reading a file
  directly feels like ground truth because it is bytes — but they are **snapshot bytes.**
- **(2) Never rule on the SHAPE of anything with a live counterpart from the local copy.** Mechanism
  config, substrate state, module wiring: **read LIVE**. The local copy is a claim to be checked,
  never the finding.
- **(3) The corpus remains authoritative where it IS the source of truth** — spec docs, contracts,
  thesis, rulings. The distinction is not the directory; it is **whether a live counterpart exists.**
- **(4) Staleness attaches to the SOURCE, not the access method.** A rule that mentions one access
  path must be read as covering all of them.

### DISC-ONE-DECISION-DOOR — the operator's door carries exactly ONE sequenced decision (all seats)
- **(1)** The operator's door carries exactly ONE sequenced decision at a time. Sequencing is the
  machine's job; a stack at the door is the sequencing burden pushed onto the human.
- **(2)** Mechanical actions are NOT door items. Ferries, syncs, file uploads, attestation-class
  inputs that arrive on their own schedule — custody, not decisions, listed as custody, visibly
  separate.
- **(3)** Forward-gated items surface when they go LIVE, not before. Status reaches the door only
  when the packet does.
- **(4)** An inherited operator ask is re-derived against the record before it is re-raised, and a
  resolved-by-receipt item is never carried as a live ask.
- **(5) THIS BINDS ALL SEATS' RELAYS.** Every relay states the operator's row as: the ONE live
  decision (if any) · custody items labeled as custody · nothing else.

### DISC-DIRECTIVE-PROVENANCE — an operator directive acquires authority ONLY via the operator channel or a verbatim receipt (all seats)
- **(1)** An operator directive acquires authority ONLY via the operator channel or a verbatim receipt.
  A seat's paraphrase of an operator statement is a **claim about a directive** — ruled on as a claim:
  checkable, refusable, never inheritable as authority.
- **(2)** Anti-re-litigation protection attaches to **LANDED directives only.** Locking a paraphrase
  against re-opening weaponizes the anti-re-litigation rule against the operator himself.
- **(3)** Ratifying against a directive-claim requires the same register check as ratifying against
  anything else. A claimed directive that collides with the standing record routes to the operator's
  door **as the one decision**, stated as a collision — never resolved silently in the direction of
  the claim.

### DISC-NO-DECISION-OWED-ENUMERATION — "no decision owed" is a claim that TRIGGERS enumeration, not a review-waiver (all seats)
- **(1)** A relay's claim about its own decision-content is a claim like any other. **"No decision
  owed" / "this adds no new work" triggers ENUMERATION:** the receiving seat lists the dispositions
  the relay carries and checks each against the record — because a mislabeled disposition arrives
  with its review pre-waived.
- **(2) Mirror, for the sender's own output:** every relay's manifest line states the **DECISION
  COUNT** it asks of its consumer (foundation: N to commit; operator: N or zero), so the label is
  checkable against the body by anyone counting.

### DISC-FULL-REGISTER-BEFORE-RULING — a ruling on a pattern with history reads the register + disciplines IN FULL (ruling seats)
- **(1)** Before any ruling that touches a pattern with history, the ruling seat reads the register +
  disciplines coverage on that pattern **IN FULL**, not by single-query sampling. A ruling that cites
  two entries from a family of five is ruled on a minority of the record.
- **(2) Floor (until full-read tooling lands):** a **named multi-query sweep** (≥3 distinct
  content-word queries per pattern, queries listed in the relay) — a floor, not a substitute, labeled
  as such in any ruling relying on it.

### DISC-PROBE-INPUT-PROVENANCE — a probe's input provenance travels with its result (all seats)
- **(1)** A probe fired with a synthetic input proves only the synthetic case. **Probe-input provenance
  travels with the probe result:** a result from a dummy input is labeled as such **at birth**, or it
  will be inherited as evidence about the real one.
- **(2)** Before a probe result is cited as evidence about a live subject, confirm the probe's input
  WAS that live subject — not a stand-in, canary, or placeholder that reproduces a different case.

### DISC-LLM-AT-THE-EDGES — LLM invocation is justified in exactly two places; all other mechanics are written code (all seats)
- **Rule (standing, binding):** LLM invocation is justified in exactly two places — **(1) content
  generation** (post/draft composition + its editorial transforms), and **(2) judgment-class evaluation
  over unstructured evidence** that cannot yet be reduced to deterministic rules over structured data.
  **(2) is a TEMPORARY license**, held only until the judgment can be distilled into code or replaced
  by a structured source. **All other mechanics are written code** (gates, walkers, conduits, janitors,
  executors).
- **Immediate binding effect:** **NO NEW LLM call enters any mechanism without a ruling at the
  architect seat.** Existing calls are grandfathered pending a gate-mechanics review.
- **Where judgment is retained (until distilled):** the call is **one-shot · structured-output ·
  receipted · CACHED against re-runs** — never a per-walk re-evaluation of unchanged evidence — with
  a named distillation trigger for eventual conversion to code/structured-source.
- **Why:** verdict non-reproducibility across models is a receipt-quality defect; and LLM extraction
  can be worse than operator-supplied input on editorial paths. The long-run shape is code that runs
  + a model that writes; where a model still judges, it judges once, on the record, until the judgment
  itself can be written down.
- **SCOPE:** criteria changes are never bundled into refactors — anything touching gate CRITERIA (not
  just implementation) surfaces separately.

### DISC-NEW-INFRA-IMPACT-REVIEW — a written impact review + operator sign-off BEFORE any new billable resource (foundation; all infra seats)
- **Rule:** before creating **any new billable resource** (resource creation · plan/SKU change ·
  anything that adds a billing meter), foundation surfaces a **written impact review** — resources ·
  billing model · recurring-cost/polling analysis · reuse-vs-new · rollback — and obtains **operator
  sign-off**. **Mechanism-ratification ≠ infra-creation authorization; they are separate gates.**
- **Scope line:** configuration changes *within* existing resources (app settings, env vars, code
  publish) do NOT trigger it — the gate sits at the **billing-meter boundary**.
- **Cost-governance triad (one family, cite together):** DISC-NEW-INFRA-IMPACT-REVIEW at the
  **provisioning** boundary · a runtime cap+alert at the **gate** boundary · a pre-run estimate at
  the **recurring-automation** boundary (any metered recurring run carries its pre-run estimate + cap
  check in the authorizing relay).

---

## §2 — Project-specific patterns (adopter fills this section)

This section is the forward-migration target for mechanism-specific patterns discovered in operational
use. Each pattern entry should include: a pattern name in SCREAMING-SNAKE, a description of the
mechanism shape, the canonical approach, the anti-pattern it supersedes, and a "banked" note for
provenance.

When a pattern is stable enough to graduate to §1, move it there with architect ratification.

**Structure each entry:**
```
### PATTERN-NAME
- **Pattern:** <canonical approach — what to do and why>
- **Anti-pattern:** <the wrong approach this replaces>
- **Banked:** <brief provenance — what incident or ruling established this>
```

<!-- Adopter: add project-specific mechanism patterns below this line. -->
