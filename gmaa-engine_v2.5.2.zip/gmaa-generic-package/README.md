<!-- COVER: authored by the GMAA Application Packaging Architect seat, 2026-08-06. Replaces the F7 SKEL-min stub README (and its genericization note, which referenced a superseded license split). Lands verbatim via foundation. Package v2.5.2 · canon pin v1.5. -->

# GMAA — Governed Multi-Agent Architecture · Engine

**Package v2.5.2 · Canon pin v1.5 · Canonical: [gmaa.ai](https://gmaa.ai) · Repository: [github.com/gmaa-ai/gmaa](https://github.com/gmaa-ai/gmaa) · Cite by version.**

GMAA is a governance layer for multi-agent systems. The unit of authorization is the set, not the change: an accountable human ratifies the complete set of pending changes against the system's invariants before any of them commits. Agents approve changes one at a time; the failure lives in the set. GMAA places one writer over each coherence boundary, assembles the concurrent pending work, and puts an accountable seat, independent of every agent, over the whole set before commit.

This package is the **engine**: a generic, blank-copy instantiation of the architecture's production machinery, ready to be laid into your project's repository and instantiated for your project. It is derived from a live production system, genericized; it is not a proposal.

## What is in the box

- `canon/` — the specification (v1.5) and the coherence-session-law addendum. The rulebook.
- `CLAUDE.md`, `disciplines.md`, `docs/FOUNDATION.md` (skeleton) — the operating contract your project's architect instantiates.
- `scripts/` — the governance machinery: lane resolution, launch, sync, validation, audit.
- `.claude/` — the fleet: agent definitions (orchestrator, executor, workers, the optional code-substrate architect) and settings.
- `agents/` — the auditor layer: git hooks, standing probes, the audit contract.
- `contracts/`, `schema/` — the portable engine contracts and schema slots.
- `_boot/`, `_knowledge/`, `_escalations/`, `dispatch/` — boot chain, coordination, the escalation case study, the dispatch surface.
- `MANIFEST.sha256` — per-file integrity for everything above. Verify before use.

## Prerequisites (the substrate floor)

Install these first; the engine does not provision them: **Claude Code CLI**, **git** with a GitHub account, and **tmux**. On Windows this implies **WSL2** with a POSIX shell. Verify each responds on your PATH before Phase 0. This release targets adopters who clear this floor.

Check the whole floor in one line, or run the bundled check:

```
claude --version && git --version && tmux -V && gh auth status
bash scripts/preflight.sh
```

## Getting started

1. Verify the package: check the zip's sha256 against its companion note, unpack, run `sha256sum -c MANIFEST.sha256`.
2. Read `canon/` first, then `CLAUDE.md`. The architecture governs the engine, not the other way around.
3. Begin with the chat-architect consultation: your project's architect (a chat seat) works from the canon and this engine to produce your project's instantiation, filling `docs/FOUNDATION.md` from its skeleton for your project.
4. Instantiate: lay the engine into your project repository, resolve lanes (folder equals lane), launch seats with `launch-orc.sh`.
5. Prove the governance before trusting it: run the seeded-fault cycle (the step-8 catch). The reconciliation gate must fire on a deliberately withheld artifact. If it passes without firing, the gate is broken; fix it before relying on it.
6. Optional, after instantiation: activate the code-substrate architect seat. The chat architect and code architect are the same role on two substrates, never occupied concurrently; the code architect joins the communication circle by doorbell, reachable only by the foundation seat and the operator.

## Licensing (open spec, internal-use engine)

- **The specification (`canon/`) is free**: CC BY 4.0, attribution required, cite by version.
- **This engine is source-available for internal use only**: PolyForm Internal Use 1.0.0 — use it and adapt it for the internal operations of you and your company; you may not distribute it, sublicense it, or provide it or works based on it to anyone outside your organization. See `LICENSE.md`.
- **Operational graduation is the licensor's service**: turning this engine into a running governed fleet for your specific project. Reach: arch@gmaa.ai.

## Integrity and versioning

Two axes, always stated together: the package version (this release: v2.5.2) and the canon pin (v1.5, by sha). Every content change is a version bump; nothing is rebuilt in place. Verify fingerprints from disk. If a verification fails, stop and report; do not proceed on a package that does not prove itself.

— By Israel Heskiel. Built and run in production. Canonical: gmaa.ai.
