#!/usr/bin/env bash
# probes/discrimination_proof_neutral.sh — NEUTRAL DISCRIMINATION-PROOF.
#
# Purpose: prove the standing-probe HARNESS genuinely distinguishes PASS from FAIL
# (that pass_signal / fail_signal classification is real, not a vacuous always-pass) —
# using ZERO adopter infra: no database, no HTTP endpoint, no console, no credentials,
# no instance data. Runnable on a clean checkout — the free engine must genuinely RUN.
#
# Contract (matches the agents/standing-probes.yaml `discrimination-proof-neutral` entry):
#   - DEFAULT run:  asserts a KNOWN-TRUE fixture -> prints "VERDICT: PASS", exit 0.
#   - FLIP  run:    DISCRIMINATION_PROVE_FAIL=1 asserts a KNOWN-FALSE fixture ->
#                   prints "VERDICT: FAIL", exit 1. This is the discrimination half:
#                   it demonstrates the harness's fail_signal path fires (so a real
#                   regression would be caught, not silently passed).
#
# The two fixtures are pure arithmetic identities (2+2==4 true; 2+2==5 false) so the
# proof depends on nothing external and can never be flaky.

set -u

fixture_true()  { [[ $((2 + 2)) -eq 4 ]]; }   # KNOWN-TRUE  invariant
fixture_false() { [[ $((2 + 2)) -eq 5 ]]; }   # KNOWN-FALSE invariant (the flip)

if [[ "${DISCRIMINATION_PROVE_FAIL:-0}" == "1" ]]; then
    # Discrimination half: assert the known-false fixture; the harness MUST see FAIL.
    if fixture_false; then
        echo "VERDICT: PASS"   # unreachable — 2+2 never equals 5
        exit 0
    else
        echo "VERDICT: FAIL (discrimination proof: known-false fixture correctly rejected)"
        exit 1
    fi
fi

# Default half: assert the known-true fixture; the harness MUST see PASS.
if fixture_true; then
    echo "VERDICT: PASS (neutral discrimination proof: known-true fixture holds; harness live)"
    exit 0
else
    echo "VERDICT: FAIL (harness broken — 2+2 assertion failed)"
    exit 1
fi
