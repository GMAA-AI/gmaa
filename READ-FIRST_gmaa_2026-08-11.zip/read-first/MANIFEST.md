# Outputs layout, 2026-08-11

One folder per ferry destination. Zips of the two deploy sets sit beside this file.

- **site-deploy/** -> the gmaa.ai web root. 7 pages + robots.txt + llms.txt + sitemap.xml.
  Deploy atomically with the repo set (pages reference the v1.6 PDF path). Note: sitemap lists
  field-evidence.html; drop that line if the field-evidence page stays parked.
- **repo-gmaa/** -> github.com/gmaa-ai/gmaa. LICENSE.md (counsel reviews first, legal artifact) ·
  v1.6 spec PDF + source md (land at canon/) · SHA256SUMS change note · README license-bullet swap ·
  getting-started chmod changeset · v1.6 public-transform changelog (ratification record).
- **relays/** -> ferried to seats (XP relay to affiliate architect; return leg to foundation).
- **content-drafts/** -> current publishable drafts only: Reddit r8, Show HN v1, Medium redo v1,
  LinkedIn v1 + v2-punchy + auto-mode response, Reddit compliance brief.
- **archive-superseded/** -> replaced revisions (Reddit r3-r7, v1.5 spec artifacts, early
  field-evidence strip, applied license copy-swap plan). Kept for the record, not for ferry.
