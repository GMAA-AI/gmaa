# GETTING-STARTED-LINUX-MAC.md: add `chmod +x launch-orc.sh` as a real step

Author-then-ferry: getting-started is the Publicist's reader material; this file ships in the repo, so the
arm commits. Applied as three coherent edits so the setup step, the launch step, and the troubleshooting
note all agree (today they don't: the walkthrough sidesteps chmod with `bash launch-orc.sh`).

Path note: the walkthrough runs the launcher as `launch-orc.sh` at the project-folder root (Step 6.2), so
`chmod +x launch-orc.sh` is correct there. If the launcher invokes sibling scripts under `scripts/` as
executables, add `chmod +x scripts/*.sh` too; confirm the exact layout against the unzipped engine.

---

## EDIT 1 - add the chmod step right after unzip (Step 4)

OLD (Step 4, item 2):
2. Unzip the engine zip into that folder, then copy the loose `canon/` folder and the docs (`README.md`, `ADOPTION-COVER.md`, `CLAUDE.md`) in beside it, so the engine and the docs all sit together in the project folder.

NEW (add item 3 immediately after):
2. Unzip the engine zip into that folder, then copy the loose `canon/` folder and the docs (`README.md`, `ADOPTION-COVER.md`, `CLAUDE.md`) in beside it, so the engine and the docs all sit together in the project folder.
3. **Make the launcher executable (first-time setup, once):** run `chmod +x launch-orc.sh`. Unzipping does not preserve the executable bit; this restores it a single time. You do not repeat it on later launches, Step 6 just runs `./launch-orc.sh` from then on. (Run it again only if you re-unzip a new engine version, which drops the bit again. And if the launcher reports `permission denied` on a script it calls, run `chmod +x scripts/*.sh` as well.)

## EDIT 2 - launch step now uses the executable directly (Step 6, item 2)

OLD:
2. Type `bash launch-orc.sh` and press **Enter**. The launcher checks the fills are in place and starts a session to instantiate the project per canon §12. It stands up the **foundation lane**. That lane's worktree folder is named `foundation` and is checked out to the `main` branch (folder equals lane; `main` is a branch, never a folder name).

NEW:
2. Type `./launch-orc.sh` and press **Enter**. The launcher checks the fills are in place and starts a session to instantiate the project per canon §12. It stands up the **foundation lane**. That lane's worktree folder is named `foundation` and is checked out to the `main` branch (folder equals lane; `main` is a branch, never a folder name).

## EDIT 3 - troubleshooting note now points at chmod (Troubleshooting)

OLD:
- **`permission denied` running the launcher:** use `bash launch-orc.sh`, not `./launch-orc.sh`.

NEW:
- **`permission denied` running the launcher:** the unzip dropped the executable bit. Run `chmod +x launch-orc.sh` (and `chmod +x scripts/*.sh` if a script it calls trips the same error), then retry. Running `bash launch-orc.sh` also works without setting the bit.

---

## Alternative (if you would rather NOT add chmod at all)
The current `bash launch-orc.sh` flow is already chmod-free and correct for the top launcher. If nothing the
launcher calls is invoked as `./`, you can leave the file as-is; it is not broken today. Adding chmod is the
right move only if a called script trips permission denied, or you want the conventional `./launch-orc.sh` UX.
Do not do half of it: chmod with `bash launch-orc.sh` still works but is redundant, and `./launch-orc.sh`
without chmod fails. Pick one column.
