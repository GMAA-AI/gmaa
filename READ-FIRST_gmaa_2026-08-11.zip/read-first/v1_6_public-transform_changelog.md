# v1.6 public-release transform, change log (minimal, correct bar)

The bar: the only leaks are specific PROJECT NAMES (the real sibling programs). All architecture
vocabulary stays, orc, foundation, origin/origin program, ARCH-120, launch-orc.sh, file/mechanism
names, provenance and lineage notes. Four edits total:

1. **Framing (required for public, decision A):** header line CONFIDENTIAL/evaluation-copy →
   "Licensed CC BY 4.0, attribution required." + canonical line. (Not a leak; the internal-vs-public
   framing switch.)
2. **The one leak:** §5 DMZ example "(affiliate↔GMAA↔AnchorPM)" → "(between separate programs on the
   same device)". This is the only place affiliate/AnchorPM appeared in the whole document.
3. **§11 reframe (you directed):** plugin described as "coming, not yet shipped"; current vehicle = the
   code as a compressed zip; the internal build-note aside removed.
4. **Version history moved to the bottom (you directed for v1.5, applied here for consistency).** Content
   unchanged, only relocated.

Nothing else was touched. orc / foundation / origin / ARCH-120 / _comms/spool lineage / BOOTSTRAP /
CHARTER-foundation / dates / ~/Code paths all remain as the architect wrote them.

## Three items flagged for your call (NOT changed by me)
- **Title:** v1.6 is authored as "Governed Multi-Agent *Delivery* Architecture." Kept as authored. Note it
  makes the public standard read as GMADA, not GMAA. Drop "Delivery" or keep, your call.
- **Draft placeholder:** §7.1 step 3 still contains "[BRACKETED, pending foundation's verbatim supply]".
  That is a visible incomplete-content marker; it should not ship in a published spec. Finalize the text or
  drop the bracket, architect's call.
- **Coherence note:** §5 states the _comms/spool was reverted / never built, but §7.4 still uses spool
  vocabulary (spool age, spool shrinking) for the liveness measurement. Internal contradiction for the
  architect to reconcile; not a leak, not mine to rewrite.
