REPO README.md, licensing bullet -- exact old -> new (arm applies on commit)

OLD:
- **This engine is source-available for internal use only.** PolyForm Internal Use 1.0.0. Use it and adapt it for the internal operations of you and your company. You may not distribute it, sublicense it, or provide it or works based on it to anyone outside your organization. See `LICENSE.md`.

NEW:
- **This engine is source-available under Apache 2.0 with the Commons Clause.** Use, modify, and redistribute it freely, including inside your own commercial operations. The Commons Clause removes one right: you may not sell the engine or offer it as a paid or hosted service. It is not an OSI open-source license. See `LICENSE.md`.

(Keep the "Operational graduation is the licensor's service" bullet as-is.)
