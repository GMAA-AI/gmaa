# READ FIRST, then deploy · GMAA · 2026-08-11

Read these before touching either deploy zip. Order:

1. **MANIFEST.md** - what every zip and folder is, and the deploy-together rule.
2. **v1_6_public-transform_changelog.md** - what changed to make the v1.6 spec public
   (4 edits) + the 3 open canon items (the BRACKETED placeholder, drafting notes, the
   §5/§7.4 spool contradiction). RATIFY before deploying the spec anywhere.
3. **SHA256SUMS_spec-line-change.txt** - the manifest line change for the v1.6 PDF and
   the engine re-pin note (engine v2.5.3 still pins canon v1.5 until the next seal).
4. **README-license-bullet_SWAP.txt** - exact old->new for the repo README license bullet.
   Apply only when LICENSE.md swaps (counsel first; Commons Clause affiliate flag).
5. **GETTING-STARTED_chmod-changeset.md** - the one-time chmod step for the walkthrough.
   Independent of the license/spec work; apply any time.

Then:
- **DEPLOY_gmaa-site_2026-08-11.zip** -> gmaa.ai web root (7 pages + robots + llms + sitemap).
- **DEPLOY_gmaa-repo_2026-08-11.zip** -> github.com/gmaa-ai/gmaa (LICENSE.md via counsel;
  the two spec files land at canon/).
- Both deploys land TOGETHER: the pages link the v1.6 PDF path and state the new license.
