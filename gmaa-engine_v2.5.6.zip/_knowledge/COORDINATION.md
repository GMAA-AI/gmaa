# COORDINATION.md — repo-as-shared-truth protocol
#
# GENERICIZATION NOTE: origin executor-lane seat renamed to generic `executor`; sequential
# multi-pass executor renamed to `dispatch-executor`; parallel build worker renamed to
# `build-worker`; origin project name replaced with `{{PROJECT_NAME}}`/generic wording;
# module lane example names replaced with `{{MODULE_LANE}}`/`module-a`/`module-b`;
# real dates used as live pointers replaced with `<date>`; real git SHAs replaced with `<sha>`;
# origin-specific ruling/issue citations replaced with rule-stated equivalents; operator UPN
# and domain names removed. Protocol mechanics (§3 read-first, §11 parallel-spawn,
# §13 cold-boot/spine-write/push-at-close, hub-and-spoke routing, inbox/outbox) KEPT verbatim
# in shape. ADDED: "Module↔Foundation asymmetry (invariant)" section with 7-axis table
# per operator direction.

**Author:** Product Architect
**Date:** <date>
**Status:** v1.0 — operator binds
**Companion:** `SYSTEM_ARCHITECTURE` (carries a pointer to this doc; this doc is authoritative for coordination)

---

## §0 — Why

Coordination friction this engine has encountered — stale premises (a session read an old HEAD while
the current HEAD had advanced), dropped/unconfirmed relays, surface double-assignment, silent
supersession (the implementer improved on relays and the authors never learned), and bundle drift —
all have **one root cause**: point-to-point relays carried through a human bus, with no shared
canonical state. The fix is **repo-as-shared-truth**, which works *because* all resources already
read the repo. This protocol is enforcement + consolidation of artifacts that already exist
(`STATE.md`, the decision queue, `dispatch/`). It deliberately does **not** make the architect a
coordination hub — `foundation` remains coordination authority.

---

## §1 — Resources & lanes (one-owner-per-surface)

> **SUPERSEDED-BY-§7** (amendment per view/data-seam contract §14).
> The lane shapes below are PRE-SEAM. Post-seam (Phase B onward) the lanes
> bifurcate `src/*` per VIEW/DATA boundary: `designer` owns view (`screens/*`,
> `components/*`); `foundation` owns data (`services/*`); architect ratifies
> typed interface shape at the seam. See §7 for the post-seam restatement.
> The §1 tables below are RETAINED AS HISTORICAL ANCHOR for the pre-seam
> wholesale-vendor workflow context.

| Resource | Owns | Repo access |
|---|---|---|
| **Operator** | Binds all decisions; apex authority | Read + push |
| **Architect** | Contracts, invariants, acceptance specs, verify-gates, architecture/flow decisions, cross-track de-confliction | **Read only** (via project knowledge search); writes route through foundation |
| **foundation** | Coordination authority + **canonical committer**; repo/DB/integrations; executes, dispatches workers, runs probes | Read + write (native git) |
| **designer** | Code App UI (`.tsx/.jsx`, manifest); forward-looking screen design | **Read only** (GitHub); outputs committed by foundation / operator-vendored |
| **cowork** | Live/UAT validation against the deployed app; issue filing from live | Read; outputs committed by foundation / operator |
| **code-Auditor** | Post-commit, observe-only; reproduces probes; checks state/log freshness (§5) | Read |

**One-owner-per-surface rule** — a given file belongs to exactly one lane:

| Surface | Owning lane |
|---|---|
| UI files (`.tsx/.jsx`), `manifest/datasources.json` | designer (PRE-SEAM; see §7 for post-seam VIEW/DATA bifurcation) |
| migrations, sprocs, execution functions, probes | foundation / code |
| contracts, invariants, acceptance specs, architecture docs | architect |
| UAT closeouts, live-surfaced issues | cowork |
| `STATE.md`, the decision-log | foundation (sole writer) |

Cross-lane needs (one lane consuming another's output) trigger the freshness guard (§4.3). This rule
prevents surface double-assignment: a `.tsx` file is designer's; a stored procedure or migration is
foundation's. **Post-seam (§7):** `src/services/*` is foundation-owned (data layer);
`src/screens/*` + `src/components/*` are designer-owned (view layer) — same one-owner principle
applied at finer granularity.

---

### §1.X — Designer read lane [addendum]

**Designer READ:** local live tip (`local_ls` / `read` / `grep` against the project working tree).
**Fallback** for files not in the local working state (stash entries, worktrees, etc.): read from
the version-control remote.

**Designer WRITE:** unchanged — routes through foundation commit (per §2 transport clause; designer
cannot push to git).

**Why this matters (cuts supersession churn):** with live read, designer relays REFERENCE landed
live mechanisms rather than authoring competing prototypes. The worked example: had designer read
the live reference set BEFORE drafting a relay list, a count mismatch wouldn't have occurred and
foundation's prior response wouldn't have propagated it.

## §2 — Read/write model

- **READ — all resources, via the repo.** designer (remote), architect (project knowledge search),
  foundation (native), cowork (checkout). The repo is the shared surface; coordination lives there,
  not in the operator's inbox.
- **WRITE — foundation is the canonical committer.** Architect, designer, and cowork have no commit
  access, so their outputs route **to foundation** (via the operator) for commit. The operator may
  push directly. Single-writer `STATE.md` + decision-log ⇒ no write contention.

---

### §2.X — Designer & Cowork → repo transport [BINDING]

> **SUPERSEDED-BY-§8** (amendment per view/data-seam contract §14).
> The wholesale-vendor workflow described below is RETIRED for designer-track
> work. Phase B onward (post-seam) designer authors data-agnostic `.tsx`
> directly in the live repo's component tree; foundation MERGES (not vendors-
> wholesale-then-rewrites) per §8 view-layer merge workflow. The last wholesale-
> vendor instance was the §15 surgical-port work package. The bundle-freshness-check
> guidance below still applies to pre-Phase-B legacy bundles archived in `dispatch/`;
> Phase B view-layer transport routes through §8. Cowork transport
> (UAT close-outs + ISSUE files) UNCHANGED below.

Designer and cowork outputs cannot be pushed to git by the source agent (they lack write access
to the repo). **foundation is the canonical vendoring agent:** foundation reads each handoff
bundle, vendors the changed files into the project at the documented paths, commits + pushes to
origin/main.

**foundation owns** *vendor-on-change* (act when a new bundle / new relay drops) *+
freshness-marker check* (§4.3) — never lift a stale bundle.

**Freshness check before any vendor:**
1. Bundle mtime vs latest designer relay mtime (most recent designer relay referenced files in
   the bundle ⇒ vendor; bundle older than relays ⇒ HALT-AND-SURFACE for fresh bundle).
2. For port work packages that lift `source/*`: check most-recent N=3 designer relays for the
   same surface before authoring.

If any designer/cowork handoff location is NOT readable by foundation, foundation HALT-AND-SURFACES
so the operator drops it once at a reachable repo path.


## §3 — Canonical surfaces (read-first)

1. **`STATE.md`** (foundation-written; the existing foundation-authoritative-writer contract). Pins
   **current HEAD SHA** + **deployed SHA**. Updated on every state transition. This is the
   anti-stale-premise surface — read it FIRST; if your local read lags the pinned SHA, re-sync
   before acting.
2. **Decision-log** (foundation-maintained; `_orchestration/decision-log.md`). One line per
   cross-agent ask:
   `id | from→to | ask | owner | STATUS ∈ {OPEN, ACTED, SUPERSEDED, CLOSED} | note`
   The **feedback edge** is the part that was missing: when an implementer takes a better path
   than a relay prescribed, they mark that relay **SUPERSEDED + one-line why** — closing the loop
   to the author instead of going dark.
3. **Lane table** (§1 of this doc).

One log, not dozens of `dispatch/` files a reader's tool truncates.

---

## §4 — Protocols

1. **Read-first.** Read `STATE.md` (+ relevant contracts) before acting. Treat a read older than
   the pinned HEAD SHA as stale.
2. **Relay → logged.** Every cross-agent ask gets a decision-log line with a STATUS. Supersession
   is explicit (§3.2), never silent.
3. **Freshness guard.** Before lifting another lane's output (port/vendor), check its version
   marker / SHA. No porting behind the author's current state (the bundle-drift fix).
4. **One-owner-per-surface** (§1).
5. **Altitude (the recalibration).** Architect specifies *contract, invariant, acceptance,
   verify-gates, architecture* — **not** implementation mechanism. The implementer, with live
   context, owns mechanism and is free to improve on it (marking the relay SUPERSEDED per §3.2).
   designer shifts toward forward-looking surfaces. Constraints (LIVE-DATA-ONLY, sproc-only,
   source-of-truth) are *not* mechanism and remain binding.

---

## §5 — Self-enforcement

The auditor already catches `STATE.md`-propagation misses but they may sit PENDING. Wire a
standing check into the auditor runlist: **a state-changing commit that doesn't update `STATE.md`
(and the decision-log, where a relay status changed) is flagged loud at commit.** This turns
recurring propagation misses from PENDING findings into a blocking gate — the protocol holds
itself up instead of relying on memory.

---

## §6 — Operator role

The operator **binds decisions** (the things only the operator can bind) and steps out of being
the **transport layer** for routine state — which now lives in the repo. The operator still
carries architect↔foundation and designer→foundation where a committer is needed, and stays in
the loop for urgent or ambiguous routing. Fewer paste-carries, same authority.

---

*Repo-as-shared-truth coordination protocol. Leans on existing artifacts; foundation is the
single committer (designer + architect + cowork are read-mostly, writes routed through
foundation). Operator binds.*

### §4.3.X — Designer = freshness-marker authority [addendum]

**Designer is the freshness-marker authority.** Designer DIFFs the handoff bundle against live
`src/*` (via their local read lane, §1.X) AND advances the marker when the bundle reflects the
current `src/*` state.

**foundation vendors on that marker** — foundation reads the marker via the bundle's header /
manifest / changelog stamp; if the marker indicates the bundle is ahead of live src/*, foundation
vendors; if behind, foundation HALT-AND-SURFACES per §4.3 freshness check.

This places the freshness judgment with the agent who knows whether the bundle's authored intent
reflects what landed live — designer's judgment, not foundation's bundle-mtime heuristic.


---

# AMENDMENTS PER view/data-seam contract §14 + POST-CONTRACT RULINGS

**Authority:** `contracts/view/data-seam-CONTRACT.md` §14 (amendment authority) + architect relay
(DISC-SEAM-COORD-01).

The view/data seam contract replaces the prototype → hand-port → wholesale-vendor pipeline. These
amendments fold the new model into COORDINATION.md. Where this section conflicts with §1–§6 above,
this section governs (Phase B onward); earlier sections retain historical anchor for pre-seam
workflow.

---

## §7 — Lanes (restate per view/data-seam contract §14)

> **GENERICIZATION NOTE:** this section carries the origin's VIEW/DATA-seam pattern (a designer lane authoring
> data-agnostic UI against a typed service interface). It is an ORIGIN PATTERN, retained as a worked example of
> one-owner-per-surface; the referenced `contracts/view/data-seam-CONTRACT.md` and `src/**` are not shipped. An
> adopter without that seam replaces this section with its own surface map or leaves it inert.

| Lane | Owns | Surface |
|---|---|---|
| **designer = VIEW** | Data-agnostic `.tsx` components authored **directly in the live repo's component tree**. Codes against the typed service interface only — no schema/sproc identifiers in components, no mock data baked in components, no direct `fetch` / generated-service imports | `src/screens/**/*.tsx`, `src/components/**/*.tsx` |
| **foundation = DATA** | Typed service interfaces (`src/services/interfaces/I*.ts`) + live + mock impls + `ServiceProvider` + `ServiceContext` + connection config; sole git committer | `src/services/**`, migrations, sprocs, execution functions, probes |
| **architect = CONTRACT + ACCEPTANCE** | Ratifies typed service interface shape at the seam; ratifies architecture decisions; standing probes encode binding directives (replaces per-instance prose rulings) | `contracts/*`, ratification relays |

The lane shapes from §1 above are subsumed into these three at the seam. designer no longer authors
prototype bundles — they author live `.tsx` against the typed service interface. foundation no longer
"vendors wholesale" — foundation merges component files (which already match live patterns).

---

## §8 — Transport (replace §2 + §2.X vendor-wholesale workflow)

**STRIKE:** "operator drops designer batches → foundation commits (vendor wholesale)" (the §2.X
workflow above; the last instance of the wholesale-vendor pattern is now retired).

**REPLACE with view-layer merge workflow** (per view/data-seam §8):

1. Designer authors data-agnostic `.tsx` directly in the live repo's component tree
2. Operator transports designer output to foundation (designer cannot push directly; this routing
   is unchanged)
3. foundation **merges** component files — view-layer merge, not rewrite. foundation confirms
   standing probes P1-P5 pass; commits.
4. Deploy when the surface is release-ready

Wholesale vendoring of competing prototype projects is **retired**. The prototype sandbox does
not exist post-seam; designer's prototype IS the live `.tsx`.

The §2.X "freshness check before any vendor" guidance still applies to pre-Phase-B legacy bundles
in `dispatch/` (archived as historical artifacts); not to view-layer merge flow.

---

## §9 — Typed service interface as cross-lane contract (NEW per view/data-seam §4)

> **GENERICIZATION NOTE:** this section carries the origin's VIEW/DATA-seam pattern (a designer lane authoring
> data-agnostic UI against a typed service interface). It is an ORIGIN PATTERN, retained as a worked example of
> one-owner-per-surface; the referenced `contracts/view/data-seam-CONTRACT.md` and `src/**` are not shipped. An
> adopter without that seam replaces this section with its own surface map or leaves it inert.

The **typed service interface IS the cross-lane contract between view and data.**

- Designer codes against the interface
- foundation owns the interface (lives in `src/services/interfaces/I*.ts`)
- Architect ratifies the interface shape via the data-shape ask path
- Data shape changes are interface amendments owned by foundation, ratified by architect —
  **never improvised in the view layer**

**Per-surface rule:** the typed service interface + mock impl MUST exist before designer authors
against that surface. If absent, designer issues a **data-shape ask** to foundation (concrete
proposal); foundation synthesizes; architect ratifies the resulting interface shape; foundation
fulfills (authors interface + mock + live + extends ServiceProvider); then designer authors view
against it.

---

## §10 — Auditor standing-probe set (per view/data-seam §9)

> **GENERICIZATION NOTE:** this section carries the origin's VIEW/DATA-seam pattern (a designer lane authoring
> data-agnostic UI against a typed service interface). It is an ORIGIN PATTERN, retained as a worked example of
> one-owner-per-surface; the referenced `contracts/view/data-seam-CONTRACT.md` and `src/**` are not shipped. An
> adopter without that seam replaces this section with its own surface map or leaves it inert.

Standing probes fire on every commit (auditor-driven; per `agents/standing-probes.yaml`):

| Probe | Asserts |
|---|---|
| **P1 no-mock-in-view** | No `MOCK_*` / sample-data literals in component files |
| **P2 no-schema-in-view** | No schema-namespace identifiers in components (binary: includes JSX text + tooltips, not only code paths) |
| **P3 no-sproc-in-view** | No stored-procedure identifiers in components (binary, same as P2) |
| **P4 no-direct-data** | No `fetch` / HTTP / connector imports in components; service-interface imports only |
| **P5 states-present** | Each data-bound component handles loading / empty / error as first-class states |

**Phase B `partial_fail_window`** is tolerated for not-yet-migrated legacy surfaces
(`PHASE_B_LEGACY_SCREEN violation_class` per `agents/standing-probes.yaml`). The window closes
per surface as Phase B-N migrates that surface to data-agnostic form. When the surface lands
data-agnostic + probe-clean, the window reduces by the count cleared.

---

## §11 — Wide-go-3-tracks parallel-spawn pattern

**Disjoint-scope parallel spawning needs no per-spawn ratify.** Three tracks can spawn in parallel
when file scope is provably disjoint:

> **Extended by §13(4):** disjointness is judged on TWO surfaces — code scope AND spine-write
> target — not file scope alone. The §11 parallel-spawn pattern is otherwise unchanged.

| Track | File scope |
|---|---|
| **Substrate / backend** | execution functions, migrations, probes |
| **View layer** | `src/services/**`, `src/screens/**`, `src/components/**` |
| **Data-layer / docs** | `contracts/**`, `_knowledge/**` |

**Architectural ceiling: 1 UI worker + 1 SQL worker + 1 docs worker** = 3 parallel. UI workers
cannot truly parallelize at the worker level due to shared `src/services/ServiceContext.tsx` +
`ServiceProvider.tsx` + `index.ts` registration (each Phase B-N worker extends those three files;
parallel UI workers would conflict). SQL workers operate on separate migration + probe files. Docs
workers operate on `.md` files.

When a track lands, the next worker in queue may spawn. Worked example: a wide-go batch with
Settings + event-extension + coord-amendment = 3 parallel; all 3 disjoint.

---

## §12 — Cross-references

- `contracts/view/data-seam-CONTRACT.md` §14 (amendment authority) + §8 (view-layer merge) +
  §9 (P1-P5 probes) + §4 (typed interface as contract)
- `agents/standing-probes.yaml` (P1-P5 live wiring)
- The last wholesale-vendor instance (pattern retired post that work package)
- Per-surface data-shape ask precedent (Phase B-1 Dashboard)
- Phase B-N pattern instances (Phase B-2a Performance, B-2b Settings)
- Architect relay (DISC-SEAM-COORD-01 amendment spec)

---

## §13 — Integrator operating clauses

**Authority:** architect ruling; ratified via §11 chain. Extends §1 one-owner-per-surface to the
full spine; consistent with §7 post-seam lanes.

**(1) Spine + single writer:**
- Spine = integration trunk, the one database, the append-only receipts ledger, the work-package
  DAG, `issues_register.md`, `CHECKLIST.md`, the frozen contracts, `_orchestration/STATE.md` +
  the decision-log. Read by all lanes; written only by the integrator.
- **Shared substrate enforcement:** the integrator-owned write set is the spine above PLUS `sql/`
  + `migrations/` ("the one database") + `agents/` + `scripts/` + `skill/` + `src/`
  (foundation-owned shared substrate). The D3 pre-commit gate (`agents/pre-commit-hook.sh`,
  consuming `scripts/resolve-lane.sh`) fail-closed REJECTS any module-branch commit to a spine OR
  shared-substrate path; module-authored content to any of them is a PROPOSAL to the integrator
  via reap-at-merge, never a module spine-write. Decisive rationale for the substrate inclusion:
  `scripts/resolve-lane.sh` and the hooks live under `scripts/`/`agents/` — a module-writable
  enforcement layer would be a guard able to disable its own guard; `skill/` makes the
  version-control home spine-protected the moment it exists.
- Foundation = sole integrator and sole committer to the spine. Architect, designer, cowork read
  and propose; never commit. Frozen-contract changes need architect ratification, then the
  integrator commits.
- Monotonic issue counter, single ledger append, single DAG update are safe by construction:
  exactly one writer.

**(2) Per-track boot context:**
- Identity bootstraps from LOCATION, not from chat. Foundation provisions each lane's stamped
  `_boot/BOOTSTRAP.md` at a fixed worktree-relative path before the seat boots, and records the
  lane in the spine manifest `_orchestration/lane-provisioning.md` {lane, branch, bootstrap_version,
  `git hash-object` blob, provisioned_utc}.
- A cold seat's FIRST action resolves its lane from its OWN worktree (`scripts/resolve-lane.sh`:
  worktree-root → `_boot/BOOTSTRAP.md` → stamped lane), adopts that identity, and emits
  `BOOT-ACK: lane=… version=… blob=…`. It never infers identity from chat and never inherits the
  generic contract as foundation.
- The resolver cross-checks the stamped `lane` against the worktree's FOLDER name (folder-equals-lane;
  the resolver is authoritative); mismatch = HALT. Location and stamp mutually confirm. (An adopter MAY
  layer a stamp-vs-branch cross-check as optional hardening, as the reference instantiation does.)
- No `_boot/BOOTSTRAP.md` at the fixed path → HALT (do not guess; do not assume
  integrator/foundation).
- A module lane acts ONLY on its own `_boot/BOOTSTRAP.md` (`spine_write: DENY`), commits only to
  its own worktree branch, and never applies to the spine.
- `_boot/**` is lane-provisioning metadata, NOT module work-product → integration-EXCLUDED. The
  one shared post-commit hook resolves the committing LANE via the same resolver against the
  committing-worktree root (never trunk/cwd), so it stamps each lane's audit record with that
  lane's identity.

**(3) Merge-order:**
- The integrator merges module work into the spine in CHECKLIST dependency order; foundation
  changes land before the site work that depends on them. Gate per item, not per tier.
- **Only RATIFIED members merge (canon §4):** a module branch reaches the trunk ONLY inside a
  RATIFIED set naming its lane (`scripts/reap_at_merge.sh`, M6(ii) NO-CHERRY-PICK — a non-member
  branch HALTs before the merge tree is computed). RETURNED/unratified content re-enters main only
  inside a future ratified set.

**(4) Integrator validation gate:**
- Disjointness is judged on TWO surfaces: code scope AND spine-write target. Fan out to parallel-
  validate subagents only when both are provably disjoint; otherwise serialize. Validation
  parallel, commit always serial. Subagents return results; the integrator unions the ledger in
  one append, applies migrations in dependency order, updates the DAG once. Default to serial
  whenever disjointness cannot be proven.
- **The validation gate CITES THE SET:** the merge carries the canon §4 receipt line verbatim —
  `member <lane> evaluated against the set {SET-NNNN}: joint edges = <list|NONE>`
  (`reap_at_merge.sh` writes it into the merge commit) — so every merge names the set that
  authorized it, auditable on main.

> **§13(4) ↔ §11 cross-ref:** §13(4) EXTENDS the §11 (above) disjoint-scope test to TWO
> surfaces (code scope AND spine-write target). The §11 parallel-spawn pattern is otherwise
> unchanged.

**(5) Push-at-close — origin durability:**
- Integrator duty = commit AND keep origin current. **"landed + sealed" means origin-durable,
  not local-only.** Root cause: a commit/seal/reap cadence with NO push step leaves origin
  sitting behind, pinned at an earlier state. The fix folds push INTO the close.
- The shared post-commit hook (`agents/post-commit-hook.sh`) performs a plain fast-forward
  `git push origin <branch>` at the close of every non-`[audit]` commit: **foundation** pushes
  `main` after the reap-seal; a **module** lane pushes its own `module/<x>` branch after the
  marker. Each sealed/marked unit is a clean fast-forwardable checkpoint.
- **NEVER `--force` in the cadence.** A non-fast-forward push failure is a STOP-and-surface
  event (history divergence = a merge/reconcile decision), not a retry and never a force.
- Push is **best-effort**: a landed commit cannot be unwound, so a failed push (network / non-ff)
  warns loud (does NOT fail the hook, does NOT unwind the commit) and is caught by the local-
  ahead-of-origin **drift surface** (standing probe flags `origin/main..main` > N at close) —
  never silently swallowed.
- The **terminal flush** (end-of-run / next-session start) seals AND pushes the last trailing
  unit (whose audit completes after its own commit's hook already ran).

---

## §14 — Durable end-of-run + on-idle relay

**Rationale:** tmux panes are ephemeral; reading-the-pane is a lossy, screenshot-mediated
transport. Every foundation turn ends with a **DURABLE relay FILE** so the operator (and later
an app surface) grabs a file, never the pane.

**TRIGGER — end of EVERY foundation run/turn, work OR idle. No turn ends without a written
relay.**
No-fake-closure tie-in: the run-end file **IS the run's status-of-record**; a run with no relay
file is an **INCOMPLETE run** — same class as a payload written but never committed.
- **WORK turn** → full relay: `FROM/TO/RE` + status + any chat-bound relays + **evidence inline**
  (commit shas, receipt ids). Same format as the fenced paste-blocks.
- **IDLE turn** (nothing queued) → idle heartbeat: `FROM/TO/RE` + `STATUS: IDLE` + last-completed
  + what it's waiting on + `nothing queued`. Liveness signal — an idle foundation is never silent
  (halt-loud analog: silent-idle is indistinguishable from stuck/dead).

**PATHS**
- `dispatch/LATEST.md` — ALWAYS the newest relay (stable path; the one place operator/app grabs).
- `dispatch/RELAY-TO-ARCHITECT-<UTC>-<slug>.md` — timestamped archive for history (work turns).

**MECHANICS (edge-triggered; COST-GUARD — no idle write-spam)**
- Exactly **ONE write per turn-end**. NOT a polling loop, NOT a re-fire while idle — one beat on
  *entering* idle, never a heartbeat loop.
- **Work turn:** write the timestamped archive + copy it to `LATEST.md`; **commit both with the
  run** (origin-durable, rides §13(5) push-at-close).
- **Idle beat (foundation's chosen mechanic):** update `dispatch/LATEST.md` **ONLY, worktree-
  local (uncommitted)** — swept into the next work-turn commit. No commit-per-beat (avoids a
  commit flood + idle-write-spam per COST-GUARD). The operator/app reads the working-tree
  `LATEST.md`, current even when uncommitted; origin-durability follows on the next work commit.

---

## Module↔Foundation asymmetry (invariant)

The engine is deliberately **ASYMMETRIC** between the integrator lane (`foundation`) and module
lanes. An adopter MUST NOT symmetrize it. The asymmetry is load-bearing: it is what makes
single-writer spine guarantees, append-only ledgers, and per-lane audit isolation possible
simultaneously. Collapsing the asymmetry destroys these properties.

| Axis | Foundation (integrator) | Module lane |
|---|---|---|
| **Spine write** | ALLOW — sole spine committer | DENY — own branch only; PROPOSE via reap-at-merge |
| **Audit / commit** | reap-then-audit + `[audit]` seal + background Auditor every commit | marker-only + push; NO module-side audit record; re-audited AT MERGE by foundation |
| **Relay routing** | router HUB — fans out to modules + collects surfaces; hub-and-spoke | surfaces UP to foundation only; NEVER carries a relay to the operator directly |
| **Inbox / outbox** | HAS an inbox (`_orchestration/relay-inbox/foundation/`) for operator/ferry/spoke-directed inbound + the doorbell wake namespace; sole inbox writer for every lane. Module spokes are spine-write=DENY so they cannot commit INTO it — the hub ALSO reaps module OUTBOXes cross-branch each turn (additional payload channel, not a replacement). | HAS an inbox (read cross-branch; foundation is the sole inbox writer); writes OUTBOX on own branch (integration-excluded) |
| **Per-turn INBOX-CHECK** | OBLIGATORY — the hub reads its own inbox (`_orchestration/relay-inbox/foundation/`) AND reaps module OUTBOXes each turn; the doorbell is bidirectional (spokes ring the hub) | OBLIGATORY first-action every turn — read the inbox before any other action |
| **Doorbell producer-ring** | AUTO-FIRES on inbox-commit (sole inbox writer = auto-fires on every module-lane write) | rings its counterpart via surface/outbox |
| **Currency-sync** | pushes trunk (§13(5) push-at-close) | ADOPTS-from-trunk (R1, byte-identical spine) — never diverges from trunk on spine paths |

The carrying components for each axis are: `scripts/resolve-lane.sh` (authority class — spine_write
flag per lane); `agents/pre-commit-hook.sh` + `agents/post-commit-hook.sh` (D3 spine-write
enforcement + push-at-close); the `orc` agent definition (ROUTING hub + per-turn INBOX-CHECK
obligation); `scripts/inbox.sh` (cross-branch inbox read); and the reaper (reap-at-merge, the
sole path by which module work enters the spine).

**A symmetric collapse (foundation gains an inbox, or a module self-audits / self-commits spine)
is a defect.** If you observe either: file it immediately; do not work around it.

---

*Amendments authored by foundation per architect direct-edit authorization. Original §0–§6
retained as historical anchor for pre-seam workflow context. §13 authored by integrator per
architect-ratified clause (verbatim shape). §14 authored by integrator per operator-directed +
architect-ratified durable-relay ruling.*
