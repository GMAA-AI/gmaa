#!/usr/bin/env bash
# scripts/declared-spine-paths.sh — emit the adopter's DECLARED extra spine paths (the
# {{PROJECT_SPINE_PATHS}} fill), one per line. r4 §2.11: the set gate + joint-edge + module-DENY key
# on the adopter's declared spine set + the engine base set, never the base census alone.
#
# HEAD-READBACK (architect ruling 2026-08-17, ruling #2): read the SPINE copy at HEAD
# (`git show HEAD:seats.yaml`), NEVER the lane-local working tree — a lane that forged its own roster
# must not be able to widen its own exemptions. Same rule the ledger obeys. seats.yaml is itself
# spine-owned (module-DENY) so a module cannot author it; reading at HEAD closes the uncommitted hole.
#
# Source of the declared set: the `spine_paths:` YAML list in seats.yaml. Empty (silent) when there is
# no seats.yaml at HEAD or no spine_paths block — the blank engine then gates on the base set alone.
set -u
root="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
git -C "$root" show HEAD:seats.yaml 2>/dev/null | awk '
  /^spine_paths:[[:space:]]*$/ { inb=1; next }
  inb && /^[^[:space:]#-]/ { inb=0 }                       # a dedented key ends the block
  inb && /^[[:space:]]*-[[:space:]]/ {
      s=$0; sub(/^[[:space:]]*-[[:space:]]*/,"",s)          # strip the "- " list marker
      sub(/[[:space:]]*#.*$/,"",s)                          # strip trailing comment
      gsub(/^[ \t]+|[ \t]+$/,"",s); gsub(/^["'\'']|["'\'']$/,"",s)  # trim + unquote
      if (s != "") print s
  }'
exit 0
