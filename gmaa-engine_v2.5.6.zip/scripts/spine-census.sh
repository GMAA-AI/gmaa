#!/usr/bin/env bash
# scripts/spine-census.sh — THE single authoritative spine-census emitter (one path per line).
#
# ISSUE-1 FIX (v2.5.6): every spine-enforcement consumer reads its census FROM HERE. Before this the
# census was hand-copied into each gate (pre-commit SPINE_PATHS · reap_at_merge SPINE_RE · ratify
# SPINE_PREFIXES · probe_state_propagation SPINE_RE) and the copies DRIFTED — reap's stale copy did not
# recognise the set-authorization machinery's OWN files (PENDING-SET.md, _ratification/, SLOTS.md,
# seats.yaml, launch-orc.sh, .claude/settings.json, _orchestration/lane-provisioning.md), so a module
# reaching the merge with them was caught at pre-commit but NOT at the merge-time backstop. That is
# MAINTAINED-STATE DRIFT (canon Appendix A) — the exact class the architecture cures by "generate, not
# maintain." The cure is ONE emitter; a standing parity probe (probes/foundation/probe_census_parity.sh)
# FAILS if any enforcement file reintroduces its own census literal.
#
# Emits, deterministically: the engine BASE spine set (§13(1)) — governance rationale inline, this file
# is its single home — THEN the adopter's DECLARED set (scripts/declared-spine-paths.sh, HEAD-readback of
# seats.yaml `spine_paths:`, ruling #2). Consumers keep their OWN per-gate matching/exemption logic; only
# the census SOURCE is shared. Portable to the bash 3.2 floor (no mapfile/readarray): consumers read this
# with `while IFS= read -r`.
set -u
_e(){ printf '%s\n' "$1"; }

# --- engine base spine (COORDINATION.md §13(1)); prefix (trailing /) or exact file ---
_e "ledger/"
_e "dag/"
_e "issues_register.md"
_e "CHECKLIST.md"
_e "SLOTS.md"                              # adopter slot inventory (r4 §2.9): module-DENY so the engine-update classifier's SLOT-FILL truth can't be forged
_e "contracts/"
_e "PENDING-SET.md"                        # set-auth (canon §4) pending-set ledger — foundation-owned; members reach it only via `pending-set.sh reap`
_e "_ratification/"                        # ratification packets — foundation-owned
_e "dispatch/LATEST.md"                    # foundation resume pointer (the rest of dispatch/ stays module-writable relays)
_e "_orchestration/decision-log.md"
_e "_orchestration/lane-provisioning.md"   # adopt-from-trunk ref source; module-editable would subvert the adopt-check
_e "seats.yaml"                            # adopter roster + declared spine — module-DENY (ruling #2); architect-ruled set-gated 2026-08-17
_e "sql/"                                  # adopter DB stack (C-DB SLOT) — no-op in the base engine
_e "migrations/"
_e "agents/"                               # hooks + enforcement layer — module-writable = a guard that could disable its own guard
_e "scripts/"
_e "launch-orc.sh"                         # r4 §2.7 — a module must not edit its own launcher/hook/skeleton guards
_e "skill/"
_e ".claude/agents/"                       # role-neutral persona defs — foundation-owned; closes the module self-tamper surface
_e ".claude/settings.json"                 # shared permission allow-list — a module cannot widen its own permissions

# --- adopter DECLARED spine (HEAD-readback of seats.yaml spine_paths:, ruling #2). Blank engine → nothing. ---
root="$(git rev-parse --show-toplevel 2>/dev/null || true)"
[ -n "$root" ] && [ -x "$root/scripts/declared-spine-paths.sh" ] && "$root/scripts/declared-spine-paths.sh" 2>/dev/null
exit 0
