#!/usr/bin/env python3
"""scripts/receipt-ledger.py — the receipt single-allocator + uniqueness verifier (§2.15/§2.16).

The engine's receipt id had NO real uniqueness: the ref-impl built `R-<ts>-REF` (same-second
emissions collided by construction) and the origin per-run seq reset each run. This is the one
allocator that fixes it, applied by three seats:

  canonicalize <repo_root>
      Foundation, AT REAP (called by scripts/reap_at_merge.sh on the executor apply-receipt path).
      Lane receipts arrive with a PROVISIONAL id (`R-<utc>-<lane>-<nonce>`, provisional=true).
      This assigns the CANONICAL sequential id — the SINGLE ALLOCATOR — rewrites each row in place
      (receipt_id -> canonical, provisional -> false, preserves the provisional id + adds seq), and
      HALTs (exit 3) on any duplicate canonical id whose content_sha differs (a collision is NEVER
      silently renumbered). Same id + same content_sha = idempotent replay (tolerated: a re-reap of
      already-canonical rows is a no-op).

  check-unique <repo_root> [receipt_id ...]
      ratify.sh (before the pen stamps) and probes/foundation/probe_set_gate.sh (standing mirror).
      Verifies that every receipt is UNIQUE in the spine ledger by (receipt_id, content_sha): one
      row cannot discharge on another's receipt. With ids given, restricts the collision report to
      those (a member's cited evidence receipts). exit 1 on a collision, 0 clean, 2 run-error.
      No-op PASS when no ledger is wired (adopter has not stood up ledger/**).

Uniqueness key is (receipt_id, content_sha) — a duplicate id with the SAME content is the same
receipt (tolerated); a duplicate id with DIFFERING content is a collision (rejected). Ledger scanned:
ledger/receipts.jsonl + ledger/apply-receipts/**/*.jsonl.
"""
import sys, os, json, glob
from datetime import datetime, timezone


class LedgerCorruption(Exception):
    """ISSUE-3 FIX (v2.5.6): a ledger line is present but not parseable JSON (and is not blank/comment)
    — a defect surfaced, NEVER skipped. Silently skipping it (the prior `except: continue`) hid a
    collision or forged row from both check-unique and canonicalize (fail-OPEN); halting is the engine's
    universal invariant #5 (HALT-LOUD-OVER-SILENT-DEGRADATION) in the receipt-id mechanism."""
    def __init__(self, path, lineno):
        self.path = path
        self.lineno = lineno
        super().__init__("malformed JSON at %s:%d" % (path, lineno))


def _rows(paths):
    """Yield (path, lineno, obj) for every JSON-object line; skips blank/comment; HALTs on malformed.
    ISSUE-3 FIX (v2.5.6): a non-blank, non-comment line that will not parse raises LedgerCorruption
    (was silently skipped) — a corrupt line was invisible to check-unique AND to canonicalize's scan."""
    for p in paths:
        try:
            fh = open(p, "r")
        except OSError:
            continue
        with fh:
            for i, line in enumerate(fh, 1):
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                try:
                    obj = json.loads(s)
                except json.JSONDecodeError:
                    raise LedgerCorruption(p, i)
                if isinstance(obj, dict):
                    yield (p, i, obj)


def _is_canonical(obj):
    return obj.get("provisional", False) is False


def _content_sha(obj):
    return obj.get("content_sha", "")


def _collisions(objs, only_ids=None):
    """Return {receipt_id: sorted(set(content_sha))} for ids bound to >1 distinct content_sha."""
    by_id = {}
    want = set(only_ids) if only_ids else None
    for o in objs:
        rid = o.get("receipt_id")
        if rid is None:
            continue
        if want is not None and rid not in want:
            continue
        by_id.setdefault(rid, set()).add(_content_sha(o))
    return {rid: sorted(shas) for rid, shas in by_id.items() if len(shas) > 1}


def _apply_receipt_files(root):
    return sorted(glob.glob(os.path.join(root, "ledger", "apply-receipts", "**", "*.jsonl"), recursive=True))


def _ledger_files(root):
    files = _apply_receipt_files(root)
    top = os.path.join(root, "ledger", "receipts.jsonl")
    if os.path.exists(top):
        files.append(top)
    return files


def cmd_canonicalize(root):
    files = _apply_receipt_files(root)
    if not files:
        print("[receipt-ledger] canonicalize: no apply-receipts to canonicalize (no-op).")
        return 0

    # Global sequence continues from the max seq already assigned across every apply-receipt file
    # (single allocator, monotonic: two lanes' runs can never claim the same canonical id).
    max_seq = 0
    for _, _, o in _rows(files):
        if _is_canonical(o) and isinstance(o.get("seq"), int):
            max_seq = max(max_seq, o["seq"])

    reap_ts = os.environ.get("GMAA_REAP_TS") or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    nxt = max_seq + 1
    assigned = []

    # Rewrite provisional rows in place, file-by-file, preserving line order + non-row lines.
    for p in files:
        try:
            with open(p, "r") as fh:
                lines = fh.readlines()
        except OSError as e:
            print("[receipt-ledger] HALT: cannot read %s (%s)" % (p, e), file=sys.stderr)
            return 3
        dirty = False
        out = []
        for _ln, line in enumerate(lines, 1):
            s = line.strip()
            if not s or s.startswith("#"):
                out.append(line)
                continue
            try:
                obj = json.loads(s)
            except json.JSONDecodeError:
                # ISSUE-3 FIX (v2.5.6): HALT instead of passing a corrupt line through untouched — a
                # forged/collided row hidden in a malformed line must not survive canonicalization.
                print("[receipt-ledger] HALT: malformed JSON at %s:%d — a corrupt line in a foundation-owned "
                      "ledger is a defect surfaced, never skipped (invariant #5 HALT-LOUD-OVER-SILENT-DEGRADATION)."
                      % (p, _ln), file=sys.stderr)
                return 3
            if isinstance(obj, dict) and obj.get("provisional", False) is True:
                canonical_id = "R-%s-%06d" % (reap_ts, nxt)
                obj["provisional_id"] = obj.get("receipt_id")
                obj["receipt_id"] = canonical_id
                obj["provisional"] = False
                obj["seq"] = nxt
                assigned.append((obj["provisional_id"], canonical_id))
                nxt += 1
                dirty = True
                out.append(json.dumps(obj, separators=(",", ":")) + "\n")
            else:
                out.append(line)
        if dirty:
            tmp = p + ".tmp"
            try:
                with open(tmp, "w") as fh:
                    fh.writelines(out)
                os.replace(tmp, p)
            except OSError as e:
                print("[receipt-ledger] HALT: cannot rewrite %s (%s)" % (p, e), file=sys.stderr)
                return 3

    # Dup-guard over ALL canonical rows now present: any id -> >1 distinct content_sha = collision.
    canon = [o for _, _, o in _rows(files) if _is_canonical(o)]
    cols = _collisions(canon)
    if cols:
        print("[receipt-ledger] HALT: duplicate canonical receipt id(s) at reap — collision, NOT renumbered (§2.15):", file=sys.stderr)
        for rid, shas in sorted(cols.items()):
            print("  - %s  ->  %d distinct content_sha: %s" % (rid, len(shas), ", ".join(x[:12] for x in shas)), file=sys.stderr)
        return 3

    for prov, canonical in assigned:
        print("[receipt-ledger] canonical assigned: %s  <-  %s" % (canonical, prov))
    print("[receipt-ledger] canonicalize: %d provisional receipt(s) canonicalized; ledger id-unique." % len(assigned))
    return 0


def cmd_check_unique(root, only_ids):
    files = _ledger_files(root)
    if not files:
        print("[receipt-ledger] check-unique: no spine ledger wired (no-op PASS).")
        return 0
    objs = [o for _, _, o in _rows(files)]
    cols = _collisions(objs, only_ids or None)
    if cols:
        scope = ("cited " if only_ids else "")
        print("[receipt-ledger] FAIL: non-unique %sreceipt id(s) in the spine ledger — one row could discharge on another's receipt (§2.16):" % scope, file=sys.stderr)
        for rid, shas in sorted(cols.items()):
            print("  - %s  ->  %d distinct content_sha: %s" % (rid, len(shas), ", ".join(x[:12] for x in shas)), file=sys.stderr)
        return 1
    n = len(only_ids) if only_ids else len(set(o.get("receipt_id") for o in objs if o.get("receipt_id")))
    print("[receipt-ledger] check-unique PASS: %d receipt id(s) unique by (id, content_sha)." % n)
    return 0


def main(argv):
    if len(argv) < 3:
        print("usage: receipt-ledger.py {canonicalize <repo_root> | check-unique <repo_root> [receipt_id ...]}", file=sys.stderr)
        return 2
    verb, root = argv[1], argv[2]
    if not os.path.isdir(root):
        print("[receipt-ledger] RUN_ERROR: repo_root not a directory: %s" % root, file=sys.stderr)
        return 2
    try:
        if verb == "canonicalize":
            return cmd_canonicalize(root)
        if verb == "check-unique":
            return cmd_check_unique(root, argv[3:])
    except LedgerCorruption as e:
        # ISSUE-3 FIX (v2.5.6): a malformed ledger line surfaced by the reader (_rows) — HALT loud,
        # naming path + line, exit 3 (the file's fail-closed code). Never a silent skip.
        print("[receipt-ledger] HALT: %s — a corrupt line in a foundation-owned ledger is a defect "
              "surfaced, never skipped (invariant #5 HALT-LOUD-OVER-SILENT-DEGRADATION); exit 3." % e,
              file=sys.stderr)
        return 3
    print("[receipt-ledger] RUN_ERROR: unknown verb '%s'" % verb, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
