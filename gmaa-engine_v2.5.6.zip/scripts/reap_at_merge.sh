#!/usr/bin/env bash
# scripts/reap_at_merge.sh <module-lane|executor> — audit-at-merge.
#
# GENERICIZATION NOTE: mechanism unchanged; the execution seat is `executor` (its branch is
# `executor`), site-lane examples → generic, project ruling-numbers → rule-stated,
# `STATE.md`→`LATEST.md`, and the substrate guard now reads the SHARED spine census
# (scripts/spine-census.sh; adopters extend it via `seats.yaml spine_paths:`). Re-sourced at the
# source program's ENFORCED HEAD (2026-08-19 set-authorization CUT): + the forced-merge-path
# sentinel, + the exclude-residue worktree drop (hygiene fix), + the M6(ii) 5-state prefix-match
# note. v2.5.6 (Issue 1): retired the stale hand-maintained SPINE_RE for the shared census.
#
# FORCED MERGE-PATH (C-SET-AUTHORIZATION §2b): this is the ONLY sanctioned module→trunk merge
# route. It exports REAP_AT_MERGE=1 so a pre-merge-commit hook recognises it as sanctioned and
# lets it through, while a RAW `git merge` into the trunk (no sentinel) is REJECTED. The reap
# already uses `--no-commit` (so pre-merge-commit does not fire and pre-commit/M6(i) runs on the
# `git commit`); the sentinel is belt-and-suspenders for any future auto-committing refactor.
# HONEST-LABEL: the enforcing hook (agents/pre-merge-commit-hook.sh) is built + armed in the
# source program but is NOT shipped in this engine revision — the sentinel is exported so a tree
# that wires it recognises the sanctioned reap; without it the export is a harmless no-op.
#
# Integrator-only (foundation). Merges module/<lane> into the spine and lets the
# foundation post-commit hook RE-AUDIT the incoming module work at the merge point,
# emitting the lane-stamped [audit] seal on main. Single-writer literal: the
# integrator is the only committer of both the merge commit and the audit seal; the
# module produced no audit record (only a lane marker, per the lightened module path).
#
# Architect ruling ([C] = audit-at-merge): "the Auditor receipt licenses merge-to-main,
# and C produces that receipt at the merge, by the integrator."
#
# INTEGRATION-EXCLUSION (COORDINATION.md §13(2)): `_boot/**` is lane-provisioning
# metadata, NOT module work-product. A module branch's `_boot/BOOTSTRAP.md` carries
# its own lane stamp; it must NEVER overwrite main's foundation stamp. This script
# restores main's `_boot/**` after the merge tree is computed, unconditionally
# (whether git conflicted on it or silently took the module side).
#
# HALT-LOUD: any merge conflict OUTSIDE `_boot/**` aborts (does not smooth a partial
# merge into a pass) — surface it, fix in-iter.
set -u

export REAP_AT_MERGE=1

LANE_ARG="${1:?usage: reap_at_merge.sh <module-lane|executor>   (e.g. module-a, executor)}"
REPO_ROOT="$(git rev-parse --show-toplevel)"
cd "$REPO_ROOT" || { echo "HALT: cannot cd to repo root"; exit 1; }

# Assert integrator identity from LOCATION (must be the foundation worktree).
if ! LANE_LINE="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>&1)"; then
    echo "HALT: lane unresolved ($LANE_LINE) — reap-at-merge runs only on the foundation worktree."; exit 3
fi
eval "$LANE_LINE"
[[ "${lane:-}" == "foundation" ]] || { echo "HALT: reap-at-merge is integrator-only; this worktree is lane='${lane:-?}'."; exit 1; }
# Clean-tree precondition — but TOLERATE dirty ledger/: under reap-then-audit there is
# ALWAYS pending auditor output (the ≤1 trailing) until the next reap; the merge's OWN
# post-commit reap is what seals it, and the merge never touches ledger/. So block only
# on non-ledger uncommitted work.
DIRTY="$(git status --porcelain | cut -c4- | grep -v '^ledger/' || true)"
[[ -z "$DIRTY" ]] || { echo "HALT: working tree has non-ledger changes; refusing to merge."; echo "$DIRTY" | sed 's/^/  /'; exit 1; }

# executor (the execution seat): its branch is `executor`, NOT module/*, and its ONLY permitted
# spine output is ledger/apply-receipts/** (integration-INCLUDED — reaped here into the spine
# ledger; the ratified apply-receipts-only carve-out). Every other lane is module/<lane>.
if [[ "$LANE_ARG" == "executor" ]]; then
    BRANCH="executor"; IS_EXEC=1; WORK_KIND="apply-receipt"
else
    BRANCH="module/$LANE_ARG"; IS_EXEC=; WORK_KIND="module"
fi
git rev-parse --verify -q "$BRANCH" >/dev/null 2>&1 || { echo "HALT: no such branch $BRANCH"; exit 1; }
INCOMING="$(git rev-list --count "HEAD..$BRANCH")"
[[ "$INCOMING" -gt 0 ]] || { echo "nothing to merge: $BRANCH is not ahead of $(git rev-parse --abbrev-ref HEAD)."; exit 0; }

echo "reap-at-merge: $BRANCH ($INCOMING commit(s) ahead) -> $(git rev-parse --abbrev-ref HEAD)"
echo "incoming:"; git log --oneline "HEAD..$BRANCH" | sed 's/^/  /'

# === SET-MEMBERSHIP GATE (M6(ii); NO-CHERRY-PICK — C-RATIFICATION-PACKET §5, canon §4) ===
# A module branch reaches main ONLY inside a RATIFIED set naming its lane. The executor
# apply-receipts stream rides its own ratified carve-out (per-receipt, not set-membership) and is
# exempt here. Enforced BEFORE the merge tree is computed, so a non-member never touches the index.
# `- decision: RATIFIED` prefix-matches BOTH merge states (RATIFIED · RATIFIED-WITH-SEQUENCE);
# AMENDED/HELD/REJECTED members are NOT ratified → correctly non-members here. Membership is BY LANE
# NAME in the packet's ## MEMBERS section (the shape scripts/ratify.sh writes: `lane=<lane> · …`).
RECEIPT_LINE=""
if [[ -z "${IS_EXEC:-}" ]]; then
    RATIFIED_PACKET=""
    for p in "$REPO_ROOT"/_ratification/SET-*.md; do
        [[ -e "$p" ]] || continue
        grep -qE '^- decision: RATIFIED' "$p" || continue
        # Is this lane named in the packet's MEMBERS section?
        if awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$p" | grep -qE "lane=${LANE_ARG}( |·|,|$)"; then
            RATIFIED_PACKET="$(basename "$p" .md)"; break
        fi
    done
    if [[ -z "$RATIFIED_PACKET" ]]; then
        echo "HALT: NO-CHERRY-PICK — module branch '$BRANCH' is not a member of any RATIFIED set" >&2
        echo "  (C-RATIFICATION-PACKET §5: RETURNED/unratified content reaches main ONLY inside a future ratified set)." >&2
        echo "  Assemble + ratify a set including lane '${LANE_ARG}' before merge: scripts/ratify.sh assemble → assess → ratify." >&2
        exit 3
    fi
    # canon §4 receipt line (verbatim shape), carried into the merge commit + auditable on main.
    PKT="$REPO_ROOT/_ratification/$RATIFIED_PACKET.md"
    if awk '/^## JOINT-EDGES/{j=1;next} /^## /{j=0} j' "$PKT" | grep -q 'NONE'; then
        EDGES="NONE"
    else
        EDGES="$(awk '/^## JOINT-EDGES/{j=1;next} /^## /{j=0} j' "$PKT" | grep -E '^- ' | sed 's/^- *//; s/^UNRESOLVED · //; s/^RESOLVED · //' | paste -sd'; ' - )"
        [[ -z "$EDGES" ]] && EDGES="NONE"
    fi
    RECEIPT_LINE="member ${LANE_ARG} evaluated against the set {${RATIFIED_PACKET}}: joint edges = ${EDGES}"
    echo "set-membership: $BRANCH ratified in ${RATIFIED_PACKET}."
    echo "  receipt: ${RECEIPT_LINE}"
fi

# Compute the merge tree without committing (so we can apply §13(2) exclusion first).
git merge --no-ff --no-commit "$BRANCH" >/dev/null 2>&1 || true   # may pause on conflicts

# §13(2) + ROUTING: integration-EXCLUDE _boot/** AND _orchestration/relay-outbox/** — make the
# index match MAIN's HEAD EXACTLY. A plain `git checkout HEAD -- <dir>` only restores both-side
# files; it does NOT drop the module's ADDED files (its CHARTER-<lane>.md, its outbox surfaces) →
# they would LEAK onto spine. exclude_to_head restores HEAD then unstages ONLY the additions
# (worktree untouched; identity-safe — NOT rm -rf), with a fail-closed identity guard.
exclude_to_head() {  # returns nonzero on identity-guard failure
    local ex f
    for ex in "$@"; do
        git checkout HEAD -- "$ex" 2>/dev/null || true
        # After `git checkout HEAD -- "$ex"` restores HEAD's version of every BOTH-SIDE file, the ONLY
        # remaining index-vs-HEAD diff under "$ex" is the module's ADDED files (its CHARTER-<lane>.md,
        # its relay-outbox surfaces). Drop each from BOTH the index AND the worktree:
        #   - `git rm --cached` unstages (keeps it off spine — correct), BUT
        #   - alone it leaves the file as UNTRACKED worktree residue, which trips the NEXT reap's
        #     clean-tree DIRTY check → forces a hand-reap (source-program hygiene fix, rule-stated).
        # SCOPING GUARD: only files enumerated by `git diff --cached HEAD -- "$ex"` are removed —
        # i.e. ADDs UNDER THE EXCLUDED SET ONLY. NEVER a blanket `git clean` (that would eat
        # unrelated untracked work — a foot-gun). Idempotent (`[[ -e ]]` + `rm -f`) + logged to stderr.
        while IFS= read -r f; do
            [[ -z "$f" ]] && continue
            git rm --cached --quiet --ignore-unmatch -- "$f" >/dev/null 2>&1 || true
            [[ -e "$f" ]] && rm -f -- "$f" && echo "  exclude-residue-dropped: $f" >&2
        done < <(git diff --cached --name-only HEAD -- "$ex" 2>/dev/null)
    done
    git ls-files --cached -- _boot/BOOTSTRAP.md | grep -q .
}
exclude_to_head _boot _orchestration/relay-outbox || {
    echo "HALT: identity guard — _boot/BOOTSTRAP.md missing post-exclusion; aborting merge."
    git merge --abort 2>/dev/null || git reset --hard HEAD; exit 2; }

# HALT-LOUD on any conflict OUTSIDE the integration-excluded paths.
UNMERGED="$(git ls-files -u | awk '{print $4}' | sort -u | grep -vE '^(_boot/|_orchestration/relay-outbox/)' || true)"
if [[ -n "$UNMERGED" ]]; then
    echo "HALT: merge conflict OUTSIDE integration-excluded paths — needs ruling:"; echo "$UNMERGED" | sed 's/^/  - /'
    git merge --abort 2>/dev/null || git reset --hard HEAD
    exit 2
fi

# Sanity: staged merge must not introduce writes to spine/shared-substrate beyond the lane's
# authority class.
#  - module/<lane>: NO spine paths at all (D3 prevents them committing those; assert it).
#  - executor: ONLY ledger/apply-receipts/** is permitted (ratified carve-out); EVERY other spine
#    path — INCLUDING other ledger/ subpaths — HALTS (single-spine-writer preserved).
# ISSUE-1 FIX (v2.5.6): the merge-time backstop reads the SAME census as the pre-commit gate —
# scripts/spine-census.sh (engine base set + the adopter's DECLARED set, HEAD-readback ruling #2),
# via an is_spine() that mirrors the pre-commit helper. This RETIRES the hand-maintained SPINE_RE
# that had drifted STALE: it recognised none of the set-authorization machinery's own files
# (PENDING-SET.md, _ratification/, seats.yaml, launch-orc.sh, .claude/settings.json, SLOTS.md, dag/,
# sql/, migrations/, skill/, _orchestration/lane-provisioning.md) nor the adopter-declared set — so a
# lane reaching the merge with those was caught at pre-commit but NOT at this backstop (Issue 1,
# MAINTAINED-STATE DRIFT). ADOPTERS extend the census via `seats.yaml spine_paths:`, NEVER a
# hand-edited regex here. bash 3.2 floor → read-loop, not mapfile; probe_census_parity.sh FAILS if
# this file ever reintroduces a census literal.
SPINE_PATHS=()
while IFS= read -r _sp; do [[ -n "$_sp" ]] && SPINE_PATHS+=("$_sp"); done < <("$REPO_ROOT/scripts/spine-census.sh")
# Fail-CLOSED if the census yielded nothing (script missing / exec bit lost / emit error): a hardcoded
# regex could never be empty, a generated census can — refuse to reap with no spine knowledge rather
# than let a spine-touching merge through (invariant #5; abort the in-progress merge first).
if [[ ${#SPINE_PATHS[@]} -eq 0 ]]; then
    echo "HALT: spine census empty — scripts/spine-census.sh missing/not-executable (fail-closed; refusing to reap with no spine knowledge)."
    git merge --abort 2>/dev/null || git reset --hard HEAD; exit 2
fi
is_spine() {
    local f="$1" sp
    for sp in "${SPINE_PATHS[@]}"; do
        case "$sp" in
            */) [[ "$f" == "$sp"* ]] && return 0 ;;
            *)  [[ "$f" == "$sp"  ]] && return 0 ;;
        esac
    done
    return 1
}
STAGED="$(git diff --cached --name-only)"
VIOL=""
while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    # executor carve-out UNCHANGED: on the executor apply-receipt path, ledger/apply-receipts/** is the
    # ratified single-writer stream (permitted); EVERY other spine path — incl. other ledger/ — HALTS.
    [[ -n "${IS_EXEC:-}" && "$f" == ledger/apply-receipts/* ]] && continue
    is_spine "$f" && VIOL="${VIOL}${f}"$'\n'
done <<< "$STAGED"
VIOL="$(printf '%s' "$VIOL" | grep -v '^$' || true)"
if [[ -n "$VIOL" ]]; then
    echo "HALT: incoming merge touches spine/shared-substrate paths beyond lane authority:"; echo "$VIOL" | sed 's/^/  - /'
    git merge --abort 2>/dev/null || git reset --hard HEAD
    exit 2
fi

# === RECEIPT-ID SINGLE ALLOCATOR (§2.15) ===
# The executor's apply-receipts arrive with PROVISIONAL ids (R-<utc>-<lane>-<nonce>). The foundation
# is the SINGLE ALLOCATOR: here, at reap, canonical sequential ids are assigned, the rows rewritten,
# and any duplicate canonical id (same id, differing content) HALTs — a collision is never silently
# renumbered. Idempotent (a re-reap of already-canonical rows) is a no-op. Executor path only.
if [[ -n "${IS_EXEC:-}" ]]; then
    command -v python3 >/dev/null 2>&1 || {
        echo "HALT: python3 required to canonicalize receipt ids at reap (invariant #5 — no silent skip)."
        git merge --abort 2>/dev/null || git reset --hard HEAD; exit 3; }
    if ! python3 "$REPO_ROOT/scripts/receipt-ledger.py" canonicalize "$REPO_ROOT"; then
        echo "HALT: receipt-id canonicalization failed (duplicate canonical id or unreadable ledger) — aborting merge."
        git merge --abort 2>/dev/null || git reset --hard HEAD; exit 3
    fi
    # Re-stage the rewritten apply-receipts (canonicalization stays within the executor carve-out).
    git add -- ledger/apply-receipts 2>/dev/null || true
fi

# Commit the merge (foundation). NOT [audit]-subject -> the foundation post-commit
# hook fires: reap-then-audit re-audits this merge (merge-aware CHANGED_FILES = the
# incoming work vs first parent) and seals it on the next foundation reap / flush.
git commit -q --no-edit -m "merge $BRANCH: $INCOMING $WORK_KIND commit(s) — audit-at-merge [C] (integrator re-audits incoming work)" ${RECEIPT_LINE:+-m "$RECEIPT_LINE"}
MERGE_SHA="$(git rev-parse --short HEAD)"
echo "merged as $MERGE_SHA (main _boot preserved = foundation). Foundation post-commit auditor re-auditing incoming $WORK_KIND work; [audit] seal lands on next reap / terminal flush."
