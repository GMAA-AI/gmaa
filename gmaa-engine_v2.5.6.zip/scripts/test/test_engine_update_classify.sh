#!/usr/bin/env bash
# scripts/test/test_engine_update_classify.sh — acceptance for scripts/engine-update-classify.sh
# (FIX-ORDER r4 §2.10, item-10 acceptance verbatim): on a scratch adopter tree with ONE filled slot,
# ONE hand-edited engine file, and ONE generated file, the classifier emits EXACTLY one
# PRESERVE-FILL, one CONFLICT, one PRESERVE-GENERATED, and the deltas; a moved-slot fixture
# produces STOP (exit 2). Plus a pristine-tree control (nothing preserved/conflicted, delta only).
# Isolated mktemp fixtures; exercises the LIVE worktree classifier bytes.
set -u

ENGINE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
CLS="$ENGINE/scripts/engine-update-classify.sh"
[[ -f "$CLS" ]] || { echo "FAIL: classifier missing at $CLS"; exit 2; }

T="$(mktemp -d 2>/dev/null || mktemp -d -t euctest)"; trap 'rm -rf "$T"' EXIT
PASS=0; FAIL=0
ok(){ printf '  \033[32mPASS\033[0m %s\n' "$1" 2>/dev/null || echo "  PASS $1"; PASS=$((PASS+1)); }
no(){ printf '  \033[31mFAIL\033[0m %s\n' "$1" 2>/dev/null || echo "  FAIL $1"; FAIL=$((FAIL+1)); }

# --- mini OLD baseline (engine files + a slotted contract + a generated file) ---
mkdir -p "$T/old/scripts" "$T/old/contracts" "$T/old/docs"
printf '#!/bin/sh\necho engine-v1\n'                    > "$T/old/scripts/tool.sh"
printf '# C-DB contract\nschema: {{SCHEMA}}\n'          > "$T/old/contracts/C-DB.md"
printf '# checklist\n- [ ] adopt\n'                     > "$T/old/CHECKLIST.md"
printf '# stable doc\nunchanged text\n'                 > "$T/old/docs/STABLE.md"
printf '# to-be-removed\n'                              > "$T/old/docs/OLDONLY.md"
# --- mini NEW baseline: tool.sh changed (delta CHANGED), NEWONLY added, OLDONLY removed ---
mkdir -p "$T/new/scripts" "$T/new/contracts" "$T/new/docs"
printf '#!/bin/sh\necho engine-v2\n'                    > "$T/new/scripts/tool.sh"
cp "$T/old/contracts/C-DB.md" "$T/new/contracts/"
cp "$T/old/CHECKLIST.md" "$T/new/"
cp "$T/old/docs/STABLE.md" "$T/new/docs/"
printf '# new engine doc\n'                             > "$T/new/docs/NEWONLY.md"
mk_manifest(){ ( cd "$1" && find . -type f | sort | while IFS= read -r f; do shasum -a 256 "$f"; done ) > "$2"; }
mk_manifest "$T/old" "$T/OLD-MANIFEST.sha256"
mk_manifest "$T/new" "$T/NEW-MANIFEST.sha256"
# --- SLOTS.md (real table shape) + CHANGELOGs (with + without a moved slot) ---
cat > "$T/SLOTS.md" <<'EOF'
# SLOTS.md (fixture)
| id | surface | shape | contract | default in blank | example |
|---|---|---|---|---|---|
| `{{SCHEMA}}` | `contracts/C-DB.md` (schema INVENTORY) | `{{TOKEN}}` | primary DB schema qualifier | `{{SCHEMA}}` | `dbo` |
EOF
cat > "$T/CHANGELOG-clean.md" <<'EOF'
# CHANGELOG (fixture)
## vNEXT (fixture)
No slot-contract changes in this release.
EOF
cat > "$T/CHANGELOG-moved.md" <<'EOF'
# CHANGELOG (fixture)
## vNEXT (fixture)
**Slot-contract changes.** `{{SCHEMA}}` moved from a prose mention to a frontmatter field; the
old fill form no longer resolves.

Other notes.
EOF

seed_adopter(){ rm -rf "$T/adopter"; cp -R "$T/old" "$T/adopter"; }

echo "── A. item-10 acceptance fixture: one fill · one hand-edit · one generated edit ──"
seed_adopter
printf '# C-DB contract\nschema: analytics\n'  > "$T/adopter/contracts/C-DB.md"   # FILLED slot
printf '#!/bin/sh\necho engine-v1 hacked\n'    > "$T/adopter/scripts/tool.sh"     # hand-edited engine file
printf '# checklist\n- [x] adopt\n- [ ] w2\n'  > "$T/adopter/CHECKLIST.md"        # generated file evolved
out="$(bash "$CLS" --old-manifest "$T/OLD-MANIFEST.sha256" --new-manifest "$T/NEW-MANIFEST.sha256" \
        --slots "$T/SLOTS.md" --adopter "$T/adopter" --changelog "$T/CHANGELOG-clean.md" 2>&1)"; rc=$?
[[ $rc -eq 0 ]] && ok "classifier exits 0 (classified, no STOP)" || no "expected exit 0, got $rc: ${out##*$'\n'}"
[[ "$(grep -c 'contracts/C-DB.md' <<<"$out")" -ge 1 ]] && grep -q 'filled: {{SCHEMA}}' <<<"$out" \
    && ok "EXACTLY the filled slot → PRESERVE-FILL (names {{SCHEMA}})" || no "PRESERVE-FILL wrong: $out"
grep -q 'fill=1 ' <<<"$out" && ok "fill count = 1" || no "fill count ≠ 1"
grep -q 'generated=1 ' <<<"$out" && grep -A2 'PRESERVE-GENERATED' <<<"$out" | grep -q 'CHECKLIST.md' \
    && ok "EXACTLY the generated file → PRESERVE-GENERATED (CHECKLIST.md)" || no "PRESERVE-GENERATED wrong"
grep -q 'conflict=1 ' <<<"$out" && grep -A2 'CONFLICT' <<<"$out" | grep -q 'scripts/tool.sh' \
    && ok "EXACTLY the hand-edited engine file → CONFLICT (scripts/tool.sh)" || no "CONFLICT wrong"
grep -q 'CHANGED	scripts/tool.sh' <<<"$out" && grep -q 'ADDED	docs/NEWONLY.md' <<<"$out" \
    && grep -q 'REMOVED	docs/OLDONLY.md' <<<"$out" \
    && ok "ENGINE-DELTA carries CHANGED + ADDED + REMOVED" || no "ENGINE-DELTA incomplete"
grep -q 'STOP=0' <<<"$out" && ok "no STOP on an unchanged slot contract" || no "unexpected STOP"

echo "── B. moved-slot fixture → STOP (exit 2) ──"
out="$(bash "$CLS" --old-manifest "$T/OLD-MANIFEST.sha256" --new-manifest "$T/NEW-MANIFEST.sha256" \
        --slots "$T/SLOTS.md" --adopter "$T/adopter" --changelog "$T/CHANGELOG-moved.md" 2>&1)"; rc=$?
[[ $rc -eq 2 ]] && ok "moved+filled slot → exit 2" || no "expected exit 2, got $rc"
grep -q 'STOP: {{SCHEMA}}' <<<"$out" && grep -qi 'never resolves a moved slot alone' <<<"$out" \
    && ok "STOP names the moved slot + the operator-door law" || no "STOP line wrong: $out"

echo "── C. FLIP control: pristine adopter → no preserves, no conflicts, delta only ──"
seed_adopter
out="$(bash "$CLS" --old-manifest "$T/OLD-MANIFEST.sha256" --new-manifest "$T/NEW-MANIFEST.sha256" \
        --slots "$T/SLOTS.md" --adopter "$T/adopter" --changelog "$T/CHANGELOG-moved.md" 2>&1)"; rc=$?
[[ $rc -eq 0 ]] && grep -q 'fill=0 generated=0 conflict=0 STOP=0' <<<"$out" \
    && ok "pristine tree → 0/0/0/0 + delta (moved-slot changelog is inert when nothing is filled)" \
    || no "pristine control wrong (rc=$rc): $out"

echo "── D. fail-closed: missing input → exit 3 ──"
bash "$CLS" --old-manifest "$T/nope" --new-manifest "$T/NEW-MANIFEST.sha256" --slots "$T/SLOTS.md" --adopter "$T/adopter" >/dev/null 2>&1
[[ $? -eq 3 ]] && ok "unreadable input → exit 3 (fail-closed)" || no "missing input did not exit 3"

echo
echo "== engine-update-classify acceptance: PASS=$PASS FAIL=$FAIL =="
[[ $FAIL -eq 0 ]]
