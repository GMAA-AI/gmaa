#!/usr/bin/env bash
# scripts/test/test_set_gate_seeded_fault.sh — seeded-fault acceptance for the set-level
# authorization mechanism (M1–M7). Stands up ISOLATED scratch git repos (mktemp sandbox, fresh
# `git init` per group — NEVER touches the shared tmux server, origin, or any live repo), installs
# the hooks, and asserts each acceptance from a check that CAN fail. Positive control included.
#
# Proves: M1 module-staging-PENDING-SET → REJECT · M2 empty-surfaces member → REFUSED · M3 assemble
# module-worktree → HALT / overlap → JOINT-EDGE / disjoint → NONE / numbering collision → HALT ·
# M4 semantic-only conflict reported NOT mechanically detected · M5 ratify empty-assessment → HALT /
# unresolved-edge → HALT / both-filled → RATIFIED · M6(ii) reap non-member → NO-CHERRY-PICK ·
# M6(i)(a) uncovered authored-spine → REJECT · M6(i)(b) covered → PASS · positive control.
# §2.15 receipt-id uniqueness: distinct provisional ids (same second) · reap assigns distinct canonical
# ids (single allocator) · planted duplicate canonical id → reap HALT. §2.16 uniqueness-not-presence:
# member-cited duplicate → ratify HALT · duplicate in ledger → set-gate probe FAIL · unique → PASS.
# §2.14 reference apply wrapper: mis-targeting the spine ledger → executor carve-out REJECT + wrapper
# exit 3 · default apply-receipts target → PASS · forced commit failure → wrapper exit 3 (FAIL-LOUD).
# Set-authorization CUT (2026-08-19 re-source): REQ-FOOTPRINT + REQ-HUNT FLIP probes run GREEN on the
# post-fold bytes (the fold's done-check per the delivery) · U4B conformance MISSING → MERGE HALT ·
# REQ-COST cost-guard: under-cap → 0 · over-cap → 2 (COST-CAP HALT-LOUD) · shipped-unfilled caps → 3.
# v2.5.6 §5 (Issues 1/2/3): reap NEW-census set-auth path (module + executor) → HALT 2 · OLD-census
# regression · executor apply-receipts carve-out intact · census-parity PASS/FAIL(drift) · state-prop
# set-auth-change-no-STATE → FAIL/PASS · guard git-global bypass + core.hooksPath + malformed-stdin
# fail-closed + benign ALLOWs · receipt-ledger malformed line → HALT exit 3 (both verbs) + real-dup
# regression + blank/comment tolerated. The census consumers read scripts/spine-census.sh, so newfnd/
# newmod/newexec (+ the two set-gate FLIP probes' scaffolds) now stage it (single-source dependency).
set -u

ENGINE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SBX="$(mktemp -d 2>/dev/null || mktemp -d -t setgate)"; trap 'rm -rf "$SBX"' EXIT
PASS=0; FAIL=0
ok(){ printf '  \033[32mPASS\033[0m %s\n' "$1" 2>/dev/null || echo "  PASS $1"; PASS=$((PASS+1)); }
no(){ printf '  \033[31mFAIL\033[0m %s\n' "$1" 2>/dev/null || echo "  FAIL $1"; FAIL=$((FAIL+1)); }

# --- seed an isolated foundation repo at $SBX/<tag>/foundation (folder basename == lane) ---
newfnd() {
    local d="$SBX/$1/foundation"; mkdir -p "$d/scripts/test" "$d/agents" "$d/probes/foundation" "$d/probes/set-gate" "$d/_boot" "$d/_ratification" "$d/_orchestration" "$d/contracts/ref-impl" "$d/docs" "$d/ledger/usage"
    cp "$ENGINE/scripts/resolve-lane.sh" "$ENGINE/scripts/pending-set.sh" "$ENGINE/scripts/ratify.sh" "$ENGINE/scripts/reap_at_merge.sh" "$ENGINE/scripts/declared-spine-paths.sh" "$ENGINE/scripts/spine-census.sh" "$ENGINE/scripts/guard-command-shape.sh" "$ENGINE/scripts/receipt-ledger.py" "$ENGINE/scripts/cost-guard.sh" "$d/scripts/"
    cp "$ENGINE/probes/foundation/probe_set_gate.sh" "$ENGINE/probes/foundation/probe_state_propagation.sh" "$ENGINE/probes/foundation/probe_census_parity.sh" "$d/probes/foundation/"
    cp "$ENGINE/probes/set-gate/probe_footprint_coverage_flip.sh" "$ENGINE/probes/set-gate/probe_semantic_hunt_flip.sh" "$d/probes/set-gate/"
    cp "$ENGINE/contracts/ref-impl/emit_receipt_ref.sh" "$d/contracts/ref-impl/"
    cp "$ENGINE/contracts/COST-CAPS.md" "$d/contracts/"
    cp "$ENGINE/agents/pre-commit-hook.sh" "$d/agents/"
    cp "$ENGINE/PENDING-SET.md" "$d/"
    chmod +x "$d/scripts/"*.sh "$d/scripts/receipt-ledger.py" "$d/agents/pre-commit-hook.sh" "$d/probes/foundation/"*.sh "$d/probes/set-gate/"*.sh "$d/contracts/ref-impl/emit_receipt_ref.sh"
    cat > "$d/_boot/BOOTSTRAP.md" <<'EOF'
---
lane: foundation
role: integrator
bootstrap_version: test
spine_write: ALLOW
---
test bootstrap
EOF
    printf '# lane-provisioning (genesis shape: | lane | branch | version | blob | ts |)\n| foundation | main | test | 0 | 2026 |\n' > "$d/_orchestration/lane-provisioning.md"
    ( cd "$d"
      git init -q; git symbolic-ref HEAD refs/heads/main 2>/dev/null || true
      git config user.email t@t; git config user.name t; git config commit.gpgsign false
      git add -A; git commit -q -m "seed [prov]" --no-verify
      cp agents/pre-commit-hook.sh .git/hooks/pre-commit; chmod +x .git/hooks/pre-commit )
    echo "$d"
}
# --- seed an isolated module repo (folder basename == lane == module-a) ---
newmod() {
    local d="$SBX/$1/module-a"; mkdir -p "$d/scripts" "$d/agents" "$d/_boot" "$d/_orchestration"
    cp "$ENGINE/scripts/resolve-lane.sh" "$ENGINE/scripts/ratify.sh" "$ENGINE/scripts/pending-set.sh" "$ENGINE/scripts/spine-census.sh" "$d/scripts/"
    cp "$ENGINE/agents/pre-commit-hook.sh" "$d/agents/"; cp "$ENGINE/PENDING-SET.md" "$d/"
    chmod +x "$d/scripts/"*.sh "$d/agents/pre-commit-hook.sh"
    cat > "$d/_boot/BOOTSTRAP.md" <<'EOF'
---
lane: module-a
role: module
spine_write: DENY
---
test module
EOF
    printf '# lane-provisioning (genesis shape: | lane | branch | version | blob | ts |)\n| foundation | main | test | 0 | 2026 |\n' > "$d/_orchestration/lane-provisioning.md"
    ( cd "$d"
      git init -q; git symbolic-ref HEAD refs/heads/module/a 2>/dev/null || true
      git config user.email t@t; git config user.name t; git config commit.gpgsign false
      git add -A; git commit -q -m "seed [prov]" --no-verify
      cp agents/pre-commit-hook.sh .git/hooks/pre-commit; chmod +x .git/hooks/pre-commit )
    echo "$d"
}
# --- seed an isolated EXECUTOR repo (folder basename == lane == executor, branch executor) ---
# The apply-receipts-only carve-out keys on lane==executor AND branch executor; §2.14 exercises the
# reference apply wrapper against it.
newexec() {
    local d="$SBX/$1/executor"; mkdir -p "$d/scripts" "$d/agents" "$d/_boot" "$d/_orchestration" "$d/contracts/ref-impl" "$d/ledger/apply-receipts/executor"
    cp "$ENGINE/scripts/resolve-lane.sh" "$ENGINE/scripts/spine-census.sh" "$d/scripts/"
    cp "$ENGINE/agents/pre-commit-hook.sh" "$d/agents/"
    cp "$ENGINE/contracts/ref-impl/emit_receipt_ref.sh" "$ENGINE/contracts/ref-impl/fire_ref.sh" "$ENGINE/contracts/ref-impl/apply_ref.sh" "$d/contracts/ref-impl/"
    chmod +x "$d/scripts/"*.sh "$d/agents/pre-commit-hook.sh" "$d/contracts/ref-impl/"*.sh
    cat > "$d/_boot/BOOTSTRAP.md" <<'EOF'
---
lane: executor
role: executor
spine_write: apply-receipts-only
---
test executor
EOF
    printf '# lane-provisioning (genesis shape: | lane | branch | version | blob | ts |)\n| foundation | main | test | 0 | 2026 |\n' > "$d/_orchestration/lane-provisioning.md"
    ( cd "$d"
      git init -q; git symbolic-ref HEAD refs/heads/executor 2>/dev/null || true
      git config user.email t@t; git config user.name t; git config commit.gpgsign false
      git add -A; git commit -q -m "seed [prov]" --no-verify
      cp agents/pre-commit-hook.sh .git/hooks/pre-commit; chmod +x .git/hooks/pre-commit )
    echo "$d"
}
# --- mint the fixture requirement's set-identity (REQ-FOOTPRINT §2.2; foundation-only) ---
# Sets REQID/SETID globals for add_member. Default requirement REQ-T; footprint = $1 (comma lanes).
mint_req() { # footprint-lanes [reqid]
    REQID="${2:-REQ-T}"
    SETID="$(scripts/pending-set.sh mint "$REQID" --footprint-lanes "$1" 2>/dev/null)"
}
# --- write a member entry + reap it into the ledger (foundation) ---
add_member() { # id lane surfaces [deps] [evidence-receipts]
    local dir="_orchestration/relay-outbox/$2"; mkdir -p "$dir"
    cat > "$dir/SET-MEMBER-$1.md" <<EOF
# SET-MEMBER-$1 — pending-set member entry

- member id: $1
- lane: $2
- requirement id: ${REQID:-REQ-T}
- set id: ${SETID:-SET-0001}
- branch@sha: $2/br@abc1234
- intent: seeded member
- surfaces touched: $3
- invariants touched: none-declared
- evidence receipts: ${5:-none-declared}
- self-declared dependencies: ${4:-none-declared}
EOF
    scripts/pending-set.sh reap "$dir/SET-MEMBER-$1.md" >/dev/null 2>&1
}
# --- fill the required MERGE-decision slots on an assembled packet (hunt + per-member conformance) ---
merge_ready() { # setid member...
    local sid="$1"; shift
    scripts/ratify.sh hunt "$sid" --method 'seeded grep across member surfaces' --candidates ZERO --residual 'seeded fixture; disjoint records' --verdict CLEAR >/dev/null 2>&1
    local m; for m in "$@"; do
        scripts/ratify.sh conformance "$sid" "$m" --verdict PASS --method judgment --evidence 'seeded fixture' >/dev/null 2>&1
    done
}

echo "== set-gate seeded-fault acceptance (isolated scratch; sandbox $SBX) =="

# ---- M2: empty --surfaces REFUSED ----
F="$(newfnd t2m)"; ( cd "$F"
  out="$(scripts/pending-set.sh member wp1 --intent x --surfaces '' 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -q REFUSED; } )  && ok "M2 empty-surfaces member REFUSED" || no "M2 empty-surfaces member REFUSED"

# ---- M1: module lane staging PENDING-SET.md → pre-commit REJECT ----
M="$(newmod t1)"; ( cd "$M"
  echo x >> PENDING-SET.md; git add PENDING-SET.md
  out="$(git commit -m 'try spine' 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'spine'; } ) && ok "M1 module staging PENDING-SET.md REJECTED" || no "M1 module staging PENDING-SET.md REJECTED"

# ---- M3: assemble in a module worktree HALTs ----
M="$(newmod t3h)"; ( cd "$M"
  out="$(scripts/ratify.sh assemble 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'foundation worktree'; } ) && ok "M3 assemble in module worktree HALTs" || no "M3 assemble in module worktree HALTs"

# ---- M3/M4: overlapping paths → JOINT-EDGE naming both ----
F="$(newfnd t4)"; ( cd "$F"
  mint_req 'module-a,module-b'
  add_member m1 module-a contracts/shared.md; add_member m2 module-b contracts/shared.md
  scripts/ratify.sh assemble >/dev/null 2>&1
  P="$(ls _ratification/SET-*.md | head -1)"
  awk '/^## JOINT-EDGES/{j=1;next}/^## /{j=0}j' "$P" | grep -qi 'OVERLAPPING PATH' \
    && awk '/^## JOINT-EDGES/{j=1;next}/^## /{j=0}j' "$P" | grep -q 'm1' \
    && awk '/^## JOINT-EDGES/{j=1;next}/^## /{j=0}j' "$P" | grep -q 'm2' ) \
  && ok "M3/M4 overlapping paths → JOINT-EDGE names both members" || no "M3/M4 overlapping paths → JOINT-EDGE names both members"

# ---- M3: disjoint members → NONE   +   M4: semantic-only reported NOT mechanically detected ----
F="$(newfnd t5)"; ( cd "$F"
  mint_req 'module-a,module-b'
  add_member m1 module-a contracts/a.md; add_member m2 module-b contracts/b.md
  scripts/ratify.sh assemble >/dev/null 2>&1
  P="$(ls _ratification/SET-*.md | head -1)"
  awk '/^## JOINT-EDGES/{j=1;next}/^## /{j=0}j' "$P" | grep -q 'NONE' ) \
  && ok "M3 disjoint members → JOINT-EDGES NONE" || no "M3 disjoint members → JOINT-EDGES NONE"
( cd "$F"; P="$(ls _ratification/SET-*.md | head -1)"
  grep -q 'NOT proven-complete' "$P" && grep -qi 'semantic joint incoherence' "$P" ) \
  && ok "M4 semantic-only conflict reported NOT mechanically detected (canon §13)" || no "M4 semantic-only conflict reported NOT mechanically detected"

# ---- M3: numbering collision → HALT ----
F="$(newfnd t6)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a contracts/a.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  add_member m2 module-a contracts/b.md
  out="$(scripts/ratify.sh assemble SET-0001 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi collision; } ) && ok "M3 numbering collision → HALT" || no "M3 numbering collision → HALT"

# ---- M5: ratify with empty assessment → HALT ----
F="$(newfnd t8)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a contracts/a.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  out="$(scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'assessment slot is EMPTY'; } ) && ok "M5 ratify empty-assessment → HALT" || no "M5 ratify empty-assessment → HALT"

# ---- M5: ratify with an unresolved joint edge → HALT ----
F="$(newfnd t9)"; ( cd "$F"
  mint_req 'module-a,module-b'
  add_member m1 module-a contracts/shared.md; add_member m2 module-b contracts/shared.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text 'assessed: reviewed logic/evidence/state/invariants' >/dev/null 2>&1
  out="$(scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'unresolved joint edge'; } ) && ok "M5 ratify unresolved-edge → HALT" || no "M5 ratify unresolved-edge → HALT"

# ---- M5: assess + ratify (no edges) → RATIFIED, members → ratified-in ----
F="$(newfnd t10)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a contracts/a.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text 'assessed: coherent' >/dev/null 2>&1
  merge_ready SET-0001 m1
  out="$(scripts/ratify.sh ratify SET-0001 --by operator --rationale-class in-band 2>&1)"; rc=$?
  { [[ $rc -eq 0 ]] && echo "$out" | grep -q RATIFIED && scripts/pending-set.sh list | grep -q 'ratified-in SET-0001'; } ) \
  && ok "M5 assess+hunt+conformance+ratify → RATIFIED, ledger member ratified-in" || no "M5 assess+hunt+conformance+ratify → RATIFIED, ledger member ratified-in"

# ---- M6(ii): reap a non-member module branch → NO-CHERRY-PICK HALT ----
F="$(newfnd t11)"; ( cd "$F"
  git checkout -q -b module/b; echo work > mfile.txt; git add mfile.txt; git commit -q -m 'module b work' --no-verify; git checkout -q main
  out="$(scripts/reap_at_merge.sh b 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -q 'NO-CHERRY-PICK'; } ) && ok "M6(ii) reap non-member → NO-CHERRY-PICK HALT" || no "M6(ii) reap non-member → NO-CHERRY-PICK HALT"

# ---- M6(i)(a): uncovered authored-spine → pre-commit REJECT ----
F="$(newfnd t12)"; ( cd "$F"
  echo 'new contract' > contracts/uncov.md; git add contracts/uncov.md
  out="$(git commit -m 'uncovered spine' 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'not covered by a RATIFIED set'; } ) && ok "M6(i)(a) uncovered authored-spine → REJECT" || no "M6(i)(a) uncovered authored-spine → REJECT"

# ---- M6(i)(b): covered authored-spine under a ratified set → PASS ----
F="$(newfnd t13)"
if ( cd "$F"
  echo 'new contract' > contracts/new.md
  mint_req module-a
  add_member m1 module-a contracts/new.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text 'assessed: coherent' >/dev/null 2>&1
  merge_ready SET-0001 m1
  scripts/ratify.sh ratify SET-0001 --by operator --rationale-class in-band >/dev/null 2>&1
  git add contracts/new.md
  git commit -m 'covered spine [set SET-0001]' >/dev/null 2>&1 ); then
  ok "M6(i)(b) covered authored-spine under ratified set → PASS"
else
  no "M6(i)(b) covered authored-spine under ratified set → PASS"
fi

# ---- M7 standing probe: FAILs on a planted uncited spine commit (after a ratified baseline) ----
F="$(newfnd tpf)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a contracts/base.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text ok >/dev/null 2>&1
  merge_ready SET-0001 m1
  scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band >/dev/null 2>&1
  git add -A; git commit -q -m 'ratify SET-0001' --no-verify
  echo sneaky > contracts/sneak.md; git add contracts/sneak.md; git commit -q -m 'uncited spine bypass' --no-verify
  out="$(bash probes/foundation/probe_set_gate.sh 2>&1)"; rc=$?
  { [[ $rc -eq 1 ]] && echo "$out" | grep -q 'FAIL'; } ) && ok "M7 probe FAILs on planted uncited spine commit" || no "M7 probe FAILs on planted uncited spine commit"

# ---- M7 standing probe: positive control (no uncovered spine change) → PASS ----
F="$(newfnd tpp)"; ( cd "$F"
  echo hi > docs/readme.md; git add docs/readme.md; git commit -q -m notes --no-verify
  bash probes/foundation/probe_set_gate.sh >/dev/null 2>&1 ) && ok "M7 probe positive control → PASS" || no "M7 probe positive control → PASS"

# ---- r4 §2.11: an adopter-DECLARED spine path (seats.yaml spine_paths, HEAD-read) is GATED ----
# new fault SEEN TO FAIL FIRST: uncovered declared-spine commit → REJECT.
F="$(newfnd t211a)"; ( cd "$F"
  printf 'seats:\n  - foundation\nspine_paths:\n  - db/\n' > seats.yaml; git add seats.yaml; git commit -q -m 'declare spine_paths [prov]' --no-verify
  mkdir -p db; echo 'schema' > db/schema.sql; git add db/schema.sql
  out="$(git commit -m 'uncovered declared-spine' 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'not covered by a RATIFIED set'; } ) \
  && ok "§2.11 uncovered DECLARED-spine (db/) → REJECT" || no "§2.11 uncovered DECLARED-spine → REJECT"
# then: the same declared path COVERED by a ratified set → PASS (blank engine with no seats.yaml still base-gates, proven above).
F="$(newfnd t211b)"
if ( cd "$F"
  printf 'seats:\n  - foundation\nspine_paths:\n  - db/\n' > seats.yaml; git add seats.yaml; git commit -q -m 'declare spine_paths [prov]' --no-verify
  mkdir -p db; echo 'schema' > db/schema.sql
  mint_req module-a
  add_member m1 module-a db/schema.sql
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text 'assessed: coherent' >/dev/null 2>&1
  merge_ready SET-0001 m1
  scripts/ratify.sh ratify SET-0001 --by operator --rationale-class in-band >/dev/null 2>&1
  git add db/schema.sql
  git commit -m 'covered declared-spine [set SET-0001]' >/dev/null 2>&1 ); then
  ok "§2.11 covered DECLARED-spine under ratified set → PASS"
else
  no "§2.11 covered DECLARED-spine → PASS"
fi

# ---- exemption ruling (2026-08-17): foundation updates dispatch/LATEST.md (resume pin) → PASS ----
F="$(newfnd tlx)"; ( cd "$F"
  mkdir -p dispatch; echo 'next: WP-1' > dispatch/LATEST.md; git add dispatch/LATEST.md
  git commit -m 'resume pin update' >/dev/null 2>&1 ) \
  && ok "exempt dispatch/LATEST.md: foundation resume-pin update → PASS (no set needed)" || no "exempt dispatch/LATEST.md → PASS"

# ============================================================================
# §2.15 / §2.16 RECEIPT-ID UNIQUENESS (single allocator; uniqueness not presence)
# ============================================================================

# ---- §2.15(a): two same-second emissions → distinct PROVISIONAL ids ----
RF="$SBX/emitAB.jsonl"; rm -f "$RF"
GMAA_LANE=module-a bash "$ENGINE/contracts/ref-impl/emit_receipt_ref.sh" "$RF" >/dev/null 2>&1
GMAA_LANE=module-a bash "$ENGINE/contracts/ref-impl/emit_receipt_ref.sh" "$RF" >/dev/null 2>&1
{ [[ "$(grep -o '"receipt_id":"[^"]*"' "$RF" | sort -u | wc -l | tr -d ' ')" -eq 2 ]]; } \
  && ok "§2.15(a) two same-second emissions → distinct provisional ids" || no "§2.15(a) distinct provisional ids"

# ---- §2.15(b): reap assigns distinct CANONICAL ids, continuing the global sequence ----
F="$(newfnd t215b)"
if ( cd "$F"
  mkdir -p ledger/apply-receipts/executor
  printf '%s\n' '{"receipt_id":"R-2020-01-01T00-00-00Z-000001","content_sha":"seed","provisional":false,"seq":1}' > ledger/apply-receipts/executor/seed.jsonl
  git add -A; git commit -q -m 'seed canonical [prov]' --no-verify
  git checkout -q -b executor
  GMAA_LANE=executor GMAA_NONCE=aa bash contracts/ref-impl/emit_receipt_ref.sh ledger/apply-receipts/executor/run.jsonl >/dev/null 2>&1
  GMAA_LANE=executor GMAA_NONCE=bb bash contracts/ref-impl/emit_receipt_ref.sh ledger/apply-receipts/executor/run.jsonl >/dev/null 2>&1
  git add -A; git commit -q -m 'executor apply-receipts (provisional)' --no-verify
  git checkout -q main
  scripts/reap_at_merge.sh executor >/dev/null 2>&1 || exit 1
  ! grep -q '"provisional":true' ledger/apply-receipts/executor/run.jsonl \
    && [[ "$(grep -oh '"receipt_id":"[^"]*"' ledger/apply-receipts/executor/*.jsonl | sort -u | wc -l | tr -d ' ')" -eq 3 ]] ); then
  ok "§2.15(b) reap assigns distinct canonical ids (single allocator, sequence continues)"
else
  no "§2.15(b) reap distinct canonical ids"
fi

# ---- §2.15(c): planted duplicate canonical id at reap → HALT (never renumbered) ----
F="$(newfnd t215c)"; ( cd "$F"
  mkdir -p ledger/apply-receipts/executor
  printf '%s\n' '{"receipt_id":"R-DUP-000001","content_sha":"aaa","provisional":false,"seq":1}' > ledger/apply-receipts/executor/seed.jsonl
  git add -A; git commit -q -m 'seed [prov]' --no-verify
  git checkout -q -b executor
  printf '%s\n' '{"receipt_id":"R-DUP-000001","content_sha":"bbb","provisional":false,"seq":1}' > ledger/apply-receipts/executor/planted.jsonl
  git add -A; git commit -q -m 'planted dup canonical' --no-verify
  git checkout -q main
  out="$(scripts/reap_at_merge.sh executor 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'canonical'; } ) \
  && ok "§2.15(c) planted duplicate canonical id → reap HALT" || no "§2.15(c) planted dup → reap HALT"

# ---- §2.16(d): a member cites a receipt duplicated in the ledger → ratify HALT ----
F="$(newfnd t216d)"; ( cd "$F"
  mkdir -p ledger
  printf '%s\n%s\n' '{"receipt_id":"R-CITED-1","content_sha":"aaa","provisional":false}' '{"receipt_id":"R-CITED-1","content_sha":"bbb","provisional":false}' > ledger/receipts.jsonl
  git add -A; git commit -q -m 'seed dup ledger [prov]' --no-verify
  mint_req module-a
  add_member m1 module-a contracts/a.md none-declared 'R-CITED-1'
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text 'assessed: coherent' >/dev/null 2>&1
  merge_ready SET-0001 m1
  out="$(scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'unique'; } ) \
  && ok "§2.16(d) member-cited duplicate receipt → ratify HALT" || no "§2.16(d) ratify HALT on non-unique cited receipt"

# ---- §2.16(e): duplicate receipt id in the ledger → standing set-gate probe FAIL ----
F="$(newfnd t216e)"; ( cd "$F"
  mkdir -p ledger
  printf '%s\n%s\n' '{"receipt_id":"R-P-1","content_sha":"aaa","provisional":false}' '{"receipt_id":"R-P-1","content_sha":"bbb","provisional":false}' > ledger/receipts.jsonl
  git add -A; git commit -q -m 'seed dup ledger [prov]' --no-verify
  out="$(bash probes/foundation/probe_set_gate.sh 2>&1)"; rc=$?
  { [[ $rc -eq 1 ]] && echo "$out" | grep -qi 'uniqueness'; } ) \
  && ok "§2.16(e) duplicate receipt id → set-gate probe FAIL" || no "§2.16(e) probe FAIL on duplicate receipt id"

# ---- §2.16 positive control: a UNIQUE ledger does not false-FAIL the probe ----
F="$(newfnd t216pp)"; ( cd "$F"
  mkdir -p ledger
  printf '%s\n' '{"receipt_id":"R-U-1","content_sha":"aaa","provisional":false}' > ledger/receipts.jsonl
  git add -A; git commit -q -m 'unique ledger [prov]' --no-verify
  bash probes/foundation/probe_set_gate.sh >/dev/null 2>&1 ) \
  && ok "§2.16 positive control: unique ledger → probe PASS" || no "§2.16 positive control unique ledger → PASS"

# ============================================================================
# §2.14 REFERENCE APPLY WRAPPER (contracts/ref-impl/apply_ref.sh) vs the executor carve-out
# ============================================================================

# ---- §2.14(a): wrapper MIStargeting the spine ledger (ledger/receipts.jsonl) → pre-commit
#      executor carve-out REJECTS + wrapper is FAIL-LOUD (exit 3, not 0) ----
E="$(newexec t214a)"; ( cd "$E"
  GMAA_LANE=executor GMAA_APPLY_RECEIPTS=ledger/receipts.jsonl \
    bash contracts/ref-impl/apply_ref.sh >/dev/null 2>&1; rc=$?
  [[ $rc -eq 3 ]] ) \
  && ok "§2.14(a) wrapper targeting spine ledger/receipts.jsonl → carve-out REJECT + wrapper exit 3" \
  || no "§2.14(a) spine-target → REJECT + exit 3"

# ---- §2.14(b): wrapper with the DEFAULT apply-receipts target → commit PASSES (exit 0),
#      receipt lands under ledger/apply-receipts/executor/ ----
E="$(newexec t214b)"; ( cd "$E"
  GMAA_LANE=executor bash contracts/ref-impl/apply_ref.sh >/dev/null 2>&1; rc=$?
  { [[ $rc -eq 0 ]] && git log -1 --name-only --format= | grep -q '^ledger/apply-receipts/executor/'; } ) \
  && ok "§2.14(b) wrapper default apply-receipts target → commit PASSES (exit 0)" \
  || no "§2.14(b) apply-receipts target → PASS"

# ---- §2.14(c): a FORCED commit failure (any cause) → wrapper exits 3, never warn-and-succeed ----
E="$(newexec t214c)"; ( cd "$E"
  printf '#!/bin/sh\nexit 1\n' > .git/hooks/pre-commit; chmod +x .git/hooks/pre-commit
  GMAA_LANE=executor bash contracts/ref-impl/apply_ref.sh >/dev/null 2>&1; rc=$?
  [[ $rc -eq 3 ]] ) \
  && ok "§2.14(c) forced commit failure → wrapper exit 3 (FAIL-LOUD)" \
  || no "§2.14(c) forced commit failure → exit 3"

# ============================================================================
# SET-AUTHORIZATION CUT (2026-08-19 re-source): U4B · REQ-FOOTPRINT · REQ-HUNT · REQ-COST
# ============================================================================

# ---- U4B (§2.1): conformance verdict MISSING → MERGE decision HALT (non-overridable) ----
F="$(newfnd tu4b)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a contracts/a.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text 'assessed: coherent' >/dev/null 2>&1
  scripts/ratify.sh hunt SET-0001 --method 'seeded grep' --candidates ZERO --residual 'seeded' --verdict CLEAR >/dev/null 2>&1
  out="$(scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band 2>&1)"; rc=$?
  { [[ $rc -ne 0 ]] && echo "$out" | grep -qi 'U4B conformance NOT satisfied'; } ) \
  && ok "U4B conformance MISSING → MERGE HALT (fail-closed, non-overridable)" || no "U4B conformance MISSING → MERGE HALT"

# ---- REQ-FOOTPRINT (§2.2): the shipped FLIP probe runs GREEN on the post-fold bytes ----
# (14 internal claims incl. the seeded FOOTPRINT-MISS discrimination + mint idempotency/stagger.)
F="$(newfnd tflip1)"; ( cd "$F"
  bash probes/set-gate/probe_footprint_coverage_flip.sh >/dev/null 2>&1 ) \
  && ok "REQ-FOOTPRINT FLIP probe → GREEN on post-fold bytes (fold done-check)" \
  || no "REQ-FOOTPRINT FLIP probe → GREEN"

# ---- REQ-HUNT (§2.3): the shipped FLIP probe runs GREEN on the post-fold bytes ----
# (15 internal claims incl. empty/UNABLE/CLEAR-ZERO-no-method refusals + SHARED-RECORD + substrates.)
F="$(newfnd tflip2)"; ( cd "$F"
  bash probes/set-gate/probe_semantic_hunt_flip.sh >/dev/null 2>&1 ) \
  && ok "REQ-HUNT FLIP probe → GREEN on post-fold bytes (fold done-check)" \
  || no "REQ-HUNT FLIP probe → GREEN"

# ---- REQ-COST (§2.4a): filled caps + under-cap rows → exit 0 ----
F="$(newfnd tcost)"; ( cd "$F"
  printf 'caps:\n  per_unit_usd: 1.00\n  per_cohort_usd: 10.00\nusage_ledger: ledger/usage/usage.jsonl\nprices:\n  tokens-in: 0.000003\n' > contracts/COST-CAPS.md
  printf '%s\n' '{"unit_id":"u1","cohort_id":"c1","meter":"tokens-in","tokens":100000,"at":"x"}' > ledger/usage/usage.jsonl
  bash scripts/cost-guard.sh check --unit u1 --cohort c1 >/dev/null 2>&1 ) \
  && ok "REQ-COST under-cap → exit 0 (metered gate proceeds)" || no "REQ-COST under-cap → exit 0"

# ---- REQ-COST (§2.4b): at/over cap → exit 2 with the COST-CAP HALT-LOUD shape ----
( cd "$F"
  printf '%s\n' '{"unit_id":"u1","cohort_id":"c1","meter":"api","usd_actual":2.50,"at":"x"}' >> ledger/usage/usage.jsonl
  out="$(bash scripts/cost-guard.sh check --unit u1 2>&1)"; rc=$?
  { [[ $rc -eq 2 ]] && echo "$out" | grep -q 'COST-CAP unit=u1'; } ) \
  && ok "REQ-COST over-cap → exit 2 + COST-CAP HALT-LOUD" || no "REQ-COST over-cap → exit 2 + COST-CAP"

# ---- REQ-COST (§2.4c): the SHIPPED (unfilled) caps slot → exit 3 (never assume zero) ----
F="$(newfnd tcost3)"; ( cd "$F"
  out="$(bash scripts/cost-guard.sh check --unit u1 2>&1)"; rc=$?
  { [[ $rc -eq 3 ]] && echo "$out" | grep -qi 'UNFILLED'; } ) \
  && ok "REQ-COST shipped-unfilled caps slot → exit 3 HALT (fail-closed slot; ENGINE-LAW)" \
  || no "REQ-COST unfilled caps → exit 3 HALT"

# ============================================================================
# v2.5.6 §5 — Issue 1/2/3 seeded faults (census single-source · guard bypass · receipt fail-open)
# ============================================================================

# ---- Issue 1 / reap: a ratified MODULE member reaching reap with a NEW-census set-auth path → HALT 2 ----
# The exact gap that let Issue 1 seal: reap's stale SPINE_RE omitted seats.yaml, so a module carrying it
# (via a --no-verify bypass) merged clean. Ratified first so the HALT is the SPINE-SUBSTRATE backstop
# (step 8, the census fix), NOT the NO-CHERRY-PICK membership gate.
F="$(newfnd t56_reapmod)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a seats.yaml
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text ok >/dev/null 2>&1
  merge_ready SET-0001 m1
  scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band >/dev/null 2>&1
  git add -A; git commit -q -m 'ratify SET-0001' --no-verify
  git checkout -q -b module/module-a
  printf 'seats:\n  - foundation\n' > seats.yaml; git add seats.yaml; git commit -q -m 'lane forges seats.yaml (bypass)' --no-verify
  git checkout -q main
  out="$(scripts/reap_at_merge.sh module-a 2>&1)"; rc=$?
  { [[ $rc -eq 2 ]] && echo "$out" | grep -q 'beyond lane authority' && echo "$out" | grep -q 'seats.yaml'; } ) \
  && ok "§5 Issue-1 reap: module NEW-census path (seats.yaml) → HALT exit 2 (the seal-miss, now caught)" \
  || no "§5 Issue-1 reap module NEW-census (seats.yaml) → HALT exit 2"

# ---- Issue 1 / reap regression: an OLD-census path (contracts/) still HALTs at reap ----
F="$(newfnd t56_reapold)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a contracts/x.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text ok >/dev/null 2>&1
  merge_ready SET-0001 m1
  scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band >/dev/null 2>&1
  git add -A; git commit -q -m 'ratify SET-0001' --no-verify
  git checkout -q -b module/module-a
  mkdir -p contracts; echo x > contracts/x.md; git add contracts/x.md; git commit -q -m 'lane edits contracts/ (bypass)' --no-verify
  git checkout -q main
  out="$(scripts/reap_at_merge.sh module-a 2>&1)"; rc=$?
  { [[ $rc -eq 2 ]] && echo "$out" | grep -q 'contracts/x.md'; } ) \
  && ok "§5 Issue-1 reap: OLD-census path (contracts/) still HALTs (no regression)" \
  || no "§5 Issue-1 reap OLD-census (contracts/) → HALT exit 2"

# ---- Issue 1 / reap: an EXECUTOR lane with a NEW-census set-auth path → HALT exit 2 ----
F="$(newfnd t56_reapexec)"; ( cd "$F"
  git checkout -q -b executor
  printf 'seats:\n  - foundation\n' > seats.yaml; git add seats.yaml; git commit -q -m 'executor forges seats.yaml' --no-verify
  git checkout -q main
  out="$(scripts/reap_at_merge.sh executor 2>&1)"; rc=$?
  { [[ $rc -eq 2 ]] && echo "$out" | grep -q 'seats.yaml'; } ) \
  && ok "§5 Issue-1 reap: executor NEW-census path (seats.yaml) → HALT exit 2 (carve-out is apply-receipts only)" \
  || no "§5 Issue-1 reap executor NEW-census (seats.yaml) → HALT exit 2"

# ---- Issue 1 / reap control: executor ledger/apply-receipts/ still PERMITTED (carve-out intact) ----
F="$(newfnd t56_reapexecok)"; ( cd "$F"
  git checkout -q -b executor
  mkdir -p ledger/apply-receipts/executor
  printf '%s\n' '{"receipt_id":"R-x-executor-1","content_sha":"a","provisional":true}' > ledger/apply-receipts/executor/run.jsonl
  git add -A; git commit -q -m 'executor apply receipt' --no-verify
  git checkout -q main
  scripts/reap_at_merge.sh executor >/dev/null 2>&1 ) \
  && ok "§5 Issue-1 reap control: executor ledger/apply-receipts/ → still PERMITTED (carve-out intact)" \
  || no "§5 Issue-1 reap executor apply-receipts → PERMITTED"

# ---- Issue 1 / parity probe: single-sourced → PASS ; a reintroduced literal → FAIL ----
F="$(newfnd t56_paritypass)"; ( cd "$F"
  bash probes/foundation/probe_census_parity.sh >/dev/null 2>&1 ) \
  && ok "§5 Issue-1 census-parity probe → PASS (all consumers single-sourced)" \
  || no "§5 Issue-1 census-parity probe → PASS"
F="$(newfnd t56_parityfail)"; ( cd "$F"
  printf "SPINE_RE='^(ledger/|contracts/)'\n" >> scripts/reap_at_merge.sh   # reintroduce drift
  out="$(bash probes/foundation/probe_census_parity.sh 2>&1)"; rc=$?
  { [[ $rc -eq 1 ]] && echo "$out" | grep -q 'CENSUS-PARITY FAIL' && echo "$out" | grep -q 'reap_at_merge.sh'; } ) \
  && ok "§5 Issue-1 census-parity probe → FAIL on a reintroduced census literal (drift caught)" \
  || no "§5 Issue-1 census-parity probe → FAIL on drift"

# ---- Issue 1 / state-prop: set-auth spine change without STATE.md → FAIL ; with STATE.md → PASS ----
F="$(newfnd t56_stateprop)"; ( cd "$F"
  printf 'seats:\n  - foundation\n' > seats.yaml; git add seats.yaml; git commit -q -m 'set-auth change, no STATE' --no-verify
  out="$(bash probes/foundation/probe_state_propagation.sh 2>&1)"; rc=$?
  { [[ $rc -eq 1 ]] && echo "$out" | grep -q 'STATE-PROP FAIL' && echo "$out" | grep -q 'seats.yaml'; } ) \
  && ok "§5 Issue-1 state-prop: set-auth change (seats.yaml) w/o STATE.md → FAIL (now sees set-auth paths)" \
  || no "§5 Issue-1 state-prop set-auth-no-STATE → FAIL"
F="$(newfnd t56_statepropok)"; ( cd "$F"
  printf 'seats:\n  - foundation\n' > seats.yaml; echo pin > _orchestration/STATE.md
  git add seats.yaml _orchestration/STATE.md; git commit -q -m 'set-auth change + STATE refresh' --no-verify
  bash probes/foundation/probe_state_propagation.sh >/dev/null 2>&1 ) \
  && ok "§5 Issue-1 state-prop control: set-auth change + STATE.md refresh → PASS" \
  || no "§5 Issue-1 state-prop control (+STATE.md) → PASS"

# ---- Issue 2 / guard-command-shape: git-global bypass + fail-closed stdin + no false positives ----
GUARD="$ENGINE/scripts/guard-command-shape.sh"
gtest() { # label expected(DENY|ALLOW) raw-stdin
  local rc; printf '%s' "$3" | bash "$GUARD" >/dev/null 2>&1; rc=$?
  local got=ALLOW; [ $rc -eq 2 ] && got=DENY
  [ "$got" = "$2" ] && ok "§5 Issue-2 guard: $1 → $2" || no "§5 Issue-2 guard: $1 (exp $2 got $got)"
}
gtest "git -C /tmp commit --no-verify (global before subcmd)" DENY '{"tool_input":{"command":"git -C /tmp commit --no-verify"}}'
gtest "git --no-pager commit -n"                DENY  '{"tool_input":{"command":"git --no-pager commit -n"}}'
gtest "git -c core.hooksPath=/dev/null commit"  DENY  '{"tool_input":{"command":"git -c core.hooksPath=/dev/null commit"}}'
gtest "malformed-JSON stdin (fail-closed)"      DENY  '{"tool_input":{"command":'
gtest "benign echo -n hi"                       ALLOW '{"tool_input":{"command":"echo -n hi"}}'
gtest "normal git commit -m"                    ALLOW '{"tool_input":{"command":"git commit -m ship"}}'

# ---- Issue 3 / receipt-ledger: malformed line HALTs both verbs; real dup still HALTs; blank/comment ok ----
RL="$ENGINE/scripts/receipt-ledger.py"
TL="$SBX/rl3"
rm -rf "$TL"; mkdir -p "$TL/ledger/apply-receipts/x"
printf '%s\n%s\n' '{"receipt_id":"R1","content_sha":"a","provisional":true}' '{ this is not json' > "$TL/ledger/apply-receipts/x/r.jsonl"
python3 "$RL" canonicalize "$TL" >/dev/null 2>&1; [ $? -eq 3 ] \
  && ok "§5 Issue-3 receipt canonicalize: malformed line → HALT exit 3 (was silently passed through)" \
  || no "§5 Issue-3 canonicalize malformed line → exit 3"
rm -rf "$TL"; mkdir -p "$TL/ledger"
printf '%s\n%s\n' '{"receipt_id":"R1","content_sha":"a"}' '@@ corrupt @@' > "$TL/ledger/receipts.jsonl"
python3 "$RL" check-unique "$TL" >/dev/null 2>&1; [ $? -eq 3 ] \
  && ok "§5 Issue-3 receipt check-unique: malformed line → HALT exit 3 (was invisible to uniqueness)" \
  || no "§5 Issue-3 check-unique malformed line → exit 3"
printf '%s\n%s\n' '{"receipt_id":"R1","content_sha":"a"}' '{"receipt_id":"R1","content_sha":"b"}' > "$TL/ledger/receipts.jsonl"
python3 "$RL" check-unique "$TL" >/dev/null 2>&1; [ $? -eq 1 ] \
  && ok "§5 Issue-3 receipt check-unique: real duplicate (well-formed) → FAIL exit 1 (regression)" \
  || no "§5 Issue-3 check-unique real duplicate → exit 1"
printf '\n# comment\n%s\n\n%s\n' '{"receipt_id":"R1","content_sha":"a"}' '{"receipt_id":"R2","content_sha":"b"}' > "$TL/ledger/receipts.jsonl"
python3 "$RL" check-unique "$TL" >/dev/null 2>&1; [ $? -eq 0 ] \
  && ok "§5 Issue-3 receipt check-unique: blank + #comment lines tolerated → PASS exit 0" \
  || no "§5 Issue-3 check-unique blank/comment tolerated → exit 0"
rm -rf "$TL"

# ============================================================================
# v2.5.6 r3 — Blocker 1 (probe_set_gate 5th census) + Blocker 2 (behavioral parity)
# ============================================================================

# ---- r3 B1: a --no-verify SLOTS.md commit UNCOVERED by any ratified set → probe_set_gate FAIL ----
# (The pre-r3 hand-typed case omitted SLOTS.md, so this exact bypass was invisible to the probe.)
F="$(newfnd t3b1a)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a contracts/base.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text ok >/dev/null 2>&1
  merge_ready SET-0001 m1
  scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band >/dev/null 2>&1
  git add -A; git commit -q -m 'ratify SET-0001' --no-verify
  echo 'forged slot' > SLOTS.md; git add SLOTS.md; git commit -q -m 'uncovered SLOTS.md bypass' --no-verify
  out="$(bash probes/foundation/probe_set_gate.sh 2>&1)"; rc=$?
  { [[ $rc -eq 1 ]] && echo "$out" | grep -q 'SLOTS.md'; } ) \
  && ok "r3-B1 --no-verify SLOTS.md uncovered → probe_set_gate FAIL (the 5th-census miss, now caught)" \
  || no "r3-B1 uncovered SLOTS.md → probe_set_gate FAIL"

# ---- r3 B1 control: SLOTS.md covered by a ratified member → probe_set_gate PASS ----
F="$(newfnd t3b1b)"; ( cd "$F"
  mint_req module-a
  add_member m1 module-a SLOTS.md
  scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
  scripts/ratify.sh assess SET-0001 --text ok >/dev/null 2>&1
  merge_ready SET-0001 m1
  scripts/ratify.sh ratify SET-0001 --by op --rationale-class in-band >/dev/null 2>&1
  git add -A; git commit -q -m 'ratify SET-0001' --no-verify
  echo 'slot inventory' > SLOTS.md; git add SLOTS.md; git commit -q -m 'covered SLOTS.md' --no-verify
  bash probes/foundation/probe_set_gate.sh >/dev/null 2>&1 ) \
  && ok "r3-B1 control: SLOTS.md covered by ratified set → probe_set_gate PASS" \
  || no "r3-B1 control covered SLOTS.md → PASS"
# (regression — an OLD-case path uncovered still FAILs — is the standing M7 planted-bypass case above.)

# ---- r3 B2(a): probe_set_gate census drifts in CASE form (drops SLOTS.md) → parity FAIL naming file+path ----
F="$(newfnd t3b2a)"; ( cd "$F"
  awk '{print} /^is_authored_spine\(\) \{$/{print "    case \"$1\" in SLOTS.md) return 1 ;; esac"}' \
      probes/foundation/probe_set_gate.sh > .t && mv .t probes/foundation/probe_set_gate.sh
  out="$(bash probes/foundation/probe_census_parity.sh 2>&1)"; rc=$?
  { [[ $rc -eq 1 ]] && echo "$out" | grep -q 'probe_set_gate.sh' && echo "$out" | grep -q 'SLOTS.md'; } ) \
  && ok "r3-B2(a) set-gate census drift (case form, sans SLOTS.md) → parity FAIL naming file+path" \
  || no "r3-B2(a) case-form drift in probe_set_gate → parity FAIL"

# ---- r3 B2(c): a NON-assignment divergence in ANOTHER enforcer (reap drops seats.yaml via case) → parity FAIL ----
F="$(newfnd t3b2c)"; ( cd "$F"
  awk '{print} /^is_spine\(\) \{$/{print "    case \"$1\" in seats.yaml) return 1 ;; esac"}' \
      scripts/reap_at_merge.sh > .t && mv .t scripts/reap_at_merge.sh
  out="$(bash probes/foundation/probe_census_parity.sh 2>&1)"; rc=$?
  { [[ $rc -eq 1 ]] && echo "$out" | grep -q 'reap_at_merge.sh' && echo "$out" | grep -q 'seats.yaml'; } ) \
  && ok "r3-B2(c) case-form divergence in reap (drops seats.yaml) → parity FAIL (behavioral, any form)" \
  || no "r3-B2(c) case-form divergence in reap → parity FAIL"

# ---- r3 B2 fail-closed: an enforcer refactored away from the driveable shape → parity FAIL ----
F="$(newfnd t3b2f)"; ( cd "$F"
  sed 's/^is_spine_path()/renamed_fn()/' scripts/ratify.sh > .t && mv .t scripts/ratify.sh
  out="$(bash probes/foundation/probe_census_parity.sh 2>&1)"; rc=$?
  { [[ $rc -eq 1 ]] && echo "$out" | grep -q 'cannot extract/drive'; } ) \
  && ok "r3-B2 fail-closed: undriveable enforcer (fn renamed) → parity FAIL (never assume clean)" \
  || no "r3-B2 fail-closed undriveable enforcer → parity FAIL"
# (r3 B2(b)/(d) unified → PASS = the standing t56 parity-PASS case above, now behavioral.)

# ---- positive control: foundation commits a NON-spine file → PASS ----
F="$(newfnd tpc)"; ( cd "$F"
  echo 'notes' > docs/notes.md; git add docs/notes.md; git commit -m 'notes' >/dev/null 2>&1 ) \
  && ok "positive control: non-spine foundation commit PASSES" || no "positive control: non-spine foundation commit PASSES"

echo
echo "== set-gate acceptance: PASS=$PASS FAIL=$FAIL =="
[[ $FAIL -eq 0 ]]
