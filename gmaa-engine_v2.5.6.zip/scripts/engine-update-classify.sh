#!/usr/bin/env bash
# scripts/engine-update-classify.sh — the MECHANICAL half of the engine update (docs/ENGINE-UPDATE.md
# step B2; FIX-ORDER r4 §2.10). Classification is CODE — foundation's judgment goes ONLY to the
# per-conflict rulings (DISC-LLM-AT-THE-EDGES: no model inside the classifier).
#
#   engine-update-classify.sh --old-manifest F --new-manifest F --slots F --adopter DIR [--changelog F]
#
# Inputs: OLD baseline MANIFEST.sha256 · NEW baseline MANIFEST.sha256 · SLOTS.md (the slot inventory —
# the SLOT-FILL source of truth) · the adopter tree root · the NEW baseline's CHANGELOG.md (for the
# `Slot-contract changes` heading; omit only if the NEW baseline ships none).
#
# Output — the classified diff:
#   ENGINE-DELTA        OLD→NEW baseline changes (ADDED/CHANGED/REMOVED) — the apply list.
#   PRESERVE-FILL       adopter divergence on a SLOTS.md surface where a shipped `{{TOKEN}}` was
#                       FILLED (token present in OLD baseline byte, absent in the adopter file) —
#                       preserve; re-apply where the slot contract is unchanged.
#   PRESERVE-GENERATED  adopter divergence on GENERATED GOVERNANCE (FOUNDATION.md · seats.yaml ·
#                       CHECKLIST · register · ledgers incl. PENDING-SET.md · session_state ·
#                       charters/BOOTSTRAP · relay/dispatch dirs · content) — preserve, never touched.
#   CONFLICT            adopter ENGINE-DRIFT (a hand-edited or deleted engine file) — SURFACE it;
#                       foundation rules per file, NEVER overwrites an unclassified/conflicted file.
#   STOP                a FILLED slot whose CONTRACT MOVED per the NEW CHANGELOG's `Slot-contract
#                       changes` heading — foundation never resolves a moved slot alone (operator door).
#
# Exit codes: 0 = classified, no STOP · 2 = STOP present (moved filled slot — halt the update) ·
#             3 = unreadable input (fail-closed; a classification over missing inputs is a blind check).
set -u

die3() { echo "engine-update-classify HALT (fail-closed): $*" >&2; exit 3; }
cnt()  { [[ -s "$1" ]] && grep -c '' "$1" || echo 0; }

OLDM="" NEWM="" SLOTS="" ADOPTER="" CHANGELOG=""
while [[ $# -gt 0 ]]; do case "$1" in
    --old-manifest) OLDM="${2:-}";     shift 2 ;;
    --new-manifest) NEWM="${2:-}";     shift 2 ;;
    --slots)        SLOTS="${2:-}";    shift 2 ;;
    --adopter)      ADOPTER="${2:-}";  shift 2 ;;
    --changelog)    CHANGELOG="${2:-}"; shift 2 ;;
    *) die3 "unknown arg '$1' (usage: --old-manifest F --new-manifest F --slots F --adopter DIR [--changelog F])" ;;
esac; done
[[ -f "$OLDM" ]]    || die3 "--old-manifest '$OLDM' not readable."
[[ -f "$NEWM" ]]    || die3 "--new-manifest '$NEWM' not readable."
[[ -f "$SLOTS" ]]   || die3 "--slots '$SLOTS' not readable (SLOTS.md is the SLOT-FILL source of truth)."
[[ -d "$ADOPTER" ]] || die3 "--adopter '$ADOPTER' is not a directory."
[[ -z "$CHANGELOG" || -f "$CHANGELOG" ]] || die3 "--changelog '$CHANGELOG' not readable."

T="$(mktemp -d 2>/dev/null || mktemp -d -t euclassify)"; trap 'rm -rf "$T"' EXIT

# --- normalize manifests to "sha<TAB>path" (strip leading ./) ---
norm_manifest() { awk '{sha=$1; $1=""; sub(/^[ \t*]+/,""); p=$0; sub(/^\.\//,"",p); if (sha != "" && p != "") print sha "\t" p}' "$1"; }
norm_manifest "$OLDM" > "$T/old.tsv"
norm_manifest "$NEWM" > "$T/new.tsv"
[[ -s "$T/old.tsv" ]] || die3 "OLD manifest parsed to zero rows."
[[ -s "$T/new.tsv" ]] || die3 "NEW manifest parsed to zero rows."

# --- SLOTS.md: token -> surface map (table rows only; first cell tokens, second cell first
#     path-like backticked string; a token-cell with no path in its own row carries the previous
#     row's surface — the "same skeleton" convention). ---
awk -F'|' '
    /^\|/ {
        c1=$2; c2=$3
        n = 0
        while (match(c1, /\{\{[A-Za-z0-9_]+\}\}/)) { toks[++n] = substr(c1, RSTART, RLENGTH); c1 = substr(c1, RSTART+RLENGTH) }
        if (n == 0) next
        surf = ""
        tmp = c2
        while (match(tmp, /`[^`]+`/)) {
            cand = substr(tmp, RSTART+1, RLENGTH-2); tmp = substr(tmp, RSTART+RLENGTH)
            if (cand ~ /\// || cand ~ /\.[A-Za-z]/) { if (cand !~ /\{\{/) { surf = cand; break } }
        }
        if (surf != "") last = surf; else surf = last
        if (surf == "") next
        for (i = 1; i <= n; i++) print toks[i] "\t" surf
    }' "$SLOTS" > "$T/slots.tsv"

# --- moved slots: {{TOKEN}}s named in the NEW CHANGELOG newest entry under `Slot-contract changes` ---
: > "$T/moved.txt"
if [[ -n "$CHANGELOG" ]]; then
    awk '
        /^##[^#]/ { ver++ }                     # version entries (## headings); newest = first
        ver > 1 { exit }
        /Slot-contract changes/ { inblock = 1 }
        inblock && /^[ \t]*$/ && seen { exit }  # blank line after content ends the block
        inblock { seen = 1
            s = $0
            while (match(s, /\{\{[A-Za-z0-9_]+\}\}/)) { print substr(s, RSTART, RLENGTH); s = substr(s, RSTART+RLENGTH) }
        }' "$CHANGELOG" | sort -u > "$T/moved.txt"
fi

# --- GENERATED GOVERNANCE set (FIX-ORDER r4 §2.10 list, as path patterns) ---
is_generated() {
    case "$1" in
        docs/FOUNDATION.md|seats.yaml|CHECKLIST.md|issues_register.md|PENDING-SET.md) return 0 ;;
        .claude/session_state.json) return 0 ;;
        ledger/*|_boot/*|_orchestration/relay-outbox/*|dispatch/*|content/*) return 0 ;;
    esac
    return 1
}

# --- ENGINE DELTA (OLD→NEW): ADDED / CHANGED / REMOVED ---
sort -t"$(printf '\t')" -k2 "$T/old.tsv" > "$T/old.sorted"
sort -t"$(printf '\t')" -k2 "$T/new.tsv" > "$T/new.sorted"
awk -F'\t' 'NR==FNR { old[$2]=$1; next }
    { if (!($2 in old)) print "ADDED\t" $2; else if (old[$2] != $1) print "CHANGED\t" $2; seen[$2]=1 }
    END { for (p in old) if (!(p in seen)) print "REMOVED\t" p }' "$T/old.sorted" "$T/new.sorted" | sort -k2 > "$T/delta.tsv"

# --- classify adopter divergence over every OLD-manifest path ---
: > "$T/fill.txt"; : > "$T/gen.txt"; : > "$T/conflict.txt"; : > "$T/stop.txt"
while IFS=$'\t' read -r osha path; do
    if [[ ! -f "$ADOPTER/$path" ]]; then
        echo "$path	(MISSING in adopter tree — drift by deletion; rule per file)" >> "$T/conflict.txt"
        continue
    fi
    asha="$(shasum -a 256 "$ADOPTER/$path" | awk '{print $1}')"
    [[ "$asha" == "$osha" ]] && continue
    if is_generated "$path"; then
        echo "$path" >> "$T/gen.txt"
        continue
    fi
    # slot surface? — a shipped token present in the OLD baseline byte for THIS surface and absent
    # in the adopter file = a FILL. (The OLD baseline byte is authoritative for "shipped with the
    # token": we test the adopter file against each token SLOTS.md maps to this surface.)
    filled=""
    while IFS=$'\t' read -r tok surf; do
        [[ "$surf" == "$path" ]] || continue
        if ! grep -qF "$tok" "$ADOPTER/$path" 2>/dev/null; then
            filled="${filled:+$filled,}$tok"
            if grep -qxF "$tok" "$T/moved.txt" 2>/dev/null; then
                echo "$tok	$path" >> "$T/stop.txt"
            fi
        fi
    done < "$T/slots.tsv"
    if [[ -n "$filled" ]]; then
        echo "$path	(filled: $filled)" >> "$T/fill.txt"
    else
        echo "$path" >> "$T/conflict.txt"
    fi
done < "$T/old.sorted"

# --- report ---
echo "== engine-update-classify =="
echo "old-manifest: $OLDM ($(cnt "$T/old.tsv") rows) · new-manifest: $NEWM ($(cnt "$T/new.tsv") rows) · adopter: $ADOPTER"
echo
echo "-- ENGINE-DELTA (apply; OLD→NEW baseline) --"
if [[ -s "$T/delta.tsv" ]]; then sed 's/^/  /' "$T/delta.tsv"; else echo "  (none)"; fi
echo
echo "-- PRESERVE-FILL (slot fills; re-apply where the slot contract is unchanged) --"
if [[ -s "$T/fill.txt" ]]; then sed 's/^/  /' "$T/fill.txt"; else echo "  (none)"; fi
echo
echo "-- PRESERVE-GENERATED (governance surfaces; never touched by the update) --"
if [[ -s "$T/gen.txt" ]]; then sed 's/^/  /' "$T/gen.txt"; else echo "  (none)"; fi
echo
echo "-- CONFLICT (adopter engine-drift; foundation rules per file, NEVER overwrites) --"
if [[ -s "$T/conflict.txt" ]]; then sed 's/^/  /' "$T/conflict.txt"; else echo "  (none)"; fi
echo
if [[ -s "$T/stop.txt" ]]; then
    echo "-- STOP (filled slot whose CONTRACT MOVED per the NEW CHANGELOG 'Slot-contract changes') --"
    sed 's/^/  STOP: /' "$T/stop.txt"
    echo "  ⚠ HALT the update: foundation never resolves a moved slot alone (operator door; docs/ENGINE-UPDATE.md B3)."
    echo
    echo "SUMMARY: delta=$(cnt "$T/delta.tsv") fill=$(cnt "$T/fill.txt") generated=$(cnt "$T/gen.txt") conflict=$(cnt "$T/conflict.txt") STOP=$(cnt "$T/stop.txt")"
    exit 2
fi
echo "SUMMARY: delta=$(cnt "$T/delta.tsv") fill=$(cnt "$T/fill.txt") generated=$(cnt "$T/gen.txt") conflict=$(cnt "$T/conflict.txt") STOP=0"
exit 0
