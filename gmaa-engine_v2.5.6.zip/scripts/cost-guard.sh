#!/usr/bin/env bash
# scripts/cost-guard.sh — the COST-BRAKE (C-SET-AUTHORIZATION §2.4; REQ-COST).
#
#   check --unit <id> [--cohort <id>]   read the usage LEDGER, price the rows, compare to caps.
#
# Exit codes (CLOSED set, §2.4):
#   0  under cap
#   2  at/over cap        — HALT-LOUD `COST-CAP unit=… spent=… cap=…`; the caller STOPS, never
#                           auto-continues (halt-loud invariant).
#   3  unreadable         — HALT, never "assume zero": a missing/unparseable ledger, an unpriceable
#                           row, or an UNFILLED caps slot is BLINDNESS, and blindness is a STOP
#                           (the sampled-telemetry scar INVERTED — reading nothing must never read
#                           as $0 spent).
#
# LAW (§2.4): read the ledger you write — one durable row per metered call, via the sanctioned
# write mechanism, NEVER sampled telemetry. Call site = TOP of the next metered gate (+ once at
# cohort enqueue), not after the prior write. Failure asymmetry: a usage-WRITE failure is
# log-and-continue (a usage write must not crash a verdict); a usage-READ failure HERE is a HALT.
#
# AUTHORSHIP (packaging arm, to the §2.4 spec — "the packaging arm ships the script + an EMPTY
# caps slot"): the caps + prices are CONFIG in contracts/COST-CAPS.md (operator-movable; the
# adopter fills them — the source program's own cap numbers do NOT ship). The shipped caps slot is
# UNFILLED by design → a metered path checked against the unfilled slot HALTs (exit 3) until the
# adopter fills it (ENGINE-LAW: an unreadable property never PASSes; fail-closed SLOTS, not
# smarter inference).
#
# Reference ledger shape (JSONL, one row per metered call; adopters with a DB point usage_ledger
# at an exported/materialized row file via their C-DB mechanism):
#   {"unit_id":"<id>","cohort_id":"<id|->","meter":"<meter>","tokens":<n>,"usd_actual":<usd>,"at":"<UTC>"}
# Pricing: usd_actual when present; else tokens × prices.<meter> (per-token USD) from COST-CAPS.md.
# A row with neither usd_actual nor a priceable meter → UNREADABLE (exit 3), never skipped.
set -u

die3() { echo "cost-guard HALT (unreadable — never assume zero): $*" >&2; exit 3; }
repo_root() { git rev-parse --show-toplevel 2>/dev/null || die3 "not inside a git worktree."; }

cmd_check() {
    local unit="" cohort=""
    while [[ $# -gt 0 ]]; do case "$1" in
        --unit)   unit="${2:-}";   shift 2 ;;
        --cohort) cohort="${2:-}"; shift 2 ;;
        *) echo "cost-guard: unknown arg '$1'." >&2; exit 1 ;;
    esac; done
    [[ -n "$unit" ]] || { echo "cost-guard: --unit <id> is required.  usage: cost-guard.sh check --unit <id> [--cohort <id>]" >&2; exit 1; }

    local root caps; root="$(repo_root)"; caps="$root/contracts/COST-CAPS.md"
    [[ -f "$caps" ]] || die3 "caps slot missing: contracts/COST-CAPS.md not found (§2.4 — caps are config, not code)."

    # --- read caps (fail-closed on the unfilled slot: a {{…}} token is not a number) ---
    local per_unit per_cohort
    per_unit="$(sed -n 's/^[[:space:]]*per_unit_usd:[[:space:]]*//p' "$caps" | head -1 | tr -d ' ')"
    per_cohort="$(sed -n 's/^[[:space:]]*per_cohort_usd:[[:space:]]*//p' "$caps" | head -1 | tr -d ' ')"
    [[ -n "$per_unit" ]] || die3 "per_unit_usd missing from contracts/COST-CAPS.md."
    case "$per_unit$per_cohort" in *'{{'*) die3 "caps slot UNFILLED in contracts/COST-CAPS.md (per_unit_usd='$per_unit' per_cohort_usd='${per_cohort:-—}') — an unfilled slot on a metered path HALTs (ENGINE-LAW; §2.4). Fill the caps, or do not meter." ;; esac
    echo "$per_unit" | grep -qE '^[0-9]+(\.[0-9]+)?$' || die3 "per_unit_usd '$per_unit' is not a number."
    if [[ -n "$cohort" ]]; then
        [[ -n "$per_cohort" ]] || die3 "--cohort given but per_cohort_usd missing from contracts/COST-CAPS.md."
        echo "$per_cohort" | grep -qE '^[0-9]+(\.[0-9]+)?$' || die3 "per_cohort_usd '$per_cohort' is not a number."
    fi

    # --- locate the ledger (declared in the caps file; missing ledger at check = HALT, §2.4) ---
    local ledger_rel ledger
    ledger_rel="$(sed -n 's/^[[:space:]]*usage_ledger:[[:space:]]*//p' "$caps" | head -1 | tr -d ' ')"
    [[ -n "$ledger_rel" ]] || die3 "usage_ledger: not declared in contracts/COST-CAPS.md."
    case "$ledger_rel" in *'{{'*) die3 "usage_ledger slot UNFILLED in contracts/COST-CAPS.md." ;; esac
    ledger="$root/$ledger_rel"
    [[ -f "$ledger" ]] || die3 "usage ledger '$ledger_rel' not found — a missing ledger at check is a HALT, never \$0 (§2.4: read the ledger you write)."

    # --- price + sum the rows for the unit (and cohort), fail-closed on any unpriceable row ---
    # awk does the whole pass: extracts fields from each JSONL row; a row matching the unit/cohort
    # with no usd_actual AND no price for its meter → UNREADABLE (exit 3). Prices are read from the
    # caps file's `prices:` block (per-token USD; `<meter>: <number>` lines).
    local sums
    sums="$(awk -v unit="$unit" -v cohort="$cohort" -v capsfile="$caps" '
        BEGIN {
            # load prices: lines between /^prices:/ and the next top-level key
            inp = 0
            while ((getline line < capsfile) > 0) {
                if (line ~ /^prices:/)      { inp = 1; continue }
                if (inp && line ~ /^[^ \t#]/) { inp = 0 }
                if (inp) {
                    gsub(/#.*$/, "", line)
                    if (match(line, /^[ \t]+[A-Za-z0-9_.-]+:[ \t]*[0-9.]+[ \t]*$/)) {
                        key = line; sub(/^[ \t]+/, "", key); sub(/:.*$/, "", key)
                        val = line; sub(/^[^:]*:[ \t]*/, "", val); sub(/[ \t]*$/, "", val)
                        price[key] = val + 0
                    }
                }
            }
            close(capsfile)
        }
        function jstr(row, key,   m) { if (match(row, "\"" key "\":\"[^\"]*\"")) { m = substr(row, RSTART, RLENGTH); sub(/^[^:]*:"/, "", m); sub(/"$/, "", m); return m } return "" }
        function jnum(row, key,   m) { if (match(row, "\"" key "\":[0-9.]+"))    { m = substr(row, RSTART, RLENGTH); sub(/^[^:]*:/, "", m);  return m } return "" }
        /^[ \t]*$/ { next }
        {
            u = jstr($0, "unit_id"); c = jstr($0, "cohort_id"); mt = jstr($0, "meter")
            usd = jnum($0, "usd_actual"); tok = jnum($0, "tokens")
            hitu = (u == unit); hitc = (cohort != "" && c == cohort)
            if (!hitu && !hitc) next
            if (usd != "")           { v = usd + 0 }
            else if (tok != "" && mt != "" && (mt in price)) { v = (tok + 0) * price[mt] }
            else { bad = 1; printf "UNPRICEABLE\t%d\t%s\n", NR, $0; exit 9 }
            if (hitu) su += v
            if (hitc) sc += v
        }
        END { if (bad) exit 9; printf "OK\t%.6f\t%.6f\n", su + 0, sc + 0 }
    ' "$ledger")" || {
        case "$sums" in UNPRICEABLE*) die3 "usage row cannot be priced (no usd_actual, no prices.<meter> in COST-CAPS.md): ${sums#UNPRICEABLE	}" ;; esac
        die3 "usage ledger '$ledger_rel' unreadable."
    }
    case "$sums" in OK*) : ;; UNPRICEABLE*) die3 "usage row cannot be priced (no usd_actual, no prices.<meter> in COST-CAPS.md): ${sums#UNPRICEABLE	}" ;; *) die3 "usage ledger '$ledger_rel' unreadable." ;; esac
    local spent_u spent_c
    spent_u="$(printf '%s' "$sums" | cut -f2)"; spent_c="$(printf '%s' "$sums" | cut -f3)"

    # --- compare (at/over = HALT-LOUD exit 2; the shape §2.4 names) ---
    if awk -v s="$spent_u" -v c="$per_unit" 'BEGIN{exit !(s >= c)}'; then
        echo "COST-CAP unit=$unit spent=\$$spent_u cap=\$$per_unit — HALT (at/over per-unit cap; §2.4). Operator moves the cap or the unit stops." >&2
        exit 2
    fi
    if [[ -n "$cohort" ]] && awk -v s="$spent_c" -v c="$per_cohort" 'BEGIN{exit !(s >= c)}'; then
        echo "COST-CAP cohort=$cohort spent=\$$spent_c cap=\$$per_cohort — HALT (at/over per-cohort cap; §2.4). Operator moves the cap or the cohort stops." >&2
        exit 2
    fi
    echo "cost-guard: unit=$unit spent=\$$spent_u cap=\$$per_unit — under cap${cohort:+ (cohort=$cohort spent=\$$spent_c cap=\$$per_cohort)}."
    exit 0
}

case "${1:-}" in
    check) shift; cmd_check "$@" ;;
    ""|-h|--help) echo "usage: cost-guard.sh check --unit <id> [--cohort <id>]   (exit 0 under · 2 at/over HALT · 3 unreadable HALT; C-SET-AUTHORIZATION §2.4)" ;;
    *) echo "cost-guard: unknown verb '${1}' (expected: check)." >&2; exit 1 ;;
esac
