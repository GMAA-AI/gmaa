#!/usr/bin/env bash
# scripts/orc-up.sh — bring an orc lane up in two words.
# Fail-closed bootstrap check → named tmux session at the lane worktree → `claude --agent orc` → @orc reminder.
# Run from any worktree in the repo. Operator alias: orc-up.
#
# GENERICIZATION NOTE: the hardcoded instance-lane validation list is dropped in favour of
# FOLDER-EQUALS-LANE — any lane is accepted; the fail-closed worktree + _boot existence guard
# below is what actually validates it (a lane with no committed charter cannot launch).
set -u

lane="${1:?usage: orc-up.sh <lane>   (folder-equals-lane: e.g. foundation, executor, module-a)}"

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "orc-up: not in a git worktree" >&2; exit 2; }
PARENT="$(dirname "$REPO_ROOT")"
# Convention: FOLDER-EQUALS-LANE for every seat, foundation included — foundation's worktree folder is `foundation`.
# (The trunk BRANCH is still `main`; the foundation worktree is simply checked out to it. Branch name != folder name.)
wt="$PARENT/$lane"

# FAIL-CLOSED: charter-precedes-boot. The charter + bootstrap MUST be present before launch, else the
# orc would boot personaless / HALT. This guard is the shortcut's promise that it can't reintroduce an
# unconstrained boot.
[[ -d "$wt" ]]                        || { echo "orc-up: HALT — worktree '$wt' does not exist" >&2; exit 3; }
[[ -f "$wt/_boot/BOOTSTRAP.md" ]]     || { echo "orc-up: HALT — $wt/_boot/BOOTSTRAP.md missing (charter-precedes-boot not satisfied)" >&2; exit 3; }
[[ -f "$wt/_boot/CHARTER-$lane.md" ]] || { echo "orc-up: HALT — $wt/_boot/CHARTER-$lane.md missing" >&2; exit 3; }

# Already up? attach to it.
project="$("$(dirname "$0")/resolve-project.sh")"; rp=$?
if [[ $rp -eq 0 && -n "$project" ]]; then session="${project}-${lane}"
elif [[ $rp -eq 10 ]]; then session="${lane}"   # legacy form (canon §7.3); warning already printed
else echo "orc-up: project-token resolution failed (exit $rp)" >&2; exit 2; fi
if tmux has-session -t "$session" 2>/dev/null; then
  echo "orc-up: session '$lane' already live — attaching."
  exec tmux attach -t "$session"
fi

# Delegate to the ONE launcher (no second launch path): launch-orc.sh performs the template-stamp guard,
# hook-presence guard, project namespace, double-launch guard, GENESIS, per-seat agent/model/boot-prompt,
# then creates the named tmux session and attaches. orc-up is a thin fail-closed shortcut, not a fork.
[[ -x "$wt/launch-orc.sh" ]] || { echo "orc-up: HALT — $wt/launch-orc.sh missing or not executable (chmod +x launch-orc.sh scripts/*.sh)" >&2; exit 3; }
echo "orc-up: launching '$lane' via $wt/launch-orc.sh"
echo "  REMINDER: first message to the orc must begin '@orc' (spawn precondition) — then confirm 'BOOT-ACK: lane=$lane'."
cd "$wt" && exec ./launch-orc.sh
