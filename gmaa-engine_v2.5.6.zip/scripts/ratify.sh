#!/usr/bin/env bash
# scripts/ratify.sh — set-level authorization: assemble / assess / ratify.
# Canon §4 (apply-boundary set-evaluation) + §10 (agent assesses, independent human ratifies);
# schema = contracts/C-RATIFICATION-PACKET.md. Foundation-only (resolver-gated).
#
#   assemble [SET-NNNN]   read the FULL ledger + every pending member entry, compute the
#                         mechanical joint edges, write _ratification/SET-NNNN.md per the schema,
#                         mark those members `evaluated`. (M3 assembler + M4 joint-edge.)
#   assess   SET-NNNN --text '…' | --file F
#                         the INTEGRATOR AGENT (foundation orc) fills the ASSESSMENT slot
#                         (logic · evidence · live state · invariants; cites receipts). (M5)
#   conformance-check SET-NNNN <member> [--criteria F]
#                         U4B (§2.1) STRUCTURED checker: evaluate the member's machine-checkable
#                         acceptance criteria (_ratification/criteria/<member>.md) → record verdict.
#   conformance       SET-NNNN <member> --verdict PASS|FAIL --method structured|judgment --evidence '…'
#                         U4B (§2.1) verdict recorder — the BOUNDED-JUDGMENT-at-edge path for a prose
#                         criterion (SANCTIONED §2.1), or an out-of-band structured result.
#   ratify   SET-NNNN --by 'name' --rationale-class in-band|OUT-OF-BAND [--decision STATE] [...]
#                         the operator's pen ONLY: stamps the §3 DECISION + ratified-by/at/packet-sha;
#                         REFUSES if the assessment slot is empty, or (for a MERGE decision) any joint
#                         edge is unresolved. (M5, built up to our 5-state taxonomy.)
#
# SCAR (kept verbatim, canon §4 authority): serialized transport hides the set; it does not dissolve
# it. Members are each ratified alone; joint evaluation has never run — the incoherence that lives in
# their interaction reaches commit unseen. This mechanism converts per-change review into set-relative
# review at the apply boundary. It is ON TOP OF per-change review, never instead of it.
#
# GENERICIZATION NOTE (round-trip provenance): this engine's ratify.sh was lifted by the source
# program (at this engine's frozen 7a179264), hardened at its ENFORCED HEAD — the CLOSED 5-state
# decision taxonomy (C-RATIFICATION-PACKET §3/§5), U4B conformance (§2.1), the REQ-FOOTPRINT
# coverage gate (§2.2), the 3-layer joint-edge model + REQUIRED SEMANTIC-HUNT slot (§2.3) — and
# RE-SOURCED back whole (2026-08-19 set-authorization CUT). Mechanism verbatim; source-program
# ruling-numbers rule-stated; SPINE_PREFIXES read from the SHARED census emitter (scripts/spine-census.sh,
# v2.5.6 Issue-1 single-source — was a 4th hand-maintained copy). Consumes
# scripts/pending-set.sh + scripts/resolve-lane.sh + the PENDING-SET.md machine schema (incl. the
# SET-IDENTITY mint registry). scripts/declared-spine-paths.sh + scripts/receipt-ledger.py ship in
# this engine (-x/presence-guarded → graceful no-op only in a tree that lacks them).

set -u

die()  { echo "ratify: $*" >&2; exit 1; }
halt() { echo "ratify HALT: $*" >&2; exit 3; }
repo_root() { git rev-parse --show-toplevel 2>/dev/null || die "not inside a git worktree (fail-closed)."; }

# Spine-owned prefixes = the SHARED spine census (scripts/spine-census.sh = this engine's pre-commit
# base set + the adopter's HEAD-readback declared set, ruling #2) so "shared unforkable" joint-edge
# detection keys on the EXACT substrate the gate protects.
# ISSUE-1 FIX (v2.5.6): this SPINE_PREFIXES literal was a FOURTH hand-maintained census copy — the
# fix-order named only three consumers (pre-commit, reap, state-prop); the arm FOUND this one while
# scoping and folded it onto the single source. SURFACED to the architect: the order undercounted the
# census copies by one. Now generated (drift cannot recur; probe_census_parity.sh enforces it).
# bash 3.2 floor → read-loop, not mapfile. is_spine_path() below is UNCHANGED.
SPINE_PREFIXES=()
_census="$(git rev-parse --show-toplevel 2>/dev/null)/scripts/spine-census.sh"
if [[ -x "$_census" ]]; then while IFS= read -r _sp; do [[ -n "$_sp" ]] && SPINE_PREFIXES+=("$_sp"); done < <("$_census" 2>/dev/null); fi
# Fail-CLOSED if the census yielded nothing (script missing / exec bit lost): the old literal could
# never be empty; refuse to ratify with no spine knowledge rather than silently detect zero joint edges
# (invariant #5). Guards is_spine_path() from a raw empty-array `set -u` crash without altering it.
[[ ${#SPINE_PREFIXES[@]} -eq 0 ]] && halt "spine census empty — scripts/spine-census.sh missing/not-executable; cannot resolve the spine set for joint-edge detection (fail-closed)."
is_spine_path() { local f="$1" sp; for sp in "${SPINE_PREFIXES[@]}"; do case "$sp" in */) [[ "$f" == "$sp"* ]] && return 0;; *) [[ "$f" == "$sp" ]] && return 0;; esac; done; return 1; }

resolve_foundation() {
    local root resolver line; root="$(repo_root)"; resolver="$root/scripts/resolve-lane.sh"
    [[ -x "$resolver" ]] || die "lane resolver missing/not-executable at $resolver (fail-closed)."
    line="$("$resolver")" || die "lane UNRESOLVED (resolver exit != 0) — fail-closed."
    eval "$line"   # -> lane= role= ...
    [[ "${lane:-}" == "foundation" ]] || halt "assemble/assess/ratify run ONLY in the foundation worktree (got lane='${lane:-?}'). Module lanes contribute member entries; they NEVER write the packet."
}

# --- member model: read pending rows from PENDING-SET.md; deps from the SET-MEMBER entries. ---
# Emits, one member per line:  <id>\t<lane>\t<branch@sha>\t<surface,surface,…>
pending_members() {
    local root; root="$(repo_root)"
    "$root/scripts/pending-set.sh" list 2>/dev/null | awk -F'|' '
        { st=$7; gsub(/^[ \t]+|[ \t]+$/,"",st) }
        st=="pending" || st ~ /^evaluated/ {
            id=$3; ln=$4; br=$5; sf=$6
            gsub(/^[ \t]+|[ \t]+$/,"",id); gsub(/^[ \t]+|[ \t]+$/,"",ln)
            gsub(/^[ \t]+|[ \t]+$/,"",br); gsub(/^[ \t]+|[ \t]+$/,"",sf)
            print id"\t"ln"\t"br"\t"sf
        }'
}

# Declared dependencies for a member id (from its SET-MEMBER entry, if present).
member_deps() {
    local root id; root="$(repo_root)"; id="$1"
    local f; f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || { echo ""; return; }
    awk -F': ' '/^- self-declared dependencies:/ {print $2; exit}' "$f"
}

# REQ-FOOTPRINT (§2.2) — the member's parent requirement_id / minted set_id (from its SET-MEMBER entry).
member_reqid() {
    local root id f; root="$(repo_root)"; id="$1"
    f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || { echo ""; return; }
    awk -F': ' '/^- requirement id:/ {print $2; exit}' "$f"
}
member_setid() {
    local root id f; root="$(repo_root)"; id="$1"
    f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || { echo ""; return; }
    awk -F': ' '/^- set id:/ {print $2; exit}' "$f"
}

# Evidence receipts a member cites (from its SET-MEMBER "evidence receipts:" field), one id per line.
# Skips the "none-declared" sentinel. (§2.16 — these are the ids whose ledger uniqueness ratify verifies.)
member_receipts() {
    local root id; root="$(repo_root)"; id="$1"
    local f; f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || return
    awk -F': ' '/^- evidence receipts:/ {print $2; exit}' "$f" \
        | tr ',' '\n' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' \
        | grep -viE '^(none-declared|none)$' | grep -v '^$' || true
}

# REQ-HUNT (§2.3) — the member's declared cross-substrate effects (§4a multi-substrate manifest), raw
# string ('db: …; make: …; wp: …', or the 'git-surfaces-only' sentinel). Empty if no member file.
member_effects() {
    local root id f; root="$(repo_root)"; id="$1"
    f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || { echo ""; return; }
    awk '/^- declared effects/ {sub(/^[^:]*: /,""); print; exit}' "$f"
}

# REQ-HUNT (§2.3 Layer B — SoR shared-record class) — normalized STRUCTURE-OF-RECORD identifiers a member
# CITES, extracted from its surfaces + declared-effects, diffed cross-member against the §5 index namespace.
# MECHANICAL + INCOMPLETE-BY-DESIGN (canon §13, SAID-SO on the packet): sproc names (sp_*) and standing-probe
# ids (probe_*) are path/effect-embedded and reliably extractable; object names, seats.yaml keys, SLOTS.md ids
# and contract SECTIONS are NOT yet mechanized (a model may hand the integrator a candidate list — never a
# CLEAR stamp; Layer C carries the residual). One token per line, deduped.
record_tokens() {   # $1 = surfaces (comma list) ; $2 = declared-effects (raw)
    { printf '%s\n' "${1//,/ }"; printf '%s\n' "${2:-}"; } \
        | grep -oE 'sp_[a-z0-9_]+|probe_[a-z0-9_]+' 2>/dev/null \
        | sed -E 's/^(sp_[a-z0-9_]+)$/sproc:\1/; s/^(probe_[a-z0-9_]+)$/probe:\1/' \
        | sort -u
}

# REQ-HUNT (§2.3 footprint.substrates secondary cross-check; rule-stated) — the SoR SUBSTRATES a
# member writes. Any git surface = a git-spine effect; each declared-effect KEY maps to its §5 substrate.
# Flag (never hard-miss) when a member writes a substrate outside the requirement's declared footprint.
member_substrates() {   # $1 = surfaces (comma list) ; $2 = declared-effects (raw)
    local surf="$1" eff="${2:-}" key
    [[ -n "${surf//[[:space:],]/}" ]] && echo "git-spine"
    local -a _ES=(); IFS=';' read -ra _ES <<< "$eff"
    for key in ${_ES[@]+"${_ES[@]}"}; do key="${key%%:*}"; key="${key//[[:space:]]/}"
        case "$key" in
            db|sql|azure-sql)                   echo "azure-sql" ;;
            make)                               echo "make" ;;
            wp|wordpress)                       echo "wordpress" ;;
            fn|func|functions|azure-functions)  echo "azure-functions" ;;
            pa|power|power-platform)            echo "power-platform" ;;
            git|spine|git-spine)                echo "git-spine" ;;
        esac
    done
}
norm_substrate() { case "$1" in spine) echo "git-spine";; *) echo "$1";; esac; }

cmd_assemble() {
    resolve_foundation
    local root want="${1:-}"; root="$(repo_root)"
    mkdir -p "$root/_ratification"
    # Number: explicit SET-NNNN (collision → HALT) else mechanical = last packet at HEAD + 1.
    local num
    if [[ -n "$want" ]]; then
        [[ "$want" =~ ^SET-[0-9]{4}$ ]] || die "assemble: id must be SET-NNNN (got '$want')."
        [[ -e "$root/_ratification/$want.md" ]] && halt "numbering collision — $want already exists at HEAD. Assembly numbers are mechanical; resolve before re-assembling."
        num="${want#SET-}"
    else
        local last; last="$(ls "$root"/_ratification/SET-*.md 2>/dev/null | sed -E 's#.*/SET-([0-9]{4})\.md#\1#' | sort -n | tail -1)"
        num="$(printf '%04d' $(( 10#${last:-0} + 1 )) )"
        [[ -e "$root/_ratification/SET-$num.md" ]] && halt "numbering collision on SET-$num."
    fi
    local setid="SET-$num" packet="$root/_ratification/SET-$num.md"

    # Read members: collect ALL pending members; the REQ-FOOTPRINT gate below then verifies they
    # share ONE minted requirement/set identity (§2.2) — collection is broad, identity is enforced.
    local -a IDS=() LANES=() BRANCHES=() SURF=()
    while IFS=$'\t' read -r id lane branch surf; do
        [[ -z "$id" ]] && continue
        IDS+=("$id"); LANES+=("$lane"); BRANCHES+=("$branch"); SURF+=("$surf")
    done < <(pending_members)
    [[ ${#IDS[@]} -gt 0 ]] || halt "no pending members in the ledger — nothing to assemble."

    # --- M4: mechanical joint-edge detection (Layer A three classes + Layer B SoR shared-record; §2.3). ---
    local -a EDGES=()
    local i j
    # REQ-HUNT (§2.3 Layer B) — precompute each member's declared effects (§4a manifest) + its SoR record
    # tokens (sproc/probe ids) ONCE; the pairwise loop diffs these for cross-file SHARED-RECORD overlap.
    local -a EFFECTS=() TOKLIST=()
    for (( i=0; i<${#IDS[@]}; i++ )); do
        EFFECTS+=("$(member_effects "${IDS[$i]}")")
        TOKLIST+=("$(record_tokens "${SURF[$i]}" "${EFFECTS[$i]}" | tr '\n' ' ')")
    done
    for (( i=0; i<${#IDS[@]}; i++ )); do
        for (( j=i+1; j<${#IDS[@]}; j++ )); do
            # (a) overlapping paths + (b) shared unforkable = an overlap ON a spine-owned path.
            # (Two members touching DIFFERENT files — even both under a spine dir — are disjoint =
            # NONE; "shared unforkable" is a stronger flavor of an actual shared path, not a
            # both-touch-spine rule, per the M3 acceptance "disjoint members → NONE".)
            local shared="" unf=0 pi pj
            IFS=',' read -ra PI <<< "${SURF[$i]}"; IFS=',' read -ra PJ <<< "${SURF[$j]}"
            for pi in "${PI[@]}"; do pi="${pi// /}"; [[ -z "$pi" ]] && continue
                for pj in "${PJ[@]}"; do pj="${pj// /}"; [[ -z "$pj" ]] && continue
                    if [[ "$pi" == "$pj" ]]; then shared="${shared:+$shared, }$pi"; is_spine_path "$pi" && unf=1; fi
                done
            done
            if [[ -n "$shared" ]]; then
                if [[ $unf -eq 1 ]]; then
                    EDGES+=("${IDS[$i]} × ${IDS[$j]} — OVERLAPPING PATH(S) [shared unforkable — spine-owned]: $shared")
                else
                    EDGES+=("${IDS[$i]} × ${IDS[$j]} — OVERLAPPING PATH(S): $shared")
                fi
            fi
            # (c) declared-dependency reference / cycle
            local di dj; di="$(member_deps "${IDS[$i]}")"; dj="$(member_deps "${IDS[$j]}")"
            local iref=0 jref=0
            [[ "$di" == *"${IDS[$j]}"* ]] && iref=1
            [[ "$dj" == *"${IDS[$i]}"* ]] && jref=1
            if [[ $iref -eq 1 && $jref -eq 1 ]]; then
                EDGES+=("${IDS[$i]} × ${IDS[$j]} — DECLARED-DEPENDENCY CYCLE (each declares a dependency on the other)")
            elif [[ $iref -eq 1 ]]; then
                EDGES+=("${IDS[$i]} → ${IDS[$j]} — DECLARED DEPENDENCY (${IDS[$i]} reads a surface ${IDS[$j]} touches)")
            elif [[ $jref -eq 1 ]]; then
                EDGES+=("${IDS[$j]} → ${IDS[$i]} — DECLARED DEPENDENCY (${IDS[$j]} reads a surface ${IDS[$i]} touches)")
            fi
            # (d) REQ-HUNT Layer B (§2.3) — SoR SHARED-RECORD: the SAME record id (sproc/probe) cited by both
            # members via DIFFERENT files. Suppressed when they already share a path (Layer A OVERLAPPING PATH
            # covers that). This is the "both change sp_promote without touching the same file" case.
            if [[ -z "$shared" ]]; then
                local t t2
                for t in ${TOKLIST[$i]}; do
                    for t2 in ${TOKLIST[$j]}; do
                        [[ "$t" == "$t2" ]] && EDGES+=("${IDS[$i]} × ${IDS[$j]} — SHARED-RECORD [$t] (both members cite the same structure-of-record id via different files; §2.3 Layer B — integrator MUST assess)")
                    done
                done
            fi
        done
    done

    # === REQ-FOOTPRINT (§2.2) — footprint-coverage gate: fail-closed, before the packet is written. ===
    # (Members carry requirement_id + set_id from their SET-MEMBER manifest; the footprint.lanes come from
    #  the SET-IDENTITY registry, transcribed from the architect spec at mint. The gate reads STRUCTURE.)
    local -a REQIDS=() SETIDS=()
    local fm mrq msd
    for (( fm=0; fm<${#IDS[@]}; fm++ )); do
        mrq="$(member_reqid "${IDS[$fm]}")"; msd="$(member_setid "${IDS[$fm]}")"
        [[ -n "$mrq" ]] || halt "FOOTPRINT (§2.2(a)): member '${IDS[$fm]}' carries no requirement_id — not dispatchable without a parent requirement. Re-issue via 'pending-set.sh member … --requirement-id REQ-<id> --set-id SET-NNNN'. Fail-closed."
        [[ -n "$msd" ]] || halt "FOOTPRINT (§2.2(b)): member '${IDS[$fm]}' carries no set_id — mint + stamp a set_id before assembling. Fail-closed."
        REQIDS+=("$mrq"); SETIDS+=("$msd")
    done
    # (1) all assembled members share ONE requirement_id + ONE set_id.
    local rq0="${REQIDS[0]}" sd0="${SETIDS[0]}"
    for (( fm=1; fm<${#REQIDS[@]}; fm++ )); do
        [[ "${REQIDS[$fm]}" == "$rq0" ]] || halt "FOOTPRINT (§2.2(c)(1)): mixed requirement_ids in the assemble ('$rq0' vs '${REQIDS[$fm]}') — two requirements = two sets. Assemble each separately. Fail-closed."
        [[ "${SETIDS[$fm]}" == "$sd0" ]] || halt "FOOTPRINT (§2.2(b)): mixed set_ids for requirement '$rq0' ('$sd0' vs '${SETIDS[$fm]}') — the stagger. Fail-closed."
    done
    # The packet id IS the minted set_id (born at mint, not chosen at assemble). Reconcile any explicit arg.
    [[ -n "$want" && "$want" != "$sd0" ]] && halt "FOOTPRINT (§2.2(b)): explicit id '$want' ≠ the members' minted set_id '$sd0' — the set_id is born at mint. Fail-closed."
    if [[ "$setid" != "$sd0" ]]; then
        setid="$sd0"; num="${sd0#SET-}"; packet="$root/_ratification/$sd0.md"
        [[ -e "$packet" ]] && halt "numbering collision — $sd0 already exists at HEAD (minted set_id). Resolve before re-assembling."
    fi
    # (2) load footprint.lanes from the SET-IDENTITY registry (mint-time transcription of the architect spec).
    local reg flanes; reg="$("$root/scripts/pending-set.sh" registry "$rq0" 2>/dev/null || true)"
    [[ -n "$reg" ]] || halt "FOOTPRINT (§2.2): requirement '$rq0' has NO minted footprint in the SET-IDENTITY registry — no footprint → not dispatchable. Mint it first. Fail-closed."
    flanes="$(printf '%s' "$reg" | cut -f2)"
    local fsubs; fsubs="$(printf '%s' "$reg" | cut -f3)"   # REQ-HUNT §2.3 — optional footprint.substrates
    # Footprint lanes (declared) + assembled lanes (unique from members).
    local -a FLANES=() ALANES=(); local tok seen y
    IFS=',' read -ra _fl <<< "$flanes"
    for tok in "${_fl[@]}"; do tok="${tok//[[:space:]]/}"; tok="${tok#[}"; tok="${tok%]}"; [[ -n "$tok" ]] && FLANES+=("$tok"); done
    [[ ${#FLANES[@]} -gt 0 ]] || halt "FOOTPRINT (§2.2): requirement '$rq0' has an EMPTY footprint.lanes in the registry — no footprint → not dispatchable. Fail-closed."
    # (dedup assembled lanes; ${arr[@]+…} guards the empty-array expansion under `set -u` on bash 3.2/macOS)
    local ln
    for ln in "${LANES[@]}"; do ln="${ln//[[:space:]]/}"; [[ -z "$ln" ]] && continue
        seen=0; for y in ${ALANES[@]+"${ALANES[@]}"}; do [[ "$y" == "$ln" ]] && seen=1; done; [[ $seen -eq 0 ]] && ALANES+=("$ln"); done
    [[ ${#ALANES[@]} -gt 0 ]] || halt "FOOTPRINT: no assembled lanes could be resolved for the members (fail-closed)."
    # (3) coverage: assembled_lanes ⊇ footprint.lanes (missing required lane → HALT, never assess-aroundable).
    local -a MISSING=() EXTRA=(); local fl al hit
    for fl in "${FLANES[@]}"; do hit=0; for al in "${ALANES[@]}"; do [[ "$al" == "$fl" ]] && hit=1; done; [[ $hit -eq 0 ]] && MISSING+=("$fl"); done
    for al in "${ALANES[@]}"; do hit=0; for fl in "${FLANES[@]}"; do [[ "$al" == "$fl" ]] && hit=1; done; [[ $hit -eq 0 ]] && EXTRA+=("$al"); done
    if [[ ${#MISSING[@]} -gt 0 ]]; then
        halt "FOOTPRINT-MISS: spec '$rq0' requires lanes [${FLANES[*]}]; assembled has [${ALANES[*]}]; missing [${MISSING[*]}]. A required footprint lane is NEVER assess-aroundable on a MERGE decision (§2.2(c)(3), U4B shape). Fail-closed — do not hold a ready lane by dropping a required one."
    fi
    # (4) EXTRA lanes beyond the footprint are NOT auto-pass — a JOINT-EDGE of class UNDECLARED-OCCUPANT
    #     (integrator MUST assess; MERGE allowed only AFTER assessment — a real extra dependency can appear).
    for al in ${EXTRA[@]+"${EXTRA[@]}"}; do
        EDGES+=("$rq0 footprint [${FLANES[*]}] × occupant lane '$al' — UNDECLARED-OCCUPANT (a lane assembled beyond the declared footprint; integrator MUST assess before MERGE)")
    done
    # (5) REQ-HUNT (§2.3) footprint.substrates SECONDARY cross-check (rule-stated): a member writing
    #     a SoR substrate OUTSIDE the requirement's declared footprint.substrates is FLAGGED (never a hard
    #     FOOTPRINT-MISS — a real cross-substrate effect can be legitimate; the integrator assesses). Runs
    #     ONLY when the registry declares substrates (the field is OPTIONAL; '—'/empty → skip, unchanged;
    #     rule-stated).
    if [[ -n "${fsubs//[[:space:]]/}" && "${fsubs//[[:space:]]/}" != "—" ]]; then
        local -a FSUBS=(); local s mi msub declared; local -a _fs=()
        IFS=',' read -ra _fs <<< "$fsubs"
        for s in "${_fs[@]}"; do s="${s//[[:space:]]/}"; s="${s#[}"; s="${s%]}"; [[ -n "$s" ]] && FSUBS+=("$(norm_substrate "$s")"); done
        for (( mi=0; mi<${#IDS[@]}; mi++ )); do
            while IFS= read -r msub; do [[ -z "$msub" ]] && continue
                msub="$(norm_substrate "$msub")"; declared=0
                for s in ${FSUBS[@]+"${FSUBS[@]}"}; do [[ "$s" == "$msub" ]] && declared=1; done
                [[ $declared -eq 0 ]] && EDGES+=("${IDS[$mi]} writes substrate '$msub' — UNDECLARED-SUBSTRATE (outside footprint.substrates [${FSUBS[*]}]; §2.3 secondary cross-check — a flag, not a hard-miss; integrator MUST assess)")
            done < <(member_substrates "${SURF[$mi]}" "${EFFECTS[$mi]}" | sort -u)
        done
    fi

    local head_sha; head_sha="$(git -C "$root" rev-parse --short HEAD 2>/dev/null || echo '?')"
    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

    # --- write the packet per C-RATIFICATION-PACKET §2 (all named sections present). ---
    {
        echo "# $setid — set ratification packet"
        echo
        echo "> SCAR (canon §4): serialized transport hides the set; it does not dissolve it. Members are"
        echo "> each ratified alone; joint evaluation has never run — the incoherence in their interaction"
        echo "> reaches commit unseen. This packet is the set made visible. Set authorization is ON TOP OF"
        echo "> per-change review, never instead of it."
        echo ">"
        echo "> DETECTION HONESTY (canon §13): the JOINT-EDGES below are the MECHANICAL classes only — Layer A"
        echo "> (overlapping paths · shared unforkable artifacts · declared-dependency cycles) + Layer B (§2.3:"
        echo "> SoR SHARED-RECORD — same sproc/probe id cited across DIFFERENT files) + footprint edges"
        echo "> (UNDECLARED-OCCUPANT · UNDECLARED-SUBSTRATE). Field-proven, NOT proven-complete: object names,"
        echo "> seats/SLOTS keys, contract SECTIONS and two contradicting prose sentences are NOT mechanically"
        echo "> caught. That residual is UNSKIPPABLE — it is carried by the required ## SEMANTIC HUNT slot (§2.3"
        echo "> Layer C) + INTEGRATOR ASSESSMENT. 'none found' is a claim, not a proof."
        echo ">"
        echo "> COHERENCE LAW (REQ-HUNT §2.3): Mechanical JOINT-EDGES = NONE does NOT mean the set is coherent."
        echo "> MERGE is legal only after the SEMANTIC HUNT verdict is CLEAR or every named edge is resolved."
        echo
        echo "## HEADER"
        echo "- set id: $setid"
        echo "- requirement id: $rq0"
        echo "- footprint.lanes (spec, §2.2): [${FLANES[*]}] · assembled: [${ALANES[*]}] · coverage: $([[ ${#EXTRA[@]} -eq 0 ]] && echo 'EXACT' || echo "EXACT+extra{${EXTRA[*]}}")"
        echo "- wave id: {{WAVE}}"
        echo "- assembled-by: foundation"
        echo "- assembled-at: $now"
        echo "- HEAD sha at assembly: $head_sha"
        echo
        echo "## MEMBERS"
        for (( i=0; i<${#IDS[@]}; i++ )); do
            echo "- ${IDS[$i]} · lane=${LANES[$i]} · ${BRANCHES[$i]} · surfaces: ${SURF[$i]}"
        done
        echo
        echo "## JOINT-EDGES (mechanical; the floor)"
        if [[ ${#EDGES[@]} -eq 0 ]]; then
            echo "- NONE (no member pair shares a path, spine substrate, or declared dependency)."
            echo "  NOTE: NONE is the mechanical result only — semantic joint incoherence is not detectable here"
            echo "  and must be weighed in INTEGRATOR ASSESSMENT (canon §13)."
        else
            for e in "${EDGES[@]}"; do echo "- UNRESOLVED · $e"; done
            echo
            echo "  Each edge above must carry a \`resolution:\` line before ratify will pass (M5)."
        fi
        echo
        echo "## CONFLICT SWEEP"
        echo "- (integrator: subagent sweep of live docs + codebase across the joint set; findings + evidence"
        echo "  paths here. 'none found' requires the sweep receipt.)"
        echo
        echo "## COHERENCE CHECKS"
        echo "- (integrator: each set-level check — evaluable only on the JOINT set — · result · evidence path.)"
        echo
        echo "## CONFORMANCE (U4B — per-member: declared effects ⊨ the member's WP acceptance criteria; §2.1)"
        echo "> The GATE is mechanical + fail-closed + NON-OVERRIDABLE (rule-stated): \`ratify\` REFUSES a MERGE"
        echo "> decision unless EVERY member below carries \`verdict: PASS\` (with evidence). A STRUCTURED checker"
        echo "> (\`ratify.sh conformance-check $setid <member>\`) emits machine-checkable verdicts against the"
        echo "> member's acceptance-criteria file (_ratification/criteria/<member>.md — architect-owned; §2.1"
        echo "> corollary: a member with no checkable criteria is NOT conform-checkable and cannot PASS). An"
        echo "> irreducibly-prose criterion takes a RECORDED bounded judgment (\`ratify.sh conformance $setid"
        echo "> <member> --verdict PASS|FAIL --method judgment --evidence '…'\`, SANCTIONED §2.1). MISSING or FAIL → REFUSE."
        for (( i=0; i<${#IDS[@]}; i++ )); do
            echo "- ${IDS[$i]} · lane=${LANES[$i]} · verdict: MISSING"
        done
        echo
        echo "## INTEGRATOR ASSESSMENT (foundation agent — filled by \`ratify.sh assess\`)"
        echo "<!-- ASSESSMENT-EMPTY -->"
        echo
        echo "## SEMANTIC HUNT (canon §13 — REQUIRED; 'none found' is a claim, not a proof — §2.3 Layer C)"
        echo "> Mechanical joint-edge detection (Layer A + B above) is INCOMPLETE by construction. This slot is"
        echo "> UNSKIPPABLE: a MERGE decision (\`ratify --decision RATIFIED[-WITH-SEQUENCE]\`) REFUSES on a"
        echo "> missing/unfilled block, on verdict UNABLE, or on CLEAR asserted with 'candidates considered:"
        echo "> ZERO' and no method. Fill via: \`ratify.sh hunt $setid --method '<what was grepped / which SoR"
        echo "> indexes opened>' --candidates '<list or ZERO>' --residual '<one sentence>' --verdict"
        echo "> CLEAR|EDGE-NAMED|UNABLE [--edges '<name>[;<name>]']\`. EDGE-NAMED names join JOINT-EDGES as"
        echo "> INTEGRATOR-JUDGMENT edges (resolve like mechanical edges). NO LLM stamps CLEAR — a model may only"
        echo "> hand the integrator a candidate list to sign (§2.3 NOT)."
        echo "<!-- SEMANTIC-HUNT-EMPTY -->"
        echo
        echo "## BRIEFING (grounded alternatives for any contestable member)"
        echo "- (integrator, as needed.)"
        echo
        echo "## DECISION LINE (operator — exactly one; C-RATIFICATION-PACKET §3) + RATIONALE CLASS (§4)"
        echo "<!-- RATIFICATION-EMPTY -->"
        echo
        echo "## POST-DECISION"
        echo "- merge order executed (if -WITH-SEQUENCE): —"
        echo "- auditor reproduction ref: —"
    } > "$packet"

    # Mark included members `evaluated` in the ledger.
    local ledger="$root/PENDING-SET.md" id
    for id in "${IDS[@]}"; do
        awk -v id="$id" -v setid="$setid" 'BEGIN{FS=OFS="|"}
            /^\|[[:space:]]*[0-9]+[[:space:]]*\|/ {
                v=$3; gsub(/^[ \t]+|[ \t]+$/,"",v)
                if (v==id) { $7=" evaluated (into "setid") " }
            } {print}' "$ledger" > "$ledger.tmp" && mv "$ledger.tmp" "$ledger"
    done

    echo "assembled $setid: ${#IDS[@]} member(s), ${#EDGES[@]} mechanical joint edge(s). Packet: _ratification/$setid.md"
    [[ ${#EDGES[@]} -gt 0 ]] && echo "  ⚠ ${#EDGES[@]} joint edge(s) UNRESOLVED — HALT for pair/set ratification (resolve each before ratify)."
    return 0
}

cmd_assess() {
    resolve_foundation
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "assess: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "assess: no packet $setid."
    local text="" file=""
    while [[ $# -gt 0 ]]; do case "$1" in --text) text="${2:-}"; shift 2;; --file) file="${2:-}"; shift 2;; *) die "assess: unknown arg '$1'.";; esac; done
    [[ -z "$text" && -n "$file" ]] && { [[ -f "$file" ]] || die "assess: --file not found."; text="$(cat "$file")"; }
    [[ -n "${text// /}" ]] || die "REFUSED — assessment text is empty (fail-closed; the integrator agent must assess logic/evidence/live-state/invariants)."
    # Replace the ASSESSMENT-EMPTY marker with the assessment body.
    # NOTE (SET-0003 tooling fix): pass the (possibly MULTI-LINE) body via the ENVIRONMENT, read with
    # ENVIRON[] — NOT `awk -v body="$text"`. `-v` runs the value through awk's escape-sequence processor
    # and macOS/BSD awk aborts on an embedded newline ("newline in string"); ENVIRON[] carries arbitrary
    # multi-line text verbatim on both BSD and GNU awk. `ts` stays a safe single-line `-v`.
    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    body="$text" awk -v ts="$now" '
        /<!-- ASSESSMENT-EMPTY -->/ { print "- assessed-at: " ts; print ""; print ENVIRON["body"]; next } {print}
    ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
    echo "assessed $setid (ASSESSMENT slot filled)."
}

# cmd_ratify carries the CLOSED 5-state taxonomy (C-RATIFICATION-PACKET §3/§5) + §4 rationale class
# (built up at the source program's enforced HEAD from this engine's earlier RATIFIED-only stamp). The
# per-member PROSE dispositions (which member retained/dropped in AMENDED, alternatives in REJECTED)
# live in the packet's human-filled ASSESSMENT/BRIEFING slots — the SCRIPT wires the decision line +
# the state-appropriate ledger status + the binding invariants (unresolved-edge blocks only the MERGE
# decisions; AMENDED = SUBSET-RULE re-assembly; HELD needs a NAMED trigger; REJECTED → RETURNED).
cmd_ratify() {
    resolve_foundation   # runs in foundation's worktree; the operator drives the pen (§5 INDEPENDENCE)
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "ratify: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "ratify: no packet $setid."
    local by="" decision="RATIFIED" rclass="" sequence="" trigger=""
    while [[ $# -gt 0 ]]; do case "$1" in
        --by)              by="${2:-}";       shift 2 ;;
        --decision)        decision="${2:-}"; shift 2 ;;
        --rationale-class) rclass="${2:-}";   shift 2 ;;
        --sequence)        sequence="${2:-}"; shift 2 ;;
        --trigger)         trigger="${2:-}";  shift 2 ;;
        *) die "ratify: unknown arg '$1'." ;;
    esac; done
    # INDEPENDENCE (§5): the pen is a person.
    [[ -n "${by// /}" ]] || die "ratify: --by '<human ratifier>' is required (the pen is a person, C-RATIFICATION-PACKET §5 INDEPENDENCE)."
    # §4: rationale class recorded on ALL outcomes (in-band = resolvable from SoR; OUT-OF-BAND = decided outside the store).
    case "$rclass" in
        in-band|OUT-OF-BAND) : ;;
        *) die "ratify: --rationale-class {in-band|OUT-OF-BAND} is required (C-RATIFICATION-PACKET §4 — recorded on every outcome)." ;;
    esac
    # §3 CLOSED taxonomy — never a bare no.
    case "$decision" in
        RATIFIED|RATIFIED-WITH-SEQUENCE|AMENDED|HELD|REJECTED) : ;;
        *) die "ratify: --decision must be one of the closed set {RATIFIED|RATIFIED-WITH-SEQUENCE|AMENDED|HELD|REJECTED} (C-RATIFICATION-PACKET §3)." ;;
    esac
    # REFUSE if the assessment slot is still empty (canon §10: the agent assesses before the human decides — ALL outcomes).
    grep -q '<!-- ASSESSMENT-EMPTY -->' "$packet" && halt "assessment slot is EMPTY — run \`ratify.sh assess $setid\` first (canon §10: the agent assesses before the human ratifies)."
    # Per-decision preconditions.
    local extra=""
    case "$decision" in
        RATIFIED|RATIFIED-WITH-SEQUENCE)
            # A MERGE decision REFUSES on any UNRESOLVED joint edge (an edge line without a following resolution:).
            # (AMENDED/HELD/REJECTED are the CORRECT responses to unresolved edges — they do NOT refuse.)
            if grep -qE '^- UNRESOLVED · ' "$packet"; then
                halt "unresolved joint edge(s) in $setid — resolve each (add a \`resolution:\` line), or choose --decision AMENDED (SUBSET RULE = new set) / HELD / REJECTED. A merge decision cannot stand over an unresolved edge."
            fi
            # === REQ-HUNT (§2.3 Layer C) — the SEMANTIC HUNT slot is UNSKIPPABLE for a MERGE decision. ===
            # 'Mechanical JOINT-EDGES = NONE' does NOT license a merge (canon §13); the slot carries the residual
            # the detector cannot. REFUSE on: missing section, unfilled block, verdict UNABLE, or CLEAR asserted
            # with 'candidates considered: ZERO' + no method (an assertion, not a hunt — DISC-ABSENCE-OF-RECORD).
            grep -q '^## SEMANTIC HUNT' "$packet" || halt "packet $setid predates the REQ-HUNT semantic-hunt slot (no ## SEMANTIC HUNT section) — re-assemble (fail-closed §2.3)."
            if grep -q '<!-- SEMANTIC-HUNT-EMPTY -->' "$packet"; then
                halt "SEMANTIC HUNT slot is EMPTY in $setid — run \`ratify.sh hunt $setid --method … --candidates … --residual … --verdict CLEAR|EDGE-NAMED|UNABLE\` first (canon §13: 'none found' is a claim; §2.3 Layer C). Or choose --decision AMENDED|HELD|REJECTED."
            fi
            local hv hcand hmeth
            hv="$(awk '/^## SEMANTIC HUNT/{s=1;next} /^## /{s=0} s' "$packet" | sed -n 's/^- verdict:[[:space:]]*//p' | head -1)"
            case "$hv" in
                CLEAR)
                    hcand="$(awk '/^## SEMANTIC HUNT/{s=1;next} /^## /{s=0} s' "$packet" | sed -n 's/^- candidates considered:[[:space:]]*//p' | head -1)"
                    hmeth="$(awk '/^## SEMANTIC HUNT/{s=1;next} /^## /{s=0} s' "$packet" | sed -n 's/^- method:[[:space:]]*//p' | head -1)"
                    if [[ "${hcand//[[:space:]]/}" == "ZERO" && ( -z "${hmeth//[[:space:]]/}" || "${hmeth//[[:space:]]/}" == "—" ) ]]; then
                        halt "SEMANTIC HUNT verdict CLEAR with 'candidates considered: ZERO' and NO method in $setid — an assertion, not a hunt (DISC-ABSENCE-OF-RECORD applied to the hunt itself; §2.3). Record the method (what was grepped / which SoR indexes opened), name the edges (EDGE-NAMED), or choose AMENDED|HELD."
                    fi
                    ;;
                EDGE-NAMED)
                    # The named edges are appended to JOINT-EDGES as UNRESOLVED — the unresolved-edge refuse
                    # above already blocks a MERGE until each carries a resolution: line. Nothing extra here.
                    : ;;
                UNABLE|""|—)
                    halt "SEMANTIC HUNT verdict is '${hv:-<missing>}' in $setid — a MERGE decision REFUSES on UNABLE/missing (§2.3 Layer C, same fail-closed shape as an empty assessment). Complete the hunt (CLEAR with method, or EDGE-NAMED), or choose --decision AMENDED|HELD|REJECTED."
                    ;;
                *)
                    halt "SEMANTIC HUNT verdict '$hv' is not in the closed set {CLEAR|EDGE-NAMED|UNABLE} in $setid (§2.3). Re-run \`ratify.sh hunt\`."
                    ;;
            esac
            # === U4B CONFORMANCE (§2.1) — a MERGE decision REQUIRES verdict: PASS for EVERY member. ===
            # Fail-closed + NON-OVERRIDABLE (rule-stated); same shape as the unresolved-edge / empty-assessment
            # refusals. A non-PASS verdict (FAIL or MISSING) is answered by AMENDED/HELD/REJECTED (the §1 R5
            # return path), NOT by an override. AMENDED/HELD/REJECTED do NOT require conformance PASS.
            grep -q '^## CONFORMANCE' "$packet" || halt "packet $setid predates the U4B conformance gate (no CONFORMANCE section) — re-assemble (fail-closed §2.1)."
            local -a NONPASS=(); local mid v
            while IFS= read -r mid; do
                [[ -z "$mid" ]] && continue
                v="$(awk -v id="$mid" '/^## CONFORMANCE/{c=1;next} /^## /{c=0} c && index($0,"- " id " ·")==1 {sub(/.*verdict:[[:space:]]*/,""); sub(/[[:space:]].*/,""); print; exit}' "$packet")"
                [[ "$v" == "PASS" ]] || NONPASS+=("$mid=${v:-MISSING}")
            done < <(awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$packet" | sed -n 's/^- \([^ ]*\) .*/\1/p')
            if [[ ${#NONPASS[@]} -gt 0 ]]; then
                halt "U4B conformance NOT satisfied for $setid (§2.1) — a MERGE decision REQUIRES verdict: PASS for EVERY member; got: ${NONPASS[*]}. Produce verdicts (ratify.sh conformance-check / conformance), or choose --decision AMENDED|HELD|REJECTED (the R5 return path for a non-conforming member). Non-overridable (rule-stated)."
            fi
            if [[ "$decision" == "RATIFIED-WITH-SEQUENCE" ]]; then
                [[ -n "${sequence// /}" ]] || die "ratify: --decision RATIFIED-WITH-SEQUENCE requires --sequence '<member order>' (§3: merges in the stated order, no other change)."
                extra="- merge sequence: $sequence"
            fi
            ;;
        HELD)
            # §3: HELD → PARKED against a NAMED trigger; never limbo.
            [[ -n "${trigger// /}" ]] || die "ratify: --decision HELD requires --trigger '<named event/date>' (§3: parked against a NAMED trigger; re-surfaces on it; never limbo)."
            extra="- held trigger: $trigger"
            ;;
        AMENDED)
            # §5 SUBSET RULE: an AMENDED set is a NEW set — retained members re-enter assembly + JOINT
            # re-validation. Line-item ratification does not exist. The script records the decision +
            # the per-member dispositions (authored in ASSESSMENT/BRIEFING); it does NOT merge.
            extra="- SUBSET RULE (§5): AMENDED = a NEW set. Retained members must be re-assembled (\`ratify.sh assemble\`) + JOINT re-validated before ANY merge. Per-member dispositions are in INTEGRATOR ASSESSMENT / BRIEFING. No member merges on this line."
            ;;
        REJECTED)
            # §3: per-member dispositions + rationale + the briefing's grounded alternatives. Members → RETURNED
            # (NO-CHERRY-PICK, §5: RETURNED content reaches main ONLY inside a future ratified set).
            extra="- REJECTED (§3/§5): per-member dispositions + grounded alternatives are in INTEGRATOR ASSESSMENT / BRIEFING. Members → RETURNED (NO-CHERRY-PICK: a returned branch re-enters main ONLY inside a future ratified set)."
            ;;
    esac
    # === RECEIPT UNIQUENESS (§2.16) — runs via scripts/receipt-ledger.py (shipped in this engine) ===
    # Every evidence receipt CITED BY A MEMBER must be unique in the spine ledger by (id, content_sha):
    # a duplicate id with differing content means one member could discharge on another's receipt.
    local -a CITED=() m
    while IFS= read -r m; do [[ -z "$m" ]] && continue
        while IFS= read -r r; do [[ -n "$r" ]] && CITED+=("$r"); done < <(member_receipts "$m")
    done < <(awk '/^## MEMBERS/{x=1;next} /^## /{x=0} x' "$packet" | sed -n 's/^- \([^ ·]*\) .*/\1/p')
    if [[ ${#CITED[@]} -gt 0 && -x "$root/scripts/receipt-ledger.py" ]] && command -v python3 >/dev/null 2>&1; then
        python3 "$root/scripts/receipt-ledger.py" check-unique "$root" "${CITED[@]}" \
            || halt "member-cited receipt(s) are NOT unique in the spine ledger (§2.16) — resolve the collision before ratifying $setid."
    fi
    local psha; psha="$(shasum -a 256 "$packet" | awk '{print $1}')"
    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    # Stamp the §3 DECISION line + §4 rationale class into the RATIFICATION-EMPTY slot.
    awk -v dec="$decision" -v who="$by" -v ts="$now" -v sha="$psha" -v rc="$rclass" -v extra="$extra" '
        /<!-- RATIFICATION-EMPTY -->/ {
            print "- decision: " dec
            print "- ratified-by: " who
            print "- at: " ts
            print "- packet sha (pre-stamp): " sha
            print "- rationale class: " rc
            if (extra != "") print extra
            next
        } {print}
    ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"

    # Ledger status update per decision (only the evaluated-into-THIS-set rows).
    local ledger="$root/PENDING-SET.md" newstat
    case "$decision" in
        RATIFIED|RATIFIED-WITH-SEQUENCE) newstat="ratified-in $setid" ;;
        HELD)                            newstat="HELD (trigger: $trigger)" ;;
        AMENDED)                         newstat="pending" ;;   # SUBSET RULE: back to pending for re-assembly as a NEW set
        REJECTED)                        newstat="RETURNED" ;;  # NO-CHERRY-PICK; branch preserved
    esac
    awk -v setid="$setid" -v ns="$newstat" 'BEGIN{FS=OFS="|"}
        /^\|[[:space:]]*[0-9]+[[:space:]]*\|/ {
            v=$7; gsub(/^[ \t]+|[ \t]+$/,"",v)
            if (index(v, "evaluated (into " setid ")") == 1) { $7=" "ns" " }
        } {print}' "$ledger" > "$ledger.tmp" && mv "$ledger.tmp" "$ledger"

    echo "$decision $setid by '$by' (rationale: $rclass; packet sha $psha). Members → $newstat."
    case "$decision" in
        AMENDED)  echo "  ⚠ SUBSET RULE (§5): re-assemble the retained members as a NEW set before any merge." ;;
        REJECTED) echo "  ⚠ NO-CHERRY-PICK (§5): returned member branches re-enter main ONLY inside a future ratified set." ;;
        HELD)     echo "  ⏸ PARKED against trigger: $trigger (re-surfaces on it; never limbo)." ;;
    esac
}

# === U4B (§2.1) — record a per-member conformance verdict into the packet's CONFORMANCE section. ===
# Shared by cmd_conformance (manual/judgment) + cmd_conformance_check (structured). Fail-closed: the
# member MUST already exist in the CONFORMANCE section (seeded by assemble) — else die.
record_conformance() {
    local packet="$1" member="$2" verdict="$3" method="$4" evidence="$5" now rc
    now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    awk -v id="$member" -v v="$verdict" -v mth="$method" -v ev="$evidence" -v ts="$now" '
        /^## CONFORMANCE/{c=1; print; next}
        /^## /{c=0}
        c && index($0, "- " id " ·")==1 {
            print "- " id " · verdict: " v " · method: " mth " · evidence: " ev " · at: " ts; done=1; next
        }
        {print}
        END{ if(!done) exit 9 }
    ' "$packet" > "$packet.tmp"; rc=$?
    if [[ $rc -eq 9 ]]; then rm -f "$packet.tmp"; die "conformance: member '$member' has no line in the CONFORMANCE section of $(basename "$packet" .md) (re-assemble; fail-closed)."; fi
    mv "$packet.tmp" "$packet"
}

# conformance SET-NNNN <member> --verdict PASS|FAIL --method structured|judgment --evidence '…'
# Records a verdict directly — the path for a BOUNDED JUDGMENT at the edge (prose criterion; SANCTIONED
# §2.1) or an out-of-band structured result. A verdict is an evidence-first claim (§L) → --evidence required.
cmd_conformance() {
    resolve_foundation
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "conformance: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "conformance: no packet $setid."
    local member="${1:-}"; shift || true
    [[ -n "$member" ]] || die "conformance: <member-id> required."
    local verdict="" method="" evidence=""
    while [[ $# -gt 0 ]]; do case "$1" in
        --verdict)  verdict="${2:-}";  shift 2 ;;
        --method)   method="${2:-}";   shift 2 ;;
        --evidence) evidence="${2:-}"; shift 2 ;;
        *) die "conformance: unknown arg '$1'." ;;
    esac; done
    case "$verdict" in PASS|FAIL) : ;; *) die "conformance: --verdict {PASS|FAIL} required." ;; esac
    case "$method"  in structured|judgment) : ;; *) die "conformance: --method {structured|judgment} required (§2.1)." ;; esac
    [[ -n "${evidence// /}" ]] || die "conformance: --evidence required (§L: a verdict is an evidence-first claim, never asserted)."
    grep -q '^## CONFORMANCE' "$packet" || die "conformance: packet $setid has no CONFORMANCE section — re-assemble."
    awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$packet" | sed -n 's/^- \([^ ]*\) .*/\1/p' | grep -qx "$member" \
        || die "conformance: '$member' is not a member of $setid."
    record_conformance "$packet" "$member" "$verdict" "$method" "$evidence"
    echo "conformance $setid/$member: verdict=$verdict method=$method recorded."
}

# conformance-check SET-NNNN <member> [--criteria FILE] [--no-record]
# The STRUCTURED checker (no LLM): evaluates the member's machine-checkable acceptance criteria and
# records the verdict. Criteria file (architect-owned) default _ratification/criteria/<member>.md, one
# criterion per line:  - [exists] <path> | [absent] <path> | [grep] <ERE> :: <path> | [test] <shell> |
# [judgment] <prose>.  A [judgment] criterion is NOT auto-PASSed — it needs `conformance … --method
# judgment` (fail-closed §2.1). Absent/empty criteria file → HALT (a member with no checkable criteria
# cannot PASS; §2.1 corollary).
cmd_conformance_check() {
    resolve_foundation
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "conformance-check: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "conformance-check: no packet $setid."
    local member="${1:-}"; shift || true
    [[ -n "$member" ]] || die "conformance-check: <member-id> required."
    local criteria="" record=1
    while [[ $# -gt 0 ]]; do case "$1" in
        --criteria)  criteria="${2:-}"; shift 2 ;;
        --no-record) record=0;          shift   ;;
        *) die "conformance-check: unknown arg '$1'." ;;
    esac; done
    [[ -z "$criteria" ]] && criteria="$root/_ratification/criteria/${member}.md"
    [[ -f "$criteria" ]] || halt "conformance-check: NO acceptance-criteria file for '$member' at ${criteria#$root/} (§2.1 corollary — a member is NOT conform-checkable, and cannot PASS, without explicit checkable criteria; author them, or record a judgment verdict). Fail-closed."
    local pass=0 fail=0 judg=0 n=0; local -a RESULTS=()
    local line type args
    while IFS= read -r line; do
        line="${line#- }"; line="${line#"${line%%[![:space:]]*}"}"   # strip leading "- " + whitespace
        [[ -z "${line// /}" || "${line:0:1}" == "#" ]] && continue
        type="$(sed -n 's/^\[\([a-z-]*\)\].*/\1/p' <<<"$line")"
        args="$(sed 's/^\[[a-z-]*\][[:space:]]*//' <<<"$line")"
        n=$((n+1))
        case "$type" in
            exists) if [[ -e "$root/$args" ]]; then RESULTS+=("PASS [exists] $args"); pass=$((pass+1)); else RESULTS+=("FAIL [exists] $args"); fail=$((fail+1)); fi ;;
            absent) if [[ ! -e "$root/$args" ]]; then RESULTS+=("PASS [absent] $args"); pass=$((pass+1)); else RESULTS+=("FAIL [absent] $args"); fail=$((fail+1)); fi ;;
            grep)   local pat pth; pat="${args%% :: *}"; pth="${args##* :: }"
                    if grep -qE "$pat" "$root/$pth" 2>/dev/null; then RESULTS+=("PASS [grep] $pat :: $pth"); pass=$((pass+1)); else RESULTS+=("FAIL [grep] $pat :: $pth"); fail=$((fail+1)); fi ;;
            test)   if ( cd "$root" && eval "$args" ) >/dev/null 2>&1; then RESULTS+=("PASS [test] $args"); pass=$((pass+1)); else RESULTS+=("FAIL [test] $args"); fail=$((fail+1)); fi ;;
            judgment) RESULTS+=("JUDGMENT-REQUIRED [judgment] $args"); judg=$((judg+1)) ;;
            *)      RESULTS+=("FAIL [unknown-criterion-type:$type] $args"); fail=$((fail+1)) ;;
        esac
    done < "$criteria"
    [[ $n -gt 0 ]] || halt "conformance-check: criteria file ${criteria#$root/} has NO criteria (fail-closed §2.1)."
    echo "conformance-check $setid/$member: $n criterion(s) — PASS=$pass FAIL=$fail JUDGMENT-REQUIRED=$judg"
    local r; for r in "${RESULTS[@]}"; do echo "  - $r"; done
    local verdict method evidence
    if [[ $fail -gt 0 ]]; then
        verdict="FAIL"; method="structured"; evidence="structured $pass/$n PASS; $fail FAIL"
    elif [[ $judg -gt 0 ]]; then
        echo "  ⚠ $judg prose criterion(s) need a RECORDED bounded judgment (§2.1): ratify.sh conformance $setid $member --verdict PASS|FAIL --method judgment --evidence '…'. Verdict left non-PASS (fail-closed)."
        [[ "$record" -eq 1 ]] && record_conformance "$packet" "$member" "MISSING-JUDGMENT" "structured" "structured $pass/$((n-judg)) PASS; $judg judgment pending"
        return 0
    else
        verdict="PASS"; method="structured"; evidence="structured $pass/$n PASS"
    fi
    [[ "$record" -eq 1 ]] && record_conformance "$packet" "$member" "$verdict" "$method" "$evidence"
    echo "  verdict: $verdict$([[ "$record" -eq 1 ]] && echo ' (recorded)')"
}

# hunt SET-NNNN --method '…' --candidates '…' --residual '…' --verdict CLEAR|EDGE-NAMED|UNABLE [--edges 'a;b']
# REQ-HUNT (§2.3 Layer C) — fill the REQUIRED SEMANTIC HUNT slot. Fail-closed content rules (also re-checked
# at ratify so the packet is never left half-formed): CLEAR needs a method + candidates (a list or the token
# ZERO); EDGE-NAMED needs the named edges (they join JOINT-EDGES as INTEGRATOR-JUDGMENT and must resolve
# before a MERGE); UNABLE records the block but ratify REFUSES a MERGE on it. No LLM stamps CLEAR (a model may
# only produce a candidate list the integrator signs). `--residual` (one sentence) is always required.
cmd_hunt() {
    resolve_foundation
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "hunt: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "hunt: no packet $setid."
    local method="" candidates="" residual="" verdict="" edges=""
    while [[ $# -gt 0 ]]; do case "$1" in
        --method)     method="${2:-}";     shift 2 ;;
        --candidates) candidates="${2:-}"; shift 2 ;;
        --residual)   residual="${2:-}";   shift 2 ;;
        --verdict)    verdict="${2:-}";    shift 2 ;;
        --edges)      edges="${2:-}";      shift 2 ;;
        *) die "hunt: unknown arg '$1'." ;;
    esac; done
    grep -q '^## SEMANTIC HUNT' "$packet" || halt "hunt: packet $setid predates the REQ-HUNT semantic-hunt slot (no ## SEMANTIC HUNT section) — re-assemble (fail-closed §2.3)."
    case "$verdict" in
        CLEAR|EDGE-NAMED|UNABLE) : ;;
        *) die "hunt: --verdict must be one of {CLEAR|EDGE-NAMED|UNABLE} (§2.3 Layer C)." ;;
    esac
    [[ -n "${residual// /}" ]] || die "hunt: --residual '<one sentence>' is required (the hunt records its residual risk; §2.3)."
    if [[ "$verdict" == "CLEAR" ]]; then
        [[ -n "${method// /}" ]] || die "hunt: verdict CLEAR REQUIRES --method (what was grepped / which SoR indexes opened) — a CLEAR with no method is an assertion, not a hunt (DISC-ABSENCE-OF-RECORD; §2.3)."
        [[ -n "${candidates// /}" ]] || die "hunt: verdict CLEAR REQUIRES --candidates (a list, or the explicit token ZERO) — §2.3."
    fi
    if [[ "$verdict" == "EDGE-NAMED" ]]; then
        [[ -n "${edges// /}" ]] || die "hunt: verdict EDGE-NAMED REQUIRES --edges '<name>[;<name>]' — the named semantic edges join JOINT-EDGES as INTEGRATOR-JUDGMENT and must resolve before a MERGE (§2.3)."
    fi
    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    method="$method" candidates="$candidates" residual="$residual" verdict="$verdict" \
    awk -v ts="$now" '
        /<!-- SEMANTIC-HUNT-EMPTY -->/ {
            print "- hunt-at: " ts
            print "- method: " ENVIRON["method"]
            print "- candidates considered: " ENVIRON["candidates"]
            print "- residual risk: " ENVIRON["residual"]
            print "- verdict: " ENVIRON["verdict"]
            next
        } {print}
    ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
    if [[ "$verdict" == "EDGE-NAMED" ]]; then
        local e; local -a _EN=(); IFS=';' read -ra _EN <<< "$edges"
        for e in "${_EN[@]}"; do
            e="${e#"${e%%[![:space:]]*}"}"; e="${e%"${e##*[![:space:]]}"}"; [[ -z "$e" ]] && continue
            edge="- UNRESOLVED · INTEGRATOR-JUDGMENT: $e (§2.3 Layer C named semantic edge — add a resolution: line or choose AMENDED before MERGE)" \
            awk '
                /^## JOINT-EDGES/ {inj=1; print; next}
                inj && /^## / {print ENVIRON["edge"]; print ""; inj=0}
                {print}
                END{ if(inj) print ENVIRON["edge"] }
            ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
        done
    fi
    echo "hunt $setid: verdict=$verdict recorded (SEMANTIC HUNT slot filled)."
    [[ "$verdict" == "EDGE-NAMED" ]] && echo "  ⚠ named edge(s) appended to JOINT-EDGES — resolve each (resolution: line) or AMENDED before a MERGE decision."
    [[ "$verdict" == "UNABLE" ]] && echo "  ⚠ verdict UNABLE — ratify will REFUSE a MERGE decision (§2.3). Complete the hunt (CLEAR/EDGE-NAMED) or choose AMENDED/HELD."
}

main() {
    local verb="${1:-}"; shift || true
    case "$verb" in
        assemble)          cmd_assemble "$@" ;;
        assess)            cmd_assess "$@" ;;
        hunt)              cmd_hunt "$@" ;;
        conformance)       cmd_conformance "$@" ;;
        conformance-check) cmd_conformance_check "$@" ;;
        ratify)            cmd_ratify "$@" ;;
        ""|-h|--help) echo "usage: ratify.sh {assemble [SET-NNNN] | assess SET-NNNN --text …|--file F | hunt SET-NNNN --method … --candidates … --residual … --verdict CLEAR|EDGE-NAMED|UNABLE [--edges 'a;b'] | conformance-check SET-NNNN <member> [--criteria F] | conformance SET-NNNN <member> --verdict PASS|FAIL --method structured|judgment --evidence '…' | ratify SET-NNNN --by 'name' --rationale-class in-band|OUT-OF-BAND [--decision RATIFIED|RATIFIED-WITH-SEQUENCE|AMENDED|HELD|REJECTED] [--sequence …] [--trigger …]}" ;;
        *) die "unknown verb '$verb' (expected: assemble | assess | hunt | conformance-check | conformance | ratify)." ;;
    esac
}
main "$@"
