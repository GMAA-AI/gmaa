#!/usr/bin/env bash
# scripts/guard-command-shape.sh — PreToolUse guard (Bash). DENY dangerous git command SHAPES that a
# prefix-matched permissions deny-list cannot fully cover: a flag placed AFTER the subcommand slips a
# prefix match (".claude/settings.json //deny" says so). This is the landed L3 shape. FAIL-CLOSED.
# Wired: .claude/settings.json  hooks.PreToolUse matcher "Bash".
#
# Reads the PreToolUse JSON on stdin, extracts tool_input.command, and BLOCKS (exit 2 + stderr reason,
# the Claude Code blocking-hook contract) when a command would bypass the spine/set gate or rewrite
# shared history:
#   - git commit … --no-verify | -n                         (bypasses the pre-commit set/spine gate)
#   - git -c core.hooksPath=… commit                        (DISABLES the pre-commit hook entirely)
#   - git push … --force | -f | --force-with-lease | +<refspec>   (rewrites shared history; §13(5): NEVER)
#   - git push <src>:<trunk> from a non-foundation lane     (the push hole pre-commit cannot see)
#
# ISSUE-2 FIX (v2.5.6): the prior match keyed on `git[[:space:]]+commit` / `git[[:space:]]+push`, so a
# git GLOBAL option placed between `git` and the subcommand slipped it (`git -C /tmp commit --no-verify`,
# `git --no-pager commit -n`, `git -c core.hooksPath=/dev/null commit`), and an unparseable stdin JSON
# exited 0 (fail-OPEN). Now the command is TOKENIZED (shlex) and split into shell SEGMENTS (segment-
# scoping — a benign later `echo -n` is not a false positive); for each segment the REAL git subcommand
# is found by WALKING PAST git's global options (verified vs live `man git` 2.50.1: value-consuming
# -C · -c · --git-dir · --work-tree · --namespace · --config-env · --exec-path · --attr-source ·
# --super-prefix; everything else leading-dash is a flag global). The shape checks apply to that
# subcommand. Unparseable stdin now fails CLOSED (DENY), distinct from a truly empty/no-command stdin
# (allow). All tokenization + shape analysis is done in the python3 step; bash does only the lane/trunk
# HEAD-readback for the push-hole check. Exit 0 = allow. Exit 2 = deny.
set -u

INPUT="$(cat 2>/dev/null || true)"

# python3 does all parsing + shape analysis and prints ONE verdict protocol to stdout:
#   NOCMD                          empty stdin / no command present → allow
#   ALLOW                          parsed, no violating shape, no refspec push → allow
#   DENY\n<reason>                 a commit-bypass / force-push shape, OR unparseable stdin (fail-CLOSED)
#   PUSHCHECK\n<dest>\n<dest>…     a git push with refspec destination(s) — bash does the lane/trunk check
RESULT="$(GUARD_INPUT="$INPUT" python3 - <<'PY'
import os, sys, json, shlex, re

raw = os.environ.get("GUARD_INPUT", "")

def out(*lines):
    sys.stdout.write("\n".join(lines) + "\n")
    sys.exit(0)

# Fail-CLOSED: "no command present" (empty stdin) → allow; "stdin present but unparseable" → DENY.
if raw.strip() == "":
    out("NOCMD")
try:
    data = json.loads(raw)
except Exception:
    out("DENY", "PreToolUse stdin present but unparseable as JSON — a guard that cannot read its input must not allow (fail-closed)")

cmd = ""
if isinstance(data, dict):
    ti = data.get("tool_input")
    if isinstance(ti, dict):
        cmd = ti.get("command") or ""
if not cmd.strip():
    out("NOCMD")

# git global-option table (verified vs live `man git` 2.50.1). These take a value in the separate-token
# (no '=') form and so consume the NEXT token when walking to the subcommand.
G_ARG_LONG = {"--git-dir", "--work-tree", "--namespace", "--config-env",
              "--exec-path", "--attr-source", "--super-prefix"}
SEPS = {"&&", "||", ";", "|", "&"}
CMSKIP = {"-m", "-F", "-C", "-c", "-t"}   # commit shorts whose NEXT token is a value (avoid `-m -n` false pos)

def tokenize(s):
    try:
        return shlex.split(s, posix=True)
    except ValueError:
        # unbalanced quotes etc. — permissive fallback so coverage is not lost.
        for sep in ("&&", "||", ";", "|", "&"):
            s = s.replace(sep, " ")
        return s.split()

def segments(toks):
    seg, out_segs = [], []
    for t in toks:
        if t in SEPS:
            out_segs.append(seg); seg = []
        else:
            seg.append(t)
    out_segs.append(seg)
    return out_segs

def parse_git(seg):
    """Return (subcommand, args, cfgs). (None,[],cfgs) if no git subcommand in this segment.
    cfgs = the `name=value` strings from any -c / --config-env globals (to detect core.hooksPath)."""
    i, n = 0, len(seg)
    while i < n and not (seg[i] == "git" or seg[i].endswith("/git")):
        i += 1
    if i >= n:
        return (None, [], [])
    cfgs = []
    j = i + 1
    while j < n:
        t = seg[j]
        if not t.startswith("-"):
            break
        if t == "-c":                                        # -c name=value  (value = next token)
            if j + 1 < n:
                cfgs.append(seg[j + 1])
            j += 2; continue
        if t.startswith("-c") and not t.startswith("--"):    # -cname=value (stuck value)
            cfgs.append(t[2:]); j += 1; continue
        if t == "-C":                                        # -C <path>
            j += 2; continue
        if t.startswith("--config-env="):
            cfgs.append(t[len("--config-env="):]); j += 1; continue
        if "=" in t:                                         # --opt=value (self-contained)
            j += 1; continue
        if t in G_ARG_LONG:                                  # --git-dir <v> etc. (separate value)
            j += 2; continue
        j += 1                                               # flag global / -C<stuck> / short cluster
    if j >= n:
        return (None, [], cfgs)
    return (seg[j], seg[j + 1:], cfgs)

def hooks_disabled(cfgs):
    for c in cfgs:
        if c.split("=", 1)[0].strip().lower() == "core.hookspath":
            return True
    return False

def check(seg):
    sub, args, cfgs = parse_git(seg)
    if sub is None:
        return ("ALLOW", None, [])
    if sub == "commit":
        if hooks_disabled(cfgs):
            return ("DENY", "git -c core.hooksPath=… disables the pre-commit hook, bypassing the spine/set gate (COORDINATION §13(1)/canon §4)", [])
        k = 0
        while k < len(args):
            a = args[k]
            if a in CMSKIP:                                  # skip a value token (message/ref) after these
                k += 2; continue
            if a == "--no-verify" or a == "-n" or re.match(r'^-[A-Za-z]*n[A-Za-z]*$', a):
                return ("DENY", "git commit --no-verify/-n bypasses the pre-commit spine/set gate (COORDINATION §13(1)/canon §4)", [])
            k += 1
        return ("ALLOW", None, [])
    if sub == "push":
        if hooks_disabled(cfgs):
            return ("DENY", "git -c core.hooksPath=… disables hooks on a push (COORDINATION §13(1))", [])
        dests = []
        for a in args:
            if a in ("--force", "-f", "--force-with-lease", "--force-if-includes") \
               or a.startswith("--force-with-lease=") or re.match(r'^-[A-Za-z]*f[A-Za-z]*$', a):
                return ("DENY", "git push --force/-f/--force-with-lease/+refspec rewrites shared history (COORDINATION §13(5): NEVER --force)", [])
            if a.startswith("+") and len(a) > 1 and not a.startswith("+-"):
                return ("DENY", "git push +<refspec> is a forced update — rewrites shared history (COORDINATION §13(5))", [])
            if not a.startswith("-") and ":" in a:
                d = a.rsplit(":", 1)[1].lstrip("+")
                if d:
                    dests.append(d)
        return ("PUSHCHECK", None, dests)
    return ("ALLOW", None, [])

all_dests, push_seen = [], False
for seg in segments(tokenize(cmd)):
    v, reason, dests = check(seg)
    if v == "DENY":
        out("DENY", reason)
    if v == "PUSHCHECK":
        push_seen = True
        all_dests.extend(dests)
if push_seen and all_dests:
    out("PUSHCHECK", *all_dests)
out("ALLOW")
PY
)"

verdict="${RESULT%%$'\n'*}"
case "$verdict" in
    NOCMD|ALLOW|"")
        # empty verdict == python3 absent/crashed → degrade to ALLOW (matches the pre-fix behaviour;
        # python3 is a hard engine dependency, so this is a broken-environment edge, not attacker input).
        exit 0 ;;
    DENY)
        reason="${RESULT#*$'\n'}"
        echo "guard-command-shape DENY: $reason" >&2
        exit 2 ;;
    PUSHCHECK)
        dests="${RESULT#*$'\n'}"
        # r4 §2.2 + ruling #1: the PUSH HOLE pre-commit cannot see — a refspec push whose destination is
        # the TRUNK from a NON-foundation lane (only foundation merges to trunk; §13(1)). Lane + trunk are
        # HEAD-readback (resolve-lane + spine lane-provisioning), never a lane-local mirror.
        _root="$(git rev-parse --show-toplevel 2>/dev/null || true)"
        if [ -n "$_root" ] && [ -x "$_root/scripts/resolve-lane.sh" ]; then
            _ll="$("$_root/scripts/resolve-lane.sh" 2>/dev/null || true)"
            lane=""; eval "$_ll" 2>/dev/null || true
            if [ -n "${lane:-}" ] && [ "${lane:-}" != "foundation" ]; then
                _trunk="$(git -C "$_root" show HEAD:_orchestration/lane-provisioning.md 2>/dev/null | awk -F'|' '$2 ~ /foundation/ {gsub(/[[:space:]]/,"",$3); print $3; exit}')"
                _trunk="${_trunk:-main}"
                while IFS= read -r d; do
                    [ -z "$d" ] && continue
                    if [ "$d" = "$_trunk" ]; then
                        echo "guard-command-shape DENY: git push refspec targets trunk '${_trunk}' from non-foundation lane '${lane}' — only foundation merges to trunk (COORDINATION §13(1); the push hole pre-commit cannot see)" >&2
                        exit 2
                    fi
                done <<EOF
$dests
EOF
            fi
        fi
        exit 0 ;;
esac
exit 0
