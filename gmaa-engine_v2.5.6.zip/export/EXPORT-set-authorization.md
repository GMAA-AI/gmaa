===================================================================================================
# EXPORT BODY — SET AUTHORIZATION: architecture, enforcement, and first-execution methodology
===================================================================================================

## 1. Thesis + what changed
**The unit of authorization is the SET, not the change.** Per-change review evaluates each change in isolation;
serialized transport (one PR/commit at a time) *hides* the set but does not dissolve it. Members are each
reviewed alone, joint evaluation never runs, and the incoherence in their interaction reaches the coherence
boundary (the trunk) unseen. Set authorization evaluates the WHOLE set at the apply boundary — ON TOP OF
per-change review, never instead of it.

The model was **written but not enforced** (a reference implementation hardcoded the ratify decision to a single
accepted state — teeth in a drawer). The work packaged here is the **enforcement**: the model wired to
fail-closed gates that provably BITE on real violations against the live hook, plus the flow/manifest/
system-of-record hardening and the acceptance methodology that makes "authorized" a mechanical, non-overridable
property rather than a convention.

## 2. The round-trip flow (spec → work → assembly → authorization)
```
DOWN (spec → work):
  ARCHITECT ──spec + explicit acceptance criteria + rules──▶ ORCHESTRATOR ──WPs per breakdown/sequence──▶ LANES
  (authors WHAT-of-the-HOW)              (DETERMINES THE SET; membership is an           (execute own WP on own
                                          orchestrator decision, not self-nomination)     branch; intra-lane checks
                                                                                          are the lane's own)
UP (assembly → authorization):
  LANES ──submit completed WP──▶ ORCHESTRATOR assembles the SET, runs TWO checks:
    (A) set × codebase/live-substrate = COHERENCE   (composes; no conflict among members or with prior state)
    (B) set ⊨ the SPEC                = CONFORMANCE  (every member's declared effects satisfy its WP criteria)
    ├─ both pass ──▶ ORCHESTRATOR raises the request ──▶ HUMAN `--by` authorizes ──▶ ORCHESTRATOR-ONLY writes
    │                                                     the set record + reaps the WHOLE set (no cherry-pick)
    └─ any fail  ──▶ failing task → owning lane REDO ──▶ resubmit ──▶ re-check
                 └─ unresolved ──▶ ORCHESTRATOR ──▶ ARCHITECT (adjudicate) ──▶ (if needed) HUMAN ──▶ back down
```
- **R1 — the orchestrator determines the set** (its decomposition of the architect's spec into WPs). Membership
  is an orchestrator decision, minted at DISPATCH, not reverse-engineered at assembly, and never lane
  self-nomination.
- **R2 — the set's boundary is the REQUIREMENT, not effort or lane-count.** (See §3.)
- **R3 — two checks, both required:** (A) coherence, (B) conformance-to-spec.
- **R4 — pass ⇒ orchestrator ASKS, human AUTHORIZES, orchestrator WRITES.** The architect assesses the
  evidence (input to the ask) and adjudicates escalations, but does NOT solicit or carry the human pen and never
  writes the record.
- **R5 — fail ⇒ structured return + escalation.** A failed member is STRUCTURALLY barred from the boundary
  regardless of the others.
- **U7 — the orchestrator, and only the orchestrator, writes the set records** to the coherence boundary.

## 3. What a set IS (the requirement rule — R2)
A set = the WPs dispatched for ONE requirement; its identity is born at dispatch. Lane-cardinality is whatever
the requirement dictates:
- **One lane has work, no others → THAT is the set** (single-lane, even single-member). A ready lane is NEVER
  held waiting for unrelated lanes to acquire work. It is still both-checked; cross-member coherence is *vacuous*
  (nothing to collide with), not skipped.
- **A requirement decomposed across ≥2 lanes → ONE set that MUST contain them all** — no partial ratification,
  no cherry-pick (whole-set reap). A lane finishing early DOES wait; that wait is a real coherence dependency.
  A subset is a NEW set (SUBSET RULE), not a partial ratification of the original.
- **Anti-gaming:** the orchestrator is PROHIBITED from staggering/splitting dispatch so a genuinely multi-lane
  requirement is issued as isolated single-lane WPs to shrink sets. Decomposition is by REQUIREMENT, never by
  EFFORT.
- **⚠ ENFORCEMENT GAP (disclosed, forward-work — do not package as closed):** "purposefully split" is an intent
  the gate cannot read; as convention it violates the "no leg on convention" bar. The STRUCTURAL bind (designed,
  not yet wired): the architect's spec DECLARES each requirement's lane/substrate FOOTPRINT (a WHAT-of-the-HOW
  property), and the gate verifies the assembled set COVERS that footprint — a missing footprint-lane → REFUSE.
  Needs (a) footprint-in-spec + (b) dispatch-time set-identity + (c) an assemble-time coverage check. Until
  wired, anti-gaming is an orchestrator discipline, flagged not closed.

## 4. The ratification packet — the set made visible (schema)
The set record is a permanent packet (`_ratification/SET-NNNN.md`) with these load-bearing sections:
- **HEADER** — set id · assembled-by · assembled-at · HEAD sha at assembly (the tree the set was checked
  against; the gate re-verifies this is an ancestor of HEAD, else fail-closed).
- **MEMBERS** — each: id · lane · commit sha · declared surfaces (the paths/effects it wants to land).
- **JOINT-EDGES** — the THREE mechanical conflict classes only (overlapping paths · shared unforkable artifacts ·
  declared-dependency cycles). **Detection honesty:** field-proven, NOT proven-complete; a semantic conflict
  with no path overlap is NOT mechanically caught — it is integrator judgment, recorded in the assessment.
  "none found" is a claim, not a proof, and carries its sweep basis.
- **CONFLICT SWEEP / COHERENCE CHECKS** — set-level checks evaluable only on the JOINT set + evidence.
- **CONFORMANCE (U4B)** — per-member `verdict: PASS|FAIL|MISSING` + method + evidence (see §6).
- **INTEGRATOR ASSESSMENT** — the agent's assessment (logic · evidence · live state · invariants), filled
  BEFORE the human pen (assess-before-ratify).
- **DECISION LINE** — exactly one human decision (the §5 taxonomy), with ratified-by/at/packet-sha.
- **POST-DECISION** — merge order executed · reproduction reference.

## 5. The tooling + the closed decision taxonomy
`ratify.sh` (orchestrator-only, resolver-gated) is the state machine over the packet:
- `assemble [SET-NNNN]` — read the full pending-member ledger, compute the mechanical joint edges, write the
  packet, mark members evaluated.
- `assess SET-NNNN --text|--file` — the integrator agent fills the assessment slot.
- `conformance-check SET-NNNN <member>` — STRUCTURED U4B checker: evaluate the member's machine-checkable
  acceptance criteria → record verdict.
- `conformance SET-NNNN <member> --verdict … --method structured|judgment --evidence …` — the verdict recorder,
  including the bounded-judgment-at-edge path for an irreducibly-prose criterion.
- `ratify SET-NNNN --by '<human>' --rationale-class … --decision <STATE>` — the human pen ONLY; stamps the
  decision; REFUSES if the assessment slot is empty, any joint edge is unresolved, or (for a MERGE decision) any
  member verdict is not PASS.
- **The CLOSED 5-state decision taxonomy** (this is the one deliberate build-up beyond the lifted reference,
  which hardcoded a single accepted state): **RATIFIED · RATIFIED-WITH-SEQUENCE · AMENDED (subset rule) · HELD
  (parked against a NAMED trigger) · REJECTED (→ RETURNED, no-cherry-pick).**

## 6. U4B conformance (set ⊨ spec) — the non-overridable gate
- **What "the spec" is:** each member implements a WP carrying **explicit acceptance criteria** (architect-owned;
  a WP is not dispatchable without them). Conformance = the member's declared effects satisfy those criteria.
- **Verdict production:** STRUCTURED where machine-checkable (a file/object exists, a param is present, a test
  passes, a declared substrate effect matches the system-of-record, a coverage predicate holds) — migrate
  criteria to this form as they harden. Else a BOUNDED JUDGMENT AT THE EDGE: a single-turn structured-output
  judgment over {member changes, the criterion}, recorded with evidence, held only until it distills to
  structured. (An LLM call is justified at the *edge* for irreducibly-prose judgment; it is NEVER placed inside
  a mechanism — all other checks are written code. A metered/recurring judgment call takes a cost/impact review
  + one human sign-off.)
- **The gate:** assess REQUIRES a PASS verdict for EVERY member; `ratify` REFUSES on any FAIL **or MISSING** —
  identical shape to the empty-assessment / unresolved-edge refusals. **No override lever.**
- **Corollary:** a spec with no checkable criteria is not conform-checkable and a member under it cannot PASS —
  which is what makes U4B enforceable.

## 7. Enforcement — the teeth (logic AND wire; verified installed + firing, never asserted from source)
The bar: no leg rests on convention; a break = system failure ⇒ every leg is fail-closed AND proven-to-bite AT
THE WIRE. The gates live in the pre-commit hook, a pre-merge-commit hook, and the reap script:

> **THIS-ENGINE NOTE (WIRE honesty):** this section documents the source program's live-ENFORCED
> execution. In THIS engine revision the pre-merge-commit hook's bytes are **NOT SHIPPED** (the
> `REAP_AT_MERGE=1` sentinel ships in the reap script so a wiring tree composes) — see
> `contracts/C-SET-AUTHORIZATION.md` §2 U6 row. Every other gate row below ships and is
> seeded-fault/FLIP-proven in this engine.

| Leg | Gate | Rule | Fail-closed behavior |
|---|---|---|---|
| **D3 module propose-not-commit** | pre-commit (module-DENY) | a module lane (spine_write:DENY) staging ANY spine-owned path | REJECT exit 1 |
| **carve-out** | pre-commit | the apply-receipt-writer lane may commit SOLELY under its receipts prefix | REJECT exit 1 on any out-of-prefix path |
| **M6(i) coverage** (U4A) | pre-commit | any AUTHORED-spine path the orchestrator stages must be COVERED by a member of a **RATIFIED** set at HEAD | REJECT exit 1, names the uncovered path + nearest packet. **COVERED[] is built ONLY from `decision: RATIFIED` packets → an unratified/absent packet covers NOTHING (empty-coverage → reject everything).** |
| **M6(ii) NO-CHERRY-PICK** (U6) | reap script | module→trunk content lands ONLY inside a ratified set naming that lane | HALT before the merge tree if the branch is not a ratified-set member (no index mutation) |
| **forced merge-path** | pre-merge-commit | any merge into the trunk must carry the reap sentinel (an env sentinel, NOT a forgeable message) | REJECT unless the sanctioned reap path set it; a conflicted raw merge is caught downstream at the commit by M6(i) |
| **U5 human pen** | ratify | `--by` mandatory; REFUSES empty-assessment + unresolved-edge; orchestrator-only | REFUSE |
| **U7 orchestrator-only write** | ratify + reap + custody fork | only the orchestrator writes the set record | structural |
| **currency-verification** | boot check | the INSTALLED hook must be byte-identical to source | HALT-LOUD if installed ≠ source (a stale/absent gate must never silently pass) |

- **The install/invocation is itself fail-closed:** auto-install + boot-time currency verification (a drifted
  hook halts loud), and a forced merge-path so M6(ii) cannot depend on the integrator remembering to run the
  reap script.
- **RESIDUAL (disclosed, forward-work — NOT a hole):** a FAST-FORWARD merge of a module into the trunk creates
  no merge commit ⇒ no pre-merge-commit hook fires — structurally beyond that hook's reach. It requires the
  trunk to be a strict ancestor of the module tip, which does not hold while the orchestrator is ahead (the reap
  is `--no-ff`), so it does not occur in this workflow. The structural close is a server-side/pre-push ff-bar
  (tracked-forward). NOTE for packagers: an interim `merge.ff=false` belt was CONSIDERED and WITHDRAWN — because
  the hook rejects every non-sentinel merge into the trunk, `merge.ff=false` would route a routine upstream
  fast-forward SYNC into the reject path and break the orchestrator's own sync. A non-composing belt is worse
  than none; do not read "forced merge-path" as ff-airtight.

## 8. The member manifest + system-of-record
- **A member is a MANIFEST, not merely a git diff:** a lane's declaration of every change it wants to make
  across every substrate (code, migrations, and any external system it touches), so the set is evaluable as a
  whole and the declared effects are checkable later.
- **The spine is the system-of-record.** For every external system a **structure-of-record / check-reference**
  documents the declared effects from the spine, with an honest currency posture: what is git-spine
  LIVE-VERIFIED vs what is documented-from-spine and separately owed a live cross-check. A checker enforces
  completeness / currency / secrets-never — and never fabricates live state.

## 9. Definition of Done + the biting-proof methodology
A set-authorization capability is DONE only when it BITES on real data:
- A real ratification packet in-repo · a coherent work-unit · the acceptance rubric (§10) all PASS · the human
  `--by` pen · a reap receipt line.
- **Biting-proof methodology:** each gate must demonstrably REJECT a real (non-synthetic) violation on real data
  against the LIVE installed hook — a normal commit/merge (NEVER a `--no-verify` bypass), gate exit non-zero,
  HEAD unchanged, the probe reverted, the tree clean, and a **rejection receipt whose provenance travels** (lane
  · path · gate · rule · verbatim stderr). Both polarities are proven: the ACCEPT (a covered member lands
  through the same gate once the set is ratified) and the REJECT.
- **Verification against source (for a non-executing assessor):** the captured stderr is matched CHAR-FOR-CHAR
  to the live gate source, the fail-closed logic is proven correct, spoke captures are committed to the object
  store and independently re-readable, and each reject's "real blocked work" premise is confirmed genuine (a
  rejected commit leaves no object-store trace — the receipt + source-provability + real-premise is the
  faithful-narration proof the live hook must produce).

## 10. The acceptance rubric (A–D) — how the architect assesses a set's biting proof
- **A · COHERENCE:** the members compose — no conflict among members, none with prior authorized state.
- **B · CONFORMANCE (U4B):** every member's declared effects satisfy its WP's explicit acceptance criteria;
  per-member PASS + evidence recorded; ratify REFUSES on any FAIL or MISSING (non-overridable).
- **C · BITING—ACCEPT:** a member whose non-exempt spine paths ARE covered by the ratified set LANDS through the
  live coverage + forced-merge gates. This — not an exempt/carve-out path — is the accept proof.
- **D · BITING—REJECT (on real data, live hook, receipt captured):** (i) a spine commit whose paths are NOT
  covered by any ratified set is REJECTED by the coverage gate, fail-closed; (ii) a module→trunk member forged
  OUTSIDE a ratified packet HALTs on no-cherry-pick. Both demonstrated, each with a provenance-traveling receipt.

## 11. Completion evidence (first live-ENFORCED execution)
The first real set was assembled, checked, and its full gate battery captured live:
- A small coherent read-only work-unit (a set of members jointly completing one requirement), 0 mechanical joint
  edges, both members U4B **PASS** against architect-blessed machine-checkable criteria.
- **A–D = FINAL PASS.** The reject battery captured live: §10 empty-assessment · U5 no-`--by` · U4B
  MISSING-verdict · **M6(i) coverage** (a genuinely-wanted integrator re-stamp, blocked) · **M6(ii)
  NO-CHERRY-PICK** (the forced-merge-path) · the carve-out reject · the module-DENY reject — each a normal
  commit/merge (no bypass), gate exit non-zero, HEAD unchanged, receipt with traveling provenance, stderr
  matched char-for-char to live source.
- The set was then RATIFIED by the human pen and REAPED end-to-end: the covered non-exempt member LANDED on the
  trunk through the live coverage + forced-merge gates AFTER ratification — the SAME command that HALTed
  pre-ratify (no-cherry-pick) now AUTHORIZED the land (the accept polarity: the gate authorizes as well as
  refuses), the reap-receipt recording `joint edges = NONE`, with ZERO leak of the excluded lane artifacts to the
  trunk (integration-exclusion verified). Criterion C is thus EMPIRICAL, not by-construction.
- The ACCEPT polarity was confirmed EMPIRICALLY on BOTH enforcement paths, independently: (i) a covered member
  landing through the module→trunk forced-merge gate, and (ii) a covered orchestrator-authored commit landing
  through the COVERAGE gate — the very gate that had REJECTED those same paths while they were uncovered. The gate
  authorizes on both paths exactly as it refuses on both. (Path (ii) came from a later bookkeeping set, not the
  first execution — cited only as the second accept-path data point.)
- This is the first time the set-authorization thesis was proven ENFORCED **end-to-end** — not only rejecting
  violations but authorizing + landing a conformant set on both enforcement paths (the model existed as reference;
  here it bites AND admits).

## 12. Custody / roles (generic)
- **Architect** authors the spec + explicit acceptance criteria + rules; assesses the biting proof; adjudicates
  escalations. Does not execute mechanisms, does not carry the human pen, does not write the set record.
- **Orchestrator** decomposes into WPs, determines set membership at dispatch, assembles + assesses, raises the
  authorization request, and is the SOLE writer of the set record + reaper.
- **Lanes** execute their own WP on their own branch; intra-lane checks are the lane's own; they PROPOSE spine
  changes via the reap path, they do not commit the spine.
- **Human** holds the one authorization pen (`--by`) at ratify-time, after the agent assessment.

## 13. Forward-work (disclosed, NOT packaged as closed)
- The anti-gaming **enforcement gap** (§3): spec-declared requirement footprint + dispatch-time set-identity +
  assemble-time coverage check.
- The fast-forward **ff-residual** (§7): a server-side/pre-push ff-bar for the structural close.
- Per-substrate system-of-record **live checkers** (§8): move documented-from-spine effects to live-verified.
- Migrate prose acceptance criteria to **structured** verdicts as they harden (§6).

===================================================================================================
# END EXPORT BODY
===================================================================================================
