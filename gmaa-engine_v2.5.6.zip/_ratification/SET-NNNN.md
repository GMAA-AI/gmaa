# SET-NNNN — set ratification packet (TEMPLATE)

> This is the blank packet TEMPLATE. The integrator copies it to `_ratification/SET-<n>.md` at assemble
> (`scripts/ratify.sh assemble …`). Module lanes contribute member entries via their OWN branches and NEVER
> write the packet (D3 spine-DENY). No live packet ships in this scaffold — the adopter mints its own.
>
> SCAR (canon §4): serialized transport hides the set; it does not dissolve it. Members are each ratified
> alone; joint evaluation must run. This packet is the set made visible — ON TOP of per-change review.
>
> DETECTION HONESTY (canon §13): the JOINT-EDGES are the MECHANICAL classes only — Layer A (overlapping
> paths · shared unforkable artifacts · declared-dependency cycles) + Layer B (§2.3 SoR SHARED-RECORD — same
> sproc/probe id cited across DIFFERENT files) + footprint edges (UNDECLARED-OCCUPANT · UNDECLARED-SUBSTRATE).
> Object names, seats/SLOTS keys, contract SECTIONS and two contradicting prose sentences are NOT mechanically
> caught. That residual is UNSKIPPABLE — carried by the required `## SEMANTIC HUNT` slot + INTEGRATOR ASSESSMENT.
>
> COHERENCE LAW (§2.3): Mechanical JOINT-EDGES = NONE does NOT mean the set is coherent. MERGE is legal only
> after the SEMANTIC HUNT verdict is CLEAR or every named edge is resolved.

## HEADER
- set id: SET-NNNN
- requirement id: {{REQ-ID}}
- footprint.lanes (spec, §2.2): [{{lanes}}] · assembled: [{{lanes}}] · coverage: {{EXACT|…}}
- wave id: {{WAVE}}
- assembled-by: {{integrator}}
- assembled-at: {{UTC}}
- HEAD sha at assembly: {{sha}}

## MEMBERS
- {{member-id}} · lane={{lane}} · {{branch}}@{{sha}} · surfaces: {{path,path}}

## JOINT-EDGES (mechanical; the floor)
- {{NONE | SHARED-RECORD [id] (members X,Y) | path-overlap … }}
  NOTE: NONE is the mechanical result only — semantic joint incoherence is not detectable here and must be
  weighed in INTEGRATOR ASSESSMENT (canon §13).

## CONFLICT SWEEP
- (integrator: subagent sweep of live docs + codebase across the joint set; findings + evidence paths here.
  'none found' requires the sweep receipt.)

## COHERENCE CHECKS
- (integrator: each set-level check — evaluable only on the JOINT set — · result · evidence path.)

## CONFORMANCE (U4B — per-member: declared effects ⊨ the member's WP acceptance criteria; §2.1)
> The GATE is mechanical + fail-closed + NON-OVERRIDABLE: `ratify` REFUSES a MERGE decision unless EVERY
> member carries `verdict: PASS` (with evidence). STRUCTURED checker (`ratify.sh conformance-check SET-NNNN
> <member>`) against `_ratification/criteria/<member>.md` (architect-owned; a member with no checkable criteria
> cannot PASS). An irreducibly-prose criterion takes a RECORDED bounded judgment. MISSING or FAIL → REFUSE.
- {{member-id}} · verdict: {{PASS|FAIL}} · method: {{structured|judgment}} · evidence: {{…}} · at: {{UTC}}

## INTEGRATOR ASSESSMENT (filled by `ratify.sh assess`)
- assessed-at: {{UTC}}
- {{integrator assessment prose — LOGIC / EVIDENCE / LIVE-STATE / INVARIANTS / COHERENCE / recommendation}}

## SEMANTIC HUNT (canon §13 — REQUIRED; 'none found' is a claim, not a proof — §2.3 Layer C)
> UNSKIPPABLE: `ratify --decision RATIFIED[-WITH-SEQUENCE]` REFUSES on a missing/unfilled block, on verdict
> UNABLE, or on CLEAR asserted with 'candidates considered: ZERO' and no method. Fill via `ratify.sh hunt
> SET-NNNN --method '…' --candidates '<list|ZERO>' --residual '…' --verdict CLEAR|EDGE-NAMED|UNABLE
> [--edges '<name>;<name>']`. EDGE-NAMED names join JOINT-EDGES as INTEGRATOR-JUDGMENT edges. NO LLM stamps
> CLEAR — a model may only hand the integrator a candidate list to sign.
- hunt-at: {{UTC}}
- method: {{what was grepped / which SoR indexes opened}}
- candidates considered: {{list | ZERO}}
- residual risk: {{one sentence}}
- verdict: {{CLEAR | EDGE-NAMED | UNABLE}}

## BRIEFING (grounded alternatives for any contestable member)
- (integrator, as needed.)

## DECISION LINE (operator — exactly one; C-RATIFICATION-PACKET §3) + RATIONALE CLASS (§4)
- decision: {{RATIFIED | RATIFIED-WITH-SEQUENCE | AMENDED | HELD | REJECTED}}
- ratified-by: {{human}}
- at: {{UTC}}
- packet sha (pre-stamp): {{sha256}}
- rationale class: {{in-band | OUT-OF-BAND}}

## POST-DECISION
- merge order executed (if -WITH-SEQUENCE): —
- auditor reproduction ref: —
