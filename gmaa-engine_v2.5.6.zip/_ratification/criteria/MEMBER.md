# criteria/<member-id>.md — WP acceptance criteria (TEMPLATE)

> The architect authors the acceptance criteria for each WP/member; the integrator transcribes them here at
> dispatch (a member with NO checkable criteria file is NOT conform-checkable and CANNOT pass U4B — §2.1
> corollary). Module lanes NEVER write this file (it is spine-resident, D3 module-DENY — the integrity guard
> that a member cannot forge its own criteria). One file per member id; the filename == the member id.

## MEMBER
- member-id: {{member-id}}
- requirement-id: {{REQ-ID}}
- set-id (when assembled): SET-NNNN

## ACCEPTANCE CRITERIA (each row: a machine-checkable OR bounded-judgment predicate over the member's declared effects)
| # | criterion | class | checkable-by |
|---|---|---|---|
| AC1 | {{a file/object exists · a sproc has param X · a test passes · a declared effect matches the §5 structure-of-record}} | structured | `ratify.sh conformance-check` |
| AC2 | {{an irreducibly-prose criterion — e.g. "the review reads naturally"}} | judgment | recorded bounded judgment (§2.1, SANCTIONED) |

> **PARSER LINE FORM (the checker is the mechanism; this table is illustration — ruled 2026-08-19).**
> What `ratify.sh conformance-check` actually PARSES is one criterion per line, in exactly this shape:
> `- [exists] <path>` · `- [absent] <path>` · `- [grep] <ERE> :: <path>` · `- [test] <shell>` ·
> `- [judgment] <prose>`. Author the machine-read criteria in that line form; a table row is NOT
> parsed and fails closed (all-FAIL, never false-PASS).

## NOTES
- STRUCTURED criteria are preferred (no LLM); migrate judgment criteria to structured as they harden.
- The per-member CONFORMANCE verdict + evidence lands in the `_ratification/SET-NNNN.md` packet at ratify time.
