# SLOTS.md — adopter slot inventory (spine-owned)

This is the single inventory of every **slot** in the engine: a place an adopter fills to instantiate
the generic engine for their project. One row per slot. It is the authority the engine-update
classifier (`scripts/engine-update-classify.sh`, `docs/ENGINE-UPDATE.md`) reads to tell a **SLOT FILL**
(preserve/re-apply) from an **ENGINE DELTA** (apply) during an upgrade — so a slot absent from this
file is invisible to the upgrade path. Keep it complete.

**Shapes.** `{{TOKEN}}` = a literal placeholder token replaced in-place · *prose section* = a marked
adopter-wiring block (`C-DB SLOT` / `C-GATE SLOT` / an "adopter stub") that is a harmless no-op until
wired · *concrete file* = a file the adopter creates (not shipped in the blank).

**Status legend.** `core` = engine-generic, always meaningful · `C-DB (opt)` / `C-GATE (opt)` = optional
adopter-wiring stack, no-op when unwired · `skeleton` = placeholder inside an adopter skeleton doc ·
`⚑ naming` = the token's NAME is domain-flavored (a publish/seed/first-party shape carried from the
FORM-1 genericization, operator-ruled 2026-08-06); it is an intended optional slot — the flag is a
surfacing note for the architect, **inventory-only, not an open decision**.

---

## THE SLOT-CONTRACT RULE (binding; mirrored in CHANGELOG.md)

> **Any change to a slot's SHAPE or CONTRACT (this file's "shape"/"contract" columns) MUST be listed in
> `CHANGELOG.md` under a heading named exactly `Slot-contract changes`, stating the old→new contract.
> Absent that heading, every existing adopter fill MUST keep working unchanged** — a release with no
> `Slot-contract changes` heading is a promise that no fill breaks. The engine-update runbook
> (`docs/ENGINE-UPDATE.md`) STOPs on any slot whose contract moved per that heading, so an unannounced
> contract move is a defect this rule exists to catch.

---

## 1 · Per-lane identity — `_boot/BOOTSTRAP.md` frontmatter + `_boot/CHARTER-<lane>.md`

| id | surface (file · token) | shape | contract a fill must satisfy | default in blank | example |
|---|---|---|---|---|---|
| `{{LANE}}` | `_boot/BOOTSTRAP.md` (`lane:`, body) + `CHARTER-<lane>.md` filename | `{{TOKEN}}` | MUST equal the worktree folder name (folder-equals-lane, `resolve-lane.sh` cross-check) and the `CHARTER-<lane>.md` filename; single token, no spaces | `{{LANE}}` | `foundation` |
| `{{PROJECT}}` | `_boot/BOOTSTRAP.md` (`project:`, after `lane:`) | `{{TOKEN}}` | device-wide project token (canon §7.2/7.3); qualifies the tmux session `{project}-{lane}`; a value still beginning `{{` HALTs `resolve-project.sh` (exit 3, "unfilled project slot"); key absent = legacy bare-lane + loud warning; MANDATORY on any device hosting ≥2 projects | `{{PROJECT}}` | `gmaa` |
| `{{ROLE}}` | `_boot/BOOTSTRAP.md` (`role:`, body) | `{{TOKEN}}` | the seat's role class | `{{ROLE}}` | `integrator` / `executor` / `module-single-writer` |
| `{{SPINE_BRANCH}}` | `_boot/BOOTSTRAP.md` (`worktree_branch:`) | `{{TOKEN}}` | integration branch for this worktree; `main` for foundation, the module branch for module lanes | `{{SPINE_BRANCH}}` (intended `main`) | `main` |
| `{{SPINE_WRITE}}` | `_boot/BOOTSTRAP.md` (`spine_write:`) | `{{TOKEN}}` | DOCUMENTS the enforced authority class (`ALLOW` foundation/integrator · `DENY` module lanes); enforcement is `agents/pre-commit-hook.sh` keyed on the resolved lane, NOT this field | `{{SPINE_WRITE}}` | `ALLOW` |
| `{{PROJECT_NAME}}` | `_boot/CHARTER-foundation.md`, `disciplines.md` title, state-source paths | `{{TOKEN}}` | repo/project display name used in state-source paths + titles (distinct from `{{PROJECT}}`, the tmux-session token) | `{{PROJECT_NAME}}` | `gmaa` |
| `{{SUBAGENT_MODEL}}` | `_boot/BOOTSTRAP.md` (`subagent_model`) + `.claude/agents/*.md` (`model:`) | `{{TOKEN}}` | one declared model string all subagents run on; PRIMARY enforcement = agent-def frontmatter (read at spawn); this field keeps it spine-current | `{{SUBAGENT_MODEL}}` | `claude-sonnet-4-5` |
| `{{RULING}}` | rule-stated genericization blanks (e.g. BOOTSTRAP BOOT-CREED "ratified … as {{RULING}}") | `{{TOKEN}}` (redacted project-IP blank) | the adopter's own ruling id/citation for the named rule; MAY be left generic if the adopter has no citation | `{{RULING}}` | `_rulings/0007` |

## 2 · Spine, roster, lanes

| id | surface | shape | contract | default in blank | example |
|---|---|---|---|---|---|
| `seats.yaml` | repo root | *concrete file* (NOT shipped in blank) | adopter roster (`seats:`) + `spine_paths:` declaration; spine-owned + SET-GATED (a foundation edit needs a ratified set — architect ruling 2026-08-17, it is declared spine CONFIGURATION); read HEAD-side by `scripts/declared-spine-paths.sh` | absent → base spine set only | `seats:\n  - foundation\nspine_paths:\n  - db/` |
| `{{PROJECT_SPINE_PATHS}}` | `seats.yaml` (`spine_paths:`) — token named in `agents/pre-commit-hook.sh` comment | declared list (via `seats.yaml`) | the adopter's declared spine roots; appended to the base `SPINE_PATHS` at HEAD by `declared-spine-paths.sh` and gated in pre-commit + ratify + set-gate probe | none (blank → base set) | `db/`, `migrations/` |
| `{{MODULE_LANE}}` | `contracts/SPEC-REAPER.md` (prose example) | `{{TOKEN}}` | an illustrative module-lane name in the reaper spec; genericized instance name | `{{MODULE_LANE}}` | `module-a` |

## 3 · Execution / gate — `C-GATE SLOT` (optional; no-op if no gate executor is wired)

| id | surface | shape | contract | default in blank | example |
|---|---|---|---|---|---|
| `{{EXECUTE_MECHANISM}}` | `_boot/CHARTER-executor.md`, `contracts/ref-impl/*` (actor), `CLAUDE.md` | `{{TOKEN}}` | the concrete execution binding for the executor lane (the mechanism `fire_ref.sh`/`apply_ref.sh` stand in for); wire your gate endpoint here | `{{EXECUTE_MECHANISM}}` | a gate-executor endpoint/handle |
| `{{FUNCTION_APP}}` | `CLAUDE.md` repo layout + `§Structured outputs` | `{{TOKEN}}` | the execution function-app directory/name | `{{FUNCTION_APP}}` | `gate-exec` |
| `{{GATE_LABEL}}` | `contracts/C-GATE.md` | `{{TOKEN}}`-class | neutral continuous gate-label scheme `G1…G13` (structure unchanged; labels genericized, operator ruling 2026-08-06); a fill relabels to the adopter's gates | `{{GATE_LABEL}}` (`G1…G13`) | `G7` |
| `{{DIRECT_SEED_SENTINEL}}` | `contracts/C-GATE.md`, `contracts/C-DB.md` | `{{TOKEN}}` | sentinel value marking the direct-seed path (`C-GATE`/`C-DB opt`) | `{{DIRECT_SEED_SENTINEL}}` | a sentinel string |
| `{{FIRSTPARTY_SENTINEL}}` | `contracts/C-GATE.md`, `contracts/C-DB.md` | `{{TOKEN}}` | sentinel value marking the first-party path (`C-GATE`/`C-DB opt`) | `{{FIRSTPARTY_SENTINEL}}` | a sentinel string |
| `{{WORK_QUEUE}}` | `contracts/C-DB.md` | `{{TOKEN}}` | the direct-seed work-queue object name (`C-DB opt`) | `{{WORK_QUEUE}}` | a queue table name |
| `{{PUBLISH_TARGET}}` | `contracts/C-DB.md` | `{{TOKEN}}` | the publish-target object name (`C-DB opt`) | `{{PUBLISH_TARGET}}` | a publish table/target name |

*Status: `{{GATE_LABEL}}` `C-GATE (opt)`, `core`-adjacent. `{{DIRECT_SEED_SENTINEL}}` `{{FIRSTPARTY_SENTINEL}}`
`{{WORK_QUEUE}}` `{{PUBLISH_TARGET}}` = `C-GATE/C-DB (opt)` + `⚑ naming` (publish/seed/first-party shape,
operator-ruled FORM-1 genericization 2026-08-06 — intended optional slots; naming flagged for architect
awareness only).*

## 4 · Database — `C-DB SLOT` (optional; no-op if no database is wired)

| id | surface | shape | contract | default in blank | example |
|---|---|---|---|---|---|
| `{{SCHEMA}}` | `contracts/C-DB.md` (schema INVENTORY §1) | `{{TOKEN}}` | primary DB schema qualifier | `{{SCHEMA}}` | `dbo` |
| `{{REF_SCHEMA}}` | `contracts/C-DB.md` | `{{TOKEN}}` | reference-data schema qualifier | `{{REF_SCHEMA}}` | `ref` |
| `{{PUBLISH_SCHEMA}}` | `contracts/C-DB.md` | `{{TOKEN}}` | publish schema qualifier (`C-DB opt`, `⚑ naming`) | `{{PUBLISH_SCHEMA}}` | `pub` |
| `{{DB_APP_USER}}` | `CLAUDE.md` §WRITE-VIA-MECHANISM | `{{TOKEN}}` | the workload app user that MUST have INSERT/UPDATE/DELETE = 0 (EXECUTE-only; writes go via mechanism) | `{{DB_APP_USER}}` | `app_workload` |
| `{{DB_RUNNER}}` | `agents/standing-probes.yaml` (mediated-write-zero) | `{{TOKEN}}` | the adopter's SQL runner command | `{{DB_RUNNER}}` | a sqlcmd wrapper |
| `{{DB_MEDIATED_WRITE_PROBE}}` | `agents/standing-probes.yaml` GENERIC-INVARIANT #1 | `{{TOKEN}}` (probe path) | path to the adopter's mediated-write-zero probe; wired as standing-probe #1 | `{{DB_MEDIATED_WRITE_PROBE}}` | `probes/c-db/probe_mediated_write_zero.sql` |

## 4a · Cost-brake caps — `contracts/COST-CAPS.md` (REQ-COST SLOT; C-SET-AUTHORIZATION §2.4)

The engine ships the brake (`scripts/cost-guard.sh`, exit 0 under · 2 at/over HALT · 3 unreadable
HALT) + this EMPTY caps slot. Fail-closed: an unfilled cap on a metered path HALTs (exit 3) —
never assumed zero. The numbers are the adopter operator's (operator-movable), never the engine's.

| id | surface | shape | contract | default in blank | example |
|---|---|---|---|---|---|
| `{{PER_UNIT_USD}}` | `contracts/COST-CAPS.md` (`caps:`) | `{{TOKEN}}` | per-unit spend cap in USD; `cost-guard.sh check --unit` HALTs exit 2 at/over | `{{PER_UNIT_USD}}` (unfilled → exit 3) | `1.00` |
| `{{PER_COHORT_USD}}` | `contracts/COST-CAPS.md` (`caps:`) | `{{TOKEN}}` | per-cohort spend cap in USD (`--cohort`) | `{{PER_COHORT_USD}}` (unfilled → exit 3) | `10.00` |
| `{{METER}}` / `{{USD_PER_UNIT}}` | `contracts/COST-CAPS.md` (`prices:`) | `{{TOKEN}}` pair | per-meter USD-per-token price rows for rows with `tokens` and no `usd_actual`; an unpriceable row → exit 3 | `{{METER}}: {{USD_PER_UNIT}}` | `tokens-in: 0.000003` |

## 5 · Adopter skeletons — `docs/*_skeleton.md` (fill to instantiate; `skeleton` status)

| id | surface | shape | contract | default in blank | example |
|---|---|---|---|---|---|
| `{{SEAT_A_NAME}}` | `docs/CHAT-SEAT-PROJECT-INSTRUCTIONS_skeleton.md` | `{{TOKEN}}` | name of the operator's first special chat seat | `{{SEAT_A_NAME}}` | `architect` |
| `{{SEAT_A_TRIGGER}}` | same skeleton | `{{TOKEN}}` | the operator opening-direction phrase that selects seat A | `{{SEAT_A_TRIGGER}}` | `"you are the architect"` |
| `{{SEAT_A_CHARTER_FILE}}` | same skeleton | `{{TOKEN}}` | seat A's charter file path | `{{SEAT_A_CHARTER_FILE}}` | `_boot/CHARTER-architect.md` |
| `{{DEFAULT_SEAT_NAME}}` | same skeleton | `{{TOKEN}}` | the default ("everything else") chat seat name | `{{DEFAULT_SEAT_NAME}}` | `reader` |
| `{{DEFAULT_SEAT_CHARTER_FILE}}` | same skeleton | `{{TOKEN}}` | the default seat's charter file path | `{{DEFAULT_SEAT_CHARTER_FILE}}` | `_boot/CHARTER-reader.md` |
| `{{CODE_WRITE_ROOT}}` | same skeleton | `{{TOKEN}}` | the code seat's write territory (its allowed write roots) | `{{CODE_WRITE_ROOT}}` | `build/`, `extraction/` |
| `{{REGISTER_FILE}}` | same skeleton | `{{TOKEN}}` | the project's issues/register file path | `{{REGISTER_FILE}}` | `issues_register.md` |
| `{{PROJECT_PREFIX}}` | `docs/FIELD-EVIDENCE_skeleton.md` | `{{TOKEN}}` | field-evidence id prefix (`{{PROJECT_PREFIX}}-E-nnn`) | `{{PROJECT_PREFIX}}` | `GMAA` |

## 6 · Ratification / status prose

| id | surface | shape | contract | default in blank | example |
|---|---|---|---|---|---|
| `{{WAVE}}` | `scripts/ratify.sh` (packet template, `- wave id:`) | `{{TOKEN}}` | the wave id a ratification packet belongs to | `{{WAVE}}` | `W1` |
| `{{OPERATOR_CUSTODY_ITEM}}` | `scripts/status.sh` (operator-custody list) | `{{TOKEN}}` | one illustrative operator-custody queue item (apex go/no-go · credential · final publish) | `{{OPERATOR_CUSTODY_ITEM}}` | `an apex go/no-go` |

## 7 · Prose-section & config slots (not `{{TOKEN}}`)

| id | surface | shape | contract | default in blank |
|---|---|---|---|---|
| `C-DB SLOT` | `CLAUDE.md §Apply paths`, `contracts/C-DB.md`, `contracts/OPERATING-DISCIPLINE.md`, `agents/standing-probes.yaml` #1 | prose section + optional file stack | wire the DB apply/mechanism stack (`{{SCHEMA}}`… + `{{DB_*}}` above) OR leave as a harmless no-op | no-op stubs |
| `C-GATE SLOT` | `CLAUDE.md §Structured outputs`, `contracts/C-GATE.md`, `.claude/agents/orc.md` | prose section | wire the LLM-backed gate executor (`{{EXECUTE_MECHANISM}}`, `{{FUNCTION_APP}}`, `{{GATE_LABEL}}`…) OR no-op | no-op |
| `disciplines.md §2` | `disciplines.md` | prose section | the adopter's own `DISC-` patterns EXTEND the generic §1 set (never replace) | generic §1 only |
| `docs/FOUNDATION.md` adopter stubs | `docs/FOUNDATION.md` Parts I–VI | prose stubs | adopter fills project rationale / vision / architecture / compliance / reference | stub headings |
| `settings.json` allow-list | `.claude/settings.json` | JSON | shared vetted permission allow-list (spine-owned; a module cannot widen it); adopter ADDS entries here | base safe set |
| `settings.local.json` | `.claude/settings.local.json` | JSON | per-worktree local additions (gitignored; NOT shipped/spine) | absent |
| `standing-probes.yaml` slot entries | `agents/standing-probes.yaml` | YAML entries | the `{{DB_MEDIATED_WRITE_PROBE}}` / `{{DB_RUNNER}}` C-DB probe row (#1); adopter fills path+runner or leaves no-op | `{{…}}` no-op |

---

## Adding a slot
When a new adopter-fill point is introduced anywhere in the engine, add its row here in the same
commit — an unlisted slot is invisible to `docs/ENGINE-UPDATE.md` classification and will be
mis-treated as an ENGINE DELTA on the next upgrade (overwriting the adopter's fill). `SLOTS.md` is in
`SPINE_PATHS` (foundation-owned; set-gated).
