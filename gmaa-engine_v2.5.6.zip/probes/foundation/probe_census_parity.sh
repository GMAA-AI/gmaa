#!/usr/bin/env bash
# probes/foundation/probe_census_parity.sh — spine-census single-source parity (Issue-1 recurrence guard).
#
# CLAIM (v2.5.6 r3): the spine census has ONE source — scripts/spine-census.sh — and NO spine
# enforcer's EFFECTIVE census diverges from it IN ANY FORM (assignment, case-table, function, regex).
#
# WHY BEHAVIORAL (r3 Blocker 2 — the r2 design error, corrected): the first parity probe grepped for
# census-literal ASSIGNMENTS (SPINE_RE=/SPINE_PATHS=(/SPINE_PREFIXES=() and PASSED while a FIFTH,
# divergent census sat in probe_set_gate.sh as a hand-typed `case` table (missing SLOTS.md). A
# recurrence guard whose seeded fault only exercises the form that did NOT break is the exact
# test-gap class that let Issue 1 seal. So the primary detection is now BEHAVIORAL: for each
# enforcer, this probe EXTRACTS the enforcer's own census-population code + membership function
# (its real bytes — whatever form the census takes inside) and DRIVES that function against every
# path scripts/spine-census.sh emits. For each census path not in the enforcer's DECLARED per-gate
# exemptions, the enforcer must classify it spine — else FAIL naming enforcer + path. It tests the
# VERDICT, not the syntax. Extraction failure / a bash error / a missing verdict = FAIL (fail-closed).
#
# A SYNTACTIC layer is KEPT as a second net: a reintroduced census-literal ASSIGNMENT in an enforcer
# is drift-seed even while dormant (dead code today, someone's "authoritative list" tomorrow) — the
# behavioral layer cannot see dead code, the grep can.
#
# ENFORCERS + their DECLARED exemptions (the honest-exemption ledger — a census path an enforcer may
# legitimately classify non-spine; anything else classified non-spine = drift):
#   agents/pre-commit-hook.sh                       is_spine            (exempt: none — pure membership)
#   scripts/reap_at_merge.sh                        is_spine            (exempt: none — pure membership)
#   scripts/ratify.sh                               is_spine_path       (exempt: none — pure membership)
#   probes/foundation/probe_state_propagation.sh    is_spine            (exempt: none — prop_exempt is a
#                                                                        separate downstream filter)
#   probes/foundation/probe_set_gate.sh             is_authored_spine   (exempt: ledger/ PENDING-SET.md
#                                                                        _ratification/ dispatch/LATEST.md
#                                                                        _orchestration/decision-log.md
#                                                                        _orchestration/lane-provisioning.md
#                                                                        — the A3 running-state list, baked
#                                                                        into the fn per its gate semantics)
#
# run_by auditor (agents/standing-probes.yaml, id: census-parity); emit-on-FAIL / state-change.
# EXIT 0 = PASS · 1 = FAIL · 2 = RUN_ERROR.
set -u
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "CENSUS-PARITY RUN_ERROR: not a git worktree"; exit 2; }

CENSUS="$REPO_ROOT/scripts/spine-census.sh"
if [[ ! -x "$CENSUS" ]]; then
    echo "CENSUS-PARITY FAIL: the single census source scripts/spine-census.sh is missing or not executable — consumers cannot single-source."
    exit 1
fi
CENSUS_PATHS="$("$CENSUS" 2>/dev/null)"
if [[ -z "$CENSUS_PATHS" ]]; then
    echo "CENSUS-PARITY FAIL: scripts/spine-census.sh emitted an EMPTY census — every consumer is scanning blind."
    exit 1
fi

# --- enforcer table: file | census array name (extraction anchor) | membership fn | exempt census paths ---
ENFORCER_TABLE='agents/pre-commit-hook.sh|SPINE_PATHS|is_spine|
scripts/reap_at_merge.sh|SPINE_PATHS|is_spine|
scripts/ratify.sh|SPINE_PREFIXES|is_spine_path|
probes/foundation/probe_state_propagation.sh|SPINE_PATHS|is_spine|
probes/foundation/probe_set_gate.sh|SPINE_PATHS|is_authored_spine|ledger/ PENDING-SET.md _ratification/ dispatch/LATEST.md _orchestration/decision-log.md _orchestration/lane-provisioning.md'

fails=""

# ============ LAYER 1 — SYNTACTIC (kept): no dormant census-literal ASSIGNMENT ============
VARS='SPINE_RE|SPINE_PATHS|SPINE_PREFIXES'
while IFS='|' read -r f _init _fn _ex; do
    [[ -z "$f" || ! -f "$REPO_ROOT/$f" ]] && continue
    hits="$(grep -nE "^[[:space:]]*($VARS)=" "$REPO_ROOT/$f" \
            | grep -vE "=\([[:space:]]*\)[[:space:]]*\$" \
            | grep -vE "^\s*[0-9]+:\s*#" || true)"
    if [[ -n "$hits" ]]; then
        fails="${fails}  ${f}: hand-maintained census literal (assignment form):"$'\n'"$(printf '%s\n' "$hits" | sed 's/^/      /')"$'\n'
    fi
done <<< "$ENFORCER_TABLE"

# ============ LAYER 2 — BEHAVIORAL (primary): drive each enforcer's own membership fn ============
# Extract, from the enforcer's REAL bytes, the contiguous region from its census-array init line
# through the closing brace of its membership function (this spans the census-population code — read-
# loop or any regressed literal — plus the function, in the enforcer's own form), then run it in a
# sandbox (cwd = repo root; halt/die stubbed) and ask it to classify every census path.
extract_region() { # file census_array_name fn_name  -> prints the region, or nothing on failure
    awk -v arr="$2" -v fn="$3" '
        BEGIN { initre = "^" arr "=\\(\\)"; fnre = "^" fn "\\(\\)" }
        $0 ~ initre && !on { on=1 }
        on { print }
        on && $0 ~ fnre {
            if ($0 ~ /\}[[:space:]]*$/) exit   # one-liner fn: region ends on the same line
            infn=1; next
        }
        infn && /^\}/ { exit }
    ' "$REPO_ROOT/$1"
}

drive() { # file census_array_name fn_name  -> emits "SPINE <p>" / "NOSPINE <p>" per census path
    local frag
    frag="$(extract_region "$1" "$2" "$3")"
    [[ -z "$frag" ]] && return 9
    # the extracted fragment must actually DEFINE the fn (else the file was refactored away from the
    # expected shape — fail-closed, never assume).
    printf '%s\n' "$frag" | grep -qE "^$3\(\)" || return 9
    GMAA_FRAG="$frag" GMAA_FN="$3" GMAA_ROOT="$REPO_ROOT" GMAA_PATHS="$CENSUS_PATHS" bash -c '
        set -u
        cd "$GMAA_ROOT" || exit 9
        REPO_ROOT="$GMAA_ROOT"
        halt(){ echo "halt: $*" >&2; exit 3; }
        die(){ echo "die: $*" >&2; exit 3; }
        eval "$GMAA_FRAG" || exit 9
        while IFS= read -r p; do
            [[ -z "$p" ]] && continue
            if "$GMAA_FN" "$p"; then echo "SPINE $p"; else echo "NOSPINE $p"; fi
        done <<< "$GMAA_PATHS"
    ' 2>/dev/null
}

while IFS='|' read -r f init fn ex; do
    [[ -z "$f" ]] && continue
    if [[ ! -f "$REPO_ROOT/$f" ]]; then
        fails="${fails}  ${f}: enforcer file MISSING (cannot verify census parity — fail-closed)"$'\n'
        continue
    fi
    verdicts="$(drive "$f" "$init" "$fn")" || { fails="${fails}  ${f}: cannot extract/drive ${fn}() (census-population + membership fn not found in the expected shape — fail-closed; update the parity probe's extraction anchor if the enforcer was legitimately refactored)"$'\n'; continue; }
    while IFS= read -r p; do
        [[ -z "$p" ]] && continue
        v="$(printf '%s\n' "$verdicts" | awk -v p="$p" '$2==p{print $1; exit}')"
        if [[ -z "$v" ]]; then
            fails="${fails}  ${f}: NO VERDICT for census path '${p}' (drive incomplete — fail-closed)"$'\n'
        elif [[ "$v" == "NOSPINE" ]]; then
            # declared per-gate exemption? then a non-spine verdict is the gate's own semantics, not drift.
            exempt=0
            for e in ${ex:-}; do [[ "$p" == "$e" ]] && { exempt=1; break; }; done
            if [[ $exempt -eq 0 ]]; then
                fails="${fails}  ${f}: census path '${p}' NOT classified spine by ${fn}() (effective-census divergence — the Issue-1 drift class, any form)"$'\n'
            fi
        fi
    done <<< "$CENSUS_PATHS"
done <<< "$ENFORCER_TABLE"

if [[ -n "$fails" ]]; then
    echo "CENSUS-PARITY FAIL: enforcer census diverges from scripts/spine-census.sh (or carries a census literal)"
    echo "  (MAINTAINED-STATE DRIFT — the class that held v2.5.5; single-source via the census emitter):"
    printf '%s' "$fails"
    exit 1
fi
echo "CENSUS-PARITY PASS: all 5 enforcers' EFFECTIVE censuses match scripts/spine-census.sh (behavioral drive, exemptions declared) and no census literal is present."
exit 0
