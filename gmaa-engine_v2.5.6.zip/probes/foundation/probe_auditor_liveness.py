#!/usr/bin/env python3
"""probe_auditor_liveness.py — INTEGRATOR-TRIGGER-LIVENESS (resolution-b).
FAIL-never-warn liveness check for the post-commit auditor/integrator trigger.

GENERICIZATION NOTE: mechanism kept whole (Arm A/B/C, thresholds, verdict/exit contract). The only
change vs origin is IDENTITY: the hardcoded project root is replaced by the git-resolved worktree
root (folder-anchored, like scripts/resolve-lane.sh). A dated incident reference is generalized to
its failure-mode class. `run_by: orc` + `exclude_from_auditor: true` are declared in
agents/standing-probes.yaml (id: auditor-liveness).

RUN BY orc (§0 state-verification) AND each integrator pass — NOT by the auditor itself
(a dead auditor cannot run its own liveness check; that circularity is the whole trap).

Arm A — auditor IS firing (keys off the WORKING ledger/audit-runs.log, per architect correction):
  each recent non-[audit] commit older than ARM_A_GRACE_MIN must have an audit-runs.log block
  (its short hash referenced). Absent -> FAIL (auditor not firing).
Arm B — output is VISIBLE (keys off COMMITTED history vs the WORKING file):
  the working audit-runs.log must not reference more than ARM_B_MAX_UNCOMMITTED commits that the
  COMMITTED (HEAD) audit-runs.log does not -> i.e. audit runs are real but not being committed.
  Exceeded -> FAIL (the visibility-gap class: Arm A green, Arm B red).
Arm C — integration backlog: wires when the ready-signal + integrator land (NOT here).

exit 0 + 'VERDICT: PASS' = both arms green. exit 1 + 'VERDICT: FAIL' = either arm red.
Thresholds are starting values (tunable after real tempo)."""
import subprocess, time, sys, os

ROOT = (subprocess.run(["git", "rev-parse", "--show-toplevel"], capture_output=True, text=True).stdout.strip()
        or os.getcwd())
RUNS = os.path.join(ROOT, "ledger/audit-runs.log")
ARM_A_GRACE_MIN = 30      # async auditor needs time to fire
ARM_A_WINDOW = 10         # check the most recent N eligible commits
ARM_B_MAX_UNCOMMITTED = 1 # one in-flight session's appends OK; more = piling up

def sh(args):
    return subprocess.run(args, capture_output=True, text=True, cwd=ROOT).stdout

def recent_commits(n=20):
    out = sh(["git", "log", f"-{n}", "--pretty=%h|%ct|%s"])
    rows = []
    for l in out.splitlines():
        if "|" not in l: continue
        h, ct, sub = l.split("|", 2)
        rows.append((h, int(ct), sub))
    return rows

now = int(time.time())
working = open(RUNS).read() if os.path.exists(RUNS) else ""
committed = sh(["git", "show", "HEAD:ledger/audit-runs.log"]) or ""
commits = recent_commits(20)
fails = []

# ---- Arm A ----
eligible = [(h, ct, s) for (h, ct, s) in commits
            if not s.startswith("[audit]") and (now - ct) > ARM_A_GRACE_MIN * 60][:ARM_A_WINDOW]
missing = [(h, s) for (h, ct, s) in eligible if h not in working]
if eligible and missing:
    fails.append(f"Arm A (auditor firing): {len(missing)}/{len(eligible)} eligible commits have NO "
                 f"audit-runs.log block: " + ", ".join(h for h, _ in missing))
arm_a = "FAIL" if (eligible and missing) else ("PASS" if eligible else "PASS(vacuous: no commit >grace yet)")

# ---- Arm B ----
# commits whose audit block exists in WORKING but not in COMMITTED ledger = uncommitted audit output
lag = [(h, s) for (h, ct, s) in commits
       if not s.startswith("[audit]") and h in working and h not in committed]
if len(lag) > ARM_B_MAX_UNCOMMITTED:
    fails.append(f"Arm B (output visible): {len(lag)} audited commits in WORKING audit-runs.log are "
                 f"NOT in COMMITTED ledger (>{ARM_B_MAX_UNCOMMITTED}): " + ", ".join(h for h, _ in lag)
                 + " — auditor runs but commits are being missed; commit the [audit] backlog.")
arm_b = "FAIL" if len(lag) > ARM_B_MAX_UNCOMMITTED else "PASS"

print(f"Arm A (auditor firing)  : {arm_a}")
print(f"Arm B (output visible)  : {arm_b}  (uncommitted audited commits: {len(lag)})")
print("Arm C (integration backlog): N/A — wires with ready-signal")
if fails:
    for f in fails: print("  -", f)
    print("VERDICT: FAIL"); sys.exit(1)
print("VERDICT: PASS"); sys.exit(0)
