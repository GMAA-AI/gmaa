#!/usr/bin/env bash
# probes/foundation/probe_set_gate.sh — standing probe for the set-level authorization gate.
#
# CLAIM: every foundation commit that changed an AUTHORED-spine path, since the last RATIFIED
# packet's assembly point, is covered by a member of a ratified set at HEAD (or is an enumerated
# exemption). This is the post-hoc mirror of the pre-commit set-coverage gate (agents/pre-commit-hook.sh
# M6(i)) — it catches a spine change that reached main WITHOUT set authorization (e.g. a --no-verify
# bypass, or a hook that was not installed). Wired in agents/standing-probes.yaml (run_by auditor).
#
# EXIT: 0 = PASS (all authored-spine changes covered) · 1 = FAIL (a planted/real uncited spine commit)
#       · 2 = RUN_ERROR (not a repo / cannot read).
#
# GENERICIZATION NOTE: built to canon §4 + the shipped C-RATIFICATION-PACKET schema; identity/business
# absent by construction (it reads only paths + ratification stamps). Detection is field-proven, not
# proven-complete (canon §13): it verifies path-coverage, not semantic coherence.
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "SET-GATE-PROBE RUN_ERROR: not a git worktree"; exit 2; }
cd "$REPO_ROOT" || { echo "SET-GATE-PROBE RUN_ERROR: cannot cd repo root"; exit 2; }

# §2.16 RECEIPT UNIQUENESS (standing mirror of ratify's gate). Any receipt id bound to >1 distinct
# content_sha in the spine ledger is a collision one row could discharge on another's receipt → FAIL.
# Runs unconditionally (a corrupt ledger is a finding even before the first ratified set). No-op when
# no ledger is wired / the allocator is absent.
if [[ -x "$REPO_ROOT/scripts/receipt-ledger.py" ]] && command -v python3 >/dev/null 2>&1; then
    if ! uout="$(python3 "$REPO_ROOT/scripts/receipt-ledger.py" check-unique "$REPO_ROOT" 2>&1)"; then
        echo "SET-GATE-PROBE FAIL: receipt-id uniqueness (§2.16):"
        echo "$uout" | sed 's/^/  /'
        exit 1
    fi
fi

# ISSUE-1 FIX r3 (v2.5.6 Blocker 1): the base census is read from the SINGLE source
# scripts/spine-census.sh — this file was the FIFTH hand-maintained census copy (a hand-typed
# authored-spine `case` table), unfolded by the r2 pass and INVISIBLE to the syntactic parity guard
# (it expressed its census as a case table, not a SPINE_* assignment). Its list also omitted SLOTS.md,
# so a foundation --no-verify commit of SLOTS.md — the SLOT-FILL truth the engine-update classifier
# trusts — evaded this post-hoc coverage probe. Same MAINTAINED-STATE DRIFT class that held v2.5.5.
# bash 3.2 floor → read-loop, not mapfile; fail-CLOSED on an empty census (never scan blind).
SPINE_PATHS=()
while IFS= read -r _sp; do [[ -n "$_sp" ]] && SPINE_PATHS+=("$_sp"); done < <("$REPO_ROOT/scripts/spine-census.sh")
if [[ ${#SPINE_PATHS[@]} -eq 0 ]]; then echo "SET-GATE-PROBE RUN_ERROR: spine census empty (scripts/spine-census.sh missing/not-executable)"; exit 2; fi
# r4 §2.11: the adopter's DECLARED spine paths (HEAD-readback) — read once; authored-spine like the base.
DECLARED_SPINE="$("$REPO_ROOT/scripts/declared-spine-paths.sh" 2>/dev/null | tr '\n' ' ')"

# Authored-spine = census membership MINUS the enumerated per-gate exemptions (exemption cases kept
# verbatim; they are running/orchestration state carrying no set-coverage duty, per the A3 list).
is_authored_spine() {
    case "$1" in
        # exemptions (state pins · comms · ledger · provisioning · the mechanism's own files);
        # dispatch/LATEST.md is a resume-state pin (operator ruled EXEMPT 2026-08-17), not authored spine.
        ledger/*|_boot/*|PENDING-SET.md|_ratification/*) return 1 ;;
        _orchestration/STATE.md|_orchestration/decision-log.md|_orchestration/lane-provisioning.md) return 1 ;;
        _orchestration/relay-*|dispatch/LATEST.md) return 1 ;;
    esac
    local sp
    for sp in "${SPINE_PATHS[@]}"; do
        case "$sp" in
            */) [[ "$1" == "$sp"* ]] && return 0 ;;
            *)  [[ "$1" == "$sp"  ]] && return 0 ;;
        esac
    done
    local d; for d in ${DECLARED_SPINE:-}; do case "$1" in "$d"|"$d"*) return 0 ;; esac; done
    return 1
}

# Covered paths = union of member surfaces across all RATIFIED packets at HEAD.
COVERED=()
RATIFIED_EXISTS=0
shopt -s nullglob
for p in "$REPO_ROOT"/_ratification/SET-*.md; do
    grep -qE '^- decision: RATIFIED' "$p" || continue
    RATIFIED_EXISTS=1
    while IFS= read -r sfx; do
        [[ -z "${sfx// /}" ]] && continue
        IFS=',' read -ra PPS <<< "$sfx"
        for pp in "${PPS[@]}"; do pp="${pp// /}"; [[ -n "$pp" ]] && COVERED+=("$pp"); done
    done < <(awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$p" | sed -n 's/.*surfaces: //p')
done
# empty-array-safe under set -u (older bash).
path_covered() { local f="$1" c; [[ ${#COVERED[@]} -eq 0 ]] && return 1; for c in "${COVERED[@]}"; do [[ "$f" == "$c" ]] && return 0; done; return 1; }

# Prospective: with NO ratified set at HEAD there is nothing to enforce (genesis/provisioning
# commits authored-spine legitimately before the first set). The gate binds once sets exist.
if [[ $RATIFIED_EXISTS -eq 0 ]]; then
    echo "SET-GATE-PROBE PASS: no ratified sets at HEAD; set-gate is prospective (nothing to enforce yet)."
    exit 0
fi

# Baseline = the commit that introduced the most recent ratified packet (scan since there); if none,
# scan a bounded recent window so the probe still has teeth on a repo with no packets yet.
BASE=""
LASTPKT="$(ls -1 "$REPO_ROOT"/_ratification/SET-*.md 2>/dev/null | tail -1)"
if [[ -n "$LASTPKT" ]]; then
    BASE="$(git log -1 --format=%H -- "$LASTPKT" 2>/dev/null)"
fi
if [[ -n "$BASE" ]]; then RANGE="$BASE..HEAD"; else RANGE="-30"; fi

UNCOVERED=()
while IFS= read -r sha; do
    [[ -z "$sha" ]] && continue
    # only foundation-authored commits carry the duty; skip merge [C] second-parent noise + [audit].
    subj="$(git log -1 --format=%s "$sha")"
    [[ "$subj" =~ ^\[audit\] ]] && continue
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        is_authored_spine "$f" || continue
        path_covered "$f" || UNCOVERED+=("$sha:$f")
    done < <(git diff-tree --no-commit-id --name-only -r "$sha" 2>/dev/null)
done < <(git rev-list $RANGE 2>/dev/null)

if [[ ${#UNCOVERED[@]} -gt 0 ]]; then
    echo "SET-GATE-PROBE FAIL: authored-spine change(s) reached main WITHOUT a ratified set (canon §4):"
    for u in "${UNCOVERED[@]}"; do echo "  - ${u%%:*}  ${u#*:}"; done
    exit 1
fi
echo "SET-GATE-PROBE PASS: every authored-spine change since ${BASE:-<window>} is covered by a ratified set."
exit 0
