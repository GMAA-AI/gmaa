#!/usr/bin/env bash
# probes/foundation/probe_state_propagation.sh — COORDINATION §5 state-propagation (F8).
#
# CLAIM: a foundation commit that changed authored-spine paths also refreshed the anti-stale HEAD
# pin `_orchestration/STATE.md` — else the resume pin drifts behind the spine and a cold-boot
# re-grounds from a stale HEAD. FAIL if HEAD touched spine paths but did NOT touch STATE.md.
# run_by auditor (standing-probes.yaml, id: state-propagation); emit-on-FAIL/state-change.
#
# EXIT 0 = PASS · 1 = FAIL · 2 = RUN_ERROR. Merges + [audit] seals are exempt (no state duty).
set -u
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "STATE-PROP RUN_ERROR: not a git worktree"; exit 2; }
cd "$REPO_ROOT" || { echo "STATE-PROP RUN_ERROR: cannot cd repo root"; exit 2; }

SUBJ="$(git log -1 --format=%s 2>/dev/null)"
case "$SUBJ" in \[audit\]*) echo "STATE-PROP PASS: [audit] seal (exempt)."; exit 0 ;; esac
# a merge commit (has a second parent) carries the incoming work's own state; not a direct spine edit.
git rev-parse -q --verify HEAD^2 >/dev/null 2>&1 && { echo "STATE-PROP PASS: merge commit (exempt)."; exit 0; }

CHANGED="$(git diff-tree --root --no-commit-id --name-only -r HEAD 2>/dev/null)"
# ISSUE-1 FIX (v2.5.6): the authored-spine trigger set is derived from the SHARED census
# (scripts/spine-census.sh), retiring a hand-maintained SPINE_RE that was a THIRD, differently-drifted
# copy — it missed the set-authorization machinery's own files, so a set-auth spine change with no
# STATE.md refresh went undetected. This probe keeps its OWN per-gate exemptions (below) + its OWN
# probe-specific inclusion schema/ (an authored doc surface absent from the base census). Intended
# behavior change: a set-auth spine change (seats.yaml · launch-orc.sh · .claude/settings.json ·
# SLOTS.md · PENDING-SET.md · _ratification/ · …) with no STATE.md refresh now FAILS. bash 3.2 →
# read-loop, not mapfile; probe_census_parity.sh FAILS if this file reintroduces a census literal.
SPINE_PATHS=()
while IFS= read -r _sp; do [[ -n "$_sp" ]] && SPINE_PATHS+=("$_sp"); done < <("$REPO_ROOT/scripts/spine-census.sh")
if [[ ${#SPINE_PATHS[@]} -eq 0 ]]; then echo "STATE-PROP RUN_ERROR: spine census empty (scripts/spine-census.sh missing/not-executable)"; exit 2; fi
SPINE_PATHS+=("schema/")   # probe-specific authored surface, kept from the prior census (not in the base set)
is_spine() {
    local f="$1" sp
    for sp in "${SPINE_PATHS[@]}"; do
        case "$sp" in
            */) [[ "$f" == "$sp"* ]] && return 0 ;;
            *)  [[ "$f" == "$sp"  ]] && return 0 ;;
        esac
    done
    return 1
}
# per-gate exemptions (KEPT): the mechanism's own writes + state pins carry no STATE.md-refresh duty.
prop_exempt() {
    case "$1" in
        ledger/*)           return 0 ;;  # [audit] seals + apply-receipts — the mechanism's own writes
        _orchestration/*)   return 0 ;;  # state pins (STATE.md itself, decision-log, lane-provisioning, relays)
        dispatch/LATEST.md) return 0 ;;  # foundation resume pointer — same class as STATE.md
    esac
    return 1
}
touched=""
while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    prop_exempt "$f" && continue
    is_spine "$f" && touched="${touched}${f}"$'\n'
done <<< "$CHANGED"
touched="$(printf '%s' "$touched" | grep -v '^$' || true)"
if [[ -n "$touched" ]]; then
    if printf '%s\n' "$CHANGED" | grep -qx '_orchestration/STATE.md'; then
        echo "STATE-PROP PASS: spine change + _orchestration/STATE.md refreshed in the same commit."
        exit 0
    fi
    echo "STATE-PROP FAIL: HEAD changed authored-spine but did NOT refresh _orchestration/STATE.md (COORDINATION §5 — the resume pin drifts behind the spine):"
    printf '%s\n' "$touched" | sed 's/^/  - /'
    exit 1
fi
echo "STATE-PROP PASS: no authored-spine change in HEAD."
exit 0
