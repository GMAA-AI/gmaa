#!/usr/bin/env bash
# probes/set-gate/probe_semantic_hunt_flip.sh
# ── Standing probe (REQ-HUNT · C-SET-AUTHORIZATION §2.3) — the joint-edge 3-layer gate, FLIP-proven ──
#
# id:         set-gate-semantic-hunt
# claims:     (Layer C) the required ## SEMANTIC HUNT slot is UNSKIPPABLE — a MERGE decision REFUSES on a
#             missing/unfilled block, on verdict UNABLE, and on CLEAR asserted with 'candidates: ZERO' + no
#             method; it PROCEEDS on a CLEAR verdict carrying a method + candidates; EDGE-NAMED joins the
#             names to JOINT-EDGES as UNRESOLVED INTEGRATOR-JUDGMENT edges (blocking MERGE).
#             (Layer B) `assemble` flags a SoR SHARED-RECORD when two members cite the same sproc/probe id
#             via DIFFERENT files, and does NOT when they cite different records or share the same path
#             (that is Layer A OVERLAPPING PATH).
#             (substrates §2.3 cross-check) a member writing a substrate outside the declared
#             footprint.substrates is FLAGGED (UNDECLARED-SUBSTRATE), and is NOT when declared or when the
#             registry omits substrates.
# pass_means: each NEGATIVE (FLIP) case fails-closed / is-absent AND each POSITIVE control holds. A probe
#             that runs only the happy path proves the harness, not the gate (the 2+2 anti-pattern).
# flip:       DISCRIMINATION (mandatory) — every claim is paired with its negative.
# provenance: exercises the LIVE working-tree scripts/pending-set.sh + scripts/ratify.sh in an ISOLATED git
#             repo (mktemp, outside the spine) with a foundation resolver stub — DISC-PROBE-INPUT-PROVENANCE:
#             proves the worktree bytes, not a fixture of them. No LLM in the detector (AC6).
#
# Exit 0 = all assertions PASS (incl. the FLIP fails/absences). Non-zero = a claim did not hold (fail-closed).
set -u

REPO="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "probe: not in a git worktree"; exit 2; }
PS="$REPO/scripts/pending-set.sh"; RT="$REPO/scripts/ratify.sh"
# v2.5.6 Issue-1: ratify.sh now reads the spine census (single source) — carry it into the scaffold.
SC="$REPO/scripts/spine-census.sh"; DSP="$REPO/scripts/declared-spine-paths.sh"
[[ -f "$PS" && -f "$RT" && -f "$SC" ]] || { echo "probe: scripts missing"; exit 2; }

T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
PASS=0; FAIL=0
ok(){ echo "  PASS: $*"; PASS=$((PASS+1)); }
no(){ echo "  FAIL: $*"; FAIL=$((FAIL+1)); }

# --- isolated repo scaffold (git-init so repo_root resolves to T, outside the spine) ---
git init -q "$T"
mkdir -p "$T/scripts" "$T/_ratification" \
         "$T/_orchestration/relay-outbox/foundation" \
         "$T/_orchestration/relay-outbox/lane-a" \
         "$T/_orchestration/relay-outbox/lane-b"
cp "$PS" "$RT" "$SC" "$T/scripts/"
[[ -f "$DSP" ]] && cp "$DSP" "$T/scripts/"
cat > "$T/scripts/resolve-lane.sh" <<'EOF'
#!/usr/bin/env bash
echo 'lane=foundation role=integrator version=probe spine_write=ALLOW blob=probe'
EOF
chmod +x "$T/scripts/"*.sh

fresh_fixture(){
    rm -f "$T"/_ratification/SET-*.md
    rm -f "$T"/_orchestration/relay-outbox/*/SET-MEMBER-*.md
    ROWN=0
    cat > "$T/PENDING-SET.md" <<'EOF'
# PENDING-SET.md (probe fixture)

## THE SET

| # | member id | lane | branch@sha-range | surfaces touched | status |
|---|---|---|---|---|---|

## SET-IDENTITY

| requirement_id | set_id | footprint.lanes | footprint.substrates | exclusive | minted-at |
|---|---|---|---|---|---|

## APPLY LOG
EOF
}

# seed_member <id> <lane> <reqid> <setid> <surfaces> [<declared-effects>] — write the SET-MEMBER manifest
# + a pending ledger row directly (controls the member's LANE + declared-effects, which cmd_member wouldn't).
seed_member(){
    local id="$1" lane="$2" reqid="$3" setid="$4" surf="$5" eff="${6:-git-surfaces-only}"
    local mf="$T/_orchestration/relay-outbox/$lane/SET-MEMBER-$id.md"
    {
        echo "# SET-MEMBER-$id"
        echo "- member id: $id"
        echo "- lane: $lane"
        echo "- requirement id: $reqid"
        echo "- set id: $setid"
        echo "- branch@sha: $lane@probe"
        echo "- surfaces touched: $surf"
        echo "- declared effects (multi-substrate manifest; §3/§4a): $eff"
        echo "- self-declared dependencies: none-declared"
    } > "$mf"
    ROWN=$((ROWN+1))
    awk -v row="| $ROWN | $id | $lane | $lane@probe | $surf | pending |" '
        /^## THE SET[[:space:]]*$/ {inset=1}
        {print}
        inset && /^\|[-]+\|/ && !done {print row; done=1}
    ' "$T/PENDING-SET.md" > "$T/PENDING-SET.md.tmp" && mv "$T/PENDING-SET.md.tmp" "$T/PENDING-SET.md"
}

# setup_clean_set — fresh fixture with TWO disjoint lane-a members covering footprint [lane-a], assembled
# into SET-0001 with 0 mechanical edges, assessment filled, conformance PASS both members. Ready-to-ratify
# EXCEPT the SEMANTIC HUNT slot (still empty) — the isolation the Layer-C tests need.
setup_clean_set(){
    fresh_fixture
    scripts/pending-set.sh mint REQ-HUNTPROBE --footprint-lanes 'lane-a' >/dev/null 2>&1
    seed_member ha lane-a REQ-HUNTPROBE SET-0001 'src/a.txt'
    seed_member hb lane-a REQ-HUNTPROBE SET-0001 'src/b.txt'
    scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
    scripts/ratify.sh assess SET-0001 --text 'probe assessment: disjoint members, no joint incoherence observed.' >/dev/null 2>&1
    scripts/ratify.sh conformance SET-0001 ha --verdict PASS --method judgment --evidence 'probe' >/dev/null 2>&1
    scripts/ratify.sh conformance SET-0001 hb --verdict PASS --method judgment --evidence 'probe' >/dev/null 2>&1
}

cd "$T" || { echo "probe: cd failed"; exit 2; }

echo "── A. assemble writes the required SEMANTIC HUNT slot + coherence banner ──"
setup_clean_set
P="$T/_ratification/SET-0001.md"
grep -q '^## SEMANTIC HUNT' "$P" && ok "packet carries a ## SEMANTIC HUNT section" || no "no ## SEMANTIC HUNT section"
grep -q '<!-- SEMANTIC-HUNT-EMPTY -->' "$P" && ok "SEMANTIC HUNT slot starts UNFILLED (marker present)" || no "no SEMANTIC-HUNT-EMPTY marker"
grep -q 'MERGE is legal only after the SEMANTIC HUNT verdict is CLEAR' "$P" && ok "packet header carries the COHERENCE LAW banner" || no "no coherence-law banner"

echo "── B. Layer C FLIP — MERGE refuses on empty / UNABLE / CLEAR-ZERO-no-method; proceeds on CLEAR+method ──"
# NEGATIVE 1: empty slot → ratify RATIFIED REFUSES.
setup_clean_set
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi 'SEMANTIC HUNT slot is EMPTY' <<<"$out"; then ok "FLIP: empty SEMANTIC HUNT → MERGE REFUSED (rc=$rc)"; else no "empty-hunt did NOT refuse (rc=$rc): ${out##*$'\n'}"; fi
# NEGATIVE 2: verdict UNABLE → REFUSES.
setup_clean_set
scripts/ratify.sh hunt SET-0001 --residual 'could not open the make SoR index' --verdict UNABLE >/dev/null 2>&1
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi "verdict is 'UNABLE'" <<<"$out"; then ok "FLIP: verdict UNABLE → MERGE REFUSED (rc=$rc)"; else no "UNABLE did NOT refuse (rc=$rc): ${out##*$'\n'}"; fi
# NEGATIVE 3: CLEAR with candidates ZERO and no method → REFUSES (assertion, not a hunt).
setup_clean_set
scripts/ratify.sh hunt SET-0001 --method 'x' --candidates 'ZERO' --residual 'none' --verdict CLEAR >/dev/null 2>&1
# strip the method (cmd_hunt required one; the ratify-side rule must still catch ZERO+no-method) — target ONLY the hunt block's method line
awk 'BEGIN{s=0} /^## SEMANTIC HUNT/{s=1} /^## / && $0 !~ /SEMANTIC HUNT/{s=0} s && /^- method:/{print "- method: —"; next} {print}' "$P" > "$P.tmp" && mv "$P.tmp" "$P"
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi 'CLEAR with' <<<"$out"; then ok "FLIP: CLEAR + candidates ZERO + no method → MERGE REFUSED (rc=$rc)"; else no "CLEAR-ZERO-no-method did NOT refuse (rc=$rc): ${out##*$'\n'}"; fi
# POSITIVE control: CLEAR with method + candidates → ratify PROCEEDS to RATIFIED.
setup_clean_set
scripts/ratify.sh hunt SET-0001 --method 'grep sp_/probe_ across member surfaces + opened §5 SoR git-spine index' --candidates 'sp_x,sp_y' --residual 'low; disjoint files, distinct records' --verdict CLEAR >/dev/null 2>&1
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -eq 0 ]] && grep -q '^- decision: RATIFIED' "$P"; then ok "positive control: CLEAR+method → MERGE PROCEEDS (rc=0, decision RATIFIED stamped)"; else no "positive control failed (rc=$rc): ${out##*$'\n'}"; fi
# EDGE-NAMED: a named semantic edge joins JOINT-EDGES as UNRESOLVED → MERGE refused by the unresolved-edge gate.
setup_clean_set
scripts/ratify.sh hunt SET-0001 --residual 'two members redefine promote semantics in prose' --verdict EDGE-NAMED --edges 'promote-semantics-drift' >/dev/null 2>&1
grep -q 'INTEGRATOR-JUDGMENT: promote-semantics-drift' "$P" && ok "EDGE-NAMED appends an INTEGRATOR-JUDGMENT edge to JOINT-EDGES" || no "EDGE-NAMED did not append a named edge"
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi 'unresolved joint edge' <<<"$out"; then ok "EDGE-NAMED → MERGE REFUSED until the named edge resolves (rc=$rc)"; else no "EDGE-NAMED did NOT block MERGE (rc=$rc): ${out##*$'\n'}"; fi

echo "── C. Layer B FLIP — SoR SHARED-RECORD (same record, different files) ──"
# POSITIVE: two lane-a members cite sp_promote via DIFFERENT files → SHARED-RECORD edge.
fresh_fixture
scripts/pending-set.sh mint REQ-HUNTPROBE --footprint-lanes 'lane-a' >/dev/null 2>&1
seed_member ba lane-a REQ-HUNTPROBE SET-0001 'sql/skill/sprocs/sp_promote.sql'
seed_member bb lane-a REQ-HUNTPROBE SET-0001 'sql/skill/grants/grant_sp_promote.sql'
scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
# NOTE: grep the EDGE line (^- UNRESOLVED · …), NOT the bare token — the packet's DETECTION-HONESTY banner
# names 'SHARED-RECORD'/'UNDECLARED-SUBSTRATE' in prose; a loose grep would match the banner, not the finding.
grep -qE '^- UNRESOLVED · .*SHARED-RECORD \[sproc:sp_promote\]' "$P" && ok "SHARED-RECORD flagged: same sproc, different files (§2.3 Layer B)" || no "SHARED-RECORD not flagged for a cross-file sproc"
# FLIP: different sprocs → NO SHARED-RECORD.
fresh_fixture
scripts/pending-set.sh mint REQ-HUNTPROBE --footprint-lanes 'lane-a' >/dev/null 2>&1
seed_member na lane-a REQ-HUNTPROBE SET-0001 'sql/skill/sprocs/sp_promote.sql'
seed_member nb lane-a REQ-HUNTPROBE SET-0001 'sql/skill/sprocs/sp_demote.sql'
scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
grep -qE '^- UNRESOLVED · .*SHARED-RECORD' "$P" && no "FLIP: distinct sprocs wrongly flagged SHARED-RECORD" || ok "FLIP: distinct sprocs → NO SHARED-RECORD (discrimination holds)"
# SUPPRESSION: same PATH → Layer A OVERLAPPING PATH, NOT Layer B SHARED-RECORD.
fresh_fixture
scripts/pending-set.sh mint REQ-HUNTPROBE --footprint-lanes 'lane-a' >/dev/null 2>&1
seed_member pa lane-a REQ-HUNTPROBE SET-0001 'sql/skill/sprocs/sp_promote.sql'
seed_member pb lane-a REQ-HUNTPROBE SET-0001 'sql/skill/sprocs/sp_promote.sql'
scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
if grep -qE '^- UNRESOLVED · .*OVERLAPPING PATH' "$P" && ! grep -qE '^- UNRESOLVED · .*SHARED-RECORD' "$P"; then ok "same path → Layer A OVERLAPPING PATH, Layer B suppressed (no double-flag)"; else no "path-overlap suppression of Layer B did not hold"; fi

echo "── D. substrates cross-check FLIP — UNDECLARED-SUBSTRATE (§2.3 secondary; rule-stated) ──"
# POSITIVE: footprint.substrates [git-spine]; member declares a db (azure-sql) effect → UNDECLARED-SUBSTRATE.
fresh_fixture
scripts/pending-set.sh mint REQ-SUB --footprint-lanes 'lane-a' --footprint-substrates 'git-spine' >/dev/null 2>&1
seed_member da lane-a REQ-SUB SET-0001 'src/a.txt' 'db: sp_seed_row'
scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
grep -qE '^- UNRESOLVED · .*UNDECLARED-SUBSTRATE' "$P" && ok "db effect outside footprint.substrates [git-spine] → UNDECLARED-SUBSTRATE flag" || no "UNDECLARED-SUBSTRATE not flagged for an undeclared azure-sql effect"
# FLIP: declare azure-sql in footprint.substrates → NO flag.
fresh_fixture
scripts/pending-set.sh mint REQ-SUB --footprint-lanes 'lane-a' --footprint-substrates 'git-spine,azure-sql' >/dev/null 2>&1
seed_member db lane-a REQ-SUB SET-0001 'src/a.txt' 'db: sp_seed_row'
scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
grep -qE '^- UNRESOLVED · .*UNDECLARED-SUBSTRATE' "$P" && no "FLIP: declared azure-sql wrongly flagged UNDECLARED-SUBSTRATE" || ok "FLIP: declared azure-sql → NO flag (discrimination holds)"
# SKIP: registry omits substrates (—) → cross-check does not run, even for a db member.
fresh_fixture
scripts/pending-set.sh mint REQ-SUB --footprint-lanes 'lane-a' >/dev/null 2>&1
seed_member dc lane-a REQ-SUB SET-0001 'src/a.txt' 'db: sp_seed_row'
scripts/ratify.sh assemble SET-0001 >/dev/null 2>&1
grep -qE '^- UNRESOLVED · .*UNDECLARED-SUBSTRATE' "$P" && no "substrate check ran despite an omitted (—) footprint.substrates" || ok "omitted footprint.substrates → cross-check skipped (optional, unchanged prior behavior)"

echo
echo "set-gate-semantic-hunt: PASS=$PASS FAIL=$FAIL"
[[ $FAIL -eq 0 ]] || exit 1
exit 0
