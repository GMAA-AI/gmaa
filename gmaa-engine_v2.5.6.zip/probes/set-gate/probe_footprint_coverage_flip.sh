#!/usr/bin/env bash
# probes/set-gate/probe_footprint_coverage_flip.sh
# ── Standing probe (REQ-FOOTPRINT · C-SET-AUTHORIZATION §2.2) — the footprint-coverage gate, FLIP-proven ──
#
# id:         set-gate-footprint-coverage
# claims:     `ratify.sh assemble` REFUSES a set that does not COVER its requirement's declared
#             `footprint.lanes` (FOOTPRINT-MISS) and PROCEEDS when coverage holds; `pending-set.sh`
#             refuses an un-footprinted member, mints one set_id per requirement, and HALTs the stagger.
# pass_means: the SEEDED-MISS assemble EXITS NON-ZERO with `FOOTPRINT-MISS` (it opened the real gate,
#             not a string), AND the positive control EXITS ZERO writing a packet with `coverage: EXACT`.
# flip:       DISCRIMINATION (mandatory) — the negative case MUST fail. A probe that runs only the happy
#             path proves the harness, not the gate (the 2+2 anti-pattern; disciplines probe-FLIP law).
# provenance: exercises the LIVE working-tree scripts/pending-set.sh + scripts/ratify.sh in an ISOLATED
#             git repo (mktemp, outside the spine) with a foundation resolver stub — DISC-PROBE-INPUT-
#             PROVENANCE: proves the worktree bytes, not a fixture of them.
#
# Exit 0 = all assertions PASS (incl. the FLIP fail). Non-zero = a claim did not hold (fail-closed).
set -u

REPO="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "probe: not in a git worktree"; exit 2; }
PS="$REPO/scripts/pending-set.sh"; RT="$REPO/scripts/ratify.sh"
# v2.5.6 Issue-1: ratify.sh now reads the spine census from scripts/spine-census.sh (single source),
# so the isolated scaffold must carry it (+ declared-spine-paths.sh, which the census appends).
SC="$REPO/scripts/spine-census.sh"; DSP="$REPO/scripts/declared-spine-paths.sh"
[[ -f "$PS" && -f "$RT" && -f "$SC" ]] || { echo "probe: scripts missing"; exit 2; }

T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
PASS=0; FAIL=0
ok(){ echo "  PASS: $*"; PASS=$((PASS+1)); }
no(){ echo "  FAIL: $*"; FAIL=$((FAIL+1)); }

# --- isolated repo scaffold (git-init so repo_root resolves to T, outside the spine) ---
git init -q "$T"
mkdir -p "$T/scripts" "$T/_ratification" \
         "$T/_orchestration/relay-outbox/foundation" \
         "$T/_orchestration/relay-outbox/lane-a" \
         "$T/_orchestration/relay-outbox/lane-b"
cp "$PS" "$RT" "$SC" "$T/scripts/"
[[ -f "$DSP" ]] && cp "$DSP" "$T/scripts/"
# foundation resolver stub — we test the footprint gate LOGIC, not the resolver.
cat > "$T/scripts/resolve-lane.sh" <<'EOF'
#!/usr/bin/env bash
echo 'lane=foundation role=integrator version=probe spine_write=ALLOW blob=probe'
EOF
chmod +x "$T/scripts/"*.sh

fresh_fixture(){
    rm -f "$T"/_ratification/SET-*.md
    rm -f "$T"/_orchestration/relay-outbox/*/SET-MEMBER-*.md
    ROWN=0
    cat > "$T/PENDING-SET.md" <<'EOF'
# PENDING-SET.md (probe fixture)

## THE SET

| # | member id | lane | branch@sha-range | surfaces touched | status |
|---|---|---|---|---|---|

## SET-IDENTITY

| requirement_id | set_id | footprint.lanes | footprint.substrates | exclusive | minted-at |
|---|---|---|---|---|---|

## APPLY LOG
EOF
}

# seed_member <id> <lane> <reqid> <setid> <surfaces> — write the SET-MEMBER manifest + a pending ledger row
# directly (controls the member's LANE, which cmd_member would otherwise fix to the resolver's lane).
seed_member(){
    local id="$1" lane="$2" reqid="$3" setid="$4" surf="$5"
    local mf="$T/_orchestration/relay-outbox/$lane/SET-MEMBER-$id.md"
    {
        echo "# SET-MEMBER-$id"
        echo "- member id: $id"
        echo "- lane: $lane"
        echo "- requirement id: $reqid"
        echo "- set id: $setid"
        echo "- branch@sha: $lane@probe"
        echo "- surfaces touched: $surf"
        echo "- self-declared dependencies: none-declared"
    } > "$mf"
    ROWN=$((ROWN+1))
    awk -v row="| $ROWN | $id | $lane | $lane@probe | $surf | pending |" '
        /^## THE SET[[:space:]]*$/ {inset=1}
        {print}
        inset && /^\|[-]+\|/ && !done {print row; done=1}
    ' "$T/PENDING-SET.md" > "$T/PENDING-SET.md.tmp" && mv "$T/PENDING-SET.md.tmp" "$T/PENDING-SET.md"
}

cd "$T" || { echo "probe: cd failed"; exit 2; }

echo "── A. mint (dispatch-time set-identity) ──"
fresh_fixture
sid="$(scripts/pending-set.sh mint REQ-PROBE --footprint-lanes 'lane-a,lane-b' 2>/dev/null)"
[[ "$sid" == "SET-0001" ]] && ok "mint allocates the first set_id (SET-0001)" || no "mint allocation (got '$sid')"
sid2="$(scripts/pending-set.sh mint REQ-PROBE --footprint-lanes 'lane-a,lane-b' 2>/dev/null)"
[[ "$sid2" == "$sid" ]] && ok "mint is idempotent per requirement" || no "mint idempotency (got '$sid2')"
if scripts/pending-set.sh mint REQ-PROBE --footprint-lanes 'lane-a' >/dev/null 2>&1; then no "mint should HALT on a footprint change"; else ok "mint HALTs on a footprint change (architect-owned)"; fi
if scripts/pending-set.sh mint REQ-NOFOOT >/dev/null 2>&1; then no "mint should REFUSE an empty footprint"; else ok "mint REFUSES an empty --footprint-lanes (no footprint → not dispatchable)"; fi

echo "── B. member — not dispatchable without a parent requirement / set_id ──"
if scripts/pending-set.sh member m-x --intent 'x' --surfaces 'f.sh' >/dev/null 2>&1; then no "member should REFUSE a missing --requirement-id"; else ok "member REFUSES a missing --requirement-id (§2.2(a))"; fi
if scripts/pending-set.sh member m-x --requirement-id REQ-PROBE --intent 'x' --surfaces 'f.sh' >/dev/null 2>&1; then no "member should REFUSE a missing --set-id"; else ok "member REFUSES a missing --set-id (§2.2(b))"; fi

echo "── C. reap — the stagger (§2.2(b)) + no-mint HALT ──"
scripts/pending-set.sh member m-stag --requirement-id REQ-PROBE --set-id SET-0002 --intent 'x' --surfaces 'f.sh' >/dev/null 2>&1
if scripts/pending-set.sh reap _orchestration/relay-outbox/foundation/SET-MEMBER-m-stag.md >/dev/null 2>&1; then no "reap should HALT on the stagger"; else ok "reap HALTs the stagger (member set_id ≠ minted set_id)"; fi
scripts/pending-set.sh member m-nomint --requirement-id REQ-UNMINTED --set-id SET-0009 --intent 'x' --surfaces 'f.sh' >/dev/null 2>&1
if scripts/pending-set.sh reap _orchestration/relay-outbox/foundation/SET-MEMBER-m-nomint.md >/dev/null 2>&1; then no "reap should HALT on an unminted requirement"; else ok "reap HALTs an unminted requirement (no set_id in the registry)"; fi

echo "── D. FLIP — assemble coverage (the core discrimination) ──"
fresh_fixture
scripts/pending-set.sh mint REQ-PROBE --footprint-lanes 'lane-a,lane-b' >/dev/null 2>&1
# NEGATIVE (seeded miss): footprint [lane-a,lane-b], only lane-a present → MUST FAIL FOOTPRINT-MISS.
seed_member fa lane-a REQ-PROBE SET-0001 'src/a.txt'
out="$(scripts/ratify.sh assemble 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -q 'FOOTPRINT-MISS' <<<"$out"; then ok "FLIP negative: seeded-miss assemble FAILS with FOOTPRINT-MISS (rc=$rc)"; else no "FLIP negative did NOT fail-closed (rc=$rc): ${out##*$'\n'}"; fi
[[ ! -e "$T/_ratification/SET-0001.md" ]] && ok "FLIP negative wrote NO packet (halted before write)" || no "FLIP negative leaked a packet"
# POSITIVE (control): add lane-b → full coverage → assemble PROCEEDS with coverage EXACT.
seed_member fb lane-b REQ-PROBE SET-0001 'src/b.txt'
out="$(scripts/ratify.sh assemble 2>&1)"; rc=$?
if [[ $rc -eq 0 && -f "$T/_ratification/SET-0001.md" ]]; then ok "positive control: full-coverage assemble PROCEEDS (rc=0, packet written)"; else no "positive control failed (rc=$rc): ${out##*$'\n'}"; fi
grep -q 'coverage: EXACT' "$T/_ratification/SET-0001.md" 2>/dev/null && ok "packet HEADER records coverage: EXACT" || no "packet did not record coverage: EXACT"

echo "── E. UNDECLARED-OCCUPANT (extra lane) + mixed-requirement HALT ──"
fresh_fixture
scripts/pending-set.sh mint REQ-SOLO  --footprint-lanes 'lane-a' >/dev/null 2>&1   # SET-0001
scripts/pending-set.sh mint REQ-OTHER --footprint-lanes 'lane-a' >/dev/null 2>&1   # SET-0002
# extra lane beyond the footprint → proceeds, but flags UNDECLARED-OCCUPANT (integrator must assess).
seed_member sa lane-a REQ-SOLO SET-0001 'src/a.txt'
seed_member sb lane-b REQ-SOLO SET-0001 'src/b.txt'
out="$(scripts/ratify.sh assemble SET-0001 2>&1)"; rc=$?
if [[ $rc -eq 0 ]] && grep -q 'UNDECLARED-OCCUPANT' "$T/_ratification/SET-0001.md" 2>/dev/null; then ok "extra lane → UNDECLARED-OCCUPANT joint edge (proceeds, flagged UNRESOLVED)"; else no "UNDECLARED-OCCUPANT not flagged (rc=$rc): ${out##*$'\n'}"; fi
# mixed requirements in one assemble → HALT (two requirements = two sets).
fresh_fixture
scripts/pending-set.sh mint REQ-SOLO  --footprint-lanes 'lane-a' >/dev/null 2>&1   # SET-0001
scripts/pending-set.sh mint REQ-OTHER --footprint-lanes 'lane-a' >/dev/null 2>&1   # SET-0002
seed_member ma lane-a REQ-SOLO  SET-0001 'src/a.txt'
seed_member mb lane-a REQ-OTHER SET-0002 'src/b.txt'
out="$(scripts/ratify.sh assemble 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qiE 'mixed requirement' <<<"$out"; then ok "mixed requirements → HALT (two requirements = two sets)"; else no "mixed-requirement did NOT halt (rc=$rc): ${out##*$'\n'}"; fi

echo
echo "set-gate-footprint-coverage: PASS=$PASS FAIL=$FAIL"
[[ $FAIL -eq 0 ]] || exit 1
exit 0
