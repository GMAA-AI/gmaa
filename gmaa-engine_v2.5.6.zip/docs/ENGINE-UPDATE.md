# ENGINE-UPDATE — the foundation-run engine upgrade (runbook)

> **ENGINE UPDATES ARE FOUNDATION'S ACT** (operator-ruled). Foundation executes this runbook;
> never overwrite an unclassified file; never resolve a moved slot alone; the update commits only
> inside a ratified set. The mechanical half is code — `scripts/engine-update-classify.sh` — and
> foundation's judgment goes ONLY to the per-conflict rulings (DISC-LLM-AT-THE-EDGES).
>
> **The engine's own upgrade is a PENDING SET** — assembled, assessed, hunted, conformance-checked
> and RATIFIED BY THE OPERATOR through the shipped mechanism (M1–M6) before any member commits.
> Upgrading the engine through its own gate is the standing proof the gate is real.

## B0 · Stamp check — BEFORE any propagation (fail-closed)
Verify EVERY lane's `_boot/BOOTSTRAP.md` carries a FILLED `project:` (and `lane:` / `role:` /
`spine_write:`) **before** anything propagates: per lane, `scripts/resolve-project.sh` must exit 0
(it HALTs exit 3 on an unfilled `{{`-slot) and `scripts/resolve-lane.sh` must resolve. Propagating
onto unstamped lanes is a SILENT N-LANE FAILURE — the check precedes the propagation, always.

## B1 · Verify the new baseline
The NEW baseline zip sha256 matches its published SHA256SUMS; its MANIFEST verifies n/n
(`shasum -a 256 -c MANIFEST.sha256` → every row OK, row-count = file-count). An unverifiable
baseline is a STOP, not a "probably fine".

## B2 · Three-way classify (code, not judgment)
Run the classifier over OLD baseline manifest · NEW baseline manifest · the adopter tree:

```
scripts/engine-update-classify.sh \
  --old-manifest <OLD>/MANIFEST.sha256 --new-manifest <NEW>/MANIFEST.sha256 \
  --slots <NEW>/SLOTS.md --adopter <adopter-tree> --changelog <NEW>/CHANGELOG.md
```

It emits the classified diff: **ENGINE-DELTA** (OLD→NEW; the apply list) · **PRESERVE-FILL** (a
shipped `{{TOKEN}}` filled by the adopter — preserve; re-apply where the slot contract is
unchanged) · **PRESERVE-GENERATED** (governance surfaces: FOUNDATION.md, seats.yaml, CHECKLIST,
register, ledgers incl. PENDING-SET.md, session_state, charters/BOOTSTRAP, relay/dispatch dirs,
content — never touched) · **CONFLICT** (adopter engine-drift — foundation rules per file, NEVER
overwrites an unclassified or conflicted file).

## B3 · STOP on a moved slot
Classifier exit 2 = a FILLED slot's contract MOVED per the NEW CHANGELOG's **`Slot-contract
changes`** heading (`SLOTS.md` is the inventory; the heading is the release's promise to
adopters). **HALT the update** — foundation never resolves a moved slot alone; the old→new
contract line + the adopter's fill go to the operator, and the update resumes only on the ruling.

## B4 · Prove the updated tree (checks that can fail)
On the post-apply tree, run: the seeded-fault acceptance set
(`scripts/test/test_set_gate_seeded_fault.sh` — must be all-PASS) + its negative controls + the
standing probes (`agents/standing-probes.yaml`, incl. both set-gate FLIP probes) +
`scripts/test/test_engine_update_classify.sh` (the classifier's own acceptance). A red anywhere
stops the update before B5 — the update must not propagate a tree it cannot prove.

## B5 · Per-lane propagation — REFUSE an unfilled lane
`scripts/lane_currency_gate.sh` per lane + a per-lane HEAD readback after sync. **B5 REFUSES to
sync any lane whose `_boot/BOOTSTRAP.md` stamp is unfilled** (the B0 check re-asserted at the
door — a lane provisioned between B0 and B5 gets no free pass).

## B6 · The update rides a RATIFIED SET (the gate's own proof)
The changed files are the MEMBERS: `pending-set.sh mint` the update requirement (footprint =
foundation) → member entries → `ratify.sh assemble` → `assess` → `hunt` → `conformance` →
operator **`--by`** ratifies → members commit under the set → `reap_at_merge.sh` where lanes
carry members. No member commits before the decision line. The engine upgrading THROUGH its own
set-gate is the first-class evidence the gate governs even its own maintainer.
