#!/bin/bash
# launch-orc.sh — fleet seat launcher (deposit one copy in each worktree root)
# bash-3.2 compatible (macOS /bin/bash): case-based folder map, no associative arrays.
#
# GENERICIZATION NOTE: the folder→lane map is genericized to FOLDER-EQUALS-LANE (lane = folder
# name; FOLDER-EQUALS-LANE for every seat, foundation included), matching resolve-lane.sh. The
# MODE-NOTE incident specifics are stripped to the mechanism-of-record only.
#
# Lane resolution (in order):
#   1. _boot/BOOTSTRAP.md lane:…   (authoritative when present; v3 reads the colon form)
#   2. folder→lane case map below  (folder-equals-lane by default)
#   3. HALT-LOUD                   (never silently guess a session name)
# Session name = <project>-<lane> (v2.5.2: tmux is machine-global; the project prefix from
# scripts/resolve-project.sh prevents cross-project collisions and bell misdelivery; the LANE ID
# itself stays pure in all git paths. Doorbell R1 resolves on the same composed name).
#
# Usage:
#   ./launch-orc.sh                 launch this worktree's seat and ATTACH
#   ./launch-orc.sh --detach        launch headless (attach later: tmux attach -t <project>-<lane>)
#   ./launch-orc.sh --btab N        after settle delay, send N Shift+Tab (BTab) keystrokes (default 0)
#   ./launch-orc.sh --no-mode-flag  omit the mode flag (now the DEFAULT)
#   ./launch-orc.sh --auto-mode     opt into --permission-mode auto (classifier ON; test posture)
#
# MODE NOTE (mechanism of record): a pinned `--permission-mode auto` CLI flag OVERRIDES
# settings.json `defaultMode`, silently re-enabling the auto-mode classifier on every
# launcher-spawned seat and defeating a fleet-wide `defaultMode: default`. DEFAULT IS NOW ``
# (no flag) → settings.json `defaultMode: default` governs: the allow+deny list decides, no
# false-positive classifier drip. Opt into the test posture with `--auto-mode`. ALWAYS verify
# OBSERVED mode via /status; observed (not requested) mode is the boot receipt.

set -eu

# ---------- config ----------
CLAUDE_CMD="claude --agent orc"     # command of record (per-seat override below)
MODE_FLAG=""                        # default: settings.json-governed (default mode); --auto-mode opts into the classifier
SEAT_MODEL=""                       # v3: per-seat model tier (operator-configurable knob, ratified in your
                                    # project as {{RULING}}); empty = operator-config-governed
BOOT_PROMPT=""                      # v3: per-seat CLI positional boot prompt. The orc def's initialPrompt
                                    # AUTO-fires; a SECOND agent def's (architect) does NOT, so that seat is
                                    # booted via a positional prompt arg instead. Empty = rely on the def's initialPrompt.
SETTLE_SECS=8
# ----------------------------

# folder→lane map — FOLDER-EQUALS-LANE for every seat (foundation's folder is `foundation`, like any other lane).
# EDIT HERE only if a worktree folder name ≠ its lane id.
folder_to_lane() {
  case "$1" in
    *) echo "$1" ;;   # folder-equals-lane: the folder name IS the lane id (foundation included)
  esac
}

ATTACH=1
BTAB_COUNT=0
while [ $# -gt 0 ]; do
  case "$1" in
    --attach)        ATTACH=1; shift ;;
    --detach)        ATTACH=0; shift ;;
    --btab)          BTAB_COUNT="${2:?--btab needs a count}"; shift 2 ;;
    --no-mode-flag)  MODE_FLAG=""; shift ;;                          # now the default; kept for compatibility
    --auto-mode)     MODE_FLAG="--permission-mode auto"; shift ;;    # opt into the classifier test posture
    *) echo "HALT: unknown arg '$1'" >&2; exit 2 ;;
  esac
done

# --- resolve worktree dir + folder ---
WT_DIR="$(cd "$(dirname "$0")" && pwd)"
FOLDER="$(basename "$WT_DIR")"

# --- lane resolution: _boot first, folder map second, halt third ---
LANE=""
LANE_SOURCE=""
BOOT_LANE=""
BOOT_FILE="$WT_DIR/_boot/BOOTSTRAP.md"
if [ -f "$BOOT_FILE" ]; then
  # v3 F-1 fix (ratified in your project as {{RULING}}): the _boot frontmatter + resolve-lane.sh use
  # `lane:` (colon), not `lane=` (equals). An equals-grep always returned empty here -> _boot precedence
  # never fired and the cross-check below was dead code. Read the colon form so _boot is authoritative.
  BOOT_LANE="$(sed -nE 's/^lane:[[:space:]]*([A-Za-z0-9_-]+).*/\1/p' "$BOOT_FILE" 2>/dev/null | head -1 || true)"
  # Unfilled skeleton guard: a template stamp (`lane: {{LANE}}`) is NOT "no lane line" — it is an
  # un-instantiated project. Halt loud instead of silently falling to the folder map.
  if [ -z "$BOOT_LANE" ] && grep -qE '^lane:[[:space:]]*\{\{' "$BOOT_FILE" 2>/dev/null; then
    echo "HALT: _boot/BOOTSTRAP.md still carries the skeleton stamp (lane: {{LANE}})." >&2
    echo "      This project is not instantiated. Run the instantiation (plain claude session, canon §12) first." >&2
    exit 1
  fi
  if [ -n "$BOOT_LANE" ]; then
    LANE="$BOOT_LANE"
    LANE_SOURCE="_boot/BOOTSTRAP.md"
  fi
fi
MAP_LANE="$(folder_to_lane "$FOLDER")"
if [ -z "$LANE" ] && [ -n "$MAP_LANE" ]; then
  LANE="$MAP_LANE"
  LANE_SOURCE="folder map ($FOLDER)"
fi
if [ -z "$LANE" ]; then
  echo "HALT: cannot resolve lane for folder '$FOLDER'." >&2
  echo "      No _boot/BOOTSTRAP.md lane= line, and folder not resolvable." >&2
  exit 1
fi

# --- cross-check: if BOTH sources exist, they must agree (halt-loud) ---
if [ -n "$BOOT_LANE" ] && [ -n "$MAP_LANE" ] && [ "$BOOT_LANE" != "$MAP_LANE" ]; then
  echo "HALT: lane mismatch — _boot says '$BOOT_LANE', folder map says '$MAP_LANE'" >&2
  echo "      for folder '$FOLDER'. Resolve before launch (tmux session =" >&2
  echo "      <project>-<lane>; doorbell R1 resolves on that name)." >&2
  exit 1
fi

# --- per-seat launch command + model tier (v3 registry) ---
# Default seat = role-neutral orc (foundation / exec / module lanes). The architect is a DISTINCT
# agent def (`claude --agent architect`) on its own tier. Model tier is the operator-configurable
# knob (ratified in your project as {{RULING}}); only the architect's is wired here — other seats
# stay operator-config-governed until you extend this registry.
if [ "$LANE" = "architect" ]; then
  CLAUDE_CMD="claude --agent architect"
  SEAT_MODEL="opus"   # default architect tier as a MODEL ALIAS (operator-movable). Aliases track the current
                      # canonical id; a baked dated id rots on the vendor release cadence (field finding F-07).
  # The architect is a PRIMARY session agent, but its def's initialPrompt does NOT auto-fire (only the
  # primary orc def's does). Boot it explicitly with a positional prompt (single line, NO single-quotes).
  BOOT_PROMPT="Boot as @architect: read _boot/BOOTSTRAP.md (lane identity + load order) and .claude/agents/architect.md (your @architect def), ground from HEAD, emit BOOT-ACK: @architect charter=<def version> before any other work, then check inbound with scripts/inbox.sh (reads _orchestration/relay-inbox/architect/) and follow it."
fi

# --- session namespace: {project}-{lane} (canon §7.3, U-17) ---
PROJECT="$(scripts/resolve-project.sh)" && RP=0 || RP=$?   # guarded: under set -e a bare failing substitution aborted the
                                                             # launcher silently, making BOTH the legacy exit-10 branch and the HALT
                                                             # message below dead code (an unstamped project could not launch at all)
if [ "$RP" -eq 0 ] && [ -n "$PROJECT" ]; then
  SESSION="${PROJECT}-${LANE}"
elif [ "$RP" -eq 10 ]; then
  SESSION="${LANE}"   # legacy single-project form; the loud warning already printed (canon §7.3)
else
  echo "HALT: project-token resolution failed (resolve-project.sh exit $RP)." >&2; exit 1
fi

# --- refuse double-launch (exact-match session name) ---
if tmux has-session -t "=$SESSION" 2>/dev/null; then
  echo "HALT: tmux session '$SESSION' already exists. Not launching a second seat." >&2
  echo "      Attach with: tmux attach -t $SESSION" >&2
  exit 1
fi

# --- hook-presence guard: the spine-write boundary IS the pre-commit hook; no hook = no gate ---
_HOOKDIR="$(cd "$WT_DIR" && git rev-parse --git-path hooks 2>/dev/null)" || _HOOKDIR=""
if [ -z "$_HOOKDIR" ] || [ ! -x "$WT_DIR/$_HOOKDIR/pre-commit" ] && [ ! -x "$_HOOKDIR/pre-commit" ]; then
  echo "HALT: pre-commit hook not installed (the spine-write gate does not exist without it)." >&2
  echo "      Run: bash scripts/install_pre_commit_hook.sh && bash scripts/install_post_commit_hook.sh" >&2
  exit 1
fi

# --- genesis: local runtime state files (RELOCATED after the guards; architect-225 finding 5) ---
# Runs ONLY after lane resolution + the stamp cross-check + the session-namespace resolver + the
# double-launch guard have all passed, so a launch that dies at a prerequisite wall writes NOTHING
# (fail-clean / atomicity, kin to halt-loud). Presence-triggered + idempotent; never overwrites.
# Local-only (covered by .gitignore `.claude/*`). Five engine surfaces insist on
# .claude/session_state.json + the state-source map; a fresh blank-copy tree births them here.
cd "$WT_DIR" || { echo "HALT: cannot cd to worktree $WT_DIR" >&2; exit 1; }
genesis_note() { echo "GENESIS: created $1"; }
if [ ! -f ".claude/session_state.json" ]; then
  mkdir -p .claude
  printf '{"in_flight_iter": null}\n' > .claude/session_state.json
  genesis_note .claude/session_state.json
fi
if [ ! -f "_orchestration/STATE.md" ]; then
  mkdir -p _orchestration
  _HEAD="$(git rev-parse --verify --quiet HEAD 2>/dev/null || echo none)"
  printf '# STATE.md -- anti-stale pin (GENESIS %s)\npinned HEAD: %s\ndeployed: none\n' "$(date +%F)" "$_HEAD" > _orchestration/STATE.md
  genesis_note _orchestration/STATE.md
fi
if [ ! -f "_orchestration/decision-log.md" ]; then
  mkdir -p _orchestration
  printf '# decision-log -- one line per cross-agent ask + STATUS (GENESIS %s; no entries yet)\n' "$(date +%F)" > _orchestration/decision-log.md
  genesis_note _orchestration/decision-log.md
fi
if [ ! -f "_orchestration/lane-provisioning.md" ]; then
  mkdir -p _orchestration
  {
    printf '# lane-provisioning -- spine manifest of provisioned lanes (GENESIS %s). Foundation appends one row per lane at standup (COORDINATION §13(2)).\n' "$(date +%F)"
    printf '# The pre-commit hook resolves the integration-trunk ref FROM the foundation row of this table; keep it current.\n\n'
    printf '| lane | branch | bootstrap_version | blob | provisioned_utc |\n|---|---|---|---|---|\n'
    if [ "$LANE" = "foundation" ]; then
      _BR="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo main)"; _BL="$(git hash-object _boot/BOOTSTRAP.md 2>/dev/null || echo unknown)"
      printf '| foundation | %s | %s | %s | %s |\n' "$_BR" "$(sed -n 's/^bootstrap_version:[[:space:]]*//p' _boot/BOOTSTRAP.md | head -1)" "$_BL" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    fi
  } > _orchestration/lane-provisioning.md
  genesis_note _orchestration/lane-provisioning.md
fi
if [ ! -d "ledger" ] || [ ! -f "ledger/receipts.jsonl" ]; then
  mkdir -p ledger
  : > ledger/receipts.jsonl
  genesis_note ledger/receipts.jsonl
fi
if [ ! -f "ledger/audit-findings.md" ]; then
  mkdir -p ledger
  printf '# audit-findings (GENESIS %s; none yet)\n' "$(date +%F)" > ledger/audit-findings.md
  genesis_note ledger/audit-findings.md
fi
if [ ! -f "ledger/audit-runs.log" ]; then
  mkdir -p ledger
  : > ledger/audit-runs.log
  genesis_note ledger/audit-runs.log
fi
if [ ! -d "docs/Chat-Handoff" ]; then
  mkdir -p docs/Chat-Handoff
  : > docs/Chat-Handoff/.gitkeep
  genesis_note docs/Chat-Handoff/
fi
# relay channel for THIS lane (canon §12 step 6): inbox on the spine (foundation sole writer), outbox on the lane branch.
for _rd in "_orchestration/relay-inbox/$LANE" "_orchestration/relay-outbox/$LANE"; do
  if [ ! -d "$_rd" ]; then mkdir -p "$_rd"; : > "$_rd/.gitkeep"; genesis_note "$_rd/"; fi
done

# --- launch: detached session, cwd = worktree, then send the claude line ---
[ -n "$SEAT_MODEL" ] && CLAUDE_CMD="$CLAUDE_CMD --model $SEAT_MODEL"   # v3: per-seat model tier
if [ -n "$MODE_FLAG" ]; then
  LAUNCH_LINE="$CLAUDE_CMD $MODE_FLAG"
else
  LAUNCH_LINE="$CLAUDE_CMD"
fi
# v3: per-seat positional boot prompt (single-quoted -> one arg). For seats whose def initialPrompt
# does not auto-fire (architect). BOOT_PROMPT must contain no single-quotes.
[ -n "$BOOT_PROMPT" ] && LAUNCH_LINE="$LAUNCH_LINE '$BOOT_PROMPT'"
tmux new-session -d -s "$SESSION" -c "$WT_DIR"
sleep 1   # let the pane's shell initialize before keys arrive
tmux send-keys -t "$SESSION" "$LAUNCH_LINE" C-m

# --- optional mode-cycle keystrokes (default 0) ---
if [ "$BTAB_COUNT" -gt 0 ]; then
  sleep "$SETTLE_SECS"
  i=0
  while [ "$i" -lt "$BTAB_COUNT" ]; do
    tmux send-keys -t "$SESSION" BTab
    sleep 1
    i=$((i+1))
  done
fi

# --- receipt (observed facts only) ---
echo "== launch receipt =="
echo "lane/session : $LANE"
echo "lane source  : $LANE_SOURCE"
echo "folder       : $FOLDER"
echo "worktree     : $WT_DIR"
echo "launch line  : $LAUNCH_LINE"
echo "btab sent    : $BTAB_COUNT"
if [ "$ATTACH" -eq 1 ]; then
  echo "verify next  : attaching now → /status → confirm OBSERVED mode;"
else
  echo "verify next  : tmux attach -t "$SESSION"  → /status → confirm OBSERVED mode;"
fi
echo "               one Shift+Tab if auto didn't take."
echo "===================="

[ "$ATTACH" -eq 1 ] && exec tmux attach -t "$SESSION"
exit 0
