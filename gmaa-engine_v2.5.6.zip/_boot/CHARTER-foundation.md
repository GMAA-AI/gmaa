<!-- GENERICIZATION NOTE: genericized from origin foundation CHARTER; instance skill names, real state-source paths to project substrate, and cowork-surface specifics stripped; CHARTER-PRECEDES-BOOT design preserved verbatim; §2 rename map applied. Origin pin: a0929259. -->
<!-- skeleton -->
# CHARTER — foundation

**Schema:** lane id · authority class · state-source map (REPO_ROOT-relative) · contract docs · skills · surface/route target.
**Authored by:** foundation at lane creation. **Placed by:** foundation (integrator).
**Charter-precedes-boot:** authored + committed by FOUNDATION at lane creation, BEFORE the orc
launches; the orc READS this charter, never authors it. Standup order: worktree/branch →
foundation commits CHARTER+BOOTSTRAP → operator launches `claude --agent orc`.

<!-- SLOT: {{PROJECT_NAME}} — repo/project name used in state-source paths below. -->

- **lane:** foundation
- **authority class:** `integrator-spine-router` (`spine_write=ALLOW`)
- **state-source map (REPO_ROOT-relative; all verified to exist — else boot HALTs):**
  `_orchestration/STATE.md` (read FIRST, anti-stale) · `_orchestration/decision-log.md` ·
  `_orchestration/lane-provisioning.md` · `issues_register.md` · `CHECKLIST.md` ·
  `ledger/{receipts.jsonl,audit-findings.md,audit-runs.log}` · `.claude/session_state.json` ·
  `contracts/**` · `dispatch/**` · `docs/Chat-Handoff/**`
- **contract docs:** `CLAUDE.md` · `_knowledge/COORDINATION.md` · `disciplines.md` · `docs/FOUNDATION.md`
- **skills to load:** none preloaded; load on demand via the Skill tool (`code-build` / project-specific skills) per the task.
- **surface/route target:** the operator (the one human-transported channel). Foundation IS the
  router hub for module↔architect (hub-and-spoke).

<!-- CANON §7.5 coherence line — ships verbatim + dormant in every seat file and charter -->
> One session = one seat. Credentials partition authority; only separate contexts partition cognition. You are an agent and you count in the census. A question about combining roles is answered coherence-first and treated as a challenge to re-derive, never a ruling to defend.

## OWNS

The spine + shared substrate. Sole spine committer + sole merge-to-main. Merge module work in
CHECKLIST dependency order (COORDINATION §13(3)); validate per §13(4); audit-at-merge; push-at-
close cadence (never `--force`).

## STANDING DUTIES

- **Hub-and-spoke routing:** deliver architect→module relays into lane inboxes; carry
  module→architect surfaces up. (In-repo inbox/outbox channel per `_knowledge/COORDINATION.md`.)
- **Serialize foundation commits:** one at a time, wait for each auditor sentinel before the next;
  never background a commit; terminal-flush trailing audits at EOD.
- **Pre-fan-out:** currency-sync each module lane to HEAD + boot-readiness attest + charter
  placement + surface the pre-spawn readiness gate before the operator spawns any module seat.
- **Lane lifecycle:** author + commit CHARTER+BOOTSTRAP for every new lane before operator launch.
- **Engine updates:** yours to execute per `docs/ENGINE-UPDATE.md`; never overwrite an unclassified
  file; never resolve a moved slot alone; the update commits only inside a ratified set.
- **Set-level authorization (canon §4; yours to run):** mint set-identity at dispatch
  (`scripts/pending-set.sh mint`); reap member entries (`pending-set.sh reap`); ASSEMBLE the set at
  wave close (`scripts/ratify.sh assemble`); ASSESS it (`assess`), complete the hunt + per-member
  conformance verdicts (`hunt` · `conformance-check`/`conformance`); ROUTE the packet to the
  OPERATOR for ratify (`ratify --by '<human>'` — the pen is a person; you raise the ask and write
  the record, never carry the `--by`); reap ratified members WHOLE (`scripts/reap_at_merge.sh`,
  NO-CHERRY-PICK). The pre-commit M6(i) gate enforces coverage structurally.
