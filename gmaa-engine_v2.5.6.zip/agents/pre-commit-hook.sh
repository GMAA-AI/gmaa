#!/usr/bin/env bash
# agents/pre-commit-hook.sh — D3: spine_write HARD pre-commit gate.
#
# GENERICIZATION NOTE: mechanism byte-unchanged; this is the spine-write single-writer
# enforcement. The execution-lane carve-out keys on lane AND branch `executor` (folder-equals-lane
# convention: the executor worktree is folder `executor` on branch `executor`), moving with the
# resolve-lane.sh folder anchor. Ruling-number citations are rule-stated. The foundation
# resume-state pointer is spine-protected at `dispatch/LATEST.md` (the rest of dispatch/ stays
# module-writable for relays). `sql/`+`migrations/` are a commented C-DB-SLOT adopter stack
# (harmless no-op when absent; an adopter wiring a real database spine-protects them here).
# `foundation`/`main` are the base-census integrator + trunk (GENERIC-KEEP).
#
# Installed via scripts/install_pre_commit_hook.sh into .git/hooks/pre-commit
# (git hooks aren't versioned; this is the canonical source).
#
# Enforces COORDINATION.md §13(1) single-writer: ONLY the foundation lane
# may commit to spine-owned paths. A module lane (`module/<x>`, spine_write: DENY)
# that stages an edit to ANY spine-owned path is REJECTED (exit 1) at commit time.
# Module lanes commit only their own branch + PROPOSE spine changes; the
# integrator commits the spine.
#
# Identity comes from LOCATION via scripts/resolve-lane.sh — the SAME resolver the
# §0 cold-boot seat and the post-commit hook consume (one resolver, one
# consumption pattern). The resolver resolves the COMMITTING worktree's own root
# (`git rev-parse --show-toplevel`), never trunk/cwd, and cross-checks the stamped
# lane against the worktree FOLDER (folder-equals-lane).
#
# FAIL-CLOSED: if the lane cannot be resolved (resolver exit != 0 — no
# _boot/BOOTSTRAP.md, unset lane, or stamp<->folder mismatch) the commit is
# REJECTED. Never default to foundation on an unresolved lane.
#
# HARD PIN: committed + ENFORCED before ANY 2nd orc goes live (even same machine).

set -u

REPO_ROOT="$(git rev-parse --show-toplevel)"
RESOLVER="$REPO_ROOT/scripts/resolve-lane.sh"

if [[ ! -x "$RESOLVER" ]]; then
    echo "pre-commit REJECT: lane resolver missing/not-executable at $RESOLVER (fail-closed)." >&2
    exit 1
fi

# Resolve lane from THIS (the committing) worktree. Fail-closed on any non-zero.
if ! LANE_LINE="$("$RESOLVER")"; then
    echo "pre-commit REJECT: lane UNRESOLVED (resolver exit != 0)." >&2
    echo "  Cannot prove spine-write authority; fail-closed (never default to foundation)." >&2
    echo "  Cause: missing _boot/BOOTSTRAP.md, unset lane, or stamp<->folder mismatch (see resolver stderr above)." >&2
    exit 1
fi

# The resolver emits one KEY=VALUE line, all values single-token (lane/role/
# spine_write from _boot frontmatter; blob = git hash). eval matches the §0
# cold-boot contract `eval "$(scripts/resolve-lane.sh)"`.
eval "$LANE_LINE"   # -> lane= role= version= spine_write= blob= currency= subagent_model=

# --- Spine-owned path set (COORDINATION.md §13(1)) + membership helper. Defined BEFORE the lane
#     branches so BOTH the foundation set-coverage gate (M6(i)) and the module DENY gate consume
#     ONE list (no drift). ---
# ISSUE-1 FIX (v2.5.6): the census is emitted by the SINGLE authoritative source
# scripts/spine-census.sh (engine base set + the adopter's DECLARED set via
# scripts/declared-spine-paths.sh, HEAD-readback ruling #2). NO hand-maintained census literal lives
# here anymore. Before this, each spine gate carried its own copy and they DRIFTED — the merge-time
# backstop (reap_at_merge.sh) went stale and stopped recognising the set-authorization machinery's
# own files (MAINTAINED-STATE DRIFT, canon Appendix A). The cure is generation, not maintenance:
# probes/foundation/probe_census_parity.sh FAILS if any enforcement file reintroduces a census
# literal. Portable to the bash 3.2 floor — a read-loop, NOT mapfile/readarray (absent at 3.2).
# The governance rationale for each base entry now lives, once, in spine-census.sh.
SPINE_PATHS=()
while IFS= read -r _sp; do [[ -n "$_sp" ]] && SPINE_PATHS+=("$_sp"); done < <("$REPO_ROOT/scripts/spine-census.sh")
# Fail-CLOSED if the census yielded nothing (script missing / exec bit lost on checkout / emit error):
# a hardcoded array could never be empty, a generated one can — never commit with no spine knowledge
# (invariant #5 halt-loud-over-silent-degradation; the raw empty-array `set -u` crash is not a NAMED halt).
if [[ ${#SPINE_PATHS[@]} -eq 0 ]]; then
    echo "pre-commit REJECT: spine census empty — scripts/spine-census.sh missing/not-executable or emitted nothing (fail-closed)." >&2
    exit 1
fi

# Helper: is a path under a spine-owned prefix/file?
is_spine() {
    local f="$1" sp
    for sp in "${SPINE_PATHS[@]}"; do
        case "$sp" in
            */) [[ "$f" == "$sp"* ]] && return 0 ;;
            *)  [[ "$f" == "$sp"  ]] && return 0 ;;
        esac
    done
    return 1
}

# (r4 §2.11 declared-spine append now happens INSIDE scripts/spine-census.sh — the census emitter
#  yields base + the adopter's HEAD-readback declared set as one stream; both the module-DENY gate and
#  the foundation set-coverage gate protect the adopter's declared spine, never the base census alone.)

# === FOUNDATION: set-coverage gate (M6(i); canon §4; architect ruling 2026-08-17) ===
# Foundation may write the spine, but any AUTHORED-spine path it stages must be covered by a MEMBER
# of a RATIFIED set at HEAD. Enforcement is STRUCTURAL — set-membership BY PATH, not a message tag:
# ratification is a property of the SET OF PATHS changed, not of commit text ("before ANY member
# commits/applies … evaluated against the set", canon §4). A well-formed message cannot forge it.
# `[set SET-NNNN]` in the message stays a post-commit-verified convention, NEVER the gate.
# NAMED DELTA (A1): structural coverage replaces the order's "cite [set] in the message" (unrealizable
# at pre-commit — git has no message yet). Build order r2 / DONE-CRITERIA C6 carry the correction.
if [[ "${lane:-}" == "foundation" ]]; then
    # Exemptions BY PATH — the operator's A3 enumerated set (CLOSED list; the arm surfaces, never widens):
    #   ledger/**  ([audit] seals + apply-receipts)   _boot/**  (provisioning/genesis)
    #   PENDING-SET.md   _ratification/**
    #   _orchestration/{STATE.md, decision-log.md, lane-provisioning.md, relay-*}  (state pins + comms)
    #   dispatch/LATEST.md — foundation's resume-state pointer; operator RULED EXEMPT 2026-08-17: same
    #     nature as _orchestration/STATE.md (a handoff pin, not authored spine). Gating it would make
    #     foundation's own resume a ratification event → the mechanism would be routed around.
    # NOTE (forward-flag, from the source program's enforced run): CHECKLIST.md + issues_register.md +
    #   contracts/ are NOT exempt (authored spine) → once the gate is LIVE, a re-stamp/handoff commit
    #   touching them rides a set or is operator-exempted; surface, never self-widen.
    set_exempt() {
        case "$1" in
            ledger/*|_boot/*|PENDING-SET.md|_ratification/*) return 0 ;;
            _orchestration/STATE.md|_orchestration/decision-log.md|_orchestration/lane-provisioning.md) return 0 ;;
            _orchestration/relay-*|dispatch/LATEST.md) return 0 ;;
        esac
        return 1
    }
    if git rev-parse --verify -q HEAD >/dev/null 2>&1; then
        F_STAGED="$(git diff --cached --name-only 2>/dev/null)"
    else
        F_STAGED="$(git diff --cached --name-only --root 2>/dev/null)"
    fi
    AUTHORED=()
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        is_spine "$f" || continue
        set_exempt "$f" && continue
        AUTHORED+=("$f")
    done <<< "$F_STAGED"
    # No authored-spine staged → the set gate has nothing to cover; allow (§13(1) foundation write).
    if [[ ${#AUTHORED[@]} -eq 0 ]]; then exit 0; fi

    # Build the covered-path set from RATIFIED packets at HEAD. FAIL-CLOSED on unreadable/divergent
    # packets — an unreadable packet is NEVER treated as ratified. `- decision: RATIFIED` prefix-matches
    # BOTH merge states (RATIFIED · RATIFIED-WITH-SEQUENCE) and excludes AMENDED/HELD/REJECTED (5-state
    # taxonomy, C-RATIFICATION-PACKET §3). Parser aligns with scripts/ratify.sh's packet writer.
    COVERED=()
    shopt -s nullglob
    for p in "$REPO_ROOT"/_ratification/SET-*.md; do
        grep -qE '^- decision: RATIFIED' "$p" || continue
        ahead="$(awk -F': ' '/^- HEAD sha at assembly:/ {print $2; exit}' "$p" | tr -d ' ')"
        if [[ -n "$ahead" && "$ahead" != "?" ]]; then
            # the set must have been assembled against THIS tree (assembly sha is an ancestor of HEAD)
            if ! git merge-base --is-ancestor "$ahead" HEAD 2>/dev/null; then
                echo "pre-commit REJECT: ratified packet $(basename "$p" .md) was assembled at '$ahead', NOT an ancestor of HEAD — assembled against a different tree (fail-closed; re-assemble)." >&2
                exit 1
            fi
        else
            echo "pre-commit REJECT: ratified packet $(basename "$p" .md) has no readable assembly HEAD sha (fail-closed; never treat an unreadable packet as ratified)." >&2
            exit 1
        fi
        while IFS= read -r sfx; do
            [[ -z "${sfx// /}" ]] && continue
            IFS=',' read -ra PPS <<< "$sfx"
            for pp in "${PPS[@]}"; do pp="${pp// /}"; [[ -n "$pp" ]] && COVERED+=("$pp"); done
        done < <(awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$p" | sed -n 's/.*surfaces: //p')
    done

    # empty-array-safe under set -u (older bash): no ratified coverage → nothing is covered.
    path_covered() { local f="$1" c; [[ ${#COVERED[@]} -eq 0 ]] && return 1; for c in "${COVERED[@]}"; do [[ "$f" == "$c" ]] && return 0; done; return 1; }
    UNCOVERED=()
    for f in "${AUTHORED[@]}"; do path_covered "$f" || UNCOVERED+=("$f"); done
    if [[ ${#UNCOVERED[@]} -gt 0 ]]; then
        near="$(ls -1 "$REPO_ROOT"/_ratification/SET-*.md 2>/dev/null | tail -1 | xargs -r basename 2>/dev/null)"
        echo "pre-commit REJECT: foundation staged AUTHORED-spine path(s) NOT covered by a RATIFIED set at HEAD (canon §4 set authorization)." >&2
        for f in "${UNCOVERED[@]}"; do echo "    - $f   (nearest packet: ${near:-<none assembled>})" >&2; done
        echo "  Assemble → assess → ratify a set whose members' surfaces include these paths (scripts/ratify.sh), then commit." >&2
        exit 1
    fi
    exit 0
fi

# --- executor (execution-apply-receipt-writer; the ratified single-writer carve-out) ---
# spine_write: apply-receipts-only (declarative). ENFORCEMENT here, keyed on lane AND branch
# (neither inferred from the other): on branch `executor` ONLY, the executor may commit SOLELY
# under ledger/apply-receipts/**; every other path (incl. the rest of ledger/ and all spine
# paths) is DENIED. Single spine writer preserved; reaped-at-merge by foundation.
# NOTE (provisioning): the one-time _boot/ charter+bootstrap commit is a FOUNDATION provisioning
# act done with --no-verify (foundation authors the charter per CHARTER-PRECEDES-BOOT), NOT an
# executor runtime self-commit; runtime executor commits are apply-receipts only, enforced below.
if [[ "${lane:-}" == "executor" ]]; then
    if [[ "$(git rev-parse --abbrev-ref HEAD 2>/dev/null)" != "executor" ]]; then
        echo "pre-commit REJECT: lane 'executor' carve-out is valid ONLY on branch executor (got: $(git rev-parse --abbrev-ref HEAD 2>/dev/null))." >&2
        exit 1
    fi
    if git rev-parse --verify -q HEAD >/dev/null 2>&1; then
        E_STAGED="$(git diff --cached --name-only 2>/dev/null)"
    else
        E_STAGED="$(git diff --cached --name-only --root 2>/dev/null)"
    fi
    E_OUTSIDE=()
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        [[ "$f" == ledger/apply-receipts/* ]] && continue
        E_OUTSIDE+=("$f")
    done <<< "$E_STAGED"
    if [[ ${#E_OUTSIDE[@]} -gt 0 ]]; then
        echo "pre-commit REJECT: lane 'executor' may commit ONLY under ledger/apply-receipts/** on branch executor (the ratified execution carve-out)." >&2
        for v in "${E_OUTSIDE[@]}"; do echo "    - $v" >&2; done
        exit 1
    fi
    exit 0
fi

# --- Module lane (spine_write: DENY): reject any staged edit to a spine path. ---
# Spine-owned set = COORDINATION.md §13(1); SPINE_PATHS + is_spine() are defined ONCE above (before
# the lane branches) and consumed by both the foundation set-gate (M6(i)) and this module DENY gate.

# Resolve the integration-trunk ref at gate time from the spine manifest (do NOT hardcode
# 'main'; the manifest is itself spine-protected so this source cannot be subverted).
MERGE_HEAD_SHA="$(git rev-parse -q --verify MERGE_HEAD 2>/dev/null || true)"
TRUNK_BRANCH="$(awk -F'|' '$2 ~ /foundation/ {gsub(/[[:space:]]/,"",$3); print $3; exit}' "$REPO_ROOT/_orchestration/lane-provisioning.md" 2>/dev/null)"
TRUNK_SHA="$(git rev-parse -q --verify "$TRUNK_BRANCH" 2>/dev/null || true)"

VIOLATIONS=()
if [[ -n "$MERGE_HEAD_SHA" && -n "$TRUNK_SHA" && "$MERGE_HEAD_SHA" == "$TRUNK_SHA" ]]; then
    # === R1 ADOPT-FROM-TRUNK ===
    # A currency re-sync (merge ADOPTING the trunk) is allowed IFF the module contributes
    # NOTHING on spine paths: the index's spine MUST be BYTE-IDENTICAL to the trunk's spine.
    # Checked vs the TRUNK (not vs HEAD), so it catches divergence whether newly
    # conflict-resolved OR pre-existing in the module HEAD. Any spine path whose index blob
    # differs from the trunk = module-authored/conflict-resolved → REJECT.
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        is_spine "$f" && VIOLATIONS+=("$f")
    done <<< "$(git diff --cached --name-only "$TRUNK_SHA" 2>/dev/null)"
    REJECT_WHY="DIVERGE from the integration trunk — a currency-sync must adopt the trunk's spine VERBATIM (module-authored/conflict-resolved)"
else
    # === Standard D3 === spine paths changed by THIS commit (vs HEAD; --root if no HEAD).
    if git rev-parse --verify -q HEAD >/dev/null 2>&1; then
        STAGED="$(git diff --cached --name-only 2>/dev/null)"
    else
        STAGED="$(git diff --cached --name-only --root 2>/dev/null)"
    fi
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        is_spine "$f" && VIOLATIONS+=("$f")
    done <<< "$STAGED"
    REJECT_WHY="spine-owned — module lanes commit only their own branch + PROPOSE spine changes via reap-at-merge"
fi

if [[ ${#VIOLATIONS[@]} -gt 0 ]]; then
    echo "pre-commit REJECT: lane '${lane}' (spine_write: ${spine_write:-DENY}) — staged spine path(s) ${REJECT_WHY} (COORDINATION.md §13(1))." >&2
    echo "  Offending spine path(s):" >&2
    for v in "${VIOLATIONS[@]}"; do echo "    - $v" >&2; done
    exit 1
fi

exit 0
