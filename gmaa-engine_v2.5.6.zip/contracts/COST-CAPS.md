# contracts/COST-CAPS.md — cost-brake caps SLOT (C-SET-AUTHORIZATION §2.4; REQ-COST)

> **CONFIG, NOT CODE — an EMPTY slot by design.** The engine ships `scripts/cost-guard.sh` (the
> brake) + THIS caps file (the numbers). The adopter's operator fills the caps; the working numbers
> are **operator-movable** and never hardcoded in a mechanism. The source program's own cap numbers
> do NOT ship (they are its operator's, not the engine's).
>
> **Fail-closed (ENGINE-LAW):** an UNFILLED cap on a metered path is an unreadable property — the
> gate HALTs (`cost-guard.sh` exit 3), it never assumes zero and never passes. Fill the caps before
> wiring any metered call, or do not meter.
>
> **The law this configures (§2.4):** read the ledger you write — one durable usage row per metered
> call via the sanctioned write mechanism, NEVER sampled telemetry. `cost-guard.sh check` is called
> at the TOP of the next metered gate (+ once at cohort enqueue). Usage-WRITE failure =
> log-and-continue; usage-READ failure at check = HALT. A missing row after a successful call = a
> FINDING; a missing ledger at check = HALT.

## caps (adopter-filled; operator-movable)

```yaml
caps:
  per_unit_usd: {{PER_UNIT_USD}}         # HALT when a unit's summed spend reaches this (e.g. one WP/run)
  per_cohort_usd: {{PER_COHORT_USD}}     # HALT when a cohort's summed spend reaches this (e.g. a batch)
  fail_closed_if_unreadable: true        # declarative restatement — the script is fail-closed regardless

usage_ledger: ledger/usage/usage.jsonl   # where the sanctioned write mechanism lands usage rows
                                         # (C-DB adopters: point at the exported/materialized row file)

prices:                                  # per-meter USD **per token/unit** — used only when a row
  # <meter>: <usd-per-unit>              # carries `tokens` and no `usd_actual`
  {{METER}}: {{USD_PER_UNIT}}
```

## ledger row shape (reference)

```json
{"unit_id":"<adopter-named>","cohort_id":"<id|->","meter":"<meter>","tokens":0,"usd_actual":0.0,"at":"<UTC>"}
```

Pricing: `usd_actual` when present; else `tokens × prices.<meter>`. A row with neither → the check
is BLIND for that row → exit 3 HALT (never skipped, never $0).
