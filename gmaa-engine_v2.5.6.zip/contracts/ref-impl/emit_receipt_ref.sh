#!/usr/bin/env bash
# F4 RUNNABLE NEUTRAL REF-IMPL — emit_receipt_ref.sh
#
# PURPOSE: Emits a JSONL receipt line appended to a receipts file.
#   Demonstrates the generic receipt shape (C-GATE contract element).
#   The emitted line is a valid JSON object; verified with python json.loads.
#
# This script is the low-disclosure, no-adopter-infra proof that the
# free engine is RUNNABLE. No real ids, credentials, domains, or
# service bindings. Adopter wires to their own receipt ledger path.
#
# Usage:
#   bash emit_receipt_ref.sh <receipts_file>
#   bash emit_receipt_ref.sh /tmp/gmaa_receipts.jsonl
#
# The emitted receipt carries these generic fields (adopter may extend):
#   receipt_id    — PROVISIONAL lane id: R-<utc>-<lane>-<nonce> (see §2.15 below)
#   content_sha   — sha256 of the semantic payload (gate|item|status|halt|run_ts|actor);
#                   the uniqueness key is (receipt_id, content_sha), never the id alone
#   lane          — the emitting lane (GMAA_LANE; the ref default is the reference lane)
#   provisional   — true lane-side; the foundation single-allocator flips it false at reap
#   gate          — gate that fired
#   item_id       — item processed
#   status        — PASS | FAIL | HALT
#   halt_code     — null or a halt taxonomy code from C-GATE §7
#   run_ts        — UTC timestamp of the run
#   actor         — the mechanism slot identifier
#
# §2.15 RECEIPT-ID UNIQUENESS (single-allocator, relay-numbering doctrine).
#   A lane emits a PROVISIONAL id `R-<utc>-<lane>-<nonce>`. The per-process nonce makes two
#   same-second emissions distinct BY CONSTRUCTION (the origin `R-<ts>-<seq>` collided because seq
#   reset per run). The CANONICAL sequential id is NOT assigned here — the foundation is the single
#   allocator and stamps it at reap (`scripts/reap_at_merge.sh`), so two lanes' runs can never claim
#   the same canonical id. This script therefore ships lane-side provisional ids only.

set -euo pipefail

# sha256 helper — shasum (macOS/perl) then sha256sum (coreutils); either is present on adopters.
_sha256() { { shasum -a 256 2>/dev/null || sha256sum; } | awk '{print $1}'; }

RECEIPTS_FILE="${1:-}"
if [ -z "$RECEIPTS_FILE" ]; then
  echo "Usage: bash emit_receipt_ref.sh <receipts_file>" >&2
  exit 1
fi

GATE_ID="${GMAA_GATE_ID:-G7}"
ITEM_ID="${GMAA_ITEM_ID:-ITEM-REF-001}"
RUN_TS=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo "1970-01-01T00:00:00Z")
STATUS="PASS"
HALT_CODE="null"
ACTOR="{{EXECUTE_MECHANISM}}"
# Lane binding: the adopter's apply wrapper sets GMAA_LANE; the standalone ref proof uses `ref`.
LANE="${GMAA_LANE:-ref}"
# Per-process nonce: PID + $RANDOM so two same-second invocations cannot collide.
NONCE="${GMAA_NONCE:-$$-${RANDOM:-0}}"
RECEIPT_ID="R-${RUN_TS//:/-}-${LANE}-${NONCE}"

# content_sha = the SEMANTIC payload (NOT the id/nonce) → same receipt ⇒ same content_sha ⇒
# reap can tell an idempotent replay (tolerate) from a real collision (HALT).
CONTENT_SHA=$(printf '%s' "${GATE_ID}|${ITEM_ID}|${STATUS}|${HALT_CODE}|${RUN_TS}|${ACTOR}" | _sha256)

RECEIPT_LINE=$(printf \
  '{"receipt_id":"%s","content_sha":"%s","lane":"%s","provisional":true,"gate":"%s","item_id":"%s","status":"%s","halt_code":%s,"run_ts":"%s","actor":"%s"}' \
  "$RECEIPT_ID" "$CONTENT_SHA" "$LANE" "$GATE_ID" "$ITEM_ID" "$STATUS" "$HALT_CODE" "$RUN_TS" "$ACTOR")

echo "$RECEIPT_LINE" >> "$RECEIPTS_FILE"
echo "[emit_receipt_ref.sh] appended receipt to $RECEIPTS_FILE"
echo "  receipt_id  : $RECEIPT_ID (provisional; canonical id assigned by foundation at reap)"
echo "  content_sha : $CONTENT_SHA"
echo "  gate        : $GATE_ID"
echo "  status      : $STATUS"

python3 -c "
import json, sys
path = sys.argv[1]
lines = open(path).readlines()
for i, line in enumerate(lines, 1):
    line = line.strip()
    if not line:
        continue
    try:
        json.loads(line)
    except json.JSONDecodeError as e:
        print(f'JSONL PARSE ERROR on line {i}: {e}', file=sys.stderr)
        sys.exit(1)
print(f'[emit_receipt_ref.sh] JSONL verified ({len(lines)} line(s) in {path})')
" "$RECEIPTS_FILE"
