#!/usr/bin/env bash
# F4 RUNNABLE NEUTRAL REF-IMPL — apply_ref.sh
#
# PURPOSE: The reference ADOPTER APPLY WRAPPER. Runs the adopter's mechanism (the
#   {{EXECUTE_MECHANISM}} slot), emits an apply-receipt, and commits it on the LANE
#   branch. This is the one load-bearing instrument an adopter builds from this
#   skeleton — ship it correct-by-default so a from-scratch build is never the first
#   place the executor carve-out is exercised.
#
# CONTRACT (CLAUDE.md invariant #5 + the executor apply-receipts-only carve-out):
#   - Writes receipts ONLY under ledger/apply-receipts/<lane>/<run>.jsonl.
#     NEVER ledger/receipts.jsonl — that file is SPINE (foundation-owned, reaped at
#     merge by scripts/reap_at_merge.sh). The pre-commit executor carve-out REJECTS
#     an executor commit touching anything outside ledger/apply-receipts/**.
#   - FAIL-LOUD: any receipt-write or commit failure = `exit 3` with the reason.
#     NEVER warn-and-succeed — a swallowed commit failure would let the executor
#     proceed as if applied when nothing landed.
#   - Validated against the executor carve-out + reap_at_merge BEFORE first use
#     (scripts/test/test_set_gate_seeded_fault.sh §2.14).
#
# This is the low-disclosure, no-adopter-infra proof that the free engine is
# RUNNABLE. No real ids, credentials, domains, or service bindings. Adopters wire
# the mechanism slot + lane to their own infra.
#
# Usage (run from the lane worktree root, on the lane branch):
#   GMAA_LANE=executor bash contracts/ref-impl/apply_ref.sh
#   GMAA_LANE=executor bash contracts/ref-impl/apply_ref.sh --dry-run   # mechanism dry-run only
#
# Env slots (adopter fills):
#   GMAA_LANE            — the applying lane (default: the resolved lane, else 'ref').
#   GMAA_APPLY_RECEIPTS  — receipts target (default: ledger/apply-receipts/<lane>/<run>.jsonl).
#                          The default is the ONLY correct target; it is overridable so a
#                          MISCONFIGURED wrapper can be caught by the carve-out (see §2.14
#                          acceptance), NEVER to sanction writing the spine ledger.
#   GMAA_APPLY_NO_COMMIT — set to 1 to emit the receipt without committing (mechanism check only).

# NOTE: deliberately NOT `set -e`. A FAIL-LOUD wrapper must CATCH each failure and exit 3
# with a reason, never let `set -e` surface a bare exit 1 that a caller could mistake for a
# routine gate rejection.
set -u

EXIT_FAILLOUD=3
fail() { echo "[apply_ref.sh] FAIL-LOUD: $*" >&2; exit "$EXIT_FAILLOUD"; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EMIT="$HERE/emit_receipt_ref.sh"
FIRE="$HERE/fire_ref.sh"
[ -f "$EMIT" ] || fail "receipt emitter missing at $EMIT"

DRY_RUN=false
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=true ;;
    *) fail "unknown argument: $arg (usage: [--dry-run])" ;;
  esac
done

# --- Lane binding: adopter sets GMAA_LANE; else resolve from location; else the ref lane. ---
LANE="${GMAA_LANE:-}"
if [ -z "$LANE" ] && [ -x scripts/resolve-lane.sh ]; then
  LANE="$(scripts/resolve-lane.sh 2>/dev/null | sed -n 's/^lane=//p' | awk '{print $1}' | head -1)"
fi
LANE="${LANE:-ref}"

RUN="apply-$(date -u +%Y%m%dT%H%M%SZ 2>/dev/null || echo REF)-$$"
# The ONLY correct target is under ledger/apply-receipts/<lane>/. Overridable so a
# misconfigured adopter wrapper is caught by the carve-out (never a sanctioned spine write).
TARGET="${GMAA_APPLY_RECEIPTS:-ledger/apply-receipts/${LANE}/${RUN}.jsonl}"

# --- 1) Run the adopter mechanism (the {{EXECUTE_MECHANISM}} slot). Neutral ref = fire_ref.sh
#        --dry-run (no network). An adopter replaces this call with its real apply mechanism. ---
if [ -f "$FIRE" ]; then
  GMAA_GATE_ID="${GMAA_GATE_ID:-G7}" GMAA_ITEM_ID="${GMAA_ITEM_ID:-ITEM-REF-001}" \
    bash "$FIRE" --dry-run >/dev/null || fail "mechanism (fire_ref.sh --dry-run) returned non-zero — nothing applied"
fi
if [ "$DRY_RUN" = true ]; then
  echo "[apply_ref.sh] mechanism dry-run OK (lane $LANE); no receipt emitted, no commit; exit 0"
  exit 0
fi

# --- 2) Emit the apply-receipt into the target path. FAIL-LOUD on any emit failure. ---
mkdir -p "$(dirname "$TARGET")" || fail "cannot create receipt dir $(dirname "$TARGET")"
GMAA_LANE="$LANE" bash "$EMIT" "$TARGET" >/dev/null || fail "receipt emit failed → $TARGET"
[ -s "$TARGET" ] || fail "receipt file empty/absent after emit → $TARGET"

if [ "${GMAA_APPLY_NO_COMMIT:-0}" = "1" ]; then
  echo "[apply_ref.sh] receipt emitted to $TARGET (no-commit mode); exit 0"
  exit 0
fi

# --- 3) Commit ONLY the receipt on the lane branch. The pre-commit executor carve-out is the
#        enforcement: it REJECTS anything outside ledger/apply-receipts/**. If it (or ANY other
#        cause) fails the commit, surface exit 3 — never warn-and-succeed. ---
git add -- "$TARGET" || fail "git add failed for $TARGET"
# Capture git's own stderr so the FAIL-LOUD exit carries the REAL reason (a pre-commit carve-out
# REJECT prints here) rather than a presumed one. Apply-receipts must land under
# ledger/apply-receipts/** on the lane branch — anything else is rejected by the executor carve-out.
COMMIT_ERR="$(git commit -q -m "apply: receipt $RUN (lane $LANE)" -- "$TARGET" 2>&1)" || \
  fail "commit failed for $TARGET — nothing applied. Receipts must be under ledger/apply-receipts/** on the lane branch (executor carve-out).
    git: ${COMMIT_ERR:-<no output>}"

echo "[apply_ref.sh] applied: receipt committed at $TARGET (lane $LANE); exit 0"
exit 0
