# C-SET-AUTHORIZATION — the set-authorization model

> **ONE authoritative document** for the set-authorization + enforcement + check model. **Maintained
> by editing THIS file** (bump the version + Change-log), never by spawning new dated amendments
> (operator: "There should be one document, not 100 amendments").
>
> GENERICIZATION NOTE (round-trip provenance): this model was authored in a field program that
> lifted the set-gate FROM this engine (at frozen 7a179264), hardened it to ALL-ENFORCED at its
> live HEAD, proved it biting on real multi-lane data, and RE-SOURCED the whole cut back for
> packaging (2026-08-19). Mechanism + model verbatim; the source program's lane names → the generic
> census (foundation / module-a… / executor), its ruling/turn numbers → rule-stated, its instance
> build-history → redacted to the model's content. The WIRE column below states THIS ENGINE's
> shipped state, FLIP-probe-backed — never the source program's.
>
> - **Seat/authority:** architect (HOW-class adjudicator). Lives at `contracts/C-SET-AUTHORIZATION.md`;
>   foundation lands it on the spine at reap (foundation's pen).
> - **Status:** v0.11 — model ratified; **BITING PROOF COMPLETE IN THE SOURCE PROGRAM, TWO SETS
>   CLOSED END-TO-END** (both accept polarities EMPIRICAL — M6(ii) module-reap + M6(i)
>   foundation-coverage; the full reject battery §10·U5·U4B·M6(i)·M6(ii)·carve-out·module-DENY
>   captured live, no `--no-verify`; rule-stated). **ENGINE-LAW (operator): if a property is
>   UNREADABLE — intent, meaning, sampled telemetry, an unfilled slot — the gate does NOT PASS; it
>   REFUSES or demands a signed slot. The gate reads STRUCTURE; a human / a non-empty integrator
>   slot carries JUDGMENT — fail-closed SLOTS, not smarter inference.** Four fixes ratified +
>   schematized (rule-stated): **anti-gaming CLOSED via footprint-coverage** (§2.2 — was the §1 R2
>   gap) · **joint-edge 3-layer + required SEMANTIC-HUNT slot** (§2.3) · **cost-brake shape**
>   (§2.4) · probe-claim/FLIP law. WIRE state is HONEST per the §2 table.
> - **⚖ SUBORDINATE TO STANDING LAW** — this model does NOT preclude the laws (see §L). It operates
>   within evidence-first + the binding invariants + the disciplines; where they conflict, the LAW governs.
> - **THE THESIS:** "the unit of authorization is the SET, not the change." This document is that
>   thesis realized as an enforced mechanism — field-hardened, then re-sourced into the engine.

---

## L. Governing law — this model is SUBORDINATE to the standing law (does NOT preclude it)
Operator: *"my statements on the flow do not preclude its laws, such as evidence first, etc."* This
model is a mechanism built WITHIN the standing binding law — it never suspends, exempts, or overrides
it. **Where the flow and a standing law appear to conflict, the LAW governs.** The flow's checks are
themselves bound by it — a check verdict is not privileged over evidence.
- **Evidence-first** (BOOT-CREED + trigger→cite; `disciplines.md §0 DISC-INDEX`) binds every seat AND
  every check here. A check verdict (coherence / conformance / biting) is an evidence-first claim —
  grounded, cited, substrate-verified — never asserted. *"none found" is a claim, not a proof* — this
  is already encoded in `ratify.sh §13` DETECTION-HONESTY (= DISC-ABSENCE-OF-RECORD).
- **Binding invariants are not suspended:** #1 LIVE-DATA-ONLY · #2 WRITE-VIA-MECHANISM · #3
  MECHANISM-CONTRACT · #4 no-fake-closures (a check "passes" only on grep'd/probe evidence, never a
  hypothesis) · #5 halt-loud (any unverifiable load-bearing claim / missing record / `stop_reason` →
  HALT, no silent degrade). (The engine's invariant census — CLAUDE.md §Binding invariants.)
- **Disciplines apply to the flow's operations**, e.g.: DISC-VERIFY-DEPLOY-STATE-CLAIMS +
  SUBSTRATE-OVER-UI (a gate/record "installed / current" is a live-state claim → readback — this is
  why §2's WIRE audit was mandatory); DISC-PROBE-INPUT-PROVENANCE (a check on synthetic input proves
  only the synthetic case — §6 DoD); DISC-CORPUS-IS-MEMORY (the structure-of-record is memory → verify
  live — §5); DISC-ONE-DECISION-DOOR (escalation to operator — §1 R5); DISC-DIRECTIVE-PROVENANCE
  (operator words carry authority only via the channel / a verbatim receipt — §0).
- **Corollary (the law is already load-bearing here):** §2 "fail-closed" IS #5 halt-loud applied to
  the set-gate; §5 check-reference completeness being fail-closed IS evidence-first (you cannot check
  what isn't on record → HALT, never pass blind); §6 DoD IS evidence-first applied to the biting proof.

## 0. Provenance (operator directives, verbatim — DISC-DIRECTIVE-PROVENANCE; rule-stated. Lane
## names in the quotes are resolved to the generic census; the words are otherwise the operator's.)
1. *"Before I ratify any set, the test must be real data, no fake data and should include multiple
   lanes submitting their proposals to foundation"* + *"module-a and executor as well as possibly [module-b]
   and module-c"* → §6 DoD.
2. *"The flow should be that architect creates the spec and rules and submits the spec to foundation,
   foundation the distributes the wp to the lanes per its breakdown … the orchestrator … determines
   the set … the set does not mean just changes from one lane … checks are done between the changes
   in the set and the codebase then against the spec … if it all checks out … the operator for
   authorization to commit … if something doesn't check out, the task/s … get sent back … can't
   resolve it … routed back to foundation to … the architect for adjudication … if the architect
   needs operator input … presented to the operator. And then back down the chain"* + *"This is how
   it has been supposed to be working and I want the flow validated. This is not new."* → §1, §8.
3. *"when it all checks out, the foundation and only the foundation writes the set records to it's
   coherence boundary"* → §1 U7.
4. *"You say mostly enforced. It needs to become all enforced"* + *"If that breaks, the system fails"*
   + *"read what hooks it.. how is it enforced"* → §2.
5. *"First complete the enforcement of the spine"* → §7 sequencing.
6. *"the lane proposals should include changes it wants to make to the db or make [or whatever] record
   becomes permanent. That is potentially part of what's checked"* → §3.
7. *"Those changes should be documented in the spine by foundation for future checks"* → §4.
8. *"The foundation should have the db configuration and database schema on record with all the
   sprocs, etc so it can check for issues"* + *"Same with other systems"* + *"Also the db model"* +
   *"I expect you to fill in those blanks"* → §5.
9. *"Now my statements on the flow do not preclude its laws, such as evidence first, etc"* → §L.
10. *"if there is only work for one lane, i cant make all the work hold up until there is work for the other
    lanes … if there are multiple lanes that foundation sent the wp to, then the foundation determined what
    the set is, when it sent out the work … if the only wp is to one lane, and no other lanes have work, then
    that is the set. if the work packages being sent out, have more than one lane, then the set must involve
    them all. however, the foundation is prohibited from purposefully sending out wp that dont have other lanes
    at the same time, so that it can make smaller wp and smaller sets. its based on requirements and not based
    on effort"* → §1 R2 (REPLACES the v0.9 "inherently multi-lane"; §0.1 "multiple lanes" re-scoped to the
    source program's biting PROOF, not a per-set floor).
11. *"foundation is supposed to ask and only it can write it"* → §1 R4/U7 (FOUNDATION raises the authorization
    request + is the SOLE writer of the set record; the architect ASSESSES the biting proof + adjudicates, but
    does NOT solicit/carry the `--by` and does NOT write the record — corrects the architect's prior "architect
    brings the operator the `--by`" framing).

---

## 1. The set-authorization round-trip (the flow)
Standing intended design (operator: "not new") — validated leg-by-leg against HEAD (§8).

```
DOWN (spec → work):
 ARCHITECT ──spec+rules──▶ FOUNDATION ──WPs per breakdown+SPEC+sequence──▶ LANES
 (authors WHAT-of-HOW)      (orchestrator; DETERMINES THE SET)              (execute own WP; intra-lane
                                                                            checks are the LANE'S own)
UP (assembly → authorization):
 LANES ──submit completed WP──▶ FOUNDATION assembles the SET, runs TWO checks:
   (A) set × codebase/live-substrates  = COHERENCE   (composes, no conflict)
   (B) set ⊨ the SPEC                  = CONFORMANCE  (inline with the spec)
   ├─ all check out ──▶ OPERATOR `--by` AUTHORIZE-TO-COMMIT ──▶ U7: FOUNDATION-ONLY writes the set
   │                                                            records to the coherence boundary; reap (whole set, no cherry-pick)
   └─ something fails ──▶ failing TASK(s) → owning lane(s) REDO ──▶ resubmit ──▶ re-check
            └─ can't resolve ──▶ FOUNDATION ──▶ ARCHITECT (adjudicate) ──▶ (if needed) OPERATOR ──▶ back DOWN the chain
```

- **R1 Foundation determines the set** — its decomposition of the architect's spec into WPs (per
  breakdown + sequence); membership is an orchestrator decision, not lane self-nomination.
- **R2 The set's boundary is the REQUIREMENT, not effort or lane-count** (operator §0.10, verbatim
  2026-08-18; REPLACES the v0.9 "inherently multi-lane"). A set = the WPs foundation dispatches for ONE
  requirement; its identity is born at DISPATCH (R1). Lane-cardinality is whatever the requirement dictates:
  - **One lane's work, no other lanes with work → THAT is the set** (single-lane, even single-member) — a
    ready lane is NEVER held waiting for unrelated lanes to have work. Still both-checked (coherence: change ×
    codebase/prior-authorized-state; conformance: member ⊨ spec); cross-member coherence is vacuous (nothing
    to collide with), not skipped.
  - **A requirement decomposed across ≥2 lanes → ONE set that MUST contain them ALL** — no partial
    ratification, no cherry-pick (whole-set reap, M6(ii); a subset is a NEW set, §5 SUBSET RULE). Here a lane
    finishing early DOES wait — that wait is a real coherence dependency, not artificial coupling.
  - **Anti-gaming (operator §0.10):** foundation is PROHIBITED from purposefully staggering/splitting dispatch
    so a genuinely multi-lane requirement is issued as isolated single-lane WPs to shrink WPs/sets.
    Decomposition is by REQUIREMENT, never by EFFORT. Membership is an orchestrator decision (R1), never lane
    self-nomination — but the orchestrator's decomposition is bounded by the requirement's true footprint.
  - **CLOSED via footprint-coverage (v0.11 — the gate reads STRUCTURE, not intent).** "Purposefully" is an intent
    the gate cannot read — so we do NOT ask it to. Membership is bound to a DECLARED FOOTPRINT and the gate checks
    COVERAGE (readable). The architect spec declares each requirement's lane/substrate FOOTPRINT (a WHAT-of-HOW
    property, architect-owned); the gate verifies the assembled set COVERS it — a missing footprint-lane → REFUSE.
    Three parts, all mechanical + fail-closed (full schema §2.2): (a) footprint in the spec (no footprint → not
    dispatchable — the U4B corollary); (b) dispatch-time set-identity (`set_id` minted once per `requirement_id`;
    a 2nd dispatch of the same requirement under a different `set_id` → HALT, the stagger); (c) assemble-time
    coverage (`assembled_lanes ⊇ footprint.lanes` else `FOOTPRINT-MISS` HALT). Single-lane footprints stay legal
    (coverage vacuous + valid). This CLOSES the former convention-bound gap: design-complete; WIRE = REQ-FOOTPRINT
    (§2 table). NOT: no NLP of WP text; no inferring footprint from files-touched (files are M4; footprint is
    who-must-be-in-the-room, declared before work starts).
- **R3 Two checks, both required** — (A) coherence, (B) conformance-to-spec (see §2 U4B).
- **R4 Pass ⇒ FOUNDATION asks, operator authorizes, FOUNDATION writes** (operator §0.11, verbatim). When both
  checks pass, FOUNDATION — holding the assembled+checked packet — RAISES the authorization request to the
  operator; on the operator's `--by` (`ratify --by '<human>'`; Canon §10 agent-assesses / human-ratifies),
  FOUNDATION and ONLY foundation (U7) writes the set record. The ARCHITECT assesses the biting proof/evidence
  (input to foundation's ask) and adjudicates escalations, but does NOT solicit or carry the `--by` and NEVER
  writes the record. (Corrects the architect's prior "architect brings the operator the `--by`" framing.)
- **R5 Fail ⇒ structured return + escalation** — failing task → owning lane; unresolved →
  foundation → architect → (operator) → back down. The failed member is STRUCTURALLY barred from the
  boundary regardless.
- **U7 Foundation-and-only-foundation writes the set records to the coherence boundary** (the spine).

## 2. Enforcement — ALL enforced, fail-closed, load-bearing
Operator bar: no leg on convention; a break = system failure ⇒ fail-closed (invariant #5, no silent
degradation) AND proven-to-bite; verified AT THE WIRE (installed + firing), not asserted from source.

**Per-leg enforcement (logic + WIRE — THIS ENGINE's shipped state, seeded-fault/FLIP-proven):**
| Leg | Mechanism | Logic | WIRE (in this engine) |
|---|---|---|---|
| D3 lane propose-not-commit | `pre-commit-hook.sh` module-DENY | ✅ | ✅ ships; installed via `scripts/install_pre_commit_hook.sh`; byte-currency checked at every boot (`boot-check.sh` HOOK-CHECK); seeded-fault proven (module staging spine → REJECT) |
| U4A coherence (set × codebase) | `ratify.sh` M4 3-layer joint-edge + M6(i) coverage | ✅ | ✅ ships; seeded-fault proven (uncovered authored-spine → REJECT; covered → PASS) |
| **U4B conformance (set ⊨ spec)** | `ratify.sh` conformance-check/conformance (§2.1) | ✅ | ✅ ships; ratify-time (foundation-run); seeded-fault proven (verdict MISSING → MERGE HALT) |
| U5 operator authorize | `ratify --by` mandatory; REFUSES empty-assessment + unresolved-edge; foundation-only | ✅ | ✅ ships; seeded-fault proven |
| U6 fail→return | non-RATIFIED member barred from reap (M6(ii)) | ✅ | ✅ ships; seeded-fault proven (non-member → NO-CHERRY-PICK HALT). **`agents/pre-merge-commit-hook.sh` (forced merge-path): NOT SHIPPED** in this engine revision — the source program forces the merge-path with it (sentinel `REAP_AT_MERGE=1`); `reap_at_merge.sh` exports the sentinel so a tree that wires it recognises the sanctioned reap (see its FORCED MERGE-PATH note; honest-label, bytes requested from the source integrator) |
| U7 foundation-only write | `ratify.sh` resolve_foundation + `reap_at_merge.sh` identity gate + custody fork | ✅ | ✅ ships; resolver-gated (fail-closed on unresolved lane) |
| **FOOTPRINT-COVERAGE (anti-gaming)** | `ratify.sh assemble`: `assembled_lanes ⊇ spec footprint.lanes`; dispatch mints `set_id` per `requirement_id` (§2.2) | ✅ | ✅ **SHIPPED + FLIP-PROVEN** — `probes/set-gate/probe_footprint_coverage_flip.sh` (standing probe #6): seeded FOOTPRINT-MISS fails, full coverage proceeds |
| **SEMANTIC-HUNT slot (joint-edge C)** | `ratify.sh` required HUNT block; UNABLE / missing / CLEAR-with-zero-candidates-no-method → REFUSE (§2.3) | ✅ | ✅ **SHIPPED + FLIP-PROVEN** — `probes/set-gate/probe_semantic_hunt_flip.sh` (standing probe #7) |
| **COST-BRAKE (metered)** | `cost-guard.sh check` reads the usage LEDGER; exit 2 over-cap HALT, exit 3 unreadable HALT (§2.4) | ✅ | ✅ brake SHIPPED (`scripts/cost-guard.sh`, seeded-fault proven 0/2/3) + **EMPTY caps SLOT** (`contracts/COST-CAPS.md` — unfilled caps on a metered path → exit 3, fail-closed). The CALL SITE is adopter-wired (the base engine ships no metered gate; C-GATE slot) |

**COVERING LAW (operator — binds all three additions above):** if a property is UNREADABLE —
intent, meaning, sampled telemetry, an unfilled slot — the gate does NOT PASS; it REFUSES or demands a SIGNED slot.
PASS is reserved for a check that COULD have failed and did not. The gate reads STRUCTURE; a human / a non-empty
integrator slot carries JUDGMENT. **No LLM inside any detector** (a model may only produce a CANDIDATE LIST a human
still signs — it can never stamp a verdict). The three additions are fail-closed SLOTS in this sense, never smarter
inference. **WIRE honesty:** the table above states what THIS engine ships and proves; doctrine may not assert an
enforcement the bytes do not run (a named-but-unrun brake is a false-green on the box) — which is why the
pre-merge-commit hook and the metered call site carry explicit honest-labels instead of ✅ claims.

**Closures to reach ALL-enforced (spine):**
- **(a) LOGIC — U4B** as a hard, **non-overridable**, fail-closed assess member-check: a per-member
  conformance verdict (member ⊨ spec); `ratify` REFUSES on FAIL **or MISSING** (same shape as
  empty-assessment/unresolved-edge). Honest gate-vs-verdict model: the GATE is mechanical + fail-closed
  (a passing verdict is REQUIRED); the verdict's production is structured coverage where possible, else
  a bounded judgment at the edge (DISC-LLM-AT-THE-EDGES — no LLM in a mechanism without an architect
  ruling + cost gate if metered).
- **(b) WIRE — the installation/invocation must itself be fail-closed:** auto-install +
  currency-verification (HALT-LOUD if installed hook ≠ source — a stale/absent gate must never
  silently pass); forced merge-path (module → main ONLY via `reap_at_merge.sh`; a raw `git merge`
  prevented or post-merge REJECTED — M6(ii) can't depend on the integrator remembering the script).
  - **Forced merge-path (source-program design, PROVEN there; the HOOK is NOT shipped in this engine
    revision — honest-label):** a `pre-merge-commit` hook REJECTS any merge INTO the trunk unless it
    carries the reap sentinel `REAP_AT_MERGE=1` (fail-closed; NO `MERGE_MSG`/message escape — a
    message is forgeable, rule-stated). The sanctioned reap runs `merge --no-ff --no-commit` so
    pre-merge-commit does not fire → M6(i) gates the commit; a conflicted raw merge is caught by
    M6(i) at `git commit`. Break-glass = `git merge --no-verify` (logged). THIS ENGINE ships the
    sentinel export in `reap_at_merge.sh` (see its FORCED MERGE-PATH note) so a tree that wires the
    hook recognises the sanctioned reap; the hook bytes themselves are a tracked-forward re-source.
  - **RESIDUAL (disclosed, tracked-forward):** a FAST-FORWARD merge of a module into the trunk
    creates no merge commit ⇒ no hook fires — structurally beyond git's `pre-merge-commit` reach. It
    requires the trunk to be a strict ancestor of the module tip, which does not hold while
    foundation is ahead (reap is `--no-ff`), so it does not occur in this workflow. A structural
    close needs a server-side/pre-push ff-bar. **NO interim belt** — `merge.ff=false` was considered
    and WITHDRAWN in the source program (rule-stated): because the hook rejects EVERY non-sentinel
    merge into the trunk (no source/ref allow — forgeable), `merge.ff=false` would route a routine
    `origin/main` fast-forward SYNC into the reject path, breaking foundation's own sync. A
    non-composing belt is worse than none; the ONLY correct fix is the structural ff-bar
    (tracked-forward). Do NOT read "forced merge-path" as ff-airtight.
- **(c) BITING-PROOF:** each gate demonstrably REJECTS a real violation on real data against the LIVE
  installed hook (= §6 DoD).

### 2.1 U4B conformance mechanism (the spec foundation builds)
- **What "the spec" is:** each member implements a WP foundation assigned from the architect's
  authored spec; that WP carries **explicit acceptance criteria** (architect-owned — a WP is not
  dispatchable without them; §1 DOWN-leg). Conformance = the member's declared effects (§3 manifest)
  satisfy its WP's acceptance criteria.
- **Verdict production (decision rule):**
  - **STRUCTURED (preferred, no LLM):** where a criterion is machine-checkable — a file/object
    exists, a sproc has param X, a test passes, a declared DB/Make/WP effect matches the
    structure-of-record (§5), a coverage predicate holds — a checker emits PASS/FAIL mechanically.
    Migrate criteria to this form as they harden.
  - **BOUNDED JUDGMENT AT THE EDGE:** where a criterion is irreducibly prose (e.g. "the review reads
    naturally") — a single-turn, structured-output judgment over {member changes, the criterion},
    recorded with its evidence. SANCTIONED per DISC-LLM-AT-THE-EDGES (this ruling is the required
    architect sanction); held only until it distills to structured; cost gate applies IF
    metered/recurring (DISC-NEW-INFRA-IMPACT-REVIEW → one operator sign-off; flagged, not now).
- **The gate (mechanical · fail-closed · non-overridable):** assess REQUIRES a conformance verdict
  for EVERY member (PASS, with evidence); `ratify` REFUSES on any FAIL **or MISSING** — identical
  shape to the existing empty-assessment / unresolved-edge refusals. No override lever (rule-stated).
- **Recorded:** the per-member verdict + evidence lands in the `_ratification/SET-NNNN.md` packet
  (the spine record, §4), so a future check reads it.
- **Corollary (DOWN-leg):** an architect WP/spec is NOT dispatchable without explicit, checkable
  acceptance criteria — that is what makes U4B enforceable (you cannot conform-check against a spec
  that states no criteria). Authoring checkable acceptance criteria is architect-owned.

### 2.2 Footprint-coverage — anti-gaming as a fail-closed SLOT (REQ-FOOTPRINT; v0.11)
Bind membership to a DECLARED footprint; check coverage (readable). Do NOT ask the gate to detect "purposefully."
- **Spec footprint (architect-owned, required to dispatch) — a CLOSED block on every requirement:**
  ```yaml
  requirement_id: REQ-0041
  footprint:
    lanes: [module-a, executor]    # REQUIRED occupants ("who must be in the room"); may be ONE (single-lane legal)
    substrates: [spine, azure-sql] # OPTIONAL declared SoR surfaces this requirement may write (secondary cross-check)
    exclusive: true                # this REQ is ONE set; no sibling dispatch under another set_id
  ```
  No footprint → `pending-set.sh`/dispatch REFUSES; a WP is not dispatchable without a parent `requirement_id`
  (the same corollary as §2.1 — no criteria file → not conform-checkable).
- **Dispatch-time set-identity (born at send, not reverse-engineered at assemble):** foundation mints `set_id:
  SET-NNNN` ONCE per `requirement_id`, stamps it on every WP + `SET-MEMBER-*.md`. A 2nd dispatch of the same
  `requirement_id` under a DIFFERENT `set_id` → HALT (the stagger). A WP whose `requirement_id` has no minted
  `set_id` → HALT.
- **Assemble coverage (mechanical, fail-closed):** `ratify.sh assemble`, before writing the packet — (1) all
  pending members share ONE `requirement_id` + ONE `set_id` (mixed → HALT: two requirements = two sets); (2) load
  `footprint.lanes`; (3) `assembled_lanes ⊇ footprint.lanes` else `HALT: FOOTPRINT-MISS: spec requires <lanes>;
  assembled has <lanes>` — a missing REQUIRED lane is NEVER assess-aroundable on a MERGE decision (U4B shape);
  (4) EXTRA lanes beyond the footprint are NOT auto-pass — a JOINT-EDGE of class `UNDECLARED-OCCUPANT` (integrator
  MUST assess; MERGE allowed AFTER assessment). `substrates` is a secondary declared-scope cross-check (a member
  writing outside it is a flagged edge, not a hard-miss). Single-lane footprint → coverage vacuous + valid.
- **Standing probe (FLIP):** spec footprint `[A,B]`, dispatch only A, assemble → FAIL; both present → proceeds.

### 2.3 Joint-edge coherence — 3 layers; incompleteness is UNSKIPPABLE, not "completed" (REQ-HUNT; v0.11)
Canon §13 forbids claiming the conflict surface is complete. Fix the READING ("NONE = safe"), not the oracle.
- **Layer A (shipped, mechanical):** path overlap · shared-unforkable (spine path) · declared-dependency cycle.
- **Layer B (new, mechanical, still-incomplete-and-said-so):** at assemble, diff member surfaces vs the §5
  structure-of-record index — two members citing the same `contracts/*.md` section / sproc or object name /
  `seats.yaml` key / `SLOTS.md` id / standing-probe id → emit `SHARED-RECORD: <id> (members X,Y)` (integrator MUST
  assess). Catches "both change the meaning of `sp_promote` without touching the same file." Still misses two
  contradicting prose sentences — SAID SO on the packet.
- **Layer C (a REQUIRED slot, not a skippable paragraph):** `assemble`/`assess` fail-closed on a missing/incomplete
  block:
  ```
  ## SEMANTIC HUNT (canon §13 — required; 'none found' is a claim)
  - hunt-at: <UTC>          - method: <what was grepped / which SoR indexes were opened>
  - candidates considered: <list or ZERO>          - residual risk: <one sentence>
  - verdict: CLEAR | EDGE-NAMED | UNABLE
  ```
  Rules: **UNABLE or missing → `ratify --decision RATIFIED` REFUSES** (empty-assessment shape). **CLEAR with
  `candidates: ZERO` and no `method` → REFUSE** (an assertion, not a hunt — DISC-ABSENCE-OF-RECORD applied to the
  hunt itself). **EDGE-NAMED → the names join JOINT-EDGES as `INTEGRATOR-JUDGMENT:` and resolve like mechanical
  edges (assess / AMENDED).** No LLM stamps CLEAR — a model may only hand the integrator a candidate list to sign.
- **Packet-header wording (adopters cannot misread):** *"Mechanical JOINT-EDGES = NONE does NOT mean the set is
  coherent. MERGE is legal only after SEMANTIC HUNT verdict is CLEAR or every named edge is resolved."*

### 2.4 Cost-brake — read the ledger you write; unreadable = HALT (REQ-COST; v0.11)
The runtime boundary of the cost-governance triad (ARCH-116/119). Read DB usage rows, NEVER sampled telemetry
(the F-A scar). Missing half = SUM-before-the-next-metered-call + HALT if the SUM cannot be performed.
- **Usage ledger (law):** one durable row per metered call (`unit_id` adopter-named · `meter` · tokens/`usd_actual`
  · `at`) via the sanctioned C-DB mechanism, never App Insights.
- **Caps SLOT (config, not code):** `contracts/COST-CAPS.md` / a `SLOTS.md` row — `per_unit_usd`, `per_cohort_usd`
  (operator-movable), `fail_closed_if_unreadable: true`, `prices:` per-meter (adopter fills). Unfilled caps on a
  metered path → HALT (unfilled slot).
- **`scripts/cost-guard.sh check --unit <id> [--cohort <id>]`:** reads the LEDGER, prices rows, compares to caps —
  exit **0** under · **2** at/over (HALT-LOUD `COST-CAP unit=… spent=… cap=…`) · **3** unreadable (HALT, never
  "assume zero" — the F-A class INVERTED: blindness is a STOP). Call site = TOP of the next metered gate (+ once at
  cohort enqueue), not after the prior write.
- **Failure asymmetry:** usage-WRITE failure = log-and-continue (a usage write must not crash a verdict);
  usage-READ failure at check = HALT. A missing row after a successful call = FINDING; a missing ledger at check =
  HALT. The engine ships the script (`scripts/cost-guard.sh`) + the EMPTY caps slot
  (`contracts/COST-CAPS.md`); the working cap numbers are the adopter operator's, never the engine's.

## 3. The set member = a permanent-record MANIFEST (multi-substrate)
A member is not merely a git diff; it is a lane's **declaration of every change it wants to make
permanent, across ALL substrates** — git paths + intended DB writes + Make blueprint changes + WP
records + "whatever record becomes permanent." The assessment (§1 A+B) checks that WHOLE declared
footprint. Surface-specific WRITE mechanisms (SP-INSERT=0/`run_sql`/wp-provisioner/make-deploy) stay,
but each apply/publish/deploy REFERENCES the ratified set that authorized it (Canon §4 apply-boundary).
**Forward-compat (do now, spine build):** the member schema (`PENDING-SET.md` / `pending-set.sh
member`) is an EXTENSIBLE permanent-record manifest — git today, admits DB/Make/WP declarations later
without redesign; U4B checks "declared-effect vs {structure, spec}" generically per substrate.

## 4. The spine is the system-of-record; foundation documents declared effects for future checks
A non-git permanent change is APPLIED on its own substrate, but its authorized declaration is
DOCUMENTED as a permanent spine record by FOUNDATION (U7). The spine is the single, complete,
checkable ledger of authorized cross-substrate changes, so a FUTURE assessment checks a new proposal
against prior authorized state (coherence: no conflict with a prior authorized change — detectable
only if both are in one place; conformance: consistent with spec-history). **Generalizes an existing
pattern:** a DB migration is applied to Azure SQL but its apply-receipt is documented in the spine
ledger — extend the same to Make/WP/etc.

## 5. The check-reference — structure-of-record for EVERY system
Foundation holds, in the spine, **current + checkable**, per system: **{ config · objects · MODEL
(relationships/constraints) · domain invariants }**, to check declared changes for issues. **Secrets
never enter the record** (tokens/WP-auth/API keys/operator-private stay in custody; IP/leak-lens).

The per-system structure-of-record is a UNIFORM schema — for EACH external system a requirement may
write to, foundation records **{ config · objects · MODEL · domain invariants }**, refreshed-from-live
and checkable at check-time:
- **config** — grants / auth modes / environment / connection identity (secrets excluded — custody-only).
- **objects** — the concrete named entities (e.g. tables/columns/types/indexes/views; automation
  scenarios/modules/connections; content types/taxonomy/meta; functions/triggers/contracts), with
  signatures and closed-set memberships.
- **MODEL** — relationships + cardinalities + keys + constraint closed-sets a declared change is checked
  against.
- **domain invariants** — the system's own binding rules (e.g. a write-path/least-privilege invariant, a
  sproc-only contract, a live-data-only rule) that a member's declared effect must not violate.

*(An adopter fills ONE such record per system it operates — a database · an automation/integration
platform · a CMS · a serverless runtime · a low-code platform · the git spine itself. The
source-program instance examples that illustrated each system are stripped at leak-lens; the
adopter re-illustrates from its OWN systems. The git-spine self-record is generic: `SPINE_PATHS` census,
the closed path-exemption set, lane/branch topology, hook install+currency, the ratification-packet
schema.)*

**Cross-cutting (all systems):** CURRENCY — refreshed-from-live, provably-current or live-verified at
check-time; a stale-record check gives a false verdict (DISC-CORPUS-IS-MEMORY / SUBSTRATE-OVER-UI),
never trusted blindly. CUSTODY — executor reads live (sole reader), foundation documents in spine (U7),
secrets excluded. COMPLETENESS is fail-closed — a missing structure-of-record is a BLIND CHECK and
must HALT-LOUD (can't check what isn't on record); this keeps "the blanks" filled without operator
dictation.

## 6. Definition of Done (the operator's `--by` gate)
The `--by` attaches ONLY to a demonstration that is:
- **A — REAL LANES:** `module/a` + `executor` **mandatory**; `module/b`/`module/c`
  additional ("possibly") — each submits a real proposal to foundation. No stub `resolve-lane`, no
  `/tmp` throwaway, no synthetic members.
- **B — REAL SUBSTRATE, no fake data:** through the canonical pipeline (invariant #1 LIVE-DATA-ONLY).
- **C — BOTH POLARITIES LIVE:** a real accept (`--by`→reap) AND a real reject (a real lane's real
  out-of-set / non-conforming commit), each observed live against the installed gate.
- **D — PROVENANCE TRAVELS:** receipt records real branch/commit/packet SHAs; a synthetic self-test
  proves only the synthetic case (DISC-PROBE-INPUT-PROVENANCE) — retained as a fast regression, never
  the operator's evidence.

## 7. Sequencing (the bootstrap law — proven in the source program, rule-stated)
**SPINE FIRST** — complete git-spine enforcement (§2 a/b/c + §6) before extending set-authorization to
other substrates. **Full per-substrate multi-substrate BUILD is BANKED (a later phase)**; the §4a
manifest + §5 structure-of-record FRAMEWORK/schema-hooks land NOW (pre-install), inside the
spine-first build. Spine completion order (**corrected bootstrap** — build lands as normal foundation
commits BEFORE the gate arms; a pre-commit hook does not retroactively reject historical commits):
currency-verify → forced merge-path → U4B → §4a manifest → §5 framework (foundation build complete,
each item assessed) → **INSTALL** (machinery is exempt — no ratified set is needed to install the
gate itself; the gate does not retroactively reject the historical build commits) → **[executor] §5
live-refresh** of the external systems (sole live reader) → **[executor] §6 biting-proof** (both
polarities per gate, real multi-lane) → assemble + operator **`--by`** ratifies the covering set →
reap. **§5-before-§6 semantics (ruled):** "§5 complete before §6" = the executor's live-READS FILED
(exempt receipts), NOT the foundation re-stamp — the SoR re-stamp to `LIVE-VERIFIED` is a
`contracts/` write, GATED, so it rides the covering set (lands at `--by`); the §6 git-spine biting
proof (D3·M6(i)·M6(ii)·U4B·U5) does NOT depend on the SoR being LIVE-VERIFIED (that currency gates
ONLY cross-substrate effect checks). No deadlock. (A currency-header exemption was DECLINED: keep
the exemption set minimal/operator-owned.) A NEW `scripts/`/`agents/` commit after install needs a
ratified set (all build edits land pre-install).

## 8. Custody + tracked residuals + the open operator door
(The source program's live build/status narrative is redacted at packaging — this section keeps the
model's durable content: who holds which pen, what is honestly still open, and the one question that
belongs to the operator.)
- **Custody (settled):** architect authors specs/rulings (own branch) + adjudicates; foundation is
  orchestrator + sole spine committer + set-determiner + scribe-of-record; executor live-proves + is
  the sole live reader (apply-receipts-only spine output); lanes are single-writer to their own
  branch. U4B criteria-integrity is STRUCTURAL (`_ratification/` ∈ SPINE_PATHS → D3 module-DENY
  blocks a member forging its own criteria; only foundation authors them, sourced from the architect
  WP).
- **Tracked residuals (disclosed, non-blocking):** the ff-merge structural bar (§2b —
  server-side/pre-push; the pre-merge-commit hook itself is a tracked-forward re-source in this
  engine, §2 honest-label) · U4B criteria↔architect-WP binding is procedural today (foundation
  transcribes from the dispatched WP) — harden by content-hash-in-packet if criteria authorship ever
  leaves foundation.
- **Open operator door (ONE):** spine-write-not-in-a-spec — every spine write in exactly one bucket
  (ratified-member · enumerated-exempt incl. the packet itself + ledger/decision-log machinery ·
  controlled break-glass). Is the CLOSED path-exemption list COMPLETE, and do you want an explicit
  break-glass? Default if none: an emergency spine write is an expedited single-member set with your
  `--by` (logged, fail-closed, no hole).

---

## 9. Provenance — the round-trip (DISCHARGED at this packaging)
Operator: *"once this is completed and tested, it needs to be then documented what was done here and
sent to gmaa"* + *"i am referring to all of the set related updates."* That return is the delivery
this document arrived in — DISCHARGED 2026-08-19:
- **The arc:** the set-gate was lifted FROM this engine (frozen `7a17926`) by the source program;
  built out (`pending-set.sh`/`ratify.sh`/M6(i)/M6(ii)), flow-validated (§1), hardened to
  ALL-ENFORCED with the WIRE fix (§2), extended with the manifest / system-of-record /
  check-reference (§3–5), proven biting on real multi-lane data (§6 DoD, both polarities, live
  installed gates) — then RE-SOURCED back whole at the source's enforced HEAD for packaging.
- **What the engine carries = the GENERIC architecture + methodology** (the packaging program owns
  packaging; the source program owns + authored the hardening). NOT the source realization: its
  leak-lens strip (identity, business specifics, instance ids) was applied by its integrator at the
  DMZ; the packaging arm applied the SEMANTIC layer (lane-name bijection, rule-stating, build-history
  redaction) at this fold. The methodology writeup ships at `export/EXPORT-set-authorization.md`.
- **Nothing was sent before the DoD passed** (no-fake-closures) — the biting proof completed in the
  source program before release.

## Change-log
- **GMAA packaging fold (2026-08-19):** genericized at the re-source into the engine — source lane
  names → the generic census (foundation / module-a… / executor), ruling/turn numbers → rule-stated,
  the source program's live build/status narrative (§7/§8/change-log instance detail) redacted to the
  model's durable content, source-program leak lens = 0. §2 WIRE column restated as THIS ENGINE's shipped,
  probe-backed state: FOOTPRINT + HUNT shipped + FLIP-proven (standing probes #6/#7); COST brake
  shipped (`scripts/cost-guard.sh`) + EMPTY caps slot (`contracts/COST-CAPS.md`); pre-merge-commit
  hook + metered call site honest-labeled (not shipped / adopter-wired). Mechanism bytes verbatim.
- **v0.11:** operator ENGINE-LAW encoded — *fail-closed SLOTS, not smarter inference; an unreadable
  property (intent · meaning · sampled telemetry · unfilled slot) never PASSes; the gate reads
  STRUCTURE, a human / non-empty integrator slot carries JUDGMENT.* FOUR fixes: **(§1 R2 → §2.2)**
  the anti-gaming ENFORCEMENT GAP CLOSED via footprint-coverage (declared
  `requirement_id`/`footprint.lanes` + dispatch-minted `set_id` + assemble
  `assembled_lanes ⊇ footprint.lanes` HALT; `UNDECLARED-OCCUPANT` edge for extras); **(§2.3)**
  joint-edge becomes 3-layer — mechanical (A) + `SHARED-RECORD` SoR-index class (B) + a REQUIRED
  `SEMANTIC HUNT` slot (C) that REFUSES on UNABLE/missing/CLEAR-with-zero-no-method, with the
  packet-header "NONE ≠ coherent" wording; **(§2.4)** the cost-brake shape — `cost-guard.sh` reads
  the usage ledger, exit 2 over-cap / exit 3 unreadable both HALT; **(probe law)** every standing
  probe declares claim/pass_means/FLIP (name = claim; 0-rows-on-unproven-table = FAIL). Context: two
  sets closed end-to-end in the source program, both accept polarities empirical. Packaging
  correction (ruled): the return to the engine = re-source at origin HEAD, not patch-hunks;
  FOOTPRINT + HUNT land before the engine's set-auth seal.
- **v0.10:** TWO operator directives encoded. **(§0.10 → R2 REFRAMED):** a set's boundary is the
  REQUIREMENT, not lane-count/effort — single-lane (single-member) sets are VALID when only one lane
  has work (never hold a ready lane for unrelated lanes); a genuinely multi-lane requirement is ONE
  all-or-nothing set; foundation is BARRED from effort-splitting dispatch to shrink sets
  ("requirements not effort"). Flagged the anti-gaming ENFORCEMENT GAP (intent unreadable by the
  gate → needs spec-declared footprint + dispatch-time set-id + assemble-time coverage;
  convention-bound until wired — closed at v0.11). **(§0.11 → R4/U7):** FOUNDATION raises the
  authorization request + is SOLE writer of the set record; the architect assesses + adjudicates but
  does NOT solicit/carry the `--by` or write.
- **v0.9:** an instance least-privilege pare in the source program (evidence-gated, operator-gated
  apply) — instance narrative redacted at packaging; no model change.
- **v0.8:** two HOW-class rulings — **(1)** the §7 sequencing knot: "§5 complete before §6" relaxed
  to the executor's live-READS FILED (exempt receipts), NOT the foundation re-stamp (the re-stamp is
  a gated `contracts/` write and rides the covering set; no deadlock; the currency-header exemption
  DECLINED — keep the exemption set minimal/operator-owned). **(2)** a §5 record↔live delta ruled
  correct-the-record + evidence-gate-the-pare (instance detail redacted).
- **v0.7:** **GATE ARMED** in the source program — M6(i) + pre-merge-commit installed
  (independently verified byte-identical, shared hook dir → live on all lanes; source history —
  the pre-merge-commit hook bytes are NOT SHIPPED in this engine, §2 U6 row). WITHDREW the interim
  `merge.ff=false` ff-belt (it does not compose with the strict sentinel-only hook — it would route
  a routine trunk fast-forward sync into the reject path); the ff-residual stays tracked-forward for
  the STRUCTURAL pre-push/server-side bar only.
- **v0.6:** foundation build complete + assessed in the source program — U4B gate fail-closed /
  non-overridable / every-member-PASS with FAIL≻JUDGMENT≻PASS precedence + absent-criteria HALT
  (§2.1 corollary); criteria-integrity STRUCTURAL (D3 module-DENY on `_ratification/`); §4a
  extensible + backward-compatible; §5 checker enforces completeness/currency/secrets-never with
  HONEST currency.
- **v0.5:** forced merge-path assessed PASS (raw merge into trunk REJECTED; `--no-ff --no-commit`
  reap not blocked; sentinel allowed; no message-based escape). Fast-forward residual disclosed as
  tracked-forward. §7 reconciled to the corrected bootstrap order (build-all-then-install).
- **v0.4:** added §9 — on DoD pass, package the WHOLE set arc back to the engine (generic +
  leak-lens-stripped). Adjudicated the bootstrap sequence: operator `--by` comes AFTER the live
  biting proof (machinery exempt → install is not exemption-blocked).
- **v0.3:** added §2.1 — the U4B conformance mechanism (structured/judgment verdict, fail-closed
  non-overridable gate, per-member recorded in the packet, WPs carry checkable acceptance criteria).
- **v0.2:** added §L — the model is SUBORDINATE to standing law (evidence-first + invariants +
  disciplines); it does not preclude them.
- **v0.1:** initial consolidation (supersedes the source program's dated amendment stream; this file
  is the source-of-truth).
