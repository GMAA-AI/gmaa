<!-- GENERIC-ENGINE NOTE: this schema cites origin authority documents (docs/BUILD_ARCHITECTURE.md, docs/EXECUTION_PLAN.md,
     docs/PROTOCOL.md, docs/UAT.md) that are NOT shipped in the generic engine. Where cited, the section text below stands on its own;
     an adopter that keeps such documents restores the pointers. -->
# Receipt Schema

# GENERICIZATION NOTE: Stripped external-platform instance refs (SQL PaaS, external-API orchestrator, canvas platform), real SP/app names, ruling-doc cites, live dates. Seat/role/worker tokens renamed per §2 rename map. DB/tool slot markers added where adopter must supply their own stack.

**Authority:** `docs/BUILD_ARCHITECTURE.md` §4.3 (verbatim shape) + §8 ("the receipt ledger is the single source of truth for what is done"); `docs/EXECUTION_PLAN.md` §3 (verification spine).

## The receipt is the unit of trust

Every Ring-1 / Ring-2 / Ring-3 verification pass emits one receipt. Receipts are append-only to `ledger/receipts.jsonl`. Never edited after write — corrections are NEW receipts that reference the prior `receipt_id`.

## JSON-line shape (one receipt per line in ledger/receipts.jsonl)

```json
{
  "receipt_id": "R-<YYYYMMDDTHHMMSSZ>-<seq>",
  "wp_id": "<work-package id from schema/work-package.md>",
  "case_id": "<optional; UAT cases set this; harness/contract receipts null>",
  "verification_ring": 0 | 1 | 2 | 3,
  "ring0": {
    "tools_run": {"<tool_name>": <exit_code>, ...},
    "all_pass": true | false,
    "notes": "<optional; e.g., 'py_compile + ruff + mypy for Python artifact; sql_parse for SQL artifact'>"
  },
  "artifact_paths": ["<repo-relative path>", ...],
  "probe_path": "<repo-relative path to committed re-runnable probe>",
  "probe_last_run_at_utc": "<ISO 8601 UTC>",
  "probe_exit_code": 0 | <int>,
  "probe_output_summary": "<short; full output captured at probes/<scope>/<timestamp>.txt>",
  "probe_output_hash": "<sha256 of probe output file>",
  "git_commit": "<commit sha at probe-run time; PENDING_COMMIT if pre-commit>",
  "auditor_status": "PENDING" | "REPRODUCED" | "DIVERGED" | "WAIVED",
  "auditor_run_at_utc": "<ISO 8601 or null>",
  "auditor_notes": "<text or null>",
  "rework_attempt": 0 | <int>,
  "supersedes_receipt_id": "<prior receipt_id this receipt supersedes, or null>",
  "timestamp": "<ISO 8601 UTC; when receipt was emitted>",
  "actor": "executor | architect | code-auditor | track-lead-X | build-worker | dispatch-executor | migration-runner | external-deploy | operator"
}
```

### Ring 0 block — required (per `schema/verification.md` §1 + §8.5)

The `ring0` block is **mandatory**. A worker MAY NOT emit a receipt for an artifact failing Ring 0 (i.e., `ring0.all_pass = false` is grounds for self-healing rework per `schema/state-machine.md` §Self-healing-backward-edges, NOT receipt emission for a clean state).

The block records per-tool exit codes. Adopters supply their own static-check toolchain; common examples:
- **Python artifacts:** `{"py_compile": 0, "ruff": 0, "mypy": 0}` (worker runs all 3; any non-zero → rework).
- **SQL artifacts:** `{"sql_parse": 0}` (worker runs syntactic parse-validation; e.g., dry-run or sqlfluff).
- **External-API integration artifacts:** `{"schema_validate": 0}` (worker validates shape against published schema).
- **Bash/shell scripts:** `{"shellcheck": 0, "bash_n": 0}` (shellcheck + `bash -n` syntactic check).
- **Markdown/contract docs:** `{"markdown_parse": 0}` (light parse-validation; no link-check by default).

`ring0.all_pass = true` ⇔ every tool returned exit 0. Receipts with `all_pass = false` are rejected at emission time by worker discipline (rework loops back per `schema/state-machine.md` §Self-healing-backward-edges).

### rework_attempt + supersedes_receipt_id (BOUNDED RETRY)

- `rework_attempt = 0` for the first emission of a WP's receipt. Incremented on each backward-edge rework (probe fail / Ring 0 fail / Auditor DIVERGED).
- `supersedes_receipt_id` = the prior `receipt_id` this receipt supersedes (when reworking after a fail). The prior receipt stays in the ledger (rule 4 — append-only); this field marks the supersede chain.
- On `rework_attempt = 3+` → executor HALTS self-looping this WP + logs to `_escalations/NNN.md` per `docs/PROTOCOL.md` §2.2 BOUNDED-RETRY guard (`schema/verification.md` §8.4).

## Verification rings

| Ring | Scope | Allowed inputs | Mechanism |
|---|---|---|---|
| **1 — Unit** | Per work package | Fixtures / test doubles permitted | Adopter-supplied unit test runner (pytest, T-SQL harness, API mock, etc.) |
| **2 — Contract conformance** | Per subsystem | Live environment, read-only probes | Per-object existence + grant probes; API shape assertions; data-source binding assertions |
| **3 — Live-data integration** | Canonical path end-to-end | **Live data only — no hand-INSERT** | One real entity walked through research → approval → promotion → publish → verified external state |

## Acceptance function (bifurcated per architecture pin — v1.3)

```
CLOSED              ⇔ receipt_exists ∧ probe_exit_0 ∧ ring0_all_pass ∧ auditor_REPRODUCED
CLOSED-PROVISIONAL  ⇔ receipt_exists ∧ probe_exit_0 ∧ ring0_all_pass ∧ auditor_WAIVED (live-surface; honest admission)
                                                                       ∧ operator-spot-audit-owed
```

CLOSED-PROVISIONAL → CLOSED requires operator-spot-audit REPRODUCED per `schema/state-machine.md` §States row CLOSED-PROVISIONAL.

No exceptions. Documentation-only closures rejected by construction (`state-machine.md` explicit NO `IN_PROGRESS → CLOSED` edge). **The prior `auditor_concurs` shorthand (which historically read as "REPRODUCED OR WAIVED+freshness") is WITHDRAWN** as a fake-closure backdoor per `schema/verification.md` §4.1 — WAIVED on live-surface licenses CLOSED-PROVISIONAL only; never plain CLOSED. The 24h freshness window guards staleness, not independence.

## Probe-guard rule (universal; verbatim from `docs/BUILD_ARCHITECTURE.md` §4.2)

Every claim of "applied / done / live / verified" **must cite a committed, re-runnable probe by path**. If no probe is cited, the claim is downgraded to "asserted — NOT verified" and the work package does **not** close.

- **Per-object assertions only.** Named existence checks for each target object.
- **Aggregate proofs are forbidden.** Never `COUNT(*) FROM <catalog>`. An aggregate cannot distinguish *missing X* from *surplus Y*.
- **GRANT proofs are per-object** rows from the access-control catalog, filtered to the expected grantee.
- Probes live at versioned paths (`probes/<scope>/probe_<name>_<v>.<ext>`), are runtime-credential-safe, and are committed in the same change as the artifact they verify.

## Boundary caveat (from prior existence-check-ambiguity surface)

Existence-check functions may return a null-equivalent for BOTH "absent" AND "no permission" from non-owner runtime contexts. Probes that test existence from a restricted runtime context must differentiate: query the catalog directly AND check the access-control table for the expected grantee. If a probe surfaces ambiguity, the receipt records `WAIVED` with explicit notes; an owner-context cross-check probe is filed as a follow-up WP.

## Receipt rules (binding)

1. **Append-only.** Never edit a receipt; corrections are NEW receipts.
2. **Probe-cited.** Every receipt has a `probe_path` resolving to a committed file.
3. **Output-hashed.** The `probe_output_hash` is the sha256 of the committed output file; the Auditor re-runs the probe, hashes the output, and compares.
4. **Worker-emitted.** The worker that does the WP emits the receipt. Auditor never emits; only sets `auditor_status` + `auditor_run_at_utc` + `auditor_notes` via a NEW receipt that supersedes (cite prior receipt_id) — never via in-place edit.
5. **Failing receipts reopen WPs.** `probe_exit_code != 0` → WP `AWAITING_RECEIPT → REOPENED` (never `CLOSED`).
6. **Diverged receipts reopen WPs.** `auditor_status = DIVERGED` → WP `VERIFIED → REOPENED`.
7. **WAIVED is CLOSED-PROVISIONAL only** (per architecture pin v1.3 amendment). Auditor can WAIVE Ring-2/3 receipts where Auditor cannot reach the live surface (file-state-scope boundary per `agents/auditor-contract.md` §Interim-cover); WAIVED on live-surface licenses **CLOSED-PROVISIONAL** (not plain CLOSED) and routes the WP to operator-spot-audit per `schema/verification.md` §4.2. The prior "WAIVED licenses CLOSED if probe is freshness-window-current (24h)" rule is **WITHDRAWN** as a fake-closure backdoor — freshness guards staleness, not independence. CLOSED-PROVISIONAL → CLOSED only via operator-spot-audit REPRODUCED.

## ID convention

`receipt_id = R-<YYYYMMDDTHHMMSSZ>-<seq>` where `seq` is a 3-digit zero-padded counter within the same second. Append-only file order = receipt order = chronological order; no reordering.
