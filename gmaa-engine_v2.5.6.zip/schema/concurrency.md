<!-- GENERIC-ENGINE NOTE: this schema cites origin authority documents (docs/BUILD_ARCHITECTURE.md, docs/EXECUTION_PLAN.md,
     docs/PROTOCOL.md, docs/UAT.md) that are NOT shipped in the generic engine. Where cited, the section text below stands on its own;
     an adopter that keeps such documents restores the pointers. -->
# Parallel-Worker Concurrency Ceiling — Claude Code Environment

# GENERICIZATION NOTE: Stripped external-platform instance refs, ruling-doc cites, live-pointer dates, real SHA/date. Seat/worker tokens renamed per §2 rename map. §5 initial empirical measurement date stripped (was a live pointer); generic "fresh-repo standup" phrasing kept.

**Authority:** `docs/BUILD_ARCHITECTURE.md` §6 Phase 1 ("concurrency bounded only by the Claude Code agent limit") + §9 parallelism summary; `docs/EXECUTION_PLAN.md` §6 immediate frontier ("executor characterizes the actual concurrency ceiling").

## §1 — Two ceilings

**Per-message tool-batch ceiling** — independent tool calls in a single executor message are run concurrently by the harness. Observed comfortable range: **4-8 parallel calls per message**. Beyond ~8 the output volume + token-budget pressure on the executor thread degrades; sequential output streaming becomes the bottleneck.

**Standing-pool ceiling** — the `Agent` tool can spawn N subagents per message. Each subagent has its own context budget. Observed: 1 background agent at a time in prior operation (canvas-monitor audit class). Per role-card guard: "Spawn multiple dispatch-executor subagents in parallel without operator approval" is forbidden by executor role definition — dispatch-executor-class concurrency = 1 by policy.

## §2 — Working ceiling by phase

| Phase | Worker class | Practical max concurrent | Source |
|---|---|---|---|
| **Phase 0** | executor + architect (async via repo) + operator (touchpoints) | 3 (serial-with-parallel-reads) | BUILD_ARCH §9 ("3 waves, low") |
| **Phase 1** | 6 Track Leads (A/B/C/D/E/F) | 4 in flight per executor dispatch wave (2 wait per wave) | empirical executor-side estimate |
| **Phase 1** | Ephemeral workers within a Track Lead | unverified; assume 1 (Track Lead serializes its own WPs) — revise upward if empirical observation supports | conservative default |
| **Phase 2 (UAT)** | UAT case runners (5 journeys × ~5-10 cases + invariant suites) | 4 parallel UAT cases per executor dispatch wave | BUILD_ARCH §9 ("mostly sequential, 2 overlap points") |
| **Phase 3** | operator (single touchpoint) | 1 | BUILD_ARCH §5.1 + EXECUTION_PLAN §5 |
| **Phase 4** | additive tracks (measurement / multi-integration / extension / niche spin-up) | TBD; characterize when Phase 4 starts | BUILD_ARCH §9 |

## §3 — Operating cadence (steady state in Phase 1)

Per `docs/EXECUTION_PLAN.md` §7 operating loop step 3 ("Fan the frontier out to track leads / ephemeral workers, up to the characterized concurrency ceiling"):

- Executor computes the frontier each loop iteration.
- Executor dispatches up to N (per §2 above) workers in parallel within a single tool-batch message.
- Workers run independently; each emits artifact + receipt; executor collects receipts as they land.
- Executor never blocks the loop on a single worker — the frontier-recompute happens whenever any worker lands its receipt.
- Steady-state pattern: 4 workers in flight → 1 lands → frontier recomputed → 1 new worker dispatched → 4 in flight again.

## §4 — Recharacterization triggers

Update this file when:
- Empirical observation increases or decreases the practical ceiling (e.g., a 6-worker batch consistently times out → revise down).
- Harness changes (new Agent subagent support; new background-spawn semantics; new tool-batch limits).
- A specific WP class proves to have higher resource needs than baseline (e.g., a UAT journey that takes 5x normal wall-clock).

Recharacterizations log via NEW WP (`WP-OPS-CONCURRENCY-CHARACTERIZE-vN`) + appended here as §5+; never silently edited.

## §5 — Initial empirical measurement (P0.1)

Initial bound established at fresh-repo standup from observed executor tool-batch behavior in the parts-bin: 4-8 parallel calls per message worked routinely; spawning multiple subagents in parallel was not exercised. Phase 1 ceiling set conservatively at 4 per executor dispatch wave with empirical revision triggered by first-saturation observation.
