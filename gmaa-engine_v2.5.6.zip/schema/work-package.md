<!-- GENERIC-ENGINE NOTE: this schema cites origin authority documents (docs/BUILD_ARCHITECTURE.md, docs/EXECUTION_PLAN.md,
     docs/PROTOCOL.md, docs/UAT.md) that are NOT shipped in the generic engine. Where cited, the section text below stands on its own;
     an adopter that keeps such documents restores the pointers. -->
# Work-Package Schema

# GENERICIZATION NOTE: Stripped external-platform instance refs, ruling-doc cites, live dates, site-specific WP naming examples. Seat/role/worker tokens renamed per §2 rename map. Specialist deploy class labels neutralized to generic names. WP naming convention section rewritten to generic track/kind pattern; adopter extends per their own phase decomposition.

**Authority:** `docs/BUILD_ARCHITECTURE.md` §4.4 + §6 (Phase plan with WP table); `docs/EXECUTION_PLAN.md` §4 phase enumeration.

## Per-WP file format

A work package lives at `work-packages/<wp_id>.md` and has this shape:

```markdown
# WP <wp_id> — <one-line title>

| Field | Value |
|---|---|
| wp_id | <wp_id; globally unique; e.g., P0.1, WP-A-MIG-100, WP-B-GATE-G4> |
| track | <harness | contract | verification-spine | substrate-remediation | A | B | C | D | E | F | uat | live-fire | measurement | reconciliation> |
| phase | 0 | 1 | 2 | 3 | 4 |
| state | OPEN | IN_PROGRESS | AWAITING_RECEIPT | VERIFIED | CLOSED | REOPENED |
| branch | wp/<wp_id-kebab-cased> (per `schema/state-machine.md` branch discipline; one-to-one) — exception: P0.1 genesis WP uses `(genesis; no branch)` |
| dependencies | [<wp_id>, ...]  (other WPs that must be CLOSED before this WP's state can transition OPEN → IN_PROGRESS) |
| worker | executor | architect | code-auditor | track-lead-{X} | build-worker | dispatch-executor | migration-runner | external-deploy | operator |
| created_at | <ISO 8601 UTC> |
| state_history | <append-only list of (from_state, to_state, ts, actor, reason_or_receipt_id) tuples> |

## Acceptance

<bullet list of acceptance criteria — what receipt(s) license CLOSED>

## Artifacts

<file paths produced by this WP (relative to repo root); annotate each>

## Receipts

<list of receipt_ids in ledger/receipts.jsonl for this WP; append-only>

## Body

<the actual content of the work — design decisions, results, evidence>

## Escalation log

<append-only record of STOP-AND-SURFACE events, six-tier self-resolution exhausts, contract-ambiguity routings>

## §Self-probe

<how the receipt's probe verifies this WP's acceptance criteria; what an Auditor reproduces>
```

## Naming convention

- `P0.<n>` — Phase 0 work packages (per EXECUTION_PLAN §4 Phase 0 table). `P0.1` through `P0.6` + `P0.C` (live-infra characterize) + `P0.X` (substrate close).
- `WP-{TRACK}-{KIND}-{seq}` — Phase 1+ work packages. Examples: `WP-A-MIG-0001` (Track A substrate migration), `WP-B-GATE-<name>` (Track B gate worker), `WP-C-SCREEN-<name>` (Track C screen), `WP-D-FLOW-<name>` (Track D), `WP-E-INTEGRATION-<name>` (Track E integration), `WP-F-PROVISION-<name>` (Track F provisioning). Adopter defines their own track letters and kind labels.
- `WP-UAT-J{n}-{case}` — Phase 2 UAT cases.
- `WP-PHASE-3-{n}` — Phase 3.

## Owner conventions

- **Executor** owns the DAG + ledger + frontier + dispatch + escalation routing. Does NOT execute domain work in Phase 1+ — dispatches to track leads.
- **Architect** owns contracts (Phase 0 P0.3 + P0.6) + contract-ambiguity rulings (escalations). Does NOT execute work packages.
- **Track Lead** owns track decomposition + Ring-2 verification + worker integration.
- **Build-Worker (ephemeral)** owns one work package: produces artifact + emits receipt + terminates.
- **Code-Auditor** independently reproduces every Ring-2/3 probe; observe-and-report only; never authors or fixes.
- **Specialist deploy class** runs deploy actions under service-account credentials (migration-runner / external-deploy, etc.).
- **Operator** four touchpoints only per `docs/EXECUTION_PLAN.md` §5 (repo standup [DONE on this commit], substrate tail, account creation as-needed, first-live-entity go/no-go).

## Reference

- State transitions: `schema/state-machine.md` (explicit NO `IN_PROGRESS → CLOSED` edge).
- Receipt shape: `schema/receipt.md`.
- Verification rings: `schema/verification.md`.
- Concurrency: `schema/concurrency.md`.
