<!-- GENERIC-ENGINE NOTE: this schema cites origin authority documents (docs/BUILD_ARCHITECTURE.md, docs/EXECUTION_PLAN.md,
     docs/PROTOCOL.md, docs/UAT.md) that are NOT shipped in the generic engine. Where cited, the section text below stands on its own;
     an adopter that keeps such documents restores the pointers. -->
# Work-Package State Machine

# GENERICIZATION NOTE: Stripped external-platform instance refs and live-pointer dates. Seat/role/worker tokens renamed per §2 rename map. References to docs/ authority retained verbatim (adopter fills those docs).

**Authority:** `docs/BUILD_ARCHITECTURE.md` §4.4 verbatim ("there is no edge from IN_PROGRESS to CLOSED"); `docs/EXECUTION_PLAN.md` §1 ("no IN_PROGRESS → CLOSED edge") + §7 (operating loop).

## States

| State | Meaning | Entry condition | Exit transitions (legal) |
|---|---|---|---|
| **OPEN** | Authored, dependencies not yet all CLOSED OR awaiting worker dispatch | WP created in `work-packages/`; appears in `dag/DAG.yaml` | → `IN_PROGRESS` (executor dispatches; all deps CLOSED + worker available) |
| **IN_PROGRESS** | A worker is actively executing (initial OR rework loop per `schema/verification.md` §8.3 SELF-HEALING) | Worker starts (initial dispatch from OPEN, OR self-healing backward-edge from AWAITING_RECEIPT/VERIFIED on probe-fail/Auditor-DIVERGED per §8.3) | → `AWAITING_RECEIPT` (worker emits artifact + receipt with probe result) · → `_escalated_` (worker STOP-AND-SURFACE; cadence §2.1 binding-class) |
| **AWAITING_RECEIPT** | Probe has run; receipt landed; awaiting Auditor reproduction | Receipt appended to `ledger/receipts.jsonl` with `probe_exit_code` set; `auditor_status = PENDING` | → `VERIFIED` (probe_exit_code = 0 AND ring0 block all-PASS) · → `IN_PROGRESS` (REWORK; probe_exit_code != 0 OR ring0 block any-FAIL; self-healing per §8.3; rework-attempt count incremented) |
| **VERIFIED** | Probe passed; awaiting independent Auditor reproduction | Worker self-verification PASS | → `CLOSED` (Auditor `REPRODUCED`; merge-to-main) · → `CLOSED-PROVISIONAL` (Auditor `WAIVED` primary on live-surface probe; merge-to-main + operator-spot-audit owed per `schema/verification.md` §4.2) · → `IN_PROGRESS` (REWORK; Auditor `DIVERGED`; self-healing per §8.3; rework-attempt count incremented) |
| **CLOSED** | Acceptance complete + Auditor REPRODUCED + merged to main | Merge to main per §Branch-discipline; Auditor REPRODUCED gates the merge | (terminal; never transitions out — post-CLOSED issues become NEW WPs forward-queued) |
| **CLOSED-PROVISIONAL** | Acceptance via worker self-attestation; Auditor WAIVED live-surface primary verdict; **independent verification OWED to operator spot-audit** (per `schema/verification.md` §4.1 + §4.2; architecture pin) | Merge to main when Auditor primary verdict = WAIVED on a live-surface probe + `_escalations/NNN.md` routed to operator spot-audit queue | → `CLOSED` (operator-spot-audit REPRODUCED) · → `IN_PROGRESS` (operator-spot-audit DIVERGED; rework backward-edge per §Self-healing-backward-edges) |

## Forbidden edges

- **`IN_PROGRESS → CLOSED` is FORBIDDEN.** Verbatim from `docs/BUILD_ARCHITECTURE.md` §4.4: *"A package cannot close on a worker's assertion of 'PASS'; only a green, auditor-reproduced receipt closes it. Documentation-only closures and 'all PASS' without receipts are rejected by construction."*
- **`OPEN → VERIFIED` is FORBIDDEN.** Must traverse `IN_PROGRESS → AWAITING_RECEIPT → VERIFIED`.
- **`VERIFIED → CLOSED` without Auditor REPRODUCED is FORBIDDEN.** The Auditor's independent probe reproduction (REPRODUCED) is the close gate for plain CLOSED. WAIVED PRIMARY on a live-surface probe transitions to `CLOSED-PROVISIONAL` (NOT plain CLOSED) per architecture pin; operator-spot-audit REPRODUCED is required to transition CLOSED-PROVISIONAL → CLOSED.
- **`CLOSED-PROVISIONAL → CLOSED` without operator-spot-audit REPRODUCED is FORBIDDEN.** WAIVED-licenses-plain-CLOSED is the fake-closure backdoor the discipline forbids per `schema/verification.md` §4.1.
- **In-place receipt editing is FORBIDDEN** (per `schema/receipt.md` rule 1). Corrections are new receipts citing the prior `receipt_id`.

## Self-healing backward edges (per `schema/verification.md` §8.3)

Failed audit is **normal flow**, NOT exception. Two backward edges to `IN_PROGRESS` are legal + expected as the rework loop:

- **`AWAITING_RECEIPT → IN_PROGRESS`** — probe failed (`probe_exit_code != 0`) OR Ring 0 block any-FAIL. Worker reworks on same branch; appends new receipt on next attempt.
- **`VERIFIED → IN_PROGRESS`** — Auditor `DIVERGED` on reproduction. Worker reworks on same branch.

In both cases:
- The receipt with the FAIL stays in `ledger/receipts.jsonl` as a tracked fact (rule 4 — never edit).
- The WP's `state_history` records the backward-edge transition with a rework-attempt counter increment.
- Executor dispatches the correction immediately + autonomously (no operator surface per cadence §2.1; not binding-class).
- For shared-pattern defects: executor propagates the corrective commit to sibling WPs on their own branches — siblings REWORK, do NOT freeze.
- The build never stops. The frontier stays non-empty per `.claude/agents/orc.md` (operating loop).

**BOUNDED RETRY guard:** rework-attempt count tracked in WP `state_history`. On attempt 3+ failing in a row, executor HALTS self-looping this WP + logs to `_escalations/NNN.md` per `docs/PROTOCOL.md` §2.2 LOG-AND-CONTINUE (other WPs unaffected; this WP is the escalation-blocked one only).

## Branch discipline (per `docs/PROTOCOL.md` §1 addendum)

- **Genesis commit only:** The P0.1 scaffold itself lands on `main` as the repo-genesis commit. No worker branch is required for repo genesis (the scaffold IS the operating model standing itself up).
- **Every work package after genesis → own branch `wp/<package-id>`.** Worker commits there exclusively. Direct commits to `main` for a WP-class artifact are forbidden by discipline.
- **Branch ↔ work-package ID ↔ DAG node ↔ receipt: one-to-one.** The branch name encodes the WP ID. The first receipt for that WP cites the branch's HEAD commit (`git_commit` field in the receipt). The DAG node's `branch` field (added to `schema/work-package.md`) records the branch name.
- **Merge-to-`main` IS the `VERIFIED → {CLOSED | CLOSED-PROVISIONAL}` transition.** Mechanics:
  1. Worker emits artifact + receipt on `wp/<package-id>` branch (state: `AWAITING_RECEIPT`).
  2. Probe runs; if `probe_exit_code = 0` → state `VERIFIED` on the branch.
  3. Auditor reproduces (independent session re-runs probe on branch HEAD); verdict determines close-state per architecture pin:
     - `auditor_status = REPRODUCED` → executor opens PR / fast-forward merge to `main`; WP transitions `VERIFIED → CLOSED`.
     - `auditor_status = WAIVED` on a live-surface probe (Auditor structurally cannot reach the live surface; honest admission per `agents/auditor-contract.md` §Interim-cover) → executor merges to `main`; WP transitions `VERIFIED → CLOSED-PROVISIONAL`; operator-spot-audit owed per `schema/verification.md` §4.2 (route to `_escalations/` or operator-spot-audit queue).
     - `auditor_status = DIVERGED` → WP backward-edge `VERIFIED → IN_PROGRESS` (self-healing rework loop per §Self-healing-backward-edges); never merge.
     - **The prior "(or `WAIVED` + freshness met)" rule licensing plain CLOSED is WITHDRAWN** (freshness window guards staleness, not independence).
  4. The merge commit IS the `VERIFIED → {CLOSED | CLOSED-PROVISIONAL}` transition; the WP state updates after merge lands on `main`.
  5. `main` holds verified-closed (CLOSED + CLOSED-PROVISIONAL) work only; no in-flight WPs visible there.
- **Branch lifecycle:** `wp/<package-id>` deleted post-merge (history preserved in merge commit).
- **REOPENED handling:** If a WP is REOPENED (probe fail, Auditor diverge, STOP-AND-SURFACE), the branch stays open; new commits land on the branch; new receipts append to `ledger/receipts.jsonl` (which itself lives on the branch until merge — append-only, no edits to prior lines).
- **Genesis-class exception (P0.1 only):** the scaffold receipt is emitted on the genesis commit's `main` (no branch); `wp/P0_1.md` records this with `branch: (genesis; no branch)`.

## State-transition record

Every transition appends to the WP's `state_history` block as a tuple:

```
(<from_state>, <to_state>, <iso8601_utc>, <actor>, <reason_or_receipt_id>)
```

- `actor` per `schema/work-package.md` enumeration.
- `reason_or_receipt_id` = a `receipt_id` for AWAITING_RECEIPT / VERIFIED / CLOSED transitions; a short reason for OPEN / IN_PROGRESS / REOPENED transitions.

## Frontier computation (per `docs/EXECUTION_PLAN.md` §7 operating loop step 2)

The **frontier** = set of WPs satisfying ALL:
- State is `OPEN`.
- Every dependency in the WP's `dependencies` list is in state `CLOSED`.

Executor computes frontier each loop iteration; dispatches up to the concurrency ceiling (`schema/concurrency.md`).

The frontier NEVER includes:
- WPs in `IN_PROGRESS / AWAITING_RECEIPT / VERIFIED / CLOSED / REOPENED` (already in flight or terminal).
- WPs with any dep in any state other than `CLOSED`.

## STOP-AND-SURFACE per operating loop step 7 + escalation table

A worker that hits a halt MUST:
1. Transition the WP `IN_PROGRESS → REOPENED`.
2. Append a STOP-AND-SURFACE entry to the WP's "Escalation log".
3. Run six-tier self-resolution per `docs/PROTOCOL.md` (contract → doc → schema → probe → parts-bin → forward-queue).
4. If unresolved after all 6 tiers, log to `_escalations/NNN.md` (operator-batched to architect at discretion).

Routing per `docs/BUILD_ARCHITECTURE.md` §7 escalation table:
- **Contract ambiguity** → `_escalations/` (architect ruling).
- **Verification failure** (probe_exit_code != 0; Auditor DIVERGED) → reopen the WP; NEVER edit the receipt.
- **Irreversible action** (destructive migration; first publish; CREATE PROCEDURE-class permission grant) → operator-touchpoint queue.
- **Out-of-scope discovery** → NEW work package (forward-queue; DAG append-only for scope); never silent expansion.
- **Live state ≠ contract** → live state wins; surface; contract or build corrected; never paraphrased.

Never best-effort past a halt. Never silently widen scope. Never edit a receipt.
