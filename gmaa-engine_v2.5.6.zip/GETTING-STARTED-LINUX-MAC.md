# Getting Started: Linux and Mac
**Setting up on a Linux or Mac machine. A Windows and WSL guide ships in a future release.**

This walks you from a blank machine to a completed adoption, assuming you have never used a terminal. The adoption runs in four phases (see `ADOPTION-COVER.md`): assessment and design happen **in chat**, implementation happens **in Claude Code**. If you **already have Claude Code installed, skip straight to Step 5.**

## What you need before starting
- A Linux machine with a POSIX shell, or a Mac (macOS 13 or later)
- A Claude account with a paid plan (Pro, Max, Team, or Enterprise). Sign up at claude.ai if needed.
- All the files that came with this package (unzip it somewhere you can find)

## Step 1: Check whether Claude Code is already installed
1. Open your terminal. **Linux:** open your terminal app. **Mac:** press **Cmd + Space**, type **Terminal**, press **Enter**.
2. Type exactly `claude --version` and press **Enter**.
3. If you see a version number (like `2.x.x`) you have it. **Skip to Step 5.**
4. If you see `command not found`, continue to Step 2.

## Step 2: Install Claude Code
1. In the same terminal, copy and paste this single line, then press **Enter**:
   ```
   curl -fsSL https://claude.ai/install.sh | bash
   ```
2. Wait for it to finish (a minute or two on a normal connection). No password should be needed.
3. **Quit the terminal completely and reopen it.** This is required so it finds the new command.
4. Type `claude --version` and press **Enter**. A version number means success. If not, type `claude doctor` and follow what it says, or see Troubleshooting.

**Also install tmux** (fleet sessions, needed when you operate after adopting). **Linux:** `sudo apt install tmux` (or your distro's package manager). **Mac:** `brew install tmux`. Confirm with `tmux -V` and `git --version`.

## Step 3: Sign in once
1. Type `claude` and press **Enter**.
2. First launch walks you through setup. Pick a theme (any), and when it asks about signing in, choose your **Claude account**. A browser window opens; sign in and approve.
3. Type `/exit` and press **Enter**. The real launch comes later, in Phase 4.

## Step 4: Create the project folder (Phase 0)
1. Create the folder your project will live in, at your code root. Name it **lowercase, with no spaces**. This becomes your git repository name. **This folder is the PARENT:** the engine lives in `<folder>/foundation/` (created next), and every further lane will be a sibling worktree `<folder>/<lane>` (folder equals lane; `main` is a branch, never a folder name).
2. Create `foundation/` inside it and unzip the engine zip **into `foundation/`** (if `unzip` is not installed, which is common on a fresh WSL Ubuntu, use `python3 -c "import zipfile,sys; zipfile.ZipFile(sys.argv[1]).extractall('.')" gmaa-engine_<version>.zip`). Everything travels in the zip: the canon under `canon/`, `ADOPTION-COVER.md`, `CLAUDE.md`, the machinery. The loose files beside the zip in the release (`README.md`, `LICENSE.md`, the specification PDF, `SHA256SUMS`) are the public face; copy `README.md` and `LICENSE.md` in beside the engine if you want them in the project folder. Every worktree carries its own `scripts/` + `launch-orc.sh` (spine paths, propagated by currency-sync, never hand-copied); updates land on the spine by foundation then propagate per lane (`scripts/lane_currency_gate.sh` + per-lane HEAD readback).
3. Run the substrate-floor check from `foundation/`: `bash scripts/preflight.sh` (Claude Code CLI, git, tmux; it provisions nothing and halts loud on any miss).

## Step 5: Run Phases 1 through 3 (choose your surface)  *(skip-to point if you already had Claude Code)*
1. Read `ADOPTION-COVER.md` yourself first. It is one page, and it explains the four phases and which decisions are yours.
   **The chat path below is the recommended route.** The session that assesses and records your decisions stays separate from the one that implements them. (Work solely in the terminal? A Code-only alternative exists, described in the cover, but if you are unsure, use the chat path.) Continuing here:
2. In a chat session (a Claude project works well), upload the **architecture document** (`canon/`), the **cover**, and, if your project is already thought out, your project's spec. Ask:
   > *Read `GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1_PUBLIC.md` and `ADOPTION-COVER.md`. Is GMAA a good fit for this project? Assess only. Do not implement anything yet.*
3. The chat states which architect role it is assuming and gives you a fit assessment. **If you decide to adopt, say so explicitly.** Nothing proceeds until you do (Phase 2).
4. Work through your three decisions in conversation (invariants, auth paths, who ratifies), and have the chat write your two decision-complete fills: **`docs/FOUNDATION.md`** and **`seats.yaml`**.
5. **Download `docs/FOUNDATION.md` and `seats.yaml` and drop them into the project folder** from Step 4.

## Step 6: Launch the implementation (Phase 4)
1. In the terminal, type `cd ` (c, d, one space; do not press Enter), drag the project folder onto the terminal window, and press **Enter**.
2. Make the launcher and scripts executable (once, before first launch): `chmod +x launch-orc.sh scripts/*.sh scripts/test/*.sh`
3. Start the instantiation in a **plain** Claude session (not the launcher): type `claude` and press **Enter**. The first instantiation uses vanilla Claude, because the launcher boots a seat that must already resolve its lane from the worktree, so on an un-instantiated project it would halt. Give the session:
   ```
   Read docs/FOUNDATION.md and seats.yaml and instantiate this project per canon §12.
   Layout: this folder is the parent; git init inside <parent>/foundation/ (the engine files
   live there, checked out to main); every further lane is a sibling worktree <parent>/<lane>
   via git worktree add.
   ```
4. It verifies the fills and stands up the **two initial lanes**, `foundation` (the integrator) and `executor` (the first worker), the minimum governed census of two. Each lane's worktree folder is named for the lane and checked out to its branch (folder equals lane; `main` is a branch, never a folder name). It generates the governance files, then provisions any further lanes from `seats.yaml`. If it halts naming a missing decision, that is it working correctly. Go settle the decision. Do not work around the halt.
5. **Install the two git hooks** (once per repository; hooks are not versioned, so the package ships installers): `bash scripts/install_pre_commit_hook.sh && bash scripts/install_post_commit_hook.sh`. The pre-commit hook IS the spine-write boundary; the post-commit hook is the auditor. Without them there is no gate, only prose. The launcher halts if the pre-commit hook is missing.
6. **Now** operate the seats with the launcher: from inside a lane's worktree folder, run `./launch-orc.sh` to boot that seat. Watch for `BOOT-ACK: ...` and the `BOOT-CHECK: ...` line; that first turn is the only launch proof.
7. **The `[set SET-NNNN]` message convention (advisory):** once the set-gate is live, a foundation commit covered by a ratified set MAY carry `[set SET-NNNN]` in its commit message so readers can trace coverage at a glance. It is a post-commit-verified CONVENTION, never the gate - enforcement is STRUCTURAL, by path, in the pre-commit hook (a well-formed message cannot forge coverage; CLAUDE.md invariant #6).

## Step 7: The proof (do not skip)
Run the seeded-fault test (canon §12 step 8) with the agent. It plants a deliberate conflict, and the machinery must detect, name, hold, and recover it. **A clean run proves nothing.** Note what was seeded and whether it was caught.

## Upgrading (later)
Foundation runs the engine update; see `docs/ENGINE-UPDATE.md`.

## Step 8: Feedback (welcome)
`ADOPTION-COVER.md` lists what is most useful to send to arch@gmaa.ai, above all every place you or the AI had to guess.

## Troubleshooting
- **`command not found` after installing:** you did not reopen the terminal (Step 2.3). Or run `claude doctor`.
- **`permission denied` running the launcher:** you skipped the chmod step; run `chmod +x launch-orc.sh scripts/*.sh scripts/test/*.sh`, then `./launch-orc.sh`.
- **`HALT: project-token resolution failed` or `not in a git worktree` on launch:** the folder is not an instantiated repository yet. The launcher only boots a seat that already resolves its lane from a committed `_boot/` stamp inside a git worktree. Finish Step 6 (instantiation with a plain `claude` session) first.
- **`HALT: pre-commit hook not installed`:** run the two installers in Step 6.5.
- **The launcher says the fills are not there yet:** this is not an error. Finish the chat phases and drop `docs/FOUNDATION.md` and `seats.yaml` in, or take the Code-only path in the cover.
- **Install seems blocked:** on company-managed Macs, security policy may interfere. Ask IT, or see the official docs.
- **Never want to touch a terminal?** The Claude Desktop app includes Claude Code without the terminal (claude.com/download). The chat phases already run in chat by design.
- Official install docs: https://code.claude.com/docs/en/setup
