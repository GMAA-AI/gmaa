# PENDING-SET.md — the ratified-but-uncommitted change set, made visible

# GENERICIZATION NOTE: the mechanism (the MAINTENANCE binding law + the set-evaluation-at-every-apply-boundary
# receipt line + the row schema) is kept verbatim from origin — this is canon §4, shipped whole. The origin's
# LIVE business rows are stripped to an empty ledger carrying only the column schema + one commented example.
# Owner lane renamed to the generic census (foundation); ruling citations are rule-stated ({{RULING}}).
# This file is SPINE-OWNED (foundation is the sole writer; a module lane staging it is REJECTED by
# agents/pre-commit-hook.sh). Genesis (launch-orc.sh, foundation lane) creates this header if absent.

**Owner:** foundation (spine, single-writer, receipt-committed). **Authority:** operator ruling {{RULING}} — finding of first rank: *serialized transport hides the set; it does not dissolve it. Members are each ratified alone; joint evaluation has never run.*

**PURPOSE:** one row per change that is RATIFIED but NOT yet committed/applied to the system of record. The set made visible — the artifact whose absence the thesis names. Per-change review (auditor, ratification checkpoints) stays; the set gate is added ON TOP OF it, at the spine boundary — never instead of it.

**MAINTENANCE (binding):**
- Every future ratification **ADDS** its row in the SAME commit that registers the ruling.
- Every apply/commit **REMOVES** its row with the receipt.
- **SET-EVALUATION AT EVERY APPLY BOUNDARY (standing):** before ANY member commits/applies, the committing seat re-reads this FULL ledger and answers IN ITS RECEIPT: `member N evaluated against the set {…}: joint edges = <list|NONE>`. A named joint edge **HALTS for ratification of the PAIR/SET**, not just the member. Not a formality — it converts per-change review into set-relative review at the boundary the thesis names.
- **Cost guard:** this ledger is one file; the evaluation is one paragraph per apply. If it exceeds that it has become ceremony — FLAG it, don't endure it. It does NOT gate authoring work anywhere — only commits/applies to the system of record.
- **Milestone/SITTING windows are SET-RATIFICATION events:** the operator packet presents LEDGER STATE + joint edges + grounded options (sequence/scope/hold/substitute/reject); the operator ratifies the SET, not batched per-change approvals.

---

## THE SET

One row per pending change (ratified-but-not-yet-committed/applied). Written by foundation only
(`scripts/pending-set.sh reap`); read by any seat (`scripts/pending-set.sh list`).

| # | member id | lane | branch@sha-range | surfaces touched | status |
|---|---|---|---|---|---|
<!-- example row (delete when seeding real members):
| 1 | wp_042 | module/example | example@abc1234..def5678 | scripts/foo.sh, docs/BAR.md | pending |
-->

**Status vocabulary (closed set):** `pending` · `evaluated` (assembled into a set packet) · `ratified-in SET-NNNN` · `committed` · `RETURNED` (VERIFIED→RETURNED per C-RATIFICATION-PACKET §3; branch preserved, re-enters only inside a future ratified set — NO-CHERRY-PICK).

## SET-IDENTITY (requirement_id → minted set_id + footprint; REQ-FOOTPRINT, C-SET-AUTHORIZATION §2.2)

Foundation mints the ONE `set_id` for a `requirement_id` at dispatch (`scripts/pending-set.sh mint
<requirement_id> --footprint-lanes 'a,b'`), transcribing the architect spec's FOOTPRINT block
(architect-owned; the gate reads STRUCTURE, never intent). Every WP + `SET-MEMBER-*.md` for that
requirement carries this `set_id`. `scripts/ratify.sh assemble` reads `footprint.lanes` from here and
enforces `assembled_lanes ⊇ footprint.lanes` (a missing required lane → `FOOTPRINT-MISS` HALT; an extra lane
→ `UNDECLARED-OCCUPANT` joint edge). A 2nd member of the same requirement under a DIFFERENT `set_id` → reap
HALT (the stagger). Single-lane footprints stay legal (coverage vacuous + valid). Mint is idempotent per
requirement; a footprint change is REFUSED (re-author the spec, never a silent re-mint).

| requirement_id | set_id | footprint.lanes | footprint.substrates | exclusive | minted-at |
|---|---|---|---|---|---|
<!-- | <REQ-ID> | SET-NNNN | <lane-a,lane-b> | <substrate> | true | <UTC> | -->

## APPLY LOG (rows removed with receipts, per MAINTENANCE)

One line per member removed at its apply/commit boundary, carrying the set-evaluation receipt line verbatim:
`member N evaluated against the set {…}: joint edges = <list|NONE>`.

## JOINT EDGES (a floor, not a ceiling)

Pre-named joint edges for a set are a floor, not a ceiling. The assembler's mechanical detection
(`scripts/ratify.sh assemble`) covers Layer A — overlapping paths across members, shared unforkable
artifacts (a spine-owned path / migration slot / a file another member reads by declared dependency),
and declared-dependency cycles — plus Layer B (`SHARED-RECORD`: the same structure-of-record id cited
by two members via DIFFERENT files) and the footprint edges (`UNDECLARED-OCCUPANT` ·
`UNDECLARED-SUBSTRATE`; C-SET-AUTHORIZATION §2.2/§2.3). This detection is **field-proven, not
proven-complete (canon §13)**: a joint edge outside those classes (e.g. two contradicting prose
sentences) is carried by the packet's REQUIRED `## SEMANTIC HUNT` slot (§2.3 Layer C — a MERGE
decision REFUSES on a missing/UNABLE hunt) + INTEGRATOR ASSESSMENT, never a silent PASS.
