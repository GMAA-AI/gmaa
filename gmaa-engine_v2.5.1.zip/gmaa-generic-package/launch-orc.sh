#!/bin/bash
# launch-orc.sh — fleet seat launcher (deposit one copy in each worktree root)
# bash-3.2 compatible (macOS /bin/bash): case-based folder map, no associative arrays.
#
# GENERICIZATION NOTE: the folder→lane map is genericized to FOLDER-EQUALS-LANE (lane = folder
# name; only the integrator's `main` folder maps to `foundation`), matching resolve-lane.sh. The
# MODE-NOTE incident specifics are stripped to the mechanism-of-record only.
#
# Lane resolution (in order):
#   1. _boot/BOOTSTRAP.md lane=…   (authoritative when present)
#   2. folder→lane case map below  (folder-equals-lane by default)
#   3. HALT-LOUD                   (never silently guess a session name)
# Session name = lane id (REQUIRED for doorbell R1 resolution).
#
# Usage:
#   ./launch-orc.sh                 launch this worktree's seat and ATTACH
#   ./launch-orc.sh --detach        launch headless (attach later: tmux attach -t <lane>)
#   ./launch-orc.sh --btab N        after settle delay, send N Shift+Tab (BTab) keystrokes (default 0)
#   ./launch-orc.sh --no-mode-flag  omit the mode flag (now the DEFAULT)
#   ./launch-orc.sh --auto-mode     opt into --permission-mode auto (classifier ON; test posture)
#
# MODE NOTE (mechanism of record): a pinned `--permission-mode auto` CLI flag OVERRIDES
# settings.json `defaultMode`, silently re-enabling the auto-mode classifier on every
# launcher-spawned seat and defeating a fleet-wide `defaultMode: default`. DEFAULT IS NOW ``
# (no flag) → settings.json `defaultMode: default` governs: the allow+deny list decides, no
# false-positive classifier drip. Opt into the test posture with `--auto-mode`. ALWAYS verify
# OBSERVED mode via /status; observed (not requested) mode is the boot receipt.

set -eu

# ---------- config ----------
CLAUDE_CMD="claude --agent orc"     # command of record
MODE_FLAG=""                        # default: settings.json-governed (default mode); --auto-mode opts into the classifier
SETTLE_SECS=8
# ----------------------------

# ---------- genesis: session_state (v2.5.1 ruled delta) ----------
# Five engine surfaces insist on .claude/session_state.json (the freshness gate exits STALE when
# it is missing; the executor protocol writes it; a standing probe ages it; CHARTER-foundation
# declares it, arming orc's HARD GUARD) -- but a fresh blank-copy tree has no writer yet: origin's
# file always pre-existed its checks. Presence-triggered genesis: create the minimal file at first
# launch; never overwrite. Local-only (covered by .gitignore `.claude/*`).
if [ ! -f ".claude/session_state.json" ]; then
  mkdir -p .claude
  printf '{"in_flight_iter": null}\n' > .claude/session_state.json
  echo "GENESIS: created .claude/session_state.json"
fi

# folder→lane map — folder-equals-lane by default; only the integrator differs (folder `main` → `foundation`).
# EDIT HERE only if a worktree folder name ≠ its lane id.
folder_to_lane() {
  case "$1" in
    main|foundation) echo "foundation" ;;
    *)               echo "$1" ;;   # folder-equals-lane: the folder name IS the lane id
  esac
}

ATTACH=1
BTAB_COUNT=0
while [ $# -gt 0 ]; do
  case "$1" in
    --attach)        ATTACH=1; shift ;;
    --detach)        ATTACH=0; shift ;;
    --btab)          BTAB_COUNT="${2:?--btab needs a count}"; shift 2 ;;
    --no-mode-flag)  MODE_FLAG=""; shift ;;                          # now the default; kept for compatibility
    --auto-mode)     MODE_FLAG="--permission-mode auto"; shift ;;    # opt into the classifier test posture
    *) echo "HALT: unknown arg '$1'" >&2; exit 2 ;;
  esac
done

# --- resolve worktree dir + folder ---
WT_DIR="$(cd "$(dirname "$0")" && pwd)"
FOLDER="$(basename "$WT_DIR")"

# --- lane resolution: _boot first, folder map second, halt third ---
LANE=""
LANE_SOURCE=""
BOOT_LANE=""
BOOT_FILE="$WT_DIR/_boot/BOOTSTRAP.md"
if [ -f "$BOOT_FILE" ]; then
  BOOT_LANE="$(grep -Eo 'lane=[A-Za-z0-9_-]+' "$BOOT_FILE" 2>/dev/null | head -1 | cut -d= -f2 || true)"
  if [ -n "$BOOT_LANE" ]; then
    LANE="$BOOT_LANE"
    LANE_SOURCE="_boot/BOOTSTRAP.md"
  fi
fi
MAP_LANE="$(folder_to_lane "$FOLDER")"
if [ -z "$LANE" ] && [ -n "$MAP_LANE" ]; then
  LANE="$MAP_LANE"
  LANE_SOURCE="folder map ($FOLDER)"
fi
if [ -z "$LANE" ]; then
  echo "HALT: cannot resolve lane for folder '$FOLDER'." >&2
  echo "      No _boot/BOOTSTRAP.md lane= line, and folder not resolvable." >&2
  exit 1
fi

# --- cross-check: if BOTH sources exist, they must agree (halt-loud) ---
if [ -n "$BOOT_LANE" ] && [ -n "$MAP_LANE" ] && [ "$BOOT_LANE" != "$MAP_LANE" ]; then
  echo "HALT: lane mismatch — _boot says '$BOOT_LANE', folder map says '$MAP_LANE'" >&2
  echo "      for folder '$FOLDER'. Resolve before launch (session name MUST" >&2
  echo "      equal lane id, doorbell R1)." >&2
  exit 1
fi

# --- refuse double-launch (exact-match session name) ---
if tmux has-session -t "=$LANE" 2>/dev/null; then
  echo "HALT: tmux session '$LANE' already exists. Not launching a second seat." >&2
  echo "      Attach with: tmux attach -t $LANE" >&2
  exit 1
fi

# --- launch: detached session, cwd = worktree, then send the claude line ---
if [ -n "$MODE_FLAG" ]; then
  LAUNCH_LINE="$CLAUDE_CMD $MODE_FLAG"
else
  LAUNCH_LINE="$CLAUDE_CMD"
fi
tmux new-session -d -s "$LANE" -c "$WT_DIR"
sleep 1   # let the pane's shell initialize before keys arrive
tmux send-keys -t "$LANE" "$LAUNCH_LINE" C-m

# --- optional mode-cycle keystrokes (default 0) ---
if [ "$BTAB_COUNT" -gt 0 ]; then
  sleep "$SETTLE_SECS"
  i=0
  while [ "$i" -lt "$BTAB_COUNT" ]; do
    tmux send-keys -t "$LANE" BTab
    sleep 1
    i=$((i+1))
  done
fi

# --- receipt (observed facts only) ---
echo "== launch receipt =="
echo "lane/session : $LANE"
echo "lane source  : $LANE_SOURCE"
echo "folder       : $FOLDER"
echo "worktree     : $WT_DIR"
echo "launch line  : $LAUNCH_LINE"
echo "btab sent    : $BTAB_COUNT"
if [ "$ATTACH" -eq 1 ]; then
  echo "verify next  : attaching now → /status → confirm OBSERVED mode;"
else
  echo "verify next  : tmux attach -t $LANE  → /status → confirm OBSERVED mode;"
fi
echo "               one Shift+Tab if auto didn't take."
echo "===================="

[ "$ATTACH" -eq 1 ] && exec tmux attach -t "$LANE"
exit 0
