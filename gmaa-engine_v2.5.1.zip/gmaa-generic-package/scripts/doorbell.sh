#!/usr/bin/env bash
# scripts/doorbell.sh — SPEC-DOORBELL wrapper. tmux = BELL, git inbox = TRANSPORT.
# The integrator rings a lane so it takes a turn → its first-action INBOX-CHECK fires now (vs next
# operator spawn). Payload is NEVER here — it lives in the durable inbox
# (_orchestration/relay-inbox/<lane>/). A dropped bell DELAYS, never LOSES.
#
# GENERICIZATION NOTE: unchanged mechanism; instance lane examples (site lanes) replaced with the
# neutral {{MODULE_LANE}} placeholder. Session-name == lane is the resolve key (folder-equals-lane).
#
#   doorbell.sh ring <lane>          R1 resolve + R2 two-phase send + R3 fail-loud + R5 fixed token + submit-verify
#   doorbell.sh ack  <lane> <ref>    R4: poll the lane's outbox for a NEW surface since <ref> (consume-ack); HALT-LOUD on none
#
# R1 IMPL NOTE: the live pane_title is dynamically overwritten by Claude Code (e.g. "✳ Orc <LANE>") —
# NOT the stable `<lane>` token R1 assumed. The SESSION_NAME (== lane, folder-equals-lane) is the clean,
# unique key, so R1 resolves by session_name (pane_title corroborates). Exactly-one match required → else HALT.
set -u

WAKE_TOKEN='🔔 DOORBELL — take a turn now: run `scripts/inbox.sh` as your FIRST action, consume any new inbound, then proceed/report. (This is the bell only; your payload is in your git inbox.)'

resolve_target() {  # echoes "session:win.pane|pane_title" for exactly-one session_name==<lane>, else nonzero
    local lane="$1" out n                              # bash-3.2-safe (no mapfile)
    out="$(tmux list-panes -a -F '#{session_name}:#{window_index}.#{pane_index}|#{session_name}|#{pane_title}' 2>/dev/null \
        | awk -F'|' -v L="$lane" 'tolower($2)==tolower(L){print $1"|"$3}')"
    n="$(printf '%s\n' "$out" | grep -c .)"
    if [[ "$n" -ne 1 ]]; then
        echo "HALT(doorbell): lane='$lane' resolved to $n tmux pane(s) (need exactly 1)." >&2
        [[ "$n" -gt 0 ]] && printf '  candidate: %s\n' "$out" >&2
        echo "  (is the lane relaunched as a named tmux session? \`tmux ls\`)" >&2
        return 2
    fi
    printf '%s' "$out"
}

cmd_ring() {
    local lane="${1:?usage: doorbell.sh ring <lane>}" res target title pre post
    res="$(resolve_target "$lane")" || exit 2          # R3: fail-loud, non-zero, named reason
    target="${res%%|*}"; title="${res#*|}"
    echo "[doorbell] lane=$lane → target=$target (pane_title='$title')"
    local pre_sum post_sum                              # robust: cksum of full pane (any change = submitted)
    pre_sum="$(tmux capture-pane -p -t "$target" 2>/dev/null | cksum)"
    # R2: TWO-PHASE — literal text, THEN Enter as a SEPARATE call (chaining swallows the submit).
    tmux send-keys -t "$target" -l "$WAKE_TOKEN" || { echo "HALT(doorbell): send-keys -l failed ($target)" >&2; exit 2; }
    sleep 0.5
    tmux send-keys -t "$target" Enter            || { echo "HALT(doorbell): send-keys Enter failed ($target)" >&2; exit 2; }
    sleep 1.2
    post="$(tmux capture-pane -p -t "$target" 2>/dev/null | tail -15)"; post_sum="$(tmux capture-pane -p -t "$target" 2>/dev/null | cksum)"
    # submit-verify: Claude busy-indicator OR ANY pane change (cksum) vs pre-send.
    if echo "$post" | grep -qiE 'esc to interrupt|Running|Searching|Thinking|tokens|⏵|✶|✳' || [[ "$pre_sum" != "$post_sum" ]]; then
        echo "[doorbell] rang $lane — submit VERIFIED (pane changed / busy indicator). R4 ack pending: \`doorbell.sh ack $lane <ref>\`."
        return 0
    fi
    # Double-Enter Protocol (text may sit un-submitted): one more Enter, re-check.
    tmux send-keys -t "$target" Enter; sleep 1.2
    post_sum="$(tmux capture-pane -p -t "$target" 2>/dev/null | cksum)"
    if [[ "$pre_sum" != "$post_sum" ]]; then
        echo "[doorbell] rang $lane — submit VERIFIED after Double-Enter. R4 ack pending."
        return 0
    fi
    echo "HALT(doorbell): rang $lane but submit UNCONFIRMED after Double-Enter (pane unchanged) — do NOT assume delivery." >&2
    exit 3
}

cmd_ack() {  # R4: the bell is 'done' only when the lane's outbox shows a NEW surface (consume-ack) since <ref>.
    local lane="${1:?usage: doorbell.sh ack <lane> <ref-sha>}" ref="${2:?need a baseline ref}"
    git fetch -q origin "module/$lane" 2>/dev/null || true
    local new; new="$(git rev-list --count "${ref}..origin/module/$lane" 2>/dev/null || echo 0)"
    if [[ "${new:-0}" -gt 0 ]]; then
        echo "[doorbell] ACK: $lane advanced $new commit(s) since $ref → consume-ack landed (bell done)."; return 0
    fi
    echo "HALT(doorbell): rang $lane, NO consume-ack since $ref (outbox unchanged) — do NOT assume delivery." >&2
    exit 3
}

case "${1:-}" in
    ring) shift; cmd_ring "$@" ;;
    ack)  shift; cmd_ack  "$@" ;;
    *) echo "usage: doorbell.sh {ring <lane> | ack <lane> <ref-sha>}" >&2; exit 1 ;;
esac
