#!/usr/bin/env bash
# scripts/orc-up.sh — bring an orc lane up in two words.
# Fail-closed bootstrap check → named tmux session at the lane worktree → `claude --agent orc` → @orc reminder.
# Run from any worktree in the repo. Operator alias: orc-up.
#
# GENERICIZATION NOTE: the hardcoded instance-lane validation list is dropped in favour of
# FOLDER-EQUALS-LANE — any lane is accepted; the fail-closed worktree + _boot existence guard
# below is what actually validates it (a lane with no committed charter cannot launch).
set -u

lane="${1:?usage: orc-up.sh <lane>   (folder-equals-lane: e.g. foundation, executor, module-a)}"

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "orc-up: not in a git worktree" >&2; exit 2; }
PARENT="$(dirname "$REPO_ROOT")"
# Convention: the integrator (foundation) lives in the `main` folder; every other lane's folder == its lane id.
if [[ "$lane" == "foundation" ]]; then wt="$PARENT/main"; else wt="$PARENT/$lane"; fi

# FAIL-CLOSED: charter-precedes-boot. The charter + bootstrap MUST be present before launch, else the
# orc would boot personaless / HALT. This guard is the shortcut's promise that it can't reintroduce an
# unconstrained boot.
[[ -d "$wt" ]]                        || { echo "orc-up: HALT — worktree '$wt' does not exist" >&2; exit 3; }
[[ -f "$wt/_boot/BOOTSTRAP.md" ]]     || { echo "orc-up: HALT — $wt/_boot/BOOTSTRAP.md missing (charter-precedes-boot not satisfied)" >&2; exit 3; }
[[ -f "$wt/_boot/CHARTER-$lane.md" ]] || { echo "orc-up: HALT — $wt/_boot/CHARTER-$lane.md missing" >&2; exit 3; }

# Already up? attach to it.
if tmux has-session -t "$lane" 2>/dev/null; then
  echo "orc-up: session '$lane' already live — attaching."
  exec tmux attach -t "$lane"
fi

# Create detached session at the lane worktree, launch the orc (two-phase submit — chaining swallows it),
# then attach so the operator lands in it.
tmux new-session -d -s "$lane" -c "$wt" || { echo "orc-up: tmux new-session failed" >&2; exit 2; }
tmux send-keys -t "$lane" -l "claude --agent orc"
sleep 0.4
tmux send-keys -t "$lane" C-m
echo "orc-up: launched '$lane' orc at $wt."
echo "  REMINDER: first message to the orc must begin '@orc' (spawn precondition) — then confirm 'BOOT-ACK: lane=$lane'."
echo "  Attaching…"
exec tmux attach -t "$lane"
