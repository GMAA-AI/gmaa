#!/bin/bash
# launch-orc.sh — fleet seat launcher (deposit one copy in each worktree root)
# bash-3.2 compatible (macOS /bin/bash), no associative arrays.
#
# Lane resolution: the target worktree's _boot/BOOTSTRAP.md stamp, read by scripts/resolve-lane.sh run in
# that worktree. No stamp, or a stamp the resolver refuses => HALT-LOUD (never guess a name).
# Session name = <project>-<lane> (`project:` is stamped in _boot/BOOTSTRAP.md, read by
# scripts/resolve-project.sh, which HALTs if absent; no bare-name fallback here, only in doorbell.sh).
# The session runs scripts/seat-loop.sh: `restart` relaunches, anything else ends it.
#
# Usage:
#   ./launch-orc.sh                 launch this worktree's seat and ATTACH
#                                    (the session appears as your window,
#                                    same as launching by hand)
#   ./launch-orc.sh --detach        launch headless (no window; attach later
#                                    with: tmux attach -t <lane>)
#   ./launch-orc.sh --btab N        after settle delay, send N Shift+Tab
#                                    (BTab) keystrokes (default 0; verify
#                                    observed mode with /status regardless)
#   ./launch-orc.sh --no-mode-flag  omit the mode flag (now the DEFAULT)
#   ./launch-orc.sh --auto-mode     opt into --permission-mode auto (classifier ON; test posture)
#
# MODE NOTE (mechanism of record — UPDATED 2026-07-13, operator directive):
# The launcher previously PINNED `--permission-mode auto` (a test posture to force
# the auto-mode classifier on). That CLI flag OVERRIDES settings.json defaultMode,
# so it silently re-enabled the classifier on every launcher-spawned seat and
# defeated the fleet's `defaultMode: default` (settings.json). It was the root
# cause of a seat's persistent classifier fire block that a restart could not clear
# (the completeness probe). DEFAULT IS NOW `` (no flag) →
# settings.json `defaultMode: default` governs: the allow+deny list decides,
# no false-positive classifier drip. Opt back into the test posture with
# `--auto-mode`. ALWAYS verify OBSERVED mode via /status; observed (not
# requested) mode is the boot receipt.
#
# ONE RESOLVER: the lane and the per-seat launch line are resolved by the two
# functions below. scripts/seat-loop.sh SOURCES this file (the guard after the functions returns before any
# launcher code runs) and calls the same functions at EVERY relaunch, so a stamp edited after the loop started
# (remote_control, account, boot prompt) reaches the next relaunch. No copy of this block exists elsewhere.
# The model tier is NOT a launcher value: it is the role's, set in the agent def's `model:` front matter, and the
# harness reads it at every launch. The launcher passes no --model.

# launch_lane_resolve <worktree> -> sets LL_LANE from the worktree's stamp via scripts/resolve-lane.sh run IN
# that worktree. rc 1 + the named reason in LL_ERR when the stamp is absent or refused.
launch_lane_resolve() {
  local wt="$1" line
  LL_LANE=""; LL_ERR=""
  if [ ! -f "$wt/_boot/BOOTSTRAP.md" ]; then
    LL_ERR="no _boot/BOOTSTRAP.md in '$wt'"; return 1
  fi
  line="$(cd "$wt" && bash "$wt/scripts/resolve-lane.sh" 2>/dev/null)" || {
    LL_ERR="scripts/resolve-lane.sh refused the stamp in '$wt'"; return 1; }
  LL_LANE="$(printf '%s\n' "$line" | sed -nE 's/^lane=([A-Za-z0-9_-]+)( .*)?$/\1/p' | head -1)"
  [ -n "$LL_LANE" ] || { LL_ERR="resolve-lane.sh printed no lane= field in '$wt'"; return 1; }
}

# launch_line_resolve <worktree> <lane> <session> <mode-flag|""> -> sets LL_ARGV (the argv to exec), LL_LINE (the
# same line as one shell string, the boot prompt single-quoted), LL_RC_NOTE and LL_ACCOUNT_NOTE. rc 1 + the named
# reason in LL_ERR when the stamp cannot be read (an absent remote_control or account field is legal: not requested,
# and the default account respectively).
launch_line_resolve() {
  local wt="$1" lane="$2" session="$3" mode="$4" prompt="" rcv rcrc acctrc acctdir
  LL_ERR=""
  # Default seat = role-neutral orc (foundation/exec/site-lanes). The architect is a DISTINCT agent def; each def
  # carries its own model tier, and BOOT-ACK prints the OBSERVED model.
  LL_ARGV=(claude --agent orc)
  if [ "$lane" = "architect" ]; then
    LL_ARGV=(claude --agent architect)
    # The architect's def initialPrompt does NOT auto-fire (only the primary orc def's does), so it is booted with
    # a positional prompt (single line, NO single-quotes/apostrophes: LL_LINE single-quotes it).
    prompt="Boot as @architect: read _boot/BOOTSTRAP.md (lane identity + load order) and .claude/agents/architect.md (your @architect def), ground from HEAD, emit BOOT-ACK: @architect charter=<def version> before any other work, then check inbound with scripts/inbox.sh (reads _orchestration/relay-inbox/architect/) and follow it."
  fi
  # Remote Control from the stamp: requested + configured, never observed "on".
  # resolve-project.sh --field: rc 0 = value, rc 1 = field absent (legal), anything else = unreadable stamp.
  rcrc=0; rcv="$(bash "$wt/scripts/resolve-project.sh" --field remote_control "$wt" 2>/dev/null)" || rcrc=$?
  case "$rcrc" in
    0|1) ;;
    *) LL_ERR="remote_control unreadable in '$wt/_boot/BOOTSTRAP.md' (resolve-project.sh rc=$rcrc)"; return 1 ;;
  esac
  LL_RC_NOTE="not requested (no remote_control: true in the stamp)"
  if [ "$rcrc" = 0 ] && [ "$rcv" = "true" ]; then
    LL_ARGV=("${LL_ARGV[@]}" --remote-control "$session")
    LL_RC_NOTE="requested $session (configured)"
  fi
  # Account from the stamp: per-seat routing data. resolve-project.sh --config-dir is the ONE
  # mapping (absent field = $HOME/.claude; `account: <a>` = $HOME/.claude-<a>; malformed or unprovisioned = HALT).
  # The env prefix goes on ONLY when the stamp carries `account:`, so an unstamped lane's line is unchanged.
  # No lane-based default: the architect lane implies no account.
  acctrc=0; bash "$wt/scripts/resolve-project.sh" --field account "$wt" >/dev/null 2>&1 || acctrc=$?
  case "$acctrc" in
    0|1) ;;
    *) LL_ERR="account unreadable in '$wt/_boot/BOOTSTRAP.md' (resolve-project.sh rc=$acctrc)"; return 1 ;;
  esac
  LL_ACCOUNT_NOTE="default (no account: field in the stamp)"
  if [ "$acctrc" = 0 ]; then
    acctdir="$(bash "$wt/scripts/resolve-project.sh" --config-dir "$wt" 2>&1)" || {
      LL_ERR="account in '$wt/_boot/BOOTSTRAP.md' refused: ${acctdir:-resolve-project.sh --config-dir gave no reason}"; return 1; }
    LL_ARGV=(env "CLAUDE_CONFIG_DIR=$acctdir" "${LL_ARGV[@]}")
    LL_ACCOUNT_NOTE="$(bash "$wt/scripts/resolve-project.sh" --field account "$wt") -> $acctdir (from the stamp)"
  fi
  [ -n "$mode" ] && LL_ARGV=("${LL_ARGV[@]}" $mode)
  LL_LINE="${LL_ARGV[*]}"
  if [ -n "$prompt" ]; then
    LL_ARGV=("${LL_ARGV[@]}" "$prompt")
    LL_LINE="$LL_LINE '$prompt'"
  fi
  return 0
}

# Sourced (by scripts/seat-loop.sh): stop here, before any launcher code runs or `set -eu` leaks into the caller.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then return 0; fi

set -eu

# ---------- config ----------
MODE_FLAG=""                        # default: settings.json-governed (default mode); --auto-mode opts into the classifier
SETTLE_SECS=8
# ----------------------------

ATTACH=1
BTAB_COUNT=0
while [ $# -gt 0 ]; do
  case "$1" in
    --attach)        ATTACH=1; shift ;;
    --detach)        ATTACH=0; shift ;;
    --btab)          BTAB_COUNT="${2:?--btab needs a count}"; shift 2 ;;
    --no-mode-flag)  MODE_FLAG=""; shift ;;                          # now the default; kept for compatibility
    --auto-mode)     MODE_FLAG="--permission-mode auto"; shift ;;    # opt into the old test posture (classifier ON)
    *) echo "HALT: unknown arg '$1'" >&2; exit 2 ;;
  esac
done

# --- resolve worktree dir + folder ---
WT_DIR="$(cd "$(dirname "$0")" && pwd)"
FOLDER="$(basename "$WT_DIR")"

# --- lane resolution: the target worktree's own stamp, through resolve-lane.sh run IN that worktree ---
# (window plan row 7). No folder->lane map, no alias, no fallback: identity comes from
# LOCATION (CLAUDE.md s0). A folder with no stamp, or a stamp that fails the resolver's location checks, HALTs.
LANE_SOURCE="_boot/BOOTSTRAP.md via scripts/resolve-lane.sh"
launch_lane_resolve "$WT_DIR" || {
  echo "HALT: no session created: $LL_ERR (folder '$FOLDER')." >&2
  echo "      The lane comes only from the worktree's stamp; stamp the worktree at provisioning," >&2
  echo "      or run scripts/resolve-lane.sh there to read the named LANE-UNRESOLVED / LANE-MISMATCH line." >&2
  exit 1; }
LANE="$LL_LANE"

# --- project-qualified session name (C7): stamp or HALT, before any session exists ---
PROJ_LINE="$(bash "$WT_DIR/scripts/resolve-project.sh" "$WT_DIR")" || {
  echo "HALT: no session created (C7(a): project key absent or malformed in _boot/BOOTSTRAP.md)." >&2; exit 1; }
PROJECT="${PROJ_LINE#project=}"
SESSION="$PROJECT-$LANE"

# --- refuse double-launch (exact-match; the bare lane name too, during the C7 cutover) ---
for s in "$SESSION" "$LANE"; do
  if tmux has-session -t "=$s" 2>/dev/null; then
    echo "HALT: tmux session '$s' already exists. Not launching a second seat for lane '$LANE'." >&2
    echo "      Attach with: tmux attach -t =$s" >&2
    exit 1
  fi
done

# --- pre-commit presence guard (window plan row 12): the spine-write boundary IS the
# pre-commit hook, and an absent gate silently passes. No executable hook at the hooks path git itself
# resolves (core.hooksPath honoured; a linked worktree resolves the shared common dir) => HALT before any
# session exists. Restores the guard the frozen 2.5.7 extract still carries.
HOOK_DIR="$(git -C "$WT_DIR" rev-parse --git-path hooks 2>/dev/null)" || HOOK_DIR=""
case "$HOOK_DIR" in ""|/*) ;; *) HOOK_DIR="$WT_DIR/$HOOK_DIR" ;; esac
if [ -z "$HOOK_DIR" ] || [ ! -x "$HOOK_DIR/pre-commit" ]; then
  echo "HALT: no session created: pre-commit hook not installed at '${HOOK_DIR:-<unresolved hooks path>}/pre-commit'" >&2
  echo "      (the spine-write gate does not exist without it). Run from the main worktree:" >&2
  echo "      bash scripts/install_pre_commit_hook.sh && bash scripts/install_post_commit_hook.sh" >&2
  exit 1
fi

# --- per-seat launch line (command, account, Remote Control, mode, boot prompt): the one resolver ---
launch_line_resolve "$WT_DIR" "$LANE" "$SESSION" "$MODE_FLAG" || {
  echo "HALT: no session created: the launch line could not be resolved: $LL_ERR." >&2; exit 1; }
LAUNCH_LINE="$LL_LINE"
RC_NOTE="$LL_RC_NOTE"
ACCOUNT_NOTE="$LL_ACCOUNT_NOTE"

# --- launch: detached session, cwd = worktree, then send the loop line ---
# The loop gets the session name (fixed for the session's life) and the launcher's mode option, NEVER the launch
# line: seat-loop.sh re-resolves the line from the stamp before every launch.
LOOP_LINE="exec bash scripts/seat-loop.sh --session $SESSION"
[ -n "$MODE_FLAG" ] && LOOP_LINE="$LOOP_LINE --auto-mode"
tmux new-session -d -s "$SESSION" -c "$WT_DIR"
sleep 1   # let the pane's shell initialize before keys arrive
tmux send-keys -t "=$SESSION:" "$LOOP_LINE" C-m

# --- optional mode-cycle keystrokes (default 0) ---
if [ "$BTAB_COUNT" -gt 0 ]; then
  sleep "$SETTLE_SECS"
  i=0
  while [ "$i" -lt "$BTAB_COUNT" ]; do
    tmux send-keys -t "=$SESSION:" BTab
    sleep 1
    i=$((i+1))
  done
fi

# --- receipt (observed facts only) ---
echo "== launch receipt =="
echo "lane         : $LANE"
echo "session      : $SESSION (project '$PROJECT' from _boot/BOOTSTRAP.md)"
echo "lane source  : $LANE_SOURCE"
echo "folder       : $FOLDER"
echo "worktree     : $WT_DIR"
echo "launch line  : $LAUNCH_LINE (first launch; re-resolved from the stamp at every relaunch)"
echo "loop line    : $LOOP_LINE"
echo "remote-control: $RC_NOTE"
echo "account      : $ACCOUNT_NOTE"
echo "btab sent    : $BTAB_COUNT"
if [ "$ATTACH" -eq 1 ]; then
  echo "verify next  : attaching now → /status → confirm OBSERVED mode;"
else
  echo "verify next  : tmux attach -t =$SESSION  → /status → confirm OBSERVED mode;"
fi
echo "               one Shift+Tab if auto didn't take. Stop without restart: scripts/seat-stop.sh $LANE"
echo "===================="

[ "$ATTACH" -eq 1 ] && exec tmux attach -t "=$SESSION"
exit 0
