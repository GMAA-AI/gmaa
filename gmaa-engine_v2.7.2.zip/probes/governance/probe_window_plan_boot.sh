#!/usr/bin/env bash
# probes/governance/probe_window_plan_boot.sh — red/green poles for the 2.7 window plan BOOT rows 10, 11, 16
# (the 2.7 window plan: each member carries a red pole against the canon
# teaching on its row). Zero model calls. Runs the WORKING-TREE scripts inside a shared clone, never the live seat.
#
#   W10-OBS        row 10, canon s7.1 step 6 + s8: observed-mode.sh prints the mode from its OWN
#                  stdin `permission_mode`, labelled with the event.
#   W10-NOT-CFG    the printed mode is the stdin value even when settings.json configures another (never the config).
#   W10-ONCE       the same session + mode prints nothing the second time; a mode change prints again.
#   W10-UNKNOWN    stdin without the field prints `OBSERVED-MODE: unknown (...)`, never an inferred value.
#   W10-WIRED      settings.json wires UserPromptSubmit -> scripts/observed-mode.sh (SessionStart stdin has no field).
#   W10-CFG        boot-check prints `MODE-CHECK: configured=<defaultMode> (CONFIGURED-NOT-OBSERVED...`.
#   W11-TEMPLATE   row 11, canon s2: a `**Status:** open` inside an HTML-comment template is not counted.
#   W11-INLINE     an inline one-line comment does not swallow the register after it (the 2.5.7 sed form did).
#   W16-SCOPED     row 16, canon s4 per worktree: boot runs surface conformance with --worktree <its own root>.
#
# Usage: bash probes/governance/probe_window_plan_boot.sh   -> last line WINDOW-BOOT: N/M poles OK
set -u
REPO="$(git rev-parse --show-toplevel)" || { echo "WINDOW-BOOT: UNREADABLE (not a git worktree)"; exit 3; }
command -v jq >/dev/null 2>&1 || { echo "WINDOW-BOOT: UNREADABLE (jq not found)"; exit 3; }
W="$(mktemp -d "${TMPDIR:-/tmp}/wpb.XXXXXX")"
trap 'rm -rf "$W"' EXIT
OK=0; N=0
pole() { N=$((N+1)); [ "$2" = OK ] && OK=$((OK+1)); echo "POLE $1: $2 $3"; }

C="$W/clone"
git clone -q --shared "$REPO" "$C" || { echo "WINDOW-BOOT: UNREADABLE (clone failed)"; exit 3; }
git -C "$C" checkout -q -B main "$(git -C "$REPO" rev-parse HEAD)" || { echo "WINDOW-BOOT: UNREADABLE (checkout)"; exit 3; }
cp "$REPO/scripts/boot-check.sh" "$C/scripts/boot-check.sh"
cp "$REPO/scripts/observed-mode.sh" "$C/scripts/observed-mode.sh" 2>/dev/null || : > "$C/scripts/observed-mode.sh"
cp "$REPO/.claude/settings.json" "$C/.claude/settings.json"
mkdir -p "$C/.claude"

# ── row 10: the observed-mode hook ──
om() { ( cd "$C" && printf '%s' "$1" | bash scripts/observed-mode.sh ) 2>&1; }
CFG="$(jq -r '.permissions.defaultMode' "$C/.claude/settings.json")"
OTHER=plan; [ "$CFG" = plan ] && OTHER=auto
o="$(om "{\"session_id\":\"wpb-1\",\"hook_event_name\":\"UserPromptSubmit\",\"permission_mode\":\"$OTHER\"}")"
[ "$o" = "OBSERVED-MODE: $OTHER (source: hook stdin UserPromptSubmit)" ] \
  && pole W10-OBS OK "stdin permission_mode=$OTHER -> '$o'" || pole W10-OBS FAIL "got '$o'"
case "$o" in *"$CFG"*) pole W10-NOT-CFG FAIL "the configured '$CFG' appears in '$o'" ;;
  *) [ -n "$o" ] && pole W10-NOT-CFG OK "configured=$CFG, printed $OTHER (the stdin value, never the config)" || pole W10-NOT-CFG FAIL "no line" ;; esac
o2="$(om "{\"session_id\":\"wpb-1\",\"hook_event_name\":\"UserPromptSubmit\",\"permission_mode\":\"$OTHER\"}")"
o3="$(om '{"session_id":"wpb-1","hook_event_name":"UserPromptSubmit","permission_mode":"bypassPermissions"}')"
[ -z "$o2" ] && [ "$o3" = "OBSERVED-MODE: bypassPermissions (source: hook stdin UserPromptSubmit)" ] \
  && pole W10-ONCE OK "repeat silent; a mode change prints again" || pole W10-ONCE FAIL "repeat='$o2' change='$o3'"
o4="$(om '{"session_id":"wpb-2","hook_event_name":"SessionStart","source":"startup"}')"
o5="$(om 'not json')"
[ "$o4" = "OBSERVED-MODE: unknown (source: hook stdin SessionStart; the stdin carried no permission_mode)" ] \
  && [ "$o5" = "OBSERVED-MODE: unknown (source: hook stdin UserPromptSubmit; the stdin was not JSON)" ] \
  && pole W10-UNKNOWN OK "absent field / non-JSON -> 'unknown' with the reason" || pole W10-UNKNOWN FAIL "absent='$o4' nonjson='$o5'"
# ORDER 1584: hook commands carry a cwd-independent prefix (deny hooks also a fail-closed tail), so these pins test containment of the binding, not string equality.
jq -e '[.hooks.UserPromptSubmit[]?.hooks[]?.command] | any(.[]; contains("bash scripts/observed-mode.sh"))' "$C/.claude/settings.json" >/dev/null 2>&1 \
  && pole W10-WIRED OK "UserPromptSubmit -> scripts/observed-mode.sh" || pole W10-WIRED FAIL "not wired in settings.json"

# ── rows 10, 11, 16: one boot-check run in the clone, with a fixture register and a recording conformance stub ──
cat > "$C/issues_register.md" <<'REG'
# fixture register
**Status:** open — real entry 1
<!-- TEMPLATE
**Status:** open — a template, never data
-->
an inline marker `<!-- ASSESSMENT-EMPTY -->` in a code span
**Status:** OPEN — real entry 2
**Status:** open — real entry 3
REG
printf '#!/usr/bin/env bash\nprintf "%%s\\n" "$*" > "%s/sc-args"\necho "SURFACE-CONFORM: 1 rows over 1 worktrees"\necho "VERDICT: PASS"\n' "$W" > "$C/scripts/surface-conformance-spine.sh"
( cd "$C" && bash scripts/boot-check.sh ) > "$W/boot" 2>&1 < /dev/null
grep -q "^MODE-CHECK: configured=$CFG (CONFIGURED-NOT-OBSERVED" "$W/boot" \
  && pole W10-CFG OK "MODE-CHECK: configured=$CFG (CONFIGURED-NOT-OBSERVED...)" || pole W10-CFG FAIL "$(grep -c '^MODE-CHECK' "$W/boot") MODE-CHECK lines"
reg="$(sed -n 's/^BOOT-CHECK: .* register=\([^-]*\)-open.*/\1/p' "$W/boot")"
[ "$reg" != 4 ] && [ -n "$reg" ] && pole W11-TEMPLATE OK "template not counted (register=$reg, the unstripped count is 4)" || pole W11-TEMPLATE FAIL "register=${reg:-none}"
[ "$reg" = 3 ] && pole W11-INLINE OK "entries after the inline comment counted (register=3; the 2.5.7 sed form reads 1)" || pole W11-INLINE FAIL "register=${reg:-none} (want 3)"
args="$(cat "$W/sc-args" 2>/dev/null)"
CR="$(cd "$C" && git rev-parse --show-toplevel)"
case " $args " in *" --worktree $CR "*) pole W16-SCOPED OK "boot ran conformance with '$args'" ;;
  *) pole W16-SCOPED FAIL "boot ran conformance with '${args:-<not run>}' (want --worktree $CR)" ;; esac

echo "WINDOW-BOOT: ${OK}/${N} poles OK"
[ "$OK" = "$N" ]
