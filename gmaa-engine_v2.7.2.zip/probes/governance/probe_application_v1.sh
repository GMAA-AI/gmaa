#!/usr/bin/env bash
# probe_application_v1.sh — the APPLICATION floor for canon v1.6.5.
# A teaching is APPLIED when it has at least one live carrier. The table _index/application-carriers.tsv is the teaching source
# of record (0307 §3) and names each row's carrier; this probe re-measures every ORIGIN row's carrier on every run.
#
# Checks: A1 ids unique, denominator printed, every canon section named by _index/canon-section-map.tsv (incl. its NOT MAPPED
#   line) has >=1 row · A2 each ORIGIN row's tier check (below) · A3 a carrier set that is only _rulings/** or disciplines.md is
#   ARCHIVE-ONLY = FAIL (0260 §2) · A4 each CANON row's head text is still in the current canon edition · A5 PACKAGING rows are
#   printed with owner, out of the origin verdict (0307 OQ-6) · A6 an unreadable reference is UNREADABLE, exit 3, no verdict.
# Tier checks (A2): GATE/STRUCT/SCANNER = the ERE anchor is on a line of EVERY carrier path · DELIVERY/BOOT-TEXT = the fixed-string
#   anchor is in every carrier path · BOOT-CREED = `**<id>**` row in _index/boot-roster.md · TIER = the probe id in
#   agents/standing-probes.yaml or _index/probe-tiers.tsv · SET-CRIT = >=1 _ratification/criteria/*.md names the path ·
#   BOOT-RUN = the path is named by scripts/boot-check.sh or a scripts/*-spine.sh runner · SURVIVOR = the named row passes
#   (a cycle FAILs) · INERT = the STATE-PRE-GENESIS row is in contracts/CONSTANTS.md AND boot-check.sh prints it AND runs
#   surface-conformance (0307 OQ-1) · DORMANT = exactly 1 distinct `operator` value in _orchestration/lane-provisioning.md (OQ-5).
#   A row graded PARTIAL or UNCARRIED is NOT APPLIED by definition.
# Output: one line per ORIGIN row, `APPLIED n/N` (n = CARRIED rows whose carrier passes), `VERDICT: PASS|FAIL`.
#   Exit 0 PASS · 1 FAIL · 3 UNREADABLE. It lands RED (0307 §4(b)): its landing pole is the GREEN line, not PASS.
# Usage: probe_application_v1.sh [--ref <git-ref>]   (default: the working tree of this repo)
set -u
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "APPLICATION: UNREADABLE -- not in a git worktree"; exit 3; }
cd "$ROOT" || { echo "APPLICATION: UNREADABLE -- cannot cd to $ROOT"; exit 3; }
REF=""
while [ $# -gt 0 ]; do
  case "$1" in
    --ref) [ $# -ge 2 ] || { echo "APPLICATION: UNREADABLE -- --ref needs a value"; exit 3; }; REF="$2"; shift 2 ;;
    *) echo "APPLICATION: UNREADABLE -- unknown argument $1"; exit 3 ;;
  esac
done
if [ -n "$REF" ]; then
  git rev-parse -q --verify "${REF}^{commit}" >/dev/null || { echo "APPLICATION: UNREADABLE -- ref '$REF' does not resolve (exit 3)"; exit 3; }
fi
D="$(mktemp -d "${TMPDIR:-/tmp}/appprobe.XXXXXX")" || { echo "APPLICATION: UNREADABLE -- mktemp failed"; exit 3; }
trap 'rm -rf "$D"' EXIT

# rd <path> <out>: copy the file at the reference into <out>; rc 1 if absent.
rd() { if [ -n "$REF" ]; then git show "${REF}:$1" > "$2" 2>/dev/null; else [ -f "$1" ] && cat "$1" > "$2"; fi; }
# ls_ref <dir> <glob-suffix>: list tracked-or-present files under a dir at the reference.
ls_ref() {
  if [ -n "$REF" ]; then git ls-tree -r --name-only "$REF" -- "$1" 2>/dev/null
  else git ls-files -- "$1" 2>/dev/null; ls "$1" 2>/dev/null | sed "s#^#$1/#"; fi | sort -u
}
need() { rd "$1" "$2" || { echo "APPLICATION: UNREADABLE -- $1 absent at ${REF:-working tree} (exit 3)"; exit 3; }; }

need _index/application-carriers.tsv "$D/table"
need _index/canon-section-map.tsv "$D/secmap"
need _index/boot-roster.md "$D/roster"
need scripts/boot-check.sh "$D/bootcheck"
need contracts/CONSTANTS.md "$D/constants"
need _orchestration/lane-provisioning.md "$D/lanes"
rd agents/standing-probes.yaml "$D/yaml" || : > "$D/yaml"
rd _index/probe-tiers.tsv "$D/tiers" || : > "$D/tiers"
CANON_PATH="$(ls_ref . | grep -E '^(\./)?GOVERNED_MULTI_AGENT_ARCHITECTURE_v[0-9_]+\.md$' | sed 's#^\./##' | sort -t_ -k5 -V | tail -1)"
[ -n "$CANON_PATH" ] || { echo "APPLICATION: UNREADABLE -- no canon edition found (exit 3)"; exit 3; }
need "$CANON_PATH" "$D/canon"
sed 's/[*`]//g' "$D/canon" > "$D/canon.flat"
# boot runners: boot-check.sh + every scripts/*-spine.sh
cp "$D/bootcheck" "$D/runners"
for s in $(ls_ref scripts | grep -E '^scripts/[^/]+-spine\.sh$'); do rd "$s" "$D/s.tmp" && cat "$D/s.tmp" >> "$D/runners"; done
# criteria corpus
: > "$D/criteria"
for c in $(ls_ref _ratification/criteria | grep -E '\.md$'); do rd "$c" "$D/c.tmp" && cat "$D/c.tmp" >> "$D/criteria"; done
[ -s "$D/criteria" ] || { echo "APPLICATION: UNREADABLE -- no criteria files at the reference (exit 3)"; exit 3; }

grep -v '^#' "$D/table" | grep -v '^[[:space:]]*$' > "$D/rows"
NT="$(grep -c . "$D/rows")"
fail=0

# ---- A1 ------------------------------------------------------------------------------------------------------------------
dups="$(cut -f1 "$D/rows" | sort | uniq -d | tr '\n' ' ')"
if [ -n "$dups" ]; then echo "A1: FAIL -- duplicate ids: $dups"; fail=1; fi
awk -F'\t' '!/^#/ && NF>=2 {print $2}' "$D/secmap" | tr '|' '\n' > "$D/secs"
grep -E '^# *NOT MAPPED' "$D/secmap" | grep -oE '§[0-9]+(\.[0-9]+)?' >> "$D/secs"
sort -u "$D/secs" -o "$D/secs"
cut -f2 "$D/rows" | sort -u > "$D/tsecs"
nomiss=0
while IFS= read -r s; do
  [ -z "$s" ] && continue
  if ! grep -qxF "$s" "$D/tsecs"; then
    # a parent section (e.g. §7) is covered by any row in a subsection (§7.1)
    grep -qE "^$(printf '%s' "$s" | sed 's/\./\\./g')(\.|$)" "$D/tsecs" || { echo "A1: FAIL -- canon section $s has no teaching row"; fail=1; nomiss=$((nomiss+1)); }
  fi
done < "$D/secs"
echo "A1: $NT teaching rows · $(grep -c . "$D/secs") mapped canon sections checked · $nomiss uncovered"

# ---- A2..A5 --------------------------------------------------------------------------------------------------------------
row_of() { awk -F'\t' -v id="$1" '$1==id' "$D/rows" | head -1; }
# check_row <id> <depth> -> rc 0 pass / 1 fail; prints nothing (callers print). SURVIVOR recursion is bounded by depth.
check_row() {
  local id="$1" depth="$2" r tier paths anchor grade surv p ok
  [ "$depth" -gt 8 ] && return 1
  r="$(row_of "$id")"; [ -n "$r" ] || return 1
  tier="$(printf '%s' "$r" | cut -f5)"; paths="$(printf '%s' "$r" | cut -f6)"; anchor="$(printf '%s' "$r" | cut -f7)"
  grade="$(printf '%s' "$r" | cut -f8)"; surv="$(printf '%s' "$r" | cut -f9)"
  [ "$paths" = - ] && paths=""; [ "$anchor" = - ] && anchor=""; [ "$surv" = - ] && surv=""
  case "$grade" in CARRIED|PRE-GENESIS-INERT|DORMANT-BY-SCALE) ;; *) return 1 ;; esac
  # A3: archive-only carriers
  if [ -n "$paths" ] && ! printf '%s' "$paths" | tr '|' '\n' | grep -vqE '^(_rulings/|disciplines\.md$)'; then return 1; fi
  case "$tier" in
    GATE|STRUCT|SCANNER|DELIVERY|BOOT-TEXT)
      [ -n "$paths" ] && [ -n "$anchor" ] || return 1
      ok=0
      for p in $(printf '%s' "$paths" | tr '|' ' '); do
        rd "$p" "$D/p.tmp" || return 1
        case "$tier" in
          DELIVERY|BOOT-TEXT) grep -qF -- "$anchor" "$D/p.tmp" || return 1 ;;
          *) grep -qE -- "$anchor" "$D/p.tmp" || return 1 ;;
        esac
        ok=1
      done
      [ "$ok" = 1 ] ;;
    BOOT-CREED) grep -qF -- "**${anchor}**" "$D/roster" ;;
    TIER) grep -qE -- "(^|[^a-z0-9-])${anchor}([^a-z0-9-]|$)" "$D/yaml" "$D/tiers" ;;
    SET-CRIT) [ -n "$paths" ] && rd "$paths" "$D/p.tmp" && grep -qF -- "$paths" "$D/criteria" ;;
    BOOT-RUN) [ -n "$paths" ] && rd "$paths" "$D/p.tmp" && grep -qF -- "$paths" "$D/runners" ;;
    SURVIVOR) [ -n "$surv" ] && check_row "$surv" $((depth+1)) ;;
    INERT) grep -qF 'STATE-PRE-GENESIS' "$D/constants" && grep -qF 'echo "STATE: PRE-GENESIS' "$D/bootcheck" \
             && grep -qF 'surface-conformance-spine.sh' "$D/bootcheck" ;;
    DORMANT) [ "$(awk -F'|' '
                 /^\|/ { if(!col){ for(i=2;i<NF;i++){v=$i; gsub(/^ +| +$/,"",v); if(v=="operator") col=i}; next }
                          if($0 ~ /^\|[- |]+\|$/) next; v=$col; gsub(/^ +| +$/,"",v); if(v!="") u[v]=1 }
                 END { n=0; for(k in u) n++; print n }' "$D/lanes")" = 1 ] ;;
    *) return 1 ;;
  esac
}

APPLIED=0; CARRIED=0; INERT=0; DORMANT=0; NA=0; NO=0; GREENFAIL=0; PKG=0; CANON_OK=0; CANON_N=0
while IFS="$(printf '\t')" read -r id sec ln cls tier paths anchor grade surv note; do
  for v in sec ln cls tier paths anchor grade surv note; do eval "[ \"\$$v\" = - ] && $v=''"; done
  case "$cls" in
    CANON)
      CANON_N=$((CANON_N+1))
      h="$(printf '%s' "$anchor" | sed 's/[*`]//g' | cut -c1-40)"
      if [ -n "$h" ] && grep -qF -- "$h" "$D/canon.flat"; then CANON_OK=$((CANON_OK+1))
      else echo "A4: FAIL -- CANON $id head not found in $CANON_PATH: $h"; fail=1; fi ;;
    PACKAGING)
      PKG=$((PKG+1))
      # The ratified PACKAGING map lives at an origin-only path (no ship-carriers.tsv row): the
      # lookup that finds it moves to a sibling this file keeps un-shipped (a shipped probe reads
      # only shipped paths).
      pkg_helper="$(dirname "$0")/probe_packaging_map_origin.sh"
      if [ -r "$pkg_helper" ]; then
        pkg_out="$(bash "$pkg_helper" "$id" "$grade" "$REF")"; pkg_rc=$?
        echo "$pkg_out"
        [ "$pkg_rc" -eq 0 ] || fail=1
      else
        echo "PACKAGING $id $grade owner=GMAA (origin-only verification absent on this tree — NO RECORD)"
      fi ;;
    ORIGIN)
      NO=$((NO+1))
      [ "$grade" = CARRIED ] && CARRIED=$((CARRIED+1))
      if check_row "$id" 0; then
        case "$grade" in
          CARRIED) APPLIED=$((APPLIED+1)); echo "APPLICATION: $id $tier PASS" ;;
          PRE-GENESIS-INERT) INERT=$((INERT+1)); echo "APPLICATION: $id INERT PASS (STATE-PRE-GENESIS declared; compensating control on the boot path)" ;;
          DORMANT-BY-SCALE) DORMANT=$((DORMANT+1)); echo "APPLICATION: $id DORMANT PASS (1 distinct operator)" ;;
        esac
      else
        NA=$((NA+1)); fail=1
        case "$grade" in
          CARRIED) GREENFAIL=$((GREENFAIL+1)); echo "APPLICATION: $id $tier FAIL -- graded CARRIED but the carrier check fails" ;;
          PRE-GENESIS-INERT|DORMANT-BY-SCALE) echo "APPLICATION: $id $grade FAIL -- its measured condition does not hold" ;;
          *) echo "APPLICATION: $id $grade FAIL -- not applied: $note" ;;
        esac
      fi ;;
    *) echo "A1: FAIL -- row $id has unknown class '$cls'"; fail=1 ;;
  esac
done < "$D/rows"

echo "A4: CANON $CANON_OK of $CANON_N heads present in $CANON_PATH"
echo "A5: PACKAGING $PKG rows printed, outside the origin verdict (0307 OQ-6)"
echo "APPLIED ${APPLIED}/${NO} (CARRIED rows passing; ORIGIN denominator) · INERT ${INERT} · DORMANT ${DORMANT} · NOT-APPLIED ${NA} · source ${REF:-working tree}"
echo "APPLICATION-GREEN: CARRIED ${APPLIED} of ${CARRIED} pass their carrier check · CARRIED-FAIL ${GREENFAIL}"
if [ "$fail" = 0 ]; then echo "VERDICT: PASS"; exit 0; fi
echo "VERDICT: FAIL (${NA} of ${NO} ORIGIN rows not applied; the 2.7 floor is CARRIED-FAIL 0 with this count printed; APPLIED = N is the 2.8 floor)"
exit 1
