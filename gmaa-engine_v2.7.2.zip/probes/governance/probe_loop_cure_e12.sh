#!/bin/bash
# probes/governance/probe_loop_cure_e12.sh [--root DIR] [--keep]
# The loop-cure set's standing probe. Every pole is named
# E12-PA (P-A members A1 · cures · ledger · A2 · A3 · A4) or E12-PB (the E12 ceilings), never bare `P4` (pin 4).
# It measures DIR's HEAD (default: this repo) inside a throwaway `--shared` replica under $TMPDIR:
#   - origin is REMOVED, so no push can reach the real repo (a shared clone's origin is the local worktree);
#   - `claude` is stubbed on PATH and every call is logged, so no model call can fire and A2 can count them;
#   - the real agents/{pre-commit,post-commit}-hook.sh are installed into the replica, so poles run the real code.
# Red poles: run with --root on a replica of the PRE-cure HEAD; every E12 pole must FAIL there except E12-PA-A2,
# which is a PROTECTIVE fixture (no behaviour change) and carries its own mutation red pole.
# EXIT: 0 all poles PASS · 1 a pole FAILs · 3 UNREADABLE (replica could not be built).
set -u
grep() { /usr/bin/grep "$@"; }   # never the shell's ugrep (two known divergences on this host)
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"; KEEP=""
while [ $# -gt 0 ]; do case "$1" in --root) SRC="$2"; shift 2 ;; --keep) KEEP=1; shift ;;
  *) echo "E12-PROBE: UNREADABLE -- unknown arg $1"; exit 3 ;; esac; done
W="$(mktemp -d "${TMPDIR:-/tmp}/e12probe.XXXXXX")" || { echo "E12-PROBE: UNREADABLE -- mktemp"; exit 3; }
[ -n "$KEEP" ] || trap 'rm -rf "$W"' EXIT
mkdir -p "$W/stub"; : > "$W/claude-calls"
printf '#!/bin/sh\necho "$*" >> "%s/claude-calls"\nexit 0\n' "$W" > "$W/stub/claude"; chmod +x "$W/stub/claude"; export AUDITOR_CMD="$W/stub/claude"   # the hook's own seam: see the end of this file
export PATH="$W/stub:$PATH"
R="$W/r"
git clone -q --shared "$SRC" "$R" 2>/dev/null || { echo "E12-PROBE: UNREADABLE -- clone of $SRC failed"; exit 3; }
# the fixture's spine ref and trunk come from the ONE resolver of the tree under test (the one spine-ref resolver), never a
# literal trunk, so the probe reads at an adopter as it reads at origin. Unresolvable = UNREADABLE, named.
SR="$(bash "$R/scripts/spine-ref.sh")" && [ -n "$SR" ] \
  || { echo "E12-PROBE: UNREADABLE -- SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled in the tree under test (the one spine-ref resolver)"; exit 3; }
TRUNK="${SR#origin/}"
git -C "$R" remote remove origin
git -C "$R" config user.email e12@probe.invalid; git -C "$R" config user.name e12-probe
mkdir -p "$R/.tmp" "$R/.git/audit-done"
# fixture replica: no registry row, no key (origin was removed above, so the fixture-only enrollment is admitted). Enroll the
# foundation lane once. The enrollment is AMENDED into the clone's tip, never a commit of its own: an extra commit is a worker commit to
# E12-PB and can lift the window over its 10-worker UNSCORED floor, which writes a breach line that creates issues_register.md
# and blinds the P4 RED-E12-FILL pole (M3 r2b sweep). The hook's index-read registry holds the row. Keys stay under $W.
export SEAT_KEYS_HOME="$W/keys"
bash "$SRC/scripts/seat-keys.sh" fixture-enroll "$R" foundation > "$W/enroll-r.out" 2>&1 \
  && git -C "$R" add -f _orchestration \
  && git -C "$R" commit -q --no-verify --amend --no-edit >/dev/null 2>&1 \
  || { echo "E12-PROBE: UNREADABLE -- fixture-enroll foundation: $(tail -1 "$W/enroll-r.out")"; exit 3; }
# the real post-commit hook is installed only AFTER the enrollment amend: --no-verify does not skip post-commit, and an
# amend of a tip whose diff-tree lists relay-inbox paths, under the clone's inherited live project stamp, makes hook
# §(1c) ring live panes (architect FINDING -260; relay 1623g). Every pole below still runs under the installed hook.
cp "$R/agents/post-commit-hook.sh" "$R/.git/hooks/post-commit" 2>/dev/null && chmod +x "$R/.git/hooks/post-commit" \
  || { echo "E12-PROBE: UNREADABLE -- no agents/post-commit-hook.sh at $SRC HEAD"; exit 3; }
P=0; F=0
pole() { if [ "$2" = PASS ]; then P=$((P+1)); else F=$((F+1)); fi; echo "$1 $2 :: $3"; }
# why <output> <fallback-regex>: the commit gate's named data breach if it printed one (it names the unreadable path), else the first fallback line
why() { local o; o="$(printf '%s' "$1" | grep -m1 -oE 'CANON-READ-BREACH: \([a-z]+\) \| class=[a-z-]+ \| [^ ]+')"; if [ -n "$o" ]; then echo "$o"; else printf '%s' "$1" | grep -m1 -E "$2"; fi; }
seals_since() { git -C "$R" rev-list --count --grep='^\[audit\] seal' "$1"..HEAD; }
seed() { echo foundation > "$R/.git/audit-done/$1"; echo "fixture $1" >> "$R/ledger/audit-runs.log"; }

# ── E12-PA-A1: 4 worker commits + 1 boundary -> exactly 1 seal; the old hook seals per commit ──
B="$(git -C "$R" rev-parse HEAD)"
for i in 1 2 3 4; do
  seed "$(printf 'e12f%036d' "$i")"
  mkdir -p "$R/pole"; echo "w$i" >> "$R/pole/w.txt"; git -C "$R" add pole/w.txt
  git -C "$R" commit -q --no-verify -m "e12 fixture worker $i" >/dev/null 2>&1
done
S_BEFORE="$(seals_since "$B")"
OUT="$(cd "$R" && AUDIT_SEAL_NO_PUSH=1 AUDIT_SEAL_NO_LANES=1 bash scripts/audit-seal.sh restart 2>&1)"; RC=$?
S_AFTER="$(seals_since "$B")"
SUBJ="$(git -C "$R" log -1 --format=%s)"
if [ "$S_BEFORE" = 0 ] && [ "$RC" = 0 ] && [ "$S_AFTER" = 1 ] && printf '%s' "$SUBJ" | grep -q '^\[audit\] seal (n=[0-9]*) .*boundary=restart'; then
  pole E12-PA-A1-batch PASS "0 seals over 4 worker commits, then 1 boundary seal ($SUBJ)"
else pole E12-PA-A1-batch FAIL "seals before boundary=$S_BEFORE (want 0) · audit-seal rc=$RC · seals after=$S_AFTER (want 1) · $(printf '%s' "$OUT" | tail -1)"; fi

# ── E12-PA-A1-keep: a refused seal commit keeps its sentinel, moves no HEAD, sends no seal ──
seed e12keep0000000000000000000000000000000000
printf '#!/bin/sh\nexit 1\n' > "$R/.git/hooks/pre-commit"; chmod +x "$R/.git/hooks/pre-commit"
H0="$(git -C "$R" rev-parse HEAD)"
OUT="$(cd "$R" && AUDIT_SEAL_NO_PUSH=1 AUDIT_SEAL_NO_LANES=1 bash scripts/audit-seal.sh restart 2>&1)"; RC=$?
rm -f "$R/.git/hooks/pre-commit"
if [ "$RC" = 1 ] && [ "$(git -C "$R" rev-parse HEAD)" = "$H0" ] && [ -e "$R/.git/audit-done/e12keep0000000000000000000000000000000000" ] \
   && git -C "$R" diff --cached --quiet && printf '%s' "$OUT" | grep -q SEAL-FAILED; then
  pole E12-PA-A1-keep PASS "refused commit: rc=1, HEAD unmoved, sentinel kept, index clean"
else pole E12-PA-A1-keep FAIL "rc=$RC (want 1) · head moved=$([ "$(git -C "$R" rev-parse HEAD)" = "$H0" ] && echo no || echo yes) · $(printf '%s' "$OUT" | tail -1)"; fi
git -C "$R" checkout -q -- ledger/audit-runs.log 2>/dev/null; rm -f "$R/.git/audit-done/e12keep"*

# ── E12-PA-A1-hookquiet: the post-commit hook itself no longer writes a seal ──
seed e12hook0000000000000000000000000000000000
H0="$(git -C "$R" rev-parse HEAD)"; echo h >> "$R/pole/w.txt"; git -C "$R" add pole/w.txt
git -C "$R" commit -q --no-verify -m "e12 fixture hook-quiet" >/dev/null 2>&1
if [ "$(seals_since "$H0")" = 0 ]; then pole E12-PA-A1-hookquiet PASS "a worker commit with a finished sentinel wrote 0 seals"
else pole E12-PA-A1-hookquiet FAIL "the post-commit hook sealed $(seals_since "$H0") time(s) on a worker commit (per-commit reap still live)"; fi
git -C "$R" checkout -q -- ledger/audit-runs.log 2>/dev/null; rm -f "$R/.git/audit-done/"*

# ── E12-PA-cures: assemble refuses without --cures and on a non-resolving id ──
O1="$(cd "$R" && bash scripts/ratify.sh assemble 2>&1)"; R1=$?
O2="$(cd "$R" && bash scripts/ratify.sh assemble --cures SET-9999 2>&1)"; R2=$?
if [ "$R1" != 0 ] && printf '%s' "$O1" | grep -q -- '--cures' && [ "$R2" != 0 ] && printf '%s' "$O2" | grep -q 'does not resolve'; then
  pole E12-PA-cures PASS "no --cures: rc=$R1 named; SET-9999: rc=$R2 does not resolve"
else pole E12-PA-cures FAIL "no --cures: rc=$R1 '$(printf '%s' "$O1" | tail -1 | cut -c1-100)' · SET-9999: rc=$R2 '$(printf '%s' "$O2" | tail -1 | cut -c1-100)'"; fi

# ── E12-PA-cureboundary: one cure set per restart boundary, refused at assembly otherwise ──
#   Each fixture member goes through the shipped verbs (pending-set.sh mint -> member -> reap, then ratify.sh assemble
#   --requirement-id), so the pole runs the real assembly path. An adopter tree's PENDING-SET.md is a `fill` row seeded
#   empty: the pole writes the two section headers the shipped verbs read when the seeded file carries none (as E12-PA-A4
#   writes its own marker line). It never creates issues_register.md (RED-E12-FILL deletes it): the cure id is the
#   control's own packet. Order: control (two --cures none in one interval) · cure A · A committed · cure B (refused,
#   naming A and S) · one boundary seal through the real audit-seal.sh (its meter reads no restart ledger, so it writes no breach line into the fill path RED-E12-FILL removes) · cure C. Red at the pre-cure base: B returns rc 0.
IRX=0; [ -e "$R/issues_register.md" ] && IRX=1   # the fill path RED-E12-FILL deletes: its absence is restored below
grep -q '^## THE SET[[:space:]]*$' "$R/PENDING-SET.md" 2>/dev/null || printf '\n## THE SET\n\n| # | member id | lane | branch@sha-range | surfaces touched | status |\n|---|---|---|---|---|---|\n' >> "$R/PENDING-SET.md"
grep -q '^## SET-IDENTITY' "$R/PENDING-SET.md" || printf '\n## SET-IDENTITY\n\n| requirement_id | set_id | footprint.lanes | footprint.substrates | exclusive | minted-at |\n|---|---|---|---|---|---|\n' >> "$R/PENDING-SET.md"
cbm() {  # cbm <tag> -> mint REQ-E12-CB-<tag> and write + reap its member through the shipped verbs; prints the minted set id
  local req="REQ-E12-CB-$1" sid
  sid="$(cd "$R" && bash scripts/pending-set.sh mint "$req" --footprint-lanes foundation 2>"$W/cbm-$1.err" | grep -oE 'SET-[0-9]{4}' | head -1)"
  [ -n "$sid" ] || { echo "MINT-FAIL($(tail -1 "$W/cbm-$1.err" | cut -c1-80))"; return; }
  (cd "$R" && bash scripts/pending-set.sh member "e12-cb-$1" --requirement-id "$req" --set-id "$sid" --intent "e12 cure-boundary fixture $1" --surfaces "pole/cb-$1.txt" > "$W/cbm-$1.mem" 2>&1) || { echo "MEMBER-FAIL($(tail -1 "$W/cbm-$1.mem" | cut -c1-80))"; return; }
  (cd "$R" && bash scripts/pending-set.sh reap "_orchestration/relay-outbox/foundation/SET-MEMBER-e12-cb-$1.md" > "$W/cbm-$1.reap" 2>&1) || { echo "REAP-FAIL($(tail -1 "$W/cbm-$1.reap" | cut -c1-80))"; return; }
  echo "$sid"
}
cba() {  # cba <tag> <set-id> <cures> -> assemble that requirement's set; the output is kept in $W/cba-<tag>.out; prints the rc
  (cd "$R" && bash scripts/ratify.sh assemble "$2" --requirement-id "REQ-E12-CB-$1" --cures "$3" > "$W/cba-$1.out" 2>&1); echo $?
}
SN1="$(cbm N1)"; CN1="$(cba N1 "$SN1" none)"; SN2="$(cbm N2)"; CN2="$(cba N2 "$SN2" none)"
if [ "$CN1" = 0 ] && [ "$CN2" = 0 ] && [ -f "$R/_ratification/$SN1.md" ] && [ -f "$R/_ratification/$SN2.md" ]; then
  pole E12-PA-cureboundary-control PASS "--cures none twice in one interval: $SN1 rc=0, $SN2 rc=0"
else pole E12-PA-cureboundary-control FAIL "$SN1 rc=$CN1 · $SN2 rc=$CN2 · $(tail -1 "$W/cba-N2.out" 2>/dev/null | cut -c1-120)"; fi
SA="$(cbm A)"; CA="$(cba A "$SA" "$SN1")"
git -C "$R" add -A -- "$R/_ratification" "$R/PENDING-SET.md" "$R/_orchestration/relay-outbox" 2>/dev/null
git -C "$R" commit -q --no-verify --amend --no-edit >/dev/null 2>&1   # AMENDED into the tip (a worker commit after S), never a commit of its own: an extra worker commit moves the E12-PB window
SB="$(cbm B)"; CB="$(cba B "$SB" "$SN1")"
SS="$(git -C "$R" log --first-parent --format='%H %s' HEAD | grep -m1 -E '^[0-9a-f]{40} \[audit\] seal \(n=[0-9]+\) .*boundary=(restart|shutdown)' | cut -c1-8)"
SS="${SS:-$(git -C "$R" rev-list --first-parent HEAD | tail -1 | cut -c1-8)}"
seed "$(printf 'e12cb%035d' 1)"
OUT="$(cd "$R" && E12_RESTARTS_DIR="$W/none" AUDIT_SEAL_NO_PUSH=1 AUDIT_SEAL_NO_LANES=1 bash scripts/audit-seal.sh restart 2>&1)"; RCS=$?
CSUBJ="$(git -C "$R" log -1 --format=%s)"
git -C "$R" checkout -q -- ledger/audit-runs.log 2>/dev/null; rm -f "$R/.git/audit-done/"*
SC="$(cbm C)"; CC="$(cba C "$SC" "$SN1")"
if [ "$CA" = 0 ] && [ "$CB" != 0 ] && grep -q "$SA" "$W/cba-B.out" && grep -q "$SS" "$W/cba-B.out" && [ ! -e "$R/_ratification/$SB.md" ] \
   && [ "$RCS" = 0 ] && printf '%s' "$CSUBJ" | grep -q '^\[audit\] seal (n=[0-9]*) .*boundary=restart' && [ "$CC" = 0 ] && [ -f "$R/_ratification/$SC.md" ]; then
  pole E12-PA-cureboundary PASS "cure $SA rc=0 · cure $SB in the same interval rc=$CB naming $SA and S $SS · boundary seal rc=0 · cure $SC rc=0"
else pole E12-PA-cureboundary FAIL "cure $SA rc=$CA · cure $SB rc=$CB (want non-zero naming $SA and $SS: '$(grep -v '^STALE-BOOT' "$W/cba-B.out" 2>/dev/null | tail -1 | cut -c1-120)') · seal rc=$RCS '$(printf '%s' "$CSUBJ" | cut -c1-60)' · cure $SC rc=$CC"; fi
# the poles after this one start from a clean tree: the uncommitted fixture state (B's and C's members, C's packet, the ledger rows) is dropped
[ "$IRX" = 0 ] && rm -f "$R/issues_register.md"   # a seal or verb in this pole may write it; the next poles must see the absence
git -C "$R" checkout -q -- PENDING-SET.md 2>/dev/null; rm -f "$R/_ratification/$SC.md" "$R/_ratification/$SB.md" "$R/_orchestration/relay-outbox/foundation/SET-MEMBER-e12-cb-"[BC].md

# ── E12-PA-ledger: seat-exit appends ONE line per boundary, never twice ──
BS="$(git -C "$R" rev-parse HEAD)"
printf '\ne12 handoff move\n\n## NEXT\n\n1. e12 fixture next item\n' >> "$R/dispatch/LATEST.md"; git -C "$R" add dispatch/LATEST.md
git -C "$R" commit -q --no-verify -m "e12 fixture handoff" >/dev/null 2>&1
mkdir -p "$R/.claude"; printf 'e12-sid %s 2026-01-01T00:00:00Z startup\n' "$BS" >> "$R/.claude/seat-boot.log"
# the replica clones the real spine, whose ledger already holds the real boundaries (first: e874acf1); measure the DELTA
wf() { awk -F'\t' 'NF==4 && $1 ~ /^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9:]{8}Z$/ && $2=="foundation" && $3=="restart" && $4 ~ /^[0-9a-f]{40}$/' "$R/ledger/restarts/foundation.tsv" 2>/dev/null | grep -c .; }
N0="$(grep -c . "$R/ledger/restarts/foundation.tsv" 2>/dev/null || echo 0)"; FMT0="$(wf)"; WANT=$((N0+1)); WANTF=$((FMT0+1))
L1="$(cd "$R" && TMUX=e12 CLAUDE_CODE_SESSION_ID=e12-sid bash scripts/seat-exit.sh restart 2>&1)"; E1=$?
N1="$(grep -c . "$R/ledger/restarts/foundation.tsv" 2>/dev/null || echo 0)"
L2="$(cd "$R" && TMUX=e12 CLAUDE_CODE_SESSION_ID=e12-sid bash scripts/seat-exit.sh restart 2>&1)"; E2=$?
N2="$(grep -c . "$R/ledger/restarts/foundation.tsv" 2>/dev/null || echo 0)"
FMT="$(wf)"
if [ "$E1" = 0 ] && [ "$N1" = "$WANT" ] && [ "$E2" = 0 ] && [ "$N2" = "$WANT" ] && [ "$FMT" = "$WANTF" ]; then
  pole E12-PA-ledger PASS "1 well-formed line added by the first exit ($N0 -> $N1), none by the re-run"
else pole E12-PA-ledger FAIL "exit rc=$E1 lines=$N1 (want $WANT = $N0+1) · re-run rc=$E2 lines=$N2 (want $WANT) · well-formed=$FMT (want $WANTF) · $(printf '%s' "$L1" | grep -E 'REFUSED|restart ledger' | head -1)"; fi
# the line rides the boundary seal (foundation lane)
H0="$(git -C "$R" rev-parse HEAD)"
OUT="$(cd "$R" && AUDIT_SEAL_NO_PUSH=1 AUDIT_SEAL_NO_LANES=1 bash scripts/audit-seal.sh restart 2>&1)"; RC=$?
if [ "$RC" = 0 ] && git -C "$R" show --name-only --format= HEAD | grep -qx 'ledger/restarts/foundation.tsv' && [ "$(seals_since "$H0")" = 1 ]; then
  pole E12-PA-ledger-seal PASS "the boundary seal carries ledger/restarts/foundation.tsv"
else pole E12-PA-ledger-seal FAIL "rc=$RC · seal carries the line: $(git -C "$R" show --name-only --format= HEAD | grep -c restarts) · $(printf '%s' "$OUT" | tail -1)"; fi
rm -f "$R/.claude/seat-intent"

# ── E12-PA-lanecopy (promotion): foundation's boundary seal carries a lane's own pure-append file ──
LB="$W/lanebare.git"; git init -q --bare --initial-branch="$TRUNK" "$LB"; git -C "$R" remote add origin "$LB"
git -C "$R" push -q origin "HEAD:refs/heads/$TRUNK" 2>/dev/null   # the lane map is read at the spine ref (lane-surface.sh)
LT="$W/lanetree"; git clone -q "$LB" "$LT" 2>/dev/null; mkdir -p "$LT/ledger/restarts"
# FIXTURE PROVENANCE (DISC-PROBE-INPUT-PROVENANCE): a generic DENY module lane `lane-a` on `module/lane-a`, declared
# by ONE manifest row on this fixture's own spine ref (inserted after the first module/ row; no live lane name),
# with a restart file this probe writes itself: one well-formed line. The live ledger is never read.
# The row goes after the first module/ row; a manifest that declares no module/ row (an adopter's generated manifest holds only
# its header and one empty template row) takes it after its last table row. Two passes: find the insertion line, then print.
LPROW="| lane-a | module/lane-a | lane-a-2026-01-01-r1 | DENY | 0000000000000000000000000000000000000000 | 2026-01-01T00:00:00Z | operator |"
awk -v row="$LPROW" 'NR==FNR { if (!m && /^\| [^|]+ \| module\//) m=FNR; if (/^\|/) l=FNR; next } { print } FNR==(m ? m : l) { print row }' \
  "$LT/_orchestration/lane-provisioning.md" "$LT/_orchestration/lane-provisioning.md" > "$LT/.lp.new" && mv "$LT/.lp.new" "$LT/_orchestration/lane-provisioning.md"
git -C "$LT" add _orchestration/lane-provisioning.md; git -C "$LT" -c user.email=e@x -c user.name=x commit -q -m "fixture manifest row: lane-a"
git -C "$LT" push -q origin "HEAD:refs/heads/$TRUNK" 2>/dev/null
printf '2026-01-01T00:00:00Z\tlane-a\trestart\t%040d\n' 0 > "$LT/ledger/restarts/lane-a.tsv"
git -C "$LT" add -A; git -C "$LT" -c user.email=e@x -c user.name=x commit -q -m "lane fixture"
git -C "$LT" push -q origin HEAD:refs/heads/module/lane-a 2>/dev/null
H0="$(git -C "$R" rev-parse HEAD)"
OUT="$(cd "$R" && AUDIT_SEAL_NO_PUSH=1 bash scripts/audit-seal.sh restart 2>&1)"; RC=$?
if [ "$RC" = 0 ] && git -C "$R" show --name-only --format= HEAD | grep -qx 'ledger/restarts/lane-a.tsv' && cmp -s "$R/ledger/restarts/lane-a.tsv" "$LT/ledger/restarts/lane-a.tsv"; then
  pole E12-PA-lanecopy PASS "origin/module/lane-a:ledger/restarts/lane-a.tsv carried by one foundation boundary seal, byte-identical"
else pole E12-PA-lanecopy FAIL "rc=$RC · carried=$(git -C "$R" show --name-only --format= HEAD | grep -c 'restarts/lane-a') · $(printf '%s' "$OUT" | tail -1)"; fi
# a non-append rewrite on the lane is NOT carried
printf 'REWRITTEN\n' > "$LT/ledger/restarts/lane-a.tsv"; git -C "$LT" -c user.email=e@x -c user.name=x commit -qam "lane rewrite"
git -C "$LT" push -q origin HEAD:refs/heads/module/lane-a 2>/dev/null
seed e12copy0000000000000000000000000000000000
OUT="$(cd "$R" && AUDIT_SEAL_NO_PUSH=1 bash scripts/audit-seal.sh restart 2>&1)"
if ! grep -q REWRITTEN "$R/ledger/restarts/lane-a.tsv" && printf '%s' "$OUT" | grep -q 'not a pure-append'; then
  pole E12-PA-lanecopy-appendonly PASS "a lane rewrite is refused (warned, not carried)"
else pole E12-PA-lanecopy-appendonly FAIL "a non-append lane rewrite reached the spine copy or was not warned"; fi
git -C "$R" remote remove origin

# ── E12-PA-modlane: on a module lane, 1 boundary -> 1 `restart-ledger: <lane>` commit carrying only
#    its own file, through the REAL pre-commit (module DENY) + commit-msg (creed) + post-commit hooks; another lane's
#    file is REJECTED. A second replica on branch module/lane-a with a generic DENY stamp; its spine ref pinned to its own trunk. ──
M="$W/m"; git clone -q --shared "$R" "$M" 2>/dev/null; git -C "$M" remote remove origin 2>/dev/null
git -C "$M" config user.email e12@probe.invalid; git -C "$M" config user.name e12-probe
git -C "$M" checkout -q -b module/lane-a
# fixture replica: enroll lane-a (a DENY lane is judged at the spine ref, so the row rides a fixture commit that the spine ref is pinned to)
bash "$SRC/scripts/seat-keys.sh" fixture-enroll "$M" lane-a > "$W/enroll-m.out" 2>&1 \
  && git -C "$M" add -f _orchestration \
  && git -C "$M" commit -q --no-verify -m "e12 fixture: enroll lane-a" >/dev/null 2>&1 \
  || { echo "E12-PROBE: UNREADABLE -- fixture-enroll lane-a: $(tail -1 "$W/enroll-m.out")"; exit 3; }
git -C "$M" update-ref "refs/remotes/$SR" HEAD
sed -E -e 's/^lane: .*/lane: lane-a/' -e 's/^role: .*/role: module-orc/' -e 's#^worktree_branch: .*#worktree_branch: module/lane-a#' \
  -e 's/^spine_write: .*/spine_write: DENY/' -e 's/^bootstrap_version: .*/bootstrap_version: lane-a-2026-01-01-r1/' \
  "$M/_boot/BOOTSTRAP.md" > "$M/_boot/BOOTSTRAP.md.new" && mv "$M/_boot/BOOTSTRAP.md.new" "$M/_boot/BOOTSTRAP.md"
git -C "$M" add _boot/BOOTSTRAP.md; git -C "$M" commit -q --no-verify -m "e12 fixture: lane-a stamp" >/dev/null 2>&1
for h in pre-commit:agents/pre-commit-hook.sh commit-msg:agents/commit-msg-hook.sh post-commit:agents/post-commit-hook.sh; do
  cp "$M/${h#*:}" "$M/.git/hooks/${h%%:*}" 2>/dev/null && chmod +x "$M/.git/hooks/${h%%:*}"; done
cp "$M/scripts/spine-ref.sh" "$M/.git/hooks/spine-ref.sh" 2>/dev/null || { echo "E12-PROBE: UNREADABLE -- no scripts/spine-ref.sh to place beside the installed hooks"; exit 3; }   # the resolver beside the installed hooks, as the installer places it (0507 R2)
mkdir -p "$M/ledger/restarts"; printf '%s\tlane-a\trestart\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$(git -C "$M" rev-parse HEAD)" >> "$M/ledger/restarts/lane-a.tsv"
H0="$(git -C "$M" rev-parse HEAD)"
OUT="$(cd "$M" && bash scripts/audit-seal.sh restart 2>&1)"; RC=$?
MF="$(git -C "$M" show --name-only --format= HEAD | tr '\n' ' ')"; MS="$(git -C "$M" log -1 --format=%s)"
echo x >> "$M/ledger/restarts/lane-b.tsv"; git -C "$M" add ledger/restarts/lane-b.tsv
git -C "$M" commit -q -m "restart-ledger: lane-a foreign-file fixture" >/dev/null 2>&1; NRC=$?
if [ "$RC" = 0 ] && [ "$(git -C "$M" rev-list --count "$H0"..HEAD)" = 1 ] && [ "$MF" = "ledger/restarts/lane-a.tsv " ] \
   && printf '%s' "$MS" | grep -qE '^restart-ledger: lane-a [0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9:]{8}Z$' && [ "$NRC" != 0 ]; then
  pole E12-PA-modlane PASS "1 boundary -> 1 commit '$MS' carrying only ledger/restarts/lane-a.tsv; another lane's file rejected (rc=$NRC)"
else pole E12-PA-modlane FAIL "audit-seal rc=$RC · commits=$(git -C "$M" rev-list --count "$H0"..HEAD) (want 1) · files='$MF' · subject='$MS' · foreign-file rc=$NRC (want non-zero) · $(why "$OUT" 'REJECT|SEAL-FAILED')"; fi

# ── E12-PB: the three ceilings. A breach is a PRESSURE LINE: it prints
#    `E12-PB HALT: <ratio> <value> > <ceiling> (<frame>)` and never changes the probe's exit. ──
#    Ratio 1 reads the rolling 7-UTC-day window. Each ratio-1 pole builds its OWN window, dated in the
#    future (60 days ahead and on, 20 days apart), so neither real history nor another pole's fixture is inside it.
DAY0=$(( ($(date +%s) / 86400) * 86400 + 43200 ))   # 12:00Z today; win N is centred on DAY0 + (60 + 20N) days
wd() { echo $(( DAY0 + (60 + 20 * $1) * 86400 + ${2:-0} * 86400 )); }   # wd <window> [day offset] -> epoch
fx() {  # fx <epoch> <count> <w|s|m|p> <label>: w worker · s boundary=restart seal · m boundary=manual seal · p pre-A1 seal
  local i m; for i in $(seq 1 "$2"); do case "$3" in
    w) m="e12 fixture work $4 $i" ;; s) m="[audit] seal (n=1) — lane=foundation boundary=restart (e12 fixture $4 $i)" ;;
    m) m="[audit] seal (n=1) — lane=foundation boundary=manual (e12 fixture $4 $i)" ;;
    p) m="[audit] seal $(printf '%040d' "$i") — lane=foundation reap-then-audit (e12 fixture $4)" ;; esac
    GIT_COMMITTER_DATE="$(( $1 + i )) +0000" GIT_AUTHOR_DATE="$(( $1 + i )) +0000" \
      git -C "${FXR:-$R}" commit -q --no-verify --allow-empty -m "$m" >/dev/null 2>&1; done; }
# fresh <name>: an empty repo with full date control (the A1 floor is the commit adding scripts/audit-seal.sh,
#   which in $R is the real landing commit, so A1-floor poles build their own history). fa1 <epoch>: that A1 commit.
fresh() { FXR="$W/$1"; git init -q "$FXR"; git -C "$FXR" config user.email e12@probe.invalid; git -C "$FXR" config user.name e12-probe; }
fa1() { mkdir -p "$FXR/scripts"; echo a1 > "$FXR/scripts/audit-seal.sh"; git -C "$FXR" add scripts/audit-seal.sh
  GIT_COMMITTER_DATE="$1 +0000" GIT_AUTHOR_DATE="$1 +0000" git -C "$FXR" commit -q --no-verify -m "e12 fixture A1 landing" >/dev/null 2>&1; }
e12f() { E12_RESTARTS_DIR="$W/none" bash "$R/probes/budget/probe_efficiency_budget.sh" --root "$FXR" --e12-only 2>&1; }
e12() { (cd "$R" && E12_RESTARTS_DIR="$W/none" bash probes/budget/probe_efficiency_budget.sh --e12-only 2>&1); }
e12p() { (cd "$R" && E12_PENDING_BOUNDARY=1 E12_RESTARTS_DIR="$W/none" bash probes/budget/probe_efficiency_budget.sh --e12-only 2>&1); }
r1line() { printf '%s' "$1" | grep -m1 'seals/worker' | cut -c1-110; }
# E12-PB-seals: 30 worker + 10 seals reads exactly 1/3 (no HALT); one more seal (11/30) prints the HALT line, exit 0.
fx "$(wd 0)" 30 w s30; fx "$(wd 0)" 10 s s10
O="$(e12)"; RCa=$?
fx "$(wd 0 0)" 1 s s11
O2="$(e12)"; RCb=$?
if [ "$RCa" = 0 ] && printf '%s' "$O" | grep -q 'seals/worker 0.33 = 10/30 (ceiling 1/3, integer test' && ! printf '%s' "$O" | grep -q 'E12-PB HALT: seals' \
   && [ "$RCb" = 0 ] && printf '%s' "$O2" | grep -q '^  E12-PB HALT: seals/worker 0.37 > 1/3 (11/30; rolling window '; then
  pole E12-PB-seals PASS "10/30 is exactly 1/3, no HALT; 11/30 prints the HALT line and the exit stays 0"
else pole E12-PB-seals FAIL "10/30 rc=$RCa '$(r1line "$O")' · 11/30 rc=$RCb (want 0, a pressure line) '$(printf '%s' "$O2" | grep 'HALT: seals' | cut -c1-110)'"; fi
# E12-PB-unscored: 9 worker + 9 seals is below the 10-worker floor: UNSCORED, no HALT.
fx "$(wd 1)" 9 w u9; fx "$(wd 1)" 9 s u9
OU="$(e12)"
if printf '%s' "$OU" | grep -q 'seals/worker UNSCORED (9/9; fewer than 10 worker commits' && ! printf '%s' "$OU" | grep -q 'E12-PB HALT: seals'; then
  pole E12-PB-unscored PASS "9 worker + 9 seals: UNSCORED, no HALT"
else pole E12-PB-unscored FAIL "'$(r1line "$OU")'"; fi
# E12-PB-session: a short session (1 worker + 1 seal) inside a 7-day window of 30 worker + 9 seals reads 10/31, no HALT
#   (under the per-session frame it read 1/1 and breached).
fx "$(wd 2 -3)" 30 w s-hist; fx "$(wd 2 -3)" 9 s s-hist; fx "$(wd 2)" 1 w s-now; fx "$(wd 2)" 1 s s-now
OS="$(e12)"
if printf '%s' "$OS" | grep -q 'seals/worker 0.32 = 10/31 ' && ! printf '%s' "$OS" | grep -q 'E12-PB HALT: seals'; then
  pole E12-PB-session PASS "1 worker + 1 seal inside 30 + 9: 10/31, no HALT"
else pole E12-PB-session FAIL "'$(r1line "$OS")'"; fi
# E12-PB-classify: pre-A1 per-commit seals COUNT, boundary=manual seals are EXCLUDED, a seal at D-7 is OUTSIDE the window.
#   10 worker + 3 pre-A1 + 5 manual + 5 seals at D-7 -> 3/10 (5 excluded), no HALT; counting manual (8/10) or D-7 (8/10)
#   would HALT, dropping pre-A1 would read 0/10. Then 1 more pre-A1 seal -> 4/10 HALT.
#   Re-cut, in a fresh repo: 5 boundary seals at D-7 (outside the 7 days) · 3 worker + 4 pre-A1-form seals at
#   D-4 (before A1: printed `pre-A1 seals 4`, not scored) · the A1 commit at D-3 · 9 worker + 1 boundary seal + 2
#   pre-A1-form seals (ANOMALIES after A1, counted) + 5 manual at D -> 3/10 (A1 + 9 worker), no HALT. Counting the D-7
#   seals or manual (8/10), the pre-A1 seals (7/10), or the pre-A1 workers (3/13 plus seals) moves the line; dropping the
#   anomalies reads 1/10. Then 1 more anomaly -> 4/10 HALT.
fresh cls; CD=$(wd 3)
fx $((CD - 7*86400)) 5 s c-old; fx $((CD - 4*86400)) 3 w c-pre; fx $((CD - 4*86400)) 4 p c-pre; fa1 $((CD - 3*86400))
fx "$CD" 9 w c; fx "$CD" 1 s c; fx "$CD" 2 p c-anom; fx "$CD" 5 m c
OC="$(e12f)"
fx "$((CD + 100))" 1 p c-anom3
OC2="$(e12f)"; unset FXR
if printf '%s' "$OC" | grep -q 'seals/worker 0.30 = 3/10 (ceiling 1/3, integer test 3 x seals <= worker; 5 manual/unrecognized seal(s) excluded; pre-A1 seals 4 (prior regime, not scored); anomalies 2 ' \
   && ! printf '%s' "$OC" | grep -q 'E12-PB HALT: seals' && printf '%s' "$OC2" | grep -q '^  E12-PB HALT: seals/worker 0.40 > 1/3 (4/10; A1-floored window '; then
  pole E12-PB-classify PASS "pre-A1 seals before A1 printed (4) not scored, 2 anomalies after A1 counted, 5 manual excluded, D-7 outside: 3/10 no HALT; one more anomaly: 4/10 HALT"
else pole E12-PB-classify FAIL "'$(r1line "$OC")' then '$(printf '%s' "$OC2" | grep -m1 'seals/worker' | cut -c1-110)'"; fi
# E12-PB-a1floor: A1 at D-2 with 50 pre-A1 per-commit seals before it (at D-4) and 12 worker (A1 + 11) +
#   3 boundary seals after it -> 3/12, no HALT, `pre-A1 seals 50` printed. Ignoring the floor reads 53/12 and HALTs.
#   A repo with no A1 commit (no scripts/audit-seal.sh on first-parent) reads UNREADABLE for ratio 1, never a score.
fresh a1f; AD=$(wd 6)
fx $((AD - 4*86400)) 50 p a-pre; fa1 $((AD - 2*86400)); fx "$AD" 11 w a; fx "$AD" 3 s a
OA="$(e12f)"
fresh noa1; fx "$AD" 12 w n; fx "$AD" 3 s n
ON="$(e12f)"; unset FXR
if printf '%s' "$OA" | grep -q 'seals/worker 0.25 = 3/12 (ceiling 1/3, .*pre-A1 seals 50 (prior regime, not scored)' && ! printf '%s' "$OA" | grep -q 'E12-PB HALT: seals' \
   && printf '%s' "$ON" | grep -q '^  E12-PB REPORT  seals/worker UNREADABLE (no A1 commit' && ! printf '%s' "$ON" | grep -q 'seals/worker [0-9]'; then
  pole E12-PB-a1floor PASS "A1 at D-2: 3/12 scored, pre-A1 seals 50 printed not scored, no HALT; no A1 commit: UNREADABLE, no score"
else pole E12-PB-a1floor FAIL "'$(r1line "$OA")' · no-A1: '$(r1line "$ON")'"; fi

# ── E12-PB-pending: E12_PENDING_BOUNDARY=1 adds the pending seal to the window ──
fx "$(wd 4)" 30 w p; fx "$(wd 4)" 9 s p
OP="$(e12p)"
fx "$(wd 4)" 1 s p10
OQ="$(e12p)"
if printf '%s' "$OP" | grep -q 'seals/worker 0.33 = 10/30 .*the pending boundary seal' && ! printf '%s' "$OP" | grep -q 'E12-PB HALT: seals' \
   && printf '%s' "$OQ" | grep -q '^  E12-PB HALT: seals/worker 0.37 > 1/3 (11/30; rolling window .*the pending boundary seal'; then
  pole E12-PB-pending PASS "30 worker + 9 seals + the pending seal reads 10/30 (no HALT); with a 10th seal, 11/30 HALTs: the pending seal is counted once"
else pole E12-PB-pending FAIL "'$(r1line "$OP")' then '$(r1line "$OQ")'"; fi

# ── E12-PB-register: a breach at the boundary writes ONE issues_register.md line per ratio per UTC day,
#    carried by the seal commit; a second breach the same UTC day is deduplicated. Real pre-commit + commit-msg hooks. ──
#   The E12-PA poles' boundary seals above may already have written today's line (their sessions breach too): strip any
#   E12-PB-BREACH line in a fixture commit first, so this pole measures the write and then the dedup from a clean register.
if [ ! -e "$R/issues_register.md" ]; then
  pole E12-PB-register FAIL "declared fill path issues_register.md is absent from the tree under test (_index/engine-paths.tsv fill row; the boundary seal reads and appends to it)"
else
grep -v '^- E12-PB-BREACH ' "$R/issues_register.md" > "$W/reg.clean"; cp "$W/reg.clean" "$R/issues_register.md"
git -C "$R" add issues_register.md; git -C "$R" commit -q --no-verify --allow-empty -m "e12 fixture: clean register" >/dev/null 2>&1
fx "$(wd 5)" 30 w r; fx "$(wd 5)" 10 s r   # the window ending now: 30 worker + 10 seals + the pending seal = 11/30 > 1/3
for h in pre-commit:agents/pre-commit-hook.sh commit-msg:agents/commit-msg-hook.sh; do
  cp "$R/${h#*:}" "$R/.git/hooks/${h%%:*}" 2>/dev/null && chmod +x "$R/.git/hooks/${h%%:*}"; done
cp "$R/scripts/spine-ref.sh" "$R/.git/hooks/spine-ref.sh" 2>/dev/null || { echo "E12-PROBE: UNREADABLE -- no scripts/spine-ref.sh to place beside the installed hooks"; exit 3; }   # the resolver beside the installed hooks, as the installer places it (0507 R2)
RG0="$(grep -c '^- E12-PB-BREACH ' "$R/issues_register.md")"
OUT="$(cd "$R" && AUDIT_SEAL_NO_PUSH=1 AUDIT_SEAL_NO_LANES=1 bash scripts/audit-seal.sh restart 2>&1)"; RC=$?
RG1="$(grep -c '^- E12-PB-BREACH ' "$R/issues_register.md")"
CARRIED="$(git -C "$R" show --name-only --format= HEAD | grep -cx issues_register.md)"
KEYOK="$(grep -cE "^- E12-PB-BREACH $(date -u +%Y-%m-%d) seals/worker · E12-PB HALT: seals/worker 0\.37 > 1/3 \(11/30; rolling window " "$R/issues_register.md")"
fx "$(wd 5)" 1 w r2                         # the seal above is dated now (outside window 5); 31 worker + 10 + pending = 11/31, still a breach
OUT2="$(cd "$R" && AUDIT_SEAL_NO_PUSH=1 AUDIT_SEAL_NO_LANES=1 bash scripts/audit-seal.sh restart 2>&1)"; RC2=$?
RG2="$(grep -c '^- E12-PB-BREACH ' "$R/issues_register.md")"
rm -f "$R/.git/hooks/pre-commit" "$R/.git/hooks/commit-msg"
if [ "$RC" = 0 ] && [ "$((RG1-RG0))" = 1 ] && [ "$CARRIED" = 1 ] && [ "$KEYOK" = 1 ] && [ "$RC2" = 0 ] && [ "$RG2" = "$RG1" ] \
   && printf '%s' "$OUT2" | grep -q 'E12-PB HALT: seals/worker' && git -C "$R" diff --quiet -- issues_register.md; then
  pole E12-PB-register PASS "breach -> 1 register line carried by the seal ($(git -C "$R" log -1 --format=%h HEAD~1)); a second breach the same UTC day adds 0 (deduplicated)"
else pole E12-PB-register FAIL "rc=$RC lines +$((RG1-RG0)) (want +1) carried=$CARRIED key=$KEYOK · second rc=$RC2 lines $RG1->$RG2 (want equal) · $(why "$OUT" 'SEAL-FAILED|REJECT|WARN')"; fi
fi
mkdir -p "$W/rs7" "$W/rs6" "$W/rs43"
# GENERIC FIXTURE LANE NAME: probe_efficiency_budget.sh derives the lane label purely
# from the tsv's own basename (line 147: `lane = os.path.basename(f)[:-4]`), never a hard-coded lane list,
# so this standalone ceiling fixture (its own $W/rsN dirs, never reading the cloned spine's real ledger/)
# needs no project lane name at all; the generic "lane-a" is used.
for i in 1 2 3 4 5 6 7; do printf '2026-03-01T0%d:00:00Z\tlane-a\trestart\t%040d\n' "$i" 0; done > "$W/rs7/lane-a.tsv"
head -6 "$W/rs7/lane-a.tsv" > "$W/rs6/lane-a.tsv"
{ for i in 1 2 3 4; do printf '2026-03-01T2%d:00:00Z\tlane-a\trestart\t%040d\n' "$i" 0; done; for i in 1 2 3; do printf '2026-03-02T0%d:00:00Z\tlane-a\trestart\t%040d\n' "$i" 0; done; } > "$W/rs43/lane-a.tsv"
O7="$(cd "$R" && E12_RESTARTS_DIR="$W/rs7" bash probes/budget/probe_efficiency_budget.sh --e12-only 2>&1)"; RC7=$?
o7="$(printf '%s\n' "$O7" | grep -c '^  E12-PB HALT: restarts/UTC-day/lane 7 > 6 (lane lane-a, UTC day 2026-03-01')"
o6="$(cd "$R" && E12_RESTARTS_DIR="$W/rs6" bash probes/budget/probe_efficiency_budget.sh --e12-only 2>&1 | grep -c 'E12-PB HALT: restarts')"
o43="$(cd "$R" && E12_RESTARTS_DIR="$W/rs43" bash probes/budget/probe_efficiency_budget.sh --e12-only 2>&1 | grep -c 'E12-PB HALT: restarts')"
if [ "$o7" = 1 ] && [ "$RC7" = 0 ] && [ "$o6" = 0 ] && [ "$o43" = 0 ]; then pole E12-PB-restarts PASS "7 in one UTC day prints the HALT line (exit 0); 6 and a 4/3 split across UTC midnight do not"
else pole E12-PB-restarts FAIL "HALT lines: 7/day=$o7 (want 1, rc=$RC7 want 0) · 6/day=$o6 (want 0) · 4/3 split=$o43 (want 0)"; fi
# Ratio 2: a rolling window of 7 UTC days ending on HEAD's committer UTC day; UNSCORED below 4 classed sets.
#   Every fixture commit here is dated FUT (30 days ahead), so the window holds the fixture sets only and no real set.
#   One cure-set is dated 10 days before FUT: it lies OUTSIDE the window and must not be counted.
FUT=$(( $(date +%s) + 30*86400 )); OLD=$(( FUT - 10*86400 ))
mkset() { printf '# SET-%s\n- decision: RATIFIED\n%s' "$1" "${2:+- cures: $2
}" > "$R/_ratification/SET-$1.md"; }
dcommit() { GIT_COMMITTER_DATE="$1 +0000" GIT_AUTHOR_DATE="$1 +0000" git -C "$R" commit -q --no-verify -m "$2" >/dev/null 2>&1; }
mkdir -p "$R/_ratification"
mkset 9906 SET-9901; git -C "$R" add _ratification/SET-9906.md; dcommit "$OLD" "e12 fixture old set"
mkset 9901 SET-9902; mkset 9902 SET-9903; mkset 9903 none; mkset 9905 ""
git -C "$R" add _ratification/SET-9901.md _ratification/SET-9902.md _ratification/SET-9903.md _ratification/SET-9905.md; dcommit "$FUT" "e12 fixture sets 3"
O3="$(cd "$R" && E12_RESTARTS_DIR="$W/none" bash probes/budget/probe_efficiency_budget.sh --e12-only 2>&1)"; RC3=$?
mkset 9904 SET-9901; git -C "$R" add _ratification/SET-9904.md; dcommit "$FUT" "e12 fixture set 4"
O4="$(cd "$R" && E12_RESTARTS_DIR="$W/none" bash probes/budget/probe_efficiency_budget.sh --e12-only 2>&1)"; RC4=$?
if [ "$RC3" = 0 ] && printf '%s' "$O3" | grep -q 'cure-sets/classed-sets UNSCORED (2/3 classed; fewer than 4' && ! printf '%s' "$O3" | grep -q 'HALT: cure-sets' \
   && [ "$RC4" = 0 ] && printf '%s' "$O4" | grep -q 'cure-sets/classed-sets 0.75 = 3/4 (ceiling 0.50, integer test 2 x cure <= classed; UNCLASSED 1 ' \
   && printf '%s' "$O4" | grep -q '^  E12-PB HALT: cure-sets/classed-sets 0.75 > 0.50 (3/4; rolling window '; then
  pole E12-PB-curesets PASS "3 classed: UNSCORED (2/3 is noise, no HALT); 4 classed: 0.75 > 0.50 prints the HALT line (exit 0); the set 10 days out and the unclassed set are excluded"
else pole E12-PB-curesets FAIL "3 classed rc=$RC3 '$(printf '%s' "$O3" | grep cure-sets | head -1 | cut -c1-110)' · 4 classed rc=$RC4 '$(printf '%s' "$O4" | grep cure-sets | head -1 | cut -c1-110)'"; fi

# ── E12-PA-A2 (protective): a non-trigger commit with a fresh LLM pass makes 0 claude calls ──
printf '{"ts_utc":"%s","sha":"e12","status":"RECORDED"}\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$R/ledger/auditor-usage.jsonl"
a2run() {  # a2run <hook-file> -> prints "LLM_REASON-value calls"
  cp "$1" "$R/.git/hooks/post-commit"; chmod +x "$R/.git/hooks/post-commit"; : > "$W/claude-calls"
  local out r p; for p in "dispatch/<e12-a2>.md" "_orchestration/<e12-a2>.md" "docs/<e12-a2>.md"; do
    mkdir -p "$R/$(dirname "$p")"; echo a2 >> "$R/$p"; git -C "$R" add "$p"
    # to a FILE, never $(...): the hook backgrounds the auditor, which holds a captured pipe open until it ends
    git -C "$R" commit --no-verify -m "e12 a2 $p" > "$W/a2.out" 2>&1
    r="$(grep -oE 'LLM_REASON=[^ ]+' "$W/a2.out" | tail -1 | sed 's/\.$//')"   # the hook prints "LLM_REASON=none."
    [ "$r" = "LLM_REASON=none" ] || { echo "$r@$p"; return; }
  done; sleep 2; echo "LLM_REASON=none calls=$(grep -c . "$W/claude-calls")"
}
A2="$(a2run "$R/agents/post-commit-hook.sh")"
sed 's#agents/\*|scripts/\*|#agents/*|dispatch/*|scripts/*|#' "$R/agents/post-commit-hook.sh" > "$W/hook-widened"
A2W="$(a2run "$W/hook-widened")"
cp "$R/agents/post-commit-hook.sh" "$R/.git/hooks/post-commit"
if [ "$A2" = "LLM_REASON=none calls=0" ] && [ "$A2W" != "LLM_REASON=none calls=0" ]; then
  pole E12-PA-A2 PASS "3 non-trigger paths: LLM_REASON=none, 0 claude calls · mutation (dispatch/* added to the trigger set) is caught: $A2W"
else pole E12-PA-A2 FAIL "real hook: '$A2' (want LLM_REASON=none calls=0) · widened hook: '$A2W' (must differ)"; fi

# ── E12-PA-A3: a code finding is classed; one naming no manifest path is `logged` ──
#   The expected class is read from the tree under test's OWN declared inputs: the shipping manifest is an origin process
#   file that an adopter tree need not carry, and its path is the one the tree's own code-auditor.sh joins for its A3 class (read below, never
#   retyped here). Where the tree declares it,
#   the class follows its rows (as before). Where it declares none, the shipped auditor fails toward attention
#   (`routed(manifest-unreadable)`, scripts/code-auditor.sh a3_class) and that is the class this pole requires.
#   `issues_register.md` is a `fill` row of _index/engine-paths.tsv: the pole reads it, so its absence FAILs here by name.
if [ ! -e "$R/issues_register.md" ]; then
  pole E12-PA-A3 FAIL "declared fill path issues_register.md is absent from the tree under test (_index/engine-paths.tsv fill row; the register-discipline finding cannot be raised)"
else
echo "- CLOSED e12 fixture line with no citation" >> "$R/issues_register.md"; git -C "$R" add issues_register.md
git -C "$R" commit -q --no-verify -m "e12 a3 fixture" >/dev/null 2>&1; S3="$(git -C "$R" rev-parse HEAD)"
(cd "$R" && bash scripts/code-auditor.sh "$S3" foundation >/dev/null 2>&1)
CL="$(grep -E "^- FINDING register-discipline" "$R/ledger/audit-findings.md" | tail -1 | grep -oE '\[A3 class=[a-z()-]+\]')"
MFREL="$(awk '/os\.path\.join\(repo_root, "/{l=$0} /^def a3_class/{print l; exit}' "$R/scripts/code-auditor.sh" | sed -nE 's/.*os\.path\.join\(repo_root, "([^"]+)", "([^"]+)"\).*/\1\/\2/p')"
if [ -z "$MFREL" ]; then
  pole E12-PA-A3 FAIL "the tree's code-auditor.sh declares no manifest path (os.path.join(repo_root, <dir>, <file>) not found): the expected class is unreadable"
elif [ -r "$R/$MFREL" ]; then
  WANT="[A3 class=logged]"; grep -qx 'issues_register.md' <(cut -f1 "$R/$MFREL") && WANT="[A3 class=routed(manifest-path)]"
  A3SRC="manifest row issues_register.md: $([ "$WANT" = "[A3 class=logged]" ] && echo no || echo yes)"
else
  WANT="[A3 class=routed(manifest-unreadable)]"; A3SRC="the tree does not carry its declared manifest $MFREL: fail-toward-attention"
fi
if [ -z "$MFREL" ]; then :
elif [ "$CL" = "$WANT" ]; then pole E12-PA-A3 PASS "register-discipline finding classed $CL ($A3SRC)"
else pole E12-PA-A3 FAIL "finding class '${CL:-none}' (want $WANT; $A3SRC)"; fi
fi

# ── E12-PA-A4: boot lists ONLY the audit blocks with F/DIVERGED since the absorb stamp ──
#   CHECKLIST.md is a `fill` row of _index/engine-paths.tsv (witness scripts/boot-check.sh:113, the boot's absorb anchor). The pole
#   needs the file to EXIST (its absence FAILs by name) and writes the marker line itself when the seeded file carries none.
if [ ! -e "$R/CHECKLIST.md" ]; then
  pole E12-PA-A4 FAIL "declared fill path CHECKLIST.md is absent from the tree under test (_index/engine-paths.tsv fill row; the boot's absorb anchor cannot be stamped)"
else
AN="$(git -C "$R" rev-parse --short=8 HEAD~1)"
grep -q '^\*\*absorbed_through_sha:\*\*' "$R/CHECKLIST.md" || printf '**absorbed_through_sha:** `%s`\n' "$AN" >> "$R/CHECKLIST.md"
sed -i '' -E "s/^(\*\*absorbed_through_sha:\*\* )\`[0-9a-f]+\`/\1\`$AN\`/" "$R/CHECKLIST.md" 2>/dev/null || sed -i -E "s/^(\*\*absorbed_through_sha:\*\* )\`[0-9a-f]+\`/\1\`$AN\`/" "$R/CHECKLIST.md"
HS="$(git -C "$R" rev-parse --short=8 HEAD)"
printf '\n## LLM audit — `%s` (e12 fixture)\n### F1 (LOW) — fixture finding\n**Verdict for `%s`: REPRODUCED, with 1 LOW finding.**\n' "$HS" "$HS" >> "$R/ledger/audit-findings.md"
A4="$(cd "$R" && bash scripts/boot-check.sh 2>/dev/null | grep '^AUDIT-READ-CHECK:')"
if printf '%s' "$A4" | grep -q "$HS@:" && printf '%s' "$A4" | grep -qE '^AUDIT-READ-CHECK: [0-9]+ of [0-9]+ '; then
  pole E12-PA-A4 PASS "$(printf '%s' "$A4" | cut -c1-140)"
else pole E12-PA-A4 FAIL "line: '${A4:-absent}' (want the fixture F block $HS listed)"; fi
fi

echo "E12-PROBE: $P PASS · $F FAIL of $((P+F)) poles (root $SRC @ $(git -C "$SRC" rev-parse --short=8 HEAD))"
[ "$F" = 0 ] && { echo "VERDICT: PASS"; exit 0; }
echo "VERDICT: FAIL"; exit 1

# AUDITOR_CMD (line 20): the hook re-exports PATH with the real claude dirs first, so the PATH stub alone never reaches
# it; the probe uses the hook's own AUDITOR_CMD seam, so no fixture commit spawns a real auditor. The PATH prepend stays
# for every other `claude` call. Written here, after the last exit, so no cited line above moves.
