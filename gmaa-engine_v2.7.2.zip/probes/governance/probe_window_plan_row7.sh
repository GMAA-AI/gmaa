#!/usr/bin/env bash
# probe_window_plan_row7.sh — window plan row 7:
# identity comes from LOCATION only. resolve-lane.sh has no branch->lane map and no ref/manifest read; it checks
# the stamp's worktree_branch against HEAD's branch, module/<x> => lane <x>, and spine_write ALLOW only on main.
# The launcher has no folder->lane map. The inboxf.sh XP filter reads the stamped project, fail-open.
#
# Zero model calls. Every fixture is a shared clone; the live hub and live lane worktrees are only READ.
# Usage: probe_window_plan_row7.sh [--src <dir>]
#   --src <dir>  the bytes under test: <dir>/scripts/** and <dir>/launch-orc.sh are overlaid into each fixture.
#                Default: this worktree. For the red pole, pass a dump of HEAD's scripts/ and launch-orc.sh.
# Exit 0 only when every pole is OK. Prints `ROW7: <ok>/<n>`.
set -u
REPO="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "ROW7: UNREADABLE (not in a git worktree)"; exit 3; }
SRC="$REPO"
[ "${1:-}" = "--src" ] && { SRC="${2:?--src needs a dir}"; }
[ -f "$SRC/scripts/resolve-lane.sh" ] && [ -f "$SRC/launch-orc.sh" ] || { echo "ROW7: UNREADABLE (no scripts/resolve-lane.sh or launch-orc.sh under $SRC)"; exit 3; }

W="$(mktemp -d "${TMPDIR:-/tmp}/wpr7.XXXXXX")" || { echo "ROW7: UNREADABLE (mktemp)"; exit 3; }
trap 'rm -rf "$W"' EXIT
OK=0; N=0
pole() { N=$((N+1)); [ "$2" = OK ] && OK=$((OK+1)); echo "POLE $1: $2 $3"; }
HEAD_SHA="$(git -C "$REPO" rev-parse HEAD)"

# tmux shim (no session ever exists; every other verb succeeds) — the launcher's tmux calls never touch the real server.
mkdir -p "$W/bin"; printf '#!/bin/sh\n[ "$1" = has-session ] && exit 1\nexit 0\n' > "$W/bin/tmux"; chmod +x "$W/bin/tmux"

overlay() {  # overlay <clone> — the bytes under test
  rm -rf "$1/scripts"; cp -R "$SRC/scripts" "$1/scripts"; cp "$SRC/launch-orc.sh" "$1/launch-orc.sh"
}
hook_stub() {  # satisfies the launcher's pre-commit presence guard (row 12) inside a fixture
  local h; h="$(git -C "$1" rev-parse --git-path hooks)"; case "$h" in /*) ;; *) h="$1/$h" ;; esac
  mkdir -p "$h"; printf '#!/bin/sh\nexit 0\n' > "$h/pre-commit"; chmod +x "$h/pre-commit"
}
fixture() {  # fixture <name> [<source-repo>] -> clone path (HEAD of the source; hub fixtures are -B main at HEAD_SHA)
  local c="$W/$1" from="${2:-$REPO}"
  git clone -q --shared "$from" "$c" >/dev/null 2>&1 || return 1
  [ "$from" = "$REPO" ] && { git -C "$c" checkout -q -B main "$HEAD_SHA" || return 1; }
  overlay "$c"; printf '%s\n' "$c"
}
stamp() {  # stamp <clone> <lane> <worktree_branch> <spine_write> — rewrite the front-matter fields in place,
           # values via env (branch names carry '/'), then read all three back; a failed rewrite fails the probe.
  SL="$2" SB="$3" SW="$4" perl -0pi -e 's/^lane:.*$/lane: $ENV{SL}/m; s/^worktree_branch:.*$/worktree_branch: $ENV{SB}/m; s/^spine_write:.*$/spine_write: $ENV{SW}/m' "$1/_boot/BOOTSTRAP.md"
  grep -qx "lane: $2" "$1/_boot/BOOTSTRAP.md" && grep -qx "worktree_branch: $3" "$1/_boot/BOOTSTRAP.md" \
    && grep -qx "spine_write: $4" "$1/_boot/BOOTSTRAP.md" || { echo "ROW7: UNREADABLE (stamp rewrite failed in $1)"; exit 3; }
}
resolve() { (cd "$1" && bash scripts/resolve-lane.sh 2>&1); }

# ── W7-NOREF: no origin refs at all; a valid stamp still resolves (the refused trunk-read draft HALTed here) ──
c="$(fixture noref)" && git -C "$c" remote remove origin
out="$(resolve "$c")"; rc=$?
[ "$rc" = 0 ] && grep -q '^lane=foundation ' <<< "$out" \
  && pole W7-NOREF OK "no origin refs, rc=0 lane=foundation" || pole W7-NOREF FAIL "rc=$rc $(printf '%s' "$out" | tail -1)"

# ── W7-WTB: a copied integrator stamp (worktree_branch main) on branch `architect` => exit 3 ──
c="$(fixture wtb)"; git -C "$c" checkout -q -b architect; stamp "$c" foundation main DENY
out="$(resolve "$c")"; rc=$?
[ "$rc" = 3 ] && grep -q 'LANE-MISMATCH' <<< "$out" \
  && pole W7-WTB OK "rc=3 named" || pole W7-WTB FAIL "rc=$rc $(printf '%s' "$out" | tail -1)"

# ── W7-WTB-MODULE: module/x stamp lane x but worktree_branch module/y => exit 3 (the deleted map accepted it) ──
c="$(fixture wtbm)"; git -C "$c" checkout -q -b module/x; stamp "$c" x module/y DENY
out="$(resolve "$c")"; rc=$?
[ "$rc" = 3 ] && grep -q "worktree_branch='module/y'" <<< "$out" \
  && pole W7-WTB-MODULE OK "rc=3 named" || pole W7-WTB-MODULE FAIL "rc=$rc $(printf '%s' "$out" | tail -1)"

# ── W7-MODULE: branch module/x, stamp lane y => exit 3 ──
c="$(fixture module)"; git -C "$c" checkout -q -b module/x; stamp "$c" y module/x DENY
out="$(resolve "$c")"; rc=$?
[ "$rc" = 3 ] && grep -q 'LANE-MISMATCH' <<< "$out" \
  && pole W7-MODULE OK "rc=3 named" || pole W7-MODULE FAIL "rc=$rc $(printf '%s' "$out" | tail -1)"

# ── W7-SPINE: a non-trunk branch carrying spine_write ALLOW => exit 3 (the deleted map never read spine_write) ──
c="$(fixture spine)"; git -C "$c" checkout -q -b module/x; stamp "$c" x module/x ALLOW
out="$(resolve "$c")"; rc=$?
[ "$rc" = 3 ] && grep -q 'spine_write=ALLOW' <<< "$out" \
  && pole W7-SPINE OK "rc=3 named" || pole W7-SPINE FAIL "rc=$rc $(printf '%s' "$out" | tail -1)"

# ── W7-NOMAP: stamped lane names on NON-COMMENT lines of the four carriers, outside the launcher's shipped-seat
#    (architect) block => 0. Frame: perl word match; comment lines are the G14 strip pass's, not this row's. ──
lanes="$(for wt in $(git -C "$REPO" worktree list --porcelain | sed -n 's/^worktree //p'); do
  sed -n 's/^lane:[[:space:]]*//p' "$wt/_boot/BOOTSTRAP.md" 2>/dev/null | head -1; done | sort -u | tr '\n' '|' | sed 's/|$//')"
hits=0
for f in scripts/resolve-lane.sh launch-orc.sh scripts/launch-orc.sh scripts/inboxf.sh; do
  n="$(L="$lanes" perl -ne 'BEGIN{$re=qr/(?<![\w\/.-])(?:$ENV{L})(?![\w-])/} next if /^\s*#/; next if /architect/ && $ARGV =~ /launch-orc/; $c++ if /$re/; END{print $c+0}' "$SRC/$f")"
  hits=$((hits+n))
done
[ -n "$lanes" ] && [ "$hits" = 0 ] && pole W7-NOMAP OK "0 lane-name code lines over 4 carriers (lanes: $lanes)" \
  || pole W7-NOMAP FAIL "$hits lane-name code line(s) over 4 carriers (lanes: ${lanes:-<none read>})"

# ── W7-LAUNCH-NOSTAMP: a folder with no stamp HALTs with the named line, no session ──
PATH="$W/bin:$PATH"; export PATH
mkdir -p "$W/fold"; c="$(fixture ls-raw)" && mv "$c" "$W/fold/fx-lane" && c="$W/fold/fx-lane"; hook_stub "$c"
rm -f "$c/_boot/BOOTSTRAP.md"
out="$(cd "$c" && bash launch-orc.sh --detach 2>&1)"; rc=$?
[ "$rc" != 0 ] && grep -q 'HALT: no session created: no _boot/BOOTSTRAP.md' <<< "$out" \
  && pole W7-LAUNCH-NOSTAMP OK "rc=$rc named HALT" || pole W7-LAUNCH-NOSTAMP FAIL "rc=$rc $(printf '%s' "$out" | tail -2 | tr '\n' '|')"

# ── W7-LAUNCH-NOLANE: stamp present, lane: removed, folder named like an old alias => HALT, never a folder guess ──
mkdir -p "$W/fold2"; c="$(fixture ln-raw)" && mv "$c" "$W/fold2/fx-lane" && c="$W/fold2/fx-lane"; hook_stub "$c"
perl -ni -e 'print unless /^lane:/' "$c/_boot/BOOTSTRAP.md"
out="$(cd "$c" && bash launch-orc.sh --detach 2>&1)"; rc=$?
[ "$rc" != 0 ] && ! grep -q '^lane  *: ' <<< "$out" \
  && pole W7-LAUNCH-NOLANE OK "rc=$rc, no lane guessed" || pole W7-LAUNCH-NOLANE FAIL "rc=$rc $(printf '%s' "$out" | grep -m1 '^lane' )"

# ── W7-LAUNCH: each live stamped lane worktree resolves its own stamped lane through the launcher ──
nl=0; okl=0; bad=""
while read -r wt; do
  [ -f "$wt/_boot/BOOTSTRAP.md" ] || continue
  want="$(sed -n 's/^lane:[[:space:]]*//p' "$wt/_boot/BOOTSTRAP.md" | head -1)"
  wb="$(sed -n 's/^worktree_branch:[[:space:]]*//p' "$wt/_boot/BOOTSTRAP.md" | head -1)"
  [ "$(git -C "$wt" rev-parse --abbrev-ref HEAD)" = "$wb" ] || continue   # nested agent-* worktrees HALT by design (W7-WTB class)
  nl=$((nl+1)); c="$W/live-$nl"
  git clone -q --shared "$wt" "$c" >/dev/null 2>&1 || { bad="$bad $want:clone"; continue; }
  cp "$wt/_boot/BOOTSTRAP.md" "$c/_boot/BOOTSTRAP.md"
  cp "$SRC/launch-orc.sh" "$c/launch-orc.sh"; cp "$SRC/scripts/resolve-lane.sh" "$c/scripts/resolve-lane.sh"; hook_stub "$c"
  got="$(cd "$c" && bash launch-orc.sh --detach 2>&1 | sed -n 's/^lane  *: //p' | head -1)"
  [ "$got" = "$want" ] && okl=$((okl+1)) || bad="$bad $want:got=$got"
done < <(git -C "$REPO" worktree list --porcelain | sed -n 's/^worktree //p')
[ "$nl" -gt 0 ] && [ "$okl" = "$nl" ] && pole W7-LAUNCH OK "$okl of $nl live lane worktrees resolve their stamped lane" \
  || pole W7-LAUNCH FAIL "$okl of $nl;$bad"

# ── W7-XP-EMPTY: empty project: => a TO-other note is SHOWN, and a named PROJECT-UNRESOLVED line prints ──
xp_run() {  # xp_run <name> <project-value> -> inboxf check output over a 2-note XP fixture
  local c d="$W/xp-$1"; c="$(fixture "x-$1")" || return 1
  perl -0pi -e "s/^project:.*\$/project: $2/m" "$c/_boot/BOOTSTRAP.md"
  mkdir -p "$d"; printf 'TO: acme\n\nself\n' > "$d/self.md"; printf 'TO: someone-else\n\nforeign\n' > "$d/foreign.md"
  (cd "$c" && XP_DIR="$d" bash scripts/inboxf.sh check 2>&1)
}
out="$(xp_run empty '')"
grep -qE '^NEW  xp +foreign\.md$' <<< "$out" && grep -q 'PROJECT-UNRESOLVED' <<< "$out" \
  && pole W7-XP-EMPTY OK "foreign note shown, named line printed" \
  || pole W7-XP-EMPTY FAIL "$(printf '%s\n' "$out" | grep -E '^(XP|NEW  xp)' | tr '\n' '|')"

# ── W7-XP-STAMP: project: acme => TO: acme shown, TO: someone-else filtered ──
out="$(xp_run stamp acme)"
grep -qE '^NEW  xp +self\.md$' <<< "$out" && ! grep -qE '^NEW  xp +foreign\.md$' <<< "$out" \
  && pole W7-XP-STAMP OK "self shown, foreign filtered" \
  || pole W7-XP-STAMP FAIL "$(printf '%s\n' "$out" | grep -E '^(XP|NEW  xp)' | tr '\n' '|')"

echo "ROW7: $OK/$N"
[ "$OK" = "$N" ]
