#!/bin/bash
# probes/governance/probe_seat_restart_poles.sh — poles for the C7 + seat-restart automation set
# Poles P1-P19, each of which can FAIL.
# Every mechanism runs against a THROWAWAY fixture repo (mktemp) with a recording tmux stub on PATH:
# no live tmux session is touched. Reads the scripts under test from this worktree (or $SUT_ROOT).
# Live-only halves, stated not faked: P3's BOOT-ACK/BOOT-CHECK in a relaunched session, and Remote Control
# being visible on the operator's phone, are verifiable only at a real relaunch (the cutover).
# Output: `POLE <id>: OK|FAIL <detail>` per pole, then `SEAT-RESTART-POLES: <ok>/<n> poles OK`; exit 0 iff all OK.
# Also prints `BARE-CENSUS:` (C7(c): bare-named seat sessions live, until 0), informational, never scored.
set -u
REPO="${SUT_ROOT:-$(git rev-parse --show-toplevel)}"
W="$(mktemp -d "${TMPDIR:-/tmp}/seatpoles.XXXXXX")"
# reap_w: kill the processes whose cwd is under $W (detached verifiers and their sleeps); never this shell
reap_w() {
  local wr; wr="$(cd "$W" 2>/dev/null && pwd -P)" || return 0
  /usr/sbin/lsof -a -d cwd -F pn 2>/dev/null | awk -v d="$wr/" '/^p/{p=substr($0,2)} /^n/{if (index(substr($0,2) "/", d) == 1) print p}' |
    while read -r pid; do [ "$pid" != "$$" ] && kill "$pid" 2>/dev/null; done
  return 0
}
trap 'reap_w; rm -rf "$W"' EXIT
OKN=0; N=0
pole() { N=$((N + 1)); if [ "$2" = OK ]; then OKN=$((OKN + 1)); fi; echo "POLE $1: $2 ${3:-}"; }
unset CLAUDE_CODE_CHILD_SESSION   # the probe may run inside a seat; seat-stop's refusal is tested explicitly

# ---------- stub tmux (records every call; models sessions from a file) ----------
mkdir -p "$W/bin"
cat > "$W/bin/tmux" <<'STUB'
#!/bin/bash
echo "$*" >> "$STUB_LOG"
case "$1" in
  has-session) t="${3#=}"; grep -qx -- "$t" "$STUB_SESSIONS" 2>/dev/null ;;
  new-session) while [ $# -gt 0 ]; do [ "$1" = -s ] && echo "$2" >> "$STUB_SESSIONS"; shift; done ;;
  kill-session) t="${3#=}"; grep -vx -- "$t" "$STUB_SESSIONS" > "$STUB_SESSIONS.n" 2>/dev/null; mv "$STUB_SESSIONS.n" "$STUB_SESSIONS" ;;
  list-panes) cat "$STUB_PANES" 2>/dev/null ;;
  capture-pane) date +%s%N ;;
  *) : ;;
esac
STUB
chmod +x "$W/bin/tmux"
export STUB_LOG="$W/tmux.log" STUB_SESSIONS="$W/sessions" STUB_PANES="$W/panes"
: > "$STUB_LOG"; : > "$STUB_SESSIONS"; : > "$STUB_PANES"
P="$W/bin:$PATH"
PRJ="fixprog"   # the fixture stamp's own program value (any value works: the seat name is derived from the stamp, never named here)

# ---------- fixture repo ----------
mkfix() {  # mkfix <dir> <lane> <stamp extra lines...>
  local d="$1" lane="$2"; shift 2
  mkdir -p "$d/_boot" "$d/scripts" "$d/dispatch" "$d/.claude"
  { echo "---"; echo "lane: $lane"; echo "worktree_branch: main"; for l in "$@"; do echo "$l"; done; echo "---"; echo "# fixture"; } > "$d/_boot/BOOTSTRAP.md"
  for s in resolve-project.sh seat-exit.sh seat-b6-stop.sh seat-precompact.sh seat-loop.sh seat-stop.sh seat-boot-record.sh statusline-context.sh doorbell.sh resolve-lane.sh subagent-lib.sh audit-seal.sh lane-surface.sh; do
    cp "$REPO/scripts/$s" "$d/scripts/$s" 2>/dev/null
  done
  cp "$REPO/scripts/launch-orc.sh" "$d/launch-orc.sh"
  echo ".claude/*" > "$d/.gitignore"
  echo "v1" > "$d/dispatch/LATEST.md"
  git -C "$d" init -q -b main   # row 7: the stamp names its branch; resolve-lane.sh checks it
  # window plan row 12: the launcher HALTs without an executable pre-commit hook, so the fixture installs one
  printf '#!/bin/sh\nexit 0\n' > "$d/.git/hooks/pre-commit"; chmod +x "$d/.git/hooks/pre-commit"
  git -C "$d" -c user.name=p -c user.email=p@p -c core.hooksPath=/dev/null add -A
  git -C "$d" -c user.name=p -c user.email=p@p -c core.hooksPath=/dev/null commit -qm fixture
}
gc() { git -C "$F" -c user.name=p -c user.email=p@p -c core.hooksPath=/dev/null "$@"; }
F="$W/fx"
mkfix "$F" foundation "project: ${PRJ}" "remote_control: true" "handoff: dispatch/LATEST.md"
SID="sid-own-1"
BOOT="$(git -C "$F" rev-parse HEAD)"
echo "$SID $BOOT 2026-10-01T00:00:00Z startup" > "$F/.claude/seat-boot.log"
xit() { ( cd "$F" && env PATH="$P" TMUX="${1}" CLAUDE_CODE_SESSION_ID="$SID" bash scripts/seat-exit.sh "$2" ) >"$W/out" 2>&1; echo $?; }

# P2: handoff unchanged since boot sha -> exit 2, no intent
rc="$(xit /tmp/t,1,0 restart)"
[ "$rc" = 2 ] && [ ! -f "$F/.claude/seat-intent" ] && grep -q "unchanged since" "$W/out" \
  && pole P2 OK "unchanged handoff refused rc=2" || pole P2 FAIL "rc=$rc $(head -1 "$W/out")"

# P-TMUX: not a tmux seat -> refused
rc="$(xit "" restart)"
[ "$rc" = 2 ] && grep -q "not a tmux seat" "$W/out" && pole P-TMUX OK "TMUX unset refused" || pole P-TMUX FAIL "rc=$rc"

printf 'v2\n\n## NEXT\n\n1. fixture next item\n' > "$F/dispatch/LATEST.md"; gc commit -qam handoff
# P1/P16 red half: tracked edit -> exit 2, no intent, no keystroke
echo dirt >> "$F/dispatch/LATEST.md"; : > "$STUB_LOG"
rc="$(xit /tmp/t,1,0 restart)"
[ "$rc" = 2 ] && [ ! -f "$F/.claude/seat-intent" ] && [ ! -s "$STUB_LOG" ] \
  && pole P1 OK "tracked edit refused rc=2, no intent, no keystroke" || pole P1 FAIL "rc=$rc"
gc checkout -q -- dispatch/LATEST.md
# P16 green half + P15: untracked-only passes; seat-exit itself sends NO keystroke
echo scratch > "$F/untracked-note.md"; : > "$STUB_LOG"
rc="$(xit /tmp/t,1,0 restart)"
read -r k s _ < "$F/.claude/seat-intent" 2>/dev/null || true
[ "$rc" = 0 ] && [ "${k:-}" = restart ] && [ "${s:-}" = "$SID" ] && grep -q "untracked=1" "$W/out" \
  && pole P16 OK "untracked-only passed; intent=restart for own session" || pole P16 FAIL "rc=$rc k=${k:-} $(head -1 "$W/out")"
[ ! -s "$STUB_LOG" ] && pole P15 OK "seat-exit.sh made 0 tmux calls" || pole P15 FAIL "tmux calls: $(tr '\n' ';' < "$STUB_LOG")"

# ---------- Stop hook ----------
# Pole isolation (r6): every /exit send arms a DETACHED verifier in seat-b6-stop.sh (the CONFIRM_DELAY read, plus the
# VERIFY_AT offsets, default 20 60 180 s, whose LOST path re-feeds the hook and sends again). It outlives the pole and
# keeps the cwd, ROOT and STUB_LOG it was spawned with. So the sending poles run in their OWN fixture copy ($FX), and
# each stop() call gets its OWN stub log: a verifier from an earlier call can write only to that call's log and that
# fixture, never to a later pole's (seen before this cure: P-EXIT-FOREIGN FAIL capture-pane -p -t %9, 1 of 9 runs).
# Isolation is by construction, not by timing. reap_w at EXIT stops anything still running with a cwd under $W.
# Red for the isolation: VERIFY_AT=3 re-feeds the 1st send inside the foreign pole; the uncured probe FAILs P-EXIT-FOREIGN.
stop() { printf '{"session_id":"%s"}' "$1" | ( cd "$FX" && env PATH="$P" TMUX_PANE="%9" SEND_CMD="$W/bin/tmux" SEND_DELAY=0 STUB_LOG="${2:-$STUB_LOG}" bash scripts/seat-b6-stop.sh ); }
FX="$W/fx-exit"; cp -R "$F" "$FX"; rm -f "$F/.claude/seat-intent" "$FX/.claude/seat-exit-sent"
# P-EXIT: own intent -> /exit sent to own pane once; a 2nd turn end for the SAME intent means the session is still
# alive, so the send was lost: logged SEAT-EXIT-LOST and re-sent (this pole read "then not again"
# until that cure — the one-shot defect, ISSUE-SEAT-EXIT-ONE-SHOT-BLIND-SEND; full poles in probe_subagent_restart_poles.sh)
: > "$W/x1.log"; : > "$W/x2.log"
stop "$SID" "$W/x1.log" > "$W/out"; sleep 2
c1="$(grep -c 'send-keys -t %9 -l /exit' "$W/x1.log")"
stop "$SID" "$W/x2.log" > /dev/null; sleep 2
c2="$(grep -c 'send-keys -t %9 -l /exit' "$W/x2.log")"
[ "$c1" = 1 ] && [ "$c2" = 1 ] && [ ! -s "$W/out" ] && grep -q 'SEAT-EXIT-LOST' "$FX/.claude/seat-loop.log" && pole P-EXIT OK "own intent: /exit sent once to own pane, no injection; lost send re-sent once (0337 §4)" || pole P-EXIT FAIL "c1=$c1 c2=$c2"
# foreign session with the same intent on disk -> no send (its own log: only the foreign call can write to it)
: > "$W/xf.log"; stop "sid-foreign" "$W/xf.log" > /dev/null; sleep 1
[ ! -s "$W/xf.log" ] && pole P-EXIT-FOREIGN OK "foreign session sends nothing" || pole P-EXIT-FOREIGN FAIL "$(tr '\n' ';' < "$W/xf.log")"
FX="$F"; rm -f "$F/.claude/seat-intent" "$F/.claude/b6-injected" "$F/.claude/e11-tokens.log"

pct() { echo "$1 ${2}000 $2 2026-10-01T00:00:00Z" > "$F/.claude/context-pct"; }
inj() { stop "$SID" | jq -r '.hookSpecificOutput.additionalContext // empty' 2>/dev/null; }
# P7 (levels are tokens; pct() writes tokens = pct*1000): 249K none; 250K soft (tokens+pct);
# 349K none (latched); 350K hard; P14: 350K again -> none
pct "$SID" 249; a="$(inj)"; pct "$SID" 250; b="$(inj)"; pct "$SID" 349; c="$(inj)"; pct "$SID" 350; d="$(inj)"; e="$(inj)"
[ -z "$a" ] && echo "$b" | grep -q "250000 tokens carried (250% " && [ -z "$c" ] && echo "$d" | grep -q "Never OPEN a new WP" \
  && pole P7 OK "249K none · 250K inject (tokens+pct) · 350K inject" || pole P7 FAIL "a=[$a] b=[${b:0:40}] c=[$c] d=[${d:0:40}]"
[ -z "$c" ] && [ -z "$e" ] && pole P14 OK "same-level Stop in same session injects once" || pole P14 FAIL "c=[$c] e=[$e]"
# P13: foreign session line past hard -> no injection
rm -f "$F/.claude/b6-injected"; pct "sid-dead" 720; f="$(inj)"
[ -z "$f" ] && pole P13 OK "foreign-session 720K line ignored" || pole P13 FAIL "injected: ${f:0:60}"
# null pct -> no reading
rm -f "$F/.claude/b6-injected"; echo "$SID 0 null x" > "$F/.claude/context-pct"; g="$(inj)"
[ -z "$g" ] && pole P-NULL OK "null pct = no reading" || pole P-NULL FAIL "injected on null"
# E11: own-session readings appended, foreign not
n11="$(grep -c " $SID " "$F/.claude/e11-tokens.log" 2>/dev/null)"; f11="$(grep -c "sid-dead" "$F/.claude/e11-tokens.log" 2>/dev/null)"
[ "${n11:-0}" -ge 5 ] && [ "${f11:-0}" = 0 ] && pole E11 OK "own-session lines=$n11, foreign=0" || pole E11 FAIL "own=$n11 foreign=$f11"
# P21 (0330 §6): E11 appends only for a numeric token reading; a null token appends nothing
rm -f "$F/.claude/e11-tokens.log"
echo "$SID null 10 x" > "$F/.claude/context-pct"; stop "$SID" > /dev/null
c21a="$(wc -l < "$F/.claude/e11-tokens.log" 2>/dev/null || echo 0)"
pct "$SID" 10; stop "$SID" > /dev/null
c21b="$(wc -l < "$F/.claude/e11-tokens.log" 2>/dev/null || echo 0)"
[ "${c21a:-0}" -eq 0 ] && [ "${c21b:-0}" -ge 1 ] && pole P21 OK "null token appends nothing (a=$c21a); numeric token appends (b=$c21b)" || pole P21 FAIL "a=$c21a b=$c21b"

# ---------- statusline writer ----------
printf '{"session_id":"%s","model":{"display_name":"M"},"context_window":{"total_input_tokens":123456,"used_percentage":12.7}}' "$SID" \
  | ( cd "$F" && bash scripts/statusline-context.sh ) > "$W/out"
read -r s t p _ < "$F/.claude/context-pct"
printf '{"session_id":"%s","context_window":{"total_input_tokens":0,"used_percentage":null}}' "$SID" | ( cd "$F" && bash scripts/statusline-context.sh ) > /dev/null
read -r _ _ p2 _ < "$F/.claude/context-pct"
[ "$s" = "$SID" ] && [ "$t" = 123456 ] && [ "$p" = 12 ] && [ "$p2" = null ] && pole P-STATUSLINE OK "writes <sid> <tokens> <pct> <utc>; null kept null" || pole P-STATUSLINE FAIL "s=$s t=$t p=$p p2=$p2"
# P20 (0330 §6/§4): absent total_input_tokens writes null (never 0); field 5 carries the window (null if absent)
printf '{"session_id":"%s","context_window":{"used_percentage":5,"context_window_size":180000}}' "$SID" \
  | ( cd "$F" && bash scripts/statusline-context.sh ) > /dev/null
read -r s20 t20 p20 u20 w20 < "$F/.claude/context-pct"
printf '{"session_id":"%s","context_window":{"total_input_tokens":999,"used_percentage":5}}' "$SID" \
  | ( cd "$F" && bash scripts/statusline-context.sh ) > /dev/null
read -r _ _ _ _ w20b < "$F/.claude/context-pct"
[ "$t20" = null ] && [ "$w20" = 180000 ] && [ "$w20b" = null ] \
  && pole P20 OK "no-token-field writes null not 0; field5=window ($w20), null when absent" || pole P20 FAIL "t20=$t20 w20=$w20 w20b=$w20b"

# ---------- PreCompact (P19 / P6) ----------
pct "$SID" 80
pc() { printf '%s' "$1" | ( cd "$F" && bash scripts/seat-precompact.sh ); }
r1="$(pc "{\"session_id\":\"$SID\",\"trigger\":\"auto\"}" | jq -r '.decision + "|" + .reason' 2>/dev/null)"
r2="$(pc "{\"session_id\":\"$SID\",\"trigger\":\"manual\"}")"
r3="$(pc "{\"session_id\":\"$SID\",\"trigger\":\"auto\",\"agent_id\":\"a1\"}")"
r4="$(pc "{\"session_id\":\"sid-headless\",\"trigger\":\"auto\"}")"
echo "$r1" | grep -q "^block|.*seat-exit.sh restart" && [ -z "$r2" ] \
  && pole P19 OK "auto blocked with the B6.1 instruction; manual passes" || pole P19 FAIL "r1=[${r1:0:50}] r2=[$r2]"
[ -z "$r3" ] && [ -z "$r4" ] && pole P19-SCOPE OK "subagent (agent_id) and non-seat session may compact" || pole P19-SCOPE FAIL "r3=[$r3] r4=[$r4]"

# ---------- seat-loop (P3 stub half, P4, P5, P12, P17) ----------
cat > "$F/fake.sh" <<'FAKE'
#!/bin/bash
n=$(( $(cat .claude/runs 2>/dev/null || echo 0) + 1 )); echo $n > .claude/runs
act="$(sed -n "${n}p" .claude/plan)"
# <kind>:<mutation> edits the stamp DURING this run, before the intent is written.
mut=""; case "$act" in *:*) mut="${act#*:}"; act="${act%%:*}" ;; esac
B=_boot/BOOTSTRAP.md
case "$mut" in
  addrc)     awk '{print} /^lane:/{print "remote_control: true"}' "$B" > "$B.n"; mv "$B.n" "$B" ;;
  droprc)    grep -v '^remote_control:' "$B" > "$B.n"; mv "$B.n" "$B" ;;
  breaklane) grep -v '^lane:' "$B" > "$B.n"; mv "$B.n" "$B" ;;
esac
case "$act" in
  restart|shutdown) printf '%s sid h %s u\n' "$act" "$(date +%s)" > .claude/seat-intent ;;
  stale) printf 'restart sid h 1 u\n' > .claude/seat-intent ;;
esac
exit 0
FAKE
# The loop re-resolves its launch line from the stamp, so the fixture command is a `claude`
# stub on a loop-only PATH: it records its argv to .claude/argv and plays the plan through fake.sh.
mkdir -p "$W/cbin"; printf '#!/bin/bash\necho "$*" >> .claude/argv\nexec bash fake.sh\n' > "$W/cbin/claude"; chmod +x "$W/cbin/claude"
loop() { printf '%s\n' "$@" > "$F/.claude/plan"; rm -f "$F/.claude/runs" "$F/.claude/seat-intent" "$F/.claude/argv"; : > "$STUB_LOG"
  ( cd "$F" && env PATH="$W/cbin:$P" bash scripts/seat-loop.sh --session ${PRJ}-foundation ) < /dev/null > "$W/loop.out" 2>&1; echo $?; }
rc="$(loop restart none)"; runs="$(cat "$F/.claude/runs")"
[ "$rc" = 0 ] && [ "$runs" = 2 ] && [ ! -f "$F/.claude/seat-intent" ] && pole P3 OK "restart relaunched once, then default stop (stub half; BOOT-ACK half is live-only)" || pole P3 FAIL "rc=$rc runs=$runs"
[ ! -s "$STUB_LOG" ] && pole P12 OK "relaunch is in-session: 0 tmux calls (same qualified name)" || pole P12 FAIL "tmux calls during loop"
rc="$(loop shutdown restart)"; runs="$(cat "$F/.claude/runs")"
[ "$rc" = 0 ] && [ "$runs" = 1 ] && pole P4 OK "shutdown ends the loop after 1 run" || pole P4 FAIL "rc=$rc runs=$runs"
rc="$(loop stale restart)"; runs="$(cat "$F/.claude/runs")"
[ "$rc" = 0 ] && [ "$runs" = 1 ] && [ ! -f "$F/.claude/seat-intent" ] && pole P5 OK "stale intent does not relaunch; marker consumed" || pole P5 FAIL "rc=$rc runs=$runs"
rc="$(loop restart restart restart restart)"; runs="$(cat "$F/.claude/runs")"
[ "$rc" = 3 ] && [ "$runs" = 4 ] && grep -q "SEAT-LOOP-HALT: foundation 3 restarts in 30 min" "$W/loop.out" \
  && pole P17 OK "4th restart in 30 min -> SEAT-LOOP-HALT, rc=3" || pole P17 FAIL "rc=$rc runs=$runs"
rc="$(loop restart none)"
grep -q "launch-line re-resolved changed=no" "$W/loop.out" && pole P-RR-SAME OK "unchanged stamp: relaunch logs changed=no (0377 s2.1)" || pole P-RR-SAME FAIL "rc=$rc $(grep -c re-resolved "$W/loop.out") re-resolved lines"
rm -f "$F/.claude/runs"; ( cd "$F" && env PATH="$W/cbin:$P" bash scripts/seat-loop.sh bash fake.sh ) < /dev/null > "$W/loop.out" 2>&1; rc=$?
[ "$rc" = 2 ] && [ ! -f "$F/.claude/runs" ] && pole P-RR-ARGV OK "a launch line given as argv is refused rc=2, nothing launched (frozen-argv form retired)" || pole P-RR-ARGV FAIL "rc=$rc"

# ---------- re-resolved launch line, end to end (poles 1-3; pole 1 is the red pole) ----------
# The loop line is the one launch-orc.sh actually sent (read from the tmux stub), run in the fixture with the
# `claude` stub; the stub edits the stamp during run 1. Run against HEAD's bytes before the cure (SUT_ROOT),
# poles RR-ADD and RR-HALT are red: the frozen argv relaunches without the flag, and relaunches on a broken stamp.
e2e() {  # e2e <fixture> <launch-orc args> -- <plan...>
  local d="$1" a=""; shift; while [ "$1" != -- ]; do a="$a $1"; shift; done; shift
  cp "$F/fake.sh" "$d/fake.sh"; printf '%s\n' "$@" > "$d/.claude/plan"; rm -f "$d/.claude/runs" "$d/.claude/argv" "$d/.claude/seat-intent"
  : > "$STUB_LOG"; : > "$STUB_SESSIONS"
  ( cd "$d" && env PATH="$P" bash launch-orc.sh --detach $a ) > "$W/launch.out" 2>&1
  local line; line="$(sed -n 's/^send-keys -t =[^ ]* exec \(.*\) C-m$/\1/p' "$STUB_LOG" | head -1)"
  [ -n "$line" ] || { echo "nolaunch"; return; }
  ( cd "$d" && env PATH="$W/cbin:$P" bash -c "$line" ) < /dev/null > "$W/loop.out" 2>&1; echo $?; }
argv() { sed -n "${2}p" "$1/.claude/argv" 2>/dev/null; }
F5="$W/fx5"; mkfix "$F5" foundation "project: ${PRJ}"
rc="$(e2e "$F5" -- restart:addrc none)"
case "$(argv "$F5" 1)" in *--remote-control*) a1=has ;; *) a1=lacks ;; esac
case "$(argv "$F5" 2)" in *"--remote-control ${PRJ}-foundation"*) a2=has ;; *) a2=lacks ;; esac
[ "$rc" = 0 ] && [ "$a1" = lacks ] && [ "$a2" = has ] && grep -q "changed=yes" "$W/loop.out" \
  && pole P-RR-ADD OK "stamp gains remote_control mid-run: relaunch carries --remote-control (changed=yes)" || pole P-RR-ADD FAIL "rc=$rc run1=$a1 run2=$a2"
F6="$W/fx6"; mkfix "$F6" foundation "project: ${PRJ}" "remote_control: true"
rc="$(e2e "$F6" -- restart:droprc none)"
case "$(argv "$F6" 1)" in *"--remote-control ${PRJ}-foundation"*) a1=has ;; *) a1=lacks ;; esac
case "$(argv "$F6" 2)" in *--remote-control*) a2=has ;; *) a2=lacks ;; esac
[ "$rc" = 0 ] && [ "$a1" = has ] && [ "$a2" = lacks ] && grep -q "changed=yes" "$W/loop.out" \
  && pole P-RR-DROP OK "stamp loses remote_control mid-run: relaunch drops the flag" || pole P-RR-DROP FAIL "rc=$rc run1=$a1 run2=$a2"
F7="$W/fx7"; mkfix "$F7" foundation "project: ${PRJ}" "remote_control: true"
rc="$(e2e "$F7" -- restart:breaklane restart)"; runs="$(cat "$F7/.claude/runs" 2>/dev/null)"
[ "$rc" = 4 ] && [ "$runs" = 1 ] && grep -q "SEAT-LOOP-HALT: .*re-resolution failed" "$W/loop.out" \
  && pole P-RR-HALT OK "unreadable stamp at relaunch: SEAT-LOOP-HALT rc=4, no relaunch" || pole P-RR-HALT FAIL "rc=$rc runs=$runs"
F8="$W/fx8"; mkfix "$F8" foundation "project: ${PRJ}"
rc="$(e2e "$F8" --auto-mode -- restart none)"
case "$(argv "$F8" 2)" in *"--permission-mode auto"*) a2=has ;; *) a2=lacks ;; esac
[ "$rc" = 0 ] && [ "$a2" = has ] && pole P-RR-MODE OK "launcher --auto-mode survives a relaunch" || pole P-RR-MODE FAIL "rc=$rc run2=$a2"

# ---------- launch-orc (P11, 4a remote control, 0317 §1 model) ----------
launch() { : > "$STUB_LOG"; : > "$STUB_SESSIONS"; ( cd "$1" && env PATH="$P" bash launch-orc.sh --detach ) > "$W/launch.out" 2>&1; echo $?; }
rc="$(launch "$F")"
grep -q "new-session -d -s ${PRJ}-foundation" "$STUB_LOG" && grep -q "send-keys -t =${PRJ}-foundation: exec bash scripts/seat-loop.sh --session ${PRJ}-foundation C-m" "$STUB_LOG" \
  && grep -q "^launch line  : claude --agent orc --remote-control ${PRJ}-foundation " "$W/launch.out" \
  && pole P11 OK "session ${PRJ}-foundation from the stamp; loop line sent" || pole P11 FAIL "rc=$rc $(tr '\n' ';' < "$STUB_LOG" | cut -c1-200)"
grep -q "^remote-control: requested ${PRJ}-foundation (configured)$" "$W/launch.out" && ! grep -qiE "remote-control:.*\bon\b" "$W/launch.out" \
  && pole P-RC OK "receipt: requested + (configured), never 'on'" || pole P-RC FAIL "$(grep remote-control "$W/launch.out")"
F2="$W/fx2"; mkfix "$F2" foundation "handoff: dispatch/LATEST.md"
rc="$(launch "$F2")"
[ "$rc" != 0 ] && ! grep -q new-session "$STUB_LOG" && grep -q "HALT" "$W/launch.out" \
  && pole P11-RED OK "absent project stamp -> HALT rc=$rc, no session created" || pole P11-RED FAIL "rc=$rc"
F3="$W/fx3"; mkfix "$F3" architect "project: ${PRJ}"
rc="$(launch "$F3")"
grep -q "^launch line  : claude --agent architect" "$W/launch.out" && ! grep -q -- "--model" "$W/launch.out" && grep -q "^remote-control: not requested" "$W/launch.out" \
  && pole P-MODEL OK "architect launches with no --model pin (def default governs)" || pole P-MODEL FAIL "$(grep 'launch line' "$W/launch.out" | cut -c1-160)"
# P-HOOK (window plan row 12; canon s4 an absent gate silently passes): red = no executable
# pre-commit hook -> HALT, no session; the non-executable variant must HALT too (presence alone is not the gate).
F4="$W/fx4"; mkfix "$F4" foundation "project: ${PRJ}"
rm -f "$F4/.git/hooks/pre-commit"
rc="$(launch "$F4")"
[ "$rc" != 0 ] && ! grep -q new-session "$STUB_LOG" && grep -q "HALT: no session created: pre-commit hook not installed" "$W/launch.out" \
  && pole P-HOOK OK "absent pre-commit hook -> HALT rc=$rc, no session created" || pole P-HOOK FAIL "rc=$rc $(head -1 "$W/launch.out")"
printf '#!/bin/sh\nexit 0\n' > "$F4/.git/hooks/pre-commit"; chmod -x "$F4/.git/hooks/pre-commit"
rc="$(launch "$F4")"
[ "$rc" != 0 ] && ! grep -q new-session "$STUB_LOG" && grep -q "pre-commit hook not installed" "$W/launch.out" \
  && pole P-HOOK-X OK "non-executable pre-commit hook -> HALT rc=$rc" || pole P-HOOK-X FAIL "rc=$rc"
echo "foundation" > "$STUB_SESSIONS"; : > "$STUB_LOG"
( cd "$F" && env PATH="$P" bash launch-orc.sh --detach ) > "$W/launch.out" 2>&1; rc=$?
[ "$rc" != 0 ] && ! grep -q new-session "$STUB_LOG" && pole P-DOUBLE OK "live bare 'foundation' refuses a qualified launch (cutover guard)" || pole P-DOUBLE FAIL "rc=$rc"

# ---------- seat-stop (P8) ----------
echo "${PRJ}-foundation" > "$STUB_SESSIONS"; : > "$STUB_LOG"; rm -f "$F/.claude/seat-intent"
( cd "$F" && env PATH="$P" bash scripts/seat-stop.sh foundation 1 ) > "$W/out" 2>&1; rc=$?
read -r k _ < "$F/.claude/seat-intent" 2>/dev/null || true
[ "$rc" = 0 ] && [ "${k:-}" = shutdown ] && grep -q "send-keys -t =${PRJ}-foundation: -l /exit" "$STUB_LOG" && grep -q "kill-session -t =${PRJ}-foundation" "$STUB_LOG" \
  && pole P8 OK "hung session: /exit, then kill-session after timeout; shutdown left on disk" || pole P8 FAIL "rc=$rc k=${k:-}"
: > "$STUB_LOG"
( cd "$F" && env PATH="$P" CLAUDE_CODE_CHILD_SESSION=1 bash scripts/seat-stop.sh foundation 1 ) > "$W/out" 2>&1; rc=$?
[ "$rc" = 2 ] && [ ! -s "$STUB_LOG" ] && pole P8-SEAT OK "refused inside a Claude Code session (seats never stop seats)" || pole P8-SEAT FAIL "rc=$rc"

# ---------- doorbell qualified-first (C7(c)) ---------- generic lane name (lane-a: lanes are keyed on the declared class, never an origin name)
printf '%s\n' "${PRJ}-lane-a:0.0|${PRJ}-lane-a|t" "lane-a:0.0|lane-a|t" > "$STUB_PANES"; : > "$STUB_LOG"
( cd "$F" && env PATH="$P" bash scripts/doorbell.sh ring lane-a ) > "$W/out" 2>&1
first="$(grep -m1 'send-keys' "$STUB_LOG" | awk '{print $3}')"
[ "$first" = "${PRJ}-lane-a:0.0" ] && pole P-DOORBELL OK "qualified name rung first" || pole P-DOORBELL FAIL "first target=[$first]"
printf '%s\n' "lane-a:0.0|lane-a|t" > "$STUB_PANES"; : > "$STUB_LOG"
( cd "$F" && env PATH="$P" bash scripts/doorbell.sh ring lane-a ) > "$W/out" 2>&1
first="$(grep -m1 'send-keys' "$STUB_LOG" | awk '{print $3}')"
[ "$first" = "lane-a:0.0" ] && grep -q "WARN(doorbell): C7 bare-name fallback" "$W/out" && pole P-DOORBELL-BARE OK "bare fallback rings with a named warning" || pole P-DOORBELL-BARE FAIL "first=[$first]"

# ---------- this worktree (P9, P10, P18) ----------
cmp -s "$REPO/launch-orc.sh" "$REPO/scripts/launch-orc.sh" && pole P9 OK "root launch-orc.sh == scripts/launch-orc.sh" || pole P9 FAIL "copies differ"
S="$REPO/.claude/settings.json"
# ORDER 1584: hook commands carry a cwd-independent prefix (deny hooks also a fail-closed tail), so these pins test containment of the binding, not string equality.
if jq -e '(.statusLine.command | contains("bash scripts/statusline-context.sh"))
  and ([.hooks.Stop[].hooks[].command] | any(.[]; contains("bash scripts/seat-b6-stop.sh")))
  and ([.hooks.Stop[].hooks[].command] | any(.[]; contains("bash scripts/creed-scan-spine.sh 2>&1 || true")))
  and ([.hooks.SessionStart[].hooks[].command] | any(.[]; contains("bash scripts/seat-boot-record.sh")))
  and ([.hooks.PreCompact[] | select(.matcher == "auto") | .hooks[].command] | any(.[]; contains("bash scripts/seat-precompact.sh")))
  and ([.hooks.PreCompact[] | select(.matcher != "auto")] | length == 0)' "$S" >/dev/null 2>&1; then
  miss=""; for s in statusline-context seat-b6-stop seat-boot-record seat-precompact seat-exit seat-loop seat-stop resolve-project; do [ -f "$REPO/scripts/$s.sh" ] || miss="$miss $s"; done
  [ -z "$miss" ] && pole P10 OK "settings wire statusLine+Stop(+creed kept)+SessionStart+PreCompact(auto only); 8 scripts present" || pole P10 FAIL "missing:$miss"
else pole P10 FAIL "settings.json wiring incomplete"; fi
ign=0; for f in context-pct seat-intent b6-injected seat-boot.log e11-tokens.log seat-exit-sent seat-loop.log; do git -C "$REPO" check-ignore -q ".claude/$f" && ign=$((ign + 1)); done
[ "$ign" = 7 ] && pole P18 OK "7 of 7 state files gitignored (the 3 ruled + 4 added)" || pole P18 FAIL "$ign of 7 ignored"

# ---------- C7(c) bare census (informational) ----------
lanes="$(awk -F'|' 'NR>2 && $2 ~ /[a-z]/ {gsub(/ /,"",$2); sub(/\(.*/,"",$2); print $2}' "$REPO/_orchestration/lane-provisioning.md" 2>/dev/null | head -7)"
live="$(command tmux list-sessions -F '#{session_name}' 2>/dev/null)"
bare=0; tot=0; for l in $lanes; do tot=$((tot + 1)); printf '%s\n' "$live" | grep -qx -- "$l" && bare=$((bare + 1)); done
echo "BARE-CENSUS: $bare of $tot lane ids have a live bare-named tmux session (C7(c) fallback removed at 0)"

echo "SEAT-RESTART-POLES: $OKN/$N poles OK"
[ "$OKN" = "$N" ]
