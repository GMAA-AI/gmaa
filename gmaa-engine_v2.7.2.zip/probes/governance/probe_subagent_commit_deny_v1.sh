#!/usr/bin/env bash
# probes/governance/probe_subagent_commit_deny_v1.sh — canon 1.3: a subagent never commits or pushes, and no agent-team
# primitive is enabled. Two halves, one verdict.
#  A. HOOK POLES (synthetic PreToolUse stdin through scripts/subagent-commit-deny.sh): subagent+commit deny, subagent+
#     `git -C /x push` deny, env-prefixed/chained/nested forms deny, subagent+status allow, hub (agent_type=orc, no
#     agent_id)+commit allow, jq-less/garbled stdin with an agent_id fails closed; one pole per wrapped/quoted/keyword-led
#     shape ("git", \git, nice, timeout, { }, if/then) denies, and the same wrappers around a read-only git allow. Plus
#     the hook is BOUND on the Bash PreToolUse matcher in .claude/settings.json.
#  B. AGENT-TEAMS OFF: CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS must not be "1" in tracked .claude/settings.json env, in a
#     present .claude/settings.local.json, in the process env, or in the user ~/.claude/settings.json when readable.
#     Sources it CANNOT see are printed UNREADABLE-SOURCE (managed settings, a --settings payload): named, not a verdict.
#  SELF-REDS: a copy of the hook with the agent_id check removed must turn the hub pole red; a copy with the push pattern
#     removed must turn the push pole red; a fixture settings.json carrying the flag must turn the teams pole red.
# Exit 0 PASS · 1 FAIL · 3 UNREADABLE.   Env: SCD_HOOK (hook path override), SCD_SETTINGS (settings.json override).
set -u
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "SUBAGENT-COMMIT-DENY: UNREADABLE -- not in a git worktree"; exit 3; }
command -v jq >/dev/null 2>&1 || { echo "SUBAGENT-COMMIT-DENY: UNREADABLE -- jq missing"; exit 3; }
HOOK_REAL="${SCD_HOOK:-$ROOT/scripts/subagent-commit-deny.sh}"
[ -f "$HOOK_REAL" ] || { echo "SUBAGENT-COMMIT-DENY: UNREADABLE -- $HOOK_REAL absent"; exit 3; }
SET_REAL="${SCD_SETTINGS:-$ROOT/.claude/settings.json}"
[ -f "$SET_REAL" ] || { echo "SUBAGENT-COMMIT-DENY: UNREADABLE -- $SET_REAL absent"; exit 3; }
D="$(mktemp -d "${TMPDIR:-/tmp}/scdprobe.XXXXXX")" || { echo "SUBAGENT-COMMIT-DENY: UNREADABLE -- mktemp failed"; exit 3; }
trap 'rm -rf "$D"' EXIT
FAILS=0; NP=0
res() { NP=$((NP+1)); if [ "$2" = ok ]; then echo "POLE $1: PASS"; else FAILS=$((FAILS+1)); echo "POLE $1: FAIL"; fi; }

# hook <script> <json-stdin> -> prints DENY or ALLOW
hook() { out="$(printf '%s' "$2" | bash "$1" 2>/dev/null)"; rc=$?
  if printf '%s' "$out" | jq -e '.hookSpecificOutput.permissionDecision=="deny"' >/dev/null 2>&1; then echo DENY
  elif [ $rc -eq 0 ] && [ -z "$out" ]; then echo ALLOW; else echo "OTHER($rc)"; fi; }
sub() { jq -cn --arg c "$1" '{session_id:"s1",agent_id:"ag1",agent_type:"general-purpose",tool_name:"Bash",tool_input:{command:$c}}'; }
hubj() { jq -cn --arg c "$1" '{session_id:"s1",agent_type:"orc",tool_name:"Bash",tool_input:{command:$c}}'; }

run_poles() { # <hook> <prefix-label-suffix>; echoes poles, sets via res
  H="$1"; sfx="$2"
  [ "$(hook "$H" "$(sub 'git commit -m x')")" = DENY ] && res "subagent-commit-deny$sfx" ok || res "subagent-commit-deny$sfx" bad
  [ "$(hook "$H" "$(sub 'git -C /x push origin main')")" = DENY ] && res "subagent-push-deny$sfx" ok || res "subagent-push-deny$sfx" bad
  [ "$(hook "$H" "$(sub 'git status')")" = ALLOW ] && res "subagent-status-allow$sfx" ok || res "subagent-status-allow$sfx" bad
  [ "$(hook "$H" "$(hubj 'git commit -m x')")" = ALLOW ] && res "hub-commit-allow$sfx" ok || res "hub-commit-allow$sfx" bad
}
run_poles "$HOOK_REAL" ""
# extra forms (real hook only)
ok=1
for c in 'FOO=1 git commit -m x' 'cd /x && git push' 'git -c user.name=a commit -am y' 'echo hi; git commit --amend' 'env GIT_AUTHOR_NAME=a git push' 'bash -c "git commit -m z"' 'git commit-tree HEAD^{tree}'; do
  [ "$(hook "$HOOK_REAL" "$(sub "$c")")" = DENY ] || { ok=0; echo "  form not denied: $c"; }
done
[ $ok = 1 ] && res "subagent-forms-deny" ok || res "subagent-forms-deny" bad
ok=1
for c in 'git log --oneline -5' 'git diff HEAD' 'git -C /x status' 'ls -la' 'echo committed'; do
  [ "$(hook "$HOOK_REAL" "$(sub "$c")")" = ALLOW ] || { ok=0; echo "  form not allowed: $c"; }
done
[ $ok = 1 ] && res "subagent-readonly-forms-allow" ok || res "subagent-readonly-forms-allow" bad
# One pole per wrapped, quoted or keyword-led shape: after quote and backslash stripping, shell keywords and wrappers,
# a segment whose command is git + a refused subcommand is denied.
for sh in 'quoted-git|"git" commit -m x' 'backslash-git|\git commit -m x' 'nice-wrapper|nice git commit -m x' \
          'timeout-wrapper|timeout 5 git commit -m x' 'brace-group|{ git commit -m x; }' 'if-then|if true; then git commit -m x; fi'; do
  lab="${sh%%|*}"; c="${sh#*|}"
  [ "$(hook "$HOOK_REAL" "$(sub "$c")")" = DENY ] && res "subagent-shape-$lab-deny" ok || res "subagent-shape-$lab-deny" bad
done
# ...and the same wrappers around a read-only git, or git named as text, stay ALLOW (no over-reach).
ok=1
for c in 'nice git status' 'timeout 5 git diff' '{ git status; }' 'if true; then git log; fi' 'grep -n "git commit" notes.md' 'echo "git push"'; do
  [ "$(hook "$HOOK_REAL" "$(sub "$c")")" = ALLOW ] || { ok=0; echo "  form not allowed: $c"; }
done
[ $ok = 1 ] && res "subagent-wrapped-readonly-allow" ok || res "subagent-wrapped-readonly-allow" bad
# relay 1586a (auditor 5267578a F1): a wrapper named by path, an ANSI-C quoted git, and a wrapper whose argument is the
# word git each deny; the same shapes around a read-only git allow.
for sh in 'abs-nice-wrapper|/usr/bin/nice git commit -m x' 'abs-env-wrapper|/usr/bin/env git commit -m x' \
          'ansi-c-quoted-git|$'\''git'\'' commit -m x' 'sudo-user-git|sudo -u git git commit -m x'; do
  lab="${sh%%|*}"; c="${sh#*|}"
  [ "$(hook "$HOOK_REAL" "$(sub "$c")")" = DENY ] && res "subagent-shape-$lab-deny" ok || res "subagent-shape-$lab-deny" bad
done
ok=1
for c in '/usr/bin/nice git status' '/usr/bin/env git log' '$'\''git'\'' status' 'sudo -u git git status' 'sudo -u git ls'; do
  [ "$(hook "$HOOK_REAL" "$(sub "$c")")" = ALLOW ] || { ok=0; echo "  form not allowed: $c"; }
done
[ $ok = 1 ] && res "subagent-residual-readonly-allow" ok || res "subagent-residual-readonly-allow" bad
# unparseable stdin: with an agent_id shown -> deny (fail closed); without -> allow
[ "$(hook "$HOOK_REAL" '{"agent_id":"ag1","tool_input":{"command":"git commit"')" = DENY ] && res "garbled-with-agent_id-fails-closed" ok || res "garbled-with-agent_id-fails-closed" bad
[ "$(hook "$HOOK_REAL" 'not json at all')" = ALLOW ] && res "garbled-without-agent_id-allows" ok || res "garbled-without-agent_id-allows" bad
# bound in settings.json on the Bash PreToolUse matcher
if jq -e '[.hooks.PreToolUse[] | select(.matcher=="Bash") | .hooks[].command] | any(test("scripts/subagent-commit-deny\\.sh"))' "$SET_REAL" >/dev/null 2>&1
then res "hook-bound-PreToolUse-Bash" ok; else res "hook-bound-PreToolUse-Bash" bad; fi

# SELF-REDS on mutated copies of the hook
sed 's/^\[ -n "\$AID" \] || exit 0$/:/' "$HOOK_REAL" > "$D/red-noaid.sh"
cmp -s "$HOOK_REAL" "$D/red-noaid.sh" && { echo "RED-1 UNREADABLE -- mutation did not change the hook"; exit 3; }
[ "$(hook "$D/red-noaid.sh" "$(hubj 'git commit -m x')")" != ALLOW ] && echo "RED-1 (agent_id check removed): hub-commit-allow turns FAIL -- as required" || { echo "RED-1: hub pole stayed green"; FAILS=$((FAILS+1)); }
sed "s/^BAD='.*'\$/BAD='^(commit|commit-tree)\$'/" "$HOOK_REAL" > "$D/red-nopush.sh"
cmp -s "$HOOK_REAL" "$D/red-nopush.sh" && { echo "RED-2 UNREADABLE -- mutation did not change the hook"; exit 3; }
[ "$(hook "$D/red-nopush.sh" "$(sub 'git -C /x push origin main')")" != DENY ] && echo "RED-2 (push pattern removed): subagent-push-deny turns FAIL -- as required" || { echo "RED-2: push pole stayed green"; FAILS=$((FAILS+1)); }

# B. agent-teams-off
FLAG=CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS
teams_in() { jq -r --arg k "$FLAG" '.env[$k] // empty | tostring' "$1" 2>/dev/null; }
teams_check() { # <settings-file> <label> -> 0 off, 1 on
  v="$(teams_in "$1")"; if [ "$v" = "1" ]; then echo "  $2: $FLAG=1 (ON)"; return 1; fi; echo "  $2: not 1 (value='${v:-unset}')"; return 0; }
echo "AGENT-TEAMS sources:"
TOK=0
teams_check "$SET_REAL" "tracked .claude/settings.json" || TOK=1
LOCAL="$ROOT/.claude/settings.local.json"
if [ -f "$LOCAL" ]; then teams_check "$LOCAL" ".claude/settings.local.json (present)" || TOK=1; else echo "  .claude/settings.local.json: absent in this worktree"; fi
if [ "${!FLAG:-}" = "1" ]; then echo "  process env: $FLAG=1 (ON)"; TOK=1; else echo "  process env: not 1 (value='${!FLAG:-unset}')"; fi
USET="${CLAUDE_CONFIG_DIR:-$HOME/.claude}/settings.json"   # the session's config dir
if [ -r "$USET" ]; then teams_check "$USET" "user $USET (readable)" || TOK=1; else echo "  user $USET: UNREADABLE-SOURCE (absent or unreadable)"; fi
echo "  managed settings: UNREADABLE-SOURCE (outside the repo; not provable from here)"
echo "  --settings payload / CLI flags of the launching command: UNREADABLE-SOURCE (not visible to a hook-side probe)"
[ $TOK = 0 ] && res "agent-teams-off" ok || res "agent-teams-off" bad
# red: fixture carrying the flag must read ON
jq '.env += {"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS":"1"}' "$SET_REAL" > "$D/fixture-teams-on.json" 2>/dev/null
if teams_check "$D/fixture-teams-on.json" "RED-3 fixture" >/dev/null; then echo "RED-3: fixture with the flag read OFF"; FAILS=$((FAILS+1)); else echo "RED-3 (fixture settings.json plants $FLAG=1): agent-teams-off turns FAIL -- as required"; fi

echo "SUBAGENT-COMMIT-DENY: ${NP} poles, ${FAILS} FAIL (source ${ROOT})"
if [ $FAILS -eq 0 ]; then echo "VERDICT: PASS"; exit 0; fi
echo "VERDICT: FAIL"; exit 1
