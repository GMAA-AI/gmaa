#!/bin/bash
# probes/governance/probe_hub_reachability.sh — every lane can ring the hub under the hub's CURRENT session name.
# Architect relay 2026-10-01-22: the SET-0126 hub rename landed before any lane had the resolver, so every
# lane->foundation bell rang 0 panes. Pole: a hub-side rename must not land before every lane resolves it.
# Pure and deterministic: no tmux, no ring. For each lane worktree it derives the session name that THAT
# worktree's doorbell would ring for lane `foundation`, using the same rule as doorbell.sh resolve_target:
#   qualified `<project>-foundation` when the worktree has a project stamp AND its doorbell qualifies names,
#   else bare `foundation`.
# The hub's name comes from the NAMER, not the ringer (auditor 12535d8a F1): the `SESSION="..."` template in the
# hub's scripts/launch-orc.sh, with $PROJECT = the hub's stamp and $LANE = foundation. The ringer's rule applied to
# the hub must equal it too, else a launcher-only rename would pass. A template that is absent, duplicated, or
# carries any other `$` reference is UNREADABLE (never guessed).
# Usage: probe_hub_reachability.sh [<lane-worktree> ...]   (default: every sibling worktree of this repo,
#        excluding this one and nested agent-worktree trees under the .claude directory). HUB_REACH_HUB=<dir> substitutes the hub
#        worktree (fixtures only).
# Exit 0 = every lane reaches the hub · 1 = at least one lane would ring a different name · 3 = UNREADABLE.
set -u
HUB="${HUB_REACH_HUB:-$(git rev-parse --show-toplevel)}" || { echo "HUB-REACH: UNREADABLE (not in a worktree)"; exit 3; }

ring_name() {  # <worktree> -> the session name its doorbell rings for lane `foundation`
  local w="$1" proj
  proj="$(bash "$w/scripts/resolve-project.sh" "$w" 2>/dev/null)"; proj="${proj#project=}"
  if [ -n "$proj" ] && [ -f "$w/scripts/doorbell.sh" ] && grep -q 'qual="$proj-$lane"' "$w/scripts/doorbell.sh"; then
    printf '%s-foundation\n' "$proj"
  else
    printf 'foundation\n'
  fi
}

namer_name() {  # <hub worktree> -> the session name its launcher creates for lane `foundation`, or nonzero
  local w="$1" n tpl proj
  [ -f "$w/scripts/launch-orc.sh" ] || return 1
  n="$(grep -cE '^[[:space:]]*SESSION="[^"]*"[[:space:]]*$' "$w/scripts/launch-orc.sh")"
  [ "$n" -eq 1 ] || return 1
  tpl="$(sed -nE 's/^[[:space:]]*SESSION="([^"]*)"[[:space:]]*$/\1/p' "$w/scripts/launch-orc.sh")"
  proj="$(bash "$w/scripts/resolve-project.sh" "$w" 2>/dev/null)"; proj="${proj#project=}"
  case "$tpl" in *'$PROJECT'*|*'${PROJECT}'*) [ -n "$proj" ] || return 1 ;; esac
  tpl="${tpl//\$\{PROJECT\}/$proj}"; tpl="${tpl//\$PROJECT/$proj}"
  tpl="${tpl//\$\{LANE\}/foundation}"; tpl="${tpl//\$LANE/foundation}"
  case "$tpl" in *'$'*|'') return 1 ;; esac
  printf '%s\n' "$tpl"
}

HUBNAME="$(namer_name "$HUB")" || { echo "HUB-REACH: UNREADABLE (hub launcher $HUB/scripts/launch-orc.sh: no single resolvable SESSION= template)"; exit 3; }
HUBRING="$(ring_name "$HUB")"
if [ "$HUBRING" != "$HUBNAME" ]; then
  echo "  hub: FAIL (launch-orc.sh names '$HUBNAME', the ring rule derives '$HUBRING')"
  HUBFAIL=1
else
  HUBFAIL=0
fi
if [ $# -gt 0 ]; then
  LANES=("$@")
else
  LANES=()
  while IFS= read -r w; do
    [ "$w" = "$HUB" ] && continue
    case "$w" in */.claude/worktrees/*) continue ;; esac
    LANES+=("$w")
  done < <(git worktree list --porcelain | awk '/^worktree /{print substr($0,10)}')
fi
[ ${#LANES[@]} -gt 0 ] || { echo "HUB-REACH: UNREADABLE (0 lane worktrees found; a census of zero is not a PASS)"; exit 3; }

OK=0; N=0
for w in "${LANES[@]}"; do
  N=$((N+1))
  [ -f "$w/_boot/BOOTSTRAP.md" ] || { echo "  $w: FAIL (no _boot/BOOTSTRAP.md)"; continue; }
  got="$(ring_name "$w")"
  if [ "$got" = "$HUBNAME" ]; then OK=$((OK+1)); echo "  $(basename "$w"): OK (rings $got)"
  else echo "  $(basename "$w"): FAIL (rings '$got', hub is '$HUBNAME')"; fi
done
echo "HUB-REACH: $OK/$N lanes ring the hub as '$HUBNAME' (named by launch-orc.sh; hub ring rule $([ "$HUBFAIL" -eq 0 ] && echo agrees || echo DISAGREES))"
[ "$OK" -eq "$N" ] && [ "$HUBFAIL" -eq 0 ] && exit 0 || exit 1
