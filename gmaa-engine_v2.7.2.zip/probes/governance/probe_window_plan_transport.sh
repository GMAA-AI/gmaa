#!/usr/bin/env bash
# probes/governance/probe_window_plan_transport.sh — red/green poles for the 2.7 window plan transport rows
# (the 2.7 window plan: each member carries a red pole against the canon
# teaching on its row). Zero model calls. Runs the REAL scripts inside a shared clone, never the live hub:
# a live `inboxf.sh check` rewrites the hub's shown-snapshot, which bounds `consume --all` (canon s5).
#
#   W3        row 3, canon s5 truthful empty + s2 HALT-LOUD: an unreadable lane manifest HALTs rc=3 with an
#             UNREADABLE line naming the read; it never prints `empty`.
#   W3-ZERO   row 3: a manifest that parses to 0 declared lanes HALTs rc=3 the same way.
#   W3-GREEN  control: the real manifest still sweeps (INBOXF-CHECK line, no UNREADABLE).
#
# Usage: bash probes/governance/probe_window_plan_transport.sh   -> last line WINDOW-TRANSPORT: N/M poles OK
set -u
REPO="$(git rev-parse --show-toplevel)" || { echo "WINDOW-TRANSPORT: UNREADABLE (not a git worktree)"; exit 3; }
# the fixture's spine ref and trunk come from the ONE resolver of the tree under test (the one spine-ref resolver), never a
# literal trunk, so the probe reads at an adopter as it reads at origin. Unresolvable = UNREADABLE, named.
SR="$(bash "$REPO/scripts/spine-ref.sh")" && [ -n "$SR" ] \
  || { echo "WINDOW-TRANSPORT: UNREADABLE (SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled; the one spine-ref resolver)"; exit 3; }
TRUNK="${SR#origin/}"
W="$(mktemp -d "${TMPDIR:-/tmp}/wpt.XXXXXX")"
trap 'rm -rf "$W"' EXIT
OK=0; N=0
pole() { N=$((N+1)); [ "$2" = OK ] && OK=$((OK+1)); echo "POLE $1: $2 $3"; }

# Resolve the lanes this probe needs from the live manifest at runtime (0376 §1: a replica probe whose
# input is the live record reads lane names from the manifest, never hard-coded) — by DECLARED CLASS,
# never by name, so the probe keeps exercising the real origin refs under any future roster:
#   MOD_LANE/MOD_BRANCH   the first DENY lane whose branch follows module/<lane>  (the common module shape)
#   ALT_LANE/ALT_BRANCH   the first DENY lane whose branch does NOT (the D-21 counter-example this probe's
#                         own W8 exists to catch: a `module/$lane` guess must not be trusted)
#   EXEC_LANE/EXEC_BRANCH the apply-receipts-only lane
. "$REPO/scripts/lane-surface.sh" || { echo "WINDOW-TRANSPORT: UNREADABLE (lane-surface.sh)"; exit 3; }
lane_manifest_load || { echo "WINDOW-TRANSPORT: UNREADABLE (lane manifest: $LANE_MANIFEST_ERROR)"; exit 3; }
MOD_LANE="" MOD_BRANCH="" ALT_LANE="" ALT_BRANCH="" EXEC_LANE="" EXEC_BRANCH=""
while IFS= read -r l; do
    c="$(lane_class "$l")" || continue
    b="$(lane_branch "$l")" || continue
    case "$c" in
        DENY)
            case "$b" in
                module/*) [ -z "$MOD_LANE" ] && { MOD_LANE="$l"; MOD_BRANCH="$b"; } ;;
                *)        [ -z "$ALT_LANE" ] && { ALT_LANE="$l"; ALT_BRANCH="$b"; } ;;
            esac ;;
        apply-receipts-only)
            [ -z "$EXEC_LANE" ] && { EXEC_LANE="$l"; EXEC_BRANCH="$b"; } ;;
    esac
done < <(lane_roster)
[ -n "$MOD_LANE" ]  || { echo "WINDOW-TRANSPORT: UNREADABLE (no DENY lane on a module/<lane> branch declared)"; exit 3; }
[ -n "$ALT_LANE" ]  || { echo "WINDOW-TRANSPORT: UNREADABLE (no DENY lane on a non-module/ branch declared)"; exit 3; }
[ -n "$EXEC_LANE" ] || { echo "WINDOW-TRANSPORT: UNREADABLE (no apply-receipts-only lane declared)"; exit 3; }

C="$W/clone"
git clone -q --shared "$REPO" "$C" || { echo "WINDOW-TRANSPORT: UNREADABLE (clone failed)"; exit 3; }
git -C "$C" checkout -q -B "$TRUNK" "$(git -C "$REPO" rev-parse HEAD)" || { echo "WINDOW-TRANSPORT: UNREADABLE (checkout)"; exit 3; }
# the probe judges the WORKING-TREE scripts (the member under test), on the committed manifest
for s in inboxf.sh inbox.sh lane-surface.sh consume-core.sh resolve-lane.sh; do cp "$REPO/scripts/$s" "$C/scripts/$s"; done
mkdir -p "$C/.claude" "$W/xp"
hub() { ( cd "$C" && env XP_DIR="$W/xp" "$@" bash scripts/inboxf.sh check ) > "$W/out" 2>&1; echo $?; }

# W3: the manifest read fails (a ref that does not exist)
rc="$(hub LANE_SURFACE_REF=origin/no-such-ref-wpt)"
[ "$rc" = 3 ] && grep -q "^INBOXF-CHECK: foundation UNREADABLE (lane manifest: git show origin/no-such-ref-wpt:" "$W/out" \
  && ! grep -q "empty" "$W/out" \
  && pole W3 OK "unreadable manifest -> rc=3, UNREADABLE line, no 'empty'" || pole W3 FAIL "rc=$rc $(tail -1 "$W/out")"

# W3-ZERO: the manifest exists but declares 0 lanes (objects only; no ref is written)
blob="$(printf '# lane provisioning\n\nno table here\n' | git -C "$C" hash-object -w --stdin)"
orch="$(printf '100644 blob %s\tlane-provisioning.md\n' "$blob" | git -C "$C" mktree)"
root="$(printf '040000 tree %s\t_orchestration\n' "$orch" | git -C "$C" mktree)"
zc="$(git -C "$C" -c user.name=p -c user.email=p@p commit-tree "$root" -m wpt-zero)"
rc="$(hub LANE_SURFACE_REF="$zc")"
[ "$rc" = 3 ] && grep -q "^INBOXF-CHECK: foundation UNREADABLE (lane manifest: .*parsed to 0 declared lanes)" "$W/out" \
  && ! grep -q "empty" "$W/out" \
  && pole W3-ZERO OK "0-lane manifest -> rc=3, UNREADABLE line, no 'empty'" || pole W3-ZERO FAIL "rc=$rc $(tail -1 "$W/out")"

# W3-GREEN: control on the real manifest
rc="$(hub LANE_SURFACE_REF="$SR")"
grep -q "^INBOXF-CHECK: foundation " "$W/out" && ! grep -q "UNREADABLE (lane manifest" "$W/out" \
  && pole W3-GREEN OK "real manifest sweeps (rc=$rc)" || pole W3-GREEN FAIL "rc=$rc $(tail -1 "$W/out")"

# W1 (row 1, canon s5: consume --all may mark only what the check displayed): a mail that lands between two
# sweeps must not enter the shown-snapshot unprinted. A `find` shim lists XP, then drops late.md on its FIRST
# call only, so a second sweep inside the same check would see it.
mkdir -p "$W/bin"; : > "$W/findcount"
cat > "$W/bin/find" <<SHIM
#!/bin/sh
/usr/bin/find "\$@"
n=\$(wc -l < "$W/findcount"); echo x >> "$W/findcount"
[ "\$n" -eq 0 ] && printf 'TO: foundation\n\nlate\n' > "$W/xp/late.md"
exit 0
SHIM
chmod +x "$W/bin/find"
printf 'TO: foundation\n\nearly\n' > "$W/xp/early.md"
rm -f "$C/.claude/inboxf-seen" "$C/.claude/inboxf-shown" "$W/xp/early.md"
( cd "$C" && env XP_DIR="$W/xp" bash scripts/inboxf.sh seed ) > /dev/null 2>&1   # every lane item seen: only XP is pending
printf 'TO: foundation\n\nearly\n' > "$W/xp/early.md"
rc="$(hub PATH="$W/bin:$PATH" LANE_SURFACE_REF="$SR")"
printed_late="$(grep -cE '^NEW  xp +late\.md$' "$W/out" || true)"
shown_late="$(grep -cxF "$(printf 'xp\tlate.md')" "$C/.claude/inboxf-shown" 2>/dev/null || true)"
shown_early="$(grep -cxF "$(printf 'xp\tearly.md')" "$C/.claude/inboxf-shown" 2>/dev/null || true)"
[ "$printed_late" = 0 ] && [ "$shown_late" = 0 ] && [ "$shown_early" = 1 ] && grep -q 'NEW  xp *early.md' "$W/out" \
  && pole W1 OK "shown-snapshot == printed NEW lines (early shown+printed; late neither)" \
  || pole W1 FAIL "late printed=$printed_late shown=$shown_late; early shown=$shown_early"

# W2 (row 2, canon s4 one rule one carrier): the hub's consume --all intersects with still-pending, like the
# spoke. early.md was shown; it leaves the source; consume --all must consume 0 and leave it unmarked.
rm -f "$W/xp/early.md" "$W/xp/late.md"
( cd "$C" && env XP_DIR="$W/xp" bash scripts/inboxf.sh consume --all --premise holds@wpt ) > "$W/out" 2>&1
grep -q "^INBOXF-CONSUMED: 0 item" "$W/out" && ! grep -qxF "$(printf 'xp\tearly.md')" "$C/.claude/inboxf-seen" 2>/dev/null \
  && pole W2 OK "shown-but-no-longer-pending -> 0 consumed (SHOWN ∩ pending, one carrier)" \
  || pole W2 FAIL "$(tail -1 "$W/out"); seen=$(grep -c early.md "$C/.claude/inboxf-seen" 2>/dev/null)"
grep -q "core_consume_all" "$REPO/scripts/inbox.sh" && ! grep -q 'grep -qxF "$f"' "$REPO/scripts/inbox.sh" \
  && pole W2-ONE OK "spoke --all delegates to core_consume_all (no second copy of the intersection)" \
  || pole W2-ONE FAIL "inbox.sh still carries its own intersection"

# W4 (row 4, canon s4 HEAD readback): a spoke reads the spine at origin/main, never a local `main` mirror.
# The resolved DENY module-branch lane is checked out; a relay exists ONLY at origin/main (objects + a
# clone-local ref update).
S="$W/spoke"
git clone -q --shared "$REPO" "$S" && git -C "$S" checkout -q -B "$MOD_BRANCH" "origin/$MOD_BRANCH" \
  || { echo "WINDOW-TRANSPORT: UNREADABLE (spoke clone)"; exit 3; }
for s in inbox.sh consume-core.sh resolve-lane.sh lane-surface.sh; do cp "$REPO/scripts/$s" "$S/scripts/$s"; done
mkdir -p "$S/.claude"
git -C "$S" branch -q -f "$TRUNK" "$SR"
rb="$(printf 'FROM: orc-foundation\nTO: orc-%s\n\nwpt only at the spine ref\n' "$MOD_LANE" | git -C "$S" hash-object -w --stdin)"
idx="$W/idx"; GIT_INDEX_FILE="$idx" git -C "$S" read-tree "$SR"
GIT_INDEX_FILE="$idx" git -C "$S" update-index --add --cacheinfo "100644,$rb,_orchestration/relay-inbox/${MOD_LANE}/9999-wpt-origin-only.md"
nt="$(GIT_INDEX_FILE="$idx" git -C "$S" write-tree)"
nc="$(git -C "$S" -c user.name=p -c user.email=p@p commit-tree "$nt" -p "$SR" -m wpt-origin-only)"
git -C "$S" update-ref "refs/remotes/$SR" "$nc"
( cd "$S" && bash scripts/inbox.sh check ) > "$W/out" 2>&1; rc=$?
grep -q "9999-wpt-origin-only.md" "$W/out" && grep -q "wpt only at the spine ref" "$W/out" \
  && pole W4 OK "spoke shows + inlines a relay present only at the spine ref (rc=$rc)" \
  || pole W4 FAIL "rc=$rc $(grep -m1 INBOX-CHECK "$W/out")"

# W6 (row 6, canon s5: fail-open must not re-include the class it was built to drop): a note addressed to
# another seat "via operator" is not shown; a note to foundation is (control).
rm -f "$W/xp/"*.md "$C/.claude/inboxf-seen"
( cd "$C" && env XP_DIR="$W/xp" bash scripts/inboxf.sh seed ) > /dev/null 2>&1
printf 'FROM: origin foundation\nTO: gmaa packaging seat (operator-run)\n\nx\n' > "$W/xp/w6-own-outbound.md"
printf 'FROM: architect\nTO: orc-foundation\n\nx\n' > "$W/xp/w6-to-us.md"
rc="$(hub LANE_SURFACE_REF="$SR")"
! grep -q "w6-own-outbound.md" "$W/out" && grep -q "NEW  xp *w6-to-us.md" "$W/out" \
  && pole W6 OK "'TO: ... operator' note filtered; 'TO: orc-foundation' shown" \
  || pole W6 FAIL "$(grep -c w6- "$W/out") w6 lines shown"

# W15 (row 15, canon s5 + s7.4): a seen XP note is not re-opened. 5 notes are consumed, 1 is new; a grep shim
# counts header parses of XP notes during one check: exactly 1.
( cd "$C" && env XP_DIR="$W/xp" bash scripts/inboxf.sh consume --all --premise holds@wpt ) > /dev/null 2>&1
for i in 1 2 3 4; do printf 'TO: orc-foundation\n\nold\n' > "$W/xp/w15-old-$i.md"; done
( cd "$C" && env XP_DIR="$W/xp" bash scripts/inboxf.sh check ) > /dev/null 2>&1
( cd "$C" && env XP_DIR="$W/xp" bash scripts/inboxf.sh consume --all --premise holds@wpt ) > /dev/null 2>&1
printf 'TO: orc-foundation\n\nnew\n' > "$W/xp/w15-new.md"
REALGREP="$(command -v grep)"; : > "$W/greplog"
mkdir -p "$W/gbin"
cat > "$W/gbin/grep" <<SHIM
#!/bin/sh
for a in "\$@"; do case "\$a" in "$W/xp/"*) echo "\$a" >> "$W/greplog";; esac; done
exec "$REALGREP" "\$@"
SHIM
chmod +x "$W/gbin/grep"
rc="$(hub PATH="$W/gbin:$PATH" LANE_SURFACE_REF="$SR")"
parses="$(wc -l < "$W/greplog" | tr -d ' ')"
[ "$parses" = 1 ] && grep -q "w15-new.md" "$W/greplog" && grep -q "NEW  xp *w15-new.md" "$W/out" \
  && pole W15 OK "1 header parse for 1 new note among 6 (seen notes not re-opened)" \
  || pole W15 FAIL "parses=$parses ($(tr '\n' ' ' < "$W/greplog" | sed "s#$W/xp/##g"))"

# W13 (row 13, canon s4: a meaningful probe, not an unbounded tax): one hub check reads the lane manifest ONCE.
REALGIT="$(command -v git)"; : > "$W/gitlog"
cat > "$W/gbin/git" <<SHIM
#!/bin/sh
case "\$*" in *lane-provisioning.md*) echo "\$*" >> "$W/gitlog";; esac
exec "$REALGIT" "\$@"
SHIM
chmod +x "$W/gbin/git"
rc="$(hub PATH="$W/gbin:$PATH" LANE_SURFACE_REF="$SR")"
reads="$(wc -l < "$W/gitlog" | tr -d ' ')"
[ "$reads" = 1 ] && pole W13 OK "1 manifest read per hub check" || pole W13 FAIL "manifest reads=$reads"

# W14 (row 14; canon s5: the sweep reads the authorized message surface): the resolved apply-receipts-only
# lane's mail lives in ledger/apply-receipts/relay/. Its origin branch gains 4 files (objects + a
# clone-local ref update).
rm -f "$W/xp/"*.md
( cd "$C" && env XP_DIR="$W/xp" bash scripts/inboxf.sh seed ) > /dev/null 2>&1
# the live hub has every pre-cutover apply-receipts-only-lane file seen (0 of 667 unseen at the cutover):
# mirror that state
git -C "$C" ls-tree -r --name-only "origin/$EXEC_BRANCH" -- ledger/apply-receipts/ | sed 's#.*/##' \
  | awk -v l="$EXEC_LANE" '{print l"\t"$0}' >> "$C/.claude/inboxf-seen"
idx2="$W/idx2"; GIT_INDEX_FILE="$idx2" git -C "$C" read-tree "origin/$EXEC_BRANCH"
addf() { local b; b="$(printf '%b' "$2" | git -C "$C" hash-object -w --stdin)"
         GIT_INDEX_FILE="$idx2" git -C "$C" update-index --add --cacheinfo "100644,$b,ledger/apply-receipts/$1"; }
addf "R-wpt-receipt.md"            'receipt body\n'
addf "relay/RETURN-wpt-msg.md"     "FROM: ${EXEC_LANE}\nTO: orc-foundation\n\nmsg\n"
addf "SURFACE-wpt-misfiled.md"     "FROM: ${EXEC_LANE}\n\nno to line\n"
addf "APPLY-wpt-to-foundation.md"  "FROM: ${EXEC_LANE}\nTO: orc-foundation\n\nmail by header\n"
et="$(GIT_INDEX_FILE="$idx2" git -C "$C" write-tree)"
ec="$(git -C "$C" -c user.name=p -c user.email=p@p commit-tree "$et" -p "origin/$EXEC_BRANCH" -m wpt-exec)"
git -C "$C" update-ref "refs/remotes/origin/$EXEC_BRANCH" "$ec"
rc="$(hub LANE_SURFACE_REF="$SR")"
grep -qE "^NEW  ${EXEC_LANE} +origin/${EXEC_BRANCH}:ledger/apply-receipts/relay/RETURN-wpt-msg\\.md\$" "$W/out" \
  && pole W14-RELAY OK "a message in relay/ is an inbox item" || pole W14-RELAY FAIL "$(grep -c RETURN-wpt "$W/out") lines"
! grep -q "R-wpt-receipt.md" "$W/out" && grep -qxF "$(printf '%s\tR-wpt-receipt.md' "$EXEC_LANE")" "$C/.claude/inboxf-screened" \
  && pole W14-RECEIPT OK "a receipt outside relay/ is not an inbox item (screened)" || pole W14-RECEIPT FAIL "shown or not screened"
grep -q "^MISFILED-MAIL: ${EXEC_LANE} origin/${EXEC_BRANCH}:ledger/apply-receipts/SURFACE-wpt-misfiled.md" "$W/out" \
  && pole W14-MISFILED-NAME OK "SURFACE-* outside relay/ -> MISFILED-MAIL" || pole W14-MISFILED-NAME FAIL "no line"
grep -q "^MISFILED-MAIL: ${EXEC_LANE} origin/${EXEC_BRANCH}:ledger/apply-receipts/APPLY-wpt-to-foundation.md" "$W/out" \
  && grep -q "· 2 misfiled$" "$W/out" \
  && pole W14-MISFILED-TO OK "'TO: foundation' outside relay/ -> MISFILED-MAIL; the check line counts 2 misfiled" \
  || pole W14-MISFILED-TO FAIL "$(tail -1 "$W/out")"
# W14-CUTOVER: an unseen pre-cutover mail file is SURFACED by the same detector, never silently seeded: after
# the check above it is still neither seen nor screened.
! grep -qF "SURFACE-wpt-misfiled.md" "$C/.claude/inboxf-seen" && ! grep -qF "SURFACE-wpt-misfiled.md" "$C/.claude/inboxf-screened" \
  && pole W14-CUTOVER OK "unseen mail outside relay/ stays surfaced (not seen, not screened)" || pole W14-CUTOVER FAIL "silently absorbed"

# W8 (row 8, canon s7.4: the ack reflects real outbox motion): the ack resolves the lane's branch through
# lane_branch. The resolved apply-receipts-only lane and the resolved non-module-branch DENY lane both have
# a branch name that is NOT `module/<lane>`; a `module/$lane` guess counts 0 and prints a false HALT. A
# separate clone whose origin URL is dead, so `git fetch` cannot move the pinned refs.
D="$W/d8"; git clone -q --shared "$REPO" "$D" && git -C "$D" checkout -q -B "$TRUNK" "$(git -C "$REPO" rev-parse HEAD)"
cp "$REPO/scripts/doorbell.sh" "$REPO/scripts/lane-surface.sh" "$D/scripts/"
git -C "$D" remote set-url origin "$W/no-such-remote"
git -C "$D" update-ref "refs/remotes/$SR" "$(git -C "$D" rev-parse HEAD)"
B8_EXEC_BASE="$(git -C "$D" rev-parse "refs/remotes/origin/$EXEC_BRANCH")"
B8_EXEC_MOVED="$(git -C "$D" -c user.name=p -c user.email=p@p commit-tree "${B8_EXEC_BASE}^{tree}" -p "$B8_EXEC_BASE" -m "wpt-$EXEC_BRANCH-motion")"
git -C "$D" update-ref "refs/remotes/origin/$EXEC_BRANCH" "$B8_EXEC_MOVED"
B8_ALT_BASE="$(git -C "$D" rev-parse "refs/remotes/origin/$ALT_BRANCH")"
B8_ALT_MOVED="$(git -C "$D" -c user.name=p -c user.email=p@p commit-tree "${B8_ALT_BASE}^{tree}" -p "$B8_ALT_BASE" -m "wpt-$ALT_BRANCH-motion")"
git -C "$D" update-ref "refs/remotes/origin/$ALT_BRANCH" "$B8_ALT_MOVED"
ack() { ( cd "$D" && bash scripts/doorbell.sh ack "$@" ) > "$W/out8" 2>&1; echo $?; }
rc="$(ack "$EXEC_LANE" "$B8_EXEC_BASE")"
[ "$rc" = 0 ] && grep -q "ACK: ${EXEC_LANE} advanced 1 commit" "$W/out8" \
  && pole W8-EXEC OK "apply-receipts-only lane ack reads origin/$EXEC_BRANCH (1 commit of motion -> ACK)" || pole W8-EXEC FAIL "rc=$rc $(tail -1 "$W/out8")"
rc="$(ack "$ALT_LANE" "$B8_ALT_BASE")"
[ "$rc" = 0 ] && grep -q "ACK: ${ALT_LANE} advanced 1 commit" "$W/out8" \
  && pole W8-ARCH OK "architect-class lane ack reads origin/$ALT_BRANCH (1 commit -> ACK)" || pole W8-ARCH FAIL "rc=$rc $(tail -1 "$W/out8")"
rc="$(ack "$EXEC_LANE" "$(git -C "$D" rev-parse "refs/remotes/origin/$EXEC_BRANCH")")"
[ "$rc" = 3 ] && grep -q "NO consume-ack" "$W/out8" \
  && pole W8-NOMOTION OK "no motion since the tip -> HALT rc=3 (the true negative survives)" || pole W8-NOMOTION FAIL "rc=$rc $(tail -1 "$W/out8")"
rc="$(ack no-such-lane-wpt "$B8_EXEC_BASE")"
[ "$rc" = 3 ] && grep -q "UNRESOLVED" "$W/out8" && ! grep -q "NO consume-ack" "$W/out8" \
  && pole W8-UNDECLARED OK "undeclared lane -> HALT UNRESOLVED, not 'no consume-ack'" || pole W8-UNDECLARED FAIL "rc=$rc $(tail -1 "$W/out8")"

# W17 (row 17; canon s5 a landed message cannot drop): the seen-state records the blob. A
# consumed item whose bytes change re-shows ONCE, labelled AMENDED-AFTER-CONSUME, and hides again after consume.
# Hub poles on XP notes (blob = git hash-object) in their own clone; one spoke pole on a module lane.
E="$W/e17"; git clone -q --shared "$REPO" "$E" && git -C "$E" checkout -q -B "$TRUNK" "$(git -C "$REPO" rev-parse HEAD)"
for s in inboxf.sh inbox.sh lane-surface.sh consume-core.sh resolve-lane.sh; do cp "$REPO/scripts/$s" "$E/scripts/$s"; done
mkdir -p "$E/.claude" "$W/xp17"; X="$W/xp17"
h17() { ( cd "$E" && env XP_DIR="$X" bash scripts/inboxf.sh "$@" ) > "$W/o17" 2>&1; echo $?; }
printf 'TO: foundation\n\nfirst body\n' > "$X/a17.md"
h17 seed >/dev/null                                   # seal the live lane surfaces; a17 is sealed with them
h17 >/dev/null
! grep -q "a17.md" "$W/o17" && pole W17-HIDDEN OK "a seen note with an unchanged blob stays hidden" || pole W17-HIDDEN FAIL "$(grep a17 "$W/o17" | head -1)"
b0="$(git hash-object "$X/a17.md")"; printf 'TO: foundation\n\nERRATUM body\n' > "$X/a17.md"; b1="$(git hash-object "$X/a17.md")"
h17 >/dev/null
grep -q "^NEW  xp           a17.md$" "$W/o17" && grep -qxF "AMENDED-AFTER-CONSUME: a17.md (${b0:0:7} -> ${b1:0:7})" "$W/o17" \
  && pole W17-AMENDED OK "amended after consume -> NEW + 'AMENDED-AFTER-CONSUME: a17.md (${b0:0:7} -> ${b1:0:7})'" || pole W17-AMENDED FAIL "$(grep -E 'a17|AMENDED' "$W/o17" | head -2 | tr '\n' ' ')"
h17 consume xp a17.md --premise holds@wpt >/dev/null; h17 >/dev/null
! grep -q "a17.md" "$W/o17" && pole W17-ONCE OK "after consume the amended note hides again (re-marked at the new blob)" || pole W17-ONCE FAIL "still shown"
printf 'TO: foundation\n\nnew\n' > "$X/n17.md"; h17 >/dev/null
grep -q "^NEW  xp           n17.md$" "$W/o17" && ! grep -q "AMENDED-AFTER-CONSUME: n17" "$W/o17" \
  && pole W17-NEW OK "an unseen note shows NEW, unlabelled" || pole W17-NEW FAIL "$(grep n17 "$W/o17" | head -1)"
# migration: a legacy (blob-less) seen line is seen at its CURRENT blob after `migrate`; nothing re-shows at cutover
printf 'TO: foundation\n\nlegacy\n' > "$X/l17.md"; printf 'xp\tl17.md\n' >> "$E/.claude/inboxf-seen"
rc="$(h17 migrate)"; mig="$(grep '^INBOXF-MIGRATE:' "$W/o17")"; h17 >/dev/null
[ "$rc" = 0 ] && printf '%s' "$mig" | grep -qE 'seen-lines migrated [1-9][0-9]* of [1-9]' && ! grep -q "l17.md" "$W/o17" \
  && pole W17-MIGRATE OK "'$mig'; the legacy note does not re-show at cutover" || pole W17-MIGRATE FAIL "rc=$rc '$mig' $(grep -c l17 "$W/o17")"
printf 'TO: foundation\n\nlegacy amended\n' > "$X/l17.md"; h17 >/dev/null
grep -q "AMENDED-AFTER-CONSUME: l17.md" "$W/o17" && pole W17-MIGRATE-AMEND OK "an amendment after the migration re-shows" || pole W17-MIGRATE-AMEND FAIL "not re-shown"
# spoke: a module lane reading its spine inbox at origin/main (row 4) sees an in-place amendment of a consumed relay
S17="$W/s17"; git clone -q --shared "$REPO" "$S17" && git -C "$S17" checkout -q -B "$MOD_BRANCH" "$(git -C "$REPO" rev-parse HEAD)"
for s in inbox.sh consume-core.sh resolve-lane.sh lane-surface.sh inboxf.sh; do cp "$REPO/scripts/$s" "$S17/scripts/$s"; done
sed -E -e "s/^lane: .*/lane: ${MOD_LANE}/" -e "s#^worktree_branch: .*#worktree_branch: ${MOD_BRANCH}#" -e 's/^spine_write: .*/spine_write: DENY/' \
  "$REPO/_boot/BOOTSTRAP.md" > "$S17/_boot/BOOTSTRAP.md"
sp() { ( cd "$S17" && bash scripts/inbox.sh "$@" ) > "$W/s17o" 2>&1; }
spine() { local t b ix="$W/ix17"; b="$(printf '%s\n' "$1" | git -C "$S17" hash-object -w --stdin)"
  GIT_INDEX_FILE="$ix" git -C "$S17" read-tree "$SR"
  GIT_INDEX_FILE="$ix" git -C "$S17" update-index --add --cacheinfo "100644,$b,_orchestration/relay-inbox/${MOD_LANE}/9999-r17.md"
  t="$(GIT_INDEX_FILE="$ix" git -C "$S17" write-tree)" || { echo "write-tree failed"; return 1; }
  git -C "$S17" update-ref "refs/remotes/$SR" "$(git -C "$S17" -c user.name=p -c user.email=p@p commit-tree "$t" -p "$SR" -m r17)"; }
spine "first"; mkdir -p "$S17/.claude"; : > "$S17/.claude/inbox-seen"
sp; sp consume 9999-r17.md --premise holds@wpt; sp
s_hidden="$(grep -c "9999-r17" "$W/s17o")"
spine "erratum"; sp
[ "$s_hidden" = 0 ] && grep -q "^AMENDED-AFTER-CONSUME: 9999-r17.md (" "$W/s17o" && grep -q "NEW: _orchestration/relay-inbox/${MOD_LANE}/9999-r17.md" "$W/s17o" \
  && pole W17-SPOKE OK "spoke: consumed relay hidden, in-place amendment re-shows labelled" || pole W17-SPOKE FAIL "hidden-hits=$s_hidden $(grep -E 'AMENDED|INBOX-CHECK' "$W/s17o" | head -2 | tr '\n' ' ')"

echo "WINDOW-TRANSPORT: ${OK}/${N} poles OK"
[ "$OK" = "$N" ]
