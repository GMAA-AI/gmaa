#!/usr/bin/env bash
# probe_completeness_v1.sh — the DEFAULT-MODE ALLOW-LIST COMPLETENESS PROBE,
# re-run as a STANDING probe: the §8 completeness probe.
#
# WHAT ITEM 76 ASKED (§1, read-only enumeration + a ruling):
#   §1.1/§1.2  does every ratified, recurring op the seats run route through an AUDITED WRAPPER
#              (the wrappers the completeness table, _index/completeness-classes.tsv, declares) AND match a
#              standing NARROW allow-rule — never a widened grant?
#   §1.3       does the deny-list still catch the MUST-NEVER set: a cloud-CLI service-principal login (the A rows of `completeness-classes.tsv`),
#              DDL applies, force-push, credential surfaces, external-API, spend-class?
#   §1.4       VERDICT — drip-free, or an enumerated gap (name it; don't flip modes to work around it).
#   §2 (RULING, binds the remedy): the fix for a gap is a NARROW wrapper allow-rule, never a widened
#              grant (`Bash(scripts/*)`-class broadening is RULED OUT in advance, in so many words).
#
# WHAT A STANDING PROBE CAN RE-RUN, AND WHAT IT CANNOT:
#   §1.1's "every command class the seats have run in the last ~20 turns" is TRANSCRIPT-derived — no
#   static surface holds that history, and reconstructing it needs an LLM judgment call over session
#   logs, which LLM-AT-THE-EDGES bars from a mechanism (a probe is written code, not a judgment fire).
#   What IS structural and re-runnable on every commit:
#     CHECK A (§1.3) — the deny-list still names each must-never class (a class is PRESENT iff at
#       least one deny entry matches ANY of its listed patterns; patterns are a defensible reading of
#       the prose class name, not a re-litigation of it — a human dispositions a wrong pattern, this
#       probe just makes the current coverage state loud instead of assumed).
#     CHECK B (§1.1, the wrappers the completeness table declares) —
#       each carry an EXPLICIT narrow allow-rule naming the script (not merely swept
#       in by a directory-wide glob).
#   §2's anti-widen ruling is reported as INFO, not a verdict-driving check: judging whether an
#   existing directory-wide entry (`Bash(scripts/*)`) is compliant depends on whether it is PAIRED with
#   an independent narrowing enforcer (settings.json's own header names `greenlight-policy.sh` L3 as
#   exactly that pairing) — that is an architect-class reading of the ruling, not a linter's; a false
#   FAIL here would be worse than a human seeing the fact and dispositioning it (false positives are
#   fine per this file's own doctrine — DISC-EXECUTABILITY-NEEDS-AN-EXECUTOR/linter-not-proof-gate — a
#   false negative baked into the verdict is not).
#
# CLASS TABLE: every CHECK A class (name, pattern) and every CHECK B wrapper is a row of _index/completeness-classes.tsv
# (kind · name · pattern · scope · note); this file names no class and no wrapper. scope=engine rows ship to every install;
# scope=origin rows are the declaring project's own domain rows, and an adopter fills its own. A row whose note starts with
# HELD: is a class its project holds back: its MISSING row is reported as HELD and does not count as a gap. Any other MISSING
# class or wrapper is a gap. The HELD set therefore lives in the table, never in this file.
# NEVER PASS OVER ZERO: each check prints its denominator (`check=A <n> classes declared (engine e · origin o)`,
# `check=B <n> wrappers declared`). With 0 origin rows the verdict is `VERDICT: PASS (engine n · domain 0 declared)`, exit 0, and
# a FILL-OWED line names the fill; that is not a FAIL. A table that is absent, unreadable, has no data rows or has a row that does
# not parse is `COMPLETENESS: UNREADABLE <path> ...`, exit 3, NO VERDICT line; it is never an empty PASS.
#
# ENGINE POLES (verdict-driving; this probe is the CALLER of the greenlight deny-class engine in
# scripts/greenlight-policy.sh): the engine poles drive the verdict: whether the deny
# ENGINE works, measured on a DECLARED FIXTURE class table passed through GREENLIGHT_DENY_TABLE (a test-only
# override the engine honours): E1 sample command -> deny naming the class · E2 the wrapper form of the same command -> no deny ·
# E3 the real (ships-empty) table -> no deny on the sample · E4 table absent -> no deny AND no allow (fail closed, UNVERIFIED line) · E5 a command matching no row -> no deny (the match is a match, not a blanket).
# Output: one `COMPLETENESS: check=<A|B> class=<name> …` row per check + a `COMPLETENESS: INFO …` row
# per §2 note, then `VERDICT: PASS (engine n · domain m declared)` exit 0 iff every CHECK A class (other than a HELD: row) and every CHECK B
# wrapper is present and every engine pole passes, else `VERDICT: FAIL (<n> gap(s): …)` exit 1. `.claude/settings.json` missing or unparseable
# ⇒ `COMPLETENESS: UNREADABLE — <reason>` exit 3, NO VERDICT line (DISC-CHILD-FAILURE-MUST-SURFACE).
# bash 3.2-safe (macOS /bin/bash; no associative arrays). python3 used only to parse JSON (stdlib only).
set -u

unreadable() { echo "COMPLETENESS: UNREADABLE — $* (exit 3; this is NOT a verdict)"; exit 3; }
unreadable_table() { echo "COMPLETENESS: UNREADABLE $1 — $2 (exit 3; this is NOT a verdict)"; exit 3; }

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || unreadable "not inside a git worktree"
SETTINGS="$REPO_ROOT/.claude/settings.json"
[ -f "$SETTINGS" ] || unreadable "$SETTINGS absent"

TMP="$(mktemp -d "${TMPDIR:-/tmp}/complprobe.XXXXXX")" || unreadable "mktemp failed"
trap 'rm -rf "$TMP"' EXIT

python3 - "$SETTINGS" > "$TMP/perms.txt" <<'PYEOF'
import json, sys
path = sys.argv[1]
try:
    data = json.load(open(path))
except Exception as e:
    print("PARSE-ERROR\t%s" % e)
    sys.exit(1)
perms = data.get("permissions", {})
if not isinstance(perms, dict):
    print("PARSE-ERROR\tno 'permissions' object")
    sys.exit(1)
for a in (perms.get("allow", []) or []):
    print("ALLOW\t" + str(a))
for d in (perms.get("deny", []) or []):
    print("DENY\t" + str(d))
PYEOF
rc=$?
[ $rc -eq 0 ] || unreadable "$(command grep '^PARSE-ERROR' "$TMP/perms.txt" 2>/dev/null | cut -f2- || echo 'python3/JSON parse failed')"

command grep '^DENY'  "$TMP/perms.txt" | cut -f2- > "$TMP/deny.txt"
command grep '^ALLOW' "$TMP/perms.txt" | cut -f2- > "$TMP/allow.txt"

GAPS=0
HELD=0
NROWS=0
ENGROWS=0

# ── THE CLASS TABLE — every class and wrapper this probe checks is a row here ───────────────────────
TABLE_REL="_index/completeness-classes.tsv"
TABLE="$REPO_ROOT/$TABLE_REL"
[ -r "$TABLE" ] || unreadable_table "$TABLE_REL" "table absent or unreadable"
awk -F'\t' '
    /^#/ || /^[[:space:]]*$/ || $1=="kind" { next }
    NF!=5 || ($1!="A" && $1!="B") || ($4!="engine" && $4!="origin") || $2=="" || $3=="" || $5=="" { print "BAD\t" NR "\t" $0; next }
    { print }
' "$TABLE" > "$TMP/rows.tsv"
BADROW="$(command grep -m1 '^BAD' "$TMP/rows.tsv")"
[ -z "$BADROW" ] || unreadable_table "$TABLE_REL" "unparseable row at line $(printf '%s' "$BADROW" | cut -f2)"
[ -s "$TMP/rows.tsv" ] || unreadable_table "$TABLE_REL" "0 rows declared"
count() {   # count <kind> <scope|any>
  awk -F'\t' -v k="$1" -v s="$2" '$1==k && (s=="any" || $4==s) {n++} END {print n+0}' "$TMP/rows.tsv"
}
A_ALL="$(count A any)"; A_ENG="$(count A engine)"; A_ORG="$(count A origin)"
B_ALL="$(count B any)"; B_ENG="$(count B engine)"; B_ORG="$(count B origin)"
ENG_N=$((A_ENG+B_ENG)); ORG_N=$((A_ORG+B_ORG))
echo "COMPLETENESS: check=A ${A_ALL} classes declared (engine ${A_ENG} · origin ${A_ORG})"
echo "COMPLETENESS: check=B ${B_ALL} wrappers declared (engine ${B_ENG} · origin ${B_ORG})"

# ── CHECK A (§1.3) — must-never deny-list coverage ──────────────────────────────────────────────
while IFS=$'\t' read -r kind name pat scope note; do
  [ "$kind" = "A" ] || continue
  hit="$(command grep -Ei -e "$pat" "$TMP/deny.txt" | head -1)"
  NROWS=$((NROWS+1))
  if [ -n "$hit" ]; then
    echo "COMPLETENESS: check=A class=${name} scope=${scope} verdict=PRESENT matched=\"${hit}\""
  elif [ "${note#HELD:}" != "$note" ]; then
    echo "COMPLETENESS: check=A class=${name} scope=${scope} verdict=MISSING — no deny entry matches pattern /${pat}/i (HELD: the table holds this class back; reported, not a gap)"
    HELD=$((HELD+1))
  else
    echo "COMPLETENESS: check=A class=${name} scope=${scope} verdict=MISSING — no deny entry matches pattern /${pat}/i"
    GAPS=$((GAPS+1))
  fi
done < "$TMP/rows.tsv"

# ── CHECK B (§1.1) — the audited wrappers, each an explicit narrow allow-rule ───────────────────────
while IFS=$'\t' read -r kind name pat scope note; do
  [ "$kind" = "B" ] || continue
  hit="$(command grep -F -e "$pat" "$TMP/allow.txt" | head -1)"
  NROWS=$((NROWS+1))
  if [ -n "$hit" ]; then
    echo "COMPLETENESS: check=B wrapper=${name} scope=${scope} verdict=PRESENT matched=\"${hit}\""
  elif [ "${note#HELD:}" != "$note" ]; then
    echo "COMPLETENESS: check=B wrapper=${name} scope=${scope} verdict=MISSING — no allow entry names ${pat} explicitly (HELD: the table holds this wrapper back; reported, not a gap)"
    HELD=$((HELD+1))
  else
    echo "COMPLETENESS: check=B wrapper=${name} scope=${scope} verdict=MISSING — no allow entry names ${pat} explicitly"
    GAPS=$((GAPS+1))
  fi
done < "$TMP/rows.tsv"

# ── INFO (§2 ruling) — directory-wide allow entries, reported but NOT verdict-driving (see header) ──
WIDE="$(command grep -E '^Bash\((\./)?(bash )?scripts/\*\)$' "$TMP/allow.txt")"
if [ -n "$WIDE" ]; then
  while IFS= read -r w; do
    [ -n "$w" ] || continue
    echo "COMPLETENESS: INFO §2-anti-widen entry=\"${w}\" — directory-wide grant present; settings.json's own header names greenlight-policy.sh (L3) as the paired narrowing enforcer (scripts/* clean@HEAD); disposition is an architect-class read of the completeness ruling, not this linter's — reported, not counted toward VERDICT."
  done <<EOF
$WIDE
EOF
fi

# ── ENGINE POLES — exercise the greenlight deny-class engine on a declared fixture table ─────────────
ENGINE="$REPO_ROOT/scripts/greenlight-policy.sh"
[ -r "$ENGINE" ] || unreadable "$ENGINE absent"
FIX="$TMP/fixture-classes.tsv"
printf 'class_id\tdeny_ere\twrapper_ere\treason\n' > "$FIX"
printf 'FIX-1\tfixture-danger\t^scripts/fixture-wrapper\\.sh \tfixture class: danger off the wrapper\n' >> "$FIX"
SAMPLE='fixture-danger --apply'
WRAPPED='scripts/fixture-wrapper.sh fixture-danger --apply'
eng() {   # eng <table-or-empty> <command>: stdout of the engine; stderr to $TMP/eng.err
  local tbl="$1" c="$2" payload
  payload="$(printf '{"tool_name":"Bash","tool_input":{"command":"%s"}}' "$c")"
  if [ -n "$tbl" ]; then
    ( cd "$REPO_ROOT" && printf '%s' "$payload" | GREENLIGHT_DENY_TABLE="$tbl" bash "$ENGINE" 2>"$TMP/eng.err" )
  else
    ( cd "$REPO_ROOT" && printf '%s' "$payload" | env -u GREENLIGHT_DENY_TABLE bash "$ENGINE" 2>"$TMP/eng.err" )
  fi
}
pole() {   # pole <id> <rc> <detail>
  ENGROWS=$((ENGROWS+1))
  if [ "$2" -eq 0 ]; then echo "COMPLETENESS: engine pole=$1 verdict=PASS — $3"
  else echo "COMPLETENESS: engine pole=$1 verdict=FAIL — $3"; GAPS=$((GAPS+1)); fi
}
o="$(eng "$FIX" "$SAMPLE")"
printf '%s' "$o" | command grep -q '"permissionDecision":"deny"' && printf '%s' "$o" | command grep -q 'deny class FIX-1'; pole E1-deny $? "fixture sample -> ${o:-<no decision>}"
o="$(eng "$FIX" "$WRAPPED")"
! printf '%s' "$o" | command grep -q '"permissionDecision":"deny"'; pole E2-wrapper-not-deny $? "wrapper form -> ${o:-<no decision>}"
o="$(eng "" "$SAMPLE")"
! printf '%s' "$o" | command grep -q '"permissionDecision":"deny"'; pole E3-real-table-no-deny $? "real table (data rows: $(command grep -cvE '^(#|class_id|[[:space:]]*$)' "$REPO_ROOT/_index/greenlight-deny-classes.tsv" 2>/dev/null)) -> ${o:-<no decision>}"
o="$(eng "$FIX" "ls -la")"
! printf '%s' "$o" | command grep -q '"permissionDecision":"deny"'; pole E5-nonmatching-not-deny $? "fixture table, non-matching command -> ${o:-<no decision>}"
o="$(eng "$TMP/absent.tsv" "ls")"
[ -z "$o" ] && command grep -q 'UNVERIFIED' "$TMP/eng.err"; pole E4-absent-fails-closed $? "table absent -> stdout '${o}' stderr '$(head -1 "$TMP/eng.err")'"

echo "COMPLETENESS: ${NROWS} checks (${A_ALL} must-never classes + ${B_ALL} named wrappers; engine ${ENG_N} · origin ${ORG_N}) — ${HELD} held (a HELD: note in the table; not gaps)"
echo "COMPLETENESS: ${ENGROWS} engine poles (greenlight deny-class engine, fixture table)"
if [ "$ORG_N" -eq 0 ]; then
  echo "COMPLETENESS: FILL-OWED 0 domain rows declared in ${TABLE_REL}: add this install's own must-never classes and wrappers (scope=origin); not a FAIL"
fi
if [ "$GAPS" -eq 0 ]; then
  echo "VERDICT: PASS (engine ${ENG_N} · domain ${ORG_N} declared)"
  exit 0
else
  echo "VERDICT: FAIL (${GAPS} gap(s) — see the MISSING and engine-pole FAIL rows above; §2 ruling: close a coverage gap with a NARROW wrapper allow-rule, never a widened grant)"
  exit 1
fi
