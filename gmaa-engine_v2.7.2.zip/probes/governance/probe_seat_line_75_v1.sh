#!/usr/bin/env bash
# probe_seat_line_75_v1.sh — the SEAT-LINE presence probe (canon §7.5, "the line every seat carries").
# The canon cuts the §7.5 line as verbatim text every seat file must carry; this probe measures it by FULL TEXT, not a
# prefix: the line is read out of the CURRENT canon edition at the reference (anchored name, _PUBLIC excluded, sort -V --
# the one rule shared with governance.sh and the surface-conformance probe), then each subject must contain it after
# whitespace normalisation (blockquote markers and line wraps collapse to single spaces; no other folding).
#
# SUBJECTS (derived from the reference tree each run, denominator printed): every .claude/agents/*.md · CLAUDE.md ·
# _boot/BOOTSTRAP.md. BOOTSTRAP.md is a lane-stamped file that carries the line today; it is in scope because the
# stamp is what a cold-booted seat reads first.
# OUTPUT: one `SEAT-LINE: <path> verdict=CARRIED|MISSING|ABSENT` row per subject (non-CARRIED first), a denominator line
# `SEAT-LINE: N of M subjects carry the canon §7.5 line (canon <file>)`, then `VERDICT: PASS` (exit 0) or
# `VERDICT: FAIL (k of M subjects lack it)` (exit 1). Canon unreadable, the §7.5 line not found in it, or the
# subject set empty => `SEAT-LINE: UNREADABLE ...` exit 3, no verdict (DISC-CHILD-FAILURE-MUST-SURFACE).
# Usage: probe_seat_line_75_v1.sh [--ref <git-ref>]   (default: the spine ref, scripts/spine-ref.sh; SEAT_LINE_REF env honoured)
set -u
REF="${SEAT_LINE_REF:-}"
while [ $# -gt 0 ]; do
  case "$1" in
    --ref) case "${2:-}" in ""|--*) echo "usage: $0: --ref needs a value" >&2; exit 1 ;; esac; REF="$2"; shift 2 ;;
    *) echo "usage: $0 [--ref <git-ref>]"; exit 1 ;;
  esac
done
unreadable() { echo "SEAT-LINE: UNREADABLE — $* (exit 3; this is NOT a verdict)"; exit 3; }

ANCHOR="$(git rev-parse --show-toplevel 2>/dev/null)" || unreadable "not inside a git worktree"
# default frame = the ONE spine-ref resolver's output (the one spine-ref resolver); unresolvable is UNREADABLE by name, no literal
[ -n "$REF" ] || REF="$(bash "$ANCHOR/scripts/spine-ref.sh")" || unreadable "SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and no --ref/SEAT_LINE_REF given (the one spine-ref resolver)"
SHA="$(git -C "$ANCHOR" rev-parse -q --verify "${REF}^{commit}" 2>/dev/null)" || unreadable "reference '${REF}' cannot be read"
CANON="$(git -C "$ANCHOR" ls-tree -r --name-only "$SHA" 2>/dev/null | grep -E '^GOVERNED_MULTI_AGENT_ARCHITECTURE_v[0-9_]+\.md$' | sort -V | tail -1)"
[ -n "$CANON" ] || unreadable "no canon edition at ${REF}"
T="$(mktemp -d "${TMPDIR:-/tmp}/seatline.XXXXXX")" || unreadable "mktemp failed"
trap 'rm -rf "$T"' EXIT

# Whitespace-normalised view of a git blob: strip leading blockquote/emphasis-free markers per line, collapse whitespace.
norm() { perl -0777 -pe 's/^[ \t]*>[ \t]?//mg; s/\s+/ /g; $_ .= "\n"'; }

git -C "$ANCHOR" show "${SHA}:${CANON}" 2>/dev/null | norm > "$T/canon" || unreadable "${CANON} unreadable at ${REF}"
LINE="$(perl -ne 'if (/(One session = one seat\..*?never a ruling to defend\.)/) { print $1; exit }' "$T/canon")"
[ -n "$LINE" ] || unreadable "the §7.5 line (One session = one seat. … never a ruling to defend.) not found in ${CANON}"
printf '%s' "$LINE" > "$T/line"

SUBJ="$( { git -C "$ANCHOR" ls-tree -r --name-only "$SHA" | grep -E '^\.claude/agents/[^/]+\.md$'; echo CLAUDE.md; echo _boot/BOOTSTRAP.md; } | sort -u)"
M=0; K=0; : > "$T/bad"; : > "$T/good"
while IFS= read -r p; do
  [ -n "$p" ] || continue
  M=$((M+1))
  if ! git -C "$ANCHOR" cat-file -e "${SHA}:${p}" 2>/dev/null; then echo "SEAT-LINE: ${p} verdict=ABSENT" >> "$T/bad"; continue; fi
  git -C "$ANCHOR" show "${SHA}:${p}" | norm > "$T/s"
  if perl -e 'local $/; open(L,"<",$ARGV[0]); my $l=<L>; open(S,"<",$ARGV[1]); my $s=<S>; exit(index($s,$l)>=0 ? 0 : 1)' "$T/line" "$T/s"; then
    K=$((K+1)); echo "SEAT-LINE: ${p} verdict=CARRIED" >> "$T/good"
  else echo "SEAT-LINE: ${p} verdict=MISSING" >> "$T/bad"; fi
done <<EOF
$SUBJ
EOF
[ "$M" -gt 0 ] || unreadable "subject set empty at ${REF}"
cat "$T/bad" "$T/good"
echo "SEAT-LINE: ${K} of ${M} subjects carry the canon §7.5 line (canon ${CANON} at ${REF} ${SHA:0:8})"
if [ "$K" -eq "$M" ]; then echo "VERDICT: PASS"; exit 0; fi
echo "VERDICT: FAIL ($((M-K)) of ${M} subjects lack it)"; exit 1
