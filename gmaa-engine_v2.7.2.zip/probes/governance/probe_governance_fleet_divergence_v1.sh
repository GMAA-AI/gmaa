#!/usr/bin/env bash
# probe_governance_fleet_divergence_v1.sh — RETIRED (pointer stub). Subsumed by the surface-conformance probe.
#
# This probe compared BRANCH content (`$ref:$path` blob ids across origin branches carrying a _boot stamp) —
# axis 1, which was closed as not-a-deficit (lanes READ the spine, they never merge it) — was hand-run
# (never runlisted), and hardcoded a canon edition four behind the pointer. Its successor measures the
# EXECUTING surface (on-disk bytes per git worktree) and resolves the canon by version-sort:
#
#     probes/governance/probe_surface_conformance_v1.sh        (run from spine bytes: scripts/surface-conformance-spine.sh)
#
# The full retired body is recoverable at its last blob: git cat-file -p b60c5e72   (retired 2026-09-23).
# The path stays so existing citations (decision-log :7480, issues_register :2328) resolve —
# the SPEC-COHERENCE-PROOF stub precedent. Running it prints this pointer and exits 3 (NOT a verdict).
echo "FLEET-DIVERGENCE: RETIRED — use probes/governance/probe_surface_conformance_v1.sh. This is NOT a verdict."
exit 3
