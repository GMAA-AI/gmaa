#!/bin/bash
# probes/governance/probe_hub_reachability_poles.sh — SET-0134 poles for probe_hub_reachability.sh (auditor 12535d8a F1:
# the hub name must come from the NAMER, scripts/launch-orc.sh). Fake hub worktrees under .tmp/. Usage: [<probe-file>]
set -u
P="${1:-probes/governance/probe_hub_reachability.sh}"
R="$(git rev-parse --show-toplevel)"
cd "$R" || exit 3; mkdir -p .tmp
mk() {  # <dir> <SESSION template line> -> a fake hub worktree
  rm -rf "$1"; mkdir -p "$1/_boot" "$1/scripts"
  cp scripts/resolve-project.sh scripts/doorbell.sh "$1/scripts/"
  sed "s|^SESSION=\".*\"\$|$2|" scripts/launch-orc.sh > "$1/scripts/launch-orc.sh"
  printf -- '---\nlane: foundation\nproject: demo\n---\n' > "$1/_boot/BOOTSTRAP.md"
}
LANEFX=.tmp/hubfx-lane; rm -rf "$LANEFX"; mkdir -p "$LANEFX/_boot" "$LANEFX/scripts"
cp scripts/resolve-project.sh scripts/doorbell.sh "$LANEFX/scripts/"
printf -- '---\nlane: lane-a\nproject: demo\n---\n' > "$LANEFX/_boot/BOOTSTRAP.md"
ok=0; n=0
pole() {  # <name> <want rc> <hubdir or ''>
  n=$((n+1))
  if [ -n "$3" ]; then out="$(HUB_REACH_HUB="$R/$3" bash "$P" "$LANEFX" 2>&1)"; rc=$?
  else out="$(bash "$P" 2>&1)"; rc=$?; fi
  if [ "$rc" = "$2" ]; then ok=$((ok+1)); echo "  pole $n ($1): OK rc=$rc"; else echo "  pole $n ($1): FAIL rc=$rc want $2 :: $(echo "$out" | tail -1)"; fi
}
pole "live 6 lanes" 0 ""
mk .tmp/hubfx-same 'SESSION="$PROJECT-$LANE"';            pole "unchanged launcher" 0 .tmp/hubfx-same
mk .tmp/hubfx-seat 'SESSION="$PROJECT-seat-$LANE"';       pole "launcher-only rename (auditor F1)" 1 .tmp/hubfx-seat
mk .tmp/hubfx-brace 'SESSION="${PROJECT}-${LANE}"';       pole "brace form, same name" 0 .tmp/hubfx-brace
mk .tmp/hubfx-unk 'SESSION="$PROJECT-$OTHER"';            pole "unresolvable template" 3 .tmp/hubfx-unk
mk .tmp/hubfx-none 'NOSESSION=1';                         pole "no template" 3 .tmp/hubfx-none
echo "HUBREACH-POLES: $ok/$n"
[ "$ok" -eq "$n" ]
