#!/usr/bin/env bash
# probe_seat_defs_v1.sh — the agent-definition probe for canon v1.6.5 §1.3.
# One probe, three checks over every .claude/agents/**/*.md in THIS worktree (or --dir <path>):
#
#   L · static loadability (C2, T1.3.8 static half; canon :86 "stored is not loadable"). The runtime SKIPS a def
#       silently when its front matter is not loadable. The rules below are the live docs' list, read 2026-10-01
#       at https://code.claude.com/docs/en/sub-agents ("Claude Code skips a file ... without reporting it in the
#       session"): the first line is `---` and a closing `---` follows · the YAML parses to a mapping · `name` is
#       present, does not start with `-` and contains no `:` · `description` is present and non-empty · `name` is
#       unique across the tree · if `tools` is given, >=1 entry resolves to a known tool ("if no entry in the list
#       resolves to a tool, the subagent usually fails to launch") · `model`, if given, is sonnet|opus|haiku|fable|
#       inherit or a full claude-* id. The LIVE-SPAWN half of T1.3.8 is the C1 fan-out receipt, not this probe.
#   R · read-only class (C10, T1.3.6; canon :84 "'Read-only' as a prompt on an advancing executor is a wish, not a
#       control"). A def whose description DECLARES read-only (classifier below, SCOPE) must have no
#       Write, Edit, MultiEdit, NotebookEdit or Bash in its EFFECTIVE tool set. Effective = `tools` (every tool if
#       omitted) + Read/Write/Edit when `memory` is set (docs: "Read, Write, and Edit tools are automatically enabled
#       so the subagent can manage its memory files") − `disallowedTools` (an entry with a specifier removes the
#       whole tool). Sole path: the harness enforces this tool set; the description cannot widen or narrow it.
#       SCOPE (disclosed, widened SET-0120): any-case clause-initial or adjectival read-only, not negated, not a path-mode use;
#       architect.md's "Reads ... the transport and packaging repos READ-ONLY" (read verb earlier in the clause) is path-mode, not a class claim.
#   K · no key, no allow-list of its own (C8, T1.3.1; canon :69). Every def: no credential-shaped string (the
#       line number and class are printed, never the match). Subagent defs (every def except the seat defs named
#       by --seats, default `orc architect`, CLAUDE.md §Seats): no `permissionMode` other than default|manual|plan,
#       and no `mcpServers`. NOT judged: `hooks` (a capability, not an allow-list).
#
# Output: one `SEAT-DEF:` line per failing check, a `SEAT-DEFS:` summary with every denominator, `VERDICT: PASS|FAIL`.
# Exit 0 PASS · 1 FAIL · 3 UNREADABLE (no python3/PyYAML, no defs dir, or zero defs; no verdict line is printed).
# Usage: probe_seat_defs_v1.sh [--dir <agents-dir>] [--seats 'orc architect']
set -u
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "SEAT-DEFS: UNREADABLE -- not in a git worktree"; exit 3; }
DIR="$ROOT/.claude/agents"; SEATS="orc architect"
while [ $# -gt 0 ]; do
  case "$1" in
    --dir) [ $# -ge 2 ] || { echo "SEAT-DEFS: UNREADABLE -- --dir needs a value"; exit 3; }; DIR="$2"; shift 2 ;;
    --seats) [ $# -ge 2 ] || { echo "SEAT-DEFS: UNREADABLE -- --seats needs a value"; exit 3; }; SEATS="$2"; shift 2 ;;
    *) echo "SEAT-DEFS: UNREADABLE -- unknown argument $1"; exit 3 ;;
  esac
done
[ -d "$DIR" ] || { echo "SEAT-DEFS: UNREADABLE -- no agents dir at $DIR"; exit 3; }
command -v python3 >/dev/null 2>&1 || { echo "SEAT-DEFS: UNREADABLE -- python3 not found"; exit 3; }
python3 -c 'import yaml' 2>/dev/null || { echo "SEAT-DEFS: UNREADABLE -- PyYAML not importable"; exit 3; }

python3 - "$DIR" "$SEATS" <<'PYEOF'
import sys, os, re, glob, yaml
d, seats = sys.argv[1], set(sys.argv[2].split())
files = sorted(glob.glob(os.path.join(d, '**', '*.md'), recursive=True))
if not files:
    print("SEAT-DEFS: UNREADABLE -- 0 defs under " + d); sys.exit(3)
KNOWN = {'Read','Write','Edit','MultiEdit','NotebookEdit','Glob','Grep','Bash','WebFetch','WebSearch','Skill',
         'Task','Agent','TodoWrite','LS','NotebookRead','BashOutput','KillShell','SlashCommand'}
WRITE = {'Write','Edit','MultiEdit','NotebookEdit','Bash'}
MODELS = {'sonnet','opus','haiku','fable','inherit'}
# R classifier (SET-0120, cure for auditor 2991a739 F1): a description DECLARES read-only when it holds `read-only` or
# `read only` (any case) that is clause-initial or adjectival, NOT negated and NOT a path-mode object. A clause is the
# text since the last . ; : ! ? ( ) — – , (or the start). Negated: `not`/`never`/`non` right before it (`not read-only
# class`). Path-mode: a read verb earlier in the same clause (`Reads ... the transport and packaging repos READ-ONLY`), or a data-object noun
# right after it (`read-only SQL`). Over-reading toward "declares" is the accepted failure direction.
RO_WORD = re.compile(r'\bread[- ]only\b', re.I)
RO_NEG = re.compile(r'\b(not|never|non)[\s-]*(a\s+|an\s+)?$', re.I)
RO_VERB = re.compile(r'\b(reads?|reading|opens?|accesses|access|mounts?|views?|inspects?|browses?)\b', re.I)
RO_OBJ = re.compile(r'\s*(sql|quer(y|ies)|mounts?|cop(y|ies)|views?|connections?|replicas?|transactions?)\b', re.I)
CLAUSE = re.compile(r'[.;:!?()—–,]')
def ro_declared(desc):
    for m in RO_WORD.finditer(desc):
        before = desc[:m.start()]
        cut = max([x.end() for x in CLAUSE.finditer(before)] or [0])
        clause = before[cut:]
        if RO_NEG.search(clause): continue
        if RO_VERB.search(clause): continue
        if RO_OBJ.match(desc[m.end():]): continue
        return True
    return False
CRED = re.compile(r'sk-ant-[A-Za-z0-9_-]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----|xox[abprs]-[A-Za-z0-9-]{10,}'
                  r'|gh[pousr]_[A-Za-z0-9]{30,}|(?i:(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*["\']?[A-Za-z0-9/+_\-]{24,})')

def entries(v):
    """tools/disallowedTools as a list of base tool names; a comma string is split outside parentheses."""
    if v is None: return None
    items = v if isinstance(v, list) else None
    if items is None:
        s, depth, cur, items = str(v), 0, '', []
        for ch in s:
            if ch == '(': depth += 1
            elif ch == ')': depth -= 1
            if ch == ',' and depth == 0: items.append(cur); cur = ''
            else: cur += ch
        items.append(cur)
    return [re.sub(r'\(.*$', '', str(x)).strip() for x in items if str(x).strip()]

fails, names = [], {}
nL = nR = nRok = nK = 0
okL = okK = 0
for f in files:
    rel = os.path.relpath(f, d)
    txt = open(f, encoding='utf-8', errors='replace').read()
    lines = txt.split('\n')
    bad = []
    fm = None
    nL += 1
    if lines[0].rstrip('\r') != '---':
        bad.append('L no front matter: first line is not ---')
    else:
        try:
            end = next(i for i in range(1, len(lines)) if lines[i].rstrip('\r') == '---')
            try:
                fm = yaml.safe_load('\n'.join(lines[1:end]))
                if not isinstance(fm, dict): bad.append('L front matter is not a mapping'); fm = None
            except Exception as e:
                bad.append('L YAML does not parse (' + str(e).split('\n')[0][:80] + ')')
        except StopIteration:
            bad.append('L no closing ---')
    if fm is not None:
        nm = fm.get('name')
        if not isinstance(nm, str) or not nm.strip(): bad.append('L no name')
        elif nm.startswith('-') or ':' in nm: bad.append('L name starts with - or contains :')
        else: names.setdefault(nm, []).append(rel)
        ds = fm.get('description')
        if not isinstance(ds, str) or not ds.strip(): bad.append('L no description')
        tl = entries(fm.get('tools'))
        if tl is not None:
            known = [t for t in tl if t in KNOWN or t.startswith('mcp__')]
            if not known: bad.append('L no tools entry resolves to a known tool')
        md = fm.get('model')
        if md is not None and not (str(md) in MODELS or str(md).startswith('claude-')): bad.append('L model not recognized: ' + str(md))
    if not any(b.startswith('L') for b in bad): okL += 1
    # R: read-only class
    if fm is not None and isinstance(fm.get('description'), str) and ro_declared(fm["description"]):
        nR += 1
        tl = entries(fm.get('tools'))
        eff = set(KNOWN) if tl is None else set(tl)
        if fm.get('memory'): eff |= {'Read','Write','Edit'}
        eff -= set(entries(fm.get('disallowedTools')) or [])
        w = sorted(eff & WRITE)
        if w: bad.append('R declares Read-only but its effective tools include ' + ','.join(w))
        else: nRok += 1
    # K: no key, no allow-list of its own
    nK += 1
    kb = False
    for i, ln in enumerate(lines, 1):
        m = CRED.search(ln)
        if m: bad.append('K credential-shaped string at line %d (match not printed)' % i); kb = True
    if fm is not None and str(fm.get('name', '')) not in seats:
        pm = fm.get('permissionMode')
        if pm is not None and str(pm) not in ('default', 'manual', 'plan'):
            bad.append('K subagent def sets its own permissionMode: ' + str(pm)); kb = True
        if 'mcpServers' in fm: bad.append('K subagent def declares its own mcpServers'); kb = True
    if not kb: okK += 1
    for b in bad: fails.append('SEAT-DEF: %s %s FAIL -- %s' % (rel, b[0], b[2:]))
dups = {n: fs for n, fs in names.items() if len(fs) > 1}
for n, fs in sorted(dups.items()):
    fails.append('SEAT-DEF: %s L FAIL -- name "%s" is not unique (the runtime loads only one)' % (','.join(fs), n))
    okL -= len(fs) - 1
for x in fails: print(x)
n = len(files)
print('SEAT-DEFS: %d defs under %s · L loadable %d/%d · R read-only-declared %d, clean %d/%d · K no-key/no-allow-list %d/%d · seats exempt from K front-matter: %s'
      % (n, d, okL, nL, nR, nRok, nR, okK, nK, ' '.join(sorted(seats))))
print('VERDICT: ' + ('PASS' if not fails else 'FAIL (%d failing check line(s))' % len(fails)))
sys.exit(0 if not fails else 1)
PYEOF
