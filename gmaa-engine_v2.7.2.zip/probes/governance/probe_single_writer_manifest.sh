#!/usr/bin/env bash
# probes/governance/probe_single_writer_manifest.sh
#
# "Single-writer manifest-enforceable, one-line probe": asserts
# _orchestration/lane-provisioning.md carries EXACTLY ONE table row containing the literal
# substring "| ALLOW |" — the foundation row, the sole declared spine-write seat. Standing check
# per the ruling's own cure: `grep -c '| ALLOW |' <manifest> == 1`.
#
# Output: one ROW per matching line (line number + the row's lane column), then
#   SINGLE-WRITER-MANIFEST: <n>/1
#   VERDICT: PASS|FAIL
# exit 0 = PASS (n==1), exit 1 = FAIL (n==0 or n>1).
# exit 3 = UNREADABLE (manifest missing/unreadable) — NO verdict line printed in that case.
#
# --selfcheck: copies the real manifest into a temp dir, appends a SECOND "| ALLOW |" row (mutant
# lane), re-runs this probe against the mutated copy, and asserts the run FAILs at count 2/1.
# Prints SELFCHECK: PASS|FAIL. Never mutates the real manifest.
#
# Env override (selfcheck uses this to point at the mutated copy without touching the real file):
#   MANIFEST_FILE

set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"
if [[ -z "$REPO_ROOT" ]]; then
    REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"

# ⛔ FRAME: governance-probes-spine.sh runs THIS file's spine bytes in every
#   lane's worktree. The manifest is spine-owned (foundation is its sole writer), and a lane's branch copy is
#   correctly NOT merged up (currency is a READ) — measured at e47213f6, `architect` and
#   a module lane branch carry copies whose blobs differ from main's. Reading "$REPO_ROOT/…" on a lane therefore
#   judged a stale copy. Default: the hub (spine_write=ALLOW) reads its own worktree (the spine in progress);
#   every other seat reads ${SWM_REF:-the spine ref (scripts/spine-ref.sh)}. An explicit MANIFEST_FILE (the selfcheck's mutated copy) wins.
MANIFEST_FRAME="explicit"
if [[ -z "${MANIFEST_FILE:-}" ]]; then
    _rl_line="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>/dev/null)" || _rl_line=""
    if [[ " $_rl_line " == *" spine_write=ALLOW "* ]]; then
        MANIFEST_FILE="$REPO_ROOT/_orchestration/lane-provisioning.md"; MANIFEST_FRAME="WORKTREE(hub)"
    else
        # the spine ref (the one spine-ref resolver): SWM_REF if set (a replica knob), else the ONE resolver; unresolvable = UNREADABLE
        _swm_ref="${SWM_REF:-}"
        [[ -n "$_swm_ref" ]] || _swm_ref="$(bash "$REPO_ROOT/scripts/spine-ref.sh")" \
            || { echo "UNREADABLE: SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and SWM_REF unset (the one spine-ref resolver)" >&2; exit 3; }
        _swm_tmp="$(mktemp "${TMPDIR:-/tmp}/swm-manifest.XXXXXX")" || { echo "UNREADABLE: mktemp failed" >&2; exit 3; }
        trap 'rm -f "$_swm_tmp"' EXIT
        if git -C "$REPO_ROOT" show "${_swm_ref}:_orchestration/lane-provisioning.md" > "$_swm_tmp" 2>/dev/null && [[ -s "$_swm_tmp" ]]; then
            MANIFEST_FILE="$_swm_tmp"; MANIFEST_FRAME="SPINE(${_swm_ref})"
        else
            echo "UNREADABLE: manifest not readable at ${_swm_ref}:_orchestration/lane-provisioning.md (spine frame; the lane copy is NOT substituted)" >&2
            exit 3
        fi
    fi
fi

run_selfcheck() {
    local sc_dir out rc
    sc_dir="$(mktemp -d "${TMPDIR:-/tmp}/single-writer-manifest-selfcheck.XXXXXX")"

    if [[ ! -r "$REPO_ROOT/_orchestration/lane-provisioning.md" ]]; then
        echo "SELFCHECK: FAIL (real manifest unreadable at $REPO_ROOT/_orchestration/lane-provisioning.md)"
        rm -rf "$sc_dir"
        exit 1
    fi

    cp "$REPO_ROOT/_orchestration/lane-provisioning.md" "$sc_dir/lane-provisioning.md"
    printf '| mutant | module/mutant | mutant-2026-09-23-r1 | ALLOW | 0000000000000000000000000000000000000000 | 2026-09-23T00:00:00Z |\n' >> "$sc_dir/lane-provisioning.md"

    out="$(MANIFEST_FILE="$sc_dir/lane-provisioning.md" "$SELF" 2>&1)"
    rc=$?

    if [[ $rc -eq 1 ]] \
       && printf '%s\n' "$out" | command grep -Fq "VERDICT: FAIL" \
       && printf '%s\n' "$out" | command grep -Fq "SINGLE-WRITER-MANIFEST: 2/1" \
       && printf '%s\n' "$out" | command grep -Fq "lane=mutant"; then
        echo "SELFCHECK: PASS (mutated copy with a seeded second ALLOW row correctly FAILed at 2/1, naming the seeded row)"
        rm -rf "$sc_dir"
        exit 0
    else
        echo "SELFCHECK: FAIL (mutated copy did not fail as expected; rc=$rc)"
        echo "--- mutated run output ---"
        printf '%s\n' "$out"
        rm -rf "$sc_dir"
        exit 1
    fi
}

if [[ "${1:-}" == "--selfcheck" ]]; then
    run_selfcheck
fi

if [[ ! -r "$MANIFEST_FILE" ]]; then
    echo "UNREADABLE: manifest not readable at $MANIFEST_FILE" >&2
    exit 3
fi

rows_found=0
while IFS= read -r hit; do
    [[ -z "$hit" ]] && continue
    lineno="${hit%%:*}"
    rest="${hit#*:}"
    lane="$(printf '%s\n' "$rest" | sed -E 's/^\|[[:space:]]*([^|]*)\|.*/\1/' | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//')"
    printf 'ROW: line=%s lane=%s\n' "$lineno" "$lane"
    rows_found=$((rows_found+1))
done < <(command grep -n -F '| ALLOW |' "$MANIFEST_FILE")

echo "SINGLE-WRITER-MANIFEST: ${rows_found}/1 [frame: ${MANIFEST_FRAME}]"
if [[ $rows_found -eq 1 ]]; then
    echo "VERDICT: PASS"
    exit 0
else
    echo "VERDICT: FAIL"
    exit 1
fi
