#!/usr/bin/env bash
# probe_efficiency_budget.sh — the budget probe (E6 added later; the S-spec cap applies). A MEASURING INSTRUMENT that can FAIL: every bar with a ruled number is
#   PASS/FAIL; every bar with NO ruled number (E6a/E6b — "no number is set here", 0252 §1) is REPORTED with its
#   frame and never scored (DISC-A-NUMBER-CARRIES-ITS-FRAME: an invented bar is a fake measurement).
#
# BARS (bytes = `wc -c`, 1 KB = 1024 B; frame printed per line):
#   E1  CLAUDE.md                                   ≤ 16384 B
#   E2  rule index loaded at boot = _index/boot-roster.md (generated)   ≤ 8192 B
#   E3  total a seat reads at session start         ≤ 40960 B   PER SEAT: CLAUDE.md + THAT
#       seat's def (every .claude/agents/ def is a bar E3:<name>) + SessionStart hook output up to the creed-scan
#       call-out (0299 §1(c)) + _boot/BOOTSTRAP.md + _boot/CHARTER-<lane>.md; a missing component = UNREADABLE (exit 3). The
#       gitignored seat memory index and home-dir auto-memory are NOT shipped, so they are reported beside E3, not in it
#   E4  unwired rules shipped = 0                   (governance.tsv rows with ship=generic AND strength=UNWIRED)
#   P1  every MERGE/RETIRE row in _index/layers.tsv names its protection's carrier — survivor · mechanism ·
#       boot-creed, or `record` PROVEN by baseline non-membership
#   P2  net governance coverage (index PREDICATE ∪ disciplines.md §0) ≥ the pinned BEFORE side
#       (_index/coverage-baseline.tsv @ a4d6a14d) and no baseline protection LOST
#   S   each S mechanism spec ≤ 8192 B, AND carries the five lens lines + the 0252 §3 limit line (LENS)
#       (0247 §3 — the ONLY document for its mechanism; a mechanism
#       with no spec file yet reports ABSENT = FAIL, never skipped)
#   E6a synchronous commit path (REPORT): wall-clock of `creed-scan.sh --staged` (commit-msg) — a COMPONENT
#       lower bound; pre-commit is not timed here and is labelled NO RECORD
#   E6b async hub path (REPORT): per hub commit, AUDIT receipt-id time (ledger/receipts.jsonl) − committer time;
#       model tokens / $ = read from ledger/auditor-usage.jsonl (SET-0067/0068 recorder; NO RECORD only if absent/empty)
#   PRESSURE AXES (REPORT, never scored; the exit code stays the ship gate): E7 restart read-cost
#       (E3:orc + dispatch/LATEST.md, target 40960 B) · E9 LATEST (target 16384 B) · E8 rulings per landed set · E10
#       engine non-blank lines + per-file share + per-script bytes (baseline = the commit adding its anchor) · the
#       COST-OF-THE-ARC row (commits · audits · rulings · operator pens) over the window from the arc-anchor seal
#       · E12-PB loop-cure ratios (a breach prints `E12-PB HALT:` and never moves the exit)
#
# USAGE: probe_efficiency_budget.sh [--root DIR] [--hook-bytes N] [--no-e6]
#   --root        tree to measure (default: this repo) — "the probe runs on the package" (0244 §3 step 6)
#   --hook-bytes  the E3 hook component if already measured = boot-check.sh output bytes BEFORE its
#                 `[creed-scan source:` line (skips running boot-check.sh, ~25 s)
# EXIT: 0 every scored bar PASS · 1 a scored bar FAILs · 3 UNREADABLE (a required input missing — never a PASS)
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"; HOOK_BYTES=""; E6=1; E12ONLY=""
while [ $# -gt 0 ]; do case "$1" in
    --root) ROOT="$2"; shift 2 ;; --hook-bytes) HOOK_BYTES="$2"; shift 2 ;; --no-e6) E6=0; shift ;; --e12-only) E12ONLY=1; shift ;;
    *) echo "BUDGET-PROBE: UNREADABLE -- unknown arg $1"; exit 3 ;; esac; done
cd "$ROOT" || { echo "BUDGET-PROBE: UNREADABLE -- root $ROOT"; exit 3; }
SHA="$(git rev-parse --short HEAD 2>/dev/null || echo no-git)"
FAIL=0; SCORED=0
# ── E12: the loop-cure ceilings, named E12-PB. A
#    PRESSURE AXIS (reported, never scored; the exit code stays the ship gate): a breach prints `E12-PB HALT: <ratio> <value> > <ceiling> (<frame>)`
#    and NEVER changes this probe's exit; the boundary (scripts/audit-seal.sh) writes the register line and boot-check.sh
#    re-prints the HALT line, so a breach is loud, recorded and inherited (inv #5).
#    Ratios 1 and 2 read ONE ROLLING WINDOW = [D-6 00:00Z, D+1 00:00Z), D = HEAD's committer UTC day, on --first-parent
#    history, membership by committer time (ratio 1 moved off the per-session frame, under which
#    every 1-3-commit session breached). Ratio 1 = counted seals / worker commits, floored at A1 = the first --first-parent
#    commit adding scripts/audit-seal.sh (it scores only the regime A1 creates): a counted seal is a boundary
#    seal (`[audit] seal (n=K) … boundary=restart|shutdown`); a pre-A1-form seal (`[audit] seal <40-hex> …`) after A1 is an
#    ANOMALY, printed and counted; before A1 it is printed as `pre-A1 seals <n> (prior regime, not scored)`; `manual` and
#    unrecognized seals are excluded from both sides; no A1 commit = UNREADABLE; fewer than 10 worker commits = UNSCORED;
#    the ceiling is 1/3 by the integer test 3 x seals <= worker. E12_PENDING_BOUNDARY=1 (set by
#    audit-seal.sh before it commits) adds the pending seal. Ratio 2 = cure sets / classed RATIFIED sets whose
#    _ratification/SET-NNNN.md was added in the window; fewer than 4 classed = UNSCORED; integer test 2 x cure <= classed.
#    Ratio 3 reads ledger/restarts/<lane>.tsv per lane on the UTC day of that lane's latest line.
#    NO RECORD / UNSCORED is never a PASS. Python exit: 0 scored, no breach · 4 a breach · 5 a NO RECORD ratio.
e12_block() {
python3 - "${E12_RESTARTS_DIR:-ledger/restarts}" "${E12_PENDING_BOUNDARY:-}" <<'E12EOF'
import os, re, subprocess, sys, glob, collections, datetime
def git(*a):
    r = subprocess.run(["git", *a], capture_output=True)
    return r.stdout.decode(errors="replace") if r.returncode == 0 else ""
# A counted seal: a boundary seal (`boundary=restart|shutdown`, written by scripts/audit-seal.sh) OR a
# pre-A1 per-commit seal (`[audit] seal <40-hex> …`), so history inside the window is not silently dropped. Any other
# `[audit] seal` subject (`boundary=manual`, or an unrecognized shape) is EXCLUDED from both sides and its count printed.
BND = re.compile(r"^\[audit\] seal \(n=\d+\) .*boundary=(restart|shutdown)\b")
PRE_A1 = re.compile(r"^\[audit\] seal [0-9a-f]{40}\b")
pending = sys.argv[2] == "1"
halts = []; norec = False
# The window both ratio 1 and ratio 2 read: [D-6 00:00Z, D+1 00:00Z), D = HEAD's committer
# UTC day, --first-parent, membership by committer time (%ct).
hct = git("log", "-1", "--format=%ct", "HEAD").strip()
if not hct.isdigit():
    print("  E12-PB REPORT  seals/worker: NO RECORD (HEAD committer time unreadable) · ceiling 1/3")
    print("  E12-PB REPORT  cure-sets/classed-sets: NO RECORD (HEAD committer time unreadable) · ceiling 0.50")
    norec = True
else:
    hday = datetime.datetime.fromtimestamp(int(hct), datetime.timezone.utc).date()
    d0 = hday - datetime.timedelta(days=6)
    t0 = int(datetime.datetime(d0.year, d0.month, d0.day, tzinfo=datetime.timezone.utc).timestamp())
    t1 = t0 + 7 * 86400   # exclusive: 00:00Z of the UTC day after HEAD's
    w2 = f"rolling window [{d0.isoformat()}T00:00Z, {(hday + datetime.timedelta(days=1)).isoformat()}T00:00Z) = 7 UTC days ending on HEAD's committer UTC day, --first-parent"
    # Ratio 1: counted seals / worker commits over [max(D-6 00:00Z, A1), D+1 00:00Z), A1 =
    # the committer time of the first --first-parent commit that adds scripts/audit-seal.sh (SET-0151's landing). Inside
    # the window a boundary seal counts; a pre-A1-form seal there is an ANOMALY, printed and counted (a regression signal,
    # inv #5); manual/unrecognized seals are excluded from both sides. Seals before A1 inside the 7 days are printed as the
    # prior regime, never scored. No A1 commit = UNREADABLE (never a guess). UNSCORED below 10 worker commits; the
    # ceiling is exactly one third as the integer test 3 x seals <= worker (no floating-point compare in a ceiling).
    a1l = git("log", "--first-parent", "--diff-filter=A", "--reverse", "--format=%ct", "--", "scripts/audit-seal.sh").split()
    if not a1l or not a1l[0].isdigit():
        print(f"  E12-PB REPORT  seals/worker UNREADABLE (no A1 commit: no --first-parent commit adds scripts/audit-seal.sh) · ceiling 1/3")
        norec = True
    else:
        a1 = int(a1l[0]); s0 = max(t0, a1)
        seals = worker = excl = anom = prior = 0
        # no --since: its walk stops early on out-of-order committer dates; every row is filtered by %ct instead
        for l in git("log", "--first-parent", "--format=%ct%x09%s").splitlines():
            ct, _, s = l.partition("\t")
            if not ct.isdigit() or not (t0 <= int(ct) < t1): continue
            if int(ct) < s0:
                if s.startswith("[audit] seal"): prior += 1
                continue
            if s.startswith("[audit] seal"):
                if BND.match(s): seals += 1
                elif PRE_A1.match(s): seals += 1; anom += 1
                else: excl += 1
            else: worker += 1
        a1s = datetime.datetime.fromtimestamp(a1, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        w1 = (f"A1-floored window [{a1s} (A1), {(hday + datetime.timedelta(days=1)).isoformat()}T00:00Z) = A1 to the end of HEAD's committer UTC day, --first-parent"
              if a1 > t0 else w2) + (" + the pending boundary seal" if pending else "")
        if pending: seals += 1
        tail = f"{excl} manual/unrecognized seal(s) excluded; pre-A1 seals {prior} (prior regime, not scored); anomalies {anom} (pre-A1-form seals after A1, counted); {w1}"
        if worker >= 10:
            print(f"  E12-PB REPORT  seals/worker {seals / worker:.2f} = {seals}/{worker} (ceiling 1/3, integer test 3 x seals <= worker; {tail})")
            if 3 * seals > worker: halts.append(f"seals/worker {seals / worker:.2f} > 1/3 ({seals}/{worker}; {w1})")
        else:
            print(f"  E12-PB REPORT  seals/worker UNSCORED ({seals}/{worker}; fewer than 10 worker commits, the ratio-1 floor; {tail})")
    added = []; ct = None
    for l in git("log", "--first-parent", "--diff-filter=A", "--format=@%ct", "--name-only", "--", "_ratification/").splitlines():
        if l.startswith("@"): ct = int(l[1:]); continue
        if ct is not None and t0 <= ct < t1 and re.fullmatch(r"_ratification/SET-\d{4}\.md", l.strip()): added.append(l.strip())
    classed = cure = uncl = 0
    for p in sorted(set(added)):
        t = git("show", f"HEAD:{p}")
        d = re.search(r"^- decision: (\S+)", t, re.M)
        if not (d and d.group(1).startswith("RATIFIED")): continue
        c = re.search(r"^- cures: (\S+)", t, re.M)
        if not c: uncl += 1; continue
        classed += 1
        if c.group(1) != "none": cure += 1
    if classed >= 4:
        r2 = cure / classed
        print(f"  E12-PB REPORT  cure-sets/classed-sets {r2:.2f} = {cure}/{classed} (ceiling 0.50, integer test 2 x cure <= classed; UNCLASSED {uncl} excluded; {w2})")
        if 2 * cure > classed: halts.append(f"cure-sets/classed-sets {r2:.2f} > 0.50 ({cure}/{classed}; {w2})")
    else:
        print(f"  E12-PB REPORT  cure-sets/classed-sets UNSCORED ({cure}/{classed} classed; fewer than 4 classed sets, the ratio-2 floor; UNCLASSED {uncl}; {w2})")
rd = sys.argv[1]; files = sorted(glob.glob(os.path.join(rd, "*.tsv")))
if not files:
    print(f"  E12-PB REPORT  restarts/UTC-day/lane: NO RECORD ({rd}/*.tsv absent) · restarts counted via seat-exit only")
    norec = True
else:
    parts = []
    for f in files:
        lane = os.path.basename(f)[:-4]
        days = [l.split("\t")[0][:10] for l in open(f, encoding="utf-8", errors="replace") if re.match(r"^\d{4}-\d{2}-\d{2}T", l)]
        if not days: parts.append(f"{lane} 0"); continue
        last = days[-1]; n = collections.Counter(days)[last]
        parts.append(f"{lane} {n} on {last}")
        if n > 6: halts.append(f"restarts/UTC-day/lane {n} > 6 (lane {lane}, UTC day {last}, {f})")
    print("  E12-PB REPORT  restarts/UTC-day/lane (ceiling 6; the lane's latest UTC day; restarts counted via seat-exit only): " + " · ".join(parts))
for h in halts: print(f"  E12-PB HALT: {h}")
sys.exit(4 if halts else (5 if norec else 0))
E12EOF
}
if [ -n "$E12ONLY" ]; then
    e12_block; r=$?
    # a breach (4) is a pressure line, never an exit change; only an unreadable block exits 3
    case "$r" in 0|4|5) exit 0 ;; *) echo "  E12-PB UNREADABLE (python3 rc=$r)"; exit 3 ;; esac
fi
need() { [ -r "$1" ] || { echo "BUDGET-PROBE: UNREADABLE -- required input absent: $1 (exit 3, never a silent PASS)"; exit 3; }; }
bytes() { wc -c < "$1" | tr -d ' '; }
bar() {  # <id> <measured> <cap> <what>
    SCORED=$((SCORED+1))
    if [ "$2" -le "$3" ]; then echo "  $1 PASS  $2 B ≤ $3 B  — $4"; else FAIL=1; echo "  $1 FAIL  $2 B > $3 B  — $4"; fi
}
echo "BUDGET-PROBE: root=$ROOT HEAD=$SHA (frame: bytes = wc -c; 1 KB = 1024 B)"

need CLAUDE.md; E1="$(bytes CLAUDE.md)"; bar E1 "$E1" 16384 "CLAUDE.md"

need disciplines.md
# E2 re-pointed: the boot roster is the
#   GENERATED _index/boot-roster.md that boot-check.sh prints, no longer the hand-kept disciplines.md §0 body.
ROSTER="_index/boot-roster.md"
[ -s "$ROSTER" ] || { echo "BUDGET-PROBE: UNREADABLE -- $ROSTER absent or empty (E2 cannot be measured)"; exit 3; }
E2="$(bytes "$ROSTER")"
bar E2 "$E2" 8192 "$ROSTER (generated boot roster)"

LANE="$(scripts/resolve-lane.sh 2>/dev/null | tr ' ' '\n' | sed -n 's/^lane=//p' | head -1)"; LANE="${LANE:-foundation}"
# REQUIRED components: a missing one is UNREADABLE (exit 3), never 0 bytes — counting it as 0 could flip E3 from
#   FAIL to PASS (auditor 74e4ab44 F1). The seat memory index is gitignored (absent on the package by design), so it
#   is NOT an E3 component; it is reported beside E3 when present, never added and never zero-filled.
# E3 is PER-SEAT: E3 = CLAUDE.md + the booting seat's OWN def + the lane boot files +
#   the hook component, scored once per def. The seat set is EVERY def under .claude/agents/ (a superset of the
#   census-counted bootable seats: orc.md and architect.md launch via `claude --agent`, the rest are subagent defs).
#   A superset can over-measure, never let a seat escape; a def cannot leave the set by dropping a frontmatter key.
#   The boot files are THIS tree's lane; run with --root on a lane's worktree to measure that lane's own.
# ACTUAL BOOT READ: a seat's _boot/ components are ONLY the files its
#   own def's frontmatter `initialPrompt` names (orc names CHARTER-$lane + BOOTSTRAP; architect names BOOTSTRAP only,
#   so CHARTER-architect is not counted; a def with no initialPrompt loads none). A NAMED file absent = UNREADABLE.
E3=$E1; E3LIST="CLAUDE.md=$E1"
seatboot() {  # <def> -> the _boot/ files its initialPrompt names, one per line (CHARTER-$lane resolved to this lane)
    awk '/^---$/{n++; next} n==1 && /^initialPrompt:/{p=1} n==1 && p' "$1" | {
        t="$(cat)"
        case "$t" in *"_boot/CHARTER-"*) echo "_boot/CHARTER-${LANE}.md" ;; esac
        case "$t" in *"_boot/BOOTSTRAP.md"*) echo "_boot/BOOTSTRAP.md" ;; esac; }
}
SEATDEFS="$(find .claude/agents -type f -name '*.md' 2>/dev/null | LC_ALL=C sort)"
[ -n "$SEATDEFS" ] || { echo "BUDGET-PROBE: UNREADABLE -- no seat def under .claude/agents/ (E3 is per-seat; 0 seats is not a measurement)"; exit 3; }
# Hook output is FAIL-CLOSED (auditor 8c412c4f F1): a crashed boot-check emits FEWER bytes, which would lower E3
#   toward a false PASS. So: rc must be 0 AND the output must pass the expected-line census below; a supplied
#   --hook-bytes must be a positive integer. Anything else is UNREADABLE (exit 3), never a smaller number.
if [ -z "$HOOK_BYTES" ]; then
    need scripts/boot-check.sh
    # --measure: boot-check's ONE acceptance of a measuring caller (header of scripts/boot-check.sh): rc 0, or rc 3 with exactly
    #   one `BOOT-RECORD: HALT missing=` line AND the `[creed-scan source: ` line; anything else keeps its non-zero rc here.
    HOOK_OUT="$(bash scripts/boot-check.sh --measure 2>&1)"; HOOK_RC=$?
    [ "$HOOK_RC" -eq 0 ] || { echo "BUDGET-PROBE: UNREADABLE -- boot-check.sh exited $HOOK_RC (its output size is not a measurement)"; exit 3; }
    # EXPECTED-LINE CENSUS (auditor d2ace082 F1): `BOOT-CHECK:` is line ~33 of ~132, NOT the last line, and
    #   boot-check.sh exits 0 (bar the measured BOOT-RECORD HALT) with its children under `|| true` — so a crashed child after line 33 shrank
    #   the output with rc=0. Every child's summary line must appear EXACTLY once, and none may be in its
    #   degraded form (runner fault / skipped / absent-at-spine). Order = boot-check.sh emission order.
    for pfx in BOOT-CHECK HOOK-CHECK SURFACE-CONFORM-CHECK GOV-PROBES-CHECK STATE GOVCHECK-CHECK PARK-CHECK CREED-CHECK DEFER-CHECK; do
        c="$(printf '%s\n' "$HOOK_OUT" | command grep -c "^${pfx}: ")"
        [ "$c" = 1 ] || { echo "BUDGET-PROBE: UNREADABLE -- boot-check.sh output carries ${c} '${pfx}:' line(s), expected exactly 1 (a child did not complete; its output size is not a measurement)"; exit 3; }
    done
    DEG="$(printf '%s\n' "$HOOK_OUT" | command grep -E '^SURFACE-CONFORM-CHECK: (not-yet-at|rc=[0-9]+ · UNREADABLE)|^STATE: \(declared-condition line SKIPPED|^CREED-CHECK: SKIPPED' | head -1)"
    [ -z "$DEG" ] || { echo "BUDGET-PROBE: UNREADABLE -- boot-check.sh child degraded: ${DEG:0:120}"; exit 3; }
    # POSITIVE forms (auditor 6ab17855 F1): a runner fault prints its OWN `SURFACE-CONFORM: UNREADABLE` line, which
    #   boot-check adopts as the verdict — a deny-list of fallback texts cannot see it. So the surface line must be
    #   rc 0|1 with a real VERDICT, and STATE must be one of its two declared states. Anything else is exit 3.
    printf '%s\n' "$HOOK_OUT" | command grep -Eq '^SURFACE-CONFORM-CHECK: rc=[01] · VERDICT: (PASS|FAIL)' \
        || { echo "BUDGET-PROBE: UNREADABLE -- SURFACE-CONFORM-CHECK is not rc=0|1 with a VERDICT (runner fault): $(printf '%s\n' "$HOOK_OUT" | command grep -m1 '^SURFACE-CONFORM-CHECK: ' | cut -c1-120)"; exit 3; }
    printf '%s\n' "$HOOK_OUT" | command grep -Eq '^STATE: (PRE-GENESIS|GENESIS) ' \
        || { echo "BUDGET-PROBE: UNREADABLE -- STATE line is not a declared state (PRE-GENESIS|GENESIS)"; exit 3; }
    printf '%s\n' "$HOOK_OUT" | command grep -Eq '^GOV-PROBES-CHECK: rc=[0-9]+ · [0-9]+ PASS · [0-9]+ FAIL · 0 UNREADABLE of [1-9]' \
        || { echo "BUDGET-PROBE: UNREADABLE -- GOV-PROBES-CHECK line has no summary or an UNREADABLE probe (runner fault)"; exit 3; }
    # The creed-scan boundary call-out is NOT an E3 component (E3 is the boot-loaded governance read, per seat): it is a linter surfaced at the
    #   boundary, not boot-loaded governance. It is boot-check section (5), which always opens with the spine
    #   runner's `[creed-scan source: ` line (scripts/creed-scan-spine.sh). The E3 component is every byte BEFORE that
    #   line. The marker must appear exactly once, or the boundary is unknown and the size is not a measurement.
    c="$(printf '%s\n' "$HOOK_OUT" | command grep -c '^\[creed-scan source: ')"
    [ "$c" = 1 ] || { echo "BUDGET-PROBE: UNREADABLE -- boot-check.sh output carries ${c} '[creed-scan source:' line(s), expected exactly 1 (the E3/creed-scan boundary is unknown)"; exit 3; }
    HOOK_ALL="$(printf '%s\n' "$HOOK_OUT" | wc -c | tr -d ' ')"
    PRECREED="$(printf '%s\n' "$HOOK_OUT" | awk '/^\[creed-scan source: /{exit} {print}' | wc -c | tr -d ' ')"
    # The E3 hook component (the same per-seat boot-read frame as the call-out rule above) is the STABLE
    #   surface = roster + census + each `*-CHECK:` one-line SUMMARY. Every 4-space-indented DETAIL block contiguous
    #   under a `*-CHECK:` summary (printed only in a non-nominal state: SURFACE-CONFORM drift boot-check.sh:143-145,
    #   GOV-PROBE non-PASS :158, AUDITOR-LIVENESS rc!=0 :176) is a transient diagnostic and is dropped BY CONSTRUCTION,
    #   never one block named at a time. The summary line stays counted. Indented lines under a non-`*-CHECK:` line, and
    #   the 2-space `  ⚠` warnings (directives a seat acts on), are counted (fail toward counting). The lines still PRINT.
    HOOK_BYTES="$(printf '%s\n' "$HOOK_OUT" | awk '/^\[creed-scan source: /{exit}
        /^[A-Z][A-Z0-9-]*-CHECK: /{blk=1; print; next}
        blk && /^    /{next}
        {blk=0; print}' | wc -c | tr -d ' ')"
    echo "     (hook: $HOOK_ALL B total; $((HOOK_ALL-PRECREED)) B creed-scan call-out excluded; $((PRECREED-HOOK_BYTES)) B *-CHECK detail blocks excluded (transient diagnostics, not boot-loaded surface))"
fi
case "$HOOK_BYTES" in ''|*[!0-9]*|0) echo "BUDGET-PROBE: UNREADABLE -- hook bytes '$HOOK_BYTES' is not a positive integer"; exit 3 ;; esac
E3=$((E3+HOOK_BYTES)); E3LIST="$E3LIST SessionStart-hook-output(pre-creed-scan)=$HOOK_BYTES"
NSEAT=0
while IFS= read -r d; do
    b="$(bytes "$d")"; NSEAT=$((NSEAT+1)); s="$(basename "$d" .md)"; sb=0; sl=""
    while IFS= read -r f; do [ -n "$f" ] || continue; need "$f"; fb="$(bytes "$f")"; sb=$((sb+fb)); sl="$sl $f=$fb"; done <<< "$(seatboot "$d")"
    bar "E3:$s" "$((E3+b+sb))" 40960 "session-start read, seat def $d=$b + boot-read(initialPrompt):${sl:- none} + lane=$LANE: $E3LIST"
    [ "$s" = orc ] && E3ORC=$((E3+b+sb))
done <<< "$SEATDEFS"
echo "     (E3 scored per seat: $NSEAT defs under .claude/agents/, every one a bar)"
[ -r .claude/agent-memory/orc/MEMORY.md ] && echo "     (beside E3, not counted: seat memory index $(bytes .claude/agent-memory/orc/MEMORY.md) B — gitignored, not shipped)"

need _index/governance.tsv
E4="$(awk -F'\t' '/^#/{next} NF>=11 && $9=="generic" && $11=="UNWIRED"{n++; ids=ids $1 " "} END{print n+0 "\t" ids}' _index/governance.tsv)"
E4N="${E4%%$'\t'*}"; E4IDS="${E4#*$'\t'}"
E4D="$(awk -F'\t' '/^#/{next} NF>=11 && $9=="generic"' _index/governance.tsv | grep -c .)"
SCORED=$((SCORED+1))
if [ "$E4N" -eq 0 ]; then echo "  E4 PASS  0 of $E4D shipped rows unwired"
else FAIL=1; echo "  E4 FAIL  $E4N of $E4D shipped rows unwired: $E4IDS"; fi

# ── GOVERNANCE-PRESERVATION POLES. Efficiency may relocate / mechanize / consolidate a
#   protection, never remove one. P1: every MERGE/RETIRE row in _index/layers.tsv names where its protection now lives
#   (_index/preservation.tsv, else its MERGE target resolved to a CURRENT index id). P2: net coverage — protections
#   enforced (index strength=PREDICATE) or boot-loaded (disciplines.md §0) — may not fall below the pinned BEFORE side
#   (_index/coverage-baseline.tsv). Existence is checked here; FIRING is proven at 0247 §7 step 6.
need _index/layers.tsv; need _index/preservation.tsv; need _index/coverage-baseline.tsv
PV_TMP="$(mktemp -d)"
# P1/P2 boot set = the ids the GENERATED roster actually boots, read from the same file E2 measures.
command grep -oE '^- \*\*DISC-[A-Z0-9-]+' "$ROSTER" | sed 's/^- \*\*//' | sort -u > "$PV_TMP/boot"
[ -s "$PV_TMP/boot" ] || { echo "BUDGET-PROBE: UNREADABLE -- $ROSTER yields 0 ids (P2 cannot be measured)"; rm -rf "$PV_TMP"; exit 3; }
: > "$PV_TMP/mech_ok"
awk -F'\t' '/^#/{next} $2=="mechanism"{print $3}' _index/preservation.tsv | while IFS= read -r w; do
    case "$w" in
        gate:*|probe:*) [ -e "${w#*:}" ] && printf '%s\n' "$w" >> "$PV_TMP/mech_ok" ;;
        scanner:*) command grep -Eq "^[[:space:]]+${w#scanner:}/regex\)" scripts/creed-scan.sh 2>/dev/null && printf '%s\n' "$w" >> "$PV_TMP/mech_ok" ;;
    esac
done
PV_OUT="$(awk -F'\t' -v BOOT="$PV_TMP/boot" -v MOK="$PV_TMP/mech_ok" '
    BEGIN { while ((getline l < BOOT) > 0) boot[l]=1; while ((getline l < MOK) > 0) mok[l]=1 }
    FILENAME ~ /governance\.tsv$/   { if ($0 ~ /^#/) next; idx[$1]=1; if ($11=="PREDICATE") pred[$1]=1; next }
    FILENAME ~ /layers\.tsv$/       { if ($0 ~ /^#/ || NF<4) next; if ($3=="MERGE"||$3=="RETIRE") { disp[$1]=$3; split($4,a," "); tgt[$1]=a[1]; order[++n]=$1 }; next }
    FILENAME ~ /preservation\.tsv$/ { if ($0 ~ /^#/ || NF<3) next; if ($2=="alias") alias[$1]=$3; else { pk[$1]=$2; pw[$1]=$3 }; next }
    FILENAME ~ /coverage-baseline\.tsv$/ { if ($0 ~ /^#/ || NF<2) next; base[$1]=1; nb++; next }
    function mkcarrier(   i) { for (i in tgt) carrier[tgt[i]]=1; for (i in pw) carrier[pw[i]]=1; for (i in alias) { carrier[i]=1; carrier[alias[i]]=1 } }
    function resolve(id, d,   t) {   # -> "OK:<kind>:<where>" | "FAIL:<why>"
        if (d > 8) return "FAIL:merge-chain-too-deep"
        if (id in pk) {
            if (pk[id]=="survivor")   return ((pw[id] in idx) ? "OK:survivor:" pw[id] : "FAIL:survivor-not-an-index-id:" pw[id])
            if (pk[id]=="mechanism")  return ((pw[id] in mok) ? "OK:mechanism:" pw[id] : "FAIL:mechanism-absent:" pw[id])
            if (pk[id]=="boot-creed") return ((id in boot) ? "OK:boot-creed:§0" : "FAIL:claims-boot-creed-but-not-in-§0")
            if (pk[id]=="record") {   # PROVEN by baseline non-membership, never asserted
                if (disp[id]!="RETIRE") return "FAIL:record-on-a-MERGE-row"
                if (id in base)         return "FAIL:record-row-is-a-baseline-protection"
                # LIVE clauses of the 0259 §2 "i.e." (auditor 8b66fe14 F2; NO apostrophes in this single-quoted awk body): a protection gained AFTER the pinned baseline
                if (id in pred)         return "FAIL:record-row-is-a-live-PREDICATE-protection"
                if (id in boot)         return "FAIL:record-row-is-a-live-§0-protection"
                if (id in carrier)      return "FAIL:record-row-is-a-carrier"
                return "OK:record:-"
            }
            return "FAIL:" pk[id]
        }
        if (disp[id]=="RETIRE") return "FAIL:retire-with-no-preservation-row"
        t=tgt[id]; if (t in alias) t=alias[t]
        if (t in idx) return "OK:survivor:" t
        if (t in disp) return resolve(t, d+1)
        return "FAIL:merge-target-unresolved:" tgt[id]
    }
    function covered(id,   r, k, w) {
        if ((id in pred) || (id in boot)) return 1
        if (!(id in disp)) return 0
        r=resolve(id,0); if (r !~ /^OK:/) return 0
        split(r, k, ":"); w=substr(r, length(k[1] k[2])+3)
        if (k[2]=="mechanism" || k[2]=="boot-creed") return 1
        return ((w in pred) || (w in boot))
    }
    END {
        mkcarrier()
        for (i=1;i<=n;i++) { r=resolve(order[i],0); split(r,k,":"); if (k[1]=="OK") ok[k[2]]++; else { nf++; why=substr(r,6); sub(/:.*/,"",why); fw[why]++; fl=fl " " order[i] } }
        printf "P1|%d|%d|%d|%d|%d|%d|%s|%d|", n, n-nf, ok["survivor"]+0, ok["mechanism"]+0, ok["boot-creed"]+0, nf+0, fl, ok["record"]+0
        for (w in fw) printf "%s=%d ", w, fw[w]; printf "\n"
        after=0; for (b in base) { if (covered(b)) after++; else lost=lost " " b }
        for (x in pred) if (!(x in base)) { after++; gain=gain " " x }
        for (x in boot) if (!(x in base) && !(x in pred)) { after++; gain=gain " " x }
        printf "P2|%d|%d|%s|%s\n", nb, after, lost, gain
    }' _index/governance.tsv _index/layers.tsv _index/preservation.tsv _index/coverage-baseline.tsv)"
rm -rf "$PV_TMP"
P1L="$(printf '%s\n' "$PV_OUT" | command grep '^P1')"; P2L="$(printf '%s\n' "$PV_OUT" | command grep '^P2')"
[ -n "$P1L" ] && [ -n "$P2L" ] || { echo "BUDGET-PROBE: UNREADABLE -- preservation poles produced no result"; exit 3; }
# `|`, never a tab: bash `read` collapses consecutive whitespace-IFS chars, so an EMPTY field shifts every later one.
IFS='|' read -r _ P1N P1OK P1S P1M P1B P1F P1FL P1R P1W <<< "$P1L"
SCORED=$((SCORED+1))
if [ "$P1F" -eq 0 ]; then echo "  P1 PASS  $P1OK of $P1N MERGE/RETIRE rows name their carrier (survivor $P1S · mechanism $P1M [PROVISIONAL until step-6 firing] · boot-creed $P1B · record $P1R [proven: not in baseline, no row's carrier])"
else FAIL=1; echo "  P1 FAIL  $P1F of $P1N MERGE/RETIRE rows name no carrier [${P1W% }] (carriers: survivor $P1S · mechanism $P1M [PROVISIONAL] · boot-creed $P1B · record $P1R) :$P1FL"; fi
IFS='|' read -r _ P2B P2A P2LOST P2GAIN <<< "$P2L"
# An EMPTY before side makes "after >= before" vacuous (auditor 299feb6a F1, case 2) — unreadable, never a PASS.
[ "${P2B:-0}" -gt 0 ] || { echo "BUDGET-PROBE: UNREADABLE -- _index/coverage-baseline.tsv has 0 protection rows (P2 has no BEFORE side)"; exit 3; }
SCORED=$((SCORED+1))
if [ "$P2A" -ge "$P2B" ] && [ -z "$P2LOST" ]; then echo "  P2 PASS  net governance coverage $P2A >= $P2B before (frame: _index/coverage-baseline.tsv @ a4d6a14d; enforced PREDICATE ∪ boot roster (_index/boot-roster.md))${P2GAIN:+ · new:$P2GAIN}"
else FAIL=1; echo "  P2 FAIL  net governance coverage $P2A vs $P2B before (frame: _index/coverage-baseline.tsv @ a4d6a14d) · LOST:${P2LOST:- none}${P2GAIN:+ · new:$P2GAIN}"; fi

# S specs: the six mechanism specs + CANON is exempt (genesis-time cost, 0247 §3) + the door row is a discipline.
for spec in "MECH-SEAT:contracts/LAUNCH-CONTRACT.md" "MECH-WRITE:contracts/MECH-WRITE.md" \
            "MECH-CHANGE-AUTH:contracts/C-SET-AUTHORIZATION.md" "MECH-TRANSPORT:contracts/SPEC-DOORBELL.md" \
            "MECH-ENFORCE:contracts/SPEC-GOVERNANCE-INDEX.md" "MECH-AUDIT:agents/auditor-contract.md"; do
    n="${spec%%:*}"; f="${spec#*:}"
    if [ -r "$f" ]; then bar "S:$n" "$(bytes "$f")" 8192 "$f"
        # LENS ("the conformance probe checks the five are present") + the limit line
        #   verbatim. Whitespace-normalized match, so a re-wrap cannot fail it and a paraphrase cannot pass.
        miss=""
        for lens in "Server-side twin:" "Identity source:" "Role model:" "Install/upgrade path:" "Harness binding:"; do
            command grep -qF -- "**$lens**" "$f" || miss="$miss [$lens]"
        done
        { tr -s ' \n' ' ' < "$f" | command grep -qF -- "S binds a seat that has not read it only to the extent its enforcer cannot be bypassed by that seat. With local hooks (v1.6.5) that is an honest-operator property at n = 1; the server-side twin (" \
              && tr -s ' \n' ' ' < "$f" | command grep -qF -- "canon v1.6.6 candidate) is what makes it a guarantee."; } || miss="$miss [0252-limit-line]"
        SCORED=$((SCORED+1))
        if [ -z "$miss" ]; then echo "  S:$n LENS PASS  5 of 5 lens lines + the 0252 §3 limit line"
        else FAIL=1; echo "  S:$n LENS FAIL  missing:$miss"; fi
    else SCORED=$((SCORED+1)); FAIL=1; echo "  S:$n FAIL  ABSENT — $f does not exist yet (a mechanism with no spec cannot meet the cap)"; fi
done

# ── PRESSURE AXES — E7 · E9 · E8 · E10 (+ per-file share) · COST-OF-THE-ARC
#   (pressure axes). REPORTED, NEVER SCORED: no line below calls bar(),
#   touches SCORED or sets FAIL, so the exit code keeps meaning "the ship gate holds" (the exit code is the ship gate). A missing input (a
#   package tree carries no git history, ledger or dispatch/) prints NO RECORD and never moves the exit.
#   E10 baseline = the commit that FIRST adds the token E10-BASELINE-ANCHOR to this file (0313 §2.1: "the sha at which
#   E10 lands"), found by `git log -S`; before that commit lands, there is no baseline and the line says so.
echo "  -- PRESSURE AXES (REPORT ONLY, never scored: the exit code is the ship gate) --"
if [ -n "${E3ORC:-}" ] && [ -r dispatch/LATEST.md ]; then
    LB="$(bytes dispatch/LATEST.md)"
    echo "  E7 REPORT  $((E3ORC+LB)) B vs 40960 B target — restart read-cost = E3:orc $E3ORC B + dispatch/LATEST.md $LB B (frame: this tree at $SHA)"
    echo "  E9 REPORT  $LB B vs 16384 B target — dispatch/LATEST.md, the handoff a restarted seat reads first"
else echo "  E7 REPORT  NO RECORD — needs the E3:orc bar and dispatch/LATEST.md (E3:orc=${E3ORC:-absent}; LATEST $( [ -r dispatch/LATEST.md ] && echo present || echo absent))"; fi
E12_OUT="$(e12_block)"; E12_RC=$?; printf '%s\n' "$E12_OUT"
# E12-PB is a pressure axis (reported, never scored): neither a breach nor an unreadable block moves FAIL/SCORED.
case "$E12_RC" in 0|4|5) ;; *) echo "  E12-PB REPORT  NO RECORD — the E12 block exited non-zero (python3 rc=$E12_RC); never a PASS" ;; esac
python3 - "$SHA" <<'PYEOF' || echo "  PRESSURE REPORT  NO RECORD — the E10 block exited non-zero (python3 rc=$?)"
import os, re, subprocess, sys, json, datetime
HEAD = sys.argv[1]
def git(*a):
    try: r = subprocess.run(["git", *a], capture_output=True)
    except Exception: return None
    return r.stdout if r.returncode == 0 else None
def utc(sha):
    t = git("log", "-1", "--format=%ct", sha)
    return datetime.datetime.fromtimestamp(int(t), datetime.timezone.utc).strftime("%Y-%m-%dT%H:%MZ") if t and t.strip() else "?"
def nonblank(b): return sum(1 for l in b.split(b"\n") if l.strip())
SPEC = ["scripts", "agents", "probes/set-gate", "probes/governance*"]
def in_frame(p):
    s = p.split("/")
    return len(s) >= 2 and (s[0] in ("scripts", "agents") or (len(s) >= 3 and s[0] == "probes" and (s[1] == "set-gate" or s[1].startswith("governance"))))
# ── E10: non-blank lines over scripts/ + agents/ + probes/governance*/ + probes/set-gate/, every file (0313 §2.1).
lst = git("ls-files", "-z", "--", *SPEC)
if lst is not None:
    files, how = sorted(p for p in lst.decode().split("\0") if p and in_frame(p)), "every tracked file (git ls-files; working-tree bytes)"
else:
    files, how = [], "every file on disk (no git: os.walk)"
    for top in ["scripts", "agents", "probes"]:
        for d, _, fs in os.walk(top):
            files += [os.path.join(d, f) for f in fs if in_frame(os.path.join(d, f))]
    files.sort()
rows, absent = [], 0
for p in files:
    try: b = open(p, "rb").read()
    except OSError: absent += 1; continue
    rows.append((nonblank(b), len(b), p))
L = sum(r[0] for r in rows)
anc = git("log", "--format=%H", "-S", "E10-BASELINE-ANCHOR", "--", "probes/budget/probe_efficiency_budget.sh")
anc = anc.decode().split() if anc else []
if anc:
    base = anc[-1]
    names = [p for p in git("ls-tree", "-r", "-z", "--name-only", base, "--", "scripts", "agents", "probes").decode().split("\0") if p and in_frame(p)]
    cp = subprocess.run(["git", "cat-file", "--batch"], input="".join(f"{base}:{p}\n" for p in names).encode(), capture_output=True).stdout
    i, BL = 0, 0
    while i < len(cp):
        j = cp.index(b"\n", i); h = cp[i:j].split()
        if len(h) < 3: i = j + 1; continue
        n = int(h[2]); BL += nonblank(cp[j + 1:j + 1 + n]); i = j + 1 + n + 1
    bl = f"baseline {base[:8]} ({utc(base)}) = {BL} lines in {len(names)} files · delta {L - BL:+d}"
else:
    bl = "baseline NOT YET LANDED (no commit adds E10-BASELINE-ANCHOR to this probe; this tree is the baseline-to-be)"
print(f"  E10 REPORT  {L} non-blank lines in {len(rows)} files (frame: scripts/ + agents/ + probes/governance*/ + probes/set-gate/, {how}; {absent} listed-but-absent; HEAD {HEAD}) · {bl} (pressure axis between baseline and step I; at I the bar is delta <= 0, 0313 §2.1)")
top = sorted(rows, key=lambda r: -r[1])[:5]
print("  E10 per-script byte cap: NO NUMBER RULED (0281 §6 adopted the cap; 0313 §2.1 asks each share printed and the largest named) · largest by bytes: " + " · ".join(f"{p} {b} B" for _, b, p in top))
print("  E10 per-file share (non-blank lines · % of E10 · bytes · path), largest first:")
for n, b, p in sorted(rows, key=lambda r: (-r[0], r[2])):
    print(f"     {n:6d} {100.0 * n / L if L else 0:5.1f}% {b:8d} B  {p}")
PYEOF
# ── E8 + COST-OF-THE-ARC is an ORIGIN-ONLY pressure axis (0376 §5): its window-anchor ruling file
#    has no ship-carriers.tsv row, so this SHIPPED file names it nowhere, not even in a comment.
#    The measurement lives in a sibling script this repo keeps un-shipped (no manifest row); call
#    it by a generic relative path when present, and report NO RECORD when it is not (an adopter's
#    package, where the sibling was never copied).
ARC_HELPER="$(dirname "$0")/probe_cost_of_the_arc_origin.sh"
if [ -r "$ARC_HELPER" ]; then
    bash "$ARC_HELPER" "$SHA"
else
    echo "  E8 REPORT  NO RECORD — origin-only axis, probe_cost_of_the_arc_origin.sh not present on this tree"
    echo "  COST-OF-THE-ARC REPORT  NO RECORD — origin-only axis, probe_cost_of_the_arc_origin.sh not present on this tree"
fi

if [ "$E6" -eq 1 ]; then
    echo "  -- E6 (REPORT ONLY in this build; bars ruled: E6a med<=2s max<=10s once hooks record timing; E6b med<=3min max<=10min — scoring lands with those recorders) --"
    if [ -x scripts/creed-scan.sh ]; then
        m="$(mktemp)"; printf 'budget probe timing run\n' > "$m"
        t0="$(python3 -c 'import time;print(time.time())')"; bash scripts/creed-scan.sh --staged --msg "$m" >/dev/null 2>&1; rcs=$?
        t1="$(python3 -c 'import time;print(time.time())')"; rm -f "$m"
        echo "  E6a REPORT creed-scan --staged = $(python3 -c "print(round($t1-$t0,2))") s wall-clock (rc=$rcs; EMPTY staged set — a floor, not a commit; pre-commit hook: NO RECORD)"
    else echo "  E6a REPORT scripts/creed-scan.sh absent — NO RECORD"; fi
    # E6b source = auditor RECEIPT ids `R-<UTC ts>-AUDIT-<sha>-…` in ledger/receipts.jsonl (emission time). NOT
    #   audit-runs.log: its dated `<ts> audit <sha>` line format stopped at 2026-09-23 (later entries are prose), so
    #   a grep over it returned 4 stale samples — an inherited number (caught in review).
    if [ -r ledger/receipts.jsonl ]; then
        grep -oE '"R-[0-9]{8}T[0-9]{6}Z-AUDIT-[0-9a-f]{7,40}' ledger/receipts.jsonl | tr -d '"' | awk '!seen[$0]++' | tail -20 | python3 -c '
import sys,subprocess,datetime,statistics
def usage():
    # SET-0067/0068 recorder (scripts/auditor-usage-record.sh -> ledger/auditor-usage.jsonl, sealed with each audit).
    #   Absent file = NO RECORD; present = RECORDED rows + median list-price $ (frame: claude -p total_cost_usd,
    #   keyless Max plan = quota, not billed). The $ bar is unset until 20 rows exist.
    import json,os
    f="ledger/auditor-usage.jsonl"
    if not os.path.exists(f): return "NO RECORD (ledger/auditor-usage.jsonl absent)"
    c=[]
    for x in open(f):
        try: r=json.loads(x)
        except Exception: continue
        if r.get("status")=="RECORDED" and isinstance(r.get("total_cost_usd"),(int,float)): c.append(r["total_cost_usd"])
    if not c: return "NO RECORD (0 RECORDED rows in ledger/auditor-usage.jsonl)"
    bar="$ bar SET-ABLE" if len(c)>=20 else f"$ bar unset until 20 rows ({len(c)} of 20)"
    return f"RECORDED n={len(c)} rows, median ${statistics.median(c):.2f} list-price per run (ledger/auditor-usage.jsonl); {bar}"
d=[]
for l in sys.stdin:
    p=l.strip().split("-"); ts,sha=p[1],p[3]
    r=subprocess.run(["git","log","-1","--format=%ct",sha],capture_output=True,text=True)
    if r.returncode or not r.stdout.strip(): continue
    t=datetime.datetime.strptime(ts,"%Y%m%dT%H%M%SZ").replace(tzinfo=datetime.timezone.utc).timestamp()
    s=t-int(r.stdout)
    if s>0: d.append(s)
if d: print(f"  E6b REPORT auditor wall-clock per hub commit: median {statistics.median(d)/60:.1f} min · max {max(d)/60:.1f} min · n={len(d)} (last 20 AUDIT receipts; frame: receipt-id UTC ts − committer ts); tokens/$: {usage()}")
else: print("  E6b REPORT no AUDIT receipts resolvable — NO RECORD")'
    else echo "  E6b REPORT ledger/receipts.jsonl absent — NO RECORD"; fi
fi
[ "$FAIL" -eq 0 ] && { echo "BUDGET-PROBE: PASS ($SCORED scored bars)"; exit 0; }
echo "BUDGET-PROBE: FAIL ($SCORED scored bars; E6 unscored)"; exit 1
