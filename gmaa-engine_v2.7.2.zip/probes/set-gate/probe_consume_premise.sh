#!/usr/bin/env bash
# probe_consume_premise.sh — poles for PREMISE-AT-PICKUP, + an execution-lane
# SURFACE (an unknown flag was filed as a relay name and written to the marker).
# Refusal poles run the REAL front doors (they write nothing on refusal — asserted by marker delta).
# The recording pole runs consume-core against a THROWAWAY marker, so this probe never touches live state.
# Usage: probe_consume_premise.sh [module-worktree]   (module door is exercised when a lane worktree is given)
set -u
REPO="$(git rev-parse --show-toplevel)"
MOD="${1:-}"
FAILS=0; N=0
ok()   { N=$((N+1)); echo "POLE $1: OK — $2"; }
bad()  { N=$((N+1)); FAILS=$((FAILS+1)); echo "POLE $1: FAIL — $2"; }
# NOTE: the pipeline's status is tr's (0), so `|| echo 0` never fired and an ABSENT
# file printed EMPTY, not 0. Guard the file, not the pipeline.
lines(){ if [ -f "$1" ]; then wc -l < "$1" | tr -d ' '; else echo 0; fi; }

# ---- refusal poles on a door: <label> <worktree> <script> <marker> ----
door() {
    local lab="$1" wt="$2" sc="$3" mk="$4" b rc
    local x="${HUB_ARGS:-probe-x}"
    for c in "nopremise|consume $x" "malformed|consume $x --premise bogus" \
             "unknownflag|consume $x --bogus --premise holds@_rulings/9996" \
             "emptyvalue|consume $x --premise"; do
        name="${c%%|*}"; args="${c#*|}"
        b="$(lines "$wt/$mk")"
        (cd "$wt" && bash "$sc" $args) >/dev/null 2>&1; rc=$?
        if [ "$rc" -eq 2 ] && [ "$(lines "$wt/$mk")" = "$b" ]; then ok "$lab-$name" "rc=2, marker delta 0"
        else bad "$lab-$name" "rc=$rc, marker $b -> $(lines "$wt/$mk")"; fi
    done
}
HUB_ARGS="probe-src probe-x" door HUB "$REPO" "${HUB_SCRIPT:-$REPO/scripts/inboxf.sh}" ".claude/inboxf-seen"
if [ -n "$MOD" ]; then door MODULE "$MOD" "$REPO/scripts/inbox.sh" ".claude/inbox-seen"; fi

# ---- recording pole: consume-core against a throwaway marker ----
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
out="$(bash -c ". '$REPO/scripts/consume-core.sh'; core_init '$T/seen' '$T/shown';
        core_take_premise fixture-1 --premise holds@_rulings/9996 || exit 9;
        core_consume_one \"\${CORE_ARGS[0]}\"; cat '$T/seen'; echo ---; cat '$T/seen.premise'" 2>&1)"
if printf '%s' "$out" | grep -qx 'fixture-1' && printf '%s' "$out" | grep -qE $'\tfixture-1\tholds@_rulings/9996$'; then
    ok RECORD "marker gets the NAME only; the pair lands in <marker>.premise"
else bad RECORD "$(printf '%s' "$out" | head -3 | tr '\n' ' ')"; fi
if printf '%s' "$out" | grep -qE '^(--premise|holds@)'; then bad RECORD-NOJUNK "flag text reached the marker"; else ok RECORD-NOJUNK "no flag text in the marker"; fi

echo "CONSUME-PREMISE-PROBE: $((N-FAILS))/$N poles OK"
[ "$FAILS" -eq 0 ]
