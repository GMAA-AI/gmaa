#!/usr/bin/env bash
# probes/set-gate/probe_census_parity.sh
#
# (MECH-WRITE): asserts the three "declared spine" censuses are the SAME SET
# (order-independent):
#   1. agents/pre-commit-hook.sh   SPINE_PATHS    (multi-line bash array)
#   2. scripts/ratify.sh           SPINE_PREFIXES (single-line bash array, ~:135)
#   3. scripts/declared-spine-paths.sh (the emitter; stdout, one path per line)
#
# Output: one ROW per path in the union of the three sets, naming which source(s) carry it, then
#   CENSUS-PARITY: <matched>/<total>
#   VERDICT: PASS|FAIL
# exit 0 = PASS, exit 1 = FAIL.
# exit 3 = UNREADABLE (a source could not be located/parsed) — NO verdict line is printed in that
# case (an unreadable source must never be silently read as "empty set = still equal").
#
# --selfcheck: copies the three real sources into a temp dir, drops ONE path from the pre-commit
# copy's SPINE_PATHS block, re-runs this probe against the mutated copies, and asserts the run
# FAILs and NAMES the dropped path. Prints SELFCHECK: PASS|FAIL. Never mutates the real repo files.
#
# Env overrides (selfcheck uses these to point at mutated copies without touching the real files):
#   PRECOMMIT_FILE, RATIFY_FILE, EMITTER_FILE

set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"
if [[ -z "$REPO_ROOT" ]]; then
    REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"

# ⛔ FRAME (MECH-WRITE): governance-probes-spine.sh runs THIS file's spine bytes in every
#   lane's worktree. The three censuses it compares are ENFORCER bytes whose executing copy is the SPINE's (one
#   shared hook install; spine-run ratify/emitter) — a lane's branch copy is correctly NOT merged up,
#   so reading "$REPO_ROOT/…" on a lane judged files that never execute (measured at e47213f6:
#   rc=3 on `architect` + a module lane, whose branches predate declared-spine-paths.sh). Default: the hub
#   (spine_write=ALLOW) reads its own worktree; every other seat reads ${CENSUS_REF:-the spine ref (scripts/spine-ref.sh)}. An explicit
#   *_FILE env override (the selfcheck's mutated copies) always wins.
CENSUS_FRAME="WORKTREE(hub)"
_rl_line="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>/dev/null)" || _rl_line=""
if [[ " $_rl_line " != *" spine_write=ALLOW "* ]]; then
    # the spine ref (the one spine-ref resolver): CENSUS_REF if set (a replica knob), else the ONE resolver; unresolvable = UNREADABLE
    _cp_ref="${CENSUS_REF:-}"
    [[ -n "$_cp_ref" ]] || _cp_ref="$(bash "$REPO_ROOT/scripts/spine-ref.sh")" \
        || { echo "UNREADABLE: SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and CENSUS_REF unset (the one spine-ref resolver)"; exit 3; }
    CENSUS_FRAME="SPINE(${_cp_ref})"
    _cp_dir="$(mktemp -d "${TMPDIR:-/tmp}/census-parity.XXXXXX")" || { echo "UNREADABLE: mktemp failed"; exit 3; }
    trap 'rm -rf "$_cp_dir"' EXIT
    for _cp_p in agents/pre-commit-hook.sh scripts/ratify.sh scripts/declared-spine-paths.sh _index/engine-paths.tsv; do
        mkdir -p "$_cp_dir/$(dirname "$_cp_p")"
        git -C "$REPO_ROOT" show "${_cp_ref}:${_cp_p}" > "$_cp_dir/$_cp_p" 2>/dev/null && chmod +x "$_cp_dir/$_cp_p" || rm -f "$_cp_dir/$_cp_p"
    done
    _CP_BASE="$_cp_dir"
    export ENGINE_PATHS_FILE="${ENGINE_PATHS_FILE:-$_cp_dir/_index/engine-paths.tsv}"   # the handoff path is read in the SAME frame as the three censuses
else
    _CP_BASE="$REPO_ROOT"
fi
PRECOMMIT_FILE="${PRECOMMIT_FILE:-$_CP_BASE/agents/pre-commit-hook.sh}"
RATIFY_FILE="${RATIFY_FILE:-$_CP_BASE/scripts/ratify.sh}"
EMITTER_FILE="${EMITTER_FILE:-$_CP_BASE/scripts/declared-spine-paths.sh}"

# --- extraction: agents/pre-commit-hook.sh SPINE_PATHS (multi-line array, one bare-quoted path
# per line, comments on their OWN lines — verified at authoring time; a line that mixes a quoted
# path with a trailing comment would be mis-parsed, but no such line exists in the source shape).
extract_precommit_spine_paths() {
    local file="$1" in=0 found=0 line trimmed
    [[ -r "$file" ]] || return 1
    while IFS= read -r line || [[ -n "$line" ]]; do
        if [[ "$line" =~ ^SPINE_PATHS=\( ]]; then
            in=1; found=1
            continue
        fi
        if [[ $in -eq 1 ]]; then
            if [[ "$line" =~ ^\)[[:space:]]*$ ]]; then
                in=0
                continue
            fi
            trimmed="${line#"${line%%[![:space:]]*}"}"
            [[ -z "$trimmed" ]] && continue
            [[ "$trimmed" == \#* ]] && continue
            if [[ "$trimmed" =~ ^\"([^\"]*)\" ]]; then
                printf '%s\n' "${BASH_REMATCH[1]}"
            fi
        fi
    done < "$file"
    [[ $found -eq 1 ]] || return 1
    return 0
}

# --- extraction: scripts/ratify.sh SPINE_PREFIXES (single-line array).
extract_ratify_spine_prefixes() {
    local file="$1" line
    [[ -r "$file" ]] || return 1
    line="$(command grep -m1 '^SPINE_PREFIXES=(' "$file")" || return 1
    printf '%s\n' "$line" | command grep -o '"[^"]*"' | sed -e 's/^"//' -e 's/"$//'
}

write_list() {
    local content="$1" outfile="$2"
    if [[ -z "$content" ]]; then
        : > "$outfile"
    else
        printf '%s\n' "$content" | LC_ALL=C sort -u > "$outfile"
    fi
}

run_selfcheck() {
    local sc_dir dropped out rc
    sc_dir="$(mktemp -d "${TMPDIR:-/tmp}/census-parity-selfcheck.XXXXXX")"

    if [[ ! -r "$REPO_ROOT/agents/pre-commit-hook.sh" || ! -r "$REPO_ROOT/scripts/ratify.sh" || ! -x "$REPO_ROOT/scripts/declared-spine-paths.sh" ]]; then
        echo "SELFCHECK: FAIL (one or more real sources unreadable/not-executable under $REPO_ROOT)"
        rm -rf "$sc_dir"
        exit 1
    fi

    cp "$REPO_ROOT/agents/pre-commit-hook.sh" "$sc_dir/pre-commit-hook.sh"
    cp "$REPO_ROOT/scripts/ratify.sh" "$sc_dir/ratify.sh"
    cp "$REPO_ROOT/scripts/declared-spine-paths.sh" "$sc_dir/declared-spine-paths.sh"
    chmod +x "$sc_dir/declared-spine-paths.sh"

    dropped="sql/"
    command grep -Ev '^[[:space:]]*"'"${dropped}"'"[[:space:]]*$' "$sc_dir/pre-commit-hook.sh" > "$sc_dir/pre-commit-hook.sh.new" \
        && mv "$sc_dir/pre-commit-hook.sh.new" "$sc_dir/pre-commit-hook.sh"

    out="$(PRECOMMIT_FILE="$sc_dir/pre-commit-hook.sh" \
           RATIFY_FILE="$sc_dir/ratify.sh" \
           EMITTER_FILE="$sc_dir/declared-spine-paths.sh" \
           "$SELF" 2>&1)"
    rc=$?

    if [[ $rc -eq 1 ]] \
       && printf '%s\n' "$out" | command grep -Fq "VERDICT: FAIL" \
       && printf '%s\n' "$out" | command grep -Fq "PATH: ${dropped}" \
       && printf '%s\n' "$out" | command grep -F "PATH: ${dropped}" | command grep -Fq "pre-commit=N"; then
        echo "SELFCHECK: PASS (mutated copy with '${dropped}' dropped from pre-commit correctly FAILed, naming the dropped path)"
        rm -rf "$sc_dir"
        exit 0
    else
        echo "SELFCHECK: FAIL (mutated copy did not fail as expected; rc=$rc)"
        echo "--- mutated run output ---"
        printf '%s\n' "$out"
        rm -rf "$sc_dir"
        exit 1
    fi
}

if [[ "${1:-}" == "--selfcheck" ]]; then
    run_selfcheck
fi

# The consumers type the hub's handoff path as the variable $HANDOFF_PATH (they read it from the engine-path table's role:handoff
# row); the emitter resolves it. A consumer entry `$HANDOFF_PATH` is compared as that resolved path, never as the text.
H_PATH=""
if [[ -x "$EMITTER_FILE" ]]; then
    H_PATH="$("$EMITTER_FILE" --role handoff 2>/dev/null)" || { echo "UNREADABLE: the emitter could not resolve role:handoff ($EMITTER_FILE --role handoff)" >&2; exit 3; }
fi
p_list="$(extract_precommit_spine_paths "$PRECOMMIT_FILE")"; p_rc=$?
p_list="${p_list//\$HANDOFF_PATH/$H_PATH}"
r_list="$(extract_ratify_spine_prefixes "$RATIFY_FILE")"; r_rc=$?
r_list="${r_list//\$HANDOFF_PATH/$H_PATH}"
if [[ -x "$EMITTER_FILE" ]]; then
    e_list="$("$EMITTER_FILE" --canonical 2>/dev/null)"; e_rc=$?   # --canonical: the default output is the adopter-EXTRA contract (empty)
else
    e_list=""; e_rc=1
fi

if [[ $p_rc -ne 0 || $r_rc -ne 0 || $e_rc -ne 0 ]]; then
    echo "UNREADABLE: could not parse one or more sources (pre-commit=$PRECOMMIT_FILE rc=$p_rc, ratify=$RATIFY_FILE rc=$r_rc, emitter=$EMITTER_FILE rc=$e_rc)" >&2
    exit 3
fi

TMPDIR_PROBE="$(mktemp -d "${TMPDIR:-/tmp}/census-parity.XXXXXX")"
trap 'rm -rf "$TMPDIR_PROBE"' EXIT

write_list "$p_list" "$TMPDIR_PROBE/precommit.txt"
write_list "$r_list" "$TMPDIR_PROBE/ratify.txt"
write_list "$e_list" "$TMPDIR_PROBE/emitter.txt"
cat "$TMPDIR_PROBE/precommit.txt" "$TMPDIR_PROBE/ratify.txt" "$TMPDIR_PROBE/emitter.txt" | LC_ALL=C sort -u > "$TMPDIR_PROBE/union.txt"

total=0
matched=0
fail=0
while IFS= read -r path; do
    [[ -z "$path" ]] && continue
    total=$((total+1))
    in_p="N"; in_r="N"; in_e="N"
    command grep -Fxq -- "$path" "$TMPDIR_PROBE/precommit.txt" && in_p="Y"
    command grep -Fxq -- "$path" "$TMPDIR_PROBE/ratify.txt" && in_r="Y"
    command grep -Fxq -- "$path" "$TMPDIR_PROBE/emitter.txt" && in_e="Y"
    printf 'PATH: %-40s pre-commit=%s ratify=%s emitter=%s\n' "$path" "$in_p" "$in_r" "$in_e"
    if [[ "$in_p" == "Y" && "$in_r" == "Y" && "$in_e" == "Y" ]]; then
        matched=$((matched+1))
    else
        fail=1
    fi
done < "$TMPDIR_PROBE/union.txt"

echo "CENSUS-PARITY: ${matched}/${total}"
if [[ $fail -eq 0 && $total -gt 0 ]]; then
    echo "VERDICT: PASS"
    exit 0
else
    echo "VERDICT: FAIL"
    exit 1
fi
