#!/usr/bin/env bash
# probe_module_adopt_merge_guard.sh — module-adopt merge guard acceptance probe.
#
# ⛔ WHY THIS EXISTS AS AN EXECUTING PROBE AND NOT A TEXT SCAN:
# §2e is explicit — "a `bash -n` + a text scan certify SHAPE, not that the reject FIRES; only executing
# the raw merge and seeing the REJECT does." The hole being closed was itself a case of a header that
# ASSERTED a safety property the bytes did not have. So this probe performs real merges in a throwaway
# repo and reads the enforcer's real output.
#
# ⛔ ASSERT ON THE REJECT STRING, NEVER ON THE EXIT CODE ALONE. A replica can exit non-zero for reasons
# that have nothing to do with the property under test (detached HEAD being the classic: the hook takes
# the "not the trunk" path for the wrong reason and the pole scores green by accident). Every pole below
# matches the SPECIFIC message, so a right answer for a wrong reason still FAILS.
#
# POLES — the four PRESERVATION poles are as load-bearing as the bite (§2d): a guard that closes the
# dangerous door by also closing the legitimate ones is a regression wearing a fix's clothes.
#   P1 BITE      raw `git merge trunk` on a module branch            -> REJECT (the new behaviour)
#   P2 SANCTION  same merge carrying LANE_CURRENCY_SYNC=1            -> ALLOWED
#   P3 GATE      the real gate shape (`--no-ff --no-commit`)         -> hook never fires, ALLOWED
#   P4 FF        fast-forward (no merge commit)                      -> hook never fires, ALLOWED
#   P5 TRUNK     raw `git merge` INTO the trunk                      -> still REJECT (no regression)
#   P6 REAP      same, carrying REAP_AT_MERGE=1                      -> still ALLOWED (no regression)
#
# USAGE: probe_module_adopt_merge_guard.sh          -> run all poles; exit 0 iff every pole holds
set -u

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
HOOK="$REPO_ROOT/agents/pre-merge-commit-hook.sh"
# the fixture's trunk is the branch half of the ONE resolver of the tree under test (the one spine-ref resolver), never a
# literal; the resolver is copied into each fixture, because the hook resolves the trunk through it.
SPINE_REF_SRC="$REPO_ROOT/scripts/spine-ref.sh"
SR="$(bash "$SPINE_REF_SRC")" && [[ -n "$SR" ]] \
    || { echo "UNREADABLE: SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled in the tree under test (the one spine-ref resolver)"; exit 3; }
TRUNK="${SR#origin/}"
[[ -r "$HOOK" ]] || { echo "HALT: hook not readable at $HOOK (fail-closed)" >&2; exit 9; }

WORK="$(mktemp -d -t admtguard)" || { echo "HALT: mktemp failed" >&2; exit 9; }
# shellcheck disable=SC2064
trap "rm -rf '$WORK'" EXIT

PASS=0; FAIL=0
pole() {  # pole <name> <expect:REJECT|ALLOW> <expected-substring> <output-file> <rc>
    local name="$1" expect="$2" want="$3" out="$4" rc="$5" got
    if [[ "$expect" == "REJECT" ]]; then
        if [[ "$rc" -ne 0 ]] && grep -qF "$want" "$out"; then
            echo "  PASS  $name — rejected, and the message is the RIGHT one"; PASS=$((PASS+1)); return 0
        fi
        if [[ "$rc" -ne 0 ]]; then
            echo "  FAIL  $name — rejected but for the WRONG reason (message did not contain: $want)"
            sed 's/^/          /' "$out" | head -3
        else
            echo "  FAIL  $name — NOT rejected (the guard did not bite)"
        fi
        FAIL=$((FAIL+1)); return 1
    fi
    if [[ "$rc" -eq 0 ]]; then
        echo "  PASS  $name — allowed (legitimate workflow preserved)"; PASS=$((PASS+1)); return 0
    fi
    echo "  FAIL  $name — BLOCKED, but this workflow must keep working"
    sed 's/^/          /' "$out" | head -3
    FAIL=$((FAIL+1)); return 1
}

# ---- build a throwaway repo: a trunk + a module branch, with the hook installed ----
# ⛔ GENERIC LANE NAMES: the hook keys its message-severity branch on the stamp's
#    DECLARED spine_write CLASS, never a lane NAME, so this fixture stamps a `spine_write:` field and
#    passes it as a 3rd arg instead of hard-coding project lane names the old fixture
#    used only to pick a message. `foundation` is UNCHANGED and is NOT one of the renamed literals: the
#    hook's (unedited, out-of-scope-here) trunk-row lookup `awk -F'|' '$2 ~ /foundation/'` is keyed on
#    that literal specifically, and `probe_pin_zero_ref.sh` itself treats `foundation`/`architect` as
#    generic engine role names, not project-specific lane tokens (same standing as the P3 exclusion).
build_repo() {   # build_repo <dir> <lane> <spine_write>
    local d="$1" lane="$2" sw="${3:-DENY}"
    mkdir -p "$d" && cd "$d" || return 9
    git init -q -b "$TRUNK" .
    git config user.email p@p; git config user.name p
    mkdir -p _orchestration _boot .git/hooks scripts
    cp "$SPINE_REF_SRC" scripts/spine-ref.sh || return 9
    # The hook resolves the trunk from this manifest (spine-protected in the real repo) with
    #   awk -F'|' '$2 ~ /foundation/ { print $3 }'   ⇒ $2=lane, $3=BRANCH.
    # ⚠ MY FIRST FIXTURE HAD THE COLUMNS WRONG (`| foundation | foundation | main |`), so $3 resolved
    # to "foundation" instead of "main". TRUNK_BRANCH was therefore never equal to the current branch,
    # and the trunk poles P5/P6 took the MODULE path — the probe FAILED and told me exactly that.
    # Recorded rather than silently fixed: a probe whose fixture does not mirror the real artifact tests
    # a world that does not exist, and here it would have reported the trunk-side guard as broken when
    # it was untouched. Mirrors the real row shape verbatim:
    #   | foundation | main | <version> | ALLOW | <blob> | <utc> |
    printf '| lane | branch | version | spine_write | blob | provisioned |\n|---|---|---|---|---|---|\n| foundation | %s | probe-fixture-r1 | ALLOW | 0000000000000000000000000000000000000000 | 2026-01-01T00:00:00Z |\n' \
        "$TRUNK" > _orchestration/lane-provisioning.md
    printf 'lane: %s\nspine_write: %s\n' "$lane" "$sw" > _boot/BOOTSTRAP.md
    echo seed > f.txt
    git add -A && git commit -qm seed
    cp "$HOOK" .git/hooks/pre-merge-commit && chmod +x .git/hooks/pre-merge-commit
    cp "$SPINE_REF_SRC" .git/hooks/spine-ref.sh || return 9   # an installed hook reads the resolver beside it (0507 R2/R16; the installer places it)
    # trunk advances
    echo trunkwork >> f.txt && git commit -qam "trunk work"
    # a module branch that is BEHIND and also AHEAD (so an adopt is a real merge, never a ff)
    git branch -q module/probe HEAD~1
    git checkout -q module/probe
    echo lanework > lane.txt && git add -A && git commit -qm "lane work"
    return 0
}

echo "── module-adopt merge guard — executing poles (throwaway repo) ──"

# ---- P1 BITE: raw adopt on a module branch must REJECT ----
build_repo "$WORK/p1" "lane-a" "DENY" || exit 9
git merge --no-ff "$TRUNK" > "$WORK/p1.out" 2>&1; rc=$?
pole "P1 BITE     raw adopt on module branch" REJECT \
     "raw 'git merge' adopting the trunk into lane branch" "$WORK/p1.out" "$rc"

# ---- P1b class-aware severity: the apply-receipts-only lane gets the charter-destruction wording ----
build_repo "$WORK/p1b" "exec-lane" "apply-receipts-only" || exit 9
git merge --no-ff "$TRUNK" > "$WORK/p1b.out" 2>&1; rc=$?
pole "P1b SEVERITY apply-receipts-only names charter destruction" REJECT \
     "DESTROYS your charter" "$WORK/p1b.out" "$rc"

# ---- P2 SANCTION: the sentinel permits it ----
build_repo "$WORK/p2" "lane-a" "DENY" || exit 9
LANE_CURRENCY_SYNC=1 git merge --no-ff "$TRUNK" > "$WORK/p2.out" 2>&1; rc=$?
pole "P2 SANCTION LANE_CURRENCY_SYNC=1" ALLOW "" "$WORK/p2.out" "$rc"

# ---- P3 GATE: the real gate shape never trips the hook ----
build_repo "$WORK/p3" "lane-a" "DENY" || exit 9
git merge --no-ff --no-commit "$TRUNK" > "$WORK/p3.out" 2>&1; rc=$?
pole "P3 GATE     --no-ff --no-commit" ALLOW "" "$WORK/p3.out" "$rc"

# ---- P4 FF: a fast-forward creates no merge commit, so the hook never fires ----
build_repo "$WORK/p4" "lane-a" "DENY" || exit 9
git checkout -q -B module/ff "$TRUNK~1"          # strictly behind, no own commits
git merge "$TRUNK" > "$WORK/p4.out" 2>&1; rc=$?
pole "P4 FF       fast-forward adopt" ALLOW "" "$WORK/p4.out" "$rc"

# ---- P5 TRUNK: the pre-existing trunk-side reject must be untouched ----
build_repo "$WORK/p5" "foundation" "ALLOW" || exit 9
git checkout -q "$TRUNK"
git merge --no-ff module/probe > "$WORK/p5.out" 2>&1; rc=$?
pole "P5 TRUNK    raw merge INTO trunk" REJECT \
     "raw 'git merge' into the integration trunk" "$WORK/p5.out" "$rc"

# ---- P6 REAP: the sanctioned trunk-side path must be untouched ----
build_repo "$WORK/p6" "foundation" "ALLOW" || exit 9
git checkout -q "$TRUNK"
REAP_AT_MERGE=1 git merge --no-ff module/probe > "$WORK/p6.out" 2>&1; rc=$?
pole "P6 REAP     REAP_AT_MERGE=1 into trunk" ALLOW "" "$WORK/p6.out" "$rc"

echo "── poles: PASS=$PASS FAIL=$FAIL ──"
[[ "$FAIL" -eq 0 ]] || { echo "PROBE FAIL"; exit 1; }
echo "PROBE PASS — the guard bites on the raw adopt AND every legitimate path still works."
