#!/usr/bin/env bash
# probe_govcheck_relay_ref.sh — GOVCHECK-GATE ref resolution for a lane OUTBOX path.
# An `answered@_orchestration/relay-outbox/<lane>/<file>` ref can never exist at spine HEAD (outboxes are
# integration-excluded). It resolves ONLY when a ruling names that exact path (a sealed ruling's `Source` line).
# POLES (replica = `git clone --shared`, hooks off, deleted on exit):
#   S  staged ruling cites an outbox path that a staged SEAL names      ⇒ rc=0 (resolves)
#   U  staged ruling cites an outbox path that NO ruling names           ⇒ rc=1 + "does not resolve" (red pole)
#   P  pre-fix control scanner on pole S's input                         ⇒ rc=1 (defect reproduces — control)
#   W  staged ruling cites an outbox path it ALSO carries on its OWN line (self-cite), no seal ⇒ rc=1 (auditor 47572b87 F1)
#   X  pre-self-cite-fix control scanner on pole W's input              ⇒ rc=0 (fail-open reproduces — control)
# CONTROL PROVENANCE (DISC-PROBE-INPUT-PROVENANCE; 0507 R1(iii)): the two control scanners are SYNTHETIC
# commits built inside this probe's own replica, children of the resolver's trunk, never pinned origin commits (an
# adopter holds no origin sha, C-PIN §3). Each is the scanner under test with ONE named mechanism removed:
#   P-control: the `_orchestration/relay-outbox/*)` arm of gc_ref_resolves() is deleted (the pre-SET-0053 shape)
#   X-control: the GC_CITER self-exclusion is deleted, so `_gx` is always `_rulings` (the pre-auditor-F1 shape)
# A mutation that does not apply exactly once is UNREADABLE (exit 3), never a verdict.
# USAGE: probe_govcheck_relay_ref.sh [scanner-under-test]   EXIT 0 all OK · 1 a pole failed · 3 UNREADABLE
set -u
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SCAN_SRC="${1:-$REPO/scripts/creed-scan.sh}"
[ -r "$SCAN_SRC" ] || { echo "RELAY-REF-PROBE: UNREADABLE -- scanner under test missing at $SCAN_SRC"; exit 3; }
W="$(mktemp -d "${TMPDIR:-/tmp}/relayrefprobe.XXXXXX")" || exit 3
trap 'rm -rf "$W"' EXIT
D="$W/r"
# the replica's trunk is the ONE resolver's output of the tree under test (the one spine-ref resolver), never a literal
SR="$(bash "$REPO/scripts/spine-ref.sh")" && [ -n "$SR" ] || { echo "RELAY-REF-PROBE: UNREADABLE -- SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled (the one spine-ref resolver)"; exit 3; }
git clone --shared -q "$REPO" "$D" && git -C "$D" checkout -q -B "${SR#origin/}" "$SR" \
  && git -C "$D" config core.hooksPath /dev/null || { echo "RELAY-REF-PROBE: UNREADABLE -- replica"; exit 3; }
# every scanner copy runs from $W, so the tree under test's resolver sits beside it there (0507 R2: found beside the running script)
cp "$SCAN_SRC" "$W/cured.sh" && cp "$REPO/scripts/spine-ref.sh" "$W/spine-ref.sh" || { echo "RELAY-REF-PROBE: UNREADABLE -- staging the scanner copy"; exit 3; }
# synthetic_control <name> <perl-substitution> -> a commit on the replica's trunk carrying the mutated scanner; its bytes to $W/<name>.sh
synthetic_control() {
    local n="$1" sub="$2" c blob tree
    SRR_SUB="$sub" perl -0e 'local $/; my $s=<STDIN>; my $n = eval "\$s =~ $ENV{SRR_SUB}"; print STDERR "$n\n"; print $s' < "$W/cured.sh" 2>"$W/$n.count" > "$W/$n.mut"
    [ "$(cat "$W/$n.count")" = 1 ] || { echo "RELAY-REF-PROBE: UNREADABLE -- control $n mutation applied $(cat "$W/$n.count") time(s), expected 1"; exit 3; }
    blob="$(git -C "$D" hash-object -w "$W/$n.mut")" \
      && GIT_INDEX_FILE="$W/$n.idx" git -C "$D" read-tree HEAD \
      && GIT_INDEX_FILE="$W/$n.idx" git -C "$D" update-index --cacheinfo "100755,$blob,scripts/creed-scan.sh" \
      && tree="$(GIT_INDEX_FILE="$W/$n.idx" git -C "$D" write-tree)" \
      && c="$(GIT_AUTHOR_NAME=probe GIT_AUTHOR_EMAIL=probe@probe.invalid GIT_COMMITTER_NAME=probe GIT_COMMITTER_EMAIL=probe@probe.invalid \
              git -C "$D" commit-tree "$tree" -p HEAD -m "synthetic control: $n")" \
      && git -C "$D" show "$c:scripts/creed-scan.sh" > "$W/$n.sh" || { echo "RELAY-REF-PROBE: UNREADABLE -- synthetic control $n"; exit 3; }
    echo "CONTROL: $n = synthetic commit ${c:0:12} on $(git -C "$D" rev-parse --abbrev-ref HEAD) (parent $(git -C "$D" rev-parse --short HEAD))"
}
synthetic_control prefix 's/^ {10}_orchestration\/relay-outbox\/\*\)\n.*?(?=^ {10}ARCH-\[0-9\]\*)//msg'
synthetic_control preself 's/local _gx="_rulings"; \[ -n "\$\{GC_CITER:-\}" \] && _gx=":\(exclude\)\$\{GC_CITER\}"/local _gx="_rulings"/g'
OK=0; TOTAL=0
pole() { TOTAL=$((TOTAL+1)); if [ "$2" -eq 0 ]; then OK=$((OK+1)); echo "POLE $1: OK — $3"; else echo "POLE $1: FAIL — $3"; fi; }
SEALED="_orchestration/relay-outbox/architect/2099-01-01-01-RULED-ARCH-9998-probe-sealed.md"
UNSEALED="_orchestration/relay-outbox/architect/2099-01-01-02-RULED-ARCH-9999-probe-never-sealed.md"
stage() {   # <cited-outbox-path> <with-seal 0|1>
    git -C "$D" reset -q --hard; git -C "$D" clean -qfd
    # an adopter tree may carry no _rulings/ of its own: create it, or nothing is staged and every pole reads a vacuous rc 0
    mkdir -p "$D/_rulings" || { echo "RELAY-REF-PROBE: UNREADABLE -- cannot create _rulings/ in the replica"; exit 3; }
    if [ "$2" -eq 1 ]; then
        printf '# _rulings/9998 — ARCH-9998 · RULED — probe seal\n\n**Source (reaped cross-branch):** →\n`%s`\n\nGOVERNANCE-CHECK: probe-seal answered@_rulings/9998\n' "$SEALED" > "$D/_rulings/9998-ARCH-9998-RULED-probe-seal.md"
        git -C "$D" add "_rulings/9998-ARCH-9998-RULED-probe-seal.md" || { echo "RELAY-REF-PROBE: UNREADABLE -- staging the seal"; exit 3; }
    fi
    printf '# _rulings/9997 — ARCH-9997 · RULED — probe citer\n\nGOVERNANCE-CHECK: probe-topic answered@`%s` (sibling)\n' "$1" > "$D/_rulings/9997-ARCH-9997-RULED-probe-citer.md"
    git -C "$D" add "_rulings/9997-ARCH-9997-RULED-probe-citer.md" || { echo "RELAY-REF-PROBE: UNREADABLE -- staging the citer"; exit 3; }
    printf 'probe: relay-ref pole\n' > "$D/.m"
}
run() { ( cd "$D" && lane=probe bash "$1" --staged --msg "$D/.m" 2>&1 ); }

stage "$SEALED" 1; OUT="$(run "$W/cured.sh")"; RC=$?
[ "$RC" -eq 0 ] && pole S 0 "outbox ref named by a staged seal resolves (rc=0)." \
                || pole S 1 "expected rc=0; got rc=$RC. $(printf '%s' "$OUT" | grep -E 'GOVCHECK|CREED-GATE' | tr '\n' ' ' | cut -c1-240)"
OUT="$(run "$W/prefix.sh")"; RC=$?
{ [ "$RC" -eq 1 ] && printf '%s' "$OUT" | grep -q 'does not resolve'; } && pole P 0 "pre-fix control scanner rejects the same input (defect reproduces)." \
                || pole P 1 "expected pre-fix rc=1 + 'does not resolve'; got rc=$RC."
stage "$UNSEALED" 0; OUT="$(run "$W/cured.sh")"; RC=$?
{ [ "$RC" -eq 1 ] && printf '%s' "$OUT" | grep -q 'does not resolve'; } && pole U 0 "outbox ref that NO ruling names still REJECTED (rc=1)." \
                || pole U 1 "expected rc=1 + 'does not resolve'; got rc=$RC."
stage_self() {   # a citer whose own body carries the cited path as a whole line — the only "seal" is itself
    git -C "$D" reset -q --hard; git -C "$D" clean -qfd
    mkdir -p "$D/_rulings" || { echo "RELAY-REF-PROBE: UNREADABLE -- cannot create _rulings/ in the replica"; exit 3; }
    printf '# _rulings/9997 — ARCH-9997 · RULED — probe self-citer\n\n`%s`\n\nGOVERNANCE-CHECK: probe-topic answered@`%s` (self)\n' "$UNSEALED" "$UNSEALED" > "$D/_rulings/9997-ARCH-9997-RULED-probe-citer.md"
    git -C "$D" add "_rulings/9997-ARCH-9997-RULED-probe-citer.md" || { echo "RELAY-REF-PROBE: UNREADABLE -- staging the citer"; exit 3; }
    printf 'probe: relay-ref self-cite pole\n' > "$D/.m"
}
stage_self; OUT="$(run "$W/cured.sh")"; RC=$?
{ [ "$RC" -eq 1 ] && printf '%s' "$OUT" | grep -q 'does not resolve'; } && pole W 0 "own-line self-cite does NOT resolve itself (rc=1)." \
                || pole W 1 "expected rc=1 + 'does not resolve'; got rc=$RC."
OUT="$(run "$W/preself.sh")"; RC=$?
{ [ "$RC" -eq 0 ] && ! printf '%s' "$OUT" | grep -q 'does not resolve'; } && pole X 0 "pre-self-cite control scanner ACCEPTS the self-cite (fail-open reproduces)." \
                || pole X 1 "expected pre-fix rc=0 with no 'does not resolve'; got rc=$RC."
echo "RELAY-REF-PROBE: ${OK}/${TOTAL} poles OK"
[ "$OK" -eq "$TOTAL" ] && [ "$TOTAL" -eq 5 ]
