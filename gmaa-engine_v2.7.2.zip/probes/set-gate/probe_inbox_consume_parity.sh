#!/usr/bin/env bash
# probe_inbox_consume_parity.sh — hub `consume` interface parity.
#
# ⛔ THE DEFECT THIS LOCKS DOWN. `scripts/inbox.sh` delegates the WHOLE verb to `scripts/inboxf.sh`, and
# that delegation promised "the shared front-door behaviour is identical". It was not: the hub required
# `consume <src> <name>` and rejected the bare `<name>` form with rc=2 — the exact command
# `.claude/agents/orc.md:147` prescribes inside the block it calls "the FIRST action of EVERY turn".
# The seen-marker advances ONLY on consume, so a seat following its own persona could not advance it.
#
# ⛔ WHY AMBIGUITY MUST FAIL CLOSED, WHICH IS THE WHOLE POINT OF POLE A2. A bare name is ambiguous at the
# hub by construction — two lanes may carry the same filename. Consuming the WRONG lane's copy marks
# genuinely unread work as read, silently. That is precisely the harm the shown-snapshot bound was
# ratified to prevent (ISSUE-INBOX-CONSUME-ALL-SWALLOWS-UNREAD-2026-07-22). Resolving "helpfully" by
# taking the first match would reintroduce it wearing a convenience's clothes.
#
# ⛔ THIS PROBE MUTATES REAL SEEN-STATE, SO IT BACKS UP AND RESTORES. `.claude/inboxf-seen` is the live
# marker for this worktree; a probe that corrupted it would silently resurrect or swallow real relays.
# Backup happens BEFORE any write and restore runs on EXIT (including failure), never only on success.
#
# POLES:
#   A1 bare <name>, UNIQUE in the shown-snapshot   -> rc 0, marker gains exactly that id
#   A2 bare <name>, AMBIGUOUS across sources       -> rc 2, marker UNCHANGED, candidates listed
#   A3 bare <name>, ABSENT from the snapshot       -> rc 2, marker UNCHANGED
#   A4 explicit <src> <name>                       -> rc 0 (the pre-existing form must not regress)
#   A5 --all                                       -> rc 0 (the ratified shown-snapshot-bounded path)
set -u

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO_ROOT" || { echo "HALT: cannot cd to repo root" >&2; exit 9; }
HUB="scripts/inboxf.sh"
SEEN=".claude/inboxf-seen"
SHOWN=".claude/inboxf-shown"
# A later change made `--premise` MANDATORY on consume; this probe predated it and every
# valid consume returned rc 2 (4 FAIL at HEAD b7e49ff2). The poles test the
# consume INTERFACE, so they pass the premise the interface now requires.
PREM="--premise holds@HEAD"
PREMF=".claude/inboxf-seen.premise"   # the premise sidecar consume now writes — backed up + restored too
[[ -x "$HUB" ]] || { echo "HALT: $HUB not executable (fail-closed)" >&2; exit 9; }

BK="$(mktemp -d -t inbparity)" || { echo "HALT: mktemp failed" >&2; exit 9; }
cp "$SEEN"  "$BK/seen.bak"  2>/dev/null || : > "$BK/seen.bak"
cp "$SHOWN" "$BK/shown.bak" 2>/dev/null || : > "$BK/shown.bak"
cp "$PREMF" "$BK/premf.bak" 2>/dev/null || : > "$BK/premf.bak"
restore() { cp "$BK/seen.bak" "$SEEN" 2>/dev/null; cp "$BK/shown.bak" "$SHOWN" 2>/dev/null; cp "$BK/premf.bak" "$PREMF" 2>/dev/null; rm -rf "$BK"; }
trap restore EXIT

PASS=0; FAIL=0
chk() {  # chk <name> <want-rc> <got-rc> <want-delta> <got-delta>
    if [[ "$2" == "$3" && "$4" == "$5" ]]; then
        echo "  PASS  $1 (rc=$3, marker delta=$5)"; PASS=$((PASS+1))
    else
        echo "  FAIL  $1 — rc want=$2 got=$3 ; marker-delta want=$4 got=$5"; FAIL=$((FAIL+1))
    fi
}
lines() { if [ -f "$SEEN" ]; then grep -c . "$SEEN"; else echo 0; fi; }  # NOTE: grep -c prints 0 itself; only a missing FILE needs a guard.

# Synthetic snapshot: one UNIQUE name and one name DUPLICATED across two sources. Generic lane names
# (lane-a/lane-b); the consume interface under test does not validate `<src>` against
# any declared-lane manifest (scripts/inboxf.sh consume <src> <name> is a free-form marker write), so
# these tokens carry no dependency on a real project lane.
printf 'architect\tPARITY-UNIQ.md\nlane-a\tPARITY-DUP.md\nlane-b\tPARITY-DUP.md\n' > "$SHOWN"

echo "── inbox consume parity — executing poles (live marker backed up + restored) ──"

b=$(lines); "$HUB" consume PARITY-UNIQ.md $PREM >/dev/null 2>&1; rc=$?; a=$(lines)
chk "A1 bare UNIQUE   -> consumed"      0 "$rc" 1 "$((a-b))"

b=$(lines); "$HUB" consume PARITY-DUP.md $PREM  >/dev/null 2>&1; rc=$?; a=$(lines)
chk "A2 bare AMBIGUOUS-> HALT, no write" 2 "$rc" 0 "$((a-b))"

b=$(lines); "$HUB" consume PARITY-ABSENT.md $PREM >/dev/null 2>&1; rc=$?; a=$(lines)
chk "A3 bare ABSENT   -> HALT, no write" 2 "$rc" 0 "$((a-b))"

b=$(lines); "$HUB" consume lane-b PARITY-EXPL.md $PREM >/dev/null 2>&1; rc=$?; a=$(lines)
chk "A4 explicit src  -> consumed"      0 "$rc" 1 "$((a-b))"

# A2 must also PRINT the disambiguating commands — a HALT that does not say how to proceed is a wall.
if "$HUB" consume PARITY-DUP.md $PREM 2>&1 | grep -q "consume lane-a PARITY-DUP.md"; then
    echo "  PASS  A2b HALT prints the disambiguating commands"; PASS=$((PASS+1))
else
    echo "  FAIL  A2b HALT does not tell the caller how to proceed"; FAIL=$((FAIL+1))
fi

"$HUB" consume --all $PREM >/dev/null 2>&1; rc=$?
if [[ "$rc" -eq 0 ]]; then echo "  PASS  A5 --all still works (rc=0)"; PASS=$((PASS+1));
else echo "  FAIL  A5 --all regressed (rc=$rc)"; FAIL=$((FAIL+1)); fi

echo "── poles: PASS=$PASS FAIL=$FAIL ──"
[[ "$FAIL" -eq 0 ]] || { echo "PROBE FAIL"; exit 1; }
echo "PROBE PASS — bare-name parity restored, and ambiguity/absence fail CLOSED without touching the marker."
