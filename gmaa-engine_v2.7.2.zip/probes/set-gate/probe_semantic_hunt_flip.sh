#!/usr/bin/env bash
# probes/set-gate/probe_semantic_hunt_flip.sh
# ── Standing probe (REQ-HUNT · C-SET-AUTHORIZATION §2.3) — the joint-edge 3-layer gate, FLIP-proven ──
#
# id:         set-gate-semantic-hunt
# claims:     (Layer C) the required ## SEMANTIC HUNT slot is UNSKIPPABLE — a MERGE decision REFUSES on a
#             missing/unfilled block, on verdict UNABLE, and on CLEAR asserted with 'candidates: ZERO' + no
#             method; it PROCEEDS on a CLEAR verdict carrying a method + candidates; EDGE-NAMED joins the
#             names to JOINT-EDGES as UNRESOLVED INTEGRATOR-JUDGMENT edges (blocking MERGE).
#             (Layer B) `assemble` flags a SoR SHARED-RECORD when two members cite the same sproc/probe id
#             via DIFFERENT files, and does NOT when they cite different records or share the same path
#             (that is Layer A OVERLAPPING PATH).
#             (substrates §2.3 cross-check) a member writing a substrate outside the declared
#             footprint.substrates is FLAGGED (UNDECLARED-SUBSTRATE), and is NOT when declared or when the
#             registry omits substrates.
#             (REQ-HUNT APPEND) a hunt on a FILLED slot APPENDS a dated
#             `### RE-HUNT #N` block (N increments; the original and every prior block are never edited —
#             annotate-not-overwrite) instead of silently doing nothing; a MERGE decision reads the LATEST
#             block, never the first, and PRINTS which block it read; a re-hunt verdict UNABLE over a
#             packet that already carries a MERGE decision is REFUSED (downgrade-after-MERGE, §2.2) while a
#             non-downgrade re-hunt (e.g. CLEAR) after the same MERGE is NOT refused; every hunt success
#             path leaves the packet byte-different (never "recorded" over 0 changed bytes, §2.3); CLEAR and
#             EDGE-NAMED exit 0, UNABLE exits non-zero.
# pass_means: each NEGATIVE (FLIP) case fails-closed / is-absent AND each POSITIVE control holds. A probe
#             that runs only the happy path proves the harness, not the gate (the 2+2 anti-pattern).
# flip:       DISCRIMINATION (mandatory) — every claim is paired with its negative.
# provenance: exercises the LIVE working-tree scripts/pending-set.sh + scripts/ratify.sh in an ISOLATED git
#             repo (mktemp, outside the spine) with a foundation resolver stub — DISC-PROBE-INPUT-PROVENANCE:
#             proves the worktree bytes, not a fixture of them. No LLM in the detector (AC6).
#
# Exit 0 = all assertions PASS (incl. the FLIP fails/absences). Non-zero = a claim did not hold (fail-closed).
set -u

REPO="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "probe: not in a git worktree"; exit 2; }
PS="$REPO/scripts/pending-set.sh"; RT="$REPO/scripts/ratify.sh"
[[ -f "$PS" && -f "$RT" ]] || { echo "probe: scripts missing"; exit 2; }

T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
PASS=0; FAIL=0
ok(){ echo "  PASS: $*"; PASS=$((PASS+1)); }
no(){ echo "  FAIL: $*"; FAIL=$((FAIL+1)); }

# --- isolated repo scaffold (git-init so repo_root resolves to T, outside the spine) ---
git init -q "$T"
# fixture repo: no registry row, no key. Enroll the stubbed foundation lane once (apex: the pen path ties the OS login).
SEAT_KEYS_HOME="$(mktemp -d)"; export SEAT_KEYS_HOME; trap 'rm -rf "$T" "$SEAT_KEYS_HOME"' EXIT
bash "$REPO/scripts/seat-keys.sh" fixture-enroll "$T" foundation --apex > "$SEAT_KEYS_HOME/enroll.out" 2>&1 || { echo "probe: fixture-enroll failed: $(tail -1 "$SEAT_KEYS_HOME/enroll.out")"; exit 2; }
mkdir -p "$T/scripts" "$T/_ratification" \
         "$T/_orchestration/relay-outbox/foundation" \
         "$T/_orchestration/relay-outbox/lane-a" \
         "$T/_orchestration/relay-outbox/lane-b"
cp "$PS" "$RT" "$REPO/scripts/seat-keys.sh" "$T/scripts/"   # ratify.sh calls $root/scripts/seat-keys.sh login-line / login-tie
mkdir -p "$T/_index"; cp "$REPO/scripts/declared-spine-paths.sh" "$T/scripts/"; cp "$REPO/_index/engine-paths.tsv" "$T/_index/"   # 0429: ratify.sh resolves role:handoff from the engine-paths table at load and fails closed without it

# DISC-PROBE-INPUT-PROVENANCE: the fixture carries its OWN copy of the shipped substrate table bytes (engine rows only,
# as the generator emits them) - never the live _index/substrates.tsv. ratify.sh reads this one from the fixture root.
printf '%s\n' '# substrates.tsv (probe fixture: the shipped engine rows)' 'alias	canonical	scope	note' \
    'git	git-spine	engine	-' 'spine	git-spine	engine	-' 'git-spine	git-spine	engine	-' \
    'db	sql	engine	-' 'sql	sql	engine	-' 'fn	functions	engine	-' 'func	functions	engine	-' 'functions	functions	engine	-' \
    'cms	cms	engine	-' 'automation	automation	engine	-' 'flow	automation	engine	-' \
    'low-code	low-code	engine	-' 'lowcode	low-code	engine	-' > "$T/_index/substrates.tsv"
cat > "$T/scripts/resolve-lane.sh" <<'EOF'
#!/usr/bin/env bash
echo 'lane=foundation role=integrator version=probe spine_write=ALLOW blob=probe'
EOF
chmod +x "$T/scripts/resolve-lane.sh" "$T/scripts/pending-set.sh" "$T/scripts/ratify.sh"

fresh_fixture(){
    rm -f "$T"/_ratification/SET-*.md
    rm -f "$T"/_orchestration/relay-outbox/*/SET-MEMBER-*.md
    ROWN=0
    cat > "$T/PENDING-SET.md" <<'EOF'
# PENDING-SET.md (probe fixture)

## THE SET

| # | member id | lane | branch@sha-range | surfaces touched | status |
|---|---|---|---|---|---|

## SET-IDENTITY

| requirement_id | set_id | footprint.lanes | footprint.substrates | exclusive | minted-at |
|---|---|---|---|---|---|

## APPLY LOG
EOF
}

# seed_member <id> <lane> <reqid> <setid> <surfaces> [<declared-effects>] — write the SET-MEMBER manifest
# + a pending ledger row directly (controls the member's LANE + declared-effects, which cmd_member wouldn't).
seed_member(){
    local id="$1" lane="$2" reqid="$3" setid="$4" surf="$5" eff="${6:-git-surfaces-only}"
    local mf="$T/_orchestration/relay-outbox/$lane/SET-MEMBER-$id.md"
    {
        echo "# SET-MEMBER-$id"
        echo "- member id: $id"
        echo "- lane: $lane"
        echo "- requirement id: $reqid"
        echo "- set id: $setid"
        echo "- branch@sha: $lane@probe"
        echo "- surfaces touched: $surf"
        echo "- declared effects (multi-substrate manifest; §3/§4a): $eff"
        echo "- self-declared dependencies: none-declared"
    } > "$mf"
    ROWN=$((ROWN+1))
    awk -v row="| $ROWN | $id | $lane | $lane@probe | $surf | pending |" '
        /^## THE SET[[:space:]]*$/ {inset=1}
        {print}
        inset && /^\|[-]+\|/ && !done {print row; done=1}
    ' "$T/PENDING-SET.md" > "$T/PENDING-SET.md.tmp" && mv "$T/PENDING-SET.md.tmp" "$T/PENDING-SET.md"
}

# setup_clean_set — fresh fixture with TWO disjoint lane-a members covering footprint [lane-a], assembled
# into SET-0001 with 0 mechanical edges, assessment filled, conformance PASS both members. Ready-to-ratify
# EXCEPT the SEMANTIC HUNT slot (still empty) — the isolation the Layer-C tests need.
setup_clean_set(){
    fresh_fixture
    scripts/pending-set.sh mint REQ-HUNTPROBE --footprint-lanes 'lane-a' >/dev/null 2>&1
    seed_member ha lane-a REQ-HUNTPROBE SET-0001 'src/a.txt'
    seed_member hb lane-a REQ-HUNTPROBE SET-0001 'src/b.txt'
    scripts/ratify.sh assemble --cures none SET-0001 >/dev/null 2>&1
    scripts/ratify.sh assess SET-0001 --text 'probe assessment: disjoint members, no joint incoherence observed.' >/dev/null 2>&1
    scripts/ratify.sh conformance SET-0001 ha --verdict PASS --method judgment --evidence 'probe' >/dev/null 2>&1
    scripts/ratify.sh conformance SET-0001 hb --verdict PASS --method judgment --evidence 'probe' >/dev/null 2>&1
}

cd "$T" || { echo "probe: cd failed"; exit 2; }

echo "── A. assemble writes the required SEMANTIC HUNT slot + coherence banner ──"
setup_clean_set
P="$T/_ratification/SET-0001.md"
grep -q '^## SEMANTIC HUNT' "$P" && ok "packet carries a ## SEMANTIC HUNT section" || no "no ## SEMANTIC HUNT section"
grep -q '<!-- SEMANTIC-HUNT-EMPTY -->' "$P" && ok "SEMANTIC HUNT slot starts UNFILLED (marker present)" || no "no SEMANTIC-HUNT-EMPTY marker"
grep -q 'MERGE is legal only after the SEMANTIC HUNT verdict is CLEAR' "$P" && ok "packet header carries the COHERENCE LAW banner" || no "no coherence-law banner"

echo "── B. Layer C FLIP — MERGE refuses on empty / UNABLE / CLEAR-ZERO-no-method; proceeds on CLEAR+method ──"
# NEGATIVE 1: empty slot → ratify RATIFIED REFUSES.
setup_clean_set
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi 'SEMANTIC HUNT slot is EMPTY' <<<"$out"; then ok "FLIP: empty SEMANTIC HUNT → MERGE REFUSED (rc=$rc)"; else no "empty-hunt did NOT refuse (rc=$rc): ${out##*$'\n'}"; fi
# NEGATIVE 2: verdict UNABLE → REFUSES.
setup_clean_set
scripts/ratify.sh hunt SET-0001 --residual 'could not open the make SoR index' --verdict UNABLE >/dev/null 2>&1
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi "verdict is 'UNABLE'" <<<"$out"; then ok "FLIP: verdict UNABLE → MERGE REFUSED (rc=$rc)"; else no "UNABLE did NOT refuse (rc=$rc): ${out##*$'\n'}"; fi
# NEGATIVE 3: CLEAR with candidates ZERO and no method → REFUSES (assertion, not a hunt).
setup_clean_set
scripts/ratify.sh hunt SET-0001 --method 'x' --candidates 'ZERO' --residual 'none' --verdict CLEAR >/dev/null 2>&1
# strip the method (cmd_hunt required one; the ratify-side rule must still catch ZERO+no-method) — target ONLY the hunt block's method line
awk 'BEGIN{s=0} /^## SEMANTIC HUNT/{s=1} /^## / && $0 !~ /SEMANTIC HUNT/{s=0} s && /^- method:/{print "- method: —"; next} {print}' "$P" > "$P.tmp" && mv "$P.tmp" "$P"
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi 'CLEAR with' <<<"$out"; then ok "FLIP: CLEAR + candidates ZERO + no method → MERGE REFUSED (rc=$rc)"; else no "CLEAR-ZERO-no-method did NOT refuse (rc=$rc): ${out##*$'\n'}"; fi
# POSITIVE control: CLEAR with method + candidates → ratify PROCEEDS to RATIFIED.
setup_clean_set
scripts/ratify.sh hunt SET-0001 --method 'grep sp_/probe_ across member surfaces + opened §5 SoR git-spine index' --candidates 'sp_x,sp_y' --residual 'low; disjoint files, distinct records' --verdict CLEAR >/dev/null 2>&1
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -eq 0 ]] && grep -q '^- decision: RATIFIED' "$P"; then ok "positive control: CLEAR+method → MERGE PROCEEDS (rc=0, decision RATIFIED stamped)"; else no "positive control failed (rc=$rc): ${out##*$'\n'}"; fi
# EDGE-NAMED: a named semantic edge joins JOINT-EDGES as UNRESOLVED → MERGE refused by the unresolved-edge gate.
setup_clean_set
scripts/ratify.sh hunt SET-0001 --residual 'two members redefine promote semantics in prose' --verdict EDGE-NAMED --edges 'promote-semantics-drift' >/dev/null 2>&1
grep -q 'INTEGRATOR-JUDGMENT: promote-semantics-drift' "$P" && ok "EDGE-NAMED appends an INTEGRATOR-JUDGMENT edge to JOINT-EDGES" || no "EDGE-NAMED did not append a named edge"
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi 'unresolved joint edge' <<<"$out"; then ok "EDGE-NAMED → MERGE REFUSED until the named edge resolves (rc=$rc)"; else no "EDGE-NAMED did NOT block MERGE (rc=$rc): ${out##*$'\n'}"; fi

echo "── C. Layer B FLIP — SoR SHARED-RECORD (same record, different files) ──"
# POSITIVE: two lane-a members cite sp_fx_promote via DIFFERENT files → SHARED-RECORD edge.
fresh_fixture
scripts/pending-set.sh mint REQ-HUNTPROBE --footprint-lanes 'lane-a' >/dev/null 2>&1
seed_member ba lane-a REQ-HUNTPROBE SET-0001 'fx/procs/sp_fx_promote.sql'
seed_member bb lane-a REQ-HUNTPROBE SET-0001 'fx/grants/grant_sp_fx_promote.sql'
scripts/ratify.sh assemble --cures none SET-0001 >/dev/null 2>&1
# NOTE: grep the EDGE line (^- UNRESOLVED · …), NOT the bare token — the packet's DETECTION-HONESTY banner
# names 'SHARED-RECORD'/'UNDECLARED-SUBSTRATE' in prose; a loose grep would match the banner, not the finding.
grep -qE '^- UNRESOLVED · .*SHARED-RECORD \[sproc:sp_fx_promote\]' "$P" && ok "SHARED-RECORD flagged: same sproc, different files (§2.3 Layer B)" || no "SHARED-RECORD not flagged for a cross-file sproc"
# FLIP: different sprocs → NO SHARED-RECORD.
fresh_fixture
scripts/pending-set.sh mint REQ-HUNTPROBE --footprint-lanes 'lane-a' >/dev/null 2>&1
seed_member na lane-a REQ-HUNTPROBE SET-0001 'fx/procs/sp_fx_promote.sql'
seed_member nb lane-a REQ-HUNTPROBE SET-0001 'fx/procs/sp_demote.sql'
scripts/ratify.sh assemble --cures none SET-0001 >/dev/null 2>&1
grep -qE '^- UNRESOLVED · .*SHARED-RECORD' "$P" && no "FLIP: distinct sprocs wrongly flagged SHARED-RECORD" || ok "FLIP: distinct sprocs → NO SHARED-RECORD (discrimination holds)"
# SUPPRESSION: same PATH → Layer A OVERLAPPING PATH, NOT Layer B SHARED-RECORD.
fresh_fixture
scripts/pending-set.sh mint REQ-HUNTPROBE --footprint-lanes 'lane-a' >/dev/null 2>&1
seed_member pa lane-a REQ-HUNTPROBE SET-0001 'fx/procs/sp_fx_promote.sql'
seed_member pb lane-a REQ-HUNTPROBE SET-0001 'fx/procs/sp_fx_promote.sql'
scripts/ratify.sh assemble --cures none SET-0001 >/dev/null 2>&1
if grep -qE '^- UNRESOLVED · .*OVERLAPPING PATH' "$P" && ! grep -qE '^- UNRESOLVED · .*SHARED-RECORD' "$P"; then ok "same path → Layer A OVERLAPPING PATH, Layer B suppressed (no double-flag)"; else no "path-overlap suppression of Layer B did not hold"; fi

echo "── D. substrates cross-check FLIP — UNDECLARED-SUBSTRATE (§2.3 secondary) ──"
# POSITIVE: footprint.substrates [git-spine]; member declares a db (sql) effect → UNDECLARED-SUBSTRATE.
fresh_fixture
scripts/pending-set.sh mint REQ-SUB --footprint-lanes 'lane-a' --footprint-substrates 'git-spine' >/dev/null 2>&1
seed_member da lane-a REQ-SUB SET-0001 'src/a.txt' 'db: sp_seed_row'
scripts/ratify.sh assemble --cures none SET-0001 >/dev/null 2>&1
grep -qE '^- UNRESOLVED · .*UNDECLARED-SUBSTRATE' "$P" && ok "db effect outside footprint.substrates [git-spine] → UNDECLARED-SUBSTRATE flag" || no "UNDECLARED-SUBSTRATE not flagged for an undeclared sql effect"
# FLIP: declare sql in footprint.substrates → NO flag.
fresh_fixture
scripts/pending-set.sh mint REQ-SUB --footprint-lanes 'lane-a' --footprint-substrates 'git-spine,sql' >/dev/null 2>&1
seed_member db lane-a REQ-SUB SET-0001 'src/a.txt' 'db: sp_seed_row'
scripts/ratify.sh assemble --cures none SET-0001 >/dev/null 2>&1
grep -qE '^- UNRESOLVED · .*UNDECLARED-SUBSTRATE' "$P" && no "FLIP: declared sql wrongly flagged UNDECLARED-SUBSTRATE" || ok "FLIP: declared sql → NO flag (discrimination holds)"
# SKIP: registry omits substrates (—) → cross-check does not run, even for a db member.
fresh_fixture
scripts/pending-set.sh mint REQ-SUB --footprint-lanes 'lane-a' >/dev/null 2>&1
seed_member dc lane-a REQ-SUB SET-0001 'src/a.txt' 'db: sp_seed_row'
scripts/ratify.sh assemble --cures none SET-0001 >/dev/null 2>&1
grep -qE '^- UNRESOLVED · .*UNDECLARED-SUBSTRATE' "$P" && no "substrate check ran despite an omitted (—) footprint.substrates" || ok "omitted footprint.substrates → cross-check skipped (optional, unchanged prior behavior)"

echo "── E. REQ-HUNT APPEND — filled-slot append, latest-wins, exit-status ──"
# E1: a first hunt on the EMPTY slot still fills it exactly as before — ONE plain block, no RE-HUNT header
# (preservation pole; SET-0069's runner criteria re-run — the ORIGINAL fill path must not change shape).
setup_clean_set
scripts/ratify.sh hunt SET-0001 --method 'grep sp_/probe_ across member surfaces' --candidates 'sp_x' --residual 'low' --verdict CLEAR >/dev/null 2>&1
vcount="$(grep -cE '^- verdict:' "$P")"; rcount="$(grep -cE '^### RE-HUNT #' "$P")"
if [[ "$vcount" -eq 1 && "$rcount" -eq 0 ]]; then ok "preservation: first hunt on an EMPTY slot still fills ONE plain block (no RE-HUNT header)"; else no "first-fill format changed (verdict lines=$vcount, RE-HUNT headers=$rcount)"; fi

# E2 (a): a SECOND hunt on the now-FILLED slot APPENDS a dated RE-HUNT #1 block — never a silent no-op.
# RED on the old bytes: the pre-cure awk substitutes nothing (marker already gone) and prints "… recorded
# (SEMANTIC HUNT slot filled)." over 0 changed bytes — this is the defect itself.
out="$(scripts/ratify.sh hunt SET-0001 --method 'second pass' --candidates 'sp_y' --residual 'low' --verdict CLEAR 2>&1)"; rc=$?
if [[ $rc -eq 0 ]] && grep -qE '^### RE-HUNT #1 · .* · by ' "$P" && grep -qi 'RE-HUNT #1 appended' <<<"$out"; then
    ok "RED-CURE: filled-slot hunt APPENDS ### RE-HUNT #1 (rc=0, block present, success line names it)"
else
    no "filled-slot hunt did not append RE-HUNT #1 (rc=$rc): ${out##*$'\n'}"
fi

# E3 (a): N increments on a THIRD hunt (RE-HUNT #2); the FIRST RE-HUNT block is left byte-present
# (annotate-not-overwrite — never edited, only appended after).
before2="$(grep -cE '^### RE-HUNT #1' "$P")"
out="$(scripts/ratify.sh hunt SET-0001 --method 'third pass' --candidates 'sp_z' --residual 'low' --verdict CLEAR 2>&1)"; rc=$?
after2="$(grep -cE '^### RE-HUNT #1' "$P")"
if [[ $rc -eq 0 ]] && grep -qE '^### RE-HUNT #2 · ' "$P" && [[ "$before2" -eq "$after2" ]]; then
    ok "RE-HUNT numbering increments (#2 appended, #1 preserved byte-present, annotate-not-overwrite)"
else
    no "RE-HUNT #2 did not append correctly or #1 was disturbed (rc=$rc, #1 count $before2 -> $after2)"
fi

# E4 (b): LATEST-WINS — append a re-hunt verdict UNABLE over the CLEAR history above; a MERGE decision
# MUST now read the LATEST (UNABLE) block and REFUSE, not the FIRST (CLEAR) block. RED on the old bytes:
# `head -1` reads the FIRST block in the section, so ratify wrongly PROCEEDS to RATIFIED on stale CLEAR.
scripts/ratify.sh hunt SET-0001 --residual 'could not re-open the make SoR index this pass' --verdict UNABLE >/dev/null 2>&1
out="$(scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED 2>&1)"; rc=$?
if [[ $rc -ne 0 ]] && grep -qi "verdict is 'UNABLE'" <<<"$out"; then
    ok "RED-CURE: latest-wins — ratify reads the LATEST (UNABLE) block and REFUSES, not the first CLEAR block (rc=$rc)"
else
    no "latest-wins did NOT hold — ratify did not refuse on the latest UNABLE block (rc=$rc): ${out##*$'\n'}"
fi
if grep -qi 'reading LATEST block' <<<"$out" && grep -qE 'RE-HUNT #' <<<"$out"; then
    ok "ratify PRINTS which block it read (names the RE-HUNT block, not silent)"
else
    no "ratify did not print which SEMANTIC HUNT block it read: ${out##*$'\n'}"
fi

echo "── E'. downgrade-after-MERGE refusal + no-op invariant + exit-status (fresh sets) ──"
# E5 (c): downgrade-after-MERGE — ratify a set CLEAR, then attempt a re-hunt verdict UNABLE. Must REFUSE
# (exit non-zero), quote the ruling's own class name, and leave the RATIFIED packet byte-UNTOUCHED (a hunt
# after the pen is a finding for the register, not a slot edit — §2.2). RED on the old bytes: the pre-cure
# hunt has no concept of "already ratified" and would happily print "UNABLE recorded" at rc=0 (inverted
# exit-status bug) over a packet it also did not actually change.
setup_clean_set
scripts/ratify.sh hunt SET-0001 --method 'grep sp_/probe_ across member surfaces' --candidates 'sp_x' --residual 'low' --verdict CLEAR >/dev/null 2>&1
scripts/ratify.sh ratify SET-0001 --by 'Probe Operator' --rationale-class in-band --decision RATIFIED >/dev/null 2>&1
grep -q '^- decision: RATIFIED' "$P" || no "E5 setup failed: packet was not ratified"
pre_sha="$(shasum -a 256 "$P" | awk '{print $1}')"
out="$(scripts/ratify.sh hunt SET-0001 --residual 'post-merge finding: candidate list may be stale' --verdict UNABLE 2>&1)"; rc=$?
post_sha="$(shasum -a 256 "$P" | awk '{print $1}')"
if [[ $rc -ne 0 ]] && grep -qi 'DOWNGRADE' <<<"$out" && [[ "$pre_sha" == "$post_sha" ]]; then
    ok "RED-CURE: downgrade-after-MERGE (CLEAR→UNABLE post-ratify) REFUSED (rc=$rc), packet byte-untouched"
else
    no "downgrade-after-MERGE did NOT refuse or mutated a ratified packet (rc=$rc, sha $pre_sha -> $post_sha): ${out##*$'\n'}"
fi
# E5-FLIP: a re-hunt verdict CLEAR (not a downgrade) after the SAME MERGE is NOT blocked — the refusal is
# scoped to the DOWNGRADE case only (§2.2), never a blanket "no hunt after ratify" rule.
out="$(scripts/ratify.sh hunt SET-0001 --method 'post-merge re-check' --candidates 'ZERO' --residual 'confirmed clean' --verdict CLEAR 2>&1)"; rc=$?
if [[ $rc -eq 0 ]] && grep -qE '^### RE-HUNT #' "$P"; then ok "FLIP: a non-downgrade re-hunt (CLEAR) after the same MERGE is NOT refused (rc=0, appended)"; else no "FLIP failed: a CLEAR re-hunt after MERGE was wrongly blocked (rc=$rc): ${out##*$'\n'}"; fi

# E6 (d): the no-op invariant — every REAL hunt success path leaves the packet byte-different (first fill
# AND a re-hunt append), and the refusal string is wired into the source (same defensive-halt class as
# cmd_ratify's own ZERO-BYTE STAMP check — by construction every write path here ADDS a full new block, so
# the halt is unreachable via a normal call; proven present + wired, not merely claimed).
setup_clean_set
s0="$(shasum -a 256 "$P" | awk '{print $1}')"
scripts/ratify.sh hunt SET-0001 --method 'm' --candidates 'c' --residual 'r' --verdict CLEAR >/dev/null 2>&1
s1="$(shasum -a 256 "$P" | awk '{print $1}')"
scripts/ratify.sh hunt SET-0001 --method 'm2' --candidates 'c2' --residual 'r2' --verdict CLEAR >/dev/null 2>&1
s2="$(shasum -a 256 "$P" | awk '{print $1}')"
if [[ "$s0" != "$s1" && "$s1" != "$s2" ]]; then ok "no-op invariant: both the first fill and the re-hunt append change the packet sha"; else no "a hunt call left the packet byte-identical (s0=$s0 s1=$s1 s2=$s2)"; fi
if command grep -q 'hunt: wrote nothing' "$RT"; then ok "the no-op refusal message 'hunt: wrote nothing' is wired into cmd_hunt (static presence)"; else no "'hunt: wrote nothing' is not present in scripts/ratify.sh"; fi

# E7 (e): exit status — CLEAR/EDGE-NAMED exit 0; UNABLE exits non-zero (corrected
# design). RED on the old bytes: the trailing conditional-echo idiom is INVERTED there — CLEAR/EDGE-NAMED
# exit 1, UNABLE exits 0.
setup_clean_set
scripts/ratify.sh hunt SET-0001 --method 'm' --candidates 'c' --residual 'r' --verdict CLEAR >/dev/null 2>&1; rc_clear=$?
scripts/ratify.sh hunt SET-0001 --residual 'r2' --verdict UNABLE >/dev/null 2>&1; rc_unable=$?
setup_clean_set
scripts/ratify.sh hunt SET-0001 --residual 'edge case' --verdict EDGE-NAMED --edges 'x-drift' >/dev/null 2>&1; rc_edge=$?
if [[ $rc_clear -eq 0 && $rc_edge -eq 0 && $rc_unable -ne 0 ]]; then
    ok "RED-CURE: exit status — CLEAR rc=$rc_clear, EDGE-NAMED rc=$rc_edge (both 0); UNABLE rc=$rc_unable (non-zero)"
else
    no "exit status wrong — CLEAR rc=$rc_clear, EDGE-NAMED rc=$rc_edge, UNABLE rc=$rc_unable (want 0,0,nonzero)"
fi

echo
echo "set-gate-semantic-hunt: PASS=$PASS FAIL=$FAIL"
[[ $FAIL -eq 0 ]] || exit 1
exit 0
