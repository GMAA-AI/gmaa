#!/usr/bin/env bash
# probe_auditor_model_pin_v1.sh — standing probe `auditor-model-pin`.
#   The auditor's tier is `opus`, carried by an explicit `--model "$AUDITOR_MODEL"` whose ONE literal lives in the hook.
#   POLE 1 (the stamp): agents/post-commit-hook.sh carries the invocation flag exactly once and the default assignment's
#     literal is `opus` (grep over the hook). Red: a scratch copy with the flag removed reads FAIL.
#   POLE 2 (the ledger): every ledger/auditor-usage.jsonl row with status RECORDED and ts_utc at or after the landing
#     commit's committer time has every model_usage key beginning `claude-opus-` or `claude-haiku-` (the harness's own
#     utility calls). Any other key prints `AUDITOR-MODEL: FAIL <ts_utc> <sha8> <model>` and exits 1. A RECORDED row
#     with no model_usage reading is a stamp that cannot be shown: FAIL <ts_utc> <sha8> ABSENT (DISC-ABSENCE-OF-RECORD, fail-closed).
#     Zero rows since the landing prints `AUDITOR-MODEL: NO RECORD since <sha8>` and is labelled, never PASS.
#   The landing commit = the oldest commit that ADDED this probe file; no such commit yet (a pre-landing tree) is labelled
#   NO RECORD (landing commit not in history), never a pass. Test seams (fixtures only): --hook --ledger --since-epoch --since-label.
# EXIT: 0 no pole FAILs (pole 2 may be labelled NO RECORD) · 1 a pole FAILs · 3 unreadable input.
# SIGNALS (agents/standing-probes.yaml): pass "AUDITOR-MODEL-PIN: OK" · fail "AUDITOR-MODEL: FAIL".
set -u
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "AUDITOR-MODEL-PIN: UNREADABLE not in a git worktree" >&2; exit 3; }
HOOK="$ROOT/agents/post-commit-hook.sh"; LEDGER="$ROOT/ledger/auditor-usage.jsonl"; SINCE=""; LABEL=""
while [ $# -gt 0 ]; do
    case "$1" in
        --hook) HOOK="$2"; shift 2 ;;
        --ledger) LEDGER="$2"; shift 2 ;;
        --since-epoch) SINCE="$2"; shift 2 ;;
        --since-label) LABEL="$2"; shift 2 ;;
        *) echo "AUDITOR-MODEL-PIN: UNREADABLE unknown argument $1" >&2; exit 3 ;;
    esac
done
[ -r "$HOOK" ] || { echo "AUDITOR-MODEL-PIN: UNREADABLE hook $HOOK" >&2; exit 3; }
[ -r "$LEDGER" ] || { echo "AUDITOR-MODEL-PIN: UNREADABLE ledger $LEDGER" >&2; exit 3; }
fail=0; P2="pole 2 PASS"
# --- POLE 1: the stamp ---
n_flag="$(command grep -c -- '--model "\$AUDITOR_MODEL"' "$HOOK")"
n_def="$(command grep -c '^AUDITOR_MODEL="\${AUDITOR_MODEL:-opus}"$' "$HOOK")"
if [ "$n_flag" = "1" ] && [ "$n_def" = "1" ]; then
    echo "AUDITOR-MODEL: pole 1 stamp PASS (flag lines=$n_flag, default-opus lines=$n_def)"
else
    echo "AUDITOR-MODEL: FAIL pole 1 stamp (flag lines=$n_flag expected 1, default-opus lines=$n_def expected 1) in $HOOK"; fail=1
fi
# --- POLE 2: the ledger, since the landing commit ---
if [ -z "$SINCE" ]; then
    LSHA="$(git -C "$ROOT" log --diff-filter=A --format=%H -- probes/auditor/probe_auditor_model_pin_v1.sh 2>/dev/null | tail -1)"
    if [ -n "$LSHA" ]; then SINCE="$(git -C "$ROOT" log -1 --format=%ct "$LSHA")"; LABEL="${LSHA:0:8}"; fi
fi
if [ -z "$SINCE" ]; then
    echo "AUDITOR-MODEL: pole 2 ledger NO RECORD since (landing commit not in history; labelled, not a pass)"; P2="pole 2 NO RECORD, not a PASS"
else
    out="$(python3 -I - "$LEDGER" "$SINCE" "${LABEL:-landing}" <<'PY'
import json, sys, datetime
ledger, since, label = sys.argv[1], int(sys.argv[2]), sys.argv[3]
n = 0; bad = []
try:
    rows = [json.loads(ln) for ln in open(ledger, encoding="utf-8") if ln.strip()]
    for r in rows:
        datetime.datetime.strptime(r["ts_utc"], "%Y-%m-%dT%H:%M:%SZ") if r.get("status") == "RECORDED" else None
except (OSError, ValueError, KeyError) as e:
    print(f"unreadable ledger: {e}", file=sys.stderr); sys.exit(3)
for r in rows:
    if r.get("status") != "RECORDED":
        continue
    ts = datetime.datetime.strptime(r["ts_utc"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=datetime.timezone.utc).timestamp()
    if ts < since:
        continue
    n += 1
    mu = r.get("model_usage")
    keys = list(mu) if isinstance(mu, dict) and mu else []
    if not keys:
        bad.append(f"AUDITOR-MODEL: FAIL {r['ts_utc']} {str(r.get('sha',''))[:8]} ABSENT")
    for k in keys:
        if not (k.startswith("claude-opus-") or k.startswith("claude-haiku-")):
            bad.append(f"AUDITOR-MODEL: FAIL {r['ts_utc']} {str(r.get('sha',''))[:8]} {k}")
for b in bad:
    print(b)
if bad:
    print(f"AUDITOR-MODEL: pole 2 ledger FAIL ({len(bad)} off-tier of {n} RECORDED rows since {label})")
elif n == 0:
    print(f"AUDITOR-MODEL: pole 2 ledger NO RECORD since {label}")
else:
    print(f"AUDITOR-MODEL: pole 2 ledger PASS ({n} RECORDED rows since {label}, all claude-opus-/claude-haiku-)")
sys.exit(1 if bad else 0)
PY
)"; prc=$?
    printf '%s\n' "$out"
    case "$out" in *"NO RECORD"*) P2="pole 2 NO RECORD, not a PASS" ;; esac
    [ "$prc" -eq 3 ] && { echo "AUDITOR-MODEL-PIN: UNREADABLE ledger rows" >&2; exit 3; }
    [ "$prc" -eq 0 ] || fail=1
fi
if [ "$fail" -eq 0 ]; then echo "AUDITOR-MODEL-PIN: OK (pole 1 PASS; $P2)"; exit 0; fi
echo "AUDITOR-MODEL-PIN: not ok"; exit 1
