#!/usr/bin/env bash
# AC9 seeded fixture — force BOTH sides of a surface to enumerate empty; MUST exit 3, never 0.
# Isolated temp tree (DISC-PROBE-INPUT-PROVENANCE: a synthetic-input result proves the synthetic
# case, and that is exactly what is wanted here — the real repo can never present zero/zero).
set -uo pipefail
SRC="$(git rev-parse --show-toplevel)"
# the fixture's spine ref is the ONE resolver's output of the tree under test (the one spine-ref resolver), never a literal
SR="$(bash "$SRC/scripts/spine-ref.sh")" && [ -n "$SR" ] \
  || { echo "UNREADABLE: SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled in the tree under test (the one spine-ref resolver)"; exit 3; }
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
cd "$T"
git init -q .; git config user.email a@b.c; git config user.name t
mkdir -p _orchestration/relay-outbox/architect _orchestration/relay-inbox/architect _ratification/criteria scripts
cp "$SRC/scripts/spine-ref.sh" scripts/spine-ref.sh   # the resolver travels with the reconciler (its default GOV_REF)
: > _orchestration/relay-outbox/architect/.gitkeep
: > _orchestration/relay-inbox/architect/.gitkeep
git add -A >/dev/null; git commit -qm "empty both sides"
git branch -q architect 2>/dev/null || true
# Point origin/* at this tree's own refs so the surface reads EMPTY on both sides.
git update-ref "refs/remotes/$SR" HEAD
git update-ref refs/remotes/origin/architect HEAD
cp "$SRC/scripts/reconciliation-diff.sh" ./rd.sh
cp "$SRC/scripts/canon-core.sh" ./canon-core.sh   # NOTE: the shared resolver travels with the script
cp "$SRC/scripts/consume-core.sh" ./consume-core.sh   # the relay-name predicate travels with the script
cp "$SRC/scripts/spine-ref.sh" ./spine-ref.sh   # the spine-ref resolver travels with it too (0507 R2: found beside the running script)
o="$(bash ./rd.sh --surface manifest --no-fetch 2>&1)"; r=$?
echo "--- fixture output ---"
printf '%s\n' "$o" | tail -6
echo "AC9 exit=$r (expect 3)"
printf '%s' "$o" | grep -qiE 'UNREADABLE|failed read' && echo "AC9 message=OK (names it a failed read, not agreement)"
# ⚠ EXIT CONVENTION — hardened after a review caught it.
#   The prior final line was `[ "$r" -eq 3 ] && echo "AC9 PASS" || echo "AC9 FAIL"`, which PRINTS
#   the verdict and EXITS 0 EITHER WAY — `echo` succeeds in both branches. Its two siblings end
#   `[ "$F" -eq 0 ] || exit 1`; this one did not. A bare invocation of it as an acceptance test
#   would therefore have been a FIFTH check that cannot go red — created while fixing four of
#   exactly that kind, and sitting inside the fixture set that exists to PROVE the poles went red.
#   ***A probe that cannot report its own failure is not evidence.***
# REASON-BOUND: exit 3 alone is not the pole — a MISSING HELPER also exits 3, which passed
# this probe for the wrong reason when canon-core.sh was first introduced. The 3 must carry the zero/zero reason.
if [ "$r" -eq 3 ] && printf '%s' "$o" | grep -qE 'both sides enumerated ZERO files'; then echo "AC9 PASS"; else echo "AC9 FAIL (exit=$r; zero/zero reason absent)"; exit 1; fi
