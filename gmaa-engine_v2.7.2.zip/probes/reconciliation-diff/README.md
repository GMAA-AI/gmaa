# `probes/reconciliation-diff/` — the SEEN-TO-FAIL evidence for `SET-0007`

**Why these are here and not in scratch (explicit GO).** These fixtures **are the evidence that the acceptance poles went RED.** A seen-to-fail proof whose fixtures live in gitignored `.tmp/` is **unreproducible the moment scratch clears** — which is the standing finding exactly: *a durable document instructing a re-run against a path the repo cannot keep.* The claim *"six poles went red"* is only checkable if the thing that reddened them survives.

**Why `probes/` is the right home, verified not assumed:** `probes/` is **NOT in `SPINE_PATHS`** (0 matches in the `agents/pre-commit-hook.sh` census) ⇒ **no ratified set required; a foundation commit suffices** — the same reasoning as for the link-inventory generator. **And a seen-to-fail fixture is evidence, which is what `probes/` is for.** *(Foundation asked rather than assumed, because the last durable-path question turned on exactly the scaffolding-vs-mechanism distinction.)*

---

## The three harnesses

| file | covers | bar |
|---|---|---|
| `probe_ac1_ac6_battery_v1.sh` | **AC1–AC6** — closed exit set · bidirectional headings on all 3 surfaces · surface-definition + denominator printed · stale labelled and non-zero · unreadable ⇒ exit 3 · read-only | 6 PASS / 0 FAIL |
| `probe_ac7_ac8_seeded_poles_v1.sh` | **AC7's three SEEDED red poles** (`manifest` D2 · `pending-set` D1 · `origin-engine` D1) **+ AC8** content-not-ancestry | 4 PASS / 0 FAIL |
| `probe_ac9_zero_zero_unreadable_v1.sh` | **AC9** — both sides enumerate empty ⇒ exit **3**, never 0 | PASS |

**AC7's other three poles are LIVE-RED and need no fixture** — they occur in the real tree: `manifest` D1 · `pending-state` D2 · `origin-engine` D2. *(One of them flagged **this very set's own criteria** as declared by no assembled packet — the gate catching its own author.)*

## Two harness lessons preserved in the files, because both produced FALSE results

1. **`probe_ac1_ac6_battery_v1.sh` header** — the first cut piped the script into `grep -q` under `set -o pipefail`. Because the script **legitimately exits 2 on divergence**, pipefail made the *pipeline* status 2 even when grep matched, so **AC2/AC3 reported FAIL against correct code.** A harness bug producing a **false RED** is cheaper than one producing a false green — **but only if you check which one is lying.** Output is now captured first, then matched.
2. **`bash 3.2` constraints** (this host): **no `mapfile`/`readarray`**, **no `${var//…/}` on large strings** (it *hangs*), and **never `grep -c … || echo 0`** (the D-9 idiom: emits `0\n0`). The first implementation used `mapfile`, which is **not a builtin here** — the arrays came back unbound and **two surfaces reported "0 divergence / exit 0" from nothing.** A false green, in the gate built to detect false greens.

## Re-running

```
bash probes/reconciliation-diff/probe_ac1_ac6_battery_v1.sh
bash probes/reconciliation-diff/probe_ac7_ac8_seeded_poles_v1.sh
bash probes/reconciliation-diff/probe_ac9_zero_zero_unreadable_v1.sh
```

**All three require `scripts/reconciliation-diff.sh` to be present.** ⚠ **At the time of writing that file is UNCOMMITTABLE** (`scripts/**` is spine, non-exempt ⇒ ratified set ⇒ the operator's pen) and exists only as working-tree bytes — **246 lines, `sha256:96d3180d08a8d50de0d1728e9d02a4…`**, verified by a second seat while the window was open. **Once `SET-0007` lands, that caveat expires and these run against the committed script.**

**Re-run them after ANY change to the mechanism's exit paths.** A change to an exit code **invalidates poles written against the old one** — green-before is not green-after.
