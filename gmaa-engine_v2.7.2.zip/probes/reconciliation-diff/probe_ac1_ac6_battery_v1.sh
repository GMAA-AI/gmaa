#!/usr/bin/env bash
# SET-0007 acceptance battery — AC1..AC6, re-run after the bash-3.2 fix.
# ⚠ HARNESS NOTE: the first cut of this battery piped the script into `grep -q` under `set -o
#   pipefail`. Because the script legitimately exits 2 on divergence, pipefail made the PIPELINE
#   status 2 even when grep matched — so AC2/AC3 reported FAIL for a script that was behaving
#   correctly. Same family as the logged `probe | tail` trap (a pipeline's status is not the
#   status of the stage you care about). Output is now CAPTURED first, then matched.
set -uo pipefail
cd "$(git rev-parse --show-toplevel)"
P=0; F=0
ok(){ echo "  PASS $1"; P=$((P+1)); }
no(){ echo "  FAIL $1"; F=$((F+1)); }
run(){ bash scripts/reconciliation-diff.sh "$@" 2>&1; }

run --surface bogus >/dev/null 2>&1
[ $? -eq 1 ] && ok "AC1 closed exit set (usage=1)" || no "AC1"

acc=0
for s in manifest pending-set origin-engine; do
  o="$(run --surface "$s" --no-fetch)"
  printf '%s' "$o" | grep -qi 'direction 1' || acc=1
  printf '%s' "$o" | grep -qi 'direction 2' || acc=1
done
[ "$acc" -eq 0 ] && ok "AC2 bidirectional on all 3 surfaces" || no "AC2"

acc=0
for s in manifest pending-set origin-engine; do
  o="$(run --surface "$s" --no-fetch)"
  printf '%s' "$o" | grep -qiE 'surface (definition|paths|refs)' || acc=1
  printf '%s' "$o" | grep -qi 'denominator' || acc=1
done
[ "$acc" -eq 0 ] && ok "AC3 surface definition + denominator printed on all 3" || no "AC3"

o="$(run --surface manifest --no-fetch)"; r=$?
printf '%s' "$o" | grep -qi 'AS-OF-LAST-FETCH' && [ "$r" -ne 0 ] && ok "AC4 stale labelled AND non-zero (exit=$r)" || no "AC4"

o="$(run --surface origin-engine --engine-root /nonexistent-path)"; r=$?
[ "$r" -eq 3 ] && printf '%s' "$o" | grep -qiE 'unreadable|HALT' && ok "AC5 unreadable=3, absence never agreement" || no "AC5"

b=$(git status --porcelain | shasum)
for s in manifest pending-set origin-engine; do run --surface "$s" --no-fetch >/dev/null 2>&1; done
a=$(git status --porcelain | shasum)
[ "$b" = "$a" ] && ok "AC6 read-only" || no "AC6"

echo "BATTERY: $P pass / $F fail"
[ "$F" -eq 0 ] || exit 1
