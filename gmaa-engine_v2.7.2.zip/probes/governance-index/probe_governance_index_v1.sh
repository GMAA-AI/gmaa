#!/usr/bin/env bash
# probe_governance_index_v1.sh — STANDING PROBE for the governance index + retriever (AC-1/AC-2)
#
# RUNLISTED: agents/standing-probes.yaml (id: governance-index-drift).
#   It is runlisted IN THE SAME SET that lands the mechanism it guards. A probe that declares itself
#   STANDING while being scheduled nowhere is the false-green class (MECH-AUDIT) names — and
#   building the mechanism without runlisting its probe would have committed that exact defect in
#   the same session that read the ruling.
#
# ASSERTS (each arm independently, so a pass cannot be carried by another arm):
#   A. generator instrument control — the §0 parser measures what it claims (synthetic fixture).
#   B. index currency — no stale drift, no unannotated CORE id, no orphan annotation row.
#   C. retriever behaviour — seeded hit fires AND the negative control does NOT (a retriever that
#      returned everything would pass a hit-only test).
#   D. wiring/strength resolution (SPEC-GOVERNANCE-INDEX) — every `wiring` value in the built
#      index is checked against the LIVE enforcer set, never asserted: a `scanner:<class>` must be a
#      class `scripts/creed-scan.sh` actually declares (read live, never hand-copied); a `probe:<path>`
#      must exist at HEAD; a `gate:<hook|script>` must name an installed hook or an existing script; a
#      `cite-only:<reason>` must carry >= 8 words. A wiring claim that does not resolve is DRIFT.
#   E. layer (SPEC-GOVERNANCE-INDEX) — every row carries layer S | W-generic | W-project (col 12,
#      from _index/layers.tsv); a row with none, or any other value, FAILS. Census printed with denominator.
#
# WHAT THIS PROBE DOES *NOT* ASSERT (canon §13 — honest scope, never represented as complete):
#   It does not assert that any draft is conformant, nor that the rule set is complete. It asserts
#   that the INSTRUMENT is intact and the INDEX is current. Those are different claims.
#
# EXIT: 0 + "VERDICT: PASS" | 1 + "VERDICT: FAIL"
set -uo pipefail
cd "$(git rev-parse --show-toplevel)" || { echo "VERDICT: FAIL (not in a git repo)"; exit 1; }

FAILED=0
note() { printf '  %-52s %s\n' "$1" "$2"; }

# --- Arm A: generator instrument control ------------------------------------
if scripts/gen-governance-index.sh self-test >/dev/null 2>&1; then
    note "A. generator instrument control (fixture)" "PASS"
else
    note "A. generator instrument control (fixture)" "FAIL"; FAILED=1
    scripts/gen-governance-index.sh self-test 2>&1 | sed 's/^/     /'
fi

# --- Arm B: index currency (drift is fail-closed) ---------------------------
B_OUT="$(scripts/gen-governance-index.sh check 2>&1)"; B_RC=$?
if [[ $B_RC -eq 0 ]]; then
    note "B. index current (no drift/unannotated/orphan)" "PASS"
else
    note "B. index current (no drift/unannotated/orphan)" "FAIL (rc=$B_RC)"; FAILED=1
    printf '%s\n' "$B_OUT" | grep -E 'DRIFT|UNANNOTATED-CORE|ORPHAN|HALT|CONTROL-MISS' | sed 's/^/     /'
fi

# --- Arm C: retriever behaviour, both polarities ----------------------------
if scripts/rulecheck.sh --self-test >/dev/null 2>&1; then
    note "C. retriever seeded-hit + negative control" "PASS"
else
    note "C. retriever seeded-hit + negative control" "FAIL"; FAILED=1
    scripts/rulecheck.sh --self-test 2>&1 | sed 's/^/     /'
fi

# --- Arm D: wiring/strength resolves at the live enforcer set (SPEC-GOVERNANCE-INDEX) --------------
# ⚠ MUST NOT split governance.tsv rows with bash `read -r ... IFS=$'\t'` directly — TAB is bash IFS
#   WHITESPACE, so a row with an EMPTY field (e.g. `interacts_with`) collapses two adjacent tabs into
#   one delimiter and shifts every later field left (the exact documented bug in gen-governance-index.sh's
#   annot_lookup comment, ASCII \x1f workaround). Re-key to \x1f via awk FIRST, THEN bash-read.
IDX="_index/governance.tsv"
D_FAIL=0
D_OUT=""
# ⛔ FRAME (MECH-WRITE): arm D must check the index the scanner READS against the
#   scanner that RUNS. Since creed-scan.sh reads the index FROM THE SPINE on every non-hub seat and
#   the hooks run the SPINE's creed-scan bytes there — so on a lane both inputs come from the spine ref, never
#   the lane's own (correctly un-merged) branch copies. The hub's worktree IS the spine in
#   progress, so the hub measures its own tree. GOV_PROBE_REF=<ref> pins an explicit frame (replicas).
_rl_line="$(scripts/resolve-lane.sh 2>/dev/null)" || _rl_line=""
if [[ -n "${GOV_PROBE_REF:-}" ]]; then FRAME="$GOV_PROBE_REF"
elif [[ " $_rl_line " == *" spine_write=ALLOW "* ]]; then FRAME="WORKTREE"
else
    # the spine ref (the one spine-ref resolver): the ONE resolver's output; unresolvable = UNREADABLE by name, never a literal
    FRAME="$(bash scripts/spine-ref.sh)" && [[ -n "$FRAME" ]] \
        || { echo "UNREADABLE: SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and GOV_PROBE_REF unset (the one spine-ref resolver)"; exit 3; }
fi
_frame_read() { if [[ "$FRAME" == WORKTREE ]]; then cat "$1" 2>/dev/null; else git show "${FRAME}:$1" 2>/dev/null; fi; }
IDX_CONTENT="$(_frame_read "$IDX")"
SCAN_CONTENT="$(_frame_read scripts/creed-scan.sh)"
printf '  %s\n' "[arm D frame: ${FRAME}]"
if [[ -n "$IDX_CONTENT" ]]; then
    KNOWN_HOOKS="pre-commit pre-merge-commit commit-msg"
    # Live scanner-class roster — read from creed-scan.sh's class_pattern() MAP itself, never hand-copied
    # (canon §4 :134(i)). ⛔ AUDITOR ed2c4654 F2: C2 removed the old hard-coded `class_name_N='x'` lines, so
    # the previous extractor returned an EMPTY roster and charged every scanner: row as DRIFT — a regression
    # C2 caused. The map key `<name>/regex)` is the one surface every class must carry to run at all.
    SCANNER_CLASSES="$(printf '%s\n' "$SCAN_CONTENT" | command grep -oE '^[[:space:]]+[a-z][a-z-]*/regex\)' \
        | sed -E 's/^[[:space:]]+([a-z-]+)\/regex\)/\1/' | sort -u)"
    if [[ -z "$SCANNER_CLASSES" ]]; then
        D_FAIL=1; D_OUT="${D_OUT}     UNREADABLE: scanner-class roster EMPTY at frame ${FRAME} -- no '<name>/regex)' keys in scripts/creed-scan.sh; arm D cannot judge any scanner: row (fail-closed)
"
    fi

    _resolves_path() {   # <path> — exists in the frame (hub: HEAD or worktree; lane: the spine ref)
        if [[ "$FRAME" == WORKTREE ]]; then
            git cat-file -e "HEAD:$1" 2>/dev/null && return 0
            [[ -f "$1" ]] && return 0
            return 1
        fi
        git cat-file -e "${FRAME}:$1" 2>/dev/null
    }

    TRIPLES="$(printf '%s\n' "$IDX_CONTENT" | awk -F'\t' '/^#/{next} NF<11{next} {printf "%s\037%s\037%s\n", $1, $10, $11}')"
    while IFS=$'\037' read -r id wiring strength; do
        [[ -z "$id" ]] && continue
        case "$wiring" in
            scanner:*)
                cls="${wiring#scanner:}"
                if ! printf '%s\n' "$SCANNER_CLASSES" | grep -qx "$cls"; then
                    D_FAIL=1; D_OUT="${D_OUT}     DRIFT: ${id} wiring=scanner:${cls} -- not a class scripts/creed-scan.sh runs
"
                fi
                ;;
            probe:*)
                p="${wiring#probe:}"
                if ! _resolves_path "$p"; then
                    D_FAIL=1; D_OUT="${D_OUT}     DRIFT: ${id} wiring=probe:${p} -- path does not exist at HEAD
"
                fi
                ;;
            gate:*)
                g="${wiring#gate:}"
                ok=0
                for h in $KNOWN_HOOKS; do [[ "$g" == "$h" ]] && ok=1; done
                if [[ $ok -eq 0 ]] && _resolves_path "$g"; then ok=1; fi
                if [[ $ok -eq 0 ]]; then
                    D_FAIL=1; D_OUT="${D_OUT}     DRIFT: ${id} wiring=gate:${g} -- names neither an installed hook nor an existing script
"
                fi
                ;;
            cite-only:*)
                reason="${wiring#cite-only:}"
                wc_n="$(printf '%s' "$reason" | wc -w | tr -d ' ')"
                if [[ "${wc_n:-0}" -lt 8 ]]; then
                    D_FAIL=1; D_OUT="${D_OUT}     DRIFT: ${id} wiring=cite-only reason under 8 words (${wc_n})
"
                fi
                ;;
            UNWIRED)
                : # grandfather label for uncurated rows — always resolves
                ;;
            *)
                D_FAIL=1; D_OUT="${D_OUT}     DRIFT: ${id} wiring='${wiring}' -- unrecognized form
"
                ;;
        esac
        case "$strength" in
            PREDICATE|CITE-ONLY|UNWIRED) ;;
            *) D_FAIL=1; D_OUT="${D_OUT}     DRIFT: ${id} strength='${strength}' -- not one of PREDICATE|CITE-ONLY|UNWIRED
" ;;
        esac
    done <<< "$TRIPLES"
else
    D_FAIL=1; D_OUT="     UNREADABLE: ${IDX} absent or empty at frame ${FRAME}
"
fi
if [[ $D_FAIL -eq 0 ]]; then
    wline="$(scripts/gen-governance-index.sh census 2>/dev/null | command grep '^WIRED:')"
    note "D. wiring/strength resolves at the live enforcer set" "PASS"
    [[ -n "$wline" ]] && printf '  %s\n' "$wline"
else
    note "D. wiring/strength resolves at the live enforcer set" "FAIL"; FAILED=1
    printf '%s' "$D_OUT"
fi

# --- Arm E: every row carries a LAYER (SPEC-GOVERNANCE-INDEX: "A row with no layer fails the index probe") ---
# Same frame as arm D (the index the scanner reads). Fail-closed on: no index, a row with an empty/invalid layer,
# or ZERO rows judged (an arm that judged nothing must not PASS). Prints the per-layer census WITH its denominator.
E_OUT="$(printf '%s\n' "$IDX_CONTENT" | awk -F'\t' '
    /^#/{next} NF<11{next}
    { n++; l=(NF>=12)?$12:""; d=(NF>=13)?$13:""; t=(NF>=14)?$14:""
      if (l=="S"||l=="W-generic"||l=="W-project") c[l]++
      else { bad++; printf "     NO-LAYER: %s layer=[%s] -- not one of S|W-generic|W-project\n", $1, l }
      # disposition (SPEC-GOVERNANCE-INDEX): KEEP | MERGE <survivor> | RETIRE <reason>; MERGE/RETIRE need a target
      if (d=="KEEP"||d=="MERGE"||d=="RETIRE") { k[d]++; if (d!="KEEP" && t=="") { bad++; printf "     NO-TARGET: %s disposition=%s with an empty target-or-reason\n", $1, d } }
      else { bad++; printf "     NO-DISPOSITION: %s disposition=[%s] -- not one of KEEP|MERGE|RETIRE\n", $1, d }
      if (d=="KEEP") { keep[l]++ } }
    END { printf "  LAYERS: S=%d W-generic=%d W-project=%d invalid=%d of %d rows [frame: '"$FRAME"']\n", c["S"], c["W-generic"], c["W-project"], bad, n
          printf "  DISPOSITIONS: KEEP=%d MERGE=%d RETIRE=%d of %d rows · KEEP by layer: S=%d W-generic=%d W-project=%d\n", k["KEEP"], k["MERGE"], k["RETIRE"], n, keep["S"], keep["W-generic"], keep["W-project"]
          if (n==0 || bad>0) exit 1 }')"; E_RC=$?
if [[ -n "$IDX_CONTENT" && $E_RC -eq 0 ]]; then
    note "E. every index row carries a valid layer" "PASS"
else
    note "E. every index row carries a valid layer" "FAIL"; FAILED=1
fi
printf '%s\n' "$E_OUT"

if [[ $FAILED -eq 0 ]]; then
    echo "VERDICT: PASS"; exit 0
else
    echo "VERDICT: FAIL"; exit 1
fi
