#!/usr/bin/env bash
# proof_arming_both_polarity_v1.sh — the build-class COMPLETION BAR, as a runnable instrument.
#
# CONTRACT: contracts/SPEC-BUILD-CLASS-STANDING-APPROVAL.md §3/§5
#
# The bar, in its own words: "LIVE both-polarity proof AT the enforcer, not a fixture:
# (red) a seeded P-failing set is REFUSED by the wired gate — the commit/close blocks; (green) a
# genuine governance-plumbing set closes under the standing class with NO operator pen. Recorded with
# the enforcer's own verdict, AUDITOR-REPRODUCIBLE."
#
# This script IS that reproducibility. A prose transcript of four poles in a packet is a claim; this
# re-runs all four against the enforcers and exits non-zero if any pole moves. It builds a throwaway
# `git clone --shared` replica per run, so it NEVER touches the live spine, the live index, or the
# operator's worktree.
#
# ⛔ IT PROVES THE WORKING-TREE BUILD. The enforcers under test are copied from $REPO_ROOT's CURRENT
#    bytes (committed or not) — that is the point at arming time, when the cure is not yet merged.
#    After the set lands, the same run proves the committed bytes, unchanged.
#
# ⛔ EVERY POLE IS ASSERTED ON STATE, NEVER ON AN EXIT CODE ALONE. "the close blocks" is checked by
#    reading the packet for `- decision:`; "the commit blocks" is checked by comparing HEAD before and
#    after. A halt message is not proof that nothing was written.
#
# EXIT: 0 = all four poles fire as specified · 1 = a pole moved · 2 = HALT (could not build the replica)

set -u
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "proof: not in a git worktree"; exit 2; }
cd "$REPO_ROOT" || exit 2

FAILS=0
ok()   { printf '  PASS  %s\n' "$*"; }
bad()  { printf '  FAIL  %s\n' "$*"; FAILS=$((FAILS+1)); }
halt() { printf 'HALT — %s\n' "$*"; exit 2; }

TMP="$(mktemp -d -t bcarming.XXXXXX)" || halt "cannot create temp dir"
trap 'rm -rf "$TMP"' EXIT
REP="$TMP/rep"

echo "== proof_arming_both_polarity_v1 (completion bar) =="
echo "-- building throwaway replica (the live spine is never touched)"
git clone --shared --quiet "$REPO_ROOT" "$REP" 2>/dev/null || halt "clone failed"

# The enforcers under test = the CURRENT working-tree bytes.
for f in scripts/ratify.sh agents/pre-commit-hook.sh scripts/build-class-check.sh; do
    cp "$REPO_ROOT/$f" "$REP/$f" || halt "cannot stage $f into the replica"
done

# The replica is a fixture holding no registry row and no key: enroll its lane once (apex: the pen poles tie the OS login).
SEAT_KEYS_HOME="$TMP/keys" bash "$REPO_ROOT/scripts/seat-keys.sh" fixture-enroll "$REP" foundation --apex >"$TMP/enroll.out" 2>&1 || halt "fixture-enroll failed: $(tail -1 "$TMP/enroll.out")"

BASE_SHA="$(git -C "$REP" rev-parse HEAD)"

# --- fixtures: two packets IDENTICAL except for the declared footprint. -----------------------------
# Holding everything else equal is what makes the pair a proof rather than two anecdotes.
mk_packet() { # $1=setid  $2=surfaces  $3=title
    cat > "$REP/_ratification/$1.md" <<PKT
# $1 — ARMING PROOF · $3

## HEADER
- set id: $1
- requirement id: REQ-ARMING-PROOF
- HEAD sha at assembly: $BASE_SHA
- p3-reversible: YES

## MEMBERS
- pf-demo · lane=foundation · main@$BASE_SHA · surfaces: $2

## JOINT-EDGES (mechanical; the floor)
- NONE detected.

## CONFORMANCE (U4B)
- pf-demo · lane=foundation · verdict: PASS · method: structured · evidence: arming proof fixture

## BUILD-CLASS (spec §3 — the mechanical P1–P4 predicate over this set's declared footprint)
<!-- BUILD-CLASS-UNEVALUATED -->

## INTEGRATOR ASSESSMENT (foundation agent — filled by \`ratify.sh assess\`)
- assessed-at: fixture
Arming proof fixture.

## SEMANTIC HUNT (canon §13)
- method: fixture — footprint read directly
- candidates considered: 1
- residual: none
- verdict: CLEAR

## DECISION LINE (operator — exactly one; C-RATIFICATION-PACKET §3) + RATIONALE CLASS (§4)
<!-- RATIFICATION-EMPTY -->

## POST-DECISION
- (pending)
PKT
}
mk_packet SET-9001 "scripts/demo-green-plumbing.sh" "GREEN POLE (genuine governance-plumbing footprint)"
mk_packet SET-9002 "_boot/BOOTSTRAP.md"              "RED POLE (seeded P-failing footprint)"

# ---------------------------------------------------------------- POLE 1 — RED at the CLOSE enforcer
echo "-- POLE 1 · RED at the close enforcer (ratify.sh ratify --standing-class)"
( cd "$REP" && bash scripts/ratify.sh ratify SET-9002 --standing-class ) >"$TMP/p1.out" 2>&1
p1_rc=$?
# ⛔ THE REFUSAL MUST COME FROM THE GATE. Measured on an UNARMED build, this pole passed VACUOUSLY:
#    `--standing-class` was an unknown argument, ratify died rc=1, nothing was stamped, and "refused"
#    read green while no gate had run. A red pole that cannot tell "the gate refused it" from "the
#    feature does not exist" certifies nothing — so the gate's OWN verdict text is required here.
if [ "$p1_rc" -eq 0 ]; then
    bad "a P-failing set closed pen-free (rc=0) — the gate did not refuse it"
elif grep -q '^- decision:' "$REP/_ratification/SET-9002.md"; then
    bad "the close was reported blocked but the packet WAS stamped — the refusal did not hold"
elif ! grep -q 'RATIFICATION-EMPTY' "$REP/_ratification/SET-9002.md"; then
    bad "the packet lost its RATIFICATION-EMPTY marker on a refused close"
elif ! grep -q 'BUILD-CLASS GATE REFUSED' "$TMP/p1.out"; then
    bad "refused, but NOT by the build-class gate (no gate verdict in the output) — vacuous pass: the consumer is not wired"
else
    ok "P-failing set REFUSED BY THE GATE (rc=$p1_rc); packet unstamped, RATIFICATION-EMPTY intact — the close actually blocked"
fi

# ---------------------------------------------------------- POLE 2 — GREEN at the CLOSE enforcer
echo "-- POLE 2 · GREEN at the close enforcer (pen-free close of a plumbing set)"
( cd "$REP" && bash scripts/ratify.sh ratify SET-9001 --standing-class ) >"$TMP/p2.out" 2>&1
p2_rc=$?
if [ "$p2_rc" -ne 0 ]; then
    bad "a genuine governance-plumbing set did NOT close pen-free (rc=$p2_rc) — see $TMP/p2.out"
elif ! grep -q '^- decision: RATIFIED' "$REP/_ratification/SET-9001.md"; then
    bad "close reported success but no '- decision: RATIFIED' was stamped (the false-success class)"
elif ! grep -q '^- ratified-by: BUILD-CLASS STANDING CLASS' "$REP/_ratification/SET-9001.md"; then
    bad "closed, but not recorded as a standing-class close"
elif ! grep -q '^- closed under: BUILD-CLASS STANDING-APPROVAL CLASS' "$REP/_ratification/SET-9001.md"; then
    bad "closed without the §4 honesty rider recording it as class authorization"
else
    ok "plumbing set CLOSED pen-free (rc=0); decision stamped, recorded as class authorization, no operator pen"
fi

# --------------------------------------------- the pen must still work on a P-failing set (routing)
echo "-- CONTROL · the gate ROUTES to the operator's pen rather than bricking the set"
( cd "$REP" && bash scripts/ratify.sh ratify SET-9002 --by 'Arming Proof Operator' --rationale-class in-band ) >"$TMP/pc.out" 2>&1
if grep -q '^- decision: RATIFIED' "$REP/_ratification/SET-9002.md"; then
    ok "the same refused set closes normally under a human pen"
else
    bad "a P-failing set could not be closed by the operator's pen either — the gate BRICKS it (see $TMP/pc.out)"
fi

# ------------------------------------------------------- POLES 3/4 — the pre-commit SPEND enforcer
echo "-- POLES 3/4 · the pre-commit enforcer (a pen-free stamp is re-verified where it is SPENT)"
# The hook refuses to run unless it is the canonical build, so the replica's canonical ref must point
# at the bytes under test. Committed with --no-verify: this is scaffolding, not a governed change.
printf '| 90 | pf-demo | foundation | main@%s | scripts/demo-green-plumbing.sh | ratified-in SET-9001 |\n' \
    "${BASE_SHA:0:8}" >> "$REP/PENDING-SET.md"
printf '#!/usr/bin/env bash\necho proof\n' > "$REP/scripts/demo-green-plumbing.sh"
cp "$REP/agents/pre-commit-hook.sh" "$REP/.git/hooks/pre-commit"
cp "$REP/scripts/spine-ref.sh" "$REP/.git/hooks/spine-ref.sh"   # an installed hook reads the resolver beside it (0507 R2/R16)
chmod +x "$REP/.git/hooks/pre-commit"
( cd "$REP" && git add -A && git commit --no-verify -q -m "proof scaffolding" ) >/dev/null 2>&1 || halt "scaffolding commit failed"
# the canonical ref is the replica's own spine ref, from the ONE resolver (the one spine-ref resolver), never a literal trunk
_SR="$( cd "$REP" && bash scripts/spine-ref.sh )" && [ -n "$_SR" ] || halt "SPINE-REF-UNRESOLVED: the replica's scripts/spine-ref.sh is missing or unfilled (the one spine-ref resolver)"
( cd "$REP" && git update-ref "refs/remotes/$_SR" HEAD ) || halt "cannot point the replica's canonical ref ($_SR) at the build under test"

# GREEN: a spine path covered ONLY by the pen-free set must commit.
printf 'echo "covered change"\n' >> "$REP/scripts/demo-green-plumbing.sh"
before="$( cd "$REP" && git rev-parse HEAD )"
( cd "$REP" && git add scripts/demo-green-plumbing.sh && git commit -q -m "proof GREEN: covered by a pen-free set" ) >"$TMP/p3.out" 2>&1
after="$( cd "$REP" && git rev-parse HEAD )"
if [ "$before" != "$after" ]; then
    ok "spine path covered ONLY by a pen-free standing-class set COMMITTED (HEAD moved)"
else
    bad "a legitimately covered path was refused — the hook over-blocks (see $TMP/p3.out)"
fi

# RED: same packet, same stamp, same coverage — only the predicate flips. Isolates the hook's
# re-verification from the coverage logic: if the commit still lands, the stamp was taken on trust.
sed -i.bak 's/^- p3-reversible: YES/- p3-reversible: NO/' "$REP/_ratification/SET-9001.md"
printf 'echo "tampered change"\n' >> "$REP/scripts/demo-green-plumbing.sh"
before="$( cd "$REP" && git rev-parse HEAD )"
( cd "$REP" && git add scripts/demo-green-plumbing.sh && git commit -q -m "proof RED: gate now refuses the stamp" ) >"$TMP/p4.out" 2>&1
after="$( cd "$REP" && git rev-parse HEAD )"
# Same vacuity trap as POLE 1: on an unarmed build this blocked simply because POLE 2 never stamped a
# covering packet at all. The hook's OWN re-verification message is therefore required as the cause.
if [ "$before" != "$after" ]; then
    bad "a commit landed under a standing-class stamp the gate refuses — the hook trusted the stamp"
elif ! grep -q 'claims a BUILD-CLASS pen-free close' "$TMP/p4.out"; then
    bad "the commit blocked, but NOT via the hook's standing-class re-verification — vacuous pass: the hook half is not wired"
else
    ok "pen-free stamp the gate REFUSES covers NOTHING, by the hook's own re-verification — the commit actually blocked (HEAD unmoved)"
fi

echo
if [ "$FAILS" -eq 0 ]; then echo "VERDICT: PASS — all four poles fire at the enforcers, plus the pen-routing control"; exit 0; fi
echo "VERDICT: FAIL ($FAILS pole(s) moved)"; exit 1
