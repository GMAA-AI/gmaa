#!/usr/bin/env bash
# probe_build_class_predicate_v1.sh — STANDING PROBE for the build-class predicate's OPERATIVE DATA.
#
# CONTRACT: contracts/SPEC-BUILD-CLASS-STANDING-APPROVAL.md §6 v0.4 — AC-B6 + AC-B7 (AC-B7 HEAD-frame clause BINDING)
# BUILD-CLASS PREDICATE (C-SET-AUTHORIZATION): P4 covers enforcers; the architect authors the operative
#           manifest (AC-B6 born as a PAIRING probe); probes must read OPERATIVE path-lists, NEVER a free
#           grep of prose; one operative file with eval precedence (AC-B7 refined: ALLOW/ENFORCER resolve,
#           DENY may pre-name); AC-B6's PAIRING premise is SUPERSEDED by shape (b) and DISSOLVED,
#           not relaxed: the .tsv is the SINGLE operative artifact, so AC-B6 IS operative-row parse
#           integrity — exactly what ARM A below performs. This probe is correct under the conformed AC;
#           it is the SPEC surface that was stale, not the probe.
#
# WHY THIS EXISTS, IN ONE LINE: a pairing check proves two lists agree with EACH OTHER; it cannot prove
# either agrees with the REPOSITORY. `seats.yaml` sat in both the spec and the .tsv, so a pure pairing
# check went GREEN while P4 protected a file that does not exist. AC-B7 is the cure.
#
# ARMS
#   A · OPERATIVE-ROW PARSE INTEGRITY (AC-B6, spec v0.3 name) — the parser reads ONLY operative
#       rule-tagged rows, never spec prose and never the .tsv's own comment/header lines. A path named
#       only in a comment/prose line MUST NOT appear in the parse; an operative path MUST. Proven against
#       SEEDED DECOYS, because a probe never shown a decoy is not known to ignore decoys.
#       This is the `cure-comment-re-trips` class: the live .tsv legitimately carries explanatory comments
#       naming REMOVED paths, and a free grep would convict them.
#   B · RESOLUTION (AC-B7) — every P1-ALLOW and P4-ENFORCER path must RESOLVE at HEAD, minus declared
#       same-set arrivals. P2-DENY is EXEMPT by ruling: pre-denying a not-yet-built surface is legitimate
#       and desirable (denying `scripts/cost-guard.sh` before it exists means the set that CREATES the
#       spend brake takes the operator's pen). A phantom ENFORCER protects nothing — that is the hazard.
#   C · DEGENERATE-GUARD — missing/unreadable/empty-list data must HALT, never read green.
#
# EXIT: 0 = PASS · 1 = FAIL (a named arm) · 2 = HALT (unreadable input / fail-closed)

set -u
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "probe: not in a git worktree"; exit 2; }
cd "$REPO_ROOT" || exit 2

TSV="${PREDICATE_TSV:-_index/authz-enforcers.tsv}"

# Paths landing in the SAME operator-penned set as the predicate, which therefore cannot be expected to
# resolve BEFORE that set lands (spec §6 AC-B7 "same-set exception"). Declared, never inferred.
#
# ⛔ DEFAULT IS EMPTY, AND IT MUST STAY EMPTY. The exception is scoped by the spec to "paths landing in
#    THIS set" — a PRE-LANDING condition that DISCHARGES the moment the set lands. It is supplied
#    per-run by the seat verifying a pending set (`SAME_SET_EXCEPTIONS="a b c" …`), never baked in.
#
# ⚠ WHY THIS IS NOT A STYLE CHOICE — CORRECTED on auditor `e09b4df4`-F3 (MED-HIGH).
#    This line previously hardcoded the four SET-0021 arrivals as its DEFAULT. SET-0021 landed at
#    `e09b4df4`, discharging the premise — but a hardcoded default has no expiry, no HEAD check, and
#    nothing to retire it, so ARM B would have gone on PERMANENTLY SKIPPING 3 of the 9 P4-ENFORCER
#    rows: the SPEC, the GATE and the MANIFEST — precisely the authorization model AC-B7 exists to keep
#    anchored. Proven both ways against a fixture carrying an unresolvable P4-ENFORCER row:
#      exemption NAMES the phantom  -> ARM B "skip (same-set arrival)" -> VERDICT: PASS rc=0  (BLIND)
#      exemption EMPTY              -> "FAIL — P4-ENFORCER path does not resolve at HEAD" rc=1
#    and with the real data at HEAD, empty costs NOTHING: all 9 ALLOW/ENFORCER paths resolve.
#    This is the `seats.yaml` class this probe's own header says it was built to kill — a phantom
#    ENFORCER protects nothing — reintroduced by the very mechanism that let the probe run pre-landing.
SAME_SET_EXCEPTIONS="${SAME_SET_EXCEPTIONS:-}"

FAILS=0
note() { printf '  %s\n' "$*"; }

# ---- the ONE parser. Operative rows only: whole-line comments dropped, rule column matched exactly.
# NOTE: only WHOLE-LINE comments are stripped (never `s/#.*$//`) — an inline '#' in the free-text `why`
# column would otherwise truncate a governed row and silently shrink the list it defines.
parse_rule() { # $1=rule $2=file
    grep -vE '^[[:space:]]*#' "$2" | grep -vE '^[[:space:]]*$' \
      | awk -F'\t' -v r="$1" '$1==r{print $2}' | sed -e 's/[[:space:]]*$//' -e '/^$/d'
}

# ⛔ FRAME IS BINDING: COMMITTED HEAD, NEVER THE INDEX (spec v0.4 AC-B7).
#    ⚠ CORRECTED at arming (was `git ls-files`, which reads the INDEX — not HEAD). The index is
#    transiently stage-able: `git add` of an empty phantom re-greens a path that exists in NO commit,
#    so the probe's own caption ("resolves at HEAD") was a claim the code did not make. This matters
#    here more than anywhere else in the repo: the predicate decides which sets SKIP THE OPERATOR'S
#    PEN, so an index read is a latent FALSE GREEN on the exact control that gates the pen — a phantom
#    ENFORCER protects nothing (the `seats.yaml` class this probe exists to kill), and staging one
#    would have hidden it. Every arm below reads the COMMITTED tree.
#    Red pole, proven at arming: a path `git add`ed-but-NOT-committed FAILS resolution.
resolves() { # $1 = path or glob -> 0 iff it matches at least one path COMMITTED AT HEAD
    local pat="$1" f
    case "$pat" in
        */\*\*) [ -n "$(git ls-tree -r --name-only HEAD -- "${pat%\*\*}" 2>/dev/null | head -1)" ] && return 0 ;;
        *\**)   while IFS= read -r f; do case "$f" in $pat) return 0 ;; esac; done \
                    < <(git ls-tree -r --name-only HEAD 2>/dev/null) ;;
        *)      git cat-file -e "HEAD:$pat" 2>/dev/null && return 0 ;;
    esac
    return 1
}

is_exception() { local p="$1" e; for e in $SAME_SET_EXCEPTIONS; do [ "$p" = "$e" ] && return 0; done; return 1; }

echo "== probe_build_class_predicate_v1 =="
[ -f "$TSV" ] || { echo "HALT — operative predicate data missing: $TSV"; exit 2; }
[ -r "$TSV" ] || { echo "HALT — operative predicate data unreadable: $TSV"; exit 2; }

# ------------------------------------------- ARM A — OPERATIVE-ROW PARSE INTEGRITY (AC-B6, spec v0.3)
echo "-- ARM A · operative-row parse integrity vs seeded decoys (AC-B6)"
FIX="$(mktemp -t bcpredicate.XXXXXX)" || { echo "HALT — cannot create fixture"; exit 2; }
{
    printf '# NOTE: seats.yaml was REMOVED from this predicate (cure-comment; must NOT parse).\n'
    printf '# P4-ENFORCER\tDECOY-COMMENTED-ROW.md\tdecoy\ta commented-out rule row must NOT parse\n'
    printf 'P1-ALLOW\tprobes/**\tplumbing\treal operative row\n'
    printf 'P4-ENFORCER\tagents/pre-commit-hook.sh\tenforcer\treal operative row\n'
} > "$FIX"

A_OUT="$(parse_rule P4-ENFORCER "$FIX"; parse_rule P1-ALLOW "$FIX")"
if printf '%s\n' "$A_OUT" | grep -q 'seats.yaml'; then
    note "FAIL — a path named only in a CURE-COMMENT was parsed as operative (free-grep behaviour)"; FAILS=$((FAILS+1))
elif printf '%s\n' "$A_OUT" | grep -q 'DECOY-COMMENTED-ROW'; then
    note "FAIL — a COMMENTED-OUT rule row was parsed as operative"; FAILS=$((FAILS+1))
elif ! printf '%s\n' "$A_OUT" | grep -q 'agents/pre-commit-hook.sh'; then
    note "FAIL — a REAL operative row was NOT parsed (the parser is too strict; a missed ENFORCER fails OPEN)"; FAILS=$((FAILS+1))
else
    note "PASS — decoys ignored (prose + commented row), real operative rows parsed"
fi
rm -f "$FIX"

# ---------------------------------------------------------------- ARM B — RESOLUTION (AC-B7)
echo "-- ARM B · every P1-ALLOW / P4-ENFORCER path resolves at HEAD (AC-B7; P2-DENY exempt)"
B_BAD=0
for rule in P1-ALLOW P4-ENFORCER; do
    while IFS= read -r p; do
        [ -n "$p" ] || continue
        if is_exception "$p"; then note "skip (same-set arrival)  $rule  $p"; continue; fi
        if ! resolves "$p"; then note "FAIL — $rule path does not resolve at HEAD: $p"; B_BAD=$((B_BAD+1)); fi
    done < <(parse_rule "$rule" "$TSV")
done
DENY_N="$(parse_rule P2-DENY "$TSV" | grep -c . || true)"
if [ "$B_BAD" -eq 0 ]; then
    note "PASS — all ALLOW/ENFORCER paths resolve (P2-DENY: $DENY_N rows, resolution NOT required by ruling)"
else
    FAILS=$((FAILS+B_BAD))
fi

# ---------------------------------------------------------------- ARM C — DEGENERATE GUARD
echo "-- ARM C · degenerate-list guard (an empty governed list must never read green)"
n_allow="$(parse_rule P1-ALLOW "$TSV" | grep -c . || true)"
n_enf="$(parse_rule P4-ENFORCER "$TSV" | grep -c . || true)"
if [ "$n_allow" -eq 0 ] || [ "$n_enf" -eq 0 ]; then
    note "FAIL — degenerate list (P1-ALLOW=$n_allow, P4-ENFORCER=$n_enf); an empty ENFORCER list silently stops protecting the authorization model"
    FAILS=$((FAILS+1))
else
    note "PASS — P1-ALLOW=$n_allow · P2-DENY=$DENY_N · P4-ENFORCER=$n_enf"
fi

echo
if [ "$FAILS" -eq 0 ]; then echo "VERDICT: PASS"; exit 0; fi
echo "VERDICT: FAIL ($FAILS finding(s))"; exit 1
