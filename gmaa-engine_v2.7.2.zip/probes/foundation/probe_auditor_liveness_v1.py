#!/usr/bin/env python3
"""probe_auditor_liveness_v1.py — ISSUE-V2-INTEGRATOR-TRIGGER-LIVENESS resolution-(b).
FAIL-never-warn liveness check for the post-commit auditor/integrator trigger.

RUN BY orc (§0 state-verification) AND each integrator pass — NOT by the auditor itself
(a dead auditor cannot run its own liveness check; that circularity is the whole trap).

Arm A — auditor IS firing (keys off the WORKING ledger/audit-runs.log, per architect correction):
  each recent non-[audit] commit older than ARM_A_GRACE_MIN must have an audit-runs.log block
  (its short hash referenced). Absent -> FAIL (auditor not firing).
Arm B — output is VISIBLE (keys off COMMITTED history vs the WORKING file):
  the working audit-runs.log must not reference more than ARM_B_MAX_UNCOMMITTED commits that the
  COMMITTED (HEAD) audit-runs.log does not -> i.e. audit runs are real but not being committed.
  Exceeded -> FAIL (visibility gap; this is what would have caught 2026-06-18: A green, B red).
Arm C — integration backlog: wires when the ready-signal + integrator land in Slice 0 (NOT here).

exit 0 + 'VERDICT: PASS' = both arms green. exit 1 + 'VERDICT: FAIL' = either arm red.
exit 3 + 'VERDICT: UNREADABLE' = the root is not a worktree, the ledger is missing, or git log read 0 commits.
Thresholds are starting values (architect: tunable after real tempo)."""
import subprocess, time, sys, os

# ROOT resolves from THIS FILE's own worktree. It was hard-coded to
# a fixed home-directory checkout path, which is NOT a git repo since the per-lane worktree layout: `git log` there
# returned nothing, so Arm A printed "PASS(vacuous)" on every run and Arm B read a stale ledger/ outside the
# worktree — the probe could not fail (the v1-abspath misgrounding class, ISSUE-AGENT-DEF-V1-ABSPATH-MISGROUNDING).
# AUDITOR_LIVENESS_ROOT overrides it for fixture poles only.
def _toplevel():
    here = os.path.dirname(os.path.abspath(__file__))
    r = subprocess.run(["git", "rev-parse", "--show-toplevel"], capture_output=True, text=True, cwd=here)
    return r.stdout.strip() if r.returncode == 0 else ""
ROOT = os.environ.get("AUDITOR_LIVENESS_ROOT") or _toplevel()
RUNS = os.path.join(ROOT, "ledger/audit-runs.log") if ROOT else ""

def unreadable(why):
    # FAIL-CLOSED (CLAUDE.md inv #5): an input the probe cannot read is never a PASS.
    print(f"VERDICT: UNREADABLE — {why}"); sys.exit(3)

if not ROOT or subprocess.run(["git", "rev-parse", "--git-dir"], capture_output=True, cwd=ROOT).returncode != 0:
    unreadable(f"root {ROOT or '<unresolved>'} is not a git worktree")
if not os.path.isfile(RUNS):
    unreadable(f"{RUNS} does not exist (the working audit ledger is the input of both arms)")
ARM_A_GRACE_MIN = 30      # async auditor needs time to fire
ARM_A_WINDOW = 10         # check the most recent N eligible commits
ARM_B_MAX_UNCOMMITTED = 1 # one in-flight session's appends OK; more = piling up

def sh(args):
    return subprocess.run(args, capture_output=True, text=True, cwd=ROOT).stdout

def recent_commits(n=20):
    out = sh(["git", "log", f"-{n}", "--pretty=%h|%ct|%s"])
    rows = []
    for l in out.splitlines():
        if "|" not in l: continue
        h, ct, sub = l.split("|", 2)
        rows.append((h, int(ct), sub))
    return rows

now = int(time.time())
working = open(RUNS).read() if os.path.exists(RUNS) else ""
committed = sh(["git", "show", "HEAD:ledger/audit-runs.log"]) or ""
commits = recent_commits(20)
if not commits:
    unreadable(f"git log in {ROOT} returned 0 commits (an empty read is not a quiet repo)")
fails = []

# ---- Arm A ----
eligible = [(h, ct, s) for (h, ct, s) in commits
            if not s.startswith("[audit]") and (now - ct) > ARM_A_GRACE_MIN * 60][:ARM_A_WINDOW]
missing = [(h, s) for (h, ct, s) in eligible if h not in working]
if eligible and missing:
    fails.append(f"Arm A (auditor firing): {len(missing)}/{len(eligible)} eligible commits have NO "
                 f"audit-runs.log block: " + ", ".join(h for h, _ in missing))
arm_a = "FAIL" if (eligible and missing) else ("PASS" if eligible else "PASS(vacuous: no commit >grace yet)")

# ---- Arm B ----
# commits whose audit block exists in WORKING but not in COMMITTED ledger = uncommitted audit output
lag = [(h, s) for (h, ct, s) in commits
       if not s.startswith("[audit]") and h in working and h not in committed]
if len(lag) > ARM_B_MAX_UNCOMMITTED:
    fails.append(f"Arm B (output visible): {len(lag)} audited commits in WORKING audit-runs.log are "
                 f"NOT in COMMITTED ledger (>{ARM_B_MAX_UNCOMMITTED}): " + ", ".join(h for h, _ in lag)
                 + " — auditor runs but commits are being missed; commit the [audit] backlog.")
arm_b = "FAIL" if len(lag) > ARM_B_MAX_UNCOMMITTED else "PASS"

print(f"Arm A (auditor firing)  : {arm_a}")
print(f"Arm B (output visible)  : {arm_b}  (uncommitted audited commits: {len(lag)})")
print("Arm C (integration backlog): N/A — wires with ready-signal in Slice 0")
if fails:
    for f in fails: print("  -", f)
    print("VERDICT: FAIL"); sys.exit(1)
print("VERDICT: PASS"); sys.exit(0)
