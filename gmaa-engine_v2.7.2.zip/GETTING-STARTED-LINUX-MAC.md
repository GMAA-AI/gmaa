# Getting Started: Mac and Ubuntu
**From a blank machine to a running foundation seat and a built roster. Assumes you have never used a terminal. This release supports macOS and Ubuntu; on Windows, Ubuntu runs under WSL2 and every step below is the Ubuntu one.**

The adoption has five phases (`ADOPTION-COVER.md`): the decision, your go, and the fills happen **in chat**; the folder and genesis happen **in the terminal**, and genesis is one command, after which the foundation seat builds the rest of your roster. If you **already have Claude Code installed, skip to Step 4.**

## What you need
- A Mac (macOS 13 or later) or an Ubuntu machine (20.04 or later). On Windows: open PowerShell as administrator, run `wsl --install` (it installs WSL2 with Ubuntu; if WSL is already installed, run `wsl --install -d Ubuntu` instead), restart, open **Ubuntu** from the Start menu, and follow the Ubuntu steps inside it; keep the project folder inside Ubuntu's own file system (under `~`), not under `/mnt/c`. Install and run `claude` inside the Ubuntu terminal, never from PowerShell or CMD
- A Claude account that includes Claude Code: Pro, Max, Ultra, Team, Enterprise or a Console account (the free plan does not include Claude Code) (Anthropic's setup page, code.claude.com/docs/en/setup, lists the current options); sign up at claude.ai if needed
- The release files (the engine zip and the files beside it), somewhere you can find them
- Python 3 with the `yaml` module (three shipped scripts import it: the seat-definition probe, the build-class check and the code auditor; without it the auditor runs none of its probes and says nothing). Check with `python3 -c "import yaml"`, which prints nothing when it is present; install with `python3 -m pip install pyyaml`
- jq, the command-line JSON tool (the boot check, the boot record and the stop hook read with it; without it they degrade, and the lines they print do not name jq: the boot record prints nothing). Check with `jq --version`; install with `brew install jq` on a Mac or `sudo apt install jq` on Ubuntu
- A private git remote for the spine: a private repository on GitHub or any other host, or nothing yet (Step 5 shows how to make a local one in one line)

## Step 1: Check whether Claude Code is installed
1. Open your terminal. **Ubuntu:** press **Ctrl + Alt + T** (on Windows: open **Ubuntu** from the Start menu). **Mac:** press **Cmd + Space**, type **Terminal**, press **Enter**.
2. Type `claude --version` and press **Enter**.
3. A version number of **2.1.302 or later**: you have it. **Skip to Step 4.** Older: run `claude update`, check again.
4. `command not found`: continue to Step 2.

## Step 2: Install Claude Code and the tools the engine uses
1. Paste this one line into the terminal and press **Enter**:
   ```
   curl -fsSL https://claude.ai/install.sh | bash
   ```
2. Wait for it to finish. No password should be needed.
3. **Quit the terminal completely and reopen it**, so it finds the new command.
4. `claude --version` prints a version number. If not: `claude doctor`, or see Troubleshooting.

**Also install the tools the engine runs on.** **Ubuntu:** `sudo apt install tmux git python3 python3-yaml jq openssh-client perl unzip`. **Mac:** `brew install tmux jq`, and the `yaml` module with `python3 -m pip install pyyaml` (What you need); git, python3, OpenSSH, perl and unzip come with macOS or its developer tools. If the terminal says `brew: command not found`, install Homebrew first with the one command on its home page, https://brew.sh (it asks for your Mac password), then open a new terminal. OpenSSH is needed as a **client only**, for `ssh-keygen` signing; the engine runs no ssh server and needs none. `genesis.sh check` (Step 6) confirms each tool for you, the `yaml` module and jq included.

## Step 3: Sign in once
1. Type `claude` and press **Enter**. First launch walks you through setup: pick any theme; when it asks about signing in, choose your **Claude account**, sign in in the browser, approve.
2. Type `/exit` and press **Enter**. The real launch is Step 8.

## Step 4: The project folder (Phase 3; after your "yes" in Phase 2)
1. Create the folder your project will live in, at your code root, named **lowercase, no spaces, letters, digits and hyphens only**. **Its name is your project token:** it is stamped into every seat and every seat's session is named `<token>-<lane>`, fixed for the life of the repository. **This folder is the PARENT.** The engine lives in `<folder>/foundation/`; every later seat is a sibling folder `<folder>/<lane>`.
2. Create `foundation/` inside it and unzip the engine zip **into `foundation/`** with `unzip` (not a tool that drops file modes). Everything the engine needs is in the zip. Keep the loose release files in the parent folder.
3. In the terminal, type `cd ` (c, d, one space; do not press Enter), drag the **foundation** folder onto the terminal window, press **Enter**. You are now inside `foundation/`; every command below runs from here.
4. Confirm the package is intact: `sha256sum -c MANIFEST.sha256` (Mac: `shasum -a 256 -c MANIFEST.sha256`). Every line must say OK; if one does not, stop and report it. Do this before you fill anything: the slot files change by design once filled.

## Step 5: The chat phases (Phases 1, 2 and 4)
1. **Decide (Phase 1).** Download `gmaa-decide_<version>.zip` from the same page as the engine. Open a new chat session, attach its `WHY-GMAA.md`, the canon and `ADOPTION-COVER.md` (and your project's spec if you have one), and paste the text of `00-PASTE-THIS.txt` as your message. The session proves it has read the files, names its role, and ends with adopt or do not adopt.
2. **Your go (Phase 2).** If you decide to adopt, say so explicitly. Nothing proceeds until you do. Then Step 4 above.
3. **The fills (Phase 4).** In the same session, attach `docs/FOUNDATION.md`, `docs/SEATS_skeleton.yaml`, `SLOTS.md`, `_knowledge/COORDINATION.md`, `SUBAGENTS.md`, `ENGINE-MAP.md`, `.claude/agents/general-purpose.md`, `_boot/CHARTER-foundation.md` and `docs/CHARTER_skeleton.md` from `foundation/` (the nine files the cover's Phase 4 names), and paste the cover's Phase 4 line (it is in `ADOPTION-COVER.md`, under "Phase 4: The fills"). The session settles your nine decisions with you (invariants, auth paths, who ratifies, the whole roster cut by the cover's rule, the six slot values, the project token, the apex seat, your coordination sections, the subagent roster) and returns the files.
4. **Place the files:** `FOUNDATION.md` at `foundation/docs/FOUNDATION.md` (replacing the skeleton); `COORDINATION.md` at `foundation/_knowledge/COORDINATION.md` (replacing the shipped file); `seats.yaml` and `genesis.conf` at the root of `foundation/`; each subagent definition at `foundation/.claude/agents/<name>.md`. `genesis.conf` is eight lines (`genesis.conf.example` shows the shape):
   ```
   PROJECT=<your token>
   REMOTE=<your remote url or path>
   COST_CAP_PER_UNIT_USD=1.00
   COST_CAP_PER_COHORT_USD=10.00
   PROJECT_AGENT_ALLOWLIST=general-purpose,<your other definitions by name>
   TRUNK_BRANCH=main
   SEAT_KEYS_DIR_NAME=seat-keys
   PROJECT_SKILL_NAMES=`example-skill`
   ```
   (your own values; the six slot lines above are the shipped fixtures).
5. If you have no remote yet, make a local one now, one line, from inside `foundation/`: `git init --bare ../spine.git` (it is `<parent>/spine.git`; put `REMOTE=../spine.git` in `genesis.conf`; move to a hosted private repository later if you want).

## Step 6: Genesis, Part 1 (Phase 5), one command
From inside `foundation/`: **`bash genesis.sh`**. It first verifies `MANIFEST.sha256` (only at a fresh unzip, before anything is filled; it prints `package intact` and keeps a timestamp of that check), then runs six steps in order and stops with a named reason at the first thing that is wrong; after you fix it, run the same command again and it continues from where it stopped.
1. **fill**: every slot from `genesis.conf`, in every file that carries it.
2. **check**: prints `READY` or exactly what is missing.
3. **seed**: stamps foundation, seeds the records, `git init` on `main`, the genesis commit, the push; it ends with `BOOT-RECORD: PASS 11 of 11` and `STATE: PRE-GENESIS` (expected; the cover says what it means).
4. **enroll foundation**: makes foundation's key on this machine and records it; it ends with `confirm-lanes CONFIRMED`.
5. **hooks**: installs the five git hook files and makes the first signed commit; it ends with `verify-commit PASS` and the boot record.
6. **launch**: foundation's seat opens in tmux as `<token>-foundation` in this window. **Read the header before you type:** it must show the seat (`@orc`), and the boot check must print `BOOT-RECORD: PASS`. The first turn is also asked to print `BOOT-ACK: lane=foundation ...`; a model may leave that line out, and its absence alone is not a failed launch. If you ran the command from inside a Claude Code session instead of a terminal, the seat launches in the background and the command prints the two lines to follow: `/exit` that session, then `tmux attach -t =<token>-foundation` (the terminal is the measured way; the background path is run in the release's walkthrough with a stand-in for `claude`).

**If it halts.** The six steps are also commands you can run by name, and each does only what is still undone: `bash genesis.sh check`, `bash genesis.sh fill <SLOT> <value>`, `bash genesis.sh seed <token> <remote>` (runs once), `bash genesis.sh enroll foundation`, `bash genesis.sh hooks` (`hooks --no-launch` to stop before the launch), `./launch-orc.sh`. `bash genesis.sh explain` lists every file each one writes.

## Step 7: What you will see (normal)

**If the seat's window is not yours** (the launch ran detached, or you closed the terminal): `tmux attach -t =<token>-foundation`, the line the launch printed. `tmux ls` lists every seat's session as `<token>-<lane>`.

**The seat's mode and its prompts.** A seat runs in the mode the shipped `.claude/settings.json` governs (the launcher's default); it stops and asks before any command the settings do not allow. Answer those prompts yourself, at the keyboard, one at a time; do not run a seat in a mode that answers them for you, and never let another agent answer them. Where a prompt offers to allow a command once or from now on, choose once: a standing allow widens what the seat may do without asking, which is a change to its authority to make deliberately, not at a prompt. Two steps are yours, from an ordinary terminal and never from inside a seat: `bash scripts/seat-stop.sh <seat>` stops a seat (it refuses to run from inside one), and `bash scripts/seat-keys.sh adopt-candidate`, run in a lane's folder, judges a sync candidate for that lane.
- Two tracked files modified after `hooks`: `ledger/audit-findings.md` and `ledger/audit-runs.log`. The auditor wrote them; foundation commits them at its first turn.
- Probe lines in the boot record on a fresh tree: `governance-index-drift FAIL` (two arms: the readiness probe is yours to supply, `SLOTS.md` section 3; the other arm reads a fixture the engine does not ship, a declared residue cured in 2.8, so the line stays FAIL on this release) and `application UNREADABLE` (no criteria files yet), plus UNREADABLE lines while the repository has fewer than ten commits or no live seat. None blocks the launch.
- `STALE-BOOT: ...` whenever commits land after the absorb marker: re-stamp `absorbed_through_sha` in `CHECKLIST.md`; foundation does this after absorbing.
- `INBOXF-CHECK: ... 1 unresolved`: the cross-project folder (`XP_DIR`). With one project this line is expected and stays; the folder is used only when a second project exchanges files with this one.
- Twenty `.sh` files are not executable after unzip, by design (libraries and hook sources); every command here runs them with `bash`.

## Step 8: Genesis, Part 2: foundation builds the roster, then the proof (do not skip)
1. **Charters first.** Every seat boots reading `_boot/CHARTER-<lane>.md`, written by your chat architect (the Phase 4 session) from that lane's boundary line in `seats.yaml`, never generated. Ask the session for each code seat's charter, the executor's included, and save it into `foundation/_boot/`.
2. **One set per lane.** In foundation's session, for each code seat in `seats.yaml` other than foundation (the chat architect has no worktree, and `lane` refuses it by name): `bash genesis.sh lane <lane>`. It creates the lane's worktree beside `foundation/`, stages the charter you saved, writes its stamp, its inbox folder on the spine, its provisioning row and its key record, commits them with the charter on `main` as foundation's one signed set and pushes (your go to run it is the word; there is no separate ratify line), then binds the lane's key in its worktree and commits the lane's stamp there with the lane's own key. For the executor (`spine_write: apply-receipts-only`, a class that cannot commit its own stamp) the last part differs: foundation signs a sync candidate carrying the executor's stamp and the executor's key adopts it, so you see `adopt-candidate PASS` where a lane shows its stamp commit. It refuses a lane whose charter is missing, a lane already provisioned, and any folder but foundation's.
3. **Launch the lane** with `./launch-orc.sh` from inside its folder (session `<token>-<lane>`); its first turn prints `INBOX-CHECK: <lane> ...`. `bash genesis.sh hooks` in `foundation/`, at any time, prints the confirmation of every lane.
4. **The proof** (canon §12 step 8): plant a deliberate conflict and the machinery must detect, name, hold and recover it. **A clean run proves nothing.** Run the two shipped poles first (`bash probes/set-gate/probe_footprint_coverage_flip.sh`, `bash probes/set-gate/probe_semantic_hunt_flip.sh`), then your own fault in your own flow. The fault is set-level (a member of a pending set, not a lone edit); it is planted by the chat architect or by you, never by foundation; you write its description (the set, the faulty member, the fault) in a file kept outside every seat's tree, and before the set is minted only that file's sha256 goes into `docs/FIELD-EVIDENCE.md`, with no set id and no member's hash; you show the file once foundation has presented its packet; and it ends at the packet: caught means the judging machinery names the faulty member before the pen is presented and nothing faulty lands. Record what was seeded and whether it was caught in `docs/FIELD-EVIDENCE.md`, which you make once by copying `docs/FIELD-EVIDENCE_skeleton.md` to that name and answering its fill prompts before you plant.

5. **Prove the subagents load:** in foundation's session, one spawn per definition with a no-op task; `SUBAGENTS.md` says what to read.

**Genesis is complete when every seat in `seats.yaml` exists, every code seat is confirmed, every subagent definition has loaded once, and the seeded fault was caught.** Then `FIRST-SET.md`.

## Adding a seat later
A new seat is an architect ruling. Edit `seats.yaml` first (the new seat with `spine_write: DENY`; only the executor carries `apply-receipts-only`, its operator, its boundary, `apex: false`), get its charter from your chat architect into `_boot/`, then Step 8.2 and 8.3 for that one lane. The registry is derived from `seats.yaml` and never edited alone.

## Upgrading (later)
Each engine release is a whole package; `CHANGELOG.md` names what changed. In your project an engine update reaches `main` inside a set your apex ratifier ratifies (`docs/ENGINE-UPDATE.md`).

## Feedback
Send what made you or the session guess, your step-8 result, and any incident to arch@gmaa.ai (`ADOPTION-COVER.md`, "Feedback").

## Troubleshooting
- **`command not found` after installing:** you did not reopen the terminal (Step 2.3). Or run `claude doctor`.
- **`GENESIS: HALT run this from inside the unzipped package folder`:** you are not in `foundation/`. Step 4.3.
- **`GENESIS: HALT this folder is named '...'`:** the engine must be unzipped into a folder named `foundation`. Step 4.2.
- **`genesis.sh` stops at NOT READY:** every line above it names one thing to fix; fix it and run `check` again.
- **`GENESIS: HALT no _boot/CHARTER-<lane>.md`:** the lane's charter is not in place (Step 8.1). **`GENESIS: HALT <lane> already has a row`:** the lane is provisioned; `bash genesis.sh hooks` prints its confirmation.
- **`keygen refused` or a key-directory error at enroll:** the `SEAT_KEYS_DIR_NAME` line is missing from `genesis.conf` (Step 5.4), or the directory is inside a git worktree; keys live outside every worktree.
- **`push to origin failed` at seed:** the remote does not exist or you cannot write to it. Fix it, then `git push -u origin main`. The engine reads the spine at `origin/main` and the remote must be named `origin`.
- **The boot check prints `UNREADABLE ... Fetch, then re-run`:** no remote, or not pushed. As above, then `git fetch origin`.
- **`permission denied` running the launcher:** the files lost their modes when unzipped. Unzip again with `unzip` (Step 4.2).
- **`HALT: no session created: ...` on launch:** the folder is not a stood-up lane yet (`C7(a): project key absent`), or the pre-commit hook is not installed. Finish Step 6; the text after the colon names what is missing.
- **`HALT: tmux session 'foundation' already exists`** (or `'<token>-foundation'`): a session by that name is already running on this machine. `tmux ls` lists them. If it is your seat, attach to it: `tmux attach -t =<token>-foundation`. If it is a plain `foundation` from something else (an older engine, a session made by hand), rename or end it (`tmux kill-session -t =foundation`) and launch again. The engine never names a session plain `foundation`.
- **The session is running but you have no window:** `tmux attach -t =<token>-foundation`. Every seat's session is `<token>-<lane>`.
- **Install seems blocked:** on company-managed Macs, security policy may interfere. Ask IT, or see the official docs.
- Official install docs: https://code.claude.com/docs/en/setup
