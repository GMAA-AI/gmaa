# SLOTS.md: what an adopter fills, and where

This file explains every place you fill to instantiate the engine for your project. It has two kinds of entry. A **slot** is a token in a shipped engine file, written as the slot's name inside double curly braces, and replaced in place. This file names slots without the braces, so filling the engine never rewrites this inventory. A **fill** is a file or record you create; nothing ships in its place. The machine record of the slots is `_index/adopter-slots.tsv`; this file and that table name the same slots, and a release is checked for it.

## 1 · Slots (tokens in shipped files)

`_index/adopter-slots.tsv` has one row per slot: `path · slot · anchor · origin_value · fixture_value · note`. The **anchor** is the literal text just before the token, so a fill can only land in one place. **origin_value** ships empty in every row: the engine's own values are not part of the package. **fixture_value** is a worked example, used by the engine's own boot test; it is not a recommendation.

| slot | file | what you fill | shipped fixture |
|---|---|---|---|
| `COST_CAP_PER_UNIT_USD` | `contracts/COST-CAPS.md` (`per_unit_usd:`) | your spend cap per unit of work, in USD | `1.00` |
| `COST_CAP_PER_COHORT_USD` | `contracts/COST-CAPS.md` (`per_cohort_usd:`) | your spend cap per cohort of units, in USD; not below the per-unit cap | `10.00` |
| `PROJECT_AGENT_ALLOWLIST` | `.claude/agents/orc.md` (the `Agent(...)` tool list) | the whole list of subagent types your orchestrator seat may spawn | `general-purpose` |
| `TRUNK_BRANCH` | `scripts/resolve-lane.sh` (the trunk comparison) and `scripts/spine-ref.sh` (the trunk ref): one slot, two anchors, the same value in both | your trunk branch name: the one branch the integrator seat writes (`main` in the cover's topology) | `trunk` |
| `SEAT_KEYS_DIR_NAME` | `scripts/seat-keys.sh` (the default key directory under `$HOME/.config`) | the name of your per-user seat-key directory; fill it before the first `seat-keys.sh keygen` | `seat-keys` |
| `PROJECT_SKILL_NAMES` | `_boot/CHARTER-foundation.md` (the skills line) | the project skills the foundation seat loads on demand, as a slash-separated list of backticked names | `example-skill` |

Fill every slot before genesis: `bash genesis.sh fill <SLOT> <value>` replaces the token in every file that carries it, and `bash genesis.sh check` lists what is still unfilled; `seed` refuses to run while any slot is open. A tree with a slot still unfilled is outside what the package promises: not every engine path that reads a slot checks it, and a slot inside a shell default parses differently until it is filled.

## 2 · Fills (files and records you create)

| fill | where | what it is | created |
|---|---|---|---|
| `docs/FOUNDATION.md` | ships as a skeleton | your invariants, auth paths, apex ratifier, substrate, and the loop ceilings line (canon §12 steps 1, 2, 7) | Phase 3 of `ADOPTION-COVER.md` |
| `seats.yaml` | repo root | your seat roster, the architect's instrument (canon §2, §7); start from `docs/SEATS_skeleton.yaml`. `genesis.sh` is the one shipped file that reads it | Phase 3; public keys, `login` and `host` by `genesis.sh enroll` in Phase 4 |
| the seat-key registry | `_orchestration/seat-keys.tsv` (`lane · branch · operator · public key · login · host · apex`) and `_orchestration/seat-keys-revoked.txt` | derived whole from `seats.yaml` by `bash genesis.sh enroll <lane>`, and changed only by changing `seats.yaml` first and running `enroll` again: one row per seat that has a key, committed one row per commit, exactly one `apex` row; the revocation list is empty at genesis | Phase 4 (`bash genesis.sh enroll`) |
| the declared engine paths | the `fill` rows of `_index/engine-paths.tsv` | the files and directories `bash genesis.sh seed` creates empty (the set ledger with its two section headers); the `written` rows are created by the shipped scripts and never seeded by hand | Phase 4 (`bash genesis.sh seed`) |
| your substrate rows | `_index/substrates.tsv` | one row per substrate your sets may write: `alias`, `canonical`, `scope`, `note`, tab-separated; `scope` is the literal `origin` for your rows (`engine` marks the shipped rows); `note` is `-` when empty. `scripts/ratify.sh assemble` reads it and exits 3 on any other shape | Phase 4, at genesis |
| foundation's state-source map | `_boot/CHARTER-foundation.md` (the state-source map line) | the sources foundation reads at boot; every declared source must exist, or the boot halts by name. `genesis.sh seed` seeds its four log sources empty and removes the one entry nothing creates | Phase 4 (`bash genesis.sh seed`) |
| your usage reader | `scripts/cost-usage-reader.sh`, or any path you set in `COST_USAGE_READER` | the read of your own usage ledger. `scripts/cost-guard.sh check` runs it before each metered call, with the parsed inputs in its environment. It prints one row `COSTGUARD_ROW unit <id> <calls> <usd>`, plus `COSTGUARD_ROW cohort 0 <calls> <usd>` when a cohort is given, with cache tokens priced. Until it exists, `scripts/cost-guard.sh` exits 3 and prints UNREADABLE by name, never a pass (`contracts/C-SET-AUTHORIZATION.md` §2.4) | before your first metered call |

No registry row ships, and the engine refuses to arm its hooks until every writing seat has exactly one.

## 3 · Layer slots
| slot | where | what you do | shipped as |
|---|---|---|---|
| WORK-project rule pack | `_index/layers.tsv` rows with layer `W-project`, and the contract files they name | write your project's own work rules, without touching a STRUCTURE (`S`) file | empty: the package carries no project rule |
| your readiness checklist | `contracts/READINESS.md` §3 | supply the checklist, the probe that walks it, and the gate that calls the probe; every check needs a red pole against the served artifact | the generic rule only |

The engine refuses to run with an empty scanner roster; the shipped WORK-generic pack satisfies it. If you strip WORK-generic, supply at least one scanner rule.

## 4 · The slot-contract rule
Any change to a slot's name, file, anchor or meaning is listed in `CHANGELOG.md` under a heading named exactly `Slot-contract changes`, stating the old and new contract. A release with no such heading is a promise that every existing fill keeps working unchanged.
