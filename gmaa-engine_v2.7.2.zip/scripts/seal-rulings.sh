#!/usr/bin/env bash
# scripts/seal-rulings.sh — 0397 §3 member 3: mechanize the existing seal form.
#
# Reference generator: .tmp/seal-ruling.py (human-driven: NNNN/ARCH-NNN/title/slug/ordinal all typed by
# the sealing seat). This script derives every one of those fields mechanically from the outbox filename
# and the existing _rulings/ corpus — "a machine-generated subject is the proof the mechanism ran" (0397 §3).
#
# WHAT IT DOES, per run:
#   1. lists origin/architect:_orchestration/relay-outbox/architect/ (REF overridable via SEAL_RULINGS_REF,
#      the fail-closed test pole's hook — mirrors SURFACE_SPINE_REF in surface-conformance-spine.sh);
#   2. a file is SEALABLE iff its name matches <date>-<ordinal>-<FORM>-ARCH-<num>-<rest>.md AND <FORM> is a
#      token that ALREADY appears (as a whole token, never typed in here) in an existing _rulings/ filename
#      at the same position (immediately after ARCH-<num>-) — the vocabulary is read, not hand-maintained —
#      MINUS every token containing HANDOFF (0397 §3 control: a HANDOFF-slug file is never sealed; the 22
#      historical handoff seals 0182…0343 are history, not form);
#   3. a sealable file is SKIPPED if its raw-bytes sha256 already equals some existing ruling's recorded
#      content-half sha256 (already sealed, under any number), or if its basename has a row in
#      _index/seal-dispositions.tsv (disposed another way; missing table = UNREADABLE, exit 3);
#   3a. a file whose ARCH number is already sealed is HELD (SEAL-HOLD line), never sealed and never silently
#      skipped: a revision may be sealable (a later-numbered resubmission of a withdrawn proposal) or
#      refused (a proposal number whose first cut was never adopted); the hub decides;
#   4. new files are numbered sequentially from the _rulings/ high-water, oldest <date>-<ordinal> first;
#   5. the masthead is written mechanically (source blob, content-half sha256, FORM from the slug — never
#      hardcoded "RULED" the way the reference generator does); the body is copied VERBATIM, byte-identical;
#   6. a sealed file whose body names the GMAA architect / package leg (README.md's own ferry rule) is
#      ferried — in --commit mode, a verbatim copy + spine path + sha256 + spine sha lands in the XP DMZ; in --dry-run
#      (the default, and what every pole here uses) this is PRINTED, never written, since the XP DMZ is
#      outside this repo and outside what a dry run may touch;
#   7. ONE commit per run (--commit only; --dry-run NEVER commits, and this script never commits in a
#      sandboxed/replica checkout unless the caller explicitly runs --commit there) with a fixed subject
#      shape naming every sealed number + its source blob + content-half sha256.
#
#   R1 (names): every path the run will create (the _rulings/ file and, when the ferry fires, the DMZ file) is
#      composed and its basename checked against the host's NAME_MAX, read from the host, BEFORE the first write.
#      A violation HALTs (`SEAL-RULINGS: HALT name-too-long ...`, exit 4) with nothing written anywhere; a name is
#      never truncated or substituted (the DMZ name is the ruling's identity in a flat directory).
#   R2 (census): the sealed census (existing files, content-half sha256 set, high-water, FORM vocabulary, sealed
#      ARCH numbers) is read from the COMMITTED corpus at the spine ref (git ls-tree + cat-file), never from the work
#      tree. A ruling file under the corpus directory that is untracked, or whose work-tree bytes differ from the spine ref, HALTs the run
#      (`SEAL-RULINGS: HALT dirty-corpus <path> ...`, exit 4): it is never read as sealed and never silently skipped.
#
# Usage: seal-rulings.sh [--dry-run|--commit] [--ref <git-ref>] [--spine-ref <git-ref>]
#   --spine-ref the ref whose committed _rulings/ is the sealed census (default HEAD; SEAL_RULINGS_SPINE_REF overrides).
#   --dry-run   (DEFAULT) print what would seal; write NOTHING, commit NOTHING.
#   --commit    write the sealed _rulings/*.md files, ferry to the DMZ, and commit ONCE (`--only` the sealed
#               paths). Runs only where resolve-lane.sh reports spine_write=ALLOW (else SKIP, exit 0). Called by
#               scripts/seat-b6-stop.sh at the restart boundary, right after audit-seal.sh.
set -uo pipefail
cd "$(git rev-parse --show-toplevel)" || exit 9

MODE="dry-run"
REF="${SEAL_RULINGS_REF:-origin/architect}"
SPINE_REF="${SEAL_RULINGS_SPINE_REF:-HEAD}"
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) MODE="dry-run"; shift ;;
    --commit) MODE="commit"; shift ;;
    --ref) REF="${2:?--ref needs a value}"; shift 2 ;;
    --spine-ref) SPINE_REF="${2:?--spine-ref needs a value}"; shift 2 ;;
    *) echo "usage: $0 [--dry-run|--commit] [--ref <git-ref>] [--spine-ref <git-ref>]" >&2; exit 2 ;;
  esac
done

# --commit writes the spine: only the spine writer may run it (seat-b6-stop.sh calls this in EVERY lane).
if [ "$MODE" = "commit" ]; then
  SW="$(bash scripts/resolve-lane.sh 2>/dev/null | command grep -oE 'spine_write=[A-Z]+' | head -1)"
  [ "$SW" = "spine_write=ALLOW" ] || { echo "SEAL-RULINGS: SKIP-NOT-SPINE-WRITER (${SW:-spine_write unresolved}); --commit runs only in the hub"; exit 0; }
fi

git rev-parse -q --verify "${REF}" >/dev/null 2>&1 || { echo "SEAL-RULINGS: UNREADABLE — ref '${REF}' cannot be resolved"; exit 3; }

git rev-parse -q --verify "${SPINE_REF}" >/dev/null 2>&1 || { echo "SEAL-RULINGS: UNREADABLE — spine ref '${SPINE_REF}' cannot be resolved"; exit 3; }

PLAN="$(mktemp "${TMPDIR:-/tmp}/seal-plan.XXXXXX")" || { echo "SEAL-RULINGS: UNREADABLE — mktemp failed"; exit 3; }
trap 'rm -f "$PLAN"' EXIT

python3 - "$REF" "$MODE" "$SPINE_REF" <<'PYEOF' > "$PLAN"
import sys, re, subprocess, hashlib, os

REF, MODE, SPINE_REF = sys.argv[1], sys.argv[2], sys.argv[3]

def git(*args):
    return subprocess.run(["git", *args], capture_output=True, check=True).stdout

def git_ok(*args):
    p = subprocess.run(["git", *args], capture_output=True)
    return p.returncode == 0, p.stdout, p.stderr

# ── 0. dirty-corpus guard (R2): the work tree must agree with the committed corpus at the spine ref ────
# `-z` keeps odd names unquoted. Entries are the direct children of _rulings/ only.
committed = [p for p in git("ls-tree", "-r", "-z", "--name-only", SPINE_REF, "--", "_rulings/")
             .decode("utf-8", "replace").split("\0")
             if p and p.count("/") == 1]
committed_md = [p for p in committed if p.endswith(".md")]

def read_blobs(paths):
    """Bodies of SPINE_REF:<path> for every path, one `git cat-file --batch` process."""
    out = {}
    if not paths:
        return out
    req = "".join(f"{SPINE_REF}:{p}\n" for p in paths).encode()
    raw = subprocess.run(["git", "cat-file", "--batch"], input=req, capture_output=True, check=True).stdout
    pos = 0
    for p in paths:
        nl = raw.index(b"\n", pos)
        hdr = raw[pos:nl].split()
        if len(hdr) != 3 or hdr[1] != b"blob":
            raise RuntimeError(f"cat-file: {SPINE_REF}:{p} -> {raw[pos:nl]!r}")
        size = int(hdr[2])
        out[p] = raw[nl + 1:nl + 1 + size]
        pos = nl + 1 + size + 1
    return out

blobs = read_blobs(committed_md)
dirty = []
cset = set(committed_md)
for fn in sorted(os.listdir("_rulings")):
    rel = "_rulings/" + fn
    if not fn.endswith(".md") or not os.path.isfile(rel):
        continue
    if rel not in cset:
        dirty.append((rel, "untracked"))
    elif open(rel, "rb").read() != blobs[rel]:
        dirty.append((rel, "modified"))
for rel in committed_md:
    if not os.path.isfile(rel):
        dirty.append((rel, "modified"))
if dirty:
    for rel, why in dirty:
        print(f"SEAL-RULINGS: HALT dirty-corpus {rel} ({why}; a prior partial run or a hand edit — resolve it, nothing is read as sealed)")
    print(f"SEAL-RULINGS: HALT dirty-corpus census: {len(dirty)} of {len(committed_md)} committed ruling files (+ untracked) disagree with {SPINE_REF}")
    sys.exit(4)

# ── 1. existing _rulings/ corpus, read from the COMMITTED tree at SPINE_REF (R2) ─────────────────────
existing = sorted(os.path.basename(p) for p in committed_md if re.match(r'^\d{4}-.*\.md$', os.path.basename(p)))
highwater = 0
existing_hashes = set()
vocab = set()
sealed_arch = {}   # ARCH number -> [ruling numbers]
FORM_RE = re.compile(r'^\d{4}-ARCH-\d+-((?:[A-Z][A-Z0-9]*-)*[A-Z][A-Z0-9]*)-')
for fn in existing:
    num = int(fn[:4])
    highwater = max(highwater, num)
    body = blobs["_rulings/" + fn].decode("utf-8", errors="replace")
    m = re.search(r'Content-half `sha256`:\*\*\s*`([0-9a-f]+)`', body)
    if m:
        existing_hashes.add(m.group(1))
    fm = FORM_RE.match(fn)
    if fm:
        vocab.add(fm.group(1))
    am = re.match(r'^\d{4}-ARCH-(\d+)-', fn)
    if am:
        sealed_arch.setdefault(am.group(1), []).append(fn[:4])

# 0397 §3 control: "a HANDOFF-slug file is never sealed" (the decision-log record of this cure). The
# historical handoff seals (0182 … 0343) stay history; their form tokens are removed from the vocabulary.
vocab = {v for v in vocab if "HANDOFF" not in v}

# Recorded dispositions (_index/seal-dispositions.tsv: source-basename <TAB> disposition <TAB> ref):
# a source the hub already disposed of another way (refused, annotated on another ruling's masthead).
dispositions = {}
try:
    for line in open("_index/seal-dispositions.tsv", encoding="utf-8"):
        if line.startswith("#") or not line.strip():
            continue
        f = line.rstrip("\n").split("\t")
        if len(f) >= 3:
            dispositions[f[0]] = (f[1], f[2])
except FileNotFoundError:
    print("SEAL-RULINGS: UNREADABLE — _index/seal-dispositions.tsv missing")
    sys.exit(3)

# ── 2. list the outbox at REF ───────────────────────────────────────────────────────────────────────
OUTBOX = "_orchestration/relay-outbox/architect"
ls = git("ls-tree", "-r", "--name-only", REF, "--", OUTBOX).decode("utf-8", "replace").splitlines()

CAND_RE = re.compile(r'^(\d{4}-\d{2}-\d{2})-(\d+)-(.+?)-ARCH-(\d+)-(.+)\.md$')

candidates = []   # (date, ordinal, form, archnum, rest, path)
skipped_no_pattern = 0
skipped_no_form = 0
for path in ls:
    base = os.path.basename(path)
    m = CAND_RE.match(base)
    if not m:
        skipped_no_pattern += 1
        continue
    date, ordinal, form, archnum, rest = m.groups()
    if form not in vocab:
        skipped_no_form += 1
        continue
    candidates.append((date, int(ordinal), form, archnum, rest, path))

candidates.sort(key=lambda c: (c[0], c[1]))

# ── 3. filter already-sealed by content-half sha256 ────────────────────────────────────────────────
to_seal = []
holds = []
already = 0
disposed = 0
tip = git("rev-parse", REF).decode().strip()
for date, ordinal, form, archnum, rest, path in candidates:
    blob = git("rev-parse", f"{REF}:{path}").decode().strip()
    body = git("cat-file", "blob", blob)
    sha = hashlib.sha256(body).hexdigest()
    if sha in existing_hashes:
        already += 1
        continue
    base = os.path.basename(path)
    if base in dispositions:
        disposed += 1
        continue
    # Same ARCH number already sealed: a revision (two real cases this covers: a later-ordinal cut of a
    # proposal that was itself sealed, and a withdrawn/refused cut followed by a later-ordinal re-issue).
    # Content sha cannot tell these apart, so the script never decides: it HOLDS the file for the hub,
    # which seals by hand or records a disposition row.
    if archnum in sealed_arch:
        holds.append((path, archnum, sealed_arch[archnum], sha))
        continue
    to_seal.append({"date": date, "ordinal": ordinal, "form": form, "archnum": archnum, "rest": rest,
                     "path": path, "blob": blob, "sha": sha, "body": body})

# ── 4. allocate numbers, write masthead, detect DMZ ferry ───────────────────────────────────────────
GMAA_RE = re.compile(r'gmaa-architect|package leg', re.I)
plan_rows = []
num = highwater
for c in to_seal:
    num += 1
    nnnn = f"{num:04d}"
    prev = f"{num-1:04d}"
    title = c["rest"].replace("-", " ")
    out_slug = f"ARCH-{c['archnum']}-{c['form']}-{c['rest']}"
    out_path = f"_rulings/{nnnn}-{out_slug}.md"
    masthead = (
        f"# _rulings/{nnnn} — ARCH-{c['archnum']} · {c['form']} — {title}\n\n"
        f"**Ruling number:** {nnnn} (mechanical allocation from the high-water at seal time: `{prev}`).\n"
        f"**Authored by:** architect (code-resident, HOW-class adjudicator), proposed **ARCH-{c['archnum']}**, {c['date']}.\n"
        f"**Sealed by:** scripts/seal-rulings.sh (mechanized; 0397 §3 member 3) — **FORM only, never content.**\n"
        f"**Form determination:** **{c['form']}** (derived mechanically from the source slug, not re-judged).\n"
        f"**Source (reaped cross-branch, byte-verified):** `{REF}` git-blob `{c['blob']}` ({len(c['body'])} B; `{REF}` tip `{tip[:8]}` at reap) →\n"
        f"`{c['path']}`\n"
        f"**Content-half `sha256`:** `{c['sha']}` — equal to the source blob at seal time (frame: `sha256` of the raw bytes below the rule; offset = **separator line + 2** — `---` then one blank line).\n\n"
        f"> WARNING: EVERYTHING BELOW THE RULE IS THE ARCHITECT'S VERBATIM SOURCE. Foundation added the\n"
        f"> masthead above and NOTHING else — no digest, no re-framing, no elision.\n"
        f"---\n\n"
    )
    ferry = bool(GMAA_RE.search(c["body"].decode("utf-8", "replace")))
    row = {"nnnn": nnnn, "out_path": out_path, "masthead": masthead, "cand": c, "ferry": ferry, "xp_dest": None}
    plan_rows.append(row)

# ── 4b. compose every output path and validate every basename BEFORE any write (R1) ─────────────────
prog = ""
if any(r["ferry"] for r in plan_rows):
    if os.path.isfile("_boot/BOOTSTRAP.md"):
        for bl in open("_boot/BOOTSTRAP.md", encoding="utf-8"):
            bm = re.match(r"project:\s*(\S+)\s*$", bl)
            if bm:
                prog = bm.group(1)
                break
    if not prog:
        sys.stderr.write("SEAL-RULINGS: UNREADABLE - no project: stamp in _boot/BOOTSTRAP.md (the ferry name carries it)\n")
        sys.exit(3)

def name_max(path):
    """The host's NAME_MAX for the directory that will hold `path` (nearest existing ancestor)."""
    d = os.path.dirname(os.path.abspath(path))
    while not os.path.isdir(d):
        d = os.path.dirname(d)
    return os.pathconf(d, "PC_NAME_MAX")

too_long = []
checked = 0
for row in plan_rows:
    c = row["cand"]
    if row["ferry"]:
        row["xp_dest"] = os.path.join(os.path.expanduser("~"), "Code", "xp", f"XP-GMAA-PROV-{c['date']}_{prog}-architect-to-gmaa_{row['nnnn']}-{c['archnum']}-{c['form']}-{c['rest']}.md")
    for path in [row["out_path"]] + ([row["xp_dest"]] if row["ferry"] else []):
        checked += 1
        n = len(os.path.basename(path).encode("utf-8"))
        lim = name_max(path)
        if n > lim:
            too_long.append((path, n, lim))
if too_long:
    for path, n, lim in too_long:
        print(f"SEAL-RULINGS: HALT name-too-long {path} {n} B > {lim} B (shorten the source slug by {n - lim} B)")
    print(f"SEAL-RULINGS: HALT name-too-long census: {len(too_long)} of {checked} output names over the host limit; 0 files written")
    sys.exit(4)

# ── 5. emit the plan (bash reads this; MODE=dry-run never writes a byte) ───────────────────────────
print(f"SEAL-RULINGS: ref={REF} tip={tip[:8]} outbox_files={len(ls)} no_pattern={skipped_no_pattern} "
      f"no_form_match={skipped_no_form} already_sealed={already} disposed={disposed} held={len(holds)} "
      f"vocab={','.join(sorted(vocab))}")
for path, archnum, nums, sha in holds:
    print(f"SEAL-HOLD: {path} ARCH-{archnum} already sealed as _rulings/{','.join(nums)} sha256={sha[:8]} "
          f"— hub decides (seal by hand, or add a _index/seal-dispositions.tsv row)")
if not plan_rows:
    print("SEAL-RULINGS: 0 new (idempotent)")
else:
    for row in plan_rows:
        c = row["cand"]
        print(f"SEAL-PLAN: {row['nnnn']} <- {c['path']} blob={c['blob'][:8]} sha256={c['sha'][:8]} "
              f"form={c['form']} ferry={'yes' if row['ferry'] else 'no'} out={row['out_path']}")
        if MODE == "commit":
            with open(row["out_path"], "wb") as f:
                f.write(row["masthead"].encode() + c["body"])
        if row["ferry"]:
            xp_dest = row["xp_dest"]
            if MODE == "commit":
                os.makedirs(os.path.dirname(xp_dest), exist_ok=True)
                with open(xp_dest, "wb") as f:
                    f.write((f"Spine path: {row['out_path']}\nsha256: {c['sha']}\nSpine sha at ferry: {tip}\n\n").encode() + c["body"])
                print(f"SEAL-FERRY: wrote {xp_dest}")
            else:
                print(f"SEAL-FERRY (dry-run, NOT written): would write {xp_dest}")
    nums = ",".join(r["nnnn"] for r in plan_rows)
    shas = ",".join(r["cand"]["sha"][:8] for r in plan_rows)
    nferry = sum(1 for r in plan_rows if r["ferry"])
    subject = (f"foundation-auto: seal-rulings.sh sealed _rulings/{nums} from {REF} tip {tip[:8]} "
               f"(FORM only, 0397 s3 member 3; DISC-A-NUMBER-CARRIES-ITS-FRAME: content-half sha256 "
               f"{shas}, raw bytes below the rule at separator+2); {nferry} ferried to DMZ")
    print(f"SEAL-COMMIT-SUBJECT: {subject}")
    if MODE == "commit":
        with open(".seal-rulings-commit-msg.tmp", "w") as f:
            f.write(subject + "\n")
PYEOF
PY_RC=$?
cat "$PLAN"
if [ $PY_RC -eq 4 ]; then exit 4; fi   # a named HALT (name-too-long | dirty-corpus) already printed above; nothing was written
if [ $PY_RC -ne 0 ]; then echo "SEAL-RULINGS: UNREADABLE — python3 plan step exited ${PY_RC}"; exit 3; fi

if [ "$MODE" = "commit" ]; then
  NEW_FILES="$(command grep -E '^SEAL-PLAN: ' "$PLAN" | sed -E 's/^SEAL-PLAN: [0-9]{4} <- .* out=//')"
  if [ -n "$NEW_FILES" ]; then
    # shellcheck disable=SC2086
    git add -- $NEW_FILES
    # --only: commit exactly the sealed files, never whatever else the hub has staged at the boundary.
    # shellcheck disable=SC2086
    git commit --only -F .seal-rulings-commit-msg.tmp -- $NEW_FILES
    RC=$?
    rm -f .seal-rulings-commit-msg.tmp
    exit $RC
  fi
fi
exit 0
