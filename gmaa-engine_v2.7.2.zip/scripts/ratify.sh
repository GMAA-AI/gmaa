#!/usr/bin/env bash
# scripts/ratify.sh — set-level authorization: assemble / assess / ratify.
# Canon §4 (apply-boundary set-evaluation) + §10 (agent assesses, independent human ratifies);
# schema = contracts/C-RATIFICATION-PACKET.md. Foundation-only (resolver-gated).
#
#   assemble [SET-NNNN] [--requirement-id REQ-<id>] --cures <ids>|none   (--cures required)
#                         --requirement-id: pool = that requirement's pending rows + rows
#                         evaluated into its minted set; without it, the whole-ledger read below is unchanged.
#                         read the FULL ledger + every pending member entry, compute the
#                         mechanical joint edges, write _ratification/SET-NNNN.md per the schema,
#                         mark those members `evaluated`. (M3 assembler + M4 joint-edge.)
#   assess   SET-NNNN --text '…' | --file F
#                         the INTEGRATOR AGENT (foundation orc) fills the ASSESSMENT slot
#                         (logic · evidence · live state · invariants; cites receipts). (M5)
#   conformance-check SET-NNNN <member> [--criteria F]
#                         U4B (§2.1) STRUCTURED checker: evaluate the member's machine-checkable
#                         acceptance criteria (_ratification/criteria/<member>.md) → record verdict.
#   conformance       SET-NNNN <member> --verdict PASS|FAIL --method structured|judgment --evidence '…'
#                         U4B (§2.1) verdict recorder — the BOUNDED-JUDGMENT-at-edge path for a prose
#                         criterion (SANCTIONED §2.1), or an out-of-band structured result.
#   ratify   SET-NNNN --by 'name' --rationale-class in-band|OUT-OF-BAND [--decision STATE] [...]
#                         the operator's pen ONLY: stamps the §3 DECISION + ratified-by/at/packet-sha;
#                         REFUSES if the assessment slot is empty, or (for a MERGE decision) any joint
#                         edge is unresolved. (M5, built up to our 5-state taxonomy.)
#   ratify   SET-NNNN --standing-class [--decision RATIFIED]
#                         ARMED 2026-09-16 (C-SET-AUTHORIZATION). The PEN-FREE close for a
#                         BUILD-CLASS set: runs scripts/build-class-check.sh LIVE against the packet and
#                         closes ONLY on rc=0, under the operator's standing CLASS grant (spec §5). rc=1
#                         (a named P failed) or rc=2 (unevaluable) HALT to the operator's pen. Mutually
#                         exclusive with --by; RATIFIED only; every other merge precondition still applies.
#
# PROVENANCE (set-gate Phase-1, P1.3 assemble + P1.6 assess/ratify, per the BYTE-GROUNDED map):
#   LIFTED from GMAA frozen 7a179264d5091ce0f8eabad754495786e48c8fce
#   (build/releases/v2.5.4.2/work/scripts/ratify.sh). `assemble`/`assess` are near-verbatim; two
#   adaptations for our lane, both flagged inline with `# DELTA`:
#     (1) SPINE_PREFIXES swapped to OUR pre-commit census (agents/pre-commit-hook.sh SPINE_PATHS +
#         PENDING-SET.md + _ratification/ + dispatch/LATEST.md) so joint-edge "shared unforkable"
#         detection keys on the same substrate our gate protects.
#     (2) cmd_ratify BUILT UP from GMAA's hardcoded `decision: RATIFIED` (its line 266) to OUR full
#         CLOSED 5-state taxonomy (contracts/C-RATIFICATION-PACKET §3/§5): RATIFIED ·
#         RATIFIED-WITH-SEQUENCE · AMENDED (SUBSET RULE) · HELD (parked against a NAMED trigger) ·
#         REJECTED (→ RETURNED, NO-CHERRY-PICK). This is the ONE place we deliberately exceed the GMAA
#         byte (byte-confirmed: GMAA hardcodes RATIFIED). Wiring to an EXISTING spec,
#         not from-scratch design.
#   PHASE-1 SCOPE: `assemble` reconstructs from ALL pending members — foundation's
#   manual dispatch discipline IS how SET-0001 is declared (AM1 semantic unit). The AM2 dispatch-time
#   set-id (mint-at-dispatch, collect-by-set-id) is Phase-2, NOT built here.
#   No `executor`→`<execution-lane>` translation is needed here (this script is foundation-only; the execution lane's exec
#   apply-receipts carve-out lives in the pre-commit/reap gates, P1.4/P1.5). Consumes our
#   scripts/pending-set.sh (unit 1) + scripts/resolve-lane.sh + PENDING-SET.md machine schema.
#   Plumbing helpers scripts/declared-spine-paths.sh + scripts/receipt-ledger.py are P1.8 (absent now →
#   graceful no-op; guarded by -x tests).

set -u

die()  { echo "ratify: $*" >&2; exit 1; }
halt() { echo "ratify HALT: $*" >&2; exit 3; }
repo_root() { git rev-parse --show-toplevel 2>/dev/null || die "not inside a git worktree (fail-closed)."; }

# need_val — cure for ISSUE-TRAILING-VALUE-FLAG-SPINS-FOREVER-IN-FIVE-SCRIPTS (SET-0083 shape,
# carried verbatim from scripts/creed-scan.sh need_val()/flag-swallow guard, auditor ac4caa28 O1 /
# 0e08e6a4 O2). A value-flag given as the LAST argument used to hang forever here: every arm below
# does `x="${2:-}"; shift 2`, and `shift 2` with one arg left fails WITHOUT shifting, so
# `[[ $# -gt 0 ]]` never becomes false. Call BEFORE reading `$2`/shifting, with the pre-shift `$#`
# and the flag name: refuses (1) no value given (only the flag left) and (2) the next arg is
# itself a `--flag` (no legitimate value here — a name, a path, a prose string — begins with `--`,
# so it would otherwise be silently swallowed as this flag's value). Routed through halt() (exit 3,
# this file's existing fail-closed code) — a named stderr reason, never a silent default.
need_val() { [[ "$1" -ge 2 ]] || halt "$2: requires a value (none given)."; case "${3-}" in --*) halt "$2: requires a value, got the flag '$3' instead." ;; esac; }

# ===================================================================================================
# === BUILD-CLASS GATE — THE ARMING SEAM (spec §3/§5; C-SET-AUTHORIZATION) ===================
# ===================================================================================================
# The predicate lives in a SEPARATE EXECUTABLE (scripts/build-class-check.sh) and stays there. We shell
# out and read ITS exit code; we never re-implement P1–P4 here. Reason: ratify.sh is itself a
# P4-ENFORCER row, so folding the predicate into this file would let ONE file both DEFINE the rule and
# APPLY it — the self-widening shape P4 exists to prevent.
#
#   rc 0 = BUILD-CLASS       ⇒ closes under the operator's standing CLASS grant, NO per-set pen
#   rc 1 = NOT build-class   ⇒ a named P failed ⇒ OPERATOR PEN REQUIRED (a normal, expected outcome)
#   rc 2 = HALT (fail-closed) ⇒ unevaluable input ⇒ treated exactly like rc 1 (never like rc 0)
#
# ⛔ FAIL-CLOSED ON A MISSING GATE. An absent/unreadable gate script is NOT "no objection" — it is an
#    UNEVALUABLE predicate, and spec §3 says an unevaluable predicate is not build-class. Anything
#    other than an affirmative rc=0 from the real gate ends at the operator's pen.
bc_gate() {   # $1 = packet path. Prints the gate's own output verbatim. Returns the gate's own rc.
    local gate; gate="$(repo_root)/scripts/build-class-check.sh"
    if [[ ! -f "$gate" ]]; then
        echo "build-class: HALT — gate script MISSING at scripts/build-class-check.sh (fail-closed: an unevaluable predicate is NOT a pass)"
        return 2
    fi
    bash "$gate" "$1"
}

# PRODUCER half of the arming (spec §3: "The verdict is recorded in the packet … a claim the auditor
# reproduces"). Runs the gate and writes ITS OWN OUTPUT + exit code into the packet's ## BUILD-CLASS
# section. Append-only: the UNEVALUATED marker is replaced on first fill, and every later evaluation is
# APPENDED with its own timestamp — an earlier evaluation's bytes are never rewritten, so the packet
# carries the history rather than a single value that silently moved.
# The recorded line is EVIDENCE, never authority: the close re-runs the gate live (see cmd_ratify).
bc_record() {   # $1 = packet path ; $2 = setid (for the console line)
    local packet="$1" setid="$2" out rc now head_sha gate_blob verdict block
    if ! grep -q '^## BUILD-CLASS' "$packet"; then
        echo "  ⚠ build-class: $setid predates the §3 gate slot (no '## BUILD-CLASS' section) — verdict NOT recorded."
        echo "    A packet with no gate slot can never close under the standing class; it takes the operator's pen."
        return 0
    fi
    out="$(bc_gate "$packet" 2>&1)"; rc=$?
    now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    head_sha="$(git rev-parse --short HEAD 2>/dev/null || echo UNKNOWN)"
    gate_blob="$(git hash-object "$(repo_root)/scripts/build-class-check.sh" 2>/dev/null || echo UNKNOWN)"
    case "$rc" in
        0) verdict="PASS — build-class (standing class applies; NO per-set operator pen)" ;;
        1) verdict="FAIL — NOT build-class ⇒ OPERATOR PEN REQUIRED" ;;
        *) verdict="HALT — predicate UNEVALUABLE (fail-closed ⇒ OPERATOR PEN REQUIRED)" ;;
    esac
    # Every number carries its frame (DISC-A-NUMBER-CARRIES-ITS-FRAME): the verdict is stamped with the
    # HEAD it was measured at AND the blob of the gate that measured it, so a reader can tell whether a
    # later disagreement is a moved footprint or a changed gate.
    block="- build-class: $verdict
- evaluated-at: $now · HEAD \`$head_sha\` · gate blob \`${gate_blob:0:8}\` · rc=$rc
- gate output (VERBATIM — the gate's own bytes, not a summary):
\`\`\`
$out
\`\`\`"
    if grep -q '<!-- BUILD-CLASS-UNEVALUATED -->' "$packet"; then
        blk="$block" awk '/<!-- BUILD-CLASS-UNEVALUATED -->/ { print ENVIRON["blk"]; next } {print}' \
            "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
    else
        blk="$block" awk -v ts="$now" '
            BEGIN{ins=0; done=0}
            /^## BUILD-CLASS/ { ins=1; print; next }
            ins && /^## / && !done {
                print "### RE-EVALUATION — " ts " (append-only; every earlier evaluation above is byte-unchanged)";
                print ENVIRON["blk"]; print ""; done=1; ins=0; print; next
            }
            {print}
            END { if (ins && !done) { print "### RE-EVALUATION — " ts; print ENVIRON["blk"] } }
        ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
    fi
    echo "  build-class: $verdict"
    echo "    recorded in $setid (evidence at $now / HEAD $head_sha). The BINDING evaluation is re-run LIVE at close."
}

# DELTA (1): Spine-owned prefixes = OUR pre-commit census (agents/pre-commit-hook.sh SPINE_PATHS) +
# the three set-gate paths (PENDING-SET.md · _ratification/ · dispatch/LATEST.md). Kept in sync with
# the pre-commit hook so "shared unforkable" joint-edge detection keys on the same substrate the gate
# protects. (P1.4 formalizes PENDING-SET.md/_ratification/ into the hook's SPINE_PATHS; keep aligned.)
# The handoff path is the declared engine-path table's `role:handoff` row, read through the ONE lookup in
# scripts/declared-spine-paths.sh (--role); fail-closed (inv #5), no default path.
HANDOFF_PATH="$("$(git rev-parse --show-toplevel 2>/dev/null)/scripts/declared-spine-paths.sh" --role handoff)" \
    || die "the role:handoff path cannot be resolved from _index/engine-paths.tsv (reason above); fail-closed, no default path is assumed."
SPINE_PREFIXES=( "ledger/" "dag/" "issues_register.md" "CHECKLIST.md" "contracts/" "_orchestration/STATE.md" "_orchestration/decision-log.md" "_orchestration/lane-provisioning.md" "sql/" "migrations/" "agents/" "scripts/" "skill/" "src/" ".claude/agents/" ".claude/settings.json" "PENDING-SET.md" "_ratification/" "$HANDOFF_PATH" )
# Append the adopter's DECLARED spine paths (HEAD-readback) so joint-edge "shared unforkable"
# detection keys on the same declared set the pre-commit gate uses (never the base census alone).
# (declared-spine-paths.sh is P1.8 — absent now → skipped.)
_dsp="$(git rev-parse --show-toplevel 2>/dev/null)/scripts/declared-spine-paths.sh"
if [[ -x "$_dsp" ]]; then while IFS= read -r _dp; do [[ -n "$_dp" ]] && SPINE_PREFIXES+=("$_dp"); done < <("$_dsp" 2>/dev/null); fi
is_spine_path() { local f="$1" sp; for sp in "${SPINE_PREFIXES[@]}"; do case "$sp" in */) [[ "$f" == "$sp"* ]] && return 0;; *) [[ "$f" == "$sp" ]] && return 0;; esac; done; return 1; }

resolve_foundation() {
    local root resolver line; root="$(repo_root)"; resolver="$root/scripts/resolve-lane.sh"
    [[ -x "$resolver" ]] || die "lane resolver missing/not-executable at $resolver (fail-closed)."
    line="$("$resolver")" || die "lane UNRESOLVED (resolver exit != 0) — fail-closed."
    eval "$line"   # -> lane= role= ...
    [[ "${lane:-}" == "foundation" ]] || halt "assemble/assess/ratify run ONLY in the foundation worktree (got lane='${lane:-?}'). Module lanes contribute member entries; they NEVER write the packet."
}

# --- member model: read pending rows from PENDING-SET.md; deps from the SET-MEMBER entries. ---
# Emits, one member per line:  <id>\t<lane>\t<branch@sha>\t<surface,surface,…>
pending_members() {
    # === DISC-CHILD-FAILURE-MUST-SURFACE ===
    # The child is captured SEPARATELY from the parse. Previously this was
    #   "$root/scripts/pending-set.sh" list 2>/dev/null | awk …
    # which masked the child's exit status behind the PIPELINE and DISCARDED its stderr. A
    # fail-closed child (e.g. pending-set.sh refusing because the shared surfaces-token
    # validator is missing) then produced an EMPTY list with pipeline_rc=0, and cmd_assemble
    # reported "no pending members in the ledger" — pointing the next seat at the LEDGER
    # instead of at the real failure. THE TWO EMPTIES MUST BE DISTINGUISHED:
    #   empty because the pool is legitimately empty  -> proceed
    #   empty because the child FAILED                -> HALT, surfacing the child's error
    local root raw rc errf; root="$(repo_root)"
    errf="$(mktemp)"
    raw="$("$root/scripts/pending-set.sh" list 2>"$errf")"; rc=$?
    if [[ $rc -ne 0 ]]; then
        local detail; detail="$(cat "$errf")"; rm -f "$errf"
        echo "ratify HALT: \`pending-set.sh list\` FAILED (exit $rc) — the member pool could NOT BE READ, which is NOT the same as an empty pool (DISC-CHILD-FAILURE-MUST-SURFACE). Child error:" >&2
        [[ -n "${detail// /}" ]] && echo "$detail" >&2
        return 3
    fi
    rm -f "$errf"
    # Pool per requirement: `pending_members status` appends the ledger status cell as a 5th
    # tab column so `assemble` can read the pool per requirement and list the presented-and-unlanded sets.
    # With no argument the output is the same four columns it always was.
    printf '%s\n' "$raw" | awk -F'|' -v wst="${1:-}" '
        { st=$7; gsub(/^[ \t]+|[ \t]+$/,"",st) }
        st=="pending" || st ~ /^evaluated/ {
            id=$3; ln=$4; br=$5; sf=$6
            gsub(/^[ \t]+|[ \t]+$/,"",id); gsub(/^[ \t]+|[ \t]+$/,"",ln)
            gsub(/^[ \t]+|[ \t]+$/,"",br); gsub(/^[ \t]+|[ \t]+$/,"",sf)
            print id"\t"ln"\t"br"\t"sf (wst=="status" ? "\t"st : "")
        }'
}

# Declared dependencies for a member id (from its SET-MEMBER entry, if present).
member_deps() {
    local root id; root="$(repo_root)"; id="$1"
    local f; f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || { echo ""; return; }
    awk -F': ' '/^- self-declared dependencies:/ {print $2; exit}' "$f"
}

# REQ-FOOTPRINT (§2.2) — the member's parent requirement_id / minted set_id (from its SET-MEMBER entry).
member_reqid() {
    local root id f; root="$(repo_root)"; id="$1"
    f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || { echo ""; return; }
    awk -F': ' '/^- requirement id:/ {print $2; exit}' "$f"
}
member_setid() {
    local root id f; root="$(repo_root)"; id="$1"
    f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || { echo ""; return; }
    awk -F': ' '/^- set id:/ {print $2; exit}' "$f"
}

# Evidence receipts a member cites (from its SET-MEMBER "evidence receipts:" field), one id per line.
# Skips the "none-declared" sentinel. (§2.16 — these are the ids whose ledger uniqueness ratify verifies.)
member_receipts() {
    local root id; root="$(repo_root)"; id="$1"
    local f; f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || return
    awk -F': ' '/^- evidence receipts:/ {print $2; exit}' "$f" \
        | tr ',' '\n' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' \
        | grep -viE '^(none-declared|none)$' | grep -v '^$' || true
}

# REQ-HUNT (§2.3) — the member's declared cross-substrate effects (§4a multi-substrate manifest), raw
# string ('db: …; make: …; wp: …', or the 'git-surfaces-only' sentinel). Empty if no member file.
member_effects() {
    local root id f; root="$(repo_root)"; id="$1"
    f="$(ls "$root"/_orchestration/relay-outbox/*/SET-MEMBER-"$id".md 2>/dev/null | head -1)"
    [[ -n "$f" ]] || { echo ""; return; }
    awk '/^- declared effects/ {sub(/^[^:]*: /,""); print; exit}' "$f"
}

# REQ-HUNT (§2.3 Layer B — SoR shared-record class) — normalized STRUCTURE-OF-RECORD identifiers a member
# CITES, extracted from its surfaces + declared-effects, diffed cross-member against the §5 index namespace.
# MECHANICAL + INCOMPLETE-BY-DESIGN (canon §13, SAID-SO on the packet): sproc names (sp_*) and standing-probe
# ids (probe_*) are path/effect-embedded and reliably extractable; object names, seats.yaml keys, SLOTS.md ids
# and contract SECTIONS are NOT yet mechanized (a model may hand the integrator a candidate list — never a
# CLEAR stamp; Layer C carries the residual). One token per line, deduped.
record_tokens() {   # $1 = surfaces (comma list) ; $2 = declared-effects (raw)
    { printf '%s\n' "${1//,/ }"; printf '%s\n' "${2:-}"; } \
        | grep -oE 'sp_[a-z0-9_]+|probe_[a-z0-9_]+' 2>/dev/null \
        | sed -E 's/^(sp_[a-z0-9_]+)$/sproc:\1/; s/^(probe_[a-z0-9_]+)$/probe:\1/' \
        | sort -u
}

# REQ-HUNT (§2.3 footprint.substrates secondary cross-check — folded in) — the SoR SUBSTRATES a
# member writes. Any git surface = a git-spine effect; each declared-effect KEY maps to its §5 substrate.
# Flag (never hard-miss) when a member writes a substrate outside the requirement's declared footprint.
# The substrate vocabulary is a TABLE (_index/substrates.tsv: alias · canonical · scope · note), never case arms.
# Parse rule (fail-closed, exit 3): the table must exist and every non-comment, non-header row must carry exactly
# 4 tab fields with a non-empty alias/canonical and scope in engine|origin — else UNREADABLE (never a default).
SUBTAB=""; SUBTAB_LOADED=""
load_substrates() {
    local root tbl bad; root="$(repo_root)"; tbl="$root/_index/substrates.tsv"
    [[ -r "$tbl" ]] || halt "UNREADABLE: substrate table $tbl is absent or unreadable (fail-closed; no default vocabulary is assumed)."
    bad="$(awk -F'\t' '/^#/ || !NF || $1=="alias" {next} NF!=4 || $1=="" || $2=="" || ($3!="engine" && $3!="origin") {print NR; exit}' "$tbl")"
    [[ -z "$bad" ]] || halt "UNREADABLE: substrate table $tbl row at line $bad is not 'alias<TAB>canonical<TAB>engine|origin<TAB>note' (fail-closed)."
    SUBTAB="$(awk -F'\t' '/^#/ || !NF || $1=="alias" {next} {print $1 "\t" $2}' "$tbl")"; SUBTAB_LOADED=1
}
# substrate_lookup <alias> — prints the canonical class; returns 1 when the alias is not in the table.
substrate_lookup() { printf '%s\n' "$SUBTAB" | awk -F'\t' -v k="$1" '$1==k {print $2; f=1; exit} END {exit !f}'; }
# effect_key_list <declared-effects> — one normalised key per line; the 'git-surfaces-only' sentinel is not a key.
effect_key_list() {
    local key; local -a _ES=(); IFS=';' read -ra _ES <<< "${1:-}"
    for key in ${_ES[@]+"${_ES[@]}"}; do key="${key%%:*}"; key="${key//[[:space:]]/}"
        [[ -n "$key" && "$key" != git-surfaces-only ]] && echo "$key"
    done
}
member_substrates() {   # $1 = surfaces (comma list) ; $2 = declared-effects (raw)
    local surf="$1" eff="${2:-}" key c
    [[ -n "${surf//[[:space:],]/}" ]] && echo "git-spine"
    while IFS= read -r key; do [[ -z "$key" ]] && continue
        c="$(substrate_lookup "$key")" && echo "$c"
    done < <(effect_key_list "$eff")
}
norm_substrate() { local c; c="$(substrate_lookup "$1")" && echo "$c" || echo "$1"; }

# Every packet declares `cures: <ids>|none` at its FIRST write
# (assemble; ratify.sh has no `open` verb). An id must resolve: SET-NNNN to an existing _ratification/SET-NNNN.md,
# ISSUE-… to an occurrence in issues_register.md (DISC-AUTHZ-INPUT-VALIDATED-AT-EARLIEST-WRITE). Prints the
# normalised value (comma-joined, de-duplicated) or dies naming the bad id.
cures_validate() {
    local root="$1" raw="$2" id out="" seen=" "
    [[ -n "$raw" ]] || die "assemble: --cures <ids>|none is REQUIRED (a set is a cure-set iff cures is not none; the field cannot be omitted)."
    if [[ "$raw" == none ]]; then echo none; return 0; fi
    for id in $(printf '%s' "$raw" | tr ',' ' '); do
        if [[ "$id" =~ ^SET-[0-9]{4}$ ]]; then
            [[ -f "$root/_ratification/$id.md" ]] || die "assemble: --cures id '$id' does not resolve (no _ratification/$id.md)."
        elif [[ "$id" =~ ^ISSUE-[A-Z0-9-]+$ ]]; then
            grep -qE "(^|[^A-Z0-9-])${id}([^A-Z0-9-]|$)" "$root/issues_register.md" 2>/dev/null \
                || die "assemble: --cures id '$id' does not resolve (no occurrence in issues_register.md)."
        else
            die "assemble: --cures id '$id' is neither SET-NNNN nor ISSUE-… (and the list is not 'none')."
        fi
        [[ "$seen" == *" $id "* ]] && continue
        seen="$seen$id "; out="${out:+$out,}$id"
    done
    [[ -n "$out" ]] || die "assemble: --cures '$raw' names no id."
    echo "$out"
}

# One cure set per restart boundary, refused at assembly otherwise. S = the newest first-parent
# commit on the current branch whose subject is a boundary seal (the shape the E12 meter counts:
# `[audit] seal (n=K) … boundary=restart|shutdown`; a `manual` seal is not a boundary), or the root when there is none.
# The boundary interval is S..HEAD (first-parent additions) plus the working tree's new packets. A cure-class packet is
# a SET-<n>.md packet in the packet directory whose `- cures:` line is not `none`. `--cures none` is never refused. No override (R4(b)).
cures_boundary_gate() {
    local root="$1" cures="$2" log s sdesc p v found=""
    [[ "$cures" == none ]] && return 0
    log="$(git -C "$root" log --first-parent --format='%H %s' HEAD 2>/dev/null)" \
        || halt "assemble: the cure-set boundary gate cannot read the first-parent history of HEAD (fail-closed)."
    s="$(printf '%s\n' "$log" | grep -m1 -E '^[0-9a-f]{40} \[audit\] seal \(n=[0-9]+\) .*boundary=(restart|shutdown)([^A-Za-z0-9_]|$)' | cut -d' ' -f1)"
    if [[ -n "$s" ]]; then sdesc="boundary seal ${s:0:8} ($(git -C "$root" log -1 --format=%s "$s" | cut -c1-60))"
    else s="$(printf '%s\n' "$log" | tail -1 | cut -d' ' -f1)"; sdesc="the root ${s:0:8} (no boundary seal on this branch)"; fi
    [[ -n "$s" ]] || halt "assemble: the cure-set boundary gate found no commit on HEAD (fail-closed)."
    while IFS= read -r p; do
        [[ "$(dirname "$p")" == _ratification && "$(basename "$p")" =~ ^SET-[0-9]{4}\.md$ ]] || continue
        if [[ -f "$root/$p" ]]; then v="$(sed -nE 's/^- cures: ([^[:space:]]+).*/\1/p' "$root/$p" | head -1)"
        else v="$(git -C "$root" show "HEAD:$p" 2>/dev/null | sed -nE 's/^- cures: ([^[:space:]]+).*/\1/p' | head -1)"; fi
        [[ -n "$v" && "$v" != none ]] && found="${found:+$found, }$(basename "$p" .md) (cures: $v)"
    done < <( { git -C "$root" log --first-parent --diff-filter=A --name-only --format= "$s..HEAD" -- _ratification/
                git -C "$root" status --porcelain --untracked-files=all -- _ratification/ | sed -nE 's/^(\?\?|A.) //p'; } | sort -u )
    [[ -z "$found" ]] || die "assemble: REFUSED (one cure set per restart boundary): cure packet $found already exists in this boundary interval, which starts at $sdesc. Either the pending member joins that packet (assemble reconstructs from all pending members), or the boundary is sealed (a restart) before a new cure set is assembled. --cures none is not refused. There is no override."
}

cmd_assemble() {
    resolve_foundation
    local root want="" cures_raw="" cures reqflag=""; root="$(repo_root)"
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --cures)   [[ $# -ge 2 ]] || die "assemble: --cures needs a value (<ids>|none)."; cures_raw="$2"; shift 2 ;;
            --cures=*) cures_raw="${1#--cures=}"; shift ;;
            # Pool per requirement: read the pool for ONE requirement. Absent = the whole-ledger read.
            --requirement-id)   need_val $# "--requirement-id" "${2:-}"; reqflag="${2:-}"; shift 2 ;;
            --requirement-id=*) reqflag="${1#--requirement-id=}"; shift ;;
            *)         [[ -z "$want" ]] || die "assemble: unexpected argument '$1'."; want="$1"; shift ;;
        esac
    done
    cures="$(cures_validate "$root" "$cures_raw")" || exit 2
    cures_boundary_gate "$root" "$cures"
    if [[ -n "$reqflag" ]]; then
        [[ "$reqflag" =~ ^REQ-[A-Za-z0-9._-]+$ ]] || die "assemble: --requirement-id must match REQ-<id> (got '$reqflag')."
    fi
    mkdir -p "$root/_ratification"
    # Number: explicit SET-NNNN (collision → HALT) else mechanical = last packet at HEAD + 1.
    local num
    if [[ -n "$want" ]]; then
        [[ "$want" =~ ^SET-[0-9]{4}$ ]] || die "assemble: id must be SET-NNNN (got '$want')."
        [[ -e "$root/_ratification/$want.md" ]] && halt "numbering collision — $want already exists at HEAD. Assembly numbers are mechanical; resolve before re-assembling."
        num="${want#SET-}"
    else
        local last; last="$(ls "$root"/_ratification/SET-*.md 2>/dev/null | sed -E 's#.*/SET-([0-9]{4})\.md#\1#' | sort -n | tail -1)"
        num="$(printf '%04d' $(( 10#${last:-0} + 1 )) )"
        [[ -e "$root/_ratification/SET-$num.md" ]] && halt "numbering collision on SET-$num."
    fi
    local setid="SET-$num" packet="$root/_ratification/SET-$num.md"

    # Read members. PHASE-1: reconstruct from ALL pending members — foundation's manual
    # dispatch discipline is how the coherent semantic set (AM1) is declared. AM2 collect-by-set-id = P2.
    local -a IDS=() LANES=() BRANCHES=() SURF=()
    # Pool per requirement: with --requirement-id the pool is that requirement's `pending` rows plus the rows
    # `evaluated (into <its minted set>)`; rows evaluated into another requirement's set are not in it.
    # EVERY `evaluated (into SET-X)` row of the whole ledger is also read, unfiltered, for `presented-after`.
    local reqset="" presented_ids=""
    if [[ -n "$reqflag" ]]; then
        reqset="$("$root/scripts/pending-set.sh" registry "$reqflag" 2>/dev/null | cut -f1)"
        [[ -n "$reqset" ]] || halt "POOL (--requirement-id): requirement '$reqflag' has NO minted set_id in the SET-IDENTITY registry — nothing to pool. Mint it first. Fail-closed."
    fi
    # CAPTURE, do not consume through process substitution. `done < <(pending_members)`
    # runs the function in a SUBSHELL, so a failure inside it cannot stop the parent; command
    # substitution preserves the exit status and lets the HALT actually fire.
    local _pm_out _pm_rc
    _pm_out="$(pending_members status)"; _pm_rc=$?
    if [[ $_pm_rc -ne 0 ]]; then
        halt "cannot read the pending-member pool (see the child error above) — REFUSING to treat an unreadable pool as an empty one (DISC-CHILD-FAILURE-MUST-SURFACE)."
    fi
    local st
    while IFS=$'\t' read -r id lane branch surf st; do
        [[ -z "$id" ]] && continue
        if [[ "$st" =~ ^evaluated\ \(into\ (SET-[0-9]{4})\)$ ]]; then presented_ids+="${BASH_REMATCH[1]}"$'\n'; fi
        if [[ -n "$reqflag" ]]; then
            [[ "$(member_reqid "$id")" == "$reqflag" ]] || continue
            [[ "$st" == "pending" || "$st" == "evaluated (into $reqset)" ]] || continue
        fi
        IDS+=("$id"); LANES+=("$lane"); BRANCHES+=("$branch"); SURF+=("$surf")
    done <<< "$_pm_out"
    [[ -z "$reqflag" || ${#IDS[@]} -gt 0 ]] || halt "POOL (--requirement-id): no pending member of '$reqflag' (and none evaluated into its set $reqset) in the ledger — nothing to assemble."
    [[ ${#IDS[@]} -gt 0 ]] || halt "no pending members in the ledger — nothing to assemble. (The pool was READ SUCCESSFULLY and is genuinely empty; a child failure would have HALTed above with the child's error.)"

    # --- M4: mechanical joint-edge detection (Layer A three classes + Layer B SoR shared-record; §2.3). ---
    local -a EDGES=()
    local i j
    # REQ-HUNT (§2.3 Layer B) — precompute each member's declared effects (§4a manifest) + its SoR record
    # tokens (sproc/probe ids) ONCE; the pairwise loop diffs these for cross-file SHARED-RECORD overlap.
    local -a EFFECTS=() TOKLIST=()
    for (( i=0; i<${#IDS[@]}; i++ )); do
        EFFECTS+=("$(member_effects "${IDS[$i]}")")
        TOKLIST+=("$(record_tokens "${SURF[$i]}" "${EFFECTS[$i]}" | tr '\n' ' ')")
    done
    for (( i=0; i<${#IDS[@]}; i++ )); do
        for (( j=i+1; j<${#IDS[@]}; j++ )); do
            # (a) overlapping paths + (b) shared unforkable = an overlap ON a spine-owned path.
            # (Two members touching DIFFERENT files — even both under a spine dir — are disjoint =
            # NONE; "shared unforkable" is a stronger flavor of an actual shared path, not a
            # both-touch-spine rule, per the M3 acceptance "disjoint members → NONE".)
            local shared="" unf=0 pi pj
            IFS=',' read -ra PI <<< "${SURF[$i]}"; IFS=',' read -ra PJ <<< "${SURF[$j]}"
            for pi in "${PI[@]}"; do pi="${pi// /}"; [[ -z "$pi" ]] && continue
                for pj in "${PJ[@]}"; do pj="${pj// /}"; [[ -z "$pj" ]] && continue
                    if [[ "$pi" == "$pj" ]]; then shared="${shared:+$shared, }$pi"; is_spine_path "$pi" && unf=1; fi
                done
            done
            if [[ -n "$shared" ]]; then
                if [[ $unf -eq 1 ]]; then
                    EDGES+=("${IDS[$i]} × ${IDS[$j]} — OVERLAPPING PATH(S) [shared unforkable — spine-owned]: $shared")
                else
                    EDGES+=("${IDS[$i]} × ${IDS[$j]} — OVERLAPPING PATH(S): $shared")
                fi
            fi
            # (c) declared-dependency reference / cycle
            local di dj; di="$(member_deps "${IDS[$i]}")"; dj="$(member_deps "${IDS[$j]}")"
            local iref=0 jref=0
            [[ "$di" == *"${IDS[$j]}"* ]] && iref=1
            [[ "$dj" == *"${IDS[$i]}"* ]] && jref=1
            if [[ $iref -eq 1 && $jref -eq 1 ]]; then
                EDGES+=("${IDS[$i]} × ${IDS[$j]} — DECLARED-DEPENDENCY CYCLE (each declares a dependency on the other)")
            elif [[ $iref -eq 1 ]]; then
                EDGES+=("${IDS[$i]} → ${IDS[$j]} — DECLARED DEPENDENCY (${IDS[$i]} reads a surface ${IDS[$j]} touches)")
            elif [[ $jref -eq 1 ]]; then
                EDGES+=("${IDS[$j]} → ${IDS[$i]} — DECLARED DEPENDENCY (${IDS[$j]} reads a surface ${IDS[$i]} touches)")
            fi
            # (d) REQ-HUNT Layer B (§2.3) — SoR SHARED-RECORD: the SAME record id (sproc/probe) cited by both
            # members via DIFFERENT files. Suppressed when they already share a path (Layer A OVERLAPPING PATH
            # covers that). This is the "both change one sproc without touching the same file" case.
            if [[ -z "$shared" ]]; then
                local t t2
                for t in ${TOKLIST[$i]}; do
                    for t2 in ${TOKLIST[$j]}; do
                        [[ "$t" == "$t2" ]] && EDGES+=("${IDS[$i]} × ${IDS[$j]} — SHARED-RECORD [$t] (both members cite the same structure-of-record id via different files; §2.3 Layer B — integrator MUST assess)")
                    done
                done
            fi
        done
    done

    # === REQ-FOOTPRINT (§2.2) — footprint-coverage gate: fail-closed, before the packet is written. ===
    # (Members carry requirement_id + set_id from their SET-MEMBER manifest; the footprint.lanes come from
    #  the SET-IDENTITY registry, transcribed from the architect spec at mint. The gate reads STRUCTURE.)
    local -a REQIDS=() SETIDS=()
    local fm mrq msd
    for (( fm=0; fm<${#IDS[@]}; fm++ )); do
        mrq="$(member_reqid "${IDS[$fm]}")"; msd="$(member_setid "${IDS[$fm]}")"
        [[ -n "$mrq" ]] || halt "FOOTPRINT (§2.2(a)): member '${IDS[$fm]}' carries no requirement_id — not dispatchable without a parent requirement. Re-issue via 'pending-set.sh member … --requirement-id REQ-<id> --set-id SET-NNNN'. Fail-closed."
        [[ -n "$msd" ]] || halt "FOOTPRINT (§2.2(b)): member '${IDS[$fm]}' carries no set_id — mint + stamp a set_id before assembling. Fail-closed."
        REQIDS+=("$mrq"); SETIDS+=("$msd")
    done
    # (1) all assembled members share ONE requirement_id + ONE set_id.
    local rq0="${REQIDS[0]}" sd0="${SETIDS[0]}"
    for (( fm=1; fm<${#REQIDS[@]}; fm++ )); do
        [[ "${REQIDS[$fm]}" == "$rq0" ]] || halt "FOOTPRINT (§2.2(c)(1)): mixed requirement_ids in the assemble ('$rq0' vs '${REQIDS[$fm]}') — two requirements = two sets. Assemble each separately. Fail-closed. Distinct requirement ids in this pool: $(printf '%s\n' "${REQIDS[@]}" | LC_ALL=C sort -u | paste -sd, - | sed 's/,/, /g') — re-run with --requirement-id REQ-<id> to assemble one."
        [[ "${SETIDS[$fm]}" == "$sd0" ]] || halt "FOOTPRINT (§2.2(b)): mixed set_ids for requirement '$rq0' ('$sd0' vs '${SETIDS[$fm]}') — the stagger. Fail-closed."
    done
    # The packet id IS the minted set_id (born at mint, not chosen at assemble). Reconcile any explicit arg.
    [[ -n "$want" && "$want" != "$sd0" ]] && halt "FOOTPRINT (§2.2(b)): explicit id '$want' ≠ the members' minted set_id '$sd0' — the set_id is born at mint. Fail-closed."
    if [[ "$setid" != "$sd0" ]]; then
        setid="$sd0"; num="${sd0#SET-}"; packet="$root/_ratification/$sd0.md"
        [[ -e "$packet" ]] && halt "numbering collision — $sd0 already exists at HEAD (minted set_id). Resolve before re-assembling."
    fi
    # (2) load footprint.lanes from the SET-IDENTITY registry (mint-time transcription of the architect spec).
    local reg flanes; reg="$("$root/scripts/pending-set.sh" registry "$rq0" 2>/dev/null || true)"
    [[ -n "$reg" ]] || halt "FOOTPRINT (§2.2): requirement '$rq0' has NO minted footprint in the SET-IDENTITY registry — no footprint → not dispatchable. Mint it first. Fail-closed."
    flanes="$(printf '%s' "$reg" | cut -f2)"
    local fsubs; fsubs="$(printf '%s' "$reg" | cut -f3)"   # REQ-HUNT §2.3 — optional footprint.substrates
    # Footprint lanes (declared) + assembled lanes (unique from members).
    local -a FLANES=() ALANES=(); local tok seen y
    IFS=',' read -ra _fl <<< "$flanes"
    for tok in "${_fl[@]}"; do tok="${tok//[[:space:]]/}"; tok="${tok#[}"; tok="${tok%]}"; [[ -n "$tok" ]] && FLANES+=("$tok"); done
    [[ ${#FLANES[@]} -gt 0 ]] || halt "FOOTPRINT (§2.2): requirement '$rq0' has an EMPTY footprint.lanes in the registry — no footprint → not dispatchable. Fail-closed."
    # (dedup assembled lanes; ${arr[@]+…} guards the empty-array expansion under `set -u` on bash 3.2/macOS)
    local ln
    for ln in "${LANES[@]}"; do ln="${ln//[[:space:]]/}"; [[ -z "$ln" ]] && continue
        seen=0; for y in ${ALANES[@]+"${ALANES[@]}"}; do [[ "$y" == "$ln" ]] && seen=1; done; [[ $seen -eq 0 ]] && ALANES+=("$ln"); done
    [[ ${#ALANES[@]} -gt 0 ]] || halt "FOOTPRINT: no assembled lanes could be resolved for the members (fail-closed)."
    # (3) coverage: assembled_lanes ⊇ footprint.lanes (missing required lane → HALT, never assess-aroundable).
    local -a MISSING=() EXTRA=(); local fl al hit
    for fl in "${FLANES[@]}"; do hit=0; for al in "${ALANES[@]}"; do [[ "$al" == "$fl" ]] && hit=1; done; [[ $hit -eq 0 ]] && MISSING+=("$fl"); done
    for al in "${ALANES[@]}"; do hit=0; for fl in "${FLANES[@]}"; do [[ "$al" == "$fl" ]] && hit=1; done; [[ $hit -eq 0 ]] && EXTRA+=("$al"); done
    if [[ ${#MISSING[@]} -gt 0 ]]; then
        halt "FOOTPRINT-MISS: spec '$rq0' requires lanes [${FLANES[*]}]; assembled has [${ALANES[*]}]; missing [${MISSING[*]}]. A required footprint lane is NEVER assess-aroundable on a MERGE decision (§2.2(c)(3), U4B shape). Fail-closed — do not hold a ready lane by dropping a required one."
    fi
    # (4) EXTRA lanes beyond the footprint are NOT auto-pass — a JOINT-EDGE of class UNDECLARED-OCCUPANT
    #     (integrator MUST assess; MERGE allowed only AFTER assessment — a real extra dependency can appear).
    for al in ${EXTRA[@]+"${EXTRA[@]}"}; do
        EDGES+=("$rq0 footprint [${FLANES[*]}] × occupant lane '$al' — UNDECLARED-OCCUPANT (a lane assembled beyond the declared footprint; integrator MUST assess before MERGE)")
    done
    # (5) REQ-HUNT (§2.3) footprint.substrates SECONDARY cross-check (folded in): a member writing
    #     a SoR substrate OUTSIDE the requirement's declared footprint.substrates is FLAGGED (never a hard
    #     FOOTPRINT-MISS — a real cross-substrate effect can be legitimate; the integrator assesses). Runs
    #     ONLY when the registry declares substrates (the field is OPTIONAL; '—'/empty → skip, unchanged).
    #     Every declared effect key must resolve through the substrate table: an alias the table does not
    #     carry is UNRESOLVED UNKNOWN-EFFECT-KEY (loud, whether or not footprint.substrates is declared).
    local _uk _umi
    for (( _umi=0; _umi<${#IDS[@]}; _umi++ )); do
        while IFS= read -r _uk; do [[ -z "$_uk" ]] && continue
            [[ -n "$SUBTAB_LOADED" ]] || load_substrates
            substrate_lookup "$_uk" >/dev/null || EDGES+=("UNKNOWN-EFFECT-KEY $_uk — member ${IDS[$_umi]} declares an effect key the substrate table (_index/substrates.tsv) does not carry; add the alias or correct the key (no default substrate is assumed)")
        done < <(effect_key_list "${EFFECTS[$_umi]}")
    done
    if [[ -n "${fsubs//[[:space:]]/}" && "${fsubs//[[:space:]]/}" != "—" ]]; then
        [[ -n "$SUBTAB_LOADED" ]] || load_substrates
        local -a FSUBS=(); local s mi msub declared; local -a _fs=()
        IFS=',' read -ra _fs <<< "$fsubs"
        for s in "${_fs[@]}"; do s="${s//[[:space:]]/}"; s="${s#[}"; s="${s%]}"; [[ -n "$s" ]] && FSUBS+=("$(norm_substrate "$s")"); done
        for (( mi=0; mi<${#IDS[@]}; mi++ )); do
            while IFS= read -r msub; do [[ -z "$msub" ]] && continue
                msub="$(norm_substrate "$msub")"; declared=0
                for s in ${FSUBS[@]+"${FSUBS[@]}"}; do [[ "$s" == "$msub" ]] && declared=1; done
                [[ $declared -eq 0 ]] && EDGES+=("${IDS[$mi]} writes substrate '$msub' — UNDECLARED-SUBSTRATE (outside footprint.substrates [${FSUBS[*]}]; §2.3 secondary cross-check — a flag, not a hard-miss; integrator MUST assess)")
            done < <(member_substrates "${SURF[$mi]}" "${EFFECTS[$mi]}" | sort -u)
        done
    fi

    local head_sha; head_sha="$(git -C "$root" rev-parse --short HEAD 2>/dev/null || echo '?')"
    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    # Stacked packets: every packet presented and unlanded at assembly time = a set with ledger rows still
    # `evaluated (into SET-X)` (assemble stamps them; ratify flips them: RATIFIED -> `ratified-in`; HELD/
    # AMENDED/REJECTED leave a different status). Presentation order = the packet's assembled-at (UTC, sortable),
    # a set with no packet file here sorts last, then by set number. This packet's own set is not "before" itself.
    local presented_after="NONE" _psid _pkey _pkeys=""
    while IFS= read -r _psid; do
        [[ -z "$_psid" || "$_psid" == "$setid" ]] && continue
        _pkey="$(awk '/^- assembled-at: / {print $3; exit}' "$root/_ratification/$_psid.md" 2>/dev/null)"
        _pkeys+="${_pkey:-~}"$'\t'"$_psid"$'\n'
    done < <(printf '%s' "$presented_ids" | LC_ALL=C sort -u)
    [[ -z "$_pkeys" ]] || presented_after="$(printf '%s' "$_pkeys" | LC_ALL=C sort -t$'\t' -k1,1 -k2,2 | cut -f2 | paste -sd, - | sed 's/,/, /g')"

    # --- write the packet per C-RATIFICATION-PACKET §2 (all named sections present). ---
    {
        echo "# $setid — set ratification packet"
        echo
        echo "> SCAR (canon §4): serialized transport hides the set; it does not dissolve it. Members are"
        echo "> each ratified alone; joint evaluation has never run — the incoherence in their interaction"
        echo "> reaches commit unseen. This packet is the set made visible. Set authorization is ON TOP OF"
        echo "> per-change review, never instead of it."
        echo ">"
        echo "> DETECTION HONESTY (canon §13): the JOINT-EDGES below are the MECHANICAL classes only — Layer A"
        echo "> (overlapping paths · shared unforkable artifacts · declared-dependency cycles) + Layer B (§2.3:"
        echo "> SoR SHARED-RECORD — same sproc/probe id cited across DIFFERENT files) + footprint edges"
        echo "> (UNDECLARED-OCCUPANT · UNDECLARED-SUBSTRATE). Field-proven, NOT proven-complete: object names,"
        echo "> seats/SLOTS keys, contract SECTIONS and two contradicting prose sentences are NOT mechanically"
        echo "> caught. That residual is UNSKIPPABLE — it is carried by the required ## SEMANTIC HUNT slot (§2.3"
        echo "> Layer C) + INTEGRATOR ASSESSMENT. 'none found' is a claim, not a proof."
        echo ">"
        echo "> COHERENCE LAW (REQ-HUNT §2.3): Mechanical JOINT-EDGES = NONE does NOT mean the set is coherent."
        echo "> MERGE is legal only after the SEMANTIC HUNT verdict is CLEAR or every named edge is resolved."
        echo
        echo "## HEADER"
        echo "- set id: $setid"
        echo "- requirement id: $rq0"
        echo "- footprint.lanes (spec, §2.2): [${FLANES[*]}] · assembled: [${ALANES[*]}] · coverage: $([[ ${#EXTRA[@]} -eq 0 ]] && echo 'EXACT' || echo "EXACT+extra{${EXTRA[*]}}")"
        echo "- wave id: <wave>"
        echo "- assembled-by: foundation"
        echo "- assembled-at: $now"
        echo "- HEAD sha at assembly: $head_sha"
        # presented-after (contracts/C-RATIFICATION-PACKET.md §2). Its OWN bullet, not a suffix on the line above:
        # agents/pre-commit-hook.sh:385 reads the `HEAD sha at assembly:` value to the end of the line.
        echo "- presented-after: $presented_after"
        # Judgment base: the tree a stacked packet is judged at is a function of the line above, so the packet names it.
        if [[ "$presented_after" == "NONE" ]]; then
            echo "- judgment-base: spine HEAD $head_sha"
        else
            echo "- judgment-base: spine HEAD $head_sha + the parked bytes of $presented_after, applied in that order · void-if: any listed packet is HELD, AMENDED or REJECTED (this packet's rows then return to pending by the AMENDED path and it re-assembles on the new base)"
        fi
        echo "- cures: $cures"
        # P3 (reversibility) is the ONE predicate limb not derivable from a footprint (spec §1/§3), so
        # the gate fail-closes on an explicit declaration. Emit it UNDECLARED so the field is VISIBLE
        # and declarable — without this line no assembled packet carries it at all, the gate FAILs P3
        # on every set, and the pen-free path is armed but UNREACHABLE (arming half a gate, from the
        # other direction). UNDECLARED is not YES: the fail-closed default is untouched, and the
        # assembler must affirmatively change it to declare reversibility.
        # ⚠ THE VALUE LINE STAYS CLEAN. The gate's P3 test is ANCHORED (`…p3-reversible:[ ]*YES[ ]*$`),
        # so a trailing instructional comment on this line would make an honest `YES` fail to match —
        # the assembler would declare reversibility and be refused with no idea why. Guidance goes on
        # its own line, never on the line the enforcer parses.
        echo "> P3: change the line below to \`- p3-reversible: YES\` ONLY if every member is genuinely"
        echo "> reversible (spec §1 P3). Anything other than exactly YES is fail-closed ⇒ operator pen."
        echo "- p3-reversible: UNDECLARED"
        echo
        echo "## MEMBERS"
        for (( i=0; i<${#IDS[@]}; i++ )); do
            echo "- ${IDS[$i]} · lane=${LANES[$i]} · ${BRANCHES[$i]} · surfaces: ${SURF[$i]}"
        done
        echo
        echo "## JOINT-EDGES (mechanical; the floor)"
        if [[ ${#EDGES[@]} -eq 0 ]]; then
            echo "- NONE (no member pair shares a path, spine substrate, or declared dependency)."
            echo "  NOTE: NONE is the mechanical result only — semantic joint incoherence is not detectable here"
            echo "  and must be weighed in INTEGRATOR ASSESSMENT (canon §13)."
        else
            for e in "${EDGES[@]}"; do echo "- UNRESOLVED · $e"; done
            echo
            echo "  Each edge above must be RESOLVED before ratify will pass (M5 / RULING 2A): flip its"
            echo "  \`- UNRESOLVED ·\` prefix to \`- RESOLVED ·\` AND add a following \`resolution: <rationale>\` line."
            echo "  BOTH are enforced — a bare prefix flip with no rationale is REFUSED (the operator ratifies the WHY)."
        fi
        echo
        echo "## CONFLICT SWEEP"
        echo "- (integrator: subagent sweep of live docs + codebase across the joint set; findings + evidence"
        echo "  paths here. 'none found' requires the sweep receipt.)"
        echo
        echo "## COHERENCE CHECKS"
        echo "- (integrator: each set-level check — evaluable only on the JOINT set — · result · evidence path.)"
        # §2.16 runs at ratify only when its helper exists; an absent helper is a printed NOT-RUN, never silence
        # and never a uniqueness claim (inv #5).
        [[ -x "$root/scripts/receipt-ledger.py" ]] || echo "- $RECEIPT_UNIQ_NOT_RUN"
        echo
        echo "## CONFORMANCE (U4B — per-member: declared effects ⊨ the member's WP acceptance criteria; §2.1)"
        echo "> The GATE is mechanical + fail-closed + NON-OVERRIDABLE: \`ratify\` REFUSES a MERGE"
        echo "> decision unless EVERY member below carries \`verdict: PASS\` (with evidence). A STRUCTURED checker"
        echo "> (\`ratify.sh conformance-check $setid <member>\`) emits machine-checkable verdicts against the"
        echo "> member's acceptance-criteria file (_ratification/criteria/<member>.md — architect-owned; §2.1"
        echo "> corollary: a member with no checkable criteria is NOT conform-checkable and cannot PASS). An"
        echo "> irreducibly-prose criterion takes a RECORDED bounded judgment (\`ratify.sh conformance $setid"
        echo "> <member> --verdict PASS|FAIL --method judgment --evidence '…'\`, SANCTIONED §2.1). MISSING or FAIL → REFUSE."
        for (( i=0; i<${#IDS[@]}; i++ )); do
            echo "- ${IDS[$i]} · lane=${LANES[$i]} · verdict: MISSING"
        done
        echo
        echo "## BUILD-CLASS (spec §3 — the mechanical P1–P4 predicate over this set's declared footprint)"
        echo "> **RECORDED, NEVER ASSERTED.** Filled by \`ratify.sh assess\` from the EXIT CODE of"
        echo "> \`scripts/build-class-check.sh\` — the assembler never types this verdict. The auditor"
        echo "> reproduces it post-merge (AC-B4)."
        echo "> **⚠ ADVISORY AT ITS TIMESTAMP, NOT AT CLOSE.** A verdict recorded here can be true when"
        echo "> written and stale when read — the footprint or the predicate data may move in between."
        echo "> The BINDING evaluation is re-run LIVE against the gate at close (\`ratify --standing-class\`),"
        echo "> which reads the gate's exit code and never this line."
        echo "<!-- BUILD-CLASS-UNEVALUATED -->"
        echo
        echo "## INTEGRATOR ASSESSMENT (foundation agent — filled by \`ratify.sh assess\`)"
        echo "<!-- ASSESSMENT-EMPTY -->"
        echo
        echo "## SEMANTIC HUNT (canon §13 — REQUIRED; 'none found' is a claim, not a proof — §2.3 Layer C)"
        echo "> Mechanical joint-edge detection (Layer A + B above) is INCOMPLETE by construction. This slot is"
        echo "> UNSKIPPABLE: a MERGE decision (\`ratify --decision RATIFIED[-WITH-SEQUENCE]\`) REFUSES on a"
        echo "> missing/unfilled block, on verdict UNABLE, or on CLEAR asserted with 'candidates considered:"
        echo "> ZERO' and no method. Fill via: \`ratify.sh hunt $setid --method '<what was grepped / which SoR"
        echo "> indexes opened>' --candidates '<list or ZERO>' --residual '<one sentence>' --verdict"
        echo "> CLEAR|EDGE-NAMED|UNABLE [--edges '<name>[;<name>]']\`. EDGE-NAMED names join JOINT-EDGES as"
        echo "> INTEGRATOR-JUDGMENT edges (resolve like mechanical edges). NO LLM stamps CLEAR — a model may only"
        echo "> hand the integrator a candidate list to sign (§2.3 NOT)."
        echo "<!-- SEMANTIC-HUNT-EMPTY -->"
        echo
        echo "## BRIEFING (grounded alternatives for any contestable member)"
        echo "- (integrator, as needed.)"
        echo
        echo "## DECISION LINE (operator — exactly one; C-RATIFICATION-PACKET §3) + RATIONALE CLASS (§4)"
        echo "<!-- RATIFICATION-EMPTY -->"
        echo
        echo "## POST-DECISION"
        echo "- merge order executed (if -WITH-SEQUENCE): —"
        echo "- auditor reproduction ref: —"
    } > "$packet"

    # Mark included members `evaluated` in the ledger.
    local ledger="$root/PENDING-SET.md" id
    for id in "${IDS[@]}"; do
        awk -v id="$id" -v setid="$setid" 'BEGIN{FS=OFS="|"}
            /^\|[[:space:]]*[0-9]+[[:space:]]*\|/ {
                v=$3; gsub(/^[ \t]+|[ \t]+$/,"",v)
                if (v==id) { $7=" evaluated (into "setid") " }
            } {print}' "$ledger" > "$ledger.tmp" && mv "$ledger.tmp" "$ledger"
    done

    echo "assembled $setid: ${#IDS[@]} member(s), ${#EDGES[@]} mechanical joint edge(s). Packet: _ratification/$setid.md"
    [[ ${#EDGES[@]} -gt 0 ]] && echo "  ⚠ ${#EDGES[@]} joint edge(s) UNRESOLVED — HALT for pair/set ratification (resolve each before ratify)."
    return 0
}

# The §2.16 NOT-RUN line: one text, written into the assembled packet and printed at the ratify skip site.
RECEIPT_UNIQ_NOT_RUN="receipt-uniqueness (§2.16): NOT-RUN (scripts/receipt-ledger.py absent; P1.8 not built)"

cmd_assess() {
    resolve_foundation
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "assess: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "assess: no packet $setid."
    local text="" file="" recut=0
    while [[ $# -gt 0 ]]; do case "$1" in
        --text)  need_val $# "--text" "${2:-}"; text="${2:-}"; shift 2 ;;
        --file)  need_val $# "--file" "${2:-}"; file="${2:-}"; shift 2 ;;
        --recut) recut=1; shift ;;
        *) die "assess: unknown arg '$1'." ;;
    esac; done
    [[ -z "$text" && -n "$file" ]] && { [[ -f "$file" ]] || die "assess: --file not found."; text="$(cat "$file")"; }
    [[ -n "${text// /}" ]] || die "REFUSED — assessment text is empty (fail-closed; the integrator agent must assess logic/evidence/live-state/invariants)."

    # === a WRITE TOOL MUST NOT REPORT SUCCESS FOR A ZERO-BYTE CHANGE (inv #5). ===
    # The pre-cure `assess` replaced ONLY the `<!-- ASSESSMENT-EMPTY -->` marker; on a packet whose slot
    # was already filled the awk passed every line through UNCHANGED and the command still printed
    # "assessed … (ASSESSMENT slot filled)." A seat that ran it to correct a STALE-at-HEAD packet and
    # trusted that line would ratify against stale evidence while holding output saying it had not.
    local has_marker=0
    grep -q '<!-- ASSESSMENT-EMPTY -->' "$packet" && has_marker=1

    # A RATIFIED packet is NEVER edited in place — re-cut is a PRE-ratify repair only.
    if [[ "$recut" -eq 1 ]] && grep -qE '^- decision: ' "$packet"; then
        halt "assess --recut REFUSED on a RATIFIED packet $setid — a ratified packet is never repaired in place. Correct by RE-ASSEMBLY."
    fi
    # (a) filled slot, no --recut => HALT. Never a silent no-op wearing a success line.
    if [[ "$has_marker" -eq 0 && "$recut" -eq 0 ]]; then
        halt "assess: ASSESSMENT slot is ALREADY FILLED in $setid — refusing a silent no-op (inv #5).
  To correct a STALE-at-HEAD assessment, APPEND a dated re-cut instead:
    ratify.sh assess $setid --recut --text '<HEAD-true narration + citations>'
  The original assessment and every dated CONFORMANCE evidence line stay BYTE-UNCHANGED."
    fi

    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    local before_sha after_sha
    before_sha="$(shasum -a 256 "$packet" | awk '{print $1}')"

    if [[ "$has_marker" -eq 1 ]]; then
        # (c) EMPTY slot — unchanged behavior.
        # NOTE (SET-0003 tooling fix): pass the (possibly MULTI-LINE) body via the ENVIRONMENT, read with
        # ENVIRON[] — NOT `awk -v body="$text"`. `-v` runs the value through awk's escape-sequence processor
        # and macOS/BSD awk aborts on an embedded newline ("newline in string"); ENVIRON[] carries arbitrary
        # multi-line text verbatim on both BSD and GNU awk. `ts` stays a safe single-line `-v`.
        body="$text" awk -v ts="$now" '
            /<!-- ASSESSMENT-EMPTY -->/ { print "- assessed-at: " ts; print ""; print ENVIRON["body"]; next } {print}
        ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
    else
        # (b) --recut — APPEND-ONLY, at the END of the INTEGRATOR ASSESSMENT section. Nothing above is
        # rewritten: the original assessment is retained verbatim and the dated CONFORMANCE evidence
        # lines (whose bytes feed the ratify gate's verdict parser) are never touched.
        body="$text" awk -v ts="$now" '
            BEGIN { inas=0; done=0 }
            /^## INTEGRATOR ASSESSMENT/ { inas=1; print; next }
            inas && /^## / && !done {
                print "";
                print "### LIVE-STATE RE-CUT — " ts " (`assess --recut`)";
                print "> **APPEND-ONLY.** The original assessment above and every dated CONFORMANCE evidence line are";
                print "> **byte-unchanged**. This block SUPERSEDES the narration above as to LIVE STATE only.";
                print "";
                print ENVIRON["body"];
                print "";
                done=1; inas=0; print; next
            }
            { print }
            END {
                if (inas && !done) {
                    print "";
                    print "### LIVE-STATE RE-CUT — " ts " (`assess --recut`)";
                    print "> **APPEND-ONLY.** The original assessment above and every dated CONFORMANCE evidence line are";
                    print "> **byte-unchanged**. This block SUPERSEDES the narration above as to LIVE STATE only.";
                    print "";
                    print ENVIRON["body"];
                }
            }
        ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
    fi

    # === THE GENERALIZED INVARIANT: success is emitted ONLY after a VERIFIED mutation. ===
    after_sha="$(shasum -a 256 "$packet" | awk '{print $1}')"
    if [[ "$before_sha" == "$after_sha" ]]; then
        halt "assess: ZERO-BYTE CHANGE on $setid — the packet is byte-identical before and after. REFUSING to print a success line for a write that did not happen (inv #5 halt-loud over silent-degradation)."
    fi
    if [[ "$has_marker" -eq 1 ]]; then
        echo "assessed $setid (ASSESSMENT slot filled; sha ${before_sha:0:12} -> ${after_sha:0:12})."
    else
        echo "re-cut $setid (dated LIVE-STATE RE-CUT block APPENDED; original assessment + CONFORMANCE lines byte-unchanged; sha ${before_sha:0:12} -> ${after_sha:0:12})."
    fi

    # === ARMING, PRODUCER HALF (C-SET-AUTHORIZATION; spec §3 "evaluate at assembly/pre-commit … recorded in
    # the packet"). The gate now RUNS on the live assess path instead of waiting for a human to think
    # of it. Non-fatal here BY DESIGN: assess's job is to produce evidence, not to decide — a FAIL is a
    # legitimate, expected verdict meaning "this set takes the operator's pen", and it must be RECORDED
    # rather than used to abort the assessment that documents it. The refusal lives at the close.
    bc_record "$packet" "$setid"
}

# DELTA (2): cmd_ratify BUILT UP to the CLOSED 5-state taxonomy (C-RATIFICATION-PACKET §3/§5).
# GMAA hardcodes `decision: RATIFIED`; our packet supports 5 states + §4 rationale class. The
# per-member PROSE dispositions (which member retained/dropped in AMENDED, alternatives in REJECTED)
# live in the packet's human-filled ASSESSMENT/BRIEFING slots — the SCRIPT wires the decision line +
# the state-appropriate ledger status + the binding invariants (unresolved-edge blocks only the MERGE
# decisions; AMENDED = SUBSET-RULE re-assembly; HELD needs a NAMED trigger; REJECTED → RETURNED).
cmd_ratify() {
    resolve_foundation   # runs in foundation's worktree; the operator drives the pen (§5 INDEPENDENCE)
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "ratify: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "ratify: no packet $setid."
    local by="" decision="RATIFIED" rclass="" sequence="" trigger="" standing=0
    while [[ $# -gt 0 ]]; do case "$1" in
        --by)              need_val $# "--by" "${2:-}";              by="${2:-}";       shift 2 ;;
        --decision)        need_val $# "--decision" "${2:-}";        decision="${2:-}"; shift 2 ;;
        --rationale-class) need_val $# "--rationale-class" "${2:-}"; rclass="${2:-}";   shift 2 ;;
        --sequence)        need_val $# "--sequence" "${2:-}";        sequence="${2:-}"; shift 2 ;;
        --trigger)         need_val $# "--trigger" "${2:-}";         trigger="${2:-}";  shift 2 ;;
        --standing-class)  standing=1;        shift   ;;
        *) die "ratify: unknown arg '$1'." ;;
    esac; done
    # INDEPENDENCE (§5): the pen is a person — UNLESS the set is BUILD-CLASS, where the person already
    # signed, once, at the CLASS level (operator grant; spec §5). That grant is the human
    # authorization §5 requires; the per-set control is then the MECHANICAL predicate, verified live below.
    if [[ "$standing" -eq 1 ]]; then
        # ⛔ MUTUALLY EXCLUSIVE, and the refusal is the point: a human pen and a pen-free class close are
        #    two DIFFERENT authorizations. Accepting both would let a standing-class close wear a person's
        #    name — exactly the misattribution the §4 honesty rider exists to prevent.
        [[ -z "${by// /}" ]] || die "ratify: --standing-class and --by are MUTUALLY EXCLUSIVE. --standing-class closes under the operator's CLASS grant with NO per-set pen; --by records a PERSON's pen. Pick the one that is true."
        # A pen-free close is available for the MERGE decision only. AMENDED/HELD/REJECTED are judgments
        # about content; the standing class authorizes a mechanical predicate, never a judgment.
        [[ "$decision" == "RATIFIED" ]] || die "ratify: --standing-class supports --decision RATIFIED only (got '$decision'). AMENDED/HELD/REJECTED are JUDGMENTS about content — the standing class authorizes a mechanical predicate, not a judgment. Those take the operator's pen."
        # The rationale for a class close is in-band BY CONSTRUCTION: it is resolvable from the store
        # (the gate's exit code + the recorded class grant). OUT-OF-BAND would be a false claim.
        case "$rclass" in
            ""|in-band) rclass="in-band" ;;
            *) die "ratify: --standing-class is in-band BY CONSTRUCTION (the rationale is the gate's exit code + the §5 class grant, both resolvable from the store); got --rationale-class '$rclass'." ;;
        esac
    else
        [[ -n "${by// /}" ]] || die "ratify: --by '<human ratifier>' is required (the pen is a person, C-RATIFICATION-PACKET §5 INDEPENDENCE)."
        # §4: rationale class recorded on ALL outcomes (in-band = resolvable from SoR; OUT-OF-BAND = decided outside the store).
        case "$rclass" in
            in-band|OUT-OF-BAND) : ;;
            *) die "ratify: --rationale-class {in-band|OUT-OF-BAND} is required (C-RATIFICATION-PACKET §4 — recorded on every outcome)." ;;
        esac
    fi
    # §3 CLOSED taxonomy — never a bare no.
    case "$decision" in
        RATIFIED|RATIFIED-WITH-SEQUENCE|AMENDED|HELD|REJECTED) : ;;
        *) die "ratify: --decision must be one of the closed set {RATIFIED|RATIFIED-WITH-SEQUENCE|AMENDED|HELD|REJECTED} (C-RATIFICATION-PACKET §3)." ;;
    esac
    # REFUSE if the assessment slot is still empty (canon §10: the agent assesses before the human decides — ALL outcomes).
    grep -q '<!-- ASSESSMENT-EMPTY -->' "$packet" && halt "assessment slot is EMPTY — run \`ratify.sh assess $setid\` first (canon §10: the agent assesses before the human ratifies)."
    # Per-decision preconditions.
    local extra=""
    case "$decision" in
        RATIFIED|RATIFIED-WITH-SEQUENCE)
            # === RULING 2A — the RESOLUTION CONTRACT. An edge is RESOLVED iff BOTH:
            #     (1) its prefix is flipped `- UNRESOLVED · ` -> `- RESOLVED · `, AND
            #     (2) it carries a following `resolution: <rationale>` line (before the next `^- ` edge
            #         or `^## ` section).
            #     The gate enforces STRUCTURE, two checks (packet philosophy: "the gate reads STRUCTURE,
            #     never intent"). Mechanism enforces structure; the OPERATOR judges the content.
            #     (AMENDED/HELD/REJECTED are the CORRECT responses to unresolved edges — they do NOT refuse.)
            # --- (i) REFUSE on any remaining UNRESOLVED edge. (Pre-existing check; correct, kept verbatim.) ---
            if grep -qE '^- UNRESOLVED · ' "$packet"; then
                halt "unresolved joint edge(s) in $setid — resolve each (flip the \`- UNRESOLVED ·\` prefix to \`- RESOLVED ·\` AND add a following \`resolution:\` line), or choose --decision AMENDED (SUBSET RULE = new set) / HELD / REJECTED. A merge decision cannot stand over an unresolved edge."
            fi
            # --- (ii) NEW (RULING 2A): REFUSE on a RESOLVED edge with NO following `resolution:` line. ---
            #     Closes the paper-over hole: a bare prefix-flip with no recorded WHY. You cannot mark an
            #     edge resolved without a rationale the operator ratifies against. Scans forward from each
            #     `- RESOLVED · ` line to the next `^- ` or `^## ` boundary looking for `resolution:`.
            local _bare
            _bare="$(awk '
                # NOTE: a consecutive RESOLVED edge must FLUSH the previous one first — otherwise
                # `next` drops an un-rationalized edge silently (fail-OPEN; caught at .tmp/gate_probe.sh case E).
                /^- RESOLVED · / { if (seeking && !found) print edge; edge=$0; seeking=1; found=0; next }
                seeking && /^resolution:|^[[:space:]]+resolution:/ { found=1; seeking=0; next }
                seeking && (/^- / || /^## /) { if (!found) print edge; seeking=0 }
                END { if (seeking && !found) print edge }
            ' "$packet")"
            if [[ -n "$_bare" ]]; then
                halt "RESOLVED joint edge(s) in $setid carry NO following \`resolution:\` line (RULING 2A — a prefix flip without a recorded rationale is a rubber-stamp; the operator ratifies against the WHY, not the label):
$_bare"
            fi
            # === REQ-HUNT (§2.3 Layer C) — the SEMANTIC HUNT slot is UNSKIPPABLE for a MERGE decision. ===
            # 'Mechanical JOINT-EDGES = NONE' does NOT license a merge (canon §13); the slot carries the residual
            # the detector cannot. REFUSE on: missing section, unfilled block, verdict UNABLE, or CLEAR asserted
            # with 'candidates considered: ZERO' + no method (an assertion, not a hunt — DISC-ABSENCE-OF-RECORD).
            grep -q '^## SEMANTIC HUNT' "$packet" || halt "packet $setid predates the REQ-HUNT semantic-hunt slot (no ## SEMANTIC HUNT section) — re-assemble (fail-closed §2.3)."
            if grep -q '<!-- SEMANTIC-HUNT-EMPTY -->' "$packet"; then
                halt "SEMANTIC HUNT slot is EMPTY in $setid — run \`ratify.sh hunt $setid --method … --candidates … --residual … --verdict CLEAR|EDGE-NAMED|UNABLE\` first (canon §13: 'none found' is a claim; §2.3 Layer C). Or choose --decision AMENDED|HELD|REJECTED."
            fi
            # === LATEST-WINS: read the LAST block in the section, not the
            #     first. A filled slot may carry one or more `### RE-HUNT #N` blocks appended after the
            #     original (`hunt` never edits the original in place); the prior code took `head -1`, which
            #     reads the FIRST block — the bug this cures. Print which block was read (§2.2: "assess/ratify
            #     print which block they read") so an operator/auditor can see it without opening the packet.
            local _hb hv hcand hmeth hblk hat
            _hb="$(hunt_latest_block "$packet")"
            hblk="$(printf '%s\n' "$_hb" | sed -n 's/^BLOCK\t//p')"
            hat="$(printf '%s\n' "$_hb" | sed -n 's/^HUNT_AT\t//p')"
            hv="$(printf '%s\n' "$_hb" | sed -n 's/^VERDICT\t//p')"
            hcand="$(printf '%s\n' "$_hb" | sed -n 's/^CANDIDATES\t//p')"
            hmeth="$(printf '%s\n' "$_hb" | sed -n 's/^METHOD\t//p')"
            echo "ratify: SEMANTIC HUNT — reading LATEST block for $setid: $hblk (hunt-at: ${hat:-<none>}; verdict: ${hv:-<none>}) [§2.2 latest-wins]"
            case "$hv" in
                CLEAR)
                    if [[ "${hcand//[[:space:]]/}" == "ZERO" && ( -z "${hmeth//[[:space:]]/}" || "${hmeth//[[:space:]]/}" == "—" ) ]]; then
                        halt "SEMANTIC HUNT verdict CLEAR with 'candidates considered: ZERO' and NO method in $setid — an assertion, not a hunt (DISC-ABSENCE-OF-RECORD applied to the hunt itself; §2.3). Record the method (what was grepped / which SoR indexes opened), name the edges (EDGE-NAMED), or choose AMENDED|HELD."
                    fi
                    ;;
                EDGE-NAMED)
                    # The named edges are appended to JOINT-EDGES as UNRESOLVED — the unresolved-edge refuse
                    # above already blocks a MERGE until each carries a resolution: line. Nothing extra here.
                    : ;;
                UNABLE|""|—)
                    halt "SEMANTIC HUNT verdict is '${hv:-<missing>}' in $setid — a MERGE decision REFUSES on UNABLE/missing (§2.3 Layer C, same fail-closed shape as an empty assessment). Complete the hunt (CLEAR with method, or EDGE-NAMED), or choose --decision AMENDED|HELD|REJECTED."
                    ;;
                *)
                    halt "SEMANTIC HUNT verdict '$hv' is not in the closed set {CLEAR|EDGE-NAMED|UNABLE} in $setid (§2.3). Re-run \`ratify.sh hunt\`."
                    ;;
            esac
            # === U4B CONFORMANCE (§2.1) — a MERGE decision REQUIRES verdict: PASS for EVERY member. ===
            # Fail-closed + NON-OVERRIDABLE; same shape as the unresolved-edge / empty-assessment
            # refusals. A non-PASS verdict (FAIL or MISSING) is answered by AMENDED/HELD/REJECTED (the §1 R5
            # return path), NOT by an override. AMENDED/HELD/REJECTED do NOT require conformance PASS.
            grep -q '^## CONFORMANCE' "$packet" || halt "packet $setid predates the U4B conformance gate (no CONFORMANCE section) — re-assemble (fail-closed §2.1)."
            local -a NONPASS=(); local mid v
            while IFS= read -r mid; do
                [[ -z "$mid" ]] && continue
                v="$(awk -v id="$mid" '/^## CONFORMANCE/{c=1;next} /^## /{c=0} c && index($0,"- " id " ·")==1 {sub(/.*verdict:[[:space:]]*/,""); sub(/[[:space:]].*/,""); print; exit}' "$packet")"
                [[ "$v" == "PASS" ]] || NONPASS+=("$mid=${v:-MISSING}")
            done < <(awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$packet" | sed -n 's/^- \([^ ]*\) .*/\1/p')
            if [[ ${#NONPASS[@]} -gt 0 ]]; then
                halt "U4B conformance NOT satisfied for $setid (§2.1) — a MERGE decision REQUIRES verdict: PASS for EVERY member; got: ${NONPASS[*]}. Produce verdicts (ratify.sh conformance-check / conformance), or choose --decision AMENDED|HELD|REJECTED (the R5 return path for a non-conforming member). Non-overridable."
            fi
            if [[ "$decision" == "RATIFIED-WITH-SEQUENCE" ]]; then
                [[ -n "${sequence// /}" ]] || die "ratify: --decision RATIFIED-WITH-SEQUENCE requires --sequence '<member order>' (§3: merges in the stated order, no other change)."
                extra="- merge sequence: $sequence"
            fi
            ;;
        HELD)
            # §3: HELD → PARKED against a NAMED trigger; never limbo.
            [[ -n "${trigger// /}" ]] || die "ratify: --decision HELD requires --trigger '<named event/date>' (§3: parked against a NAMED trigger; re-surfaces on it; never limbo)."
            extra="- held trigger: $trigger"
            ;;
        AMENDED)
            # §5 SUBSET RULE: an AMENDED set is a NEW set — retained members re-enter assembly + JOINT
            # re-validation. Line-item ratification does not exist. The script records the decision +
            # the per-member dispositions (authored in ASSESSMENT/BRIEFING); it does NOT merge.
            extra="- SUBSET RULE (§5): AMENDED = a NEW set. Retained members must be re-assembled (\`ratify.sh assemble\`) + JOINT re-validated before ANY merge. Per-member dispositions are in INTEGRATOR ASSESSMENT / BRIEFING. No member merges on this line."
            ;;
        REJECTED)
            # §3: per-member dispositions + rationale + the briefing's grounded alternatives. Members → RETURNED
            # (NO-CHERRY-PICK, §5: RETURNED content reaches main ONLY inside a future ratified set).
            extra="- REJECTED (§3/§5): per-member dispositions + grounded alternatives are in INTEGRATOR ASSESSMENT / BRIEFING. Members → RETURNED (NO-CHERRY-PICK: a returned branch re-enters main ONLY inside a future ratified set)."
            ;;
    esac
    # =================================================================================================
    # === ARMING, CONSUMER HALF — THE PEN-FREE CLOSE (C-SET-AUTHORIZATION; spec §5) ===========
    # =================================================================================================
    # This is the ONLY path in the system that closes a set with NO human pen, and it is reachable ONLY
    # through an affirmative rc=0 from the real gate, evaluated RIGHT NOW, on this packet.
    #
    # ⛔ IT RUNS LAST, AND THAT IS DELIBERATE. Every precondition above — assessment filled, no unresolved
    #    joint edge, semantic hunt complete, U4B conformance PASS on every member — has ALREADY run by the
    #    time we get here. Being build-class buys a set NO exemption from any of them; it decides one
    #    question only: whether the closing authorization is the operator's pen or his standing class grant.
    #
    # ⛔ THE RECORDED VERDICT IS NEVER THE AUTHORITY. The ## BUILD-CLASS block is evidence AT ITS
    #    TIMESTAMP. Between assess and close the footprint can change, the predicate data can change, and
    #    HEAD can move. A close that trusted the recorded line would be precisely the failure this program
    #    keeps paying for — a record true when written, stale when read, and acted on downstream. So the
    #    gate runs LIVE here and ITS EXIT CODE decides. If the two disagree, the live one wins and says so.
    if [[ "$standing" -eq 1 ]]; then
        grep -q '^## BUILD-CLASS' "$packet" || halt "$setid has no '## BUILD-CLASS' section — it predates the §3 gate slot and CANNOT close under the standing class (fail-closed, same shape as the CONFORMANCE/SEMANTIC-HUNT pre-date refusals). Re-assemble, or close it with the operator's pen (--by)."
        local bc_out bc_rc bc_now bc_head
        bc_now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"; bc_head="$(git rev-parse --short HEAD 2>/dev/null || echo UNKNOWN)"
        bc_out="$(bc_gate "$packet" 2>&1)"; bc_rc=$?
        echo "── BUILD-CLASS GATE · LIVE AT CLOSE · $bc_now · HEAD $bc_head ──"
        printf '%s\n' "$bc_out"
        case "$bc_rc" in
            0) echo "── gate rc=0 ⇒ BUILD-CLASS: closing under the standing class, no operator pen ──" ;;
            1) halt "BUILD-CLASS GATE REFUSED $setid at close (gate rc=1) — a named P failed, so this set is NOT build-class and CANNOT close pen-free. The gate's own verdict:
$bc_out
⇒ OPERATOR PEN REQUIRED. Re-run as: ratify.sh ratify $setid --by '<operator>' --rationale-class in-band" ;;
            *) halt "BUILD-CLASS GATE UNEVALUABLE on $setid at close (gate rc=$bc_rc) — fail-closed. An unevaluable predicate is NOT a pass (spec §3). The gate's own output:
$bc_out
⇒ OPERATOR PEN REQUIRED." ;;
        esac
        by="BUILD-CLASS STANDING CLASS (no per-set pen) — operator grant \`ratified\` 2026-09-16T13:43:32Z, spec §5"
        extra="${extra:+$extra
}- closed under: BUILD-CLASS STANDING-APPROVAL CLASS (spec §5). Gate rc=0 VERIFIED LIVE at close ($bc_now, HEAD \`$bc_head\`) against \`scripts/build-class-check.sh\` — NOT read from the recorded verdict.
- §4 HONESTY RIDER: this close carries NO per-set human review and claims none. The operator's authorization is the CLASS grant, exercised once, per spec §5 (operator grant 2026-09-16T13:43:32Z). The per-set controls are the mechanical P1–P4 predicate and the assembler's evidence.
- every other merge precondition (assessment · joint edges · semantic hunt · U4B conformance) was satisfied independently; build-class buys no exemption from any of them."
    fi
    _ll="$(bash "$root/scripts/seat-keys.sh" login-line)" || halt "login not recorded: the process login is unresolvable (SEAT-KEYS line above); the packet keeps its RATIFICATION-EMPTY marker."; [[ "$standing" -eq 1 ]] || bash "$root/scripts/seat-keys.sh" login-tie || halt "pen refused: the OS login does not tie to the registry apex row (SEAT-KEYS line above); the packet keeps its RATIFICATION-EMPTY marker."
    # === RECEIPT UNIQUENESS (§2.16) — no-op until P1.8 lifts receipt-ledger.py ===
    # Every evidence receipt CITED BY A MEMBER must be unique in the spine ledger by (id, content_sha):
    # a duplicate id with differing content means one member could discharge on another's receipt.
    local -a CITED=() m
    while IFS= read -r m; do [[ -z "$m" ]] && continue
        while IFS= read -r r; do [[ -n "$r" ]] && CITED+=("$r"); done < <(member_receipts "$m")
    done < <(awk '/^## MEMBERS/{x=1;next} /^## /{x=0} x' "$packet" | sed -n 's/^- \([^ ·]*\) .*/\1/p')
    if [[ ${#CITED[@]} -gt 0 && -x "$root/scripts/receipt-ledger.py" ]] && command -v python3 >/dev/null 2>&1; then
        python3 "$root/scripts/receipt-ledger.py" check-unique "$root" "${CITED[@]}" \
            || halt "member-cited receipt(s) are NOT unique in the spine ledger (§2.16) — resolve the collision before ratifying $setid."
    elif [[ ! -x "$root/scripts/receipt-ledger.py" ]]; then
        echo "$RECEIPT_UNIQ_NOT_RUN"
    fi
    local psha; psha="$(shasum -a 256 "$packet" | awk '{print $1}')"
    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    # Stamp the §3 DECISION line + §4 rationale class into the RATIFICATION-EMPTY slot.
    #
    # ⚠ `extra` RIDES THE ENVIRONMENT, NEVER `-v` — and this file already knew that. cmd_assess carries
    #   the identical note (SET-0003 tooling fix): `-v` runs the value through awk's escape-sequence
    #   processor and macOS/BSD awk ABORTS on an embedded newline ("newline in string"). `extra` was
    #   single-line for every pre-existing decision state, so the trap sat here unreachable until the
    #   the standing-class close gave it a multi-line value — at which point awk died at parse time,
    #   the `&&` short-circuited the `mv`, the packet kept its `<!-- RATIFICATION-EMPTY -->` marker, and
    #   the function printed "RATIFIED …" and returned 0. CAUGHT AT THE ENFORCER during the arming
    #   both-polarity proof, on the first live green pole — not by reading the code.
    rlogin="$_ll" extra="$extra" awk -v dec="$decision" -v who="$by" -v ts="$now" -v sha="$psha" -v rc="$rclass" '
        /<!-- RATIFICATION-EMPTY -->/ {
            print "- decision: " dec
            print "- ratified-by: " who; print ENVIRON["rlogin"]
            print "- at: " ts
            print "- packet sha (pre-stamp): " sha
            print "- rationale class: " rc
            if (ENVIRON["extra"] != "") print ENVIRON["extra"]
            next
        } {print}
    ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"

    # === THE GENERALIZED INVARIANT, NOW ON THE RATIFY PATH TOO (inv #5). =============
    # cmd_assess has carried a before/after-sha verification since: "a WRITE TOOL MUST NOT
    # REPORT SUCCESS FOR A ZERO-BYTE CHANGE." The RATIFY path — the single most load-bearing write in
    # the system, the one that authorizes a merge — never had it. The failure above proves why it must:
    # a dead awk emitted a clean "RATIFIED SET-9001 …" line over a packet that was never stamped, and
    # execution then ran ON into the PENDING-SET update UNGUARDED. ⚠ MEASURED, NOT INFERRED: in that run
    # ZERO ledger rows actually moved (`grep -c 'ratified-in SET-9001'` → 0) — the proof fixture had no
    # rows evaluated into that set, so there was nothing to flip. The hazard is the UNGUARDED CONTROL
    # FLOW, not a flip I observed: on a real set, whose rows DO match, the same dead awk would have left
    # the ledger reading `ratified-in` behind a decision line that does not exist.
    # Fail-closed on BOTH the byte-level fact (the file moved) and the semantic one (the line is there).
    local stamped_sha
    stamped_sha="$(shasum -a 256 "$packet" | awk '{print $1}')"
    if [[ "$psha" == "$stamped_sha" ]]; then
        halt "ZERO-BYTE STAMP on $setid — the packet is byte-identical before and after the decision write. REFUSING to report a ratification that did not happen (inv #5 halt-loud over silent-degradation). The PENDING-SET ledger has NOT been touched."
    fi
    grep -qE "^- decision: $decision" "$packet" || halt "STAMP VERIFICATION FAILED on $setid — the packet changed but carries no '- decision: $decision' line. REFUSING to report success on an unverifiable write (inv #5). Inspect $packet before re-running."

    # Ledger status update per decision (only the evaluated-into-THIS-set rows).
    local ledger="$root/PENDING-SET.md" newstat
    case "$decision" in
        RATIFIED|RATIFIED-WITH-SEQUENCE) newstat="ratified-in $setid" ;;
        HELD)                            newstat="HELD (trigger: $trigger)" ;;
        AMENDED)                         newstat="pending" ;;   # SUBSET RULE: back to pending for re-assembly as a NEW set
        REJECTED)                        newstat="RETURNED" ;;  # NO-CHERRY-PICK; branch preserved
    esac
    awk -v setid="$setid" -v ns="$newstat" 'BEGIN{FS=OFS="|"}
        /^\|[[:space:]]*[0-9]+[[:space:]]*\|/ {
            v=$7; gsub(/^[ \t]+|[ \t]+$/,"",v)
            if (index(v, "evaluated (into " setid ")") == 1) { $7=" "ns" " }
        } {print}' "$ledger" > "$ledger.tmp" && mv "$ledger.tmp" "$ledger"

    echo "$decision $setid by '$by' (rationale: $rclass; packet sha $psha). Members → $newstat."
    case "$decision" in
        AMENDED)  echo "  ⚠ SUBSET RULE (§5): re-assemble the retained members as a NEW set before any merge." ;;
        REJECTED) echo "  ⚠ NO-CHERRY-PICK (§5): returned member branches re-enter main ONLY inside a future ratified set." ;;
        HELD)     echo "  ⏸ PARKED against trigger: $trigger (re-surfaces on it; never limbo)." ;;
    esac
    # Explicit success exit (finding 6's corrected principle applied here too):
    # every case above reaches here having already halted/died on any refusal path, so this is the one
    # true success return — stated, not inherited from the last case arm's incidental exit code.
    return 0
}

# === U4B (§2.1) — record a per-member conformance verdict into the packet's CONFORMANCE section. ===
# Shared by cmd_conformance (manual/judgment) + cmd_conformance_check (structured). Fail-closed: the
# member MUST already exist in the CONFORMANCE section (seeded by assemble) — else die.
record_conformance() {
    local packet="$1" member="$2" verdict="$3" method="$4" evidence="$5" now rc
    now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    awk -v id="$member" -v v="$verdict" -v mth="$method" -v ev="$evidence" -v ts="$now" '
        /^## CONFORMANCE/{c=1; print; next}
        /^## /{c=0}
        c && index($0, "- " id " ·")==1 {
            print "- " id " · verdict: " v " · method: " mth " · evidence: " ev " · at: " ts; done=1; next
        }
        {print}
        END{ if(!done) exit 9 }
    ' "$packet" > "$packet.tmp"; rc=$?
    if [[ $rc -eq 9 ]]; then rm -f "$packet.tmp"; die "conformance: member '$member' has no line in the CONFORMANCE section of $(basename "$packet" .md) (re-assemble; fail-closed)."; fi
    mv "$packet.tmp" "$packet"
}

# conformance SET-NNNN <member> --verdict PASS|FAIL --method structured|judgment --evidence '…'
# Records a verdict directly — the path for a BOUNDED JUDGMENT at the edge (prose criterion; SANCTIONED
# §2.1) or an out-of-band structured result. A verdict is an evidence-first claim (§L) → --evidence required.
cmd_conformance() {
    resolve_foundation
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "conformance: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "conformance: no packet $setid."
    local member="${1:-}"; shift || true
    [[ -n "$member" ]] || die "conformance: <member-id> required."
    local verdict="" method="" evidence=""
    while [[ $# -gt 0 ]]; do case "$1" in
        --verdict)  need_val $# "--verdict" "${2:-}";  verdict="${2:-}";  shift 2 ;;
        --method)   need_val $# "--method" "${2:-}";   method="${2:-}";   shift 2 ;;
        --evidence) need_val $# "--evidence" "${2:-}"; evidence="${2:-}"; shift 2 ;;
        *) die "conformance: unknown arg '$1'." ;;
    esac; done
    case "$verdict" in PASS|FAIL) : ;; *) die "conformance: --verdict {PASS|FAIL} required." ;; esac
    case "$method"  in structured|judgment) : ;; *) die "conformance: --method {structured|judgment} required (§2.1)." ;; esac
    [[ -n "${evidence// /}" ]] || die "conformance: --evidence required (§L: a verdict is an evidence-first claim, never asserted)."
    grep -q '^## CONFORMANCE' "$packet" || die "conformance: packet $setid has no CONFORMANCE section — re-assemble."
    awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$packet" | sed -n 's/^- \([^ ]*\) .*/\1/p' | grep -qx "$member" \
        || die "conformance: '$member' is not a member of $setid."
    record_conformance "$packet" "$member" "$verdict" "$method" "$evidence"
    echo "conformance $setid/$member: verdict=$verdict method=$method recorded."
}

# conformance-check SET-NNNN <member> [--criteria FILE] [--no-record]
# The STRUCTURED checker (no LLM): evaluates the member's machine-checkable acceptance criteria and
# records the verdict. Criteria file (architect-owned) default _ratification/criteria/<member>.md, one
# criterion per line:  - [exists] <path> | [absent] <path> | [grep] <ERE> :: <path> | [test] <shell> |
# [judgment] <prose>.  A [judgment] criterion is NOT auto-PASSed — it needs `conformance … --method
# judgment` (fail-closed §2.1). Absent/empty criteria file → HALT (a member with no checkable criteria
# cannot PASS; §2.1 corollary).
# SUP_FLOOR_AWK -- the weakest top-level alternative's longest guaranteed literal run.
#   UNIT = CHARACTERS (code points), not bytes (finding 1): bwk awk is byte-based in every locale, so a
#   UTF-8 continuation byte (0x80-0xBF) adds nothing and a multibyte glyph counts ONE. Escapes, measured by a sweep of
#   all 62 single-char escapes on the runner grep (BSD grep 2.6.0, auditor 89fdceb4 F1): \d \D \w \W \s \S \b \B are
#   classes/assertions and \1-\9 backrefs, never a literal; \Q \E are zero-width quote markers; \xHH / \x{H..} is ONE
#   char; every other escape (\t \n \. \* …) is one literal char.
SUP_FLOOR_AWK='
function brk() { if (run > best[d]) best[d] = run; run = 0 }
BEGIN { for (k = 128; k < 192; k++) CONT = CONT sprintf("%c", k) }
{
  s = $0; n = length(s); d = 0; run = 0; best[0] = 0; alt[0] = 0; low = -1
  for (i = 1; i <= n; i++) {
    c = substr(s, i, 1)
    if (index(CONT, c)) continue                    # UTF-8 continuation byte: part of the char already counted
    if (c == "\\") {
      i++; e = substr(s, i, 1)
      if (index("dDwWsSbB<>`\047123456789", e)) brk()   # classes/assertions/backrefs, never a literal (6fdb681e F1, 89fdceb4 F1)
      else if (e == "Q" || e == "E") { }                # \Q…\E quote markers: zero-width, neither a char nor a break
      else if (e == "x") {                              # \xHH or \x{H..}: one char, however many bytes spell it
        if (substr(s, i+1, 1) == "{") { for (i++; i <= n && substr(s, i, 1) != "}"; i++); }
        else { for (h = 0; h < 2 && index("0123456789abcdefABCDEF", substr(s, i+1, 1)) && substr(s, i+1, 1) != ""; h++) i++ }
        run++
      }
      else run++
      continue
    }
    if (c == "[") {                                   # bracket expression: skip to its closing ]
      brk(); i++
      if (substr(s, i, 1) == "^") i++
      if (substr(s, i, 1) == "]") i++
      for (; i <= n; i++) {
        c2 = substr(s, i, 1)
        if (c2 == "[" && index(":.=", substr(s, i+1, 1))) { t = substr(s, i+1, 1); for (i += 2; i < n && !(substr(s, i, 1) == t && substr(s, i+1, 1) == "]"); i++); i++; continue }
        if (c2 == "]") break
      }
      continue
    }
    if (c == "{") { brk(); for (; i <= n && substr(s, i, 1) != "}"; i++); continue }
    if (c == "(") { brk(); d++; best[d] = 0; alt[d] = 0; continue }
    if (c == ")") { brk(); g = alt[d] ? 0 : best[d]; d--; if (d < 0) d = 0; if (g > best[d]) best[d] = g; continue }
    if (c == "|") { brk(); if (d > 0) { alt[d] = 1; continue } if (low < 0 || best[0] < low) low = best[0]; best[0] = 0; continue }
    if (index(".*+?^$", c)) { brk(); continue }
    run++
  }
  brk(); while (d > 0) { g = alt[d] ? 0 : best[d]; d--; if (g > best[d]) best[d] = g }
  if (low < 0 || best[0] < low) low = best[0]
  print low
}
'

cmd_conformance_check() {
    resolve_foundation
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "conformance-check: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "conformance-check: no packet $setid."
    local member="${1:-}"; shift || true
    [[ -n "$member" ]] || die "conformance-check: <member-id> required."
    local criteria="" record=1
    while [[ $# -gt 0 ]]; do case "$1" in
        --criteria)  need_val $# "--criteria" "${2:-}"; criteria="${2:-}"; shift 2 ;;
        --no-record) record=0;          shift   ;;
        *) die "conformance-check: unknown arg '$1'." ;;
    esac; done
    [[ -z "$criteria" ]] && criteria="$root/_ratification/criteria/${member}.md"
    [[ -f "$criteria" ]] || halt "conformance-check: NO acceptance-criteria file for '$member' at ${criteria#$root/} (§2.1 corollary — a member is NOT conform-checkable, and cannot PASS, without explicit checkable criteria; author them, or record a judgment verdict). Fail-closed."
    local pass=0 fail=0 judg=0 sup=0 n=0; local -a RESULTS=()
    local line type args sup_ref="" sup_car="" sup_pat="" sup_bad=""
    # SUPERSESSION MARKER. A `#` line directly above a
    #   criterion:  # SUPERSEDED-BY: _rulings/NNNN[ …] · CARRIER: <path> :: <ERE>[ · note]
    #   scores THAT criterion SUPERSEDED (not FAIL) only when the ruling file exists AND the carrier path matches the
    #   ERE — i.e. the pinned substance is proven to live at the carrier. A marker naming no carrier, an unresolved
    #   ruling, a carrier that does not match, or a marker with no criterion after it is a FAIL (0261 §3: a
    #   supersession with no carrier is a silent check-deletion). The criterion line itself is never edited.
    while IFS= read -r line; do
        line="${line#- }"; line="${line#"${line%%[![:space:]]*}"}"   # strip leading "- " + whitespace
        if [[ "$line" == "# SUPERSEDED-BY:"* ]]; then
            [[ -n "$sup_ref$sup_bad" ]] && { RESULTS+=("FAIL [superseded-marker] a marker with no criterion after it (${sup_ref:-malformed})"); fail=$((fail+1)); n=$((n+1)); }
            sup_bad=""; sup_ref="$(sed -nE 's/^# SUPERSEDED-BY:[[:space:]]*(_rulings\/[0-9]{4}).*/\1/p' <<<"$line")"
            sup_car="$(sed -nE 's/.* · CARRIER:[[:space:]]*([^[:space:]]+)[[:space:]]+::[[:space:]]+.*/\1/p' <<<"$line")"
            sup_pat="$(sed -nE 's/.* · CARRIER:[[:space:]]*[^[:space:]]+[[:space:]]+::[[:space:]]+(.*)$/\1/p' <<<"$line")"; sup_pat="${sup_pat%% · *}"
            [[ -z "$sup_ref" || -z "$sup_car" || -z "$sup_pat" ]] && { sup_bad="malformed: needs _rulings/NNNN · CARRIER: <path> :: <ERE>"; sup_ref=""; }
            continue
        fi
        [[ -z "${line// /}" || "${line:0:1}" == "#" ]] && continue
        type="$(sed -n 's/^\[\([a-z-]*\)\].*/\1/p' <<<"$line")"
        args="$(sed 's/^\[[a-z-]*\][[:space:]]*//' <<<"$line")"
        n=$((n+1))
        if [[ -n "$sup_bad" ]]; then RESULTS+=("FAIL [superseded-marker] $sup_bad — above [$type] $args"); fail=$((fail+1)); sup_bad=""; continue; fi
        if [[ -n "$sup_ref" ]]; then
            # CARRIER-ADEQUACY FLOOR, decided HERE at the
            #   earliest write (DISC-AUTHZ-INPUT-VALIDATED-AT-EARLIEST-WRITE). Whether the ERE pins the RIGHT substance stays
            #   at review + auditor (0264 §1(a), 0265 §1(i)); these three are only the mechanically decidable part.
            #   SUP_FLOOR_AWK option (a): the run is measured per top-level alternative and the WEAKEST one counts;
            #   bracket-expression chars never count; a group that alternates inside contributes no run (the same bypass one level down).
            local sup_lit; sup_lit="$(printf '%s\n' "$sup_pat" | awk "$SUP_FLOOR_AWK")"
            if [[ "$sup_car" == /* || "$sup_car" == *..* ]]; then RESULTS+=("FAIL [superseded-marker] carrier $sup_car is outside the repo (0264 §1(b)2) — above [$type] $args"); fail=$((fail+1))
            elif [[ "$sup_car" == _rulings/* ]]; then RESULTS+=("FAIL [superseded-marker] carrier $sup_car is a ruling record: archive-only is not an application (0260; 0264 §1(b)1) — above [$type] $args"); fail=$((fail+1))
            elif [[ "$sup_lit" -lt 12 ]]; then RESULTS+=("FAIL [superseded-marker] carrier ERE /$sup_pat/ has no literal run of >= 12 chars (longest $sup_lit in its weakest alternative; 0265 §1(ii), 0268) — above [$type] $args"); fail=$((fail+1))
            elif ! compgen -G "$root/${sup_ref}-*.md" >/dev/null; then RESULTS+=("FAIL [superseded-marker] ruling $sup_ref does not resolve — above [$type] $args"); fail=$((fail+1))
            elif grep -qE -- "$sup_pat" "$root/$sup_car" 2>/dev/null; then RESULTS+=("SUPERSEDED [$type] $args  ⇒ by $sup_ref · carrier $sup_car :: $sup_pat"); sup=$((sup+1))
            else RESULTS+=("FAIL [superseded-marker] carrier $sup_car does not carry /$sup_pat/ — above [$type] $args"); fail=$((fail+1)); fi
            sup_ref=""; continue
        fi
        case "$type" in
            exists) if [[ -e "$root/$args" ]]; then RESULTS+=("PASS [exists] $args"); pass=$((pass+1)); else RESULTS+=("FAIL [exists] $args"); fail=$((fail+1)); fi ;;
            absent) if [[ ! -e "$root/$args" ]]; then RESULTS+=("PASS [absent] $args"); pass=$((pass+1)); else RESULTS+=("FAIL [absent] $args"); fail=$((fail+1)); fi ;;
            grep)   local pat pth; pat="${args%% :: *}"; pth="${args##* :: }"
                    if grep -qE "$pat" "$root/$pth" 2>/dev/null; then RESULTS+=("PASS [grep] $pat :: $pth"); pass=$((pass+1)); else RESULTS+=("FAIL [grep] $pat :: $pth"); fail=$((fail+1)); fi ;;
            test)   if ( cd "$root" && eval "$args" ) >/dev/null 2>&1; then RESULTS+=("PASS [test] $args"); pass=$((pass+1)); else RESULTS+=("FAIL [test] $args"); fail=$((fail+1)); fi ;;
            judgment) RESULTS+=("JUDGMENT-REQUIRED [judgment] $args"); judg=$((judg+1)) ;;
            *)      RESULTS+=("FAIL [unknown-criterion-type:$type] $args"); fail=$((fail+1)) ;;
        esac
    done < "$criteria"
    [[ -n "$sup_ref$sup_bad" ]] && { RESULTS+=("FAIL [superseded-marker] a marker with no criterion after it (${sup_ref:-malformed})"); fail=$((fail+1)); n=$((n+1)); }
    [[ $n -gt 0 ]] || halt "conformance-check: criteria file ${criteria#$root/} has NO criteria (fail-closed §2.1)."
    # A member whose every criterion is superseded has no LIVE check left: FAIL, never a PASS on relocations alone.
    [[ $sup -gt 0 && $pass -eq 0 && $judg -eq 0 ]] && { RESULTS+=("FAIL [superseded-marker] every criterion is SUPERSEDED — no live check remains for this member"); fail=$((fail+1)); }
    echo "conformance-check $setid/$member: $n criterion(s) — PASS=$pass FAIL=$fail JUDGMENT-REQUIRED=$judg SUPERSEDED=$sup"
    local r; for r in "${RESULTS[@]}"; do echo "  - $r"; done
    local verdict method evidence
    if [[ $fail -gt 0 ]]; then
        verdict="FAIL"; method="structured"; evidence="structured $pass/$n PASS; $fail FAIL"
    elif [[ $judg -gt 0 ]]; then
        echo "  ⚠ $judg prose criterion(s) need a RECORDED bounded judgment (§2.1): ratify.sh conformance $setid $member --verdict PASS|FAIL --method judgment --evidence '…'. Verdict left non-PASS (fail-closed)."
        [[ "$record" -eq 1 ]] && record_conformance "$packet" "$member" "MISSING-JUDGMENT" "structured" "structured $pass/$((n-judg)) PASS; $judg judgment pending"
        return 0
    else
        verdict="PASS"; method="structured"; evidence="structured $pass/$n PASS$([[ $sup -gt 0 ]] && echo "; $sup SUPERSEDED (carrier-proven)")"
    fi
    [[ "$record" -eq 1 ]] && record_conformance "$packet" "$member" "$verdict" "$method" "$evidence"
    echo "  verdict: $verdict$([[ "$record" -eq 1 ]] && echo ' (recorded)')"
}

# === the ONE shared reader for the SEMANTIC HUNT section, so cmd_hunt's
#     own downgrade check and cmd_ratify's merge gate can never read two different blocks ("latest wins",
#     §2.2). A filled slot may carry the original block plus zero or more appended `### RE-HUNT #N · <ts> ·
#     by <lane>` blocks (never edited in place — annotate-not-overwrite); this walks the whole SEMANTIC HUNT
#     section once and keeps only the fields from the LAST block start it saw, emitting them tab-prefixed.
hunt_latest_block() {
    local packet="$1"
    awk '
        /^## SEMANTIC HUNT/ { insec=1; next }
        insec && /^## / { insec=0 }
        insec {
            if ($0 ~ /^### RE-HUNT #/) { blk=$0; hv=""; hm=""; hc=""; hat=""; next }
            if ($0 ~ /^- hunt-at:/)               { v=$0; sub(/^- hunt-at:[[:space:]]*/,"",v);               hat=v }
            if ($0 ~ /^- verdict:/)                { v=$0; sub(/^- verdict:[[:space:]]*/,"",v);                hv=v }
            if ($0 ~ /^- method:/)                 { v=$0; sub(/^- method:[[:space:]]*/,"",v);                 hm=v }
            if ($0 ~ /^- candidates considered:/)  { v=$0; sub(/^- candidates considered:[[:space:]]*/,"",v);  hc=v }
        }
        END {
            printf "BLOCK\t%s\n",      (blk=="" ? "(initial hunt block)" : blk)
            printf "HUNT_AT\t%s\n",    hat
            printf "VERDICT\t%s\n",    hv
            printf "METHOD\t%s\n",     hm
            printf "CANDIDATES\t%s\n", hc
        }
    ' "$packet"
}

# Count of `### RE-HUNT #N` blocks already appended under SEMANTIC HUNT (0 on a packet that has only the
# original block) — the next re-hunt's N is this count + 1.
hunt_rehunt_count() {
    local packet="$1"
    awk '
        /^## SEMANTIC HUNT/ { insec=1; next }
        insec && /^## / { insec=0 }
        insec && /^### RE-HUNT #/ { n++ }
        END { print n+0 }
    ' "$packet"
}

# hunt SET-NNNN --method '…' --candidates '…' --residual '…' --verdict CLEAR|EDGE-NAMED|UNABLE [--edges 'a;b']
# REQ-HUNT (§2.3 Layer C) — fill the REQUIRED SEMANTIC HUNT slot. Fail-closed content rules (also re-checked
# at ratify so the packet is never left half-formed): CLEAR needs a method + candidates (a list or the token
# ZERO); EDGE-NAMED needs the named edges (they join JOINT-EDGES as INTEGRATOR-JUDGMENT and must resolve
# before a MERGE); UNABLE records the block but ratify REFUSES a MERGE on it. No LLM stamps CLEAR (a model may
# only produce a candidate list the integrator signs). `--residual` (one sentence) is always required.
# On a FILLED slot (a re-hunt): APPENDS a dated `### RE-HUNT #N` block under `## SEMANTIC HUNT` — the
# original block is never edited (annotate-not-overwrite, §2.2); REFUSES a re-hunt verdict of UNABLE over a
# packet that already carries a MERGE decision (§2.2 downgrade-after-MERGE); REFUSES (does not silently
# "record") if the write left the packet byte-identical (§2.3 pole, inv #5). CLEAR/EDGE-NAMED are the success
# paths and exit 0 explicitly; UNABLE is a refusal for exit-status purposes even though its verdict IS
# recorded (finding 6).
cmd_hunt() {
    resolve_foundation
    local root setid="${1:-}"; shift || true; root="$(repo_root)"
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "hunt: id must be SET-NNNN."
    local packet="$root/_ratification/$setid.md"; [[ -f "$packet" ]] || die "hunt: no packet $setid."
    local method="" candidates="" residual="" verdict="" edges=""
    while [[ $# -gt 0 ]]; do case "$1" in
        --method)     need_val $# "--method" "${2:-}";     method="${2:-}";     shift 2 ;;
        --candidates) need_val $# "--candidates" "${2:-}"; candidates="${2:-}"; shift 2 ;;
        --residual)   need_val $# "--residual" "${2:-}";   residual="${2:-}";   shift 2 ;;
        --verdict)    need_val $# "--verdict" "${2:-}";    verdict="${2:-}";    shift 2 ;;
        --edges)      need_val $# "--edges" "${2:-}";      edges="${2:-}";      shift 2 ;;
        *) die "hunt: unknown arg '$1'." ;;
    esac; done
    grep -q '^## SEMANTIC HUNT' "$packet" || halt "hunt: packet $setid predates the REQ-HUNT semantic-hunt slot (no ## SEMANTIC HUNT section) — re-assemble (fail-closed §2.3)."
    case "$verdict" in
        CLEAR|EDGE-NAMED|UNABLE) : ;;
        *) die "hunt: --verdict must be one of {CLEAR|EDGE-NAMED|UNABLE} (§2.3 Layer C)." ;;
    esac
    [[ -n "${residual// /}" ]] || die "hunt: --residual '<one sentence>' is required (the hunt records its residual risk; §2.3)."
    if [[ "$verdict" == "CLEAR" ]]; then
        [[ -n "${method// /}" ]] || die "hunt: verdict CLEAR REQUIRES --method (what was grepped / which SoR indexes opened) — a CLEAR with no method is an assertion, not a hunt (DISC-ABSENCE-OF-RECORD; §2.3)."
        [[ -n "${candidates// /}" ]] || die "hunt: verdict CLEAR REQUIRES --candidates (a list, or the explicit token ZERO) — §2.3."
    fi
    if [[ "$verdict" == "EDGE-NAMED" ]]; then
        [[ -n "${edges// /}" ]] || die "hunt: verdict EDGE-NAMED REQUIRES --edges '<name>[;<name>]' — the named semantic edges join JOINT-EDGES as INTEGRATOR-JUDGMENT and must resolve before a MERGE (§2.3)."
    fi
    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

    # === §2.2 — is the slot FILLED already (a re-hunt), or is this the first fill? ======================
    local filled=1
    grep -q '<!-- SEMANTIC-HUNT-EMPTY -->' "$packet" && filled=0
    local prev_verdict="" n=0
    if [[ "$filled" -eq 1 ]]; then
        prev_verdict="$(printf '%s\n' "$(hunt_latest_block "$packet")" | sed -n 's/^VERDICT\t//p')"
        n=$(( $(hunt_rehunt_count "$packet") + 1 ))
        # --- §2.2 downgrade-after-MERGE refusal, ruling text verbatim: "a re-hunt whose verdict would
        #     DOWNGRADE a MERGE already given (CLEAR → UNABLE after ratification) exits non-zero with the
        #     reason, because a hunt after the pen is a finding for the register, not a slot edit." A MERGE
        #     already given = a §3 DECISION line of RATIFIED / RATIFIED-WITH-SEQUENCE is already stamped
        #     (same anchored pattern cmd_ratify itself uses to detect/verify that stamp).
        if [[ "$verdict" == "UNABLE" ]]; then
            local dec; dec="$(sed -n 's/^- decision: //p' "$packet" | head -1)"
            case "$dec" in
                RATIFIED|RATIFIED-WITH-SEQUENCE)
                    halt "hunt: REFUSING — $setid already carries a MERGE decision ('- decision: $dec') and this re-hunt's verdict is UNABLE — a DOWNGRADE of the hunt verdict ($prev_verdict → UNABLE) that stood behind that MERGE. A hunt after the pen is a finding for the register, not a slot edit — raise it there; this packet is not re-opened." ;;
            esac
        fi
    fi

    local psha_before; psha_before="$(shasum -a 256 "$packet" | awk '{print $1}')"

    if [[ "$filled" -eq 0 ]]; then
        # --- preservation pole (§2.3): a first hunt on an EMPTY slot fills it exactly as before this set. ---
        method="$method" candidates="$candidates" residual="$residual" verdict="$verdict" \
        awk -v ts="$now" '
            /<!-- SEMANTIC-HUNT-EMPTY -->/ {
                print "- hunt-at: " ts
                print "- method: " ENVIRON["method"]
                print "- candidates considered: " ENVIRON["candidates"]
                print "- residual risk: " ENVIRON["residual"]
                print "- verdict: " ENVIRON["verdict"]
                next
            } {print}
        ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
    else
        # --- §2.2 APPEND form: a dated RE-HUNT block under ## SEMANTIC HUNT; the original is never edited. ---
        local rehunt_header="### RE-HUNT #$n · $now · by ${lane:-foundation}"
        rehunt_header="$rehunt_header" method="$method" candidates="$candidates" residual="$residual" verdict="$verdict" ts="$now" \
        awk '
            /^## SEMANTIC HUNT/ {sec=1; print; next}
            sec && /^## / {
                print ENVIRON["rehunt_header"]
                print "- hunt-at: " ENVIRON["ts"]
                print "- method: " ENVIRON["method"]
                print "- candidates considered: " ENVIRON["candidates"]
                print "- residual risk: " ENVIRON["residual"]
                print "- verdict: " ENVIRON["verdict"]
                print ""
                sec=0
            }
            {print}
            END{ if(sec){
                print ENVIRON["rehunt_header"]
                print "- hunt-at: " ENVIRON["ts"]
                print "- method: " ENVIRON["method"]
                print "- candidates considered: " ENVIRON["candidates"]
                print "- residual risk: " ENVIRON["residual"]
                print "- verdict: " ENVIRON["verdict"]
            } }
        ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
    fi
    if [[ "$verdict" == "EDGE-NAMED" ]]; then
        local e; local -a _EN=(); IFS=';' read -ra _EN <<< "$edges"
        for e in "${_EN[@]}"; do
            e="${e#"${e%%[![:space:]]*}"}"; e="${e%"${e##*[![:space:]]}"}"; [[ -z "$e" ]] && continue
            edge="- UNRESOLVED · INTEGRATOR-JUDGMENT: $e (§2.3 Layer C named semantic edge — add a resolution: line or choose AMENDED before MERGE)" \
            awk '
                /^## JOINT-EDGES/ {inj=1; print; next}
                inj && /^## / {print ENVIRON["edge"]; print ""; inj=0}
                {print}
                END{ if(inj) print ENVIRON["edge"] }
            ' "$packet" > "$packet.tmp" && mv "$packet.tmp" "$packet"
        done
    fi

    # === §2.3 pole (WRITTEN-IS-NOT-WIRED / inv #5): every success path leaves the packet byte-different,
    #     or the command REFUSES rather than report a write that did not happen — never "recorded" over 0
    #     changed bytes. ===
    local psha_after; psha_after="$(shasum -a 256 "$packet" | awk '{print $1}')"
    if [[ "$psha_before" == "$psha_after" ]]; then
        halt "hunt: wrote nothing — $setid packet is byte-identical before and after this hunt (inv #5 halt-loud over silent-degradation). Inspect $packet before re-running."
    fi

    # === §2.2 success line — states what happened, never a bare "recorded". ===
    if [[ "$filled" -eq 0 ]]; then
        echo "hunt $setid: verdict=$verdict — SEMANTIC HUNT slot filled."
    else
        echo "hunt $setid: RE-HUNT #$n appended (previous verdict $prev_verdict → $verdict)."
    fi
    [[ "$verdict" == "EDGE-NAMED" ]] && echo "  ⚠ named edge(s) appended to JOINT-EDGES — resolve each (resolution: line) or AMENDED before a MERGE decision."
    [[ "$verdict" == "UNABLE" ]] && echo "  ⚠ verdict UNABLE — ratify will REFUSE a MERGE decision (§2.3). Complete the hunt (CLEAR/EDGE-NAMED) or choose AMENDED/HELD."

    # === exit status (finding 6, corrected design): CLEAR/EDGE-NAMED are the
    #     success paths and exit 0, EXPLICITLY — never again the trailing conditional-echo idiom whose exit
    #     status this function used to inherit by accident. UNABLE exits non-zero: it IS recorded, but it is
    #     a refusal for exit-status purposes (ratify will REFUSE a MERGE on it), same class as die/halt. ===
    if [[ "$verdict" == "UNABLE" ]]; then
        return 1
    fi
    return 0
}

main() {
    local verb="${1:-}"; shift || true
    case "$verb" in
        assemble)          cmd_assemble "$@" ;;
        assess)            cmd_assess "$@" ;;
        hunt)              cmd_hunt "$@" ;;
        conformance)       cmd_conformance "$@" ;;
        conformance-check) cmd_conformance_check "$@" ;;
        ratify)            cmd_ratify "$@" ;;
        ""|-h|--help) echo "usage: ratify.sh {assemble [SET-NNNN] --cures <ids>|none | assess SET-NNNN --text …|--file F | hunt SET-NNNN --method … --candidates … --residual … --verdict CLEAR|EDGE-NAMED|UNABLE [--edges 'a;b'] | conformance-check SET-NNNN <member> [--criteria F] | conformance SET-NNNN <member> --verdict PASS|FAIL --method structured|judgment --evidence '…' | ratify SET-NNNN {--by 'name' --rationale-class in-band|OUT-OF-BAND | --standing-class} [--decision RATIFIED|RATIFIED-WITH-SEQUENCE|AMENDED|HELD|REJECTED] [--sequence …] [--trigger …]}" ;;
        *) die "unknown verb '$verb' (expected: assemble | assess | hunt | conformance-check | conformance | ratify)." ;;
    esac
}
main "$@"
