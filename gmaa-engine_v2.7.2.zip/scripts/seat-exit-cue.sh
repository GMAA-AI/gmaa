#!/usr/bin/env bash
# scripts/seat-exit-cue.sh — UserPromptSubmit hook: the operator-word -> seat-exit verb cue
# (the exit-cue contract; the closed word map is the one below).
# The map is code, not recall (LLM-AT-THE-EDGES). CLAUDE.md §7 B6.1 states the rule; the closed set
# lives HERE ONLY (DISC-VIGILANCE-IS-FIELD-LOCAL: no retyped copy anywhere else).
# Input: the hook's own stdin JSON `.prompt`, normalized: lowercase, trim whitespace, strip trailing `.!?`.
# It cues only when the WHOLE normalized prompt is a set member; a prompt that merely contains a word gets nothing.
# Output on a match: exactly one line,
#   SEAT-EXIT-CUE: operator word "<word>" ⇒ B6.1, then scripts/seat-exit.sh <verb>
# Nothing on a miss (0 B; E3 unchanged). HALT-LOUD: no jq prints `SEAT-EXIT-CUE: unknown (jq not found)` only when
# the raw stdin's prompt field matches the set (an absent jq is reported, never read as "no match").
# Never blocks the prompt: always exit 0.
set -u
IN="$(cat)"

norm() {  # lowercase, trim, strip trailing .!? (repeatedly), trim again
  local s
  s="$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]')"
  s="${s#"${s%%[![:space:]]*}"}"; s="${s%"${s##*[![:space:]]}"}"
  while [ -n "$s" ]; do
    case "$s" in *[.!?]) s="${s%?}" ;; *) break ;; esac
  done
  s="${s%"${s##*[![:space:]]}"}"
  printf '%s' "$s"
}

verb_for() {  # the closed set (0379 §1): 7 members, 3 => restart, 4 => shutdown; no synonym inferred
  case "$1" in
    restart|"restart now"|"need restart") echo restart ;;
    exit|shutdown|"shut down"|quit) echo shutdown ;;
    *) : ;;
  esac
}

if ! command -v jq >/dev/null 2>&1; then
  # raw read of the "prompt" string (no jq to parse it); cue loud only if it is a set member
  RAW="$(printf '%s' "$IN" | tr '\n' ' ' | sed -n 's/.*"prompt"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')"
  [ -n "$(verb_for "$(norm "$RAW")")" ] && echo "SEAT-EXIT-CUE: unknown (jq not found)"
  exit 0
fi

P="$(printf '%s' "$IN" | jq -r '.prompt // empty' 2>/dev/null)"
W="$(norm "$P")"
V="$(verb_for "$W")"
[ -n "$V" ] && echo "SEAT-EXIT-CUE: operator word \"$W\" ⇒ B6.1, then scripts/seat-exit.sh $V"
exit 0
