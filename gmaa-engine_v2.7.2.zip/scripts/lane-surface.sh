#!/usr/bin/env bash
# scripts/lane-surface.sh — THE ONE INDIRECTION POINT for "which branch is a lane on, and which
# path is it AUTHORIZED to write?"  Sourced, not executed as a pipeline stage.
#
# WHY THIS EXISTS:
#   Three call sites independently re-derived a lane's branch, and a fourth re-derived its surface.
#   Every one of them keyed on a NAME PATTERN — `module/<lane>` — which is FALSE for 2 of 6 lanes
#   (`architect` → branch `architect`; the execution lane → branch `exec`). That is the D-21 class, and it has
#   now been re-found four separate times. Two copies of a resolution rule drift; this is one copy.
#
# ⛔ THE SCOPE DEFECT THIS ALSO FIXES (raised by the execution lane BEFORE the build — the cheapest
#    possible moment): an enumerator scoped to "module OUTBOXes" resolves 5 lanes and returns ZERO
#    for the 6th — the execution lane, whose carve-out permits commits SOLELY under
#    `ledger/apply-receipts/**`, so its `relay-outbox/` has never held a tracked byte. It would
#    then print `(none)` TRUTHFULLY: a hard resolution failure laundered into a clean wrong answer,
#    which is the exact truthful-empty failure reproduced inside the code written to cure it.
#
# ⭐ THE RULE, AND WHY IT IS PER-CLASS AND NOT PER-NAME: the surface is a FUNCTION OF THE DECLARED
#    `spine_write` CLASS, read from the canonical manifest. A name pattern was true for 4 of 6; a
#    declared class is true for all 6 and AUTO-EXTENDS to the planned 4th site with no code change.
#      DENY                 -> _orchestration/relay-outbox/<lane>/   (module lanes: their outbox)
#      apply-receipts-only  -> ledger/apply-receipts/                (the execution lane: its ONLY writable path)
#      ALLOW                -> (hub) NOT SWEPT — foundation is the reader, not a swept producer
#
# ⛔ DO NOT mint a second `surface_path` column in the manifest. It could drift from `spine_write`,
#    and then the authorization declaration and the sweep declaration would disagree — two copies of
#    one rule again (DISC-VIGILANCE-IS-FIELD-LOCAL: remove the field vigilance can be local to).
# ⛔ DO NOT widen a lane's carve-out so its channel fits a simpler enumerator. That lane refused exactly
#    that on its own behalf; trading a discoverability bug for an AUTHORIZATION bug is the strictly
#    worse trade (DISC-CARVE-OUT-NEEDS-A-PROMOTION-PATH). The reader adapts to the third authority
#    class; the class does not dissolve to suit the reader.

set -u

_LS_MANIFEST_REL="_orchestration/lane-provisioning.md"
# the one spine-ref resolver, found BESIDE THIS FILE only (0507 R2), resolved once at source time
_LS_SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"

_ls_repo_root() { git rev-parse --show-toplevel 2>/dev/null; }

# _ls_manifest_rows — emit "lane<TAB>branch<TAB>spine_write" for every declared lane.
# Reads the manifest from the TRUNK ref, never the worktree: the roster is a shared declaration and
# a lane must not be able to change who gets swept by editing its own checkout
# (DISC-VERIFY-AT-THE-ENFORCERS-REFERENCE — measure at the ref the gate consults).
#
# ⛔ AN UNREADABLE MANIFEST IS NOT AN EMPTY ROSTER (window plan rows 3 + 13; canon s5
#    truthful empty + s2 HALT-LOUD). The read used to discard a `git show` failure into `awk`: zero rows,
#    so no lane was named unresolved and the hub printed `empty (all declared surfaces resolved)`.
#    `lane_manifest_load` now reads the manifest ONCE per shell and returns a NAMED non-zero status:
#      3 = the `git show` of the manifest failed  ·  4 = it parsed to 0 declared lanes
#    with the reason on stderr and in `LANE_MANIFEST_ERROR`. A caller that sweeps MUST call it in its own
#    (parent) shell first and HALT on non-zero: `< <(lane_producers)` runs in a subshell, so a failure that
#    only happens in there cannot reach the caller. Loading once in the parent also ends the re-`git show`
#    on every lane_branch / lane_class / lane_producers call (row 13): the subshells inherit the rows.
_LS_ROWS=""
_LS_LOADED=""
LANE_MANIFEST_ERROR=""
lane_manifest_load() {
    [[ -n "$_LS_LOADED" ]] && return 0
    local root ref="${LANE_SURFACE_REF:-}" raw
    root="$(_ls_repo_root)" || { LANE_MANIFEST_ERROR="not in a git worktree"; echo "lane-surface: UNREADABLE — $LANE_MANIFEST_ERROR" >&2; return 3; }; [[ -n "$ref" || -f "$_LS_SPINE_REF_SH" ]] || { LANE_MANIFEST_ERROR="SPINE-REF-ABSENT $_LS_SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2)"; echo "lane-surface: UNREADABLE — $LANE_MANIFEST_ERROR" >&2; return 3; }; [[ -n "$ref" ]] || ref="$(bash "$_LS_SPINE_REF_SH")" || { LANE_MANIFEST_ERROR="SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled at $root and LANE_SURFACE_REF unset (the one spine-ref resolver; no literal fallback)"; echo "lane-surface: UNREADABLE — $LANE_MANIFEST_ERROR" >&2; return 3; }
    raw="$(git -C "$root" show "${ref}:${_LS_MANIFEST_REL}" 2>/dev/null)" || {
        LANE_MANIFEST_ERROR="git show ${ref}:${_LS_MANIFEST_REL} failed"
        echo "lane-surface: UNREADABLE — $LANE_MANIFEST_ERROR" >&2; return 3; }
    _LS_ROWS="$(printf '%s\n' "$raw" | awk -F'|' '
        /^\|/ {
            gsub(/^[ \t]+|[ \t]+$/, "", $2); gsub(/^[ \t]+|[ \t]+$/, "", $3); gsub(/^[ \t]+|[ \t]+$/, "", $5)
            if ($2 == "" || $2 == "lane" || $2 ~ /^-+$/) next
            # the manifest writes the executor row as "<lane> (exec)" — the lane id is the first token.
            sub(/[ \t]*\(.*\)[ \t]*$/, "", $2)
            if ($3 == "" || $5 == "") next
            print $2 "\t" $3 "\t" $5
        }')"
    if [[ -z "$_LS_ROWS" ]]; then
        LANE_MANIFEST_ERROR="${ref}:${_LS_MANIFEST_REL} parsed to 0 declared lanes"
        echo "lane-surface: UNREADABLE — $LANE_MANIFEST_ERROR" >&2; return 4
    fi
    _LS_LOADED=1
}

# _ls_manifest_rows — emit "lane<TAB>branch<TAB>spine_write" for every declared lane. Prints nothing and
# returns the load status when the manifest cannot be read (direct callers check it; see audit-seal.sh).
_ls_manifest_rows() {
    lane_manifest_load || return $?
    printf '%s\n' "$_LS_ROWS"
}

lane_branch() {  # lane_branch <lane> -> branch, or non-zero if undeclared
    local want="$1" l b s
    while IFS=$'\t' read -r l b s; do
        [[ "$l" == "$want" ]] && { printf '%s\n' "$b"; return 0; }
    done < <(_ls_manifest_rows)
    return 1
}

lane_class() {   # lane_class <lane> -> spine_write class
    local want="$1" l b s
    while IFS=$'\t' read -r l b s; do
        [[ "$l" == "$want" ]] && { printf '%s\n' "$s"; return 0; }
    done < <(_ls_manifest_rows)
    return 1
}

# lane_surface <lane> -> the repo-relative MESSAGE surface: the path the hub sweeps for this lane's mail.
# Returns non-zero (and prints nothing) for the hub, which is a reader and not a swept producer.
# ⭐ (window plan row 14; canon s5: the sweep reads the authorized message surface, not the lane's
#    whole writable tree): for `apply-receipts-only` the message surface is `ledger/apply-receipts/relay/`,
#    INSIDE that lane's carve-out (no authority change; the no-widening rule above holds). The writable
#    surface stays all of `ledger/apply-receipts/` (lane_writable). A content rule (name prefix or `TO:` header)
#    was measured lossy both ways and is NOT the surface; it returns only as the hub's MISFILED-MAIL detector.
lane_surface() {
    local want="$1" class
    class="$(lane_class "$want")" || return 1
    case "$class" in
        DENY)                printf '_orchestration/relay-outbox/%s/\n' "$want" ;;
        apply-receipts-only) printf 'ledger/apply-receipts/relay/\n' ;;
        ALLOW)               return 2 ;;   # hub — deliberately not swept
        *)                   return 3 ;;   # unknown class: caller must HALT-LOUD, never default
    esac
}

# lane_writable <lane> -> the whole path the lane is AUTHORIZED to write (authorization, not mail). Equal to
# lane_surface for DENY; wider for apply-receipts-only. The hub's misfile scan reads writable minus surface.
lane_writable() {
    local want="$1" class
    class="$(lane_class "$want")" || return 1
    case "$class" in
        DENY)                printf '_orchestration/relay-outbox/%s/\n' "$want" ;;
        apply-receipts-only) printf 'ledger/apply-receipts/\n' ;;
        ALLOW)               return 2 ;;
        *)                   return 3 ;;
    esac
}

lane_roster() {  # every declared lane, one per line (hub included; callers filter)
    local l b s
    while IFS=$'\t' read -r l b s; do printf '%s\n' "$l"; done < <(_ls_manifest_rows)
}

# lane_producers — the lanes a hub sweep must read: everything that is NOT the hub.
# Derived, never hardcoded; a new lane in the manifest is swept the day it is provisioned.
lane_producers() {
    local l b s
    while IFS=$'\t' read -r l b s; do
        [[ "$s" == "ALLOW" ]] && continue
        printf '%s\n' "$l"
    done < <(_ls_manifest_rows)
}

# Executed directly = self-test / inspection. Sourcing is the normal path.
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    lane_manifest_load || exit $?
    printf '%-14s %-18s %-22s %s\n' LANE BRANCH CLASS SURFACE
    while IFS=$'\t' read -r l b s; do
        surf="$(lane_surface "$l")" || surf="(hub — not swept)"
        printf '%-14s %-18s %-22s %s\n' "$l" "$b" "$s" "$surf"
    done < <(_ls_manifest_rows)
fi
