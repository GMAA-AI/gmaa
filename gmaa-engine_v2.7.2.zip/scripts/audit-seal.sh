#!/bin/bash
# scripts/audit-seal.sh <restart|shutdown|manual> — the ONE seal writer (MECH-AUDIT, loop-cure member A1).
# It seals every finished foundation [audit]-done sentinel, plus this lane's restart-ledger
# line, in ONE `[audit] seal` commit per restart boundary. Called by scripts/seat-b6-stop.sh at
# the boundary, before /exit is sent. The post-commit hook no longer seals per commit (batching moves WHEN the
# seal lands, never WHETHER the audit runs: every commit is still audited by the hook).
#
# SINGLE SOURCE of the sealed-path list: scripts/seat-exit.sh derives its pure-append exemption from the
# `G add ` lines below, so keep each sealed path on such a line. `${lane}` is substituted there.
#
# Exit: 0 = sealed, or nothing to seal · 1 = SEAL-FAILED (sentinels present and no seal landed; EVERY sentinel is
# KEPT, inv #5) · 2 = usage / unresolved identity.
# The `[audit]` subject makes the post-commit hook skip this commit (agents/post-commit-hook.sh skip-guard), so
# this script pushes its own seal (ff only, never --force; a failed push warns, the seal is still landed).
set -u
KIND="${1:-}"
case "$KIND" in restart|shutdown|manual) ;; *) echo "usage: scripts/audit-seal.sh <restart|shutdown|manual>" >&2; exit 2 ;; esac
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "SEAL-FAILED: not inside a git worktree" >&2; exit 2; }
cd "$ROOT" || exit 2
# identity = the stamp's lane: field, the same reader seat-exit.sh uses (scripts/resolve-project.sh); never chat
lane="$(bash "$ROOT/scripts/resolve-project.sh" --field lane "$ROOT" 2>/dev/null)"
[ -n "$lane" ] || { echo "SEAL-FAILED: no lane: field resolvable from _boot/BOOTSTRAP.md (scripts/resolve-project.sh); identity unresolved, nothing sealed" >&2; exit 2; }
G() { env -u GIT_INDEX_FILE -u GIT_DIR -u GIT_WORK_TREE -u GIT_PREFIX -u GIT_AUTHOR_DATE -u GIT_COMMITTER_DATE git "$@"; }
GIT_COMMON="$(cd "$(git rev-parse --git-common-dir)" && pwd)"
DONE_DIR="${AUDIT_SEAL_DONE_DIR:-$GIT_COMMON/audit-done}"   # test seam: fixtures point at a scratch dir

# Foundation only seals audit sentinels; module sentinels ride reap-at-merge (unchanged).
SEALED=()
if [ "$lane" = foundation ] && [ -d "$DONE_DIR" ]; then
  for s in "$DONE_DIR"/*; do
    [ -e "$s" ] || continue
    [ "$(cat "$s" 2>/dev/null)" = foundation ] || continue
    SEALED+=("$(basename "$s")")
  done
fi
K=${#SEALED[@]}

# Never sweep other work into a seal: a pre-staged index is refused (sentinels KEPT).
G diff --cached --quiet 2>/dev/null || { echo "SEAL-FAILED: lane=$lane boundary=$KIND: the index already holds staged changes; refusing to sweep them into a seal; ${K} sentinel(s) KEPT" >&2; exit 1; }
# --- the sealed-path list (one `G add ` per path; seat-exit.sh derives the exemption from these lines) ---
[ "$lane" = foundation ] && G add ledger/audit-runs.log ledger/audit-findings.md ledger/receipts.jsonl 2>/dev/null
[ "$lane" = foundation ] && [ -f ledger/auditor-usage.jsonl ] && G add ledger/auditor-usage.jsonl 2>/dev/null
[ -f "ledger/restarts/${lane}.tsv" ] && G add "ledger/restarts/${lane}.tsv" 2>/dev/null

# The promotion path: a lane's restart line lives on ITS branch (module lanes reach main only inside a
# RATIFIED set, reap_at_merge.sh NO-CHERRY-PICK). Foundation's boundary seal carries each lane's OWN file to the spine
# by copy-by-file from origin/<branch> (lane -> branch from scripts/lane-surface.sh, the one map), and ONLY when the
# lane's copy is a pure-append extension of the spine copy. Anything else is NOT carried and warns (single writer).
COPIED=()
if [ "$lane" = foundation ] && [ -z "${AUDIT_SEAL_NO_LANES:-}" ] && ! . "$ROOT/scripts/lane-surface.sh" 2>/dev/null; then
  echo "SEAL: WARN scripts/lane-surface.sh unreadable; NO lane restart ledger carried this boundary" >&2
elif [ "$lane" = foundation ] && [ -z "${AUDIT_SEAL_NO_LANES:-}" ]; then
  G fetch -q origin 2>/dev/null || echo "SEAL: WARN git fetch origin failed; lane restart ledgers read from the last-fetched refs" >&2
  TMPL="$(mktemp)"; ROWS="$(_ls_manifest_rows)"
  [ -n "$ROWS" ] || echo "SEAL: WARN the lane manifest is unreadable at ${LANE_SURFACE_REF:-the spine ref (scripts/spine-ref.sh)} (scripts/lane-surface.sh; its UNREADABLE line above names why); NO lane restart ledger carried this boundary" >&2
  while IFS=$'\t' read -r L LBR _; do
    [ -n "$L" ] || continue
    [ "$L" = foundation ] && continue
    G show "origin/${LBR}:ledger/restarts/${L}.tsv" > "$TMPL" 2>/dev/null || continue   # no line yet on that lane
    dst="ledger/restarts/${L}.tsv"
    if [ -f "$dst" ]; then
      cmp -s "$TMPL" "$dst" && continue
      if ! head -c "$(wc -c < "$dst")" "$TMPL" | cmp -s - "$dst"; then
        echo "SEAL: WARN origin/${LBR}:${dst} is not a pure-append extension of the spine copy; NOT carried" >&2; continue
      fi
    fi
    mkdir -p ledger/restarts && cp "$TMPL" "$dst" && G add -- "$dst" && COPIED+=("$dst")
  done <<< "$ROWS"
  rm -f "$TMPL"
fi
restore_copied() { local f; for f in ${COPIED[@]+"${COPIED[@]}"}; do G checkout -q HEAD -- "$f" 2>/dev/null || rm -f "$f"; done; }

# An E12 breach is a pressure line, so the boundary records it. Score the rolling 7-UTC-day window with
# this pending seal added (E12_PENDING_BOUNDARY=1) and append ONE issues_register.md line per breached ratio per UTC day (deduplicated by the
# key `E12-PB-BREACH <UTC day> <ratio>`). The line rides THIS seal commit. Foundation only: the register is
# spine. An unreadable E12 block or a register already dirty WARNS here and the successor's boot-check.sh still re-prints
# the HALT line, so a breach is never silent.
NREG=0
if [ "$lane" = foundation ] && [ -z "${AUDIT_SEAL_NO_E12:-}" ]; then
  E12OUT="$(E12_PENDING_BOUNDARY=1 bash "$ROOT/probes/budget/probe_efficiency_budget.sh" --e12-only 2>&1)"; E12RC=$?
  if [ "$E12RC" != 0 ]; then
    echo "SEAL: WARN the E12 block is unreadable (rc=$E12RC); NO E12 register line this boundary: $(printf '%s' "$E12OUT" | tail -1)" >&2
  elif printf '%s\n' "$E12OUT" | grep -q '^  E12-PB HALT: '; then
    if ! G diff --quiet -- issues_register.md 2>/dev/null; then
      echo "SEAL: WARN issues_register.md already has unstaged changes; the E12 register line is NOT written (never swept into a seal)" >&2
    else
      DAY="$(date -u +%Y-%m-%d)"
      while IFS= read -r h; do
        [ -n "$h" ] || continue
        key="E12-PB-BREACH ${DAY} ${h%% *}"
        grep -qF -- "$key" issues_register.md 2>/dev/null && continue
        printf -- '- %s · E12-PB HALT: %s · written by scripts/audit-seal.sh at the %s boundary (one line per breached ratio per UTC day; DISC-A-NUMBER-CARRIES-ITS-FRAME and DISC-NO-INHERITED-COUNT: value, ceiling, numerator/denominator and window as the probe printed them)\n' \
          "$key" "$h" "$KIND" >> issues_register.md && NREG=$((NREG+1))
      done <<< "$(printf '%s\n' "$E12OUT" | sed -n 's/^  E12-PB HALT: //p')"
      if [ "$NREG" -gt 0 ]; then G add issues_register.md && COPIED+=(issues_register.md); fi
    fi
  fi
  printf '%s\n' "$E12OUT" | grep '^  E12-PB HALT: ' | sed 's/^  /SEAL: /' >&2
fi

STAGED=1; G diff --cached --quiet 2>/dev/null && STAGED=0
if [ "$STAGED" = 0 ] && [ "$K" = 0 ]; then
  echo "SEAL: nothing to seal (lane=$lane boundary=$KIND, 0 sentinels, 0 staged ledger bytes)"
  exit 0
fi
SHALIST=""; [ "$K" -gt 0 ] && SHALIST="$(printf '%s ' "${SEALED[@]}")"
if [ "$lane" = foundation ]; then
  SUBJ="[audit] seal (n=${K}) ${SHALIST}— lane=${lane} boundary=${KIND} (one seal per restart boundary)"
else
  # A lane that writes no seal commits the line in a one-line commit of its own. It is not an
  # [audit] subject, so the module post-commit path runs (lane marker + push of the lane branch).
  SUBJ="restart-ledger: ${lane} $(date -u +%Y-%m-%dT%H:%M:%SZ)"
fi
# K>0 with nothing staged still writes a seal (an empty commit naming the shas). A boundary that finds sentinels
# must leave a seal; silently deleting them was ISSUE-POST-COMMIT-REAP-DROPS-SENTINEL-ON-FAILED-SEAL.
EMPTY=(); [ "$STAGED" = 0 ] && EMPTY=(--allow-empty)
PRE="$(G rev-parse HEAD)"
if ! G commit -q ${EMPTY[@]+"${EMPTY[@]}"} -m "$SUBJ"; then
  G reset -q 2>/dev/null; restore_copied
  echo "SEAL-FAILED: lane=$lane boundary=$KIND: git commit refused; ${K} sentinel(s) KEPT in $DONE_DIR; index reset" >&2
  exit 1
fi
POST="$(G rev-parse HEAD)"
if [ "$POST" = "$PRE" ] || [ "$(G log -1 --format=%s HEAD)" != "$SUBJ" ]; then
  restore_copied
  echo "SEAL-FAILED: lane=$lane boundary=$KIND: no seal commit at HEAD after commit; ${K} sentinel(s) KEPT" >&2
  exit 1
fi
for sha in ${SEALED[@]+"${SEALED[@]}"}; do rm -f "$DONE_DIR/$sha"; done
BR="$(G rev-parse --abbrev-ref HEAD 2>/dev/null)"
if [ "$lane" = foundation ] && [ -n "$BR" ] && [ "$BR" != HEAD ] && [ -z "${AUDIT_SEAL_NO_PUSH:-}" ]; then
  G push -q origin "$BR" >/dev/null 2>&1 || echo "SEAL: WARN push of $BR failed (seal is landed locally; never --force; the drift surface flags it)" >&2
fi
echo "SEAL: ${POST:0:8} n=${K} lane=${lane} boundary=${KIND} e12-register-lines=${NREG}"
exit 0
