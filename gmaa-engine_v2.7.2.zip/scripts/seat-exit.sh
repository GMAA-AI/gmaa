#!/bin/bash
# scripts/seat-exit.sh <restart|shutdown> — a seat ends ITSELF after B6.1 (PROPOSAL §2.3).
# Run by the seat as its last act. It VALIDATES and WRITES THE INTENT, and that is all: it never sends a
# keystroke (P15). When the turn ends, the Stop hook (scripts/seat-b6-stop.sh) sees a fresh intent for its own
# session and sends `/exit` to its own pane; scripts/seat-loop.sh then relaunches (restart) or ends (shutdown).
# Any seat may run it on itself (session lifecycle, 0315 §2 "Also"). No seat runs it for another seat.
#
# Refusals (exit 2, named reason; no intent written):
#   - $TMUX unset                         -> "not a tmux seat; exit by hand"
#   - CLAUDE_CODE_SESSION_ID unset        -> not run from a seat's tool shell (docs: env-vars, set in Bash tool
#                                            subprocesses and equal to the hook session_id)
#   - tracked changes, staged or unstaged -> B6.1 not done (git status --porcelain --untracked-files=no);
#                                            untracked files are printed, never blocking (0315 §2(d))
#   - no `handoff:` stamp field           -> the handoff surface is undeclared
#   - no boot record for this session     -> cannot prove the handoff moved (.claude/seat-boot.log)
#   - handoff unchanged since boot sha    -> B6.1 not externalized
#   - handoff changed but no `## NEXT` heading followed by a numbered item or a NAMED-WAIT line in any changed
#     *.md of the surface (0425 §4; the `next-state` grammar below is the one definition)
# Intent line (.claude/seat-intent): <restart|shutdown> <session_id> <HEAD sha> <epoch> <utc> [when-idle]
#
# SUBAGENTS: live subagents of THIS session never cause a
# refusal. With a non-empty own-session ledger the intent is written with field 6 `when-idle` (the loop reads
# fields 1 and 4 only, so `restart` still relaunches), the live agent_ids are printed, and ONE detached
# watchdog is armed: it sleeps to the latest deadline (max of start + effective cap + ABANDON_AFTER_MIN) and
# runs the Stop hook's own exit predicate once (scripts/seat-b6-stop.sh, SEAT_WATCHDOG=1). It never loops.
# Three more verbs (no intent written by any):
#   next-state <file> [--any-number]   prints ITEM | WAIT | NONE for the FIRST `## NEXT` heading of <file>
#                              (0425 §4); no checks, no git. The lines up to the next `^## ` are read; the
#                              first non-blank line decides: `1.` (with --any-number: any `N.`) -> ITEM; contains
#                              `NAMED-WAIT: ` -> WAIT; else NONE; no heading -> NONE. The Stop hook (seat-b6-stop.sh,
#                              duty 0b) calls it without the flag (strict `1.`); the handoff predicate below, with it.
#   recheck                    the Stop hook re-runs the checks below at fire time (0336 §2(c)(ii)); session from
#                              $SEAT_SID; no $TMUX check (the hook already holds the pane). Silent on pass.
#   clear-subagent <agent_id>  the manual verb (0336 §2(e)): drop that own-session entry, receipt line
#                              `SUBAGENT-CLEARED` in .claude/seat-loop.log. Never automatic.
# WATCHDOG_SLEEP (test seam only): overrides the computed sleep.
set -u
INTENT="${1:-}"
case "$INTENT" in restart|shutdown|recheck|clear-subagent|next-state|send|watchdog) ;; *) echo "usage: scripts/seat-exit.sh <restart|shutdown|recheck|clear-subagent <agent_id>|next-state <file> [--any-number]|send …|watchdog …>" >&2; exit 2 ;; esac
# ---------------------------------------------------------------------------------------------------------------
# The ONE append-only exemption (0329; used by the intent's B6.1 check below AND by the watchdog re-pass, 0444 R2).
# seal_paths <root> <lane>: the ledger paths the ONE boundary seal writer stages, DERIVED from its `G add ` lines
#   (scripts/audit-seal.sh, MECH-AUDIT), never retyped here. `${lane}` in a path is <lane> (the restart ledger).
# seal_append_exempt <root> <paths> <porcelain-line>: rc 0 iff the line is an UNSTAGED modification (" M") of one
#   of <paths>, whose numstat deletions = 0, whose --summary is empty (no mode or type change; auditor 6245b454 F1),
#   and whose HEAD bytes are a prefix of the working bytes. Anything else is not exempt.
seal_paths() {
  grep -E '^[[:space:]]*(\[[^]]*\][[:space:]]*&&[[:space:]]*)*G add ' "$1/scripts/audit-seal.sh" 2>/dev/null \
    | grep -oE 'ledger/[A-Za-z0-9_.${}/-]+' | sed "s/\${lane}/${2:-UNRESOLVED-LANE}/g" | sort -u
}
seal_append_exempt() {
  local r="$1" sp="$2" l="$3" p del hsz
  p="${l:3}"
  [ -n "$sp" ] && [ "${l:0:2}" = " M" ] && printf '%s\n' "$sp" | grep -qxF "$p" || return 1
  del="$(git -C "$r" diff --numstat HEAD -- "$p" | awk '{print $2}')"
  hsz="$(git -C "$r" cat-file -s "HEAD:$p" 2>/dev/null)"
  [ "$del" = "0" ] && [ -n "$hsz" ] && [ -z "$(git -C "$r" diff --summary HEAD -- "$p")" ] \
    && git -C "$r" show "HEAD:$p" | cmp -s - <(head -c "$hsz" "$r/$p")
}
# ---------------------------------------------------------------------------------------------------------------
# send <root> <sid> <pane> <kind> <n> [watchdog]   — the ONE send + verify definition (0444 R3). Called by the Stop
#   hook (scripts/seat-b6-stop.sh) and by the watchdog below, by ABSOLUTE path, after the caller has written the
#   intent-keyed sent-marker (.claude/seat-exit-sent). It types /exit into <pane> (or answers an already-open exit
#   dialog with option 1), then runs the 0387 verifier DETACHED at CONFIRM_DELAY and VERIFY_AT (+20/+60/+180 s):
#   SEAT-EXIT-CONFIRMED on a later `SEAT-LOOP: launch`; STOPPED / DIALOG-UNREAD / BLOCKED / NO-DIALOG otherwise, and
#   at a VERIFY_AT offset a BLOCKED or NO-DIALOG pane re-enters the Stop hook (the LOST path, max 3 sends). Logs one
#   SEAT-EXIT-SENT line. Env: SEND_CMD (tmux), SEND_DELAY (2), CONFIRM_DELAY (3), VERIFY_AT ("20 60 180").
#   Depends on nothing in scripts/ except, on the LOST path, the Stop hook it re-enters.
# watchdog <root> <sid> <kind> <epoch> <head> <lane> <sleep>   — the witness outside the session (0444 R1/R2).
#   Armed by restart/shutdown for EVERY intent (detached, nohup). Sleeps <sleep> s, then, once, never looping:
#   (1) the intent is gone or is not this one (session + epoch)      -> ends silently;
#   (2) a send for this intent is on record (the 0337 §4(a) marker)  -> ends silently (the healthy path; P3);
#   (3) runs the exit predicate by absolute path ($root/scripts/seat-b6-stop.sh, SEAT_WATCHDOG=1). If it sent, or
#       logged a named outcome for this session, it ends there. Otherwise (it cannot execute, or it returned with
#       no named outcome) it logs SEAT-EXIT-WATCHDOG-PREDICATE-DEAD <rc> and applies its OWN re-pass:
#         head-moved  HEAD == the intent's HEAD;   tree-dirty  no tracked change except the pure append of this
#         lane's restart ledger line (ledger/restarts/<lane>.tsv, written with the intent) and the SAME pure-append
#         exemption the intent's B6.1 check applies (seal_append_exempt over seal_paths, above; the hub's auditor
#         ledgers, appended after the intent by the post-commit auditor; 1587b);   no-pane  $TMUX_PANE set.
#       Pass -> marker, `send … watchdog` (which arms the verifier, R3). Refuse -> SEAT-EXIT-WATCHDOG-REFUSED <check>.
#   Every REFUSED from a lane that is not the hub rings foundation (scripts/doorbell.sh), the attention signal.
#   The re-pass does not run the boundary seal (scripts/audit-seal.sh); the next boundary's seal stages the ledger line.
# ---------------------------------------------------------------------------------------------------------------
if [ "$INTENT" = send ]; then
  ROOT="${2:?send: root}"; SID="${3:?send: sid}"; PANE="${4:?send: pane}"; I_KIND="${5:-?}"; SN="${6:-1}"; WD="${7:-}"
  D="$ROOT/.claude"; SEND="${SEND_CMD:-tmux}"; CONFIRM_DELAY="${CONFIRM_DELAY:-3}"
  UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  ( sleep "${SEND_DELAY:-2}"
    O1='(^|[^0-9])1\. Exit and stop tasks'; DLG='Background work is running|Background this session\?'
    stop_dialog() {  # $1 = the pane capture that decided the key, $2 = optional suffix for the STOPPED line
      TS="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
      ITEMS="$(printf '%s\n' "$1" | awk '/The following will stop when you exit:/{f=1;next} f&&/(^|[^0-9])1\. Exit and stop tasks/{exit} f{sub(/^[ \t]+/,""); sub(/[ \t]+$/,""); if($0!="")print}')"
      NI="$(printf '%s\n' "$ITEMS" | awk 'NF{c++} END{print c+0}')"
      $SEND send-keys -t "$PANE" -l "1"
      printf 'SEAT-EXIT-STOPPED %s %s %s%s\n' "$TS" "$SID" "$NI" "${2:+ $2}" >> "$D/seat-loop.log"
      printf '%s\n' "$ITEMS" | while IFS= read -r IT; do
        [ -n "$IT" ] && printf 'IN-FLIGHT %s %s %s\n' "$TS" "$SID" "$IT" >> "$D/seat-loop.log"
      done
    }
    OTHER_MODAL='Enter to confirm|Esc to cancel'
    PRE="$($SEND capture-pane -p -t "$PANE" 2>/dev/null)"
    PRESENT=""
    if printf '%s\n' "$PRE" | command grep -qE "$O1"; then
      stop_dialog "$PRE" "dialog-already-open"; PRESENT=1
    elif printf '%s\n' "$PRE" | command grep -qE "$DLG"; then
      printf 'SEAT-EXIT-DIALOG-UNREAD %s %s dialog-already-open; no option-1 line; no key sent\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$SID" >> "$D/seat-loop.log"
      exit 0
    elif printf '%s\n' "$PRE" | command grep -qE "$OTHER_MODAL"; then
      FL="$(printf '%s\n' "$PRE" | command grep -m1 -E "$OTHER_MODAL" | cut -c1-120)"
      printf 'SEAT-EXIT-BLOCKED %s %s %s dialog-already-open\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$SID" "$FL" >> "$D/seat-loop.log"
      exit 0
    fi
    [ -z "$PRESENT" ] && { $SEND send-keys -t "$PANE" -l "/exit"; sleep 1; $SEND send-keys -t "$PANE" Enter; }
    SEND_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"; SEND_T0=$(date +%s)
    VOFFS="$(printf '%s\n' "${VERIFY_AT:-20 60 180}" | tr ' ' '\n' | /usr/bin/grep -E '^[0-9]+$')"
    OFFSETS="$(printf '%s\n%s\n' "$CONFIRM_DELAY" "$VOFFS" | /usr/bin/grep -E '^[0-9]+$' | sort -n -u)"
    for OFF in $OFFSETS; do
      NOWT=$(date +%s); WAITS=$((SEND_T0 + OFF - NOWT)); [ "$WAITS" -gt 0 ] && sleep "$WAITS"
      ISV=""; printf '%s\n' "$VOFFS" | /usr/bin/grep -qx "$OFF" && ISV=1
      LAST_LAUNCH="$(command grep -F 'SEAT-LOOP: launch ' "$D/seat-loop.log" 2>/dev/null | tail -1 | cut -d' ' -f1)"
      CONFIRMED=""
      [ -n "$LAST_LAUNCH" ] && [ "$LAST_LAUNCH" \> "$SEND_UTC" ] && CONFIRMED=1
      if [ -n "$CONFIRMED" ]; then
        printf 'SEAT-EXIT-CONFIRMED %s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$SID" >> "$D/seat-loop.log"
        exit 0
      fi
      SCR="$($SEND capture-pane -p -t "$PANE" 2>/dev/null)"
      T="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
      if printf '%s\n' "$SCR" | command grep -qE "$O1"; then
        stop_dialog "$SCR"
      elif printf '%s\n' "$SCR" | command grep -qE "$DLG"; then
        printf 'SEAT-EXIT-DIALOG-UNREAD %s %s no option-1 line; no key sent\n' "$T" "$SID" >> "$D/seat-loop.log"
      elif printf '%s\n' "$SCR" | command grep -qE "$OTHER_MODAL"; then
        FL="$(printf '%s\n' "$SCR" | command grep -m1 -E "$OTHER_MODAL" | cut -c1-120)"
        printf 'SEAT-EXIT-BLOCKED %s %s %s\n' "$T" "$SID" "$FL" >> "$D/seat-loop.log"
        $SEND display-message -t "$PANE" "SEAT-EXIT-BLOCKED: $FL" 2>/dev/null
        if [ -n "$ISV" ]; then
          printf '{"session_id":"%s"}' "$SID" | bash "$ROOT/scripts/seat-b6-stop.sh" >/dev/null 2>&1
          exit 0
        fi
      else
        printf 'SEAT-EXIT-NO-DIALOG %s %s\n' "$T" "$SID" >> "$D/seat-loop.log"
        if [ -n "$ISV" ]; then
          printf '{"session_id":"%s"}' "$SID" | bash "$ROOT/scripts/seat-b6-stop.sh" >/dev/null 2>&1
          exit 0
        fi
      fi
    done ) \
    </dev/null >/dev/null 2>&1 &
  printf 'SEAT-EXIT-SENT %s %s %s %s n=%s%s\n' "$UTC" "$SID" "$PANE" "$I_KIND" "$SN" "${WD:+ watchdog}" >> "$D/seat-loop.log" 2>/dev/null
  exit 0
fi
if [ "$INTENT" = watchdog ]; then
  ROOT="${2:?watchdog: root}"; SID="${3:?watchdog: sid}"; W_KIND="${4:?watchdog: kind}"; W_EP="${5:?watchdog: epoch}"
  W_HEAD="${6:?watchdog: head}"; W_LANE="${7:-}"; W_SLP="${8:?watchdog: sleep}"
  D="$ROOT/.claude"; LOG="$D/seat-loop.log"
  ts() { date -u +%Y-%m-%dT%H:%M:%SZ; }
  ring_hub() { [ -n "$W_LANE" ] && [ "$W_LANE" != foundation ] && bash "$ROOT/scripts/doorbell.sh" ring foundation >/dev/null 2>&1; return 0; }
  refused() { printf 'SEAT-EXIT-WATCHDOG-REFUSED %s %s %s\n' "$(ts)" "$SID" "$1" >> "$LOG"; ring_hub; exit 0; }
  sent_on_record() { local a b c; [ -f "$D/seat-exit-sent" ] || return 1; read -r a b c < "$D/seat-exit-sent" || true; [ "$a" = "$SID" ] && [ "$b" = "$W_EP" ]; }
  sleep "$W_SLP"
  I_K=""; I_S=""; I_E=""
  [ -f "$D/seat-intent" ] && { read -r I_K I_S _ I_E _ < "$D/seat-intent" || true; }
  [ "$I_S" = "$SID" ] && [ "$I_E" = "$W_EP" ] || exit 0          # (1) intent consumed or superseded
  sent_on_record && exit 0                                       # (2) the healthy path already sent
  # (2b) the pane must be THIS seat's: its current path lies inside $ROOT. A watchdog armed inside a throwaway
  # fixture (a probe run from a live seat) inherits the live seat's TMUX_PANE; it must never type into it or ring
  # the hub. Logged in the fixture's own loop log, no ring, no send.
  if [ -n "${TMUX_PANE:-}" ]; then
    PP="$(${SEND_CMD:-tmux} display-message -p -t "$TMUX_PANE" '#{pane_current_path}' 2>/dev/null)"
    RP="$(cd "$ROOT" 2>/dev/null && pwd -P)"; PPP="$(cd "$PP" 2>/dev/null && pwd -P)"
    case "${PPP:-?}/" in "${RP:-//}"/*) : ;; *)
      printf 'SEAT-EXIT-WATCHDOG-NOT-OWN-PANE %s %s pane=%s path=%s\n' "$(ts)" "$SID" "$TMUX_PANE" "${PP:-?}" >> "$LOG"; exit 0 ;;
    esac
  fi
  N0="$(wc -l < "$LOG" 2>/dev/null | tr -d ' ')"; N0="${N0:-0}"
  ( cd "$ROOT" && printf '{"session_id":"%s"}' "$SID" | SEAT_WATCHDOG=1 bash "$ROOT/scripts/seat-b6-stop.sh" ) >/dev/null 2>&1; PRC=$?
  sent_on_record && exit 0                                       # (3) the predicate sent (never a second send)
  NEWL="$(tail -n +"$((N0 + 1))" "$LOG" 2>/dev/null | command grep -E "^SEAT-EXIT-(WATCHDOG-REFUSED|BLOCKED|WAIT|GAVE-UP|DIALOG-UNREAD) [^ ]+ $SID( |$)")"
  if [ "$PRC" -eq 0 ] && [ -n "$NEWL" ]; then
    printf '%s\n' "$NEWL" | command grep -q '^SEAT-EXIT-WATCHDOG-REFUSED ' && ring_hub
    exit 0                                                       # (3) a named outcome
  fi
  printf 'SEAT-EXIT-WATCHDOG-PREDICATE-DEAD %s %s %s\n' "$PRC" "$(ts)" "$SID" >> "$LOG"
  [ "$(git -C "$ROOT" rev-parse HEAD 2>/dev/null)" = "$W_HEAD" ] || refused head-moved
  RL="ledger/restarts/${W_LANE}.tsv"
  W_SEAL="$(seal_paths "$ROOT" "$W_LANE")"
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    p="${line:3}"
    if [ -n "$W_LANE" ] && [ "${line:0:2}" = " M" ] && [ "$p" = "$RL" ]; then
      hsz="$(git -C "$ROOT" cat-file -s "HEAD:$p" 2>/dev/null)"
      [ -n "$hsz" ] && git -C "$ROOT" show "HEAD:$p" | cmp -s - <(head -c "$hsz" "$ROOT/$p") && continue
    fi
    seal_append_exempt "$ROOT" "$W_SEAL" "$line" && continue
    refused tree-dirty
  done <<< "$(git -C "$ROOT" status --porcelain --untracked-files=no 2>/dev/null)"
  [ -n "${TMUX_PANE:-}" ] || refused no-pane
  printf '%s %s %s\n' "$SID" "$W_EP" 1 > "$D/seat-exit-sent"
  exec bash "$ROOT/scripts/seat-exit.sh" send "$ROOT" "$SID" "$TMUX_PANE" "$W_KIND" 1 watchdog
fi
if [ "$INTENT" = next-state ]; then
  NS_FILE="${2:-}"; NS_ANY=""; [ "${3:-}" = --any-number ] && NS_ANY=1
  [ -n "$NS_FILE" ] && [ -f "$NS_FILE" ] || { echo "usage: scripts/seat-exit.sh next-state <file> [--any-number]" >&2; exit 2; }
  awk -v any="$NS_ANY" '
    !seen && /^## NEXT([ \t].*)?$/ { seen = 1; next }
    seen && /^## / { exit }
    seen && $0 !~ /^[ \t]*$/ {
      if (any != "" && $0 ~ /^[ \t]*[0-9]+\.[ \t]/) r = "ITEM"
      else if ($0 ~ /^[ \t]*1\.[ \t]/) r = "ITEM"
      else if (index($0, "NAMED-WAIT: ") > 0) r = "WAIT"
      else r = "NONE"
      exit
    }
    END { print (r == "" ? "NONE" : r) }' "$NS_FILE"
  exit 0
fi
refuse() { echo "SEAT-EXIT REFUSED ($INTENT): $*" >&2; exit 2; }

ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || refuse "not inside a git worktree"
D="$ROOT/.claude"
# shellcheck source=scripts/subagent-lib.sh
. "$ROOT/scripts/subagent-lib.sh" || refuse "scripts/subagent-lib.sh unreadable"
if [ "$INTENT" = recheck ]; then
  SID="${SEAT_SID:-}"
  [ -n "$SID" ] || refuse "SEAT_SID unset (recheck is called by the Stop hook with the session in hand)"
else
  if [ -z "${TMUX:-}" ] && [ "$INTENT" != clear-subagent ]; then
    # The refusal surfaces outside the refused session: a log line plus a ring to foundation from a module lane
    # (a refusal printed only to the refused session is a participant-carried signal).
    printf 'SEAT-EXIT-REFUSED %s %s not-tmux\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "${CLAUDE_CODE_SESSION_ID:-?}" >> "$D/seat-loop.log" 2>/dev/null
    RF_LANE="$(bash "$ROOT/scripts/resolve-project.sh" --field lane "$ROOT" 2>/dev/null)"
    [ -n "$RF_LANE" ] && [ "$RF_LANE" != foundation ] && bash "$ROOT/scripts/doorbell.sh" ring foundation >/dev/null 2>&1
  fi
  [ -n "${TMUX:-}" ] || [ "$INTENT" = clear-subagent ] || refuse "not a tmux seat; exit by hand"
  SID="${CLAUDE_CODE_SESSION_ID:-}"
  [ -n "$SID" ] || refuse "CLAUDE_CODE_SESSION_ID unset: run this from the seat's own tool shell"
fi
if [ "$INTENT" = clear-subagent ]; then
  AID="${2:-}"
  [ -n "$AID" ] || refuse "usage: scripts/seat-exit.sh clear-subagent <agent_id>"
  sa_live "$D" "$SID" | awk -F'\t' -v a="$AID" '$2==a {f=1} END {exit !f}' \
    || refuse "no live ledger entry $AID for session $SID (.claude/subagents-live)"
  sa_drop "$D" "$SID" "$AID"
  printf 'SUBAGENT-CLEARED %s %s %s by-hand\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$SID" "$AID" >> "$D/seat-loop.log"
  echo "SEAT-EXIT: cleared subagent $AID of session $SID (receipt in .claude/seat-loop.log)"
  exit 0
fi

DIRTY="$(git -C "$ROOT" status --porcelain --untracked-files=no)"
# The auditor's ledgers are exempt when their dirt is PURE APPEND. The exempt list is DERIVED from
# the ONE seal writer's `G add ` lines (scripts/audit-seal.sh, MECH-AUDIT; before it, the post-commit hook's S1
# block), never retyped here. `${lane}` in a path is this lane (the restart ledger). Exempt only an
# UNSTAGED modification (porcelain " M") whose numstat deletions = 0 AND whose HEAD bytes are a prefix of the
# working bytes. Anything else, including an underivable list, falls through to the refusal below, as before 0329.
SE_LANE="$(bash "$ROOT/scripts/resolve-project.sh" --field lane "$ROOT" 2>/dev/null)"   # the stamp's lane: field (same reader as handoff:)
SEAL_PATHS="$(seal_paths "$ROOT" "$SE_LANE")"   # the seal writer's G add lines (scripts/audit-seal.sh), via the ONE definition above
APPEND_OK=""
if [ -n "$DIRTY" ] && [ -n "$SEAL_PATHS" ]; then
  REST=""
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    # --summary is empty for a pure content edit; it names a mode change (auditor 6245b454 F1) or a type change.
    if seal_append_exempt "$ROOT" "$SEAL_PATHS" "$line"; then
      APPEND_OK="$APPEND_OK ${line:3}"; continue
    fi
    REST="$REST$line"$'\n'
  done <<< "$DIRTY"
  DIRTY="${REST%$'\n'}"
fi
[ -z "$DIRTY" ] || refuse "tracked changes present (B6.1: commit or stash + ledger note first):
$DIRTY"
[ -z "$APPEND_OK" ] || echo "SEAT-EXIT: auditor ledger append-only dirt exempt (sealed at this boundary by scripts/audit-seal.sh):$APPEND_OK"

HANDOFF="$(bash "$ROOT/scripts/resolve-project.sh" --field handoff "$ROOT")" \
  || refuse "no 'handoff:' field in _boot/BOOTSTRAP.md front-matter (the lane's handoff surface is undeclared)"
# The boot anchor is this session's FIRST seat-boot.log line (any source). A manual /compact re-fires
# SessionStart under the same session id and appends a later line; reading the last line would move the anchor
# past work already done (false refusal of the handoff check; silent miss in the untracked list). One anchor serves
# both checks (0340 §1). §2: if the first SURVIVING line (the log keeps 500) is not `startup`, say so; never refuse.
ANCHOR="$(awk -v s="$SID" '$1==s {print $2, $3, $4; exit}' "$ROOT/.claude/seat-boot.log" 2>/dev/null)"
read -r BOOT_SHA BOOT_UTC BOOT_SRC <<< "$ANCHOR"
[ -z "${BOOT_SRC:-}" ] || [ "$BOOT_SRC" = startup ] || echo "BOOT-ANCHOR: first surviving line is $BOOT_SRC (session $SID; the startup line was trimmed or never written)"
[ -n "${BOOT_SHA:-}" ] || refuse "no boot record for session $SID in .claude/seat-boot.log (SessionStart hook scripts/seat-boot-record.sh did not run for this session; relaunch by hand)"
if git -C "$ROOT" diff --quiet "$BOOT_SHA" HEAD -- "$HANDOFF"; then
  refuse "handoff surface '$HANDOFF' unchanged since this session's boot sha ${BOOT_SHA:0:8} (B6.1: write the handoff and commit it)"
fi
# 0425 §4: a changed handoff must carry a `## NEXT` heading whose first item is numbered (any N.) or a
# NAMED-WAIT line, in at least one changed *.md of the surface (a file surface is itself). Placed before the
# recheck early-exit so the Stop hook re-tests it at fire time.
NS_OK=""; NS_TMP="$(mktemp "${TMPDIR:-/tmp}/seatexit-next.XXXXXX")"
while IFS= read -r nsf; do
  [ -n "$nsf" ] || continue
  [ -f "$ROOT/${HANDOFF%/}" ] || case "$nsf" in *.md) ;; *) continue ;; esac
  git -C "$ROOT" show "HEAD:$nsf" > "$NS_TMP" 2>/dev/null || continue
  case "$(bash "$0" next-state "$NS_TMP" --any-number)" in ITEM|WAIT) NS_OK=1; break ;; esac
done < <(git -C "$ROOT" diff --name-only "$BOOT_SHA" HEAD -- "$HANDOFF")
rm -f "$NS_TMP"
[ -n "$NS_OK" ] || refuse "handoff surface '$HANDOFF' changed but carries no '## NEXT' heading followed by a numbered item or a NAMED-WAIT line (0425 §4)"
[ "$INTENT" = recheck ] && exit 0

HEAD_SHA="$(git -C "$ROOT" rev-parse HEAD)"
UNTRACKED="$(git -C "$ROOT" status --porcelain --untracked-files=normal | grep -c '^??' || true)"
NOW="$(sa_now)"
LIVE="$(sa_live "$D" "$SID")"
# Untracked, non-ignored files whose mtime is at or after this session's boot are listed for the
# successor (.claude/untracked-since-boot, gitignored; printed as UNTRACKED-SINCE-BOOT by the next seat boot, then
# cleared). Never blocks. The boot time is BOOT_UTC from the anchor above (the session's first line, 0342 §1), the
# record the handoff check reads. If it cannot be parsed, every untracked file is listed (fails toward MORE listing).
BOOT_EPOCH="$(date -j -u -f '%Y-%m-%dT%H:%M:%SZ' "$BOOT_UTC" +%s 2>/dev/null)"
SINCE="$D/untracked-since-boot"
git -C "$ROOT" ls-files --others --exclude-standard -z | while IFS= read -r -d '' p; do
  m="$(stat -f %m "$ROOT/$p" 2>/dev/null)"
  [ -n "$BOOT_EPOCH" ] && [ -n "$m" ] && [ "$m" -lt "$BOOT_EPOCH" ] && continue
  printf '%s\n' "$p"
done > "$SINCE.$$" && mv -f "$SINCE.$$" "$SINCE"
NSINCE="$(grep -c . "$SINCE" 2>/dev/null || true)"
# (MECH-AUDIT, loop-cure member "restart ledger"): ONE tracked line per restart boundary, appended here and
# committed by the boundary seal (scripts/audit-seal.sh, run by the Stop hook before /exit). Format (TAB):
# utc_iso lane intent head_sha. Per-lane file = single writer. A re-run at the same HEAD with the same intent is
# the SAME boundary re-declared, so it is not appended twice (no overcount). Counted per UTC day per lane by E12.
[ -n "${SE_LANE:-}" ] || refuse "lane unresolved (scripts/resolve-lane.sh); the restart ledger line cannot be attributed"
RLOG="$ROOT/ledger/restarts/${SE_LANE}.tsv"
mkdir -p "$ROOT/ledger/restarts" || refuse "could not create ledger/restarts/"
LAST="$(tail -1 "$RLOG" 2>/dev/null)"
if [ "$(printf '%s' "$LAST" | cut -f3-4)" = "$(printf '%s\t%s' "$INTENT" "$HEAD_SHA")" ]; then
  echo "SEAT-EXIT: restart ledger already holds this boundary ($INTENT @ ${HEAD_SHA:0:8}); not appended again"
else
  printf '%s\t%s\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$SE_LANE" "$INTENT" "$HEAD_SHA" >> "$RLOG" \
    || refuse "could not append to ledger/restarts/${SE_LANE}.tsv"
  echo "SEAT-EXIT: restart ledger line appended (ledger/restarts/${SE_LANE}.tsv; sealed at this boundary)"
fi
IDLE=""; [ -n "$LIVE" ] && IDLE=" when-idle"
TMP="$ROOT/.claude/seat-intent.$$"
printf '%s %s %s %s %s%s\n' "$INTENT" "$SID" "$HEAD_SHA" "$NOW" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$IDLE" > "$TMP" \
  && mv -f "$TMP" "$ROOT/.claude/seat-intent" || refuse "could not write .claude/seat-intent"


echo "SEAT-EXIT: intent=$INTENT session=$SID head=${HEAD_SHA:0:8} handoff=$HANDOFF moved-since=${BOOT_SHA:0:8} untracked=$UNTRACKED (kept on disk)"
echo "SEAT-EXIT: ${NSINCE:-0} untracked file(s) created since boot ${BOOT_UTC:-<unparsed: all listed>} listed for the next boot (.claude/untracked-since-boot)"
if [ -n "$LIVE" ]; then
  DL=0
  while IFS=$'\t' read -r _ _ _ st _ _; do
    t=$(( st + $(sa_eff_cap "$st" "$NOW") + ABANDON_AFTER_MIN * 60 )); [ "$t" -gt "$DL" ] && DL="$t"
  done <<< "$LIVE"
  SLP="${WATCHDOG_SLEEP:-$(( DL > NOW ? DL - NOW + 5 : 5 ))}"
  echo "SEAT-EXIT: ${INTENT}-when-idle — $(printf '%s\n' "$LIVE" | grep -c .) live subagent(s): $(printf '%s\n' "$LIVE" | cut -f2 | tr '\n' ' ')"
  echo "SEAT-EXIT: the exit waits for each to stop, at most to its effective cap + ${ABANDON_AFTER_MIN} min (cap ${SUBAGENT_CAP_MIN} min, grace ${RESTART_GRACE_MIN} min); watchdog fires in ${SLP}s"
else
  # 0444 R1: no live subagent -> the witness still arms, and fires no later than 5 minutes after the intent.
  SLP="${WATCHDOG_SLEEP:-300}"
fi
printf 'SEAT-EXIT-WATCHDOG-ARMED %s %s sleep=%ss\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$SID" "$SLP" >> "$D/seat-loop.log"
# 0444 R1/R2: armed for EVERY intent. nohup + disown: this runs from the seat's tool shell, which ends before the
# deadline. It runs this script's own `watchdog` verb by ABSOLUTE path, so it does not depend on the hook surface or
# the session cwd; it inherits TMUX_PANE, which the send needs. See the `watchdog` verb above for what it does.
nohup bash "$ROOT/scripts/seat-exit.sh" watchdog "$ROOT" "$SID" "$INTENT" "$NOW" "$HEAD_SHA" "${SE_LANE:-}" "$SLP" \
  </dev/null >/dev/null 2>&1 &
disown 2>/dev/null || true
# 0387 §3 item 4 ("handoff lines", kept unchanged by 0398 §3): print IN-FLIGHT <kind> <id> <class>
# <output path> for every live subagent ledger entry AND every own background-shell task not yet
# completed, so B6.1's handoff surface can name them before the exit — these are the successor's own
# reading list (0398 §3). Classified by the ONE classifier (scripts/subagent-lib.sh) so this line and
# scripts/seat-boot-assess.sh cannot disagree on a class.
if [ -n "$LIVE" ]; then
  while IFS=$'\t' read -r _ aid _ st _ tp; do
    [ -n "$aid" ] || continue
    [ -n "$tp" ] && [ -e "$tp" ] || tp="UNRESOLVED"
    CR="$(sa_classify_subagent "$D" "$SID" "$aid" "$st" "$NOW" "$(sa_intent_epoch "$D" "$SID")")"
    echo "SEAT-EXIT: IN-FLIGHT subagent $aid ${CR%% *} $tp"
  done <<< "$LIVE"
fi
TDIR="$(sa_task_dir "$ROOT" "$SID")"
if [ -d "$TDIR" ]; then
  for f in "$TDIR"/*.output; do
    [ -e "$f" ] || continue
    [ -L "$f" ] && continue   # a subagent's transcript symlink here is already covered by the loop above
    sa_shell_done "$f" && continue
    TID="$(basename "$f" .output)"
    CMD="$(sa_shell_cmd "$ROOT" "$SID" "$TID")"
    CR="$(sa_classify_shell "$f" "$CMD" "$NOW")"
    echo "SEAT-EXIT: IN-FLIGHT shell $TID ${CR%% *} $f"
  done
fi
echo "SEAT-EXIT: no keystroke sent by this script; end the turn now. The Stop hook sends /exit to this pane, then the loop $([ "$INTENT" = restart ] && echo relaunches || echo ends the session)."
exit 0
