#!/usr/bin/env bash
# Shared lane-identity resolver (spine-owned per COORDINATION.md §13(1)).
# location -> _boot/BOOTSTRAP.md -> lane, with stamp<->branch cross-check.
# Consumers: (a) interactive seat §0 cold-boot; (b) Slice-1 post-commit hook.
# Resolves the COMMITTING/own WORKTREE root; never trunk-hardcoded, never cwd-assumed.
# Exit 0 = resolved (prints one KEY=VALUE line). Exit 3 = HALT (unresolved/mismatch);
#          caller MUST NOT default to foundation on exit 3.
set -u

WT_ROOT="${GIT_WORK_TREE:-$(git rev-parse --show-toplevel 2>/dev/null)}"
[[ -z "$WT_ROOT" ]] && { echo "LANE-UNRESOLVED: no worktree root" >&2; exit 3; }

BOOT="$WT_ROOT/_boot/BOOTSTRAP.md"
[[ -f "$BOOT" ]] || { echo "LANE-UNRESOLVED: missing $BOOT" >&2; exit 3; }

# Read a KEY from the YAML frontmatter block ONLY (between the first two '---').
field() {
  awk -v k="$1" '
    /^---[[:space:]]*$/ { d++; next }
    d==1 && index($0, k":")==1 { s=$0; sub("^" k ":[[:space:]]*", "", s); print s; exit }
  ' "$BOOT"
}

LANE=$(field lane); ROLE=$(field role); VERSION=$(field bootstrap_version); SPINE_WRITE=$(field spine_write)
STAMP_BRANCH=$(field worktree_branch)
[[ -z "$LANE" ]] && { echo "LANE-UNRESOLVED: _boot present, lane: unset" >&2; exit 3; }

# STAMP-VS-LOCATION cross-check (security property), built ONLY from local bytes: this worktree's own stamp and
# its own git branch (window plan row 7). No branch->lane map, no ref read, no manifest
# read: identity comes from LOCATION (CLAUDE.md s0). A stamp mis-committed into another worktree must NOT
# resolve clean, so three checks run, each a HALT (exit 3):
#   1. the stamp's worktree_branch: equals the branch this worktree has checked out;
#   2. on a module/<x> branch the stamped lane is <x> (generic convention, no project identifier);
#   3. spine_write: ALLOW only on the trunk `main` (closes the copied-integrator-stamp forgery).
BRANCH=$(git -C "$WT_ROOT" rev-parse --abbrev-ref HEAD 2>/dev/null)
if [[ -z "$BRANCH" || "$STAMP_BRANCH" != "$BRANCH" ]]; then
  echo "LANE-MISMATCH: stamp worktree_branch='$STAMP_BRANCH' != branch '$BRANCH' (stamp lane='$LANE')" >&2
  exit 3
fi
if [[ "$BRANCH" == module/* && "$LANE" != "${BRANCH#module/}" ]]; then
  echo "LANE-MISMATCH: stamp lane='$LANE' != branch '$BRANCH' (a module/<x> branch carries lane '<x>')" >&2
  exit 3
fi
if [[ "$SPINE_WRITE" == ALLOW && "$BRANCH" != {{TRUNK_BRANCH}} ]]; then
  echo "LANE-MISMATCH: stamp spine_write=ALLOW on branch '$BRANCH' (ALLOW is the trunk's only; stamp lane='$LANE')" >&2
  exit 3
fi

# ---- B1 CURRENCY GATE (thesis-PLAN §B2; HARDENED) ----
# Non-fatal, fail-safe; NEVER blocks boot. HARDENED 2026-08-10: currency is
# now a LIVE git-delta anchored on the DELIBERATE `absorbed_through_sha:` marker in CHECKLIST — it
# measures a READ. It REPLACES the old `Last refresh` DATE trigger (the proven false-green: a single
# self-stamped date bought 7d of silence through the entire surge-firefight). Visible enforcement is
# `scripts/boot-check.sh` (stdout) + the settings.json SessionStart hook; this stderr line is the belt.
CURRENCY=CURRENT
CHK="$WT_ROOT/CHECKLIST.md"
if [[ -f "$CHK" ]]; then
  anchor=$(sed -n 's/^\*\*absorbed_through_sha:\*\*[[:space:]]*//p' "$CHK" 2>/dev/null | grep -oE '[0-9a-f]{7,40}' | head -1)
  if [[ -n "$anchor" ]] && git -C "$WT_ROOT" cat-file -e "$anchor" 2>/dev/null; then
    delta=$(git -C "$WT_ROOT" rev-list --count "${anchor}..HEAD" -- CHECKLIST.md issues_register.md disciplines.md _rulings dispatch 2>/dev/null || echo 0)
    { [[ "$delta" =~ ^[0-9]+$ ]] && [[ "$delta" -gt 0 ]]; } && CURRENCY=STALE-BOOT
  else
    CURRENCY=STALE-BOOT   # no deliberate anchor present => a stamp is owed
  fi
fi
if [[ "$CURRENCY" == STALE-BOOT ]]; then
  if [[ "$SPINE_WRITE" == ALLOW ]]; then   # the integrator class, read from the stamp (no lane literal)
    echo "STALE-BOOT: unabsorbed governance delta since absorbed_through_sha -> integrator FIRST WP = run scripts/boot-check.sh, absorb to HEAD, re-stamp the marker." >&2
  else
    echo "STALE-BOOT: unabsorbed governance delta -> run scripts/boot-check.sh; proceed, emit in BOOT-ACK." >&2
  fi
fi

# ---- SUBAGENT MODEL (ALL subagents on Sonnet, ALL seats) -----
# The `sonnet` ALIAS, never a pinned id: Claude Code resolves it to the newest Sonnet at spawn,
# so the value never goes stale on a model release. Emitted so every seat can CITE it in
# BOOT-ACK. Resolution order at spawn (Claude Code >= 2.1.251): the per-call model parameter,
# then the definition's frontmatter (`.claude/agents/*.md model: sonnet`), then the env var
# CLAUDE_CODE_SUBAGENT_MODEL (settings.json `env`, same alias), then the main model. The env var
# canNOT be set from here: this script runs in an eval'd boot subshell whose env does not
# propagate to the parent claude process. This field documents the value.
SUBAGENT_MODEL=sonnet

BLOB=$(git hash-object "$BOOT")
printf 'lane=%s role=%s version=%s spine_write=%s blob=%s currency=%s subagent_model=%s\n' \
  "$LANE" "$ROLE" "$VERSION" "$SPINE_WRITE" "$BLOB" "$CURRENCY" "$SUBAGENT_MODEL"
