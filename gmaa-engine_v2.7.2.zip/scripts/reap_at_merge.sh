#!/usr/bin/env bash
# scripts/reap_at_merge.sh <module-lane> — Slice-1 [C]: audit-at-merge.
#
# Integrator-only (foundation/main). Merges module/<lane> into the spine and lets the
# foundation post-commit hook RE-AUDIT the incoming module work at the merge point,
# emitting the lane-stamped [audit] seal on main. Single-writer literal: the
# integrator is the only committer of both the merge commit and the audit seal; the
# module produced no audit record (only a lane marker, per the lightened module path).
#
# Architect ruling 2026-06-24 ([C] = audit-at-merge): "the Auditor receipt licenses
# merge-to-main, and C produces that receipt at the merge, by the integrator."
#
# INTEGRATION-EXCLUSION (COORDINATION.md §13(2)): `_boot/**` is lane-provisioning
# metadata, NOT module work-product. A module branch's `_boot/BOOTSTRAP.md` carries
# its own lane stamp; it must NEVER overwrite main's foundation stamp. This script
# restores main's `_boot/**` after the merge tree is computed, unconditionally
# (whether git conflicted on it or silently took the module side).
#
# HALT-LOUD: any merge conflict OUTSIDE `_boot/**` aborts (does not smooth a partial
# merge into a pass) — surface it, fix in-iter.
#
# FORCED MERGE-PATH (SET-AUTH-IMPL-01 item 3, C-SET-AUTHORIZATION §2): this is the ONLY
# sanctioned module→trunk merge route. It exports REAP_AT_MERGE=1 so the pre-merge-commit hook
# (agents/pre-merge-commit-hook.sh) recognises it as sanctioned and lets it through, while a RAW
# `git merge` into the trunk (no sentinel) is REJECTED. The reap already uses `--no-commit` (so
# pre-merge-commit does not fire and pre-commit/M6(i) runs on the `git commit`); the sentinel is
# belt-and-suspenders for any future auto-committing refactor.
set -u
export REAP_AT_MERGE=1

LANE_ARG="${1:?usage: reap_at_merge.sh <lane>   (any lane declared in _orchestration/lane-provisioning.md)}"
REPO_ROOT="$(git rev-parse --show-toplevel)"
cd "$REPO_ROOT" || { echo "HALT: cannot cd to repo root"; exit 1; }
# shellcheck source=scripts/lane-surface.sh
source "$REPO_ROOT/scripts/lane-surface.sh" || { echo "HALT: scripts/lane-surface.sh missing/unreadable (fail-closed)."; exit 1; }

# Assert integrator identity from LOCATION (must be the foundation/main worktree).
if ! LANE_LINE="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>/dev/null)"; then
    echo "HALT: lane unresolved ($LANE_LINE) — reap-at-merge runs only on the foundation worktree."; exit 3
fi
eval "$LANE_LINE"
[[ "${lane:-}" == "foundation" ]] || { echo "HALT: reap-at-merge is integrator-only; this worktree is lane='${lane:-?}'."; exit 1; }
# Clean-tree precondition — but TOLERATE dirty ledger/ (KINK flushed by the first live
# merge 2026-06-24): under reap-then-audit there is ALWAYS pending auditor output (the
# output) until the next restart boundary, whose seal (scripts/audit-seal.sh, MECH-AUDIT) carries it,
# and the merge never touches ledger/. So block only on non-ledger uncommitted work.
DIRTY="$(git status --porcelain | cut -c4- | grep -v '^ledger/' || true)"
[[ -z "$DIRTY" ]] || { echo "HALT: working tree has non-ledger changes; refusing to merge."; echo "$DIRTY" | sed 's/^/  /'; exit 1; }

# Every declared lane resolves its branch + authority class through the ONE shipped resolver
# (scripts/lane-surface.sh), keyed on the manifest's DECLARED CLASS — never a name/pattern
# (`module/<lane>` is false for 2 of 6 lanes: architect -> branch 'architect'; the apply-receipts-only
# lane -> branch 'exec'). apply-receipts-only is the one class whose ONLY permitted spine output is
# ledger/apply-receipts/** (integration-INCLUDED — reaped here into the spine ledger; the ratified
# carve-out); every other class is module-kind work.
lane_manifest_load || { echo "HALT: lane manifest unreadable (${LANE_MANIFEST_ERROR:-?}) — cannot resolve '$LANE_ARG'."; exit 3; }
BRANCH="$(lane_branch "$LANE_ARG")" || { echo "HALT: '$LANE_ARG' is not a declared lane (scripts/lane-surface.sh)."; exit 1; }
LANE_CLASS="$(lane_class "$LANE_ARG")" || { echo "HALT: cannot resolve the authority class for lane '$LANE_ARG' (scripts/lane-surface.sh)."; exit 1; }
if [[ "$LANE_CLASS" == "apply-receipts-only" ]]; then
    IS_EXEC=1; WORK_KIND="apply-receipt"
else
    IS_EXEC=; WORK_KIND="module"
fi
git rev-parse --verify -q "$BRANCH" >/dev/null 2>&1 || { echo "HALT: no such branch $BRANCH"; exit 1; }
INCOMING="$(git rev-list --count "HEAD..$BRANCH")"
[[ "$INCOMING" -gt 0 ]] || { echo "nothing to merge: $BRANCH is not ahead of $(git rev-parse --abbrev-ref HEAD)."; exit 0; }

echo "reap-at-merge: $BRANCH ($INCOMING commit(s) ahead) -> $(git rev-parse --abbrev-ref HEAD)"
echo "incoming:"; git log --oneline "HEAD..$BRANCH" | sed 's/^/  /'
SK_OUT="$(bash "$REPO_ROOT/scripts/seat-keys.sh" verify-range "$LANE_ARG" "HEAD..$BRANCH" --ref HEAD 2>&1)" || { echo "HALT: K4 -- an incoming commit on $BRANCH is not signed by the registered key of lane $LANE_ARG (judged at the spine HEAD, never the lane copy; unsigned, another lane key, or a revoked key all HALT here, before the merge tree):" >&2; echo "  $SK_OUT" >&2; exit 2; }; echo "  $SK_OUT"
# === SET-MEMBERSHIP GATE (M6(ii); NO-CHERRY-PICK — C-RATIFICATION-PACKET §5, canon §4) ===
# A module branch reaches main ONLY inside a RATIFIED set naming its lane. The execution lane's `exec`
# apply-receipts stream rides its OWN ratified carve-out (per-receipt — NOT
# set-membership) and is EXEMPT here (IS_EXEC). Enforced BEFORE the merge tree is computed, so a
# non-member branch never touches the index. (LIFT from GMAA frozen 7a179264 M6(ii).)
# `- decision: RATIFIED` prefix-matches BOTH merge states (RATIFIED · RATIFIED-WITH-SEQUENCE);
# AMENDED/HELD/REJECTED members are NOT ratified → correctly non-members here. Membership is BY LANE
# NAME in the packet's ## MEMBERS section (the shape scripts/ratify.sh writes: `lane=<lane> · …`).
RECEIPT_LINE=""
if [[ -z "${IS_EXEC:-}" ]]; then
    # The check is ONE function shared with the spine host's receive unit (one function, two callers): same packets read from
    # the work tree as before the move, same named HALT lines (printed by the function), same exit 3.
    source "$REPO_ROOT/scripts/set-membership.sh" || { echo "HALT: scripts/set-membership.sh missing/unreadable (fail-closed)." >&2; exit 3; }
    RATIFIED_PACKET="$(m6ii_member "$LANE_ARG" "$BRANCH" - "$REPO_ROOT")"; M6RC=$?
    [[ "$M6RC" -eq 0 && -n "$RATIFIED_PACKET" ]] || exit 3
    # canon §4 receipt line (verbatim shape), carried into the merge commit + auditable on main.
    PKT="$REPO_ROOT/_ratification/$RATIFIED_PACKET.md"
    if awk '/^## JOINT-EDGES/{j=1;next} /^## /{j=0} j' "$PKT" | grep -q 'NONE'; then
        EDGES="NONE"
    else
        EDGES="$(awk '/^## JOINT-EDGES/{j=1;next} /^## /{j=0} j' "$PKT" | grep -E '^- ' | sed 's/^- *//; s/^UNRESOLVED · //; s/^RESOLVED · //' | paste -sd'; ' - )"
        [[ -z "$EDGES" ]] && EDGES="NONE"
    fi
    RECEIPT_LINE="member ${LANE_ARG} evaluated against the set {${RATIFIED_PACKET}}: joint edges = ${EDGES}"
    echo "set-membership: $BRANCH ratified in ${RATIFIED_PACKET}."
    echo "  receipt: ${RECEIPT_LINE}"
fi

# Compute the merge tree without committing (so we can apply §13(2) exclusion first).
git merge --no-ff --no-commit "$BRANCH" >/dev/null 2>&1 || true   # may pause on conflicts

# §13(2) + ROUTING (architect 2026-06-25): integration-EXCLUDE _boot/** AND
# _orchestration/relay-outbox/** — make the index match MAIN's HEAD EXACTLY. A plain
# `git checkout HEAD -- <dir>` only restores both-side files; it does NOT drop the module's
# ADDED files (its CHARTER-<lane>.md, its outbox surfaces) → they would LEAK onto spine
# (ISSUE-BOOT-EXCLUSION-ADDS-LEAK-2026-06-25). exclude_to_head restores HEAD then unstages ONLY
# the additions (worktree untouched; identity-safe — NOT rm -rf), with a fail-closed identity guard.
exclude_to_head() {  # returns nonzero on identity-guard failure
    local ex f
    for ex in "$@"; do
        git checkout HEAD -- "$ex" 2>/dev/null || true
        # After `git checkout HEAD -- "$ex"` restores HEAD's version of every BOTH-SIDE file, the ONLY
        # remaining index-vs-HEAD diff under "$ex" is the module's ADDED files (its CHARTER-<lane>.md,
        # its relay-outbox surfaces). Drop each from BOTH the index AND the worktree:
        #   - `git rm --cached` unstages (keeps it off spine — correct), BUT
        #   - alone it leaves the file as UNTRACKED worktree residue, which trips the NEXT reap's
        #     clean-tree DIRTY check (line ~45) → forces a hand-reap (SET-0003 hygiene fix).
        # SCOPING GUARD: only files enumerated by `git diff --cached HEAD -- "$ex"`
        # are removed — i.e. ADDs UNDER THE EXCLUDED SET ONLY. NEVER a blanket `git clean` (that would
        # eat unrelated untracked work — a foot-gun). Idempotent (`[[ -e ]]` + `rm -f`) + logged to stderr.
        while IFS= read -r f; do
            [[ -z "$f" ]] && continue
            git rm --cached --quiet --ignore-unmatch -- "$f" >/dev/null 2>&1 || true
            [[ -e "$f" ]] && rm -f -- "$f" && echo "  exclude-residue-dropped: $f" >&2
        done < <(git diff --cached --name-only HEAD -- "$ex" 2>/dev/null)
    done
    git ls-files --cached -- _boot/BOOTSTRAP.md | grep -q .
}
exclude_to_head _boot _orchestration/relay-outbox || {
    echo "HALT: identity guard — _boot/BOOTSTRAP.md missing post-exclusion; aborting merge."
    git merge --abort 2>/dev/null || git reset --hard HEAD; exit 2; }

# HALT-LOUD on any conflict OUTSIDE the integration-excluded paths.
UNMERGED="$(git ls-files -u | awk '{print $4}' | sort -u | grep -vE '^(_boot/|_orchestration/relay-outbox/)' || true)"
if [[ -n "$UNMERGED" ]]; then
    echo "HALT: merge conflict OUTSIDE integration-excluded paths — needs ruling:"; echo "$UNMERGED" | sed 's/^/  - /'
    git merge --abort 2>/dev/null || git reset --hard HEAD
    exit 2
fi

# Sanity: staged merge must not introduce writes to spine/shared-substrate beyond the lane's
# authority class.
#  - module/<lane>: NO spine paths at all (D3 prevents them committing those; assert it).
#  - exec (the execution lane): ONLY ledger/apply-receipts/** is permitted (ratified carve-out);
#    EVERY other spine path — INCLUDING other ledger/ subpaths — HALTS (single-spine-writer preserved).
STAGED="$(git diff --cached --name-only)"
# The lane's OWN restart ledger is the one ledger/ path a lane carries to the spine
# (per-lane file, single writer; this reap is its promotion path). Only the exact own-lane file is exempt.
STAGED="$(printf '%s\n' "$STAGED" | grep -vxF "ledger/restarts/${LANE_ARG}.tsv" || true)"
SPINE_RE='^(ledger/|dag/|issues_register.md|CHECKLIST.md|contracts/|_orchestration/STATE.md|_orchestration/decision-log.md|sql/|migrations/|agents/|scripts/|skill/|src/)'
if [[ -n "${IS_EXEC:-}" ]]; then
    VIOL="$(echo "$STAGED" | grep -vE '^ledger/apply-receipts/' | grep -E "$SPINE_RE" || true)"
else
    VIOL="$(echo "$STAGED" | grep -E "$SPINE_RE" || true)"
fi
if [[ -n "$VIOL" ]]; then
    echo "HALT: incoming merge touches spine/shared-substrate paths beyond lane authority:"; echo "$VIOL" | sed 's/^/  - /'
    git merge --abort 2>/dev/null || git reset --hard HEAD
    exit 2
fi

# Commit the merge (foundation). NOT [audit]-subject -> the foundation post-commit
# hook fires: reap-then-audit re-audits this merge (merge-aware CHANGED_FILES = the
# incoming work vs first parent) and seals it at the next restart boundary (scripts/audit-seal.sh).
git commit -q --no-edit -m "merge $BRANCH: $INCOMING $WORK_KIND commit(s) — audit-at-merge [C] (integrator re-audits incoming work)" ${RECEIPT_LINE:+-m "$RECEIPT_LINE"}
MERGE_SHA="$(git rev-parse --short HEAD)"
echo "merged as $MERGE_SHA (main _boot preserved = foundation). Foundation post-commit auditor re-auditing incoming $WORK_KIND work; [audit] seal lands at the next restart boundary (scripts/audit-seal.sh, MECH-AUDIT)."
