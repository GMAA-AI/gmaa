#!/bin/bash
# scripts/seat-bg-deny.sh — PreToolUse hook on Bash (0387 §3 item 1; stays unchanged per 0398 §3's "what
# stays from 0387 §3"). Once THIS session's own .claude/seat-intent exists (the seat has already decided to
# restart or shut down), a `run_in_background: true` Bash call is denied with the named reason. Same shape
# as scripts/subagent-cap.sh's deny (deny-only hook, zero model calls, always exits 0). Work already in
# flight when the intent was written is unaffected — this only stops a NEW background start AFTER the seat
# has committed to exiting; a foreign session's own intent never gates this session's call.
set -u
IN="$(cat)"
SID="$(printf '%s' "$IN" | jq -r '.session_id // empty' 2>/dev/null)"
[ -n "$SID" ] || exit 0
BG="$(printf '%s' "$IN" | jq -r '.tool_input.run_in_background // false' 2>/dev/null)"
[ "$BG" = "true" ] || exit 0
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
D="$ROOT/.claude"
[ -f "$D/seat-intent" ] || exit 0
I_SID=""
read -r _ I_SID _ < "$D/seat-intent" 2>/dev/null || true
[ "${I_SID:-}" = "$SID" ] || exit 0
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
mkdir -p "$D" 2>/dev/null
printf 'SEAT-BG-DENY %s %s\n' "$UTC" "$SID" >> "$D/seat-loop.log" 2>/dev/null
jq -n '{hookSpecificOutput: {hookEventName: "PreToolUse", permissionDecision: "deny", permissionDecisionReason: "restart intent written; run it in the foreground or after the relaunch"}}'
exit 0
