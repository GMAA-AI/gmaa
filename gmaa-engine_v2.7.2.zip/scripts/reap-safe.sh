#!/usr/bin/env bash
# reap-safe.sh — STANDING reap guard (interim guard, binding until the canon §4
# reconciliation-diff runs).
#
# ⛔ AUTHORED-UNCOMMITTED. Target path `scripts/reap-safe.sh` is a non-set_exempt SPINE_PATH,
#    so these bytes cannot land without a covering ratified set. Parked here until that set.
#
# WHY THIS EXISTS (measured): reaping a batch of architect rulings with
#   `git checkout origin/<lane> -- <DIRECTORY>`
# staged **340** files when **3** were intended — the branch's entire outbox, because a directory
# checkout takes the branch's whole tree state for that path. `origin/architect` legitimately holds
# ~337 branch-only authoring-log artifacts ("expected IN KIND, not proven complete").
# A commit narrated as reaping three named rulings that silently lands 337 historical files is a
# MISREPRESENTED COMMIT — the narration and the diff must match.
#
# THE RULE THIS ENCODES: **REAP BY FILE, NEVER BY DIRECTORY.**
#
# Usage:
#   reap-safe.sh <lane-ref> <path> [<path>...]   # reap named files, refusing directories
#   reap-safe.sh --undo <lane-ref> <dir>         # remove over-reaped files under <dir> (4-test safe)
#
set -u
cd "$(git rev-parse --show-toplevel)" || exit 9

die() { printf 'reap-safe: %s\n' "$*" >&2; exit 2; }

[ $# -ge 2 ] || die "usage: reap-safe.sh <lane-ref> <path>... | --undo <lane-ref> <dir>"

if [ "$1" = "--undo" ]; then
    shift; ref="$1"; dir="$2"
    # 4-TEST SAFETY: remove ONLY files that are (a) untracked now, (b) absent from HEAD,
    # (c) present at <ref>, (d) not explicitly kept via KEEP_RE. Anything failing a test is
    # LEFT IN PLACE and reported — never a blanket `git clean` (standing prohibition).
    KEEP_RE="${KEEP_RE:-__NOTHING_MATCHES__}"
    removed=0; kept=0; skipped=0
    while IFS= read -r f; do
        [ -n "$f" ] || continue
        if printf '%s' "$f" | grep -qE "$KEEP_RE"; then kept=$((kept+1)); continue; fi
        git cat-file -e "HEAD:$f" 2>/dev/null && { echo "SKIP (exists at HEAD): $f"; skipped=$((skipped+1)); continue; }
        git cat-file -e "$ref:$f" 2>/dev/null || { echo "SKIP (not from $ref): $f"; skipped=$((skipped+1)); continue; }
        rm -f -- "$f" && removed=$((removed+1))
    done < <(git ls-files --others --exclude-standard "$dir")
    echo "undo: removed=$removed kept=$kept skipped=$skipped"
    exit 0
fi

ref="$1"; shift
staged=0
for p in "$@"; do
    # REFUSAL 1 — a directory pathspec is the foot-gun. Fail closed, name the count it WOULD have taken.
    if git ls-tree -d --name-only "$ref" -- "$p" 2>/dev/null | grep -q .; then
        n=$(git ls-tree -r --name-only "$ref" -- "$p" 2>/dev/null | wc -l | tr -d ' ')
        die "REFUSED — '$p' is a DIRECTORY at $ref and would stage ~$n files. Reap by FILE."
    fi
    # REFUSAL 2 — the file must actually exist at the source ref (a typo must not silently no-op).
    git cat-file -e "$ref:$p" 2>/dev/null || die "REFUSED — '$p' does not exist at $ref (typo or wrong ref?)."
    # REFUSAL 3 (K4) -- a relay file is reaped only with a detached signature that verifies as its FROM seat, judged at HEAD.
    SK="$(dirname "$0")/seat-keys.sh"; from="$(bash "$SK" relay-from "$p" 2>/dev/null)"; frc=$?
    [ "$frc" -le 1 ] || die "REFUSED -- cannot name the FROM seat of relay path '$p' (seat-keys relay-from rc=$frc)."
    if [ "$frc" -eq 0 ]; then
        rtmp="$(mktemp -d "${TMPDIR:-/tmp}/reap-safe.XXXXXX")" || die "mktemp failed"
        git show "$ref:$p" > "$rtmp/f" 2>/dev/null; git show "$ref:$p.sig" > "$rtmp/f.sig" 2>/dev/null || rm -f "$rtmp/f.sig"
        rout="$(bash "$SK" verify-relay "$rtmp/f" "$from" --ref HEAD 2>&1)" || { rm -rf "$rtmp"; die "REFUSED -- relay '$p' (FROM $from) does not verify: ${rout##*$'\n'}"; }
        rm -rf "$rtmp"
        git checkout "$ref" -- "$p.sig" || die "checkout failed for '$p.sig'"
        staged=$((staged+1)); echo "reaped: $p.sig"
    fi
    git checkout "$ref" -- "$p" || die "checkout failed for '$p'"
    staged=$((staged+1))
    echo "reaped: $p"
done

# RECEIPT — the narration/diff match check the incident turned on: what you asked for vs what staged.
actual=$(git diff --cached --name-only | wc -l | tr -d ' ')
echo "---"
echo "requested: $staged file(s)  |  staged in index: $actual"
[ "$staged" -eq "$actual" ] || echo "⚠ MISMATCH — index holds $actual staged path(s) but this reap asked for $staged. Inspect before committing; a commit's narration must match its diff."
