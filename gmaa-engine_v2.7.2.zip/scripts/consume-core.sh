#!/usr/bin/env bash
# scripts/consume-core.sh — THE ONE consume/seen/shown state machine.
#
# WHY:
#   `inbox.sh` (module lanes) and `inboxf.sh` (the hub) are two FRONT DOORS over the SAME state machine.
#   Until now each carried its own copy of seen/shown/consume. **Two copies of a rule drift** — and this
#   particular rule is the one that decides whether a relay is silently marked read. A drift here
#   re-creates the silent-miss class one layer down, which is the whole failure this transport work exists
#   to kill. The standing rule: *"the consume state-machine is SHARED, never re-implemented."*
#
# ⭐ THE ONLY DIFFERENCE BETWEEN THE TWO FRONT DOORS IS A PLUGGABLE SOURCE ENUMERATOR.
#   The caller sets CORE_MARKER / CORE_SHOWN and defines `core_enumerate` (emitting one item id per line);
#   everything about *when an item counts as seen* lives here and nowhere else.
#
# ⛔ INVARIANT PRESERVED FROM `inbox.sh` — DO NOT WEAKEN IT:
#   `consume --all` is bounded by the SHOWN snapshot (the names the most-recent check DISPLAYED), never by
#   the live set. That closes the TOCTOU swallow where a relay landing AFTER a check but BEFORE a blind
#   `consume --all` was marked seen UNREAD (ISSUE-INBOX-CONSUME-ALL-SWALLOWS-UNREAD, silent message-loss).
# ⛔ AND: the marker advances ONLY on consume (you ACTED), NEVER on the read. A glanced-past read must not
#   mark seen, or the silent miss returns under a different name.

set -u
# the one spine-ref resolver, found BESIDE THIS FILE only (0507 R2), resolved once at source time
_CC_SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"

# ── THE RELAY-NAME PREDICATE. ONE definition, here, beside the one enumeration rule. ─────────────────────
# A name in a relay-inbox or relay-outbox directory is a RELAY only if it does not begin with `.`, does not
# end in `.sig`, and is not `README.md`. Every shipped reader that enumerates relay names calls it, so a
# signature sidecar or a directory marker cannot count as a relay in one reader and not in another (a
# sidecar counted as unconsumed makes the inbox-age filer read every lane as stuck). Consume does not use
# it: a sidecar is not a relay, so it is never counted and needs no mark. scripts/seat-keys.sh relay_from
# keeps its own path case statement, for signing, and agrees with this on every name.
core_is_relay_name() {  # core_is_relay_name <basename> : 0 = a relay, 1 = not a relay
    case "$1" in ''|.*|*.sig|README.md) return 1 ;; esac
    return 0
}
core_filter_relay_names() {  # stdin: one basename per line -> stdout: only the relay names, order kept
    local n
    while IFS= read -r n; do core_is_relay_name "$n" && printf '%s\n' "$n"; done
    return 0
}

core_init() {  # core_init <marker-path> <shown-path>
    CORE_MARKER="$1"; CORE_SHOWN="$2"
    mkdir -p "$(dirname "$CORE_MARKER")"
    # row 17 blob cache: the caller's enumerator notes each item's CURRENT blob (core_note_blob). Per process,
    # in TMPDIR, never in the worktree, so a refusal still leaves the filesystem as found.
    CORE_BLOBS="$(mktemp "${TMPDIR:-/tmp}/core-blobs.XXXXXX" 2>/dev/null)" || CORE_BLOBS=""
    [[ -n "$CORE_BLOBS" ]] && trap 'rm -f "$CORE_BLOBS"' EXIT
    # NO marker creation here: this runs at SOURCE time, before any verb, so
    # creating the marker made every invocation — a refusal included — mutate a genesis-fresh hub. The
    # marker is born LAZILY by the first core_mark_seen append (`>>` creates it); every reader tolerates
    # its absence (core_is_seen: 2>/dev/null; inbox.sh: `-s` guard). A refusal leaves the filesystem as found.
}

# ── Row 17 (canon §5 a landed message cannot drop): the seen-state also records the BLOB. ──────
# Identity stays the id (the basename, or `<src>\t<basename>` at the hub). A marker line is either a legacy
# `<id>` or `<id>\t<40-hex blob>`; the LAST line for an id wins (the marker stays append-only). An item that is
# seen with a DIFFERENT blob was AMENDED AFTER CONSUME: it is pending again, shown ONCE with a label by the
# caller, and re-marked with the new blob on consume. A legacy line (no blob) is seen at whatever blob is
# current; `core_migrate` writes the current blob beside every legacy line at cutover, so the first amendment
# after the cutover re-shows. The caller's enumerator feeds blobs with `core_note_blob <id> <blob>`; an id with
# no noted blob behaves exactly as before row 17 (name-only), never a guessed value.
core_note_blob() { [[ -n "$CORE_BLOBS" && -n "${2:-}" ]] && printf '%s\t%s\n' "$1" "$2" >> "$CORE_BLOBS"; return 0; }
core_blob() {      # current blob of <id>, from the enumerator's notes (empty if none)
    [[ -n "$CORE_BLOBS" ]] || return 0
    # a path that never enumerated (consume by name) fills the cache ONCE; the guard stops a recursion when
    # the enumerator itself asks whether an id is current before the cache holds a single note
    if [[ ! -s "$CORE_BLOBS" && -z "${_CORE_FILLING:-}" ]] && declare -F core_enumerate >/dev/null; then
        _CORE_FILLING=1 core_enumerate >/dev/null 2>&1
    fi
    [[ -s "$CORE_BLOBS" ]] || return 0
    awk -v id="$1" 'BEGIN{n=length(id)} substr($0,1,n+1)==id "\t" && length($0)==n+41 {b=substr($0,n+2)} END{if(b!="")print b}' "$CORE_BLOBS"
}
core_recorded() {  # the marker's last record for <id>: a blob, LEGACY, or nothing (unseen)
    [[ -s "$CORE_MARKER" ]] || return 0
    awk -v id="$1" 'BEGIN{n=length(id)}
        $0==id {r="LEGACY"; next}
        substr($0,1,n+1)==id "\t" && length($0)==n+41 && substr($0,n+2) ~ /^[0-9a-f]+$/ {r=substr($0,n+2)}
        END{if(r!="")print r}' "$CORE_MARKER" 2>/dev/null
}
core_is_seen()   { [[ -n "$(core_recorded "$1")" ]]; }        # seen BY NAME (any blob)
core_amended() {   # prints "<old7> -> <new7>" and returns 0 iff seen with a recorded blob that differs from now
    local rec cur; rec="$(core_recorded "$1")"; [[ -n "$rec" && "$rec" != LEGACY ]] || return 1
    cur="$(core_blob "$1")"; [[ -n "$cur" && "$cur" != "$rec" ]] || return 1
    printf '%s -> %s\n' "${rec:0:7}" "${cur:0:7}"
}
core_is_current() { core_is_seen "$1" && ! core_amended "$1" >/dev/null; }   # seen, and not amended since
core_mark_seen() {
    local cur rec; cur="$(core_blob "$1")"; rec="$(core_recorded "$1")"
    if [[ -n "$cur" ]]; then [[ "$rec" == "$cur" ]] || printf '%s\t%s\n' "$1" "$cur" >> "$CORE_MARKER"
    else [[ -n "$rec" ]] || printf '%s\n' "$1" >> "$CORE_MARKER"; fi
}
# core_migrate — cutover (row 17 migration): every legacy line whose item has a noted blob gets that
# blob recorded beside it (seen AT ITS CURRENT BLOB, so nothing re-shows at cutover). Prints the count.
core_migrate() {
    local n=0 id
    [[ -s "$CORE_MARKER" ]] || { printf '0\n'; return 0; }
    while IFS= read -r id; do
        [[ -n "$id" ]] || continue
        [[ "$(core_recorded "$id")" == LEGACY ]] || continue
        [[ -n "$(core_blob "$id")" ]] || continue
        core_mark_seen_blob_now "$id"; n=$((n+1))
    done < <(awk '!/\t[0-9a-f]{40}$/' "$CORE_MARKER" | sort -u)
    printf '%s\n' "$n"
}
core_mark_seen_blob_now() { printf '%s\t%s\n' "$1" "$(core_blob "$1")" >> "$CORE_MARKER"; }

# core_select_noncurrent — stdin ids -> the ids that are NOT current (unseen, or seen with a recorded blob
# that differs from the noted one). ONE awk over the marker + the blob cache for the whole set: a per-id call
# chain cost ~3 processes per item, +8.5 s per hub check over a 1966-line marker (measured 2026-10-06).
# Same rule as core_is_current, in one pass; the noted blobs must be complete before it runs.
core_select_noncurrent() {
    awk -v M="$CORE_MARKER" -v B="${CORE_BLOBS:-/dev/null}" '
        function parse(line) {
            if (line ~ /\t[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]$/) {
                pid = substr(line, 1, length(line) - 41); pv = substr(line, length(line) - 39)
            } else { pid = line; pv = "LEGACY" }
        }
        BEGIN {
            while ((getline l < M) > 0) { if (l == "") continue; parse(l); rec[pid] = pv }
            while ((getline l < B) > 0) { if (l == "") continue; parse(l); if (pv != "LEGACY") cur[pid] = pv }
        }
        $0 != "" {
            if (!($0 in rec)) { print; next }
            r = rec[$0]
            if (r != "LEGACY" && ($0 in cur) && cur[$0] != r) print
        }'
}

# core_pending — items from the caller's enumerator that are NOT current: unseen, or amended after consume.
# The enumerator runs to completion FIRST, so every blob is noted before the one-pass selection reads them.
core_pending() {
    local ids; ids="$(core_enumerate)"
    [[ -n "$ids" ]] || return 0
    printf '%s\n' "$ids" | core_select_noncurrent
}

# core_record_shown — snapshot exactly what a check displayed. `consume --all` is bounded by THIS.
core_record_shown() { : > "$CORE_SHOWN"; while IFS= read -r id; do printf '%s\n' "$id" >> "$CORE_SHOWN"; done; }

# ── PREMISE AT PICKUP. ONE definition, so the two front doors cannot drift.
# CLAUDE.md §PREMISE-CHECK fires "before you work OR route any INHERITED item"; `consume` is the one place
# pickup is already a verb. So the verb REFUSES without the premise, structurally: zero judgment, zero false
# positives, one argument per item. The pair is recorded beside the marker (same durability as the marker).
# core_take_premise "$@" -> strips --premise <v> / --premise=<v>, leaves the rest in CORE_ARGS, sets CORE_PREMISE.
# Returns 2 (REFUSE, marker untouched) when the premise is absent or malformed.
core_take_premise() {
    CORE_ARGS=(); CORE_PREMISE=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --premise)   CORE_PREMISE="${2:-}"; if [[ $# -ge 2 ]]; then shift 2; else shift; fi ;;
            --premise=*) CORE_PREMISE="${1#--premise=}"; shift ;;
            --all)       CORE_ARGS+=("$1"); shift ;;
            -*)  # SURFACED 2026-09-22: an unknown flag was filed as a relay NAME and written to the
                 # marker (exit 0, "consumed"). A marker a typo can write is not a marker. REFUSE, never guess.
                 echo "consume: REFUSED — unknown flag '$1' (known: --premise <v>, --all). Marker NOT advanced." >&2
                 return 2 ;;
            *)           CORE_ARGS+=("$1"); shift ;;
        esac
    done
    if ! [[ "$CORE_PREMISE" =~ ^(holds|refuted)@[^[:space:]]+$ ]]; then
        echo "consume: REFUSED — every consume carries its PREMISE-CHECK:" >&2
        echo "    --premise holds@<ref>    (premise still true at HEAD)" >&2
        echo "    --premise refuted@<ref>  (premise false: RETRACT, do not work or route it)" >&2
        echo "  got: '${CORE_PREMISE:-<none>}'. Marker NOT advanced." >&2
        return 2
    fi
}
core_record_premise() {
    printf '%s\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "${CORE_PREMISE:-}" >> "${CORE_MARKER}.premise"
}
core_consume_one() { if declare -F core_consume_guard >/dev/null; then core_consume_guard "$1" || return 1; fi; core_mark_seen "$1"; core_record_premise "$1"; }

# core_consume_all — bounded by the SHOWN snapshot AND the still-pending set: SHOWN ∩ pending ∩ unseen.
# ⛔ ONE CARRIER (window plan row 2; canon s4 one rule, one carrier): the spoke door used
#    to carry its own intersection with still-pending and the hub door did not, so the two doors had drifted.
#    The intersection lives HERE now, for both doors: a shown id is consumed only if the caller's
#    `core_enumerate` still lists it. An enumerate that fails yields no pending ids, so the verb consumes
#    nothing (fails toward unread, never toward a swallowed message).
core_consume_all() {
    local n=0 id pend
    [[ -f "$CORE_SHOWN" ]] || { echo "consume --all: no prior check in this worktree — run a check first (the snapshot is what bounds this)." >&2; return 2; }
    pend="$(core_pending)"
    while IFS= read -r id; do
        [[ -n "$id" ]] || continue
        core_is_current "$id" && continue
        printf '%s\n' "$pend" | grep -qxF -- "$id" || continue   # must still be pending at the source
        core_consume_one "$id" && n=$((n+1))
    done < "$CORE_SHOWN"
    printf '%s\n' "$n"
}

core_seed_all() {  # cold start: seal everything currently visible so a first check reports only new arrivals
    local n=0 id
    while IFS= read -r id; do
        [[ -n "$id" ]] || continue
        core_is_current "$id" || { core_mark_seen "$id"; n=$((n+1)); }
    done < <(core_enumerate)
    printf '%s\n' "$n"
}

# core_relay_check <ref> <path> <from-lane> -- the transport-plane signature check, shared by both doors.
# 0 = the relay at <ref>:<path> carries a detached signature (namespace relay) that verifies as <from-lane>, judged at the
# spine registry; 1 = REFUSED, and ONE named line is printed on stdout. A refused relay is never shown as readable and
# never consumed (the callers skip it; the guard below stops an explicit consume). A missing verifier is a refusal too.
core_relay_check() {
    local ref="$1" path="$2" from="$3" sk="${_SELF_DIR:-}/seat-keys.sh" d out rc
    if [[ ! -f "$sk" ]]; then echo "REFUSED: ${path} :: seat-keys.sh missing at ${sk} (a relay is never read unverified)"; return 1; fi
    d="$(mktemp -d "${TMPDIR:-/tmp}/relay-check.XXXXXX")" || { echo "REFUSED: ${path} :: mktemp failed"; return 1; }
    if ! git show "${ref}:${path}" > "$d/f" 2>/dev/null; then rm -rf "$d"; echo "REFUSED: ${path} :: cannot read it at ${ref}"; return 1; fi
    git show "${ref}:${path}.sig" > "$d/f.sig" 2>/dev/null || rm -f "$d/f.sig"
    # the judging ref (the one spine-ref resolver): CORE_RELAY_REF if set (a replica/test knob), else the ONE resolver
    # scripts/spine-ref.sh; no resolution is a refusal by name, never a literal fallback (inv #5).
    local jref="${CORE_RELAY_REF:-}"
    [[ -n "$jref" || -f "$_CC_SPINE_REF_SH" ]] || { rm -rf "$d"; echo "REFUSED: ${path} :: SPINE-REF-ABSENT $_CC_SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2)"; return 1; }
    [[ -n "$jref" ]] || jref="$(bash "$_CC_SPINE_REF_SH")" \
        || { rm -rf "$d"; echo "REFUSED: ${path} :: SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and CORE_RELAY_REF unset (the one spine-ref resolver)"; return 1; }
    out="$(bash "$sk" verify-relay "$d/f" "$from" --ref "$jref" 2>&1)"; rc=$?
    out="${out//$d\/f/$path}"; rm -rf "$d"
    if [[ $rc -ne 0 ]]; then echo "REFUSED: ${path} :: ${out##*$'\n'}"; return 1; fi
    return 0
}
