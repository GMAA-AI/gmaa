#!/bin/bash
# scripts/backgrounded-sessions.sh — 0398 §2 item 3: the successor's reading list.
# Prints `BACKGROUNDED-SESSIONS: <n>` = live predecessor background sessions on THIS worktree, plus every orphan
# harness shell whose cwd is this worktree, plus the newest restart handoff's IN-FLIGHT lines. A receipt, zero
# judgment: the seat acts on it by 0398 §3 (ASSESS line per item; WORKING keep, else stop).
# Sources (DISC-CITE-THE-ENFORCER): `claude agents --json --cwd <root>` (the harness's own listing; live docs
# code.claude.com/docs/en/agent-view, read 2026-10-08) and `ps` + `lsof` as the cross-check. Why the cross-check
# is not optional: `claude stop <id>` ends the session process but leaves its background shell alive under pid 1
# (observed live 2026-10-08), so a session count alone reads 0 while work still runs.
# Never prints 0 on an unreadable source (DISC-ABSENCE-OF-RECORD): UNREADABLE instead. Always exits 0.
# Fallback (agent view may be off on a seat, and the listing may then not answer): when `claude agents --json` gives
# no JSON array, the sessions are read from the process tree (each `--bg-pty-host` process, or a child of one, whose
# cwd is this worktree), and the `fork` lines of .claude/seat-boot.log since the last `startup` are listed beside
# them. The line names the source it used (`source=`). UNREADABLE only when the process tree is unreadable too.
# Seams (tests only): BG_ROOT, BG_CLAUDE_BIN, BG_PS_BIN (ps).
set -u
ROOT="${BG_ROOT:-$(git rev-parse --show-toplevel 2>/dev/null)}" || ROOT=""
[ -n "$ROOT" ] || { echo "BACKGROUNDED-SESSIONS: UNREADABLE — not inside a git worktree"; exit 0; }
CLAUDE_BIN="${BG_CLAUDE_BIN:-claude}"
PSOUT="$("${BG_PS_BIN:-ps}" -axo pid=,ppid=,command= 2>/dev/null)" || PSOUT=""
J="$("$CLAUDE_BIN" agents --json --cwd "$ROOT" 2>/dev/null)"
cwd_of() { lsof -a -p "$1" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -1; }
in_root() { case "$1" in "$ROOT"|"$ROOT"/*) return 0 ;; esac; return 1; }
FALLBACK=""
if ! printf '%s' "$J" | jq -e 'type == "array"' >/dev/null 2>&1; then
  if [ -z "$PSOUT" ]; then
    echo "BACKGROUNDED-SESSIONS: UNREADABLE — '${CLAUDE_BIN} agents --json --cwd ${ROOT}' gave no JSON array, and the process tree (fallback) is unreadable"
    exit 0
  fi
  FALLBACK=1
fi
# live = a background row whose pid is alive; rows with no pid are exited registry entries (no process, no seat)
# O1 (audit of 4b0ca3d8): `claude agents --json` background rows carry their classification in `.state`
# (blocked/done/stopped), never `.status` (always null on a background row) — read `.state`, print it
# verbatim (never re-labelled "exited": that word is this script's own inference, not the harness's).
# O2 (audit of 4b0ca3d8): a bash `read` under `IFS=$'\t'` collapses a run of tabs (tab is IFS whitespace),
# so an EMPTY middle field vanishes and later fields shift left. The per-row join below uses the unit
# separator (\x1f, never IFS whitespace) instead of a literal tab, so an empty field stays its own field.
LIVE=""; EXITED=0; STATES=""
if [ -n "$FALLBACK" ]; then
  # a host is a claude binary (argv0) carrying --bg-pty-host as its own word; never a substring of another command line
  HOSTS="$(printf '%s\n' "$PSOUT" | awk '$3 ~ /(^|\/)claude$/ && / --bg-pty-host( |$)/ {print $1}')"
  while read -r pid ppid cmd; do
    [ -n "$pid" ] || continue
    printf '%s\n' "$HOSTS" | grep -qx "$pid" || printf '%s\n' "$HOSTS" | grep -qx "$ppid" || continue
    in_root "$(cwd_of "$pid")" || continue
    LIVE="${LIVE}  BG-SESSION pid=${pid} source=process-tree cmd=$(printf '%s' "$cmd" | cut -c1-120)"$'\n'
  done <<< "$PSOUT"
  FORKS="$(awk '$4=="startup" {f=""; next} $4=="fork" {f=f "  BG-FORK-LINE " $1 " " $3 "\n"} END {printf "%s", f}' "$ROOT/.claude/seat-boot.log" 2>/dev/null)"
  NF_="$(printf '%s' "$FORKS" | grep -c '^  BG-FORK-LINE ' || true)"
  [ -r "$ROOT/.claude/seat-boot.log" ] || NF_="n/a(no .claude/seat-boot.log)"
  SRC_USED="fallback: the process tree + .claude/seat-boot.log fork lines since the last startup=${NF_} ('${CLAUDE_BIN} agents --json' gave no JSON array)"
fi
[ -n "$FALLBACK" ] || SRC_USED="claude agents --json"
[ -n "$FALLBACK" ] || while IFS=$'\x1f' read -r id pid state name; do
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    LIVE="${LIVE}  BG-SESSION ${id} pid=${pid} state=${state:-?} name=${name}"$'\n'
  else
    EXITED=$((EXITED + 1))
    STATES="${STATES}${state:-?}"$'\n'
  fi
done < <(printf '%s' "$J" | jq -r '.[] | select(.kind == "background") | [(.id // .sessionId // "?"), (.pid // "" | tostring), (.state // ""), (.name // "")] | join("\u001f")')
NS="$(printf '%s' "$LIVE" | grep -c '^  BG-SESSION ' || true)"
# A bare tally of the registry rows' own harness states (printed verbatim, not re-inferred; "none" when
# there are no such rows — never a silent empty string, DISC-ABSENCE-OF-RECORD).
if [ -n "$FALLBACK" ]; then
  STATE_TALLY="n/a (fallback has no registry)"
elif [ -z "$STATES" ]; then
  STATE_TALLY="none"
else
  STATE_TALLY="$(printf '%s' "$STATES" | sort | uniq -c | awk '{printf "%s=%s ", $2, $1}' | sed 's/ $//')"
fi
# orphan harness shells (ppid 1, a shell-snapshot wrapper) whose cwd is this worktree
ORPH=""
while read -r pid ppid cmd; do
  [ "$ppid" = 1 ] || continue
  case "$cmd" in *"/.claude/shell-snapshots/snapshot-"*) : ;; *) continue ;; esac
  cwd="$(lsof -a -p "$pid" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -1)"
  case "$cwd" in "$ROOT"|"$ROOT"/*) : ;; *) continue ;; esac
  what="$(printf '%s' "$cmd" | sed -n 's/.* eval //p' | sed 's/ < \/dev\/null.*//' | cut -c1-120)"
  ORPH="${ORPH}  BG-ORPHAN-SHELL pid=${pid} cmd=${what:-?}"$'\n'
done <<< "$PSOUT"
NO="$(printf '%s' "$ORPH" | grep -c '^  BG-ORPHAN-SHELL ' || true)"
echo "BACKGROUNDED-SESSIONS: $((NS + NO)) (sessions=${NS} orphan-shells=${NO}; exited registry rows=${EXITED}, not seats; states=${STATE_TALLY}; source=${SRC_USED}) — ASSESS each per 0398 §3"
printf '%s' "$LIVE$ORPH${FORKS:-}"
H="$(ls -t "$ROOT"/dispatch/WIP-*-restart-HANDOFF.md 2>/dev/null | head -1)"
if [ -n "$H" ]; then
  grep -E 'IN-FLIGHT' "$H" 2>/dev/null | head -10 | sed "s|^|  IN-FLIGHT(${H#"$ROOT"/}): |"
fi
exit 0
