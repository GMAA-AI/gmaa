#!/bin/bash
# scripts/subagent-cap.sh — PreToolUse hook: the per-subagent wall-clock cap (the per-subagent bound rule).
# Keyed on `agent_id` ONLY. The hub's own calls carry no agent_id and are never touched, even though under
# `claude --agent orc` they DO carry agent_type (live hooks page) — so agent_type is
# never used as the discriminator here.
#   - no agent_id                              -> exit 0, no output (allow; the other PreToolUse hooks decide)
#   - agent_id: append `utc session_id agent_id` to .claude/subagent-calls.log (0337 §2(c): the turn-count data)
#   - its ledger age >= effective cap          -> permissionDecision "deny" with the fixed reason (both numbers)
#   - agent_id with no ledger line             -> allow (start unknown: it began before this hook was bound);
#                                                 logged as `SUBAGENT-UNLEDGERED` once per agent_id
# Effective cap = SUBAGENT_CAP_MIN, or with an own-session intent pending min(CAP, age-at-intent + GRACE)
# (scripts/subagent-lib.sh, the one definition). Zero model calls. Always exits 0.
set -u
IN="$(cat)"
AID="$(printf '%s' "$IN" | jq -r '.agent_id // empty' 2>/dev/null)"
[ -n "$AID" ] || exit 0
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
D="$ROOT/.claude"; mkdir -p "$D" 2>/dev/null
# shellcheck source=scripts/subagent-lib.sh
. "$ROOT/scripts/subagent-lib.sh" 2>/dev/null || exit 0
SID="$(printf '%s' "$IN" | jq -r '.session_id // empty' 2>/dev/null)"
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf '%s %s %s\n' "$UTC" "${SID:--}" "$AID" >> "$D/subagent-calls.log" 2>/dev/null
ST="$(sa_live "$D" "$SID" | awk -F'\t' -v a="$AID" '$2==a {print $4; exit}')"
if [ -z "$ST" ]; then
  /usr/bin/grep -q " $AID\$" "$D/subagent-unledgered" 2>/dev/null \
    || printf 'SUBAGENT-UNLEDGERED %s %s %s\n' "$UTC" "${SID:--}" "$AID" | tee -a "$D/subagent-unledgered" >> "$D/seat-loop.log"
  exit 0
fi
NOW="$(sa_now)"; AGE=$((NOW - ST))
CAP="$(sa_eff_cap "$ST" "$(sa_intent_epoch "$D" "$SID")")"
[ "$AGE" -ge "$CAP" ] || exit 0
AGE_M=$((AGE / 60)); CAP_M=$((CAP / 60))
REASON="Subagent wall-clock cap reached (${AGE_M} min of ${CAP_M} min). Stop using tools. Return now: what you finished, what you did not, and the path of any file you wrote."
printf 'SUBAGENT-CAP-DENY %s %s %s age=%ss cap=%ss\n' "$UTC" "$SID" "$AID" "$AGE" "$CAP" >> "$D/seat-loop.log" 2>/dev/null
jq -n --arg r "$REASON" '{hookSpecificOutput: {hookEventName: "PreToolUse", permissionDecision: "deny", permissionDecisionReason: $r}}'
exit 0
