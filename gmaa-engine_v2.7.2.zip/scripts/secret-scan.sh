#!/usr/bin/env bash
# scripts/secret-scan.sh — commit-time credential scan over the ADDED lines of the staged change.
#
# Usage:  secret-scan.sh --staged                 scan `git diff --cached -U0` (added lines only)
#         secret-scan.sh --file <path> [--patterns <tsv>]
#                                                 self-test mode: scan a whole file; --patterns swaps the list
# Exit:   0 clean · 1 a credential pattern matched (REFUSED, pattern + file:line named, matched text never printed)
#         2 scanner error (unreadable input, git/awk failure, grep rc >= 2): FAIL CLOSED, never a silent pass.
#
# Pattern list (name<TAB>ERE), a generic documented set of well-known credential shapes:
#   aws-access-key-id · github-token · anthropic-api-key · private-key-block · slack-token · storage-account-key
# Not a complete scanner: it catches the shapes above, not arbitrary high-entropy strings. Binary files carry no
# added text lines in a -U0 diff and are not scanned. Matches are located by file:line only; the secret is not echoed.
# Every grep is checked for rc 2 (an invalid ERE exits 2; an empty hit count would read as 0 = clean). Input goes
# through files, never `printf | grep -q` under pipefail (SIGPIPE race).
set -u

HITS_ERR() { echo "secret-scan ERROR: $*" >&2; exit 2; }

TAB="$(printf '\t')"
BUILTIN="aws-access-key-id${TAB}AKIA[0-9A-Z]{16}
github-token${TAB}gh[pousr]_[A-Za-z0-9]{36,}
anthropic-api-key${TAB}sk-ant-[A-Za-z0-9_-]{20,}
private-key-block${TAB}-----BEGIN [A-Z ]*PRIVATE KEY-----
slack-token${TAB}xox[baprs]-[A-Za-z0-9-]{10,}
storage-account-key${TAB}AccountKey=[A-Za-z0-9+/=]{40,}"

MODE=""; FILE=""; PATFILE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --staged) MODE=staged; shift ;;
    --file) [ $# -ge 2 ] || HITS_ERR "--file needs a path"; MODE=file; FILE="$2"; shift 2 ;;
    --patterns) [ $# -ge 2 ] || HITS_ERR "--patterns needs a path"; PATFILE="$2"; shift 2 ;;
    *) HITS_ERR "unknown argument $1" ;;
  esac
done
[ -n "$MODE" ] || HITS_ERR "usage: --staged | --file <path> [--patterns <tsv>]"
[ -z "$PATFILE" ] || [ "$MODE" = file ] || HITS_ERR "--patterns is self-test only (with --file)"

TMP="$(mktemp -d "${TMPDIR:-/tmp}/secret-scan.XXXXXX")" || HITS_ERR "cannot create temp dir"
trap 'rm -rf "$TMP"' EXIT
ADDED="$TMP/added.tsv"   # lines: <path>\t<newline-no>\t<text>

if [ "$MODE" = staged ]; then
  git diff --cached -U0 --no-color --no-ext-diff --diff-filter=ACMR > "$TMP/diff.txt" 2> "$TMP/git.err" \
    || HITS_ERR "git diff --cached failed: $(head -c 200 "$TMP/git.err")"
  awk -v OFS='\t' '
    /^\+\+\+ / { p=$0; sub(/^\+\+\+ (b\/)?/, "", p); next }
    /^--- /    { next }
    /^@@ /     { s=$0; sub(/^@@ -[0-9,]+ \+/, "", s); sub(/[ ,].*$/, "", s); n=s+0; next }
    /^\+/      { print p, n, substr($0, 2); n++ }
  ' "$TMP/diff.txt" > "$ADDED" || HITS_ERR "awk over the staged diff failed"
else
  [ -r "$FILE" ] || HITS_ERR "unreadable input: $FILE"
  awk -v OFS='\t' -v p="$FILE" '{ print p, NR, $0 }' "$FILE" > "$ADDED" || HITS_ERR "awk over $FILE failed"
fi

if [ -n "$PATFILE" ]; then
  [ -r "$PATFILE" ] || HITS_ERR "unreadable pattern file: $PATFILE"
  PATS="$(cat "$PATFILE")" || HITS_ERR "cannot read pattern file: $PATFILE"
else
  PATS="$BUILTIN"
fi
[ -n "$PATS" ] || HITS_ERR "empty pattern list"

bad=0; npat=0
while IFS="$TAB" read -r name ere; do
  [ -n "$name" ] || continue
  [ -n "$ere" ] || HITS_ERR "pattern '$name' has an empty ERE"
  npat=$((npat+1))
  command grep -nE -e "$ere" "$ADDED" > "$TMP/hits.txt" 2> "$TMP/grep.err"
  rc=$?
  case "$rc" in
    0) bad=1
       while IFS= read -r h; do
         rest="${h#*:}"; f="${rest%%${TAB}*}"; r2="${rest#*${TAB}}"; ln="${r2%%${TAB}*}"
         echo "secret-scan REFUSED: pattern '$name' matched at $f:$ln (matched text not printed)." >&2
       done < "$TMP/hits.txt" ;;
    1) : ;;
    *) HITS_ERR "grep rc=$rc on pattern '$name': $(head -c 200 "$TMP/grep.err")" ;;
  esac
done <<< "$PATS"
[ "$npat" -gt 0 ] || HITS_ERR "no usable patterns"

if [ "$bad" -eq 1 ]; then
  echo "  A credential in a committed record is pushed and reaped onto the spine. Remove it from the staged change; rotate it if it was ever real. No --no-verify." >&2
  exit 1
fi
echo "secret-scan: clean ($npat patterns, $(wc -l < "$ADDED" | tr -d ' ') added lines)"
exit 0
