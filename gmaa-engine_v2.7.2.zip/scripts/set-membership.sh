#!/usr/bin/env bash
# scripts/set-membership.sh -- M6(ii) NO-CHERRY-PICK as ONE sourced function with two callers (the merge reaper and the spine host's receive unit):
#   scripts/reap_at_merge.sh (the local reap, packets from the work tree, as before the move) and
#   the spine host's pre-receive check (HELD; an adopter supplies it on a forge the seats do not administer), packets at the judged merge commit's FIRST PARENT, 0489 R6.
# Source it; it defines one function and runs nothing. Bash 3.2 safe.
#
# m6ii_member <lane> <branch-label> <rev|-> [<root>]
#   rev = "-"  : read <root>/_ratification/SET-*.md from the work tree (<root> required; the reap's REPO_ROOT)
#   rev = <sha>: read the packets _ratification/SET-<NNNN>.md at that commit (git ls-tree / git show in the current repository)
#   stdout: the RATIFIED packet's name (SET-NNNN) on membership, rc 0.
#   stderr: the NAMED refusal, rc 3, when no RATIFIED packet's ## MEMBERS names lane=<lane>. Both callers print this
#           same line, so the server's refusal and the reap's HALT read alike (0489 §3 P4).
#   rc 2: the packet set is unreadable at <rev> (fail-closed, inv #5; never a member by default).
# `- decision: RATIFIED` prefix-matches both merge states (RATIFIED · RATIFIED-WITH-SEQUENCE); AMENDED/HELD/REJECTED
# are non-members. Membership is BY LANE NAME in ## MEMBERS (the shape scripts/ratify.sh writes: `lane=<lane> · ...`).
m6ii_member() {
    local lane="$1" label="$2" rev="$3" root="${4:-}" p name body list
    if [[ "$rev" == "-" ]]; then
        [[ -n "$root" ]] || { echo "set-membership: HALT no root given for a work-tree read" >&2; return 2; }
        for p in "$root"/_ratification/SET-*.md; do
            [[ -e "$p" ]] || continue
            grep -qE '^- decision: RATIFIED' "$p" || continue
            if awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$p" | grep -qE "lane=${lane}( |·|,|$)"; then
                basename "$p" .md; return 0
            fi
        done
    else
        list="$(git ls-tree --name-only "$rev" _ratification/ 2>/dev/null)" \
            || { echo "set-membership: HALT cannot list _ratification/ at $rev (fail-closed)" >&2; return 2; }
        while IFS= read -r p; do
            case "$p" in _ratification/SET-*.md) ;; *) continue ;; esac
            body="$(git show "$rev:$p" 2>/dev/null)" || { echo "set-membership: HALT cannot read $p at $rev (fail-closed)" >&2; return 2; }
            printf '%s\n' "$body" | grep -qE '^- decision: RATIFIED' || continue
            if printf '%s\n' "$body" | awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' | grep -qE "lane=${lane}( |·|,|$)"; then
                name="${p#_ratification/}"; echo "${name%.md}"; return 0
            fi
        done <<EOF
$list
EOF
    fi
    echo "HALT: NO-CHERRY-PICK — module branch '$label' is not a member of any RATIFIED set" >&2
    echo "  (C-RATIFICATION-PACKET §5: RETURNED/unratified content reaches main ONLY inside a future ratified set)." >&2
    echo "  Assemble + ratify a set including lane '${lane}' before merge: scripts/ratify.sh assemble → assess → ratify." >&2
    return 3
}
