#!/usr/bin/env bash
# scripts/check_orchestration_freshness.sh
# Per chat-Architect 2026-05-28 RELAY (post-relay-8 stack)
#
# Asserts:
#   1. .claude/session_state.json mtime within STATE_BUDGET_DAYS (default 7)
#      REPOINTED 2026-06-23 (chat-Architect): _orchestration/STATE.md reclassified a
#      FROZEN historical pointer (no v2 surface reads it); the live integrator boot
#      surface is .claude/session_state.json. NOTE: session_state.json is gitignored/
#      local-only — meaningful in the auditor's working tree, not a clean checkout.
#   2. _orchestration/decision-log.md mtime within DECISION_BUDGET_DAYS (default 14)
#   3. _orchestration/decision-log.md has at least 1 BOUND entry
# Output: "FRESH" on PASS (exit 0) or "STALE: <reason>" on FAIL (exit 1)

set -u
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"
[ -z "$REPO_ROOT" ] && REPO_ROOT="$(dirname "$0")/.."
cd "$REPO_ROOT" || exit 1

STATE_BUDGET_DAYS=${STATE_BUDGET_DAYS:-7}
DECISION_BUDGET_DAYS=${DECISION_BUDGET_DAYS:-14}

STATE=".claude/session_state.json"
DECISION="_orchestration/decision-log.md"

NOW=$(date +%s)
DAYS() { echo $(( ( NOW - $1 ) / 86400 )); }

# 1. STATE.md exists + fresh
if [ ! -f "$STATE" ]; then
  echo "STALE: $STATE missing"
  exit 1
fi
STATE_MTIME=$(stat -f %m "$STATE" 2>/dev/null || stat -c %Y "$STATE")
STATE_AGE_D=$(DAYS $STATE_MTIME)
if [ "$STATE_AGE_D" -gt "$STATE_BUDGET_DAYS" ]; then
  echo "STALE: $STATE age=${STATE_AGE_D}d > budget=${STATE_BUDGET_DAYS}d"
  exit 1
fi

# 2. decision-log.md exists + fresh
if [ ! -f "$DECISION" ]; then
  echo "STALE: $DECISION missing"
  exit 1
fi
DECISION_MTIME=$(stat -f %m "$DECISION" 2>/dev/null || stat -c %Y "$DECISION")
DECISION_AGE_D=$(DAYS $DECISION_MTIME)
if [ "$DECISION_AGE_D" -gt "$DECISION_BUDGET_DAYS" ]; then
  echo "STALE: $DECISION age=${DECISION_AGE_D}d > budget=${DECISION_BUDGET_DAYS}d"
  exit 1
fi

# 3. decision-log has at least 1 BOUND entry
if [ -f "$DECISION" ]; then BOUND_N=$(grep -c "Status:.*BOUND" "$DECISION"); else BOUND_N=0; fi  # grep -c prints 0 itself; only a missing FILE needs a guard.
if [ "$BOUND_N" -lt 1 ]; then
  echo "STALE: $DECISION has 0 BOUND entries"
  exit 1
fi

echo "FRESH: STATE age=${STATE_AGE_D}d decision-log age=${DECISION_AGE_D}d BOUND_entries=${BOUND_N}"
exit 0
