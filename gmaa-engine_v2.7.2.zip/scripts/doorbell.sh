#!/usr/bin/env bash
# scripts/doorbell.sh — SPEC-DOORBELL v0.2 wrapper. tmux = BELL, git inbox = TRANSPORT.
# Foundation rings a lane so it takes a turn → its first-action INBOX-CHECK fires now (vs next operator spawn).
# Payload is NEVER here — it lives in the durable inbox (_orchestration/relay-inbox/<lane>/). A dropped bell
# DELAYS, never LOSES.
#
#   doorbell.sh ring <lane>          R1 resolve + R2 two-phase send + R3 fail-loud + R5 fixed token + submit-verify
#   doorbell.sh ack  <lane> <ref>    R4: poll the lane's outbox for a NEW surface since <ref> (consume-ack); HALT-LOUD on none
#
# v0.2 R1 IMPL NOTE (surfaced to architect): the live pane_title is dynamically overwritten by Claude Code
# (e.g. "✳ Orc <LANE>") — NOT the stable `<lane>` token §2 R1 assumed. The SESSION_NAME (per module lane) is the clean,
# unique key, so R1 resolves by session_name (pane_title corroborates). Exactly-one match required → else HALT.
set -u

# ── DIRECTION-AWARE WAKE TOKEN ──────────
# THE DEFECT THIS REPLACES: one fixed token that always said "your payload is in your git inbox."
# For a hub→lane ring that is TRUE. For a lane→hub ring it is FALSE — lane→hub delivery is
# outbox + reap, and `relay-inbox/foundation/` is empty BY DESIGN. So the bell pointed foundation at
# the one surface that could not hold the payload, and `inbox.sh` then truthfully reported "empty."
# MEASURED 2026-09-20: 10+ such readings while three lanes had written. The operator was the detector.
#
# ⛔ A BELL MAY STATE A LOCATION ONLY IF IT RESOLVED ONE. No fabricated pointer: if the caller's
#    branch/surface cannot be resolved, the token says so rather than naming a path that may not exist.
_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# sibling-resolved (not $REPO_ROOT) so a cross-worktree invocation still finds it.
# `|| true` is CORRECT here and deliberately kept: the token builder degrades to a
# self-describing "could not resolve my outbox" message, never to a fabricated path.
. "$_SELF_DIR/lane-surface.sh" 2>/dev/null || true

wake_token() {  # wake_token <target_lane> -> the token to send
    local target="$1" caller cbranch csurface csha
    # hub→lane: the payload really is in the lane's spine inbox. Unchanged.
    if [[ "$target" != "foundation" ]]; then
        printf '%s' '🔔 DOORBELL — take a turn now: run `scripts/inbox.sh` as your FIRST action, consume any new inbound, then proceed/report. (This is the bell only; your payload is in your git inbox.)'
        return 0
    fi
    # lane→hub: name MY OWN outbox, because that is where the payload actually is.
    # ⛔ FIELD-SCOPED ON PURPOSE. `resolve-lane.sh:79` emits ONE line of SEVEN
    # fields (`lane=… role=… version=… spine_write=… blob=… currency=… subagent_model=…`). The previous
    # parse was `sed -n 's/^lane=//p'`, which strips only the PREFIX and keeps THE WHOLE REST OF THE LINE —
    # so `caller` became a 170-char string, `lane_branch`/`lane_surface` matched no lane, both returned
    # empty, and the `-n` guard below sent EVERY lane→hub ring down the "could not resolve" fallback.
    # `\([^ ]*\)` stops at the first space = the lane token only. DO NOT re-widen this to `s/^lane=//p`.
    caller="$(scripts/resolve-lane.sh 2>/dev/null | sed -n 's/^lane=\([^ ]*\).*/\1/p' | tr -d "'\"")"
    caller="${caller:-unknown}"
    cbranch="$(lane_branch "$caller" 2>/dev/null || true)"
    csurface="$(lane_surface "$caller" 2>/dev/null || true)"
    if [[ -n "$cbranch" && -n "$csurface" ]]; then
        csha="$(git rev-parse --short "origin/$cbranch" 2>/dev/null || echo HEAD)"
        printf '%s' "🔔 DOORBELL (lane→hub) — take a turn now: run \`scripts/inboxf.sh\` as your FIRST action. ⛔ NOT \`inbox.sh\` — it resolves ONE spine directory and will report \`empty\` while this payload sits unread. PAYLOAD: reap \`origin/$cbranch:$csurface\` @ \`$csha\` (my outbox — integration-EXCLUDED, so it exists ONLY on my branch and no spine-scoped read can see it)."
    else
        printf '%s' "🔔 DOORBELL (lane→hub) — take a turn now: run \`scripts/inboxf.sh\` as your FIRST action (NOT \`inbox.sh\`). ⚠ I could not resolve my own outbox ref to name it — sweep all declared lane surfaces."
    fi
}

match_session() {  # exact (case-insensitive) session-name match -> "session:win.pane|pane_title" lines
    tmux list-panes -a -F '#{session_name}:#{window_index}.#{pane_index}|#{session_name}|#{pane_title}' 2>/dev/null \
        | awk -F'|' -v L="$1" 'tolower($2)==tolower(L){print $1"|"$3}'
}

resolve_target() {  # echoes "session:win.pane|pane_title" for exactly-one session, else nonzero
    # C7(c): the QUALIFIED name <project>-<lane> first (project = this worktree's stamp, one fleet
    # = one project). The bare-lane fallback is a NAMED, TIME-BOXED transition: it warns on every use and is
    # removed in the set that measures zero bare-named seat sessions (probe_seat_restart_poles.sh prints the census).
    local lane="$1" out n proj qual                    # bash-3.2-safe (no mapfile)
    proj="$(bash "$(git rev-parse --show-toplevel 2>/dev/null)/scripts/resolve-project.sh" 2>/dev/null)"
    proj="${proj#project=}"
    out=""
    if [[ -n "$proj" ]]; then
        qual="$proj-$lane"
        out="$(match_session "$qual")"
    fi
    if [[ -z "$out" ]]; then
        out="$(match_session "$lane")"
        [[ -n "$out" ]] && echo "WARN(doorbell): C7 bare-name fallback: rang '$lane' (no '${qual:-<no project stamp>}' session). Time-boxed transition, C7(c)." >&2
    fi
    n="$(printf '%s\n' "$out" | grep -c .)"
    if [[ "$n" -ne 1 ]]; then
        echo "HALT(doorbell): lane='$lane' resolved to $n tmux pane(s) (need exactly 1)." >&2
        [[ "$n" -gt 0 ]] && printf '  candidate: %s\n' "$out" >&2
        echo "  (is the lane relaunched as a named tmux session? \`tmux ls\`)" >&2
        return 2
    fi
    printf '%s' "$out"
}

cmd_ring() {
    local lane="${1:?usage: doorbell.sh ring <lane>}" res target title pre post
    res="$(resolve_target "$lane")" || exit 2          # R3: fail-loud, non-zero, named reason
    target="${res%%|*}"; title="${res#*|}"
    echo "[doorbell] lane=$lane → target=$target (pane_title='$title')"
    local pre_sum post_sum                              # robust: cksum of full pane (any change = submitted)
    pre_sum="$(tmux capture-pane -p -t "$target" 2>/dev/null | cksum)"
    # R2: TWO-PHASE — literal text, THEN Enter as a SEPARATE call (chaining swallows the submit).
    tmux send-keys -t "$target" -l "$(wake_token "$lane")" || { echo "HALT(doorbell): send-keys -l failed ($target)" >&2; exit 2; }
    sleep 0.5
    tmux send-keys -t "$target" Enter            || { echo "HALT(doorbell): send-keys Enter failed ($target)" >&2; exit 2; }
    sleep 1.2
    post="$(tmux capture-pane -p -t "$target" 2>/dev/null | tail -15)"; post_sum="$(tmux capture-pane -p -t "$target" 2>/dev/null | cksum)"
    # submit-verify: Claude busy-indicator OR ANY pane change (cksum) vs pre-send.
    if echo "$post" | grep -qiE 'esc to interrupt|Running|Searching|Thinking|tokens|⏵|✶|✳' || [[ "$pre_sum" != "$post_sum" ]]; then
        echo "[doorbell] rang $lane — submit VERIFIED (pane changed / busy indicator). R4 ack pending: \`doorbell.sh ack $lane <ref>\`."
        return 0
    fi
    # Double-Enter Protocol (text may sit un-submitted): one more Enter, re-check.
    tmux send-keys -t "$target" Enter; sleep 1.2
    post_sum="$(tmux capture-pane -p -t "$target" 2>/dev/null | cksum)"
    if [[ "$pre_sum" != "$post_sum" ]]; then
        echo "[doorbell] rang $lane — submit VERIFIED after Double-Enter. R4 ack pending."
        return 0
    fi
    echo "HALT(doorbell): rang $lane but submit UNCONFIRMED after Double-Enter (pane unchanged) — do NOT assume delivery." >&2
    exit 3
}

cmd_ack() {  # R4: the bell is 'done' only when the lane's outbox shows a NEW surface (consume-ack) since <ref>.
    local lane="${1:?usage: doorbell.sh ack <lane> <ref-sha>}" ref="${2:?need a baseline ref}"
    # window-plan row 8: the branch comes from the ONE indirection point (lane-surface.sh), as the ring does at
    # :46. `module/$lane` is false for architect (branch architect) and the execution lane (branch exec); a name-pattern
    # guess counted 0 and printed a false HALT. No fallback: an undeclared lane or an unreadable ref HALTs
    # under its own name, never as "no consume-ack".
    local branch; branch="$(lane_branch "$lane" 2>/dev/null)" || {
        echo "HALT(doorbell): ack $lane UNRESOLVED — no branch declared for '$lane' in the lane manifest (lane-surface.sh lane_branch)." >&2; exit 3; }
    git fetch -q origin "$branch" 2>/dev/null || true
    git rev-parse -q --verify "origin/$branch^{commit}" >/dev/null 2>&1 && git rev-parse -q --verify "${ref}^{commit}" >/dev/null 2>&1 || {
        echo "HALT(doorbell): ack $lane UNREADABLE — cannot resolve origin/$branch or baseline $ref; motion not measured." >&2; exit 3; }
    local new; new="$(git rev-list --count "${ref}..origin/$branch")" || {
        echo "HALT(doorbell): ack $lane UNREADABLE — git rev-list ${ref}..origin/$branch failed." >&2; exit 3; }
    if [[ "${new:-0}" -gt 0 ]]; then
        echo "[doorbell] ACK: $lane advanced $new commit(s) since $ref → consume-ack landed (bell done)."
        # 0495 R1(e): the consume-ack proper is the lane's ACK.log line, one file in its message surface (lane_surface).
        # The motion count above stays the verdict (W8, inbox-age-filer); this reads the line itself, or says it is absent.
        local surf nl
        if surf="$(lane_surface "$lane" 2>/dev/null)"; then
            nl="$(git log --format= -p "${ref}..origin/$branch" -- "${surf}ACK.log" 2>/dev/null | grep -cE '^\+([^+]|$)')"
            if [[ "${nl:-0}" -gt 0 ]]; then
                echo "[doorbell] ACK-LOG: $lane +$nl line(s) in ${surf}ACK.log since $ref; newest: $(git show "origin/$branch:${surf}ACK.log" 2>/dev/null | tail -1)"
            else
                echo "[doorbell] ACK-LOG: $lane none in ${surf}ACK.log since $ref (motion only; the line is a new outbox file, if any)"
            fi
        else
            echo "[doorbell] ACK-LOG: $lane UNRESOLVED (no message surface for '$lane'; lane-surface.sh lane_surface)"
        fi
        return 0
    fi
    echo "HALT(doorbell): rang $lane, NO consume-ack since $ref (outbox unchanged) — do NOT assume delivery." >&2
    exit 3
}

case "${1:-}" in
    ring) shift; cmd_ring "$@" ;;
    ack)  shift; cmd_ack  "$@" ;;
    *) echo "usage: doorbell.sh {ring <lane> | ack <lane> <ref-sha>}" >&2; exit 1 ;;
esac
