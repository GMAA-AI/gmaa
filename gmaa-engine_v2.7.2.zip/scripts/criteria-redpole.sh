#!/usr/bin/env bash
# criteria-redpole.sh — the MECHANICAL half of the auditor's criteria-adequacy check.
# The judgment half (scope coverage, §3(b)2) is in
# agents/audit-system-prompt.md. DISC-LLM-AT-THE-EDGES: "does any criterion FAIL on the pre-fix bytes" is a
# mechanic, so it is code; the auditor RUNS this and charges its verdict, it does not re-derive it.
#
# usage: criteria-redpole.sh <commit>
#   For every `_ratification/criteria/*.md` the commit ADDS or MODIFIES:
#     applies = the file carries ANY criterion whose governing `#` comment is not sourced `src: _rulings/…`
#               (an architect-authored bar is out of scope for §3(b); a missing src: counts as NOT architect).
#     red pole = evaluate the file's criteria (as of <commit>) against the tree of <commit>^; the bar HAS a red
#               pole iff at least one criterion FAILs there.
#   THE BAR (auditor a4c3c563 F2; c08a86cf F1; 0408df49 F1): the governing ruling judges the set's BAR, i.e. "at least
#   one test that FAILs on the pre-fix bytes". A file's bar = its ordered evaluable criteria + its SUPERSEDED-BY markers
#   parsed as (ruling, carrier, ERE) exactly as scripts/ratify.sh:1053-1056 does. `#` comments, `src:` provenance and the
#   note after a marker's ERE are NOT the bar. Three shapes:
#     criteria changed (added/edited/removed/reordered), or the file is new, or a marker was only removed
#                       -> evaluate the whole file at the parent (the original rule, unchanged).
#     criteria identical, NEW marker(s) -> the replacement pin lives at the marker's CARRIER, so follow it:
#                       carrier `_ratification/criteria/*.md`: its criteria (at <commit>) matching the ERE, run at the parent;
#                       any other carrier: red iff the ERE matches the carrier at <commit> but not at the parent.
#                       OK if the whole-file count OR any followed carrier gives a FAIL at the parent.
#     bar identical    -> N/A (bar unchanged): a comment-only edit adds no test, so there is nothing to red-pole.
#                       Verdict order: a whole-file FAIL at the parent (k > 0) prints OK FIRST, so an unchanged bar that
#                       already had a red pole reads OK, byte-equal to the pre-SET-0135 script; only k = 0 reaches N/A.
#     re-pin: identical markers, at least one new criterion, and every new criterion directly under a
#                       contiguous `#` block carrying `src: foundation preservation|record-integrity`. A re-pin owes the
#                       ORIGIN red pole (R2): with k = 0, both bars are evaluated at origin^, where origin = the oldest commit
#                       that added the path (a rename is no origin): k_new > 0 -> OK (re-pin …) · k_new = 0, k_old > 0 ->
#                       NO-RED-POLE (dropped) · both 0 -> N/A (no red pole at its origin) · no origin -> NO-RED-POLE. These
#                       verdicts sit after `k > 0 -> OK`, so every existing verdict is byte-equal.
#   Output, one line per file:  CRITERIA-REDPOLE: <file> · applies=<yes|no> · fail-at-parent=<k> of <n> · <OK|NO-RED-POLE|N/A>
#   exit 0 = no file lacks a red pole · 1 = at least one NO-RED-POLE (the auditor charges an F) · 3 = unreadable.
# usage: criteria-redpole.sh --eval <root> <criteria-file>
#   Print `PASS|FAIL|JUDGMENT-REQUIRED [type] args` per criterion, evaluated in <root>. This mirrors
#   scripts/ratify.sh conformance-check's evaluator (strip "- " + leading space; exists/absent/grep/test/judgment;
#   a `# SUPERSEDED-BY:` marker is scored by ratify.sh's own marker rule: SUPERSEDED, or a FAIL [superseded-marker]
#   line). Parity with ratify.sh is a probe pole, SUPERSEDED verdicts included.
set -u
die() { echo "CRITERIA-REDPOLE: UNREADABLE — $* (exit 3)" >&2; exit 3; }

eval_file() {  # <root> <criteria-file>
    local root="$1" cf="$2" line type args pat pth skip=0
    [[ -r "$cf" ]] || die "criteria file $cf unreadable"
    while IFS= read -r line || [[ -n "$line" ]]; do
        line="${line#- }"; line="${line#"${line%%[![:space:]]*}"}"
        if [[ "$line" == "# SUPERSEDED-BY:"* ]]; then skip=1; continue; fi
        [[ -z "${line// /}" || "${line:0:1}" == "#" ]] && continue
        type="$(sed -n 's/^\[\([a-z-]*\)\].*/\1/p' <<<"$line")"
        [[ -n "$type" ]] || continue
        args="${line#\[$type\] }"
        if [[ $skip -eq 1 ]]; then skip=0; echo "SUPERSEDED [$type] $args"; continue; fi
        case "$type" in
            exists) if [[ -e "$root/$args" ]]; then echo "PASS [exists] $args"; else echo "FAIL [exists] $args"; fi ;;
            absent) if [[ ! -e "$root/$args" ]]; then echo "PASS [absent] $args"; else echo "FAIL [absent] $args"; fi ;;
            grep)   pat="${args%% :: *}"; pth="${args##* :: }"
                    if grep -qE "$pat" "$root/$pth" 2>/dev/null; then echo "PASS [grep] $pat :: $pth"; else echo "FAIL [grep] $pat :: $pth"; fi ;;
            test)   if ( cd "$root" && eval "$args" ) >/dev/null 2>&1; then echo "PASS [test] $args"; else echo "FAIL [test] $args"; fi ;;
            judgment) echo "JUDGMENT-REQUIRED [judgment] $args" ;;
            *)      echo "FAIL [unknown-criterion-type:$type] $args" ;;
        esac
    done < "$cf"
}

# --eval scores SUPERSEDED-BY markers by the ENFORCER's rule, not by a skip (a skip scored a marker SUPERSEDED that the
#   enforcer scored FAIL, so the two evaluators disagreed on the same bytes): scripts/ratify.sh conformance-check
#   parses (ruling, carrier, ERE) and scores, in this order: carrier outside the repo -> FAIL · carrier is a ruling ->
#   FAIL · ERE literal floor < 12 -> FAIL · ruling does not resolve -> FAIL · `grep -qE` of the ERE over the carrier
#   matches -> SUPERSEDED, else FAIL. A malformed marker, a marker with no criterion after it, and a member whose every
#   criterion is superseded (no PASS, no JUDGMENT) are FAIL there too. The floor program is NOT copied: it is read
#   from the ratify.sh beside this script, so the two evaluators cannot drift apart on it; if it cannot be read, HALT.
load_sup_floor() {
    local r; r="$(dirname "${BASH_SOURCE[0]}")/ratify.sh"
    [[ -r "$r" ]] || die "SUP_FLOOR_AWK source $r unreadable"
    SUP_FLOOR_AWK="$(awk '/^SUP_FLOOR_AWK=\x27$/{on=1; next} on && /^\x27$/{exit} on' "$r")"
    [[ -n "$SUP_FLOOR_AWK" ]] || die "SUP_FLOOR_AWK not found in $r"
}
#   The commit-mode engine below keeps eval_file's skip: there a marker is judged at its CARRIER (carrier_red), and a
#   parent-side FAIL from a carrier that does not exist yet would make every new marker a vacuous red pole.

eval_file_enforcer() {  # <root> <criteria-file> : the --eval scorer (ratify.sh marker rule)
    local root="$1" cf="$2" line type args pat pth sup_ref="" sup_bad="" sup_car="" sup_pat="" sup_lit sup=0 pass=0 judg=0
    [[ -r "$cf" ]] || die "criteria file $cf unreadable"
    [[ -n "${SUP_FLOOR_AWK:-}" ]] || load_sup_floor
    while IFS= read -r line || [[ -n "$line" ]]; do
        line="${line#- }"; line="${line#"${line%%[![:space:]]*}"}"
        if [[ "$line" == "# SUPERSEDED-BY:"* ]]; then
            [[ -n "$sup_ref$sup_bad" ]] && echo "FAIL [superseded-marker] a marker with no criterion after it (${sup_ref:-malformed})"
            sup_bad=""; sup_ref="$(sed -nE 's/^# SUPERSEDED-BY:[[:space:]]*(_rulings\/[0-9]{4}).*/\1/p' <<<"$line")"
            sup_car="$(sed -nE 's/.* · CARRIER:[[:space:]]*([^[:space:]]+)[[:space:]]+::[[:space:]]+.*/\1/p' <<<"$line")"
            sup_pat="$(sed -nE 's/.* · CARRIER:[[:space:]]*[^[:space:]]+[[:space:]]+::[[:space:]]+(.*)$/\1/p' <<<"$line")"; sup_pat="${sup_pat%% · *}"
            [[ -z "$sup_ref" || -z "$sup_car" || -z "$sup_pat" ]] && { sup_bad="malformed: needs _rulings/NNNN · CARRIER: <path> :: <ERE>"; sup_ref=""; }
            continue
        fi
        [[ -z "${line// /}" || "${line:0:1}" == "#" ]] && continue
        type="$(sed -n 's/^\[\([a-z-]*\)\].*/\1/p' <<<"$line")"
        # A pending marker takes the next non-comment line, typed or not (ratify.sh does the same).
        if [[ -z "$type" && -z "$sup_ref$sup_bad" ]]; then continue; fi
        args="$(sed 's/^\[[a-z-]*\][[:space:]]*//' <<<"$line")"
        if [[ -n "$sup_bad" ]]; then echo "FAIL [superseded-marker] $sup_bad — above [$type] $args"; sup_bad=""; continue; fi
        if [[ -n "$sup_ref" ]]; then
            sup_lit="$(printf '%s\n' "$sup_pat" | awk "$SUP_FLOOR_AWK")"
            if [[ "$sup_car" == /* || "$sup_car" == *..* ]]; then echo "FAIL [superseded-marker] carrier $sup_car is outside the repo — above [$type] $args"
            elif [[ "$sup_car" == _rulings/* ]]; then echo "FAIL [superseded-marker] carrier $sup_car is a ruling record — above [$type] $args"
            elif [[ "$sup_lit" -lt 12 ]]; then echo "FAIL [superseded-marker] carrier ERE /$sup_pat/ has no literal run of >= 12 chars (longest $sup_lit) — above [$type] $args"
            elif ! compgen -G "$root/${sup_ref}-*.md" >/dev/null; then echo "FAIL [superseded-marker] ruling $sup_ref does not resolve — above [$type] $args"
            elif grep -qE -- "$sup_pat" "$root/$sup_car" 2>/dev/null; then echo "SUPERSEDED [$type] $args"; sup=$((sup+1))
            else echo "FAIL [superseded-marker] carrier $sup_car does not carry /$sup_pat/ — above [$type] $args"; fi
            sup_ref=""; continue
        fi
        case "$type" in
            exists) if [[ -e "$root/$args" ]]; then echo "PASS [exists] $args"; pass=$((pass+1)); else echo "FAIL [exists] $args"; fi ;;
            absent) if [[ ! -e "$root/$args" ]]; then echo "PASS [absent] $args"; pass=$((pass+1)); else echo "FAIL [absent] $args"; fi ;;
            grep)   pat="${args%% :: *}"; pth="${args##* :: }"
                    if grep -qE "$pat" "$root/$pth" 2>/dev/null; then echo "PASS [grep] $pat :: $pth"; pass=$((pass+1)); else echo "FAIL [grep] $pat :: $pth"; fi ;;
            test)   if ( cd "$root" && eval "$args" ) >/dev/null 2>&1; then echo "PASS [test] $args"; pass=$((pass+1)); else echo "FAIL [test] $args"; fi ;;
            judgment) echo "JUDGMENT-REQUIRED [judgment] $args"; judg=$((judg+1)) ;;
            *)      echo "FAIL [unknown-criterion-type:$type] $args" ;;
        esac
    done < "$cf"
    [[ -n "$sup_ref$sup_bad" ]] && echo "FAIL [superseded-marker] a marker with no criterion after it (${sup_ref:-malformed})"
    [[ $sup -gt 0 && $pass -eq 0 && $judg -eq 0 ]] && echo "FAIL [superseded-marker] every criterion is SUPERSEDED — no live check remains for this member"
    return 0
}
bar_lines() {  # <criteria-file> -> the BAR, one item per line: `M<TAB>ruling<TAB>carrier<TAB>ERE` | `C<TAB>criterion`
    local line ref car pat
    while IFS= read -r line || [[ -n "$line" ]]; do
        line="${line#- }"; line="${line#"${line%%[![:space:]]*}"}"
        if [[ "$line" == "# SUPERSEDED-BY:"* ]]; then
            ref="$(sed -nE 's/^# SUPERSEDED-BY:[[:space:]]*(_rulings\/[0-9]{4}).*/\1/p' <<<"$line")"
            car="$(sed -nE 's/.* · CARRIER:[[:space:]]*([^[:space:]]+)[[:space:]]+::[[:space:]]+.*/\1/p' <<<"$line")"
            pat="$(sed -nE 's/.* · CARRIER:[[:space:]]*[^[:space:]]+[[:space:]]+::[[:space:]]+(.*)$/\1/p' <<<"$line")"; pat="${pat%% · *}"
            printf 'M\t%s\t%s\t%s\n' "$ref" "$car" "$pat"; continue
        fi
        [[ -z "${line// /}" || "${line:0:1}" == "#" ]] && continue
        [[ "$line" =~ ^\[[a-z-]+\] ]] || continue
        printf 'C\t%s\n' "$line"
    done < "$1"
}

carrier_red() {  # <car> <ERE> -> exit 0 iff the carried pin FAILs at the parent; prints a short reason
    local car="$1" pat="$2"
    [[ -n "$car" && -n "$pat" && "$car" != /* && "$car" != *..* ]] || { echo "malformed carrier"; return 1; }
    if [[ "$car" == _ratification/criteria/*.md ]]; then
        git show "${SHA}:$car" > "$T/car.md" 2>/dev/null || { echo "carrier $car absent at ${SHA:0:8}"; return 1; }
        # Evaluate the WHOLE carrier in order (its generator lines must run before a pin that reads their output), then
        # count FAILs among the criteria matching the ERE. eval_file emits exactly one line per criterion, in order.
        bar_lines "$T/car.md" | awk '/^C\t/{ sub(/^C\t/,""); print }' > "$T/car.crit"
        eval_file "$T/p" "$T/car.md" > "$T/car.res"
        local kc=0 nc=0 cl rl
        while IFS= read -r cl <&3 && IFS= read -r rl <&4; do
            grep -qE -- "$pat" <<<"$cl" 2>/dev/null || continue
            nc=$((nc+1)); [[ "$rl" == FAIL\ * ]] && kc=$((kc+1))
        done 3< "$T/car.crit" 4< "$T/car.res"
        [[ "$nc" -gt 0 ]] || { echo "carrier $car has no criterion matching the ERE"; return 1; }
        echo "$car: $kc of $nc carried criteria FAIL at parent"; [[ "$kc" -gt 0 ]]; return
    fi
    git show "${SHA}:$car" 2>/dev/null | grep -qE -- "$pat" || { echo "carrier $car does not carry the ERE at ${SHA:0:8}"; return 1; }
    if git show "${PAR}:$car" 2>/dev/null | grep -qE -- "$pat"; then echo "$car already carried the ERE at parent"; return 1; fi
    echo "$car: the carried substance is absent at parent"; return 0
}

if [[ "${1:-}" == "--eval" ]]; then
    [[ -n "${2:-}" && -n "${3:-}" ]] || die "--eval needs <root> <criteria-file>"
    eval_file_enforcer "$2" "$3"; exit 0
fi

C="${1:-}"; [[ -n "$C" ]] || die "usage: criteria-redpole.sh <commit> | --eval <root> <criteria-file>"
REPO="$(git rev-parse --show-toplevel 2>/dev/null)" || die "not in a git worktree"
cd "$REPO" || die "cannot cd to $REPO"
SHA="$(git rev-parse --verify -q "${C}^{commit}")" || die "commit '$C' does not resolve"
PAR="$(git rev-parse --verify -q "${SHA}^")" || die "commit ${SHA:0:8} has no parent (a red pole needs pre-fix bytes)"
FILES="$(git diff-tree --no-commit-id --name-only -r --diff-filter=AM "$SHA" -- '_ratification/criteria' | grep -E '\.md$' || true)"
if [[ -z "$FILES" ]]; then echo "CRITERIA-REDPOLE: ${SHA:0:8} adds or modifies no criteria file — nothing to judge"; exit 0; fi

T="$(mktemp -d -t criteriaredpole)" || die "mktemp failed"
trap 'rm -rf "$T"' EXIT
git clone -q --shared "$REPO" "$T/p" 2>/dev/null || die "shared clone failed"
git -C "$T/p" checkout -q --detach "$PAR" 2>/dev/null || die "checkout of parent ${PAR:0:8} failed"
mkdir -p "$T/p/.tmp"

bad=0
for f in $FILES; do
    git show "${SHA}:$f" > "$T/crit.md" 2>/dev/null || die "${SHA:0:8}:$f unreadable"
    # applies? any criterion whose governing comment is not `src: _rulings/…`
    applies="$(awk '{ l=$0; sub(/^- /,"",l); sub(/^[[:space:]]+/,"",l) }
                    l ~ /^#/ { g=l; next }
                    l ~ /^\[(test|grep|exists|judgment|absent)\]/ { if (g !~ /src: _rulings\/[0-9][0-9][0-9][0-9] /) { print "yes"; exit } }' "$T/crit.md")"
    applies="${applies:-no}"
    res="$(eval_file "$T/p" "$T/crit.md")"
    n="$(printf '%s\n' "$res" | grep -cE '^(PASS|FAIL) ')"
    k="$(printf '%s\n' "$res" | grep -c '^FAIL ')"
    # the bar's shape (see header): unchanged / new markers only / anything else
    shape="changed"
    bar_lines "$T/crit.md" > "$T/new.bar"
    if git show "${PAR}:$f" > "$T/old.md" 2>/dev/null; then
        bar_lines "$T/old.md" > "$T/old.bar"
        if cmp -s "$T/old.bar" "$T/new.bar"; then shape="unchanged"
        elif cmp -s <(grep '^C' "$T/old.bar") <(grep '^C' "$T/new.bar"); then
            grep '^M' "$T/old.bar" > "$T/old.m"; grep '^M' "$T/new.bar" | grep -vxF -f "$T/old.m" > "$T/new.m"
            [[ -s "$T/new.m" ]] && shape="markers"
        fi
        # re-pin shape: identical markers, at least one NEW criterion line, and EVERY new criterion
        # line sits directly under a contiguous `#` block (no criterion or blank line between) that carries
        # `src: foundation preservation` or `src: foundation record-integrity`. A label further up governs nothing here.
        if [[ "$shape" == "changed" ]] && cmp -s <(grep '^M' "$T/old.bar") <(grep '^M' "$T/new.bar"); then
            grep '^C' "$T/old.bar" > "$T/old.c" || true
            grep '^C' "$T/new.bar" | grep -vxF -f "$T/old.c" | cut -f2- > "$T/new.c" || true
            if [[ -s "$T/new.c" ]]; then
                awk '{ l=$0; sub(/^- /,"",l); sub(/^[[:space:]]+/,"",l) }
                     l ~ /^#/ { b = b "\n" l; next }
                     l ~ /^\[[a-z-]+\]/ { print ((b ~ /src: foundation (preservation|record-integrity)/) ? "L" : "U") "\t" l; b=""; next }
                     { b="" }' "$T/crit.md" > "$T/adj"
                awk 'NR==FNR { want[$0]=1; next } { s=substr($0,1,1); l=substr($0,3) } (l in want) && s != "L" { u=1 }
                     END { exit u }' "$T/new.c" "$T/adj" && shape="repin"
            fi
        fi
    fi
    # the origin pole, evaluated only when no criterion fails at the parent: origin = the oldest
    # commit that ADDED the path. A git mv destination is listed as A under a path filter, so a candidate that is a rename
    # in the whole-tree diff is no origin. Both bars (old = <commit>^, new = <commit>) are evaluated at origin^.
    rv=""
    if [[ "$shape" == "repin" && "$applies" == "yes" && "$k" -eq 0 ]]; then
        ORG="$(git log --diff-filter=A --format=%H "$SHA" -- "$f" 2>/dev/null | tail -1)"
        if [[ -n "$ORG" ]] && git diff-tree -r -M --no-commit-id --name-status --diff-filter=R "$ORG" 2>/dev/null \
                | awk -F'\t' -v p="$f" '$3==p { r=1 } END { exit !r }'; then ORG=""; fi
        OPAR=""; [[ -n "$ORG" ]] && OPAR="$(git rev-parse --verify -q "${ORG}^")"
        if [[ -z "$OPAR" ]]; then rv="NO-RED-POLE (re-pin origin not found)"
        else
            git -C "$T/p" checkout -q -f --detach "$OPAR" 2>/dev/null || die "checkout of origin parent ${OPAR:0:8} failed"
            mkdir -p "$T/p/.tmp"
            ro="$(eval_file "$T/p" "$T/old.md")"; rn="$(eval_file "$T/p" "$T/crit.md")"
            git -C "$T/p" checkout -q -f --detach "$PAR" 2>/dev/null || die "checkout of parent ${PAR:0:8} failed"
            k_old="$(printf '%s\n' "$ro" | grep -c '^FAIL ')"; k_new="$(printf '%s\n' "$rn" | grep -c '^FAIL ')"
            n_new="$(printf '%s\n' "$rn" | grep -cE '^(PASS|FAIL) ')"
            if [[ "$k_new" -gt 0 ]]; then rv="OK (re-pin: fails at origin ${ORG:0:8}^, $k_new of $n_new)"
            elif [[ "$k_old" -gt 0 ]]; then rv="NO-RED-POLE (re-pin dropped the origin red pole at ${ORG:0:8}^)"
            else rv="N/A (re-pin of a bar with no red pole at its origin ${ORG:0:8}^; not this commit's)"; fi
        fi
    fi
    cr=0; cm=0; cwhy=""
    if [[ "$shape" == "markers" ]]; then
        while IFS=$'\t' read -r _m _ref car pat; do
            cm=$((cm+1)); why="$(carrier_red "$car" "$pat")" && cr=$((cr+1)); cwhy="${cwhy:+$cwhy; }$why"
        done < "$T/new.m"
    fi
    if [[ "$applies" == "no" ]]; then v="N/A (every criterion is sourced to an architect ruling)"
    elif [[ "$k" -gt 0 ]]; then v="OK"
    elif [[ -n "$rv" ]]; then v="$rv"; [[ "$rv" == NO-RED-POLE* ]] && bad=1
    elif [[ "$shape" == "unchanged" ]]; then v="N/A (bar unchanged: comment/src:/marker-note edit only)"
    elif [[ "$cr" -gt 0 ]]; then v="OK (via CARRIER: $cr of $cm new marker(s) — $cwhy)"
    elif [[ "$shape" == "markers" ]]; then v="NO-RED-POLE (0 of $cm new marker(s) carry a red pole — $cwhy)"; bad=1
    elif [[ "$n" -eq 0 ]]; then v="NO-RED-POLE (no mechanically evaluable criterion)"; bad=1
    else v="NO-RED-POLE"; bad=1; fi
    echo "CRITERIA-REDPOLE: $f · applies=$applies · fail-at-parent=$k of $n (parent ${PAR:0:8}) · $v"
done
exit $bad
