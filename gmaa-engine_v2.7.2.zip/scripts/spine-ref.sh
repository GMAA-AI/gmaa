#!/usr/bin/env bash
# scripts/spine-ref.sh — the ONE spine-ref resolver (the one spine-ref resolver).
# Prints exactly one line, `origin/<trunk>`, and exits 0. Every shipped reader of the spine ref calls this script
# (0505 R2); none carries a trunk literal or a `main` fallback of its own.
#
# The trunk name is a project fact (canon §7.2): it lives at ONE anchor here, the SPINE_TRUNK assignment below,
# which is the SECOND row of the existing TRUNK_BRANCH slot in _index/adopter-slots.tsv (the first is
# scripts/resolve-lane.sh's comparison; one slot, two anchors, one fill). The origin's ship-tree generator ships this
# line with the slot token in place of the value, under the same exactly-one-anchor guard as resolve-lane.sh.
#
# Security property (0424 s2.2): local bytes only. This script reads no ref, no manifest, no other file and no
# environment variable, so a lane cannot point itself at another trunk by anything but editing its own copy, which
# the surface-conformance probe (canon s4) flags as DRIFT. The remote name `origin` is convention (canon s9), not a
# slot.
#
# An unfilled slot (the token left in place, or an empty value) is a HALT by name, SLOT-UNFILLED TRUNK_BRANCH, rc 3
# (inv #5). The check accepts git's branch-name characters only, so the shipped token cannot pass it.
set -u
SPINE_TRUNK={{TRUNK_BRANCH}}
case "$SPINE_TRUNK" in
  ''|*[!A-Za-z0-9._/-]*)
    echo "HALT(spine-ref): SLOT-UNFILLED TRUNK_BRANCH -- scripts/spine-ref.sh carries no filled trunk name; the adopter fills the TRUNK_BRANCH slot at onboarding (_index/adopter-slots.tsv; the one spine-ref resolver; inv #5)" >&2
    exit 3 ;;
esac
printf 'origin/%s\n' "$SPINE_TRUNK"
