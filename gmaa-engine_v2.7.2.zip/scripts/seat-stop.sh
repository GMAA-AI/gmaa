#!/bin/bash
# scripts/seat-stop.sh <lane> [timeout_s] — THE OPERATOR'S TOOL: shut a seat down and do NOT restart it
# (PROPOSAL §2.7; operator: "How would I stop the lane if I wanted to shutdown and not
# have it restart"). No seat runs this against another seat: stopping a seat is outside hub-and-spoke routing
# authority, so it REFUSES inside any Claude Code subprocess (CLAUDE_CODE_CHILD_SESSION=1; docs: env-vars, "only
# set by Claude Code itself", unlike CLAUDECODE which IDE terminals also set).
# Steps: find the lane's worktree (its _boot/BOOTSTRAP.md lane:) -> session <project>-<lane> from that stamp ->
# write `shutdown` into its .claude/seat-intent -> send /exit -> wait up to timeout_s (default 60) -> kill-session
# if still alive. The intent on disk makes the loop stop even if the kill lands. Exact-name targets only (`=`).
# TMUX_CMD (test seam only): the probe sets a recorder; unset = tmux.
set -u
TM="${TMUX_CMD:-tmux}"
if [ "${CLAUDE_CODE_CHILD_SESSION:-}" = "1" ]; then
  echo "HALT(seat-stop): refused inside a Claude Code session. seat-stop.sh is the operator's tool; a seat ends only itself (scripts/seat-exit.sh)." >&2
  exit 2
fi
LANE="${1:?usage: scripts/seat-stop.sh <lane> [timeout_s]}"
TIMEOUT="${2:-60}"
HERE="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "HALT(seat-stop): run inside any fleet worktree" >&2; exit 2; }
WT=""
while IFS= read -r line; do
  case "$line" in worktree\ *) p="${line#worktree }"
    l="$(sed -nE 's/^lane:[[:space:]]*([A-Za-z0-9_-]+).*/\1/p' "$p/_boot/BOOTSTRAP.md" 2>/dev/null | head -1)"
    [ "$l" = "$LANE" ] && { WT="$p"; break; } ;;
  esac
done < <(git -C "$HERE" worktree list --porcelain)
[ -n "$WT" ] || { echo "HALT(seat-stop): no worktree stamped lane: $LANE" >&2; exit 2; }
PROJ="$(bash "$HERE/scripts/resolve-project.sh" "$WT")" || exit 2
SESSION="${PROJ#project=}-$LANE"
if ! $TM has-session -t "=$SESSION" 2>/dev/null; then
  echo "HALT(seat-stop): no tmux session '$SESSION' (exact). Bare-named sessions predate C7; stop those by hand: tmux kill-session -t =$LANE" >&2
  exit 2
fi
mkdir -p "$WT/.claude"
printf 'shutdown - operator %s %s\n' "$(date +%s)" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$WT/.claude/seat-intent"
$TM send-keys -t "=$SESSION:" -l "/exit"; sleep 1; $TM send-keys -t "=$SESSION:" Enter
i=0
while [ "$i" -lt "$TIMEOUT" ] && $TM has-session -t "=$SESSION" 2>/dev/null; do sleep 1; i=$((i + 1)); done
if $TM has-session -t "=$SESSION" 2>/dev/null; then
  $TM kill-session -t "=$SESSION"
  echo "SEAT-STOP: $SESSION did not exit within ${TIMEOUT}s -> kill-session. intent=shutdown left on disk ($WT/.claude/seat-intent)."
else
  echo "SEAT-STOP: $SESSION exited after ${i}s. intent=shutdown consumed by the loop."
fi
exit 0
