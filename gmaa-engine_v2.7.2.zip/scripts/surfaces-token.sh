#!/usr/bin/env bash
# scripts/surfaces-token.sh — THE single `surfaces:` authorization-input predicate.
#
# WHY THIS FILE EXISTS (DISC-AUTHZ-INPUT-VALIDATED-AT-EARLIEST-WRITE):
#   A `surfaces:` token is an AUTHORIZATION INPUT — the set-coverage gate turns it into the list of
#   paths a ratified set authorizes. The gate (agents/pre-commit-hook.sh) is FAIL-CLOSED on a token
#   carrying whitespace or brackets, which is correct: an unparseable authorization input must never
#   silently widen or narrow coverage. But the gate was the FIRST detector, and it only runs on a
#   RATIFIED + LIVE packet — so a malformed token authored at `pending-set.sh member` stayed INVISIBLE
#   until the operator's pen fell, and then REJECTED every commit staging a non-exempt spine path,
#   starting with the very commit landing the set's own artifact (SET-0011).
#
#   The cure is not a looser gate. It is validating the input at the EARLIEST WRITE, where the seat
#   that can fix it is still in the loop — and doing it with ONE function so the early check and the
#   gate check CANNOT DRIFT. Two copies of an authorization rule drift; that is a recurring register
#   lesson, and it is why this is a shared library rather than a second copy of the predicate.
#
# CONTRACT: a surfaces token list = BARE PATHS, comma-separated, plus OPTIONAL `[...]` bracket
#   annotations (which are STRIPPED before parsing). Descriptive prose belongs in the member's own
#   parenthetical, NEVER inside the surfaces token.
#
# CALLERS (three, all sourcing this one function):
#   1. scripts/pending-set.sh   `member`  — author-time  (earliest write)
#   2. scripts/pending-set.sh   `reap`    — ledger-write time
#   3. agents/pre-commit-hook.sh          — the coverage gate (BACKSTOP, no longer first detector)

# surfaces_token_parse <raw-surfaces-string>
#   stdout : one normalized path token per line (annotations stripped, trimmed, empties dropped)
#   stderr : each MALFORMED token, one per line, prefixed "MALFORMED-SURFACES-TOKEN: "
#   return : 0 = all tokens well-formed · 1 = at least one malformed (FAIL-CLOSED for the caller)
surfaces_token_parse() {
    local raw="${1-}" stripped tok bad=0
    # Strip bracketed annotations FIRST, then split on comma — never split a path on a comma that
    # lives INSIDE a [...] annotation (preserved verbatim from the gate's own parser).
    stripped="$(printf '%s' "$raw" | sed 's/\[[^]]*\]//g')"
    local oldifs="$IFS"; IFS=','
    # shellcheck disable=SC2206
    local parts=($stripped)
    IFS="$oldifs"
    for tok in "${parts[@]}"; do
        tok="$(printf '%s' "$tok" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
        [ -z "$tok" ] && continue
        case "$tok" in
            *" "*|*"	"*|*"["*|*"]"*)
                printf 'MALFORMED-SURFACES-TOKEN: %s\n' "$tok" >&2; bad=1 ;;
            *)
                printf '%s\n' "$tok" ;;
        esac
    done
    return "$bad"
}

# surfaces_token_assert <raw> <context-label>
#   Fail-closed assertion for the WRITE-side callers. Emits the same message CLASS the gate emits
#   (so an author sees at authoring time exactly what the gate would have said at the pen), then
#   returns non-zero. Callers decide how to die (die/exit) so each keeps its own exit semantics.
surfaces_token_assert() {
    local raw="${1-}" ctx="${2-surfaces}" bad
    bad="$(surfaces_token_parse "$raw" 2>&1 >/dev/null)"
    [ -z "$bad" ] && return 0
    {
        printf '%s REFUSED: malformed `surfaces:` token(s) — a coverage path may not contain whitespace or brackets.\n' "$ctx"
        printf '%s\n' "$bad" | sed 's/^MALFORMED-SURFACES-TOKEN: /  - /'
        printf 'A surfaces token list = BARE PATHS (comma-separated) + optional [...] annotations ONLY.\n'
        printf 'Put descriptive prose in the member parenthetical, not in the surfaces token.\n'
        printf 'Validated HERE (earliest write) rather than at the coverage gate, where it would not\n'
        printf 'surface until the ratify pen and would then reject every gated commit.\n'
    } >&2
    return 1
}
