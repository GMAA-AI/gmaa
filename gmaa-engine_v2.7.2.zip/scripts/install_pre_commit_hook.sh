#!/usr/bin/env bash
# scripts/install_pre_commit_hook.sh
#
# One-time install of the Slice-1 D3 spine_write HARD gate.
# Git hooks aren't versioned; this script installs agents/pre-commit-hook.sh
# into .git/hooks/pre-commit and chmods it executable.
#
# Per COORDINATION.md §13(1) single-writer + chat-Architect Slice-1 relay 2026-06-24.
# Precedent: scripts/install_post_commit_hook.sh.
#
# NOTE on worktrees: by default `.git/hooks/` is SHARED across a repo's worktrees
# (they resolve hooks via the common git-dir), so installing once covers main +
# all module worktrees. The hook resolves the COMMITTING worktree's lane at
# runtime, so one installed hook correctly gates every lane. If `core.hooksPath`
# is ever set per-worktree this must be re-run per worktree — verify with
# `git rev-parse --git-path hooks` in each worktree.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$REPO_ROOT/agents/pre-commit-hook.sh"
DST="$REPO_ROOT/.git/hooks/pre-commit"

if [[ ! -f "$SRC" ]]; then
    echo "ERROR: hook source missing at $SRC" >&2
    exit 1
fi

if [[ ! -x "$REPO_ROOT/scripts/resolve-lane.sh" ]]; then
    echo "ERROR: prerequisite scripts/resolve-lane.sh missing/not-executable; D3 cannot resolve lane." >&2
    exit 1
fi

if [[ ! -d "$REPO_ROOT/.git/hooks" ]]; then
    echo "ERROR: $REPO_ROOT/.git/hooks not a directory; is this a git repo?" >&2
    exit 1
fi

# --- K4 arms LAST (the seat-key contract's install order: the installer refuses while any writing lane is unconfirmed) ---
# There is no --force: this script takes no arguments.
if [[ $# -gt 0 ]]; then
    echo "ERROR: install_pre_commit_hook.sh takes no arguments; there is no --force (K4 install order)." >&2
    exit 1
fi
# Already armed at the canonical blob (every hook this script installs, byte-equal to its source AND executable): a
# no-op, never a refusal. Nothing is copied and no backup is written. A byte-equal hook without its exec bit is dead
# (git skips a non-executable hook), so it is NOT canonical: it is re-armed below, under the same K4 order.
_hook_canon() {  # <source> <installed> : 0 when there is no source, or the installed hook is byte-equal and executable
    [[ ! -f "$1" ]] || { cmp -s "$1" "$2" && [[ -x "$2" ]]; }
}
ALL_CANON=1
for _h in pre-commit-hook.sh:pre-commit pre-merge-commit-hook.sh:pre-merge-commit commit-msg-hook.sh:commit-msg pre-push-hook.sh:pre-push; do
    _s="$REPO_ROOT/agents/${_h%%:*}"; _d="$REPO_ROOT/.git/hooks/${_h##*:}"
    if ! _hook_canon "$_s" "$_d"; then
        ALL_CANON=0
        if [[ -f "$_d" && ! -x "$_d" ]] && cmp -s "$_s" "$_d"; then echo "NOT-EXEC: .git/hooks/${_h##*:} is byte-canonical but not executable (a dead hook); re-arming it."; fi
    fi
done
# the one spine-ref resolver rides beside the hooks (0507 R2/R16: an installed hook reads the resolver beside it, never the
# work tree's), so it is part of the canonical set: absent or drifted = not canonical.
RSRC="$(cd "$(dirname "$0")" && pwd)/spine-ref.sh"; RDST="$REPO_ROOT/.git/hooks/spine-ref.sh"
[[ -f "$RSRC" ]] || { echo "ERROR: the resolver source is missing at $RSRC; an installed hook would HALT SPINE-REF-ABSENT (0507 R2)." >&2; exit 1; }
if ! _hook_canon "$RSRC" "$RDST"; then ALL_CANON=0; echo "RESOLVER: .git/hooks/spine-ref.sh is absent or not canonical; installing it beside the hooks."; fi
if [[ "$ALL_CANON" == 1 ]]; then
    echo "NO-OP: every hook is already installed at its canonical blob (agents/*-hook.sh); nothing to arm."
    exit 0
fi
# Arming or re-arming the K4 hooks (pre-commit's seat-keys line, pre-push) needs every writing lane confirmed: a
# registry row at HEAD plus a setup-signing readback in its worktree. When both K4 hooks are already canonical, this
# install arms nothing new, so a drift cure on the other hooks proceeds.
K4_CANON=1
for _h in pre-commit-hook.sh:pre-commit pre-push-hook.sh:pre-push; do
    _s="$REPO_ROOT/agents/${_h%%:*}"; _d="$REPO_ROOT/.git/hooks/${_h##*:}"
    if ! _hook_canon "$_s" "$_d"; then K4_CANON=0; fi
done
if [[ "$K4_CANON" == 0 ]]; then
    if [[ ! -f "$REPO_ROOT/scripts/seat-keys.sh" ]]; then
        echo "REFUSED: scripts/seat-keys.sh missing; the lane confirmation cannot be read, so K4 is not armed (fail-closed)." >&2
        exit 1
    fi
    if ! ( cd "$REPO_ROOT" && bash scripts/seat-keys.sh confirm-lanes --ref HEAD ); then
        echo "REFUSED: K4 arms last (K4 install order). Every writing lane named UNCONFIRMED above needs keygen + its registry row, then setup-signing in its worktree, before this install. No hook was changed." >&2
        exit 1
    fi
fi

# The resolver lands FIRST, beside the hooks: a hook installed before it would HALT SPINE-REF-ABSENT (0507 R2).
if ! _hook_canon "$RSRC" "$RDST"; then
    cp "$RSRC" "$RDST" && chmod +x "$RDST"
    _hook_canon "$RSRC" "$RDST" && echo "OK: the spine-ref resolver installed at $RDST" \
        || { echo "ERROR: resolver install failed at $RDST; no hook was changed." >&2; exit 1; }
fi

# Back up existing hook if any (operator review)
if [[ -e "$DST" ]]; then
    BACKUP="${DST}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
    cp "$DST" "$BACKUP"
    echo "Backed up existing hook to: $BACKUP"
fi

cp "$SRC" "$DST"
chmod +x "$DST"

# --- Forced merge-path (SET-AUTH-IMPL-01 item 3, C-SET-AUTHORIZATION §2) ---
# The pre-merge-commit hook STRUCTURALLY PREVENTS a raw `git merge` into the trunk (bypassing the
# M6(ii) no-cherry-pick set gate). Installed alongside pre-commit so both spine gates arm together;
# currency-verified at boot by scripts/boot-check.sh. Source-guarded (harmless no-op if absent).
MSRC="$REPO_ROOT/agents/pre-merge-commit-hook.sh"
MDST="$REPO_ROOT/.git/hooks/pre-merge-commit"
if [[ -f "$MSRC" ]]; then
    if [[ -e "$MDST" ]]; then
        MBACKUP="${MDST}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
        cp "$MDST" "$MBACKUP"
        echo "Backed up existing pre-merge-commit hook to: $MBACKUP"
    fi
    cp "$MSRC" "$MDST"
    chmod +x "$MDST"
    [[ -x "$MDST" ]] && echo "OK: pre-merge-commit hook installed at $MDST" \
        || { echo "ERROR: pre-merge-commit install failed; $MDST not executable" >&2; exit 1; }
else
    echo "WARN: pre-merge-commit hook source missing at $MSRC — forced merge-path NOT installed (§2)." >&2
fi

# the commit-time gate (GOVERNANCE-CHECK · PREMISE-CHECK · trigger->cite) on the
# OUTGOING commit. Same shared hooks dir => one install gates every lane. Absent source = loud WARN, never silent.
CSRC="$REPO_ROOT/agents/commit-msg-hook.sh"
CDST="$REPO_ROOT/.git/hooks/commit-msg"
if [[ -f "$CSRC" ]]; then
    if [[ -e "$CDST" ]]; then
        CBACKUP="${CDST}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
        cp "$CDST" "$CBACKUP"
        echo "Backed up existing commit-msg hook to: $CBACKUP"
    fi
    cp "$CSRC" "$CDST"
    chmod +x "$CDST"
    [[ -x "$CDST" ]] && echo "OK: commit-msg hook installed at $CDST" \
        || { echo "ERROR: commit-msg install failed; $CDST not executable" >&2; exit 1; }
else
    echo "WARN: commit-msg hook source missing at $CSRC — the commit-time gate is NOT installed." >&2
fi

# pre-push: K4 at the push boundary (commit signatures verified against the lane registry). Same shared hooks dir.
PSRC="$REPO_ROOT/agents/pre-push-hook.sh"
PDST="$REPO_ROOT/.git/hooks/pre-push"
if [[ -f "$PSRC" ]]; then
    if [[ -e "$PDST" ]]; then
        PBACKUP="${PDST}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
        cp "$PDST" "$PBACKUP"
        echo "Backed up existing pre-push hook to: $PBACKUP"
    fi
    cp "$PSRC" "$PDST"
    chmod +x "$PDST"
    [[ -x "$PDST" ]] && echo "OK: pre-push hook installed at $PDST" \
        || { echo "ERROR: pre-push install failed; $PDST not executable" >&2; exit 1; }
else
    echo "WARN: pre-push hook source missing at $PSRC -- commit signatures are NOT checked at push." >&2
fi

if [[ -x "$DST" ]]; then
    echo "OK: pre-commit hook installed at $DST"
    echo ""
    echo "Verify:"
    echo "  1. ls -la $DST            (hook present + executable)"
    echo "  2. diff $DST $SRC         (no drift between installed + canonical)"
    echo "  3. (main)   touch a spine file, stage, commit  -> ALLOWED  (foundation = sole writer)"
    echo "  4. (module) touch a spine file, stage, commit  -> REJECTED (spine_write: DENY)"
    echo "  5. (module) touch a non-spine file, stage, commit -> ALLOWED"
    echo "  6. (no _boot / mismatch) -> REJECTED fail-closed (never defaults foundation)"
else
    echo "ERROR: install failed; $DST not executable after chmod" >&2
    exit 1
fi
