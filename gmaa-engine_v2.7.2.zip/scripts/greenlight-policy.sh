#!/usr/bin/env bash
# scripts/greenlight-policy.sh — PreToolUse policy hook (SEAT-EXECUTION GREENLIGHT L3).
# Auto-APPROVES a Bash call IFF every segment is provably in-policy; otherwise SILENT (exit 0, no JSON)
# -> the call falls through to the normal allow/ask/deny + defaultMode flow (= the human prompt).
# ~~NEVER emits "deny"/"ask" (the static deny-list + defaultMode own those).~~ AMENDED (rows G1 + G13,
# 2026-09-23): this hook now ALSO emits "deny" for exactly one narrow class
# -- the hook-bypass token class (git commit --no-verify / -n incl. combined short-flag clusters, git -c
# core.hooksPath, git config core.hooksPath, git push/merge --no-verify) -- and, AMENDED (window-plan row 9),
# emits an explicit "deny" for a scripts/run_sql.sh invocation missing --emit-receipt.
# (Was: no decision, so the static settings.json allow of scripts/run_sql.sh let the receipt-less call run.)
# Every OTHER deny/ask case is still owned entirely by the static deny-list + defaultMode, unchanged.
# The 3 completeness deny classes (DDL / external-API / spend) are deliberately NOT added here --
# ruled; the origin project's own class rows are held to a later release.
# The engine for them is the ADOPTER-DECLARED class table (_index/greenlight-deny-classes.tsv, ships EMPTY); see the CLASS-TABLE block below.
# FAIL-CLOSED: any parse ambiguity, unrecognized shape, compound command, or deny-class token -> no
# allow -> prompt. A false-prompt is safe (annoying); a false-allow is the failure this hook must never
# produce. The new deny path is the one deliberate exception to "never denies": for the hook-bypass
# class specifically, row G1 rules that deny IS the safe direction (refuted@`.claude/settings.json`
# row for scripts/**, P1-ALLOW not P4 -- see the G1 block below).
# Contract (code.claude.com/docs/en/hooks + update-config, concur 2026-08-13):
#   stdin  = {"tool_name":"Bash","tool_input":{"command":"..."}}
#   stdout (allow) = {"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow",
#                     "permissionDecisionReason":"..."}}
#   stdout (deny, G1 hook-bypass class ONLY) = same shape with "permissionDecision":"deny"
#   stdout (deny, run_sql.sh without --emit-receipt; window-plan row 9) = the same deny shape
#   ; silent exit 0 = fall through (every other case).
set -u

payload="$(cat)"

deny() {
  printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"%s"}}\n' "$1"
  exit 0
}

extract_command() {   # jq preferred; python3 fallback; neither -> empty (fail-closed prompt)
  if command -v jq >/dev/null 2>&1; then
    printf '%s' "$payload" | jq -r '.tool_input.command // empty' 2>/dev/null
  elif command -v python3 >/dev/null 2>&1; then
    printf '%s' "$payload" | python3 -c 'import sys,json;\
d=json.load(sys.stdin);print(d.get("tool_input",{}).get("command",""))' 2>/dev/null
  fi
}
cmd="$(extract_command)"

# === G1 DENY: hook-bypass token class ========================================================================
# MUST run before every other early exit in this script -- including the canonical self-check right below
# it -- because a stale or unreadable copy of THIS hook must still refuse a bypass attempt rather than
# silently falling through: deny is the safe direction (row G1).
#
# QUOTING RULE (conservative, stated explicitly): a token is examined for a bypass flag ONLY if it sits
# OUTSIDE single- or double-quoted text in the raw command string. Every quoted span (the quote chars AND
# everything between them) is blanked to whitespace before tokenizing, so flag-shaped text that is actually
# part of a quoted argument (e.g. a commit message that happens to read "-n") is invisible to this scan and
# can never be mistaken for a real flag. This is a linter over a token view, not a shell parser: where quote
# boundaries are themselves ambiguous (unbalanced quotes, unusual escaping) it degrades toward MISSING an
# intentionally-obfuscated bypass, never toward denying something safe.
#
# Detected forms (identified positionally against the resolved git subcommand, not by bare substring match,
# so "git log -n 5" / "git show -n" / "grep -n x f" / "head -n" are never touched -- the -n check fires ONLY
# when the git subcommand actually resolves to "commit"):
#   git commit ... --no-verify
#   git commit ... -n                        (standalone short flag)
#   git commit ... -<cluster containing n>   (combined short-flag cluster, e.g. -an, -nm)
#   git -c core.hooksPath=...  ...           (global config override BEFORE the subcommand)
#   git config ... core.hooksPath ...
#   git push ... --no-verify
#   git merge ... --no-verify
# A double-dash long flag (e.g. --dry-run, which contains the letter n) is matched whole against "--*"
# BEFORE the single-dash short-cluster test runs, so it can never false-positive into the -n class.
#
# NOT built here (explicitly out of scope for this change): the 3 completeness deny classes (DDL / external-API / spend);
# ruled; the origin project's own class rows are held to a later release.
_gl_lc() { printf '%s' "$1" | tr '[:upper:]' '[:lower:]'; }

_gl_strip_quoted() {   # blank every quoted span (chars+quotes) to spaces; bash 3.2-safe, no regex engine
  local s="$1" out="" i=0 len c q
  len=${#s}; q=""
  while (( i < len )); do
    c="${s:i:1}"
    if [[ -z "$q" ]]; then
      if [[ "$c" == "'" || "$c" == '"' ]]; then q="$c"; out+=" "; i=$((i+1)); continue; fi
      if [[ "$c" == "\\" && $((i+1)) -lt $len ]]; then out+="  "; i=$((i+2)); continue; fi
      out+="$c"; i=$((i+1)); continue
    fi
    if [[ "$q" == '"' && "$c" == "\\" && $((i+1)) -lt $len ]]; then out+="  "; i=$((i+2)); continue; fi
    if [[ "$c" == "$q" ]]; then q=""; out+=" "; i=$((i+1)); continue; fi
    out+=" "; i=$((i+1))
  done
  printf '%s' "$out"
}

_gl_bypass_reason() {   # prints a reason + returns 0 on a hit; returns 1 on no hit
  local raw="$1" stripped
  stripped="$(_gl_strip_quoted "$raw")"
  local -a tok
  IFS=' ' read -r -a tok <<< "$stripped"   # read -a never globs (unlike unquoted `tok=( $x )`)
  local n=${#tok[@]} i
  for ((i=0; i<n; i++)); do
    case "${tok[$i]}" in git|*/git) : ;; *) continue ;; esac
    local j=$((i+1)) subcmd="" gt val
    while (( j < n )); do
      gt="${tok[$j]}"
      case "$gt" in
        -c)
          val="${tok[$((j+1))]:-}"
          case "$(_gl_lc "$val")" in
            core.hookspath*) printf '%s' "G1: hook-bypass token -- git -c core.hooksPath override"; return 0 ;;
          esac
          j=$((j+2)); continue ;;
        -c*)
          case "$(_gl_lc "${gt#-c}")" in
            core.hookspath*) printf '%s' "G1: hook-bypass token -- git -c core.hooksPath override"; return 0 ;;
          esac
          j=$((j+1)); continue ;;
        -C|--git-dir|--work-tree|--namespace|--super-prefix)
          j=$((j+2)); continue ;;
        --git-dir=*|--work-tree=*|--namespace=*|--super-prefix=*)
          j=$((j+1)); continue ;;
        -*)
          j=$((j+1)); continue ;;
        *)
          subcmd="$gt"; break ;;
      esac
    done
    [[ -n "$subcmd" ]] || continue
    case "$subcmd" in
      commit)
        local k=$((j+1)) ct
        while (( k < n )); do
          ct="${tok[$k]}"
          case "$ct" in
            git|*/git) break ;;
            --no-verify) printf '%s' "G1: hook-bypass token -- git commit --no-verify"; return 0 ;;
            --*) : ;;
            -*) case "$ct" in *n*) printf '%s' "G1: hook-bypass token -- git commit -n (standalone or combined short-flag cluster)"; return 0 ;; esac ;;
          esac
          k=$((k+1))
        done ;;
      push)
        local k=$((j+1)) pt
        while (( k < n )); do
          pt="${tok[$k]}"
          case "$pt" in
            git|*/git) break ;;
            --no-verify) printf '%s' "G1: hook-bypass token -- git push --no-verify"; return 0 ;;
          esac
          k=$((k+1))
        done ;;
      merge)
        local k=$((j+1)) mt
        while (( k < n )); do
          mt="${tok[$k]}"
          case "$mt" in
            git|*/git) break ;;
            --no-verify) printf '%s' "G1: hook-bypass token -- git merge --no-verify"; return 0 ;;
          esac
          k=$((k+1))
        done ;;
      config)
        local k=$((j+1)) kt
        while (( k < n )); do
          kt="${tok[$k]}"
          case "$kt" in git|*/git) break ;; esac
          case "$(_gl_lc "$kt")" in
            core.hookspath) printf '%s' "G1: hook-bypass token -- git config core.hooksPath"; return 0 ;;
          esac
          k=$((k+1))
        done ;;
    esac
  done
  return 1
}

if [[ -n "$cmd" ]]; then
  if _gl_reason="$(_gl_bypass_reason "$cmd")"; then
    deny "$_gl_reason"
  fi
fi
# === end G1 DENY ==============================================================================================

# === CLASS-TABLE DENY: adopter-declared deny classes =========================================================
# Table: _index/greenlight-deny-classes.tsv (override for TESTS ONLY: GREENLIGHT_DENY_TABLE=<path>). It SHIPS EMPTY
# (header + column contract, zero data rows), so an unmodified install decides every command exactly as before.
# Columns (tab): class_id  deny_ere  wrapper_ere  reason.   '#' lines and blank lines are skipped; the line whose
# first field is class_id is the header; wrapper_ere is `-` when a class has no exempt wrapper form.
# A Bash command that matches a row's deny_ere and does NOT match its wrapper_ere -> "deny" (same shape as G1).
# FAIL-CLOSED: table absent / unreadable, a data row with fewer than 4 fields or an empty field, or an invalid ERE
# -> NO auto-approve this call (stderr line, exit 0 = the normal prompt flow). Never a silent allow.
# Runs after G1 (a bypass token is still denied first) and before the self-check, like G1, so a stale copy of this
# hook still refuses a declared class.
_gl_tbl="${GREENLIGHT_DENY_TABLE:-}"
if [[ -z "$_gl_tbl" ]]; then
  _gl_root="$(git rev-parse --show-toplevel 2>/dev/null)"
  [[ -n "$_gl_root" ]] && _gl_tbl="$_gl_root/_index/greenlight-deny-classes.tsv"
fi
if [[ -z "$_gl_tbl" || ! -r "$_gl_tbl" ]]; then
  echo "GREENLIGHT: UNVERIFIED — deny-class table unreadable (${_gl_tbl:-no repo root}); no auto-approve this call" >&2
  exit 0
fi
while IFS=$'\t' read -r _gl_id _gl_deny _gl_wrap _gl_why || [[ -n "${_gl_id}${_gl_deny}" ]]; do
  [[ -z "$_gl_id" || "$_gl_id" == \#* || "$_gl_id" == "class_id" ]] && continue
  if [[ -z "$_gl_deny" || -z "$_gl_wrap" || -z "$_gl_why" ]]; then
    echo "GREENLIGHT: UNVERIFIED — deny-class row '${_gl_id}' has an empty field; no auto-approve this call" >&2
    exit 0
  fi
  [[ -n "$cmd" ]] || continue
  _gl_rc=0; [[ "$cmd" =~ $_gl_deny ]] || _gl_rc=$?
  if [[ $_gl_rc -eq 2 ]]; then
    echo "GREENLIGHT: UNVERIFIED — deny-class row '${_gl_id}' has an invalid ERE; no auto-approve this call" >&2
    exit 0
  fi
  [[ $_gl_rc -eq 0 ]] || continue
  if [[ "$_gl_wrap" != "-" ]]; then
    _gl_wc=0; [[ "$cmd" =~ $_gl_wrap ]] || _gl_wc=$?
    if [[ $_gl_wc -eq 2 ]]; then
      echo "GREENLIGHT: UNVERIFIED — deny-class row '${_gl_id}' has an invalid wrapper ERE; no auto-approve this call" >&2
      exit 0
    fi
    [[ $_gl_wc -eq 0 ]] && continue
  fi
  deny "greenlight: deny class ${_gl_id} -- ${_gl_why//[\"\\]/\'}"
done < "$_gl_tbl"
# === end CLASS-TABLE DENY =====================================================================================

# --- CANONICAL SELF-CHECK (the _selfcheck_canonical shape) ------
# This hook is an AUTO-APPROVER that runs from the worktree copy; a stale copy is an authorization hazard for
# that seat alone. Running blob ≠ the spine ref's blob ⇒ emit NO decision (the documented fail-safe above: a false
# prompt is safe, a false allow is the failure). Unlike the pre-commit enforcer, UNREADABLE trunk also means no
# decision — here "cannot measure" costs one prompt, never a frozen fleet. One stderr line names the state.
# NOTE: the G1 deny check above already ran and already returned if this call was a bypass —
# a stale/unreadable copy reaching THIS point can therefore still only ever fall through to a prompt, never to
# a false allow, which is exactly the property this self-check exists to preserve for the allow path.
_gl_self="${BASH_SOURCE[0]:-$0}"
# the spine ref is the ONE resolver's output (the one spine-ref resolver); no resolution = no decision this call (the fail-safe
# above: a prompt), named, never a literal fallback (inv #5).
_gl_srs="$(cd -- "$(dirname -- "$_gl_self")" 2>/dev/null && pwd -P)/spine-ref.sh"   # beside this script only (0507 R2)
[[ -f "$_gl_srs" ]] || {
  echo "GREENLIGHT: UNVERIFIED — SPINE-REF-ABSENT $_gl_srs (the one spine-ref resolver is found beside this script only; 0507 R2); no auto-approve this call" >&2
  exit 0; }
_gl_ref="$(bash "$_gl_srs" 2>/dev/null)" && [[ -n "$_gl_ref" ]] || {
  echo "GREENLIGHT: UNVERIFIED — SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled (the one spine-ref resolver); no auto-approve this call" >&2
  exit 0; }
_gl_canon="$(git rev-parse -q --verify "${_gl_ref}:scripts/greenlight-policy.sh" 2>/dev/null)"
_gl_run="$(git hash-object "$_gl_self" 2>/dev/null)"
if [[ -z "$_gl_canon" || -z "$_gl_run" ]]; then
  echo "GREENLIGHT: UNVERIFIED — cannot read ${_gl_ref}:scripts/greenlight-policy.sh or hash the running copy; no auto-approve this call" >&2
  exit 0
fi
if [[ "$_gl_run" != "$_gl_canon" ]]; then
  echo "GREENLIGHT: STALE — no auto-approve until currency-sync (running ${_gl_run:0:8} ≠ ${_gl_ref} ${_gl_canon:0:8})" >&2
  exit 0
fi

[[ -n "$cmd" ]] || exit 0                     # unparseable -> prompt

# --- FAIL-CLOSED tripwires: any of these -> do NOT auto-approve (prompt / static-deny handles) -----------
#   deny-class tokens, command substitution, background, process-subst, or a newline (multi-line body).
case "$cmd" in
  *"rm -rf"*|*"rm -fr"*|*"sudo "*|*"--dangerously-skip-permissions"*|\
  *"git push --force"*|*"git push -f "*|*"--force-with-lease"*|\
  *"curl "*|*"wget "*|*"nc "*|*"ssh "*|*".env"*|*"secrets/"*|\
  *'`'*|*'$('*|*'>('*|*'<('*|*'&'*) exit 0 ;;
esac
case "$cmd" in *$'\n'*) exit 0 ;; esac        # multi-line -> prompt
# reject compound sequencing (&& || ;) -- L2 mandates single invocations; compound -> prompt
case "$cmd" in *"&&"*|*"||"*|*";"*) exit 0 ;; esac

allow() {
  printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow","permissionDecisionReason":"%s"}}\n' "$1"
  exit 0
}
trim() { local s="$1"; s="${s#"${s%%[![:space:]]*}"}"; s="${s%"${s##*[![:space:]]}"}"; printf '%s' "$s"; }

# --- split on single '|' into pipe stages (|| already rejected above) -------------------------------------
IFS='|' read -r -a stages <<< "$cmd"
[[ ${#stages[@]} -ge 1 ]] || exit 0

readonly_filter() {   # a permitted post-filter stage (2nd+ in a pipe): read-only text tools only
  local s; s="$(trim "$1")"
  case "$s" in
    grep*|egrep*|fgrep*|head*|tail*|sed*|awk*|sort*|uniq*|wc*|cut*|tr*|cat*|jq*|rev*|nl*|column*) return 0 ;;
    *) return 1 ;;
  esac
}

primary_in_policy() {   # the FIRST stage: the actual action
  local s; s="$(trim "$1")"
  # strip harmless trailing stderr redirects so they don't defeat the match
  s="${s/ 2>&1/}"; s="${s/ 2>\/dev\/null/}"; s="$(trim "$s")"
  case "$s" in
    # any other output redirect must target .tmp/ ONLY (else prompt)
    *">"*)
      case "$s" in *">.tmp/"*|*"> .tmp/"*|*">>.tmp/"*|*">> .tmp/"*) : ;; *) return 1 ;; esac ;;
  esac
  case "$s" in
    # scripts/* entrypoints -- REQUIRE clean-at-HEAD (tampered/uncommitted -> prompt)
    scripts/*|./scripts/*|bash\ scripts/*|bash\ ./scripts/*)
      local tok path; tok="${s#bash }"; tok="$(trim "$tok")"; path="${tok%% *}"; path="${path#./}"
      [[ "$path" == scripts/*.sh || "$path" == scripts/* ]] || return 1
      # G13 (window-plan row 9): run_sql.sh is the sole SQL apply path (CLAUDE.md) and its
      # receipt is mandatory (canon §4). A call without --emit-receipt is DENIED here, before the clean-at-HEAD
      # checks, because a fall-through reaches the static settings.json allow and runs receipt-less.
      if [[ "$path" == "scripts/run_sql.sh" ]]; then
        case "$s" in *"--emit-receipt"*) : ;; *) deny "greenlight: scripts/run_sql.sh without --emit-receipt (receipt mandatory)" ;; esac
      fi
      [[ -f "$path" ]] || return 1
      [[ -z "$(git status --porcelain -- "$path" 2>/dev/null)" ]] || return 1   # dirty/untracked -> prompt
      git ls-files --error-unmatch "$path" >/dev/null 2>&1 || return 1          # must be tracked@HEAD
      return 0 ;;
    # read-only git
    git\ status*|git\ log*|git\ diff*|git\ show*|git\ rev-parse*|git\ ls-tree*|git\ ls-files*|\
    git\ branch*|git\ check-ignore*|git\ fsck*|git\ worktree\ list*|git\ fetch*) return 0 ;;
    # receipt-lane git write sequence (each is its own single invocation per L2)
    git\ add\ *|git\ commit\ *|git\ commit) return 0 ;;
    git\ push\ origin\ *)
      case "$s" in *"--force"*|*" -f"*|*"--force-with-lease"*) return 1 ;; *) return 0 ;; esac ;;
    # read-only inspection tools + scratch writes to .tmp/
    ls*|cat*|grep*|egrep*|head*|tail*|sed*|awk*|sort*|uniq*|wc*|cut*|tr*|printf*|echo*|jq*|\
    tmux\ ls*|tmux\ list-*|tmux\ capture-pane*|which*|command\ -v*|npx\ tsc*|npm\ run*) return 0 ;;
    *) return 1 ;;
  esac
}

primary_in_policy "${stages[0]}" || exit 0
for ((i=1; i<${#stages[@]}; i++)); do
  readonly_filter "${stages[$i]}" || exit 0
done
allow "greenlight: single in-policy invocation (scripts@HEAD/read-only/receipt-lane) + read-only tails"
