#!/usr/bin/env bash
# scripts/creed-scan-spine.sh — run the SPINE's creed-scan bytes at a boundary.
#
# WHY: the SessionStart/Stop boundary scans used to run `$WT_ROOT/scripts/creed-scan.sh` — the LANE'S OWN branch
# copy — which was STALE on 6 of 6 lanes, so no lane ran the L3 / manufactured-door / attribution
# detectors. Executing origin/main's bytes makes a scanner change reach every lane with NO per-lane sync, the
# same principle boot-check.sh already applies to disciplines.md (GOV_REF=origin/main) and the ruling that
# "lanes read the spine". This runner is deliberately tiny so it almost never needs to change itself.
#
# FAIL-CLOSED (DISC-CHILD-FAILURE-MUST-SURFACE): spine unreadable => an explicit UNREADABLE line and exit 3,
# never a silent or clean-looking scan. Callers run it under `|| true`, so a fault can never block a boot.
# CREED_SPINE_REF overrides the ref ONLY for the fail-closed test pole (B2).
set -u
# the spine ref (the one spine-ref resolver): CREED_SPINE_REF if set (a replica/test knob), else the ONE resolver scripts/spine-ref.sh;
# no resolution is a HALT by name, never a literal fallback (inv #5).
REF="${CREED_SPINE_REF:-}"
SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"   # beside this script only (0507 R2)
[ -n "$REF" ] || [ -f "$SPINE_REF_SH" ] || { echo "CREED-CHECK: UNREADABLE — SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2). This is NOT a clean scan. (exit 3)"; exit 3; }
[ -n "$REF" ] || REF="$(bash "$SPINE_REF_SH")" || { echo "CREED-CHECK: UNREADABLE — SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and CREED_SPINE_REF unset (the one spine-ref resolver). This is NOT a clean scan. (exit 3)"; exit 3; }
TD="$(mktemp -d "${TMPDIR:-/tmp}/creed-spine.XXXXXX")" || { echo "CREED-CHECK: UNREADABLE — mktemp failed (exit 3)"; exit 3; }
trap 'rm -rf "$TD"' EXIT
T="$TD/creed-scan.sh"
[ -f "$SPINE_REF_SH" ] && cp "$SPINE_REF_SH" "$TD/spine-ref.sh"   # the spine copy runs beside this script's resolver (0507 R2)
if git show "${REF}:scripts/creed-scan.sh" > "$T" 2>/dev/null && [ -s "$T" ]; then
    echo "[creed-scan source: SPINE(${REF}) blob $(git rev-parse --short "${REF}:scripts/creed-scan.sh" 2>/dev/null)]"
    bash "$T" "$@"
    exit $?
fi
echo "CREED-CHECK: UNREADABLE — ${REF}:scripts/creed-scan.sh could not be read. This is NOT a clean scan. Fetch, then re-run."
exit 3
