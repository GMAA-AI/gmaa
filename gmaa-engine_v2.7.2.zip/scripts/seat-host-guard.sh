#!/bin/bash
# scripts/seat-host-guard.sh <classify|record> — the ONE "is this session the seat?" predicate.
# A seat's session is the one its loop launched in the seat's tmux session: SessionStart source `startup` (or a
# `resume`/`clear`/`compact` of that same session), a child of scripts/seat-loop.sh. A session in a seat worktree that
# booted with source `fork`, or that runs under the background daemon, is a SECOND occupant: it never works, never
# commits, never runs a seat verb. It is halted loud here; foundation ends it (`claude stop <id>`).
# stdin: the SessionStart hook JSON (session_id, source, transcript_path). With no JSON on stdin (a hand run from a
#   tool shell), the session is $CLAUDE_CODE_SESSION_ID and the source is read from .claude/seat-boot.log.
# NOT the seat iff ANY of (each one checkable, never inferred):
#   (a) source == fork (this boot), or this session's FIRST .claude/seat-boot.log line has source fork (a later
#       /compact of the continuation boots `compact`, and is still not the seat);
#   (b) $CLAUDE_JOB_DIR is set (the daemon's own job directory, inherited by a daemon-hosted session);
#   (c) `claude agents --json --cwd <root>` lists this session id with kind "background" (bounded wait, SHG_AGENTS_WAIT
#       s, default 3; a listing that does not answer is skipped, never read as "not background").
#   A headless `claude -p` (source startup, no $TMUX) is NOT halted: $TMUX alone is never the predicate.
# classify: prints the SEAT-HOST-HALT line and exits 3 when not the seat; prints nothing and exits 0 otherwise.
# record:   as classify, and on a halt ALSO appends the line to .claude/seat-loop.log and rings foundation
#           (scripts/doorbell.sh) from a module lane, once per session id. Always exits 0 (a SessionStart hook never
#           blocks a boot; boot-check.sh carries the rc). The hub does not ring itself: its own pane may be the viewer.
# Line (four facts: sid, source, continued-from, who ends it):
#   SEAT-HOST-HALT <utc> <sid> source=<src> host=<fork|daemon|background> continued-from=<pane sid|unknown> — not the
#   seat; no work, no commit, no seat verb; foundation ends it with: claude stop <sid>
# Seams (tests only): SHG_CLAUDE_BIN (claude), SHG_AGENTS_WAIT (3).
set -u
VERB="${1:-}"
case "$VERB" in classify|record) ;; *) echo "usage: scripts/seat-host-guard.sh <classify|record> < hook-json" >&2; exit 2 ;; esac
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
[ -f "$ROOT/_boot/BOOTSTRAP.md" ] || exit 0          # not a seat worktree: nothing to guard
IN=""
[ -p /dev/stdin ] && { IFS= read -r -t 2 -d '' IN || true; }   # bounded: a held-open pipe never hangs a boot
SID="$(printf '%s' "$IN" | jq -r '.session_id // empty' 2>/dev/null)"
SRC="$(printf '%s' "$IN" | jq -r '.source // empty' 2>/dev/null)"
TP="$(printf '%s' "$IN" | jq -r '.transcript_path // empty' 2>/dev/null)"
SID="${SID:-${CLAUDE_CODE_SESSION_ID:-}}"
[ -n "$SID" ] || exit 0
BOOTLOG="$ROOT/.claude/seat-boot.log"
FIRST_SRC="$(awk -v s="$SID" '$1==s {print $4; exit}' "$BOOTLOG" 2>/dev/null)"
SRC="${SRC:-${FIRST_SRC:--}}"
HOST=""
if [ "$SRC" = fork ] || [ "$FIRST_SRC" = fork ]; then HOST=fork
elif [ -n "${CLAUDE_JOB_DIR:-}" ]; then HOST=daemon
else
  CB="${SHG_CLAUDE_BIN:-claude}"; WAITS="${SHG_AGENTS_WAIT:-3}"
  OUT="$(mktemp "${TMPDIR:-/tmp}/shg.XXXXXX" 2>/dev/null)" || OUT=""
  if [ -n "$OUT" ]; then
    "$CB" agents --json --cwd "$ROOT" > "$OUT" 2>/dev/null & AP=$!
    i=0; while kill -0 "$AP" 2>/dev/null && [ "$i" -lt $((WAITS * 10)) ]; do sleep 0.1; i=$((i + 1)); done
    kill "$AP" 2>/dev/null; wait "$AP" 2>/dev/null
    # a listed id may be the short form (8 hex), so it matches when it is a non-empty prefix of this session id
    jq -e --arg s "$SID" 'type == "array" and any(.[]; .kind == "background" and ((.id // .sessionId // "") as $i | $i != "" and ($s | startswith($i))))' "$OUT" >/dev/null 2>&1 && HOST=background
    rm -f "$OUT"
  fi
fi
[ -n "$HOST" ] || exit 0
# continued-from: the pane session whose transcript records `continued-in` naming this session (same project dir)
FROM=""
TD="$(dirname "${TP:-/nonexistent/x}")"
if [ -d "$TD" ]; then
  HIT="$(find "$TD" -maxdepth 1 -name '*.jsonl' -mmin -30 2>/dev/null | xargs grep -h -m1 -E "\"continuedInSessionId\" *: *\"$SID\"" 2>/dev/null | head -1)"
  FROM="$(printf '%s' "$HIT" | jq -r '.sessionId // empty' 2>/dev/null)"
fi
LINE="SEAT-HOST-HALT $(date -u +%Y-%m-%dT%H:%M:%SZ) $SID source=$SRC host=$HOST continued-from=${FROM:-unknown} — not the seat; no work, no commit, no seat verb; foundation ends it with: claude stop $SID"
echo "$LINE"
if [ "$VERB" = record ]; then
  LOG="$ROOT/.claude/seat-loop.log"
  if ! grep -qE "^SEAT-HOST-HALT [^ ]+ $SID " "$LOG" 2>/dev/null; then
    printf '%s\n' "$LINE" >> "$LOG" 2>/dev/null
    LANE="$(bash "$ROOT/scripts/resolve-project.sh" --field lane "$ROOT" 2>/dev/null)"
    [ -n "$LANE" ] && [ "$LANE" != foundation ] && bash "$ROOT/scripts/doorbell.sh" ring foundation >/dev/null 2>&1
  fi
  exit 0
fi
exit 3
