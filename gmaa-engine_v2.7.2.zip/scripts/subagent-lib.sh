#!/bin/bash
# scripts/subagent-lib.sh — SOURCED, never run. The one shared definition of a subagent's bound
# (the per-subagent bound rule and its amendment), used by every caller so the cap hook, the
# Stop hook and the watchdog cannot disagree:
#   scripts/subagent-ledger.sh (SubagentStart/SubagentStop/SessionStart) · scripts/subagent-cap.sh (PreToolUse)
#   · scripts/seat-b6-stop.sh (Stop; watchdog mode) · scripts/seat-exit.sh (intent; watchdog launch).
#
# INTERIM NUMBERS (the bound rule's interim clause; re-set from data on the usage-record path, never silently). Frame: wall-clock
# MINUTES from SubagentStart (UTC epoch seconds in the ledger) to now. Set from foundation's 6 observations
# (6..31 min each, DISC-NO-INHERITED-COUNT denominator 6), so none of the 6 would have been cut.
SUBAGENT_CAP_MIN=35      # per-subagent wall-clock cap
RESTART_GRACE_MIN=5      # with an own-session intent pending: effective cap = min(CAP, age-at-intent + GRACE)
ABANDON_AFTER_MIN=2      # after its effective cap, time for a denied subagent to return before exit abandons it
#
# LEDGER (.claude/subagents-live, gitignored runtime state like the rest of .claude/), one TAB-separated line
# per live subagent:  session_id  agent_id  agent_type  start_epoch  start_utc  transcript_path
# Every reader acts ONLY on lines of the session in hand (0337 §3(d)): headless auditors share the worktree.
# ABANDON RECORD (.claude/subagents-abandoned):  utc  session_id  agent_id  agent_type  age_s  cap_s  transcript=<path|UNRESOLVED>
# NOW_EPOCH (test seam only): the probe compresses time through it; unset = the clock.

sa_now() { echo "${NOW_EPOCH:-$(date +%s)}"; }

# sa_intent_epoch <dir> <sid> -> epoch of an own-session intent (field 4 of .claude/seat-intent), or empty.
sa_intent_epoch() {
  local k s h e
  [ -f "$1/seat-intent" ] || return 0
  read -r k s h e _ < "$1/seat-intent" || true
  [ "${s:-}" = "$2" ] || return 0
  case "${e:-}" in ''|*[!0-9]*) return 0 ;; esac
  echo "$e"
}

# sa_eff_cap <start_epoch> <intent_epoch|empty> -> effective cap in seconds (0337 §2(b)).
sa_eff_cap() {
  local cap=$((SUBAGENT_CAP_MIN * 60)) g=$((RESTART_GRACE_MIN * 60)) at
  if [ -n "${2:-}" ]; then
    at=$(( $2 - $1 )); [ "$at" -lt 0 ] && at=0
    [ $((at + g)) -lt "$cap" ] && cap=$((at + g))
  fi
  echo "$cap"
}

# sa_live <dir> <sid> -> the ledger lines of this session only.
sa_live() { [ -f "$1/subagents-live" ] && awk -F'\t' -v s="$2" '$1==s' "$1/subagents-live"; return 0; }

# sa_drop <dir> <sid> <agent_id> -> remove that entry (session-scoped); atomic rewrite.
sa_drop() {
  [ -f "$1/subagents-live" ] || return 0
  awk -F'\t' -v s="$2" -v a="$3" '!($1==s && $2==a)' "$1/subagents-live" > "$1/subagents-live.$$" \
    && mv -f "$1/subagents-live.$$" "$1/subagents-live"
}

# sa_abandon <dir> <sid> <now> <intent_epoch|empty> -> move every live line of <sid> to the abandon record.
sa_abandon() {
  local d="$1" s="$2" now="$3" ie="${4:-}" sid aid at st su tp cap utc
  utc="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  while IFS=$'\t' read -r sid aid at st su tp; do
    [ -n "$aid" ] || continue
    cap="$(sa_eff_cap "$st" "$ie")"
    [ -n "$tp" ] && [ -e "$tp" ] || tp="UNRESOLVED"
    printf '%s\t%s\t%s\t%s\t%s\t%s\ttranscript=%s\n' "$utc" "$sid" "$aid" "$at" "$((now - st))" "$cap" "$tp" >> "$d/subagents-abandoned"
    sa_drop "$d" "$sid" "$aid"
  done < <(sa_live "$d" "$s")
}

# ---------------------------------------------------------------------------------------------------------
# Restart-classification remainder (as ruled: classification moves from the
# predecessor's exit to the successor's boot; the action column — keep a WORKING item, stop everything
# else — runs there, never at the fire point). Declared constants HERE ONLY ("declared constants in one
# place … printed in every classification line", 0387 §2), consumed by scripts/seat-exit.sh (item 4, the
# handoff's IN-FLIGHT lines) and scripts/seat-boot-assess.sh (0398 §3's ASSESS step). Never redeclared at a
# second call site.
INFLIGHT_WINDOW_MIN=3      # activity window: last subagent tool-call, or last background-shell output growth
# Poll-shape list (0387 §2): sleep, while/until loops, watch, tail -f. ("the Monitor tool" is the list's 5th
# member in the ruling's prose; it names a Monitor-tool CALL, a distinct tool invocation, never a Bash
# command string, so no regex over a `run_in_background` Bash command can see it — named in the build report.)
INFLIGHT_POLL_SHAPE_RE='sleep|watch|tail[[:space:]]+-f|\bwhile\b|\buntil\b'

# sa_poll_shape <command string> -> 0 (true) iff the command matches the declared poll-shape list.
sa_poll_shape() { printf '%s' "${1:-}" | /usr/bin/grep -qEi "$INFLIGHT_POLL_SHAPE_RE"; }

# sa_task_dir <root> <sid> -> the harness's own per-session scratch dir holding tasks/<id>.output.
# TASK_DIR_BASE (test seam): overrides the `/private/tmp/claude-<uid>` prefix for a fixture.
sa_task_dir() {
  local root="$1" sid="$2" slug base
  slug="$(printf '%s' "$root" | sed 's#/#-#g')"
  base="${TASK_DIR_BASE:-/private/tmp/claude-$(id -u)}"
  echo "$base/$slug/$sid/tasks"
}

# sa_shell_done <output_path> -> 0 (true) iff the harness's own completion marker is the output file's last
# line. A completed shell is never in flight.
sa_shell_done() {
  [ -e "$1" ] || return 1
  case "$(tail -1 "$1" 2>/dev/null)" in
    '[exited with code'*) return 0 ;;
    *) return 1 ;;
  esac
}

# sa_shell_cmd <root> <sid> <task_id> -> the bash -c command string of a background-shell task, read from
# this session's own transcript (the tool_use's `.input.command`, matched to the tool_result's
# `backgroundTaskId` via the shared `tool_use_id`/`id`). TRANSCRIPT_DIR (test seam) overrides the default
# `${CLAUDE_CONFIG_DIR:-~/.claude}/projects/<slug>` transcript directory (the session's own config dir, as ruled).
sa_shell_cmd() {
  local root="$1" sid="$2" tid="$3" slug tdir tfile tuid
  slug="$(printf '%s' "$root" | sed 's#/#-#g')"
  tdir="${TRANSCRIPT_DIR:-${CLAUDE_CONFIG_DIR:-$HOME/.claude}/projects/$slug}"
  tfile="$tdir/$sid.jsonl"
  [ -f "$tfile" ] || return 0
  tuid="$(/usr/bin/grep -F "\"backgroundTaskId\":\"$tid\"" "$tfile" 2>/dev/null \
    | /usr/bin/grep -o '"tool_use_id":"[^"]*"' | head -1 | sed 's/^"tool_use_id":"//;s/"$//')"
  [ -n "$tuid" ] || return 0
  /usr/bin/grep -F "\"id\":\"$tuid\"" "$tfile" 2>/dev/null \
    | /usr/bin/grep -o '"command":"[^"]*"' | head -1 | sed 's/^"command":"//;s/"$//'
}

# sa_classify_subagent <dir> <sid> <agent_id> <start_epoch> <now> <intent_epoch|empty> -> "<CLASS> <reason>"
# (0387 §2): STUCK past its effective cap; else WORKING if subagent-calls.log shows a tool call inside the
# INFLIGHT_WINDOW_MIN window; else IDLE. No MONITORING branch for a subagent — the ruling's poll-shape class
# is defined for a background shell's command string only.
sa_classify_subagent() {
  local d="$1" sid="$2" aid="$3" st="$4" now="$5" ie="${6:-}" cap age last lep
  cap="$(sa_eff_cap "$st" "$ie")"
  age=$((now - st))
  if [ "$age" -ge "$cap" ]; then echo "STUCK past-cap(${age}s/${cap}s)"; return 0; fi
  last=""
  if [ -f "$d/subagent-calls.log" ]; then
    last="$(awk -v s="$sid" -v a="$aid" '$2==s && $3==a {l=$1} END{print l}' "$d/subagent-calls.log" 2>/dev/null)"
  fi
  if [ -n "$last" ]; then
    lep="$(date -j -u -f '%Y-%m-%dT%H:%M:%SZ' "$last" +%s 2>/dev/null)"
    if [ -n "$lep" ] && [ $((now - lep)) -lt $((INFLIGHT_WINDOW_MIN * 60)) ]; then
      echo "WORKING tool-call-$((now - lep))s-ago"; return 0
    fi
  fi
  echo "IDLE no-call-in-${INFLIGHT_WINDOW_MIN}m"
}

# sa_classify_shell <output_path> <command> <now> -> "<CLASS> <reason>" (0387 §2). MONITORING overrides
# activity ("whatever its activity", 0387 §2) when the command is a poll shape. An empty/absent output path
# (an orphan shell scripts/backgrounded-sessions.sh names with no tracked output file) reads IDLE
# no-output-file rather than guessing, never a silent WORKING.
sa_classify_shell() {
  local out="${1:-}" cmd="$2" now="$3" mtime age
  if sa_poll_shape "$cmd"; then echo "MONITORING poll-shape"; return 0; fi
  mtime=""
  [ -n "$out" ] && mtime="$(stat -f %m "$out" 2>/dev/null)"
  if [ -z "$mtime" ]; then echo "IDLE no-output-file"; return 0; fi
  age=$((now - mtime))
  if [ "$age" -lt $((INFLIGHT_WINDOW_MIN * 60)) ]; then echo "WORKING output-grew-${age}s-ago"; return 0; fi
  echo "IDLE no-growth-in-${INFLIGHT_WINDOW_MIN}m(age=${age}s)"
}
