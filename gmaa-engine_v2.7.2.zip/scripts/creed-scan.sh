#!/usr/bin/env bash
# creed-scan.sh — boundary-time trigger->cite BREACH SCANNER (MECH-AUDIT).
#
# WHAT THIS IS: a LINTER, not a proof gate. It reads the seat's own COMMITTED RECORD since the last
# boundary and calls out blood-drawing emissions that landed WITHOUT their required inline citation.
# False positives are ACCEPTABLE BY RULING — the operator said "call it out", not "block". A human
# dispositions each call-out. THEREFORE THIS SCRIPT ALWAYS EXITS 0 on findings (see EXIT CODES).
#
# WHY IT EXISTS (0152 §1): the standing disciplines already exist; the failure is the missing 10% —
# a seat holds the rule and still does not FIRE it. A check that can be skipped WILL be skipped, so
# enforcement may not live in the persona. This runs FROM THE HOOK, independent of the agent.
#
# WHAT IT READS (0152 §2b): the seat's own durable outputs since the boundary marker — committed
# relay-outbox/** deposits, _rulings/** files, register edits, and COMMIT BODIES. It scans the
# RECORD (DISC-CITE-THE-ENFORCER), never the volatile context window (memory-not-evidence, B6).
#
# CLASSES (0152 §2a: "exactly the §0 table — invent nothing"). Five §0 boot-creed classes:
#   absence | deploy-state | closure | count | operator-door
# PLUS a SIXTH, ruled separately and explicitly:
#   deferral  — CLAUDE.md #11 never-idle / no-deferral-without-a-hard-dependency
# ⚠ DO NOT ADD A CLASS HERE WITHOUT AN ARCHITECT RULING. 0152 §2a says invent nothing; the sixth
#   class is here because an architect ruling required it, not as a quiet widening.
#
# ⛔ THE SIXTH CLASS IS DELIBERATELY PARTIAL — READ BEFORE TRUSTING ITS SILENCE.
#   CLAUDE.md #11 is TWO breach classes, and only one can be mechanized:
#     (i)  BARE DEFERRAL  — deferral language with NO named blocker at all. DETECTABLE. This is it.
#     (ii) FALSE DEFERRAL — a blocker IS named but is not a real/hard dependency (a disposition
#          dressed as a dependency). *** NOT MECHANIZABLE AND NOT ATTEMPTED HERE. *** Deciding a
#          named dependency is false is judgment over unstructured evidence; a regex that merely
#          checks a blocker is NAMED would PASS the motivating breach (a prior breach named "wait
#          for the auditor sentinel" — a false blocker), i.e. a pass-arm passing for the wrong
#          reason, which manufactures false confidence and is WORSE than no detector. An LLM fire
#          in the mechanism is barred (DISC-LLM-AT-THE-EDGES) and the governing ruling REFUSES it.
#          Class (ii) stays enforced by the persona + post-commit auditor + the operator's eye.
#   ⇒ BINDING OUTPUT CONTRACT: this class NEVER emits or implies "#11 satisfied" /
#     "no never-idle breach". It emits its LITERAL finding only (DEFER-CHECK / DEFER-BREACH) and
#     ALWAYS prints the standing out-of-scope note, so a clean class-(i) scan can never be misread
#     as full #11 enforcement. The third selftest pole PROVES the blind spot rather than claiming it.
#
# EXIT CODES (deliberate, and NOT the usual convention — read before "fixing"):
#   0 = scan completed (WHETHER OR NOT breaches were found). Linter semantics, per ruling.
#       ⚠ EXCEPT in --staged / --msg GATE mode: there, 1 = the OUTGOING commit
#       carries a breach and the commit-msg hook REJECTS it. The boundary (history) mode above is UNCHANGED
#       and still exits 0 — it is the second layer, and it re-surfaces every recorded WAIVE: as CREED-WAIVER.
#   3 = the scanner could not READ what it needs (bad range / not a repo). HALT-LOUD, never a
#       silent zero — an unreadable scan must not masquerade as a clean one (DISC-ABSENCE-OF-RECORD:
#       an absence is evidence only when the recording mechanism is proven live).
#
# USAGE:
#   scripts/creed-scan.sh                 # scan since the stored marker (or last 10 commits)
#   scripts/creed-scan.sh --since <ref>   # scan an explicit range <ref>..HEAD
#   scripts/creed-scan.sh --since <a> --until <b>   # scan a PINNED range <a>..<b> (every pass)
#       --until REQUIRES an explicit --since: alone it is refused, exit 3
#   scripts/creed-scan.sh --stamp         # after scanning, advance the marker to HEAD
#   scripts/creed-scan.sh --lane <lane>   # override lane label in output
#   scripts/creed-scan.sh --class deferral   # run ONLY the named class (default: all six)
#   scripts/creed-scan.sh --class criteria-src   # run ONLY the criteria-provenance pass
#   SELFTEST=1 scripts/creed-scan.sh      # run the poles (2 creed + 4 deferral) and exit
#   scripts/creed-scan.sh --staged --msg <file>   # commit-time GATE: added lines in the emitting set + message;
#                                                 #   exit 1 on breach (run by agents/commit-msg-hook.sh)
#
set -u   # NOT -e: a linter must survive a grep that matches nothing.

# the one spine-ref resolver, found BESIDE THIS SCRIPT only (0507 R2); resolved before the cd below. A hook that runs a
# copy of this scanner places its own resolver beside the copy.
SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || {
    echo "CREED-SCAN: UNREADABLE — not inside a git worktree. HALT-LOUD (exit 3)." >&2
    exit 3
}
cd "$REPO_ROOT" || { echo "CREED-SCAN: UNREADABLE — cannot cd to repo root. (exit 3)" >&2; exit 3; }

MARKER_FILE="$(git rev-parse --git-dir)/creed-scan-through"   # runtime class: never committed
SINCE=""
UNTIL=""   # upper bound for --since (default HEAD) — lets a probe PIN a historical range
STAMP=0
LANE="${lane:-}"
WINDOW=3          # "near window": lines around the emission in which a cite counts as inline
# Transcription exemption (as amended): a `>` line is a TRANSCRIPTION (someone's words), exempt,
#   only when the marker ATTRIBUTES the line BY POSITION, never when it merely appears in it:
#   (i) line-initial: after `>`, an attribution label (`**…:**` / `**…**:` / operator: / foundation-N: / architect-N: /
#       ARCH-N: / _rulings/NNNN:) or an OPENING quote char (" “ `) that begins a quoted span, optionally inside up to 3
#       `*`/`_` emphasis markers, ONLY when the span IS the line's content (SET-0113): (a) unclosed on
#       the line (a multi-line quote; 0305 §3 escape valve) or (b) wholly quoted (the close is the last
#       content, modulo trailing emphasis / punctuation / space; this is (iii)). A span that CLOSES mid-line and is
#       followed by authored text is SCANNED. 0308: no widening; annotate a transcription with a line-initial label.
#       Arm (ii) admits NO free-text tail after the source/date (auditor 34380f0f F1: a 24-char lowercase tail group had
#       ridden in with the SET-0113 draft and admitted `— operator <authored prose>`; stripped at SET-0116);
#   (ii) line-final: `— <source>` / `– <source>`, where <source> is the operator, a ref (foundation-/architect-/ARCH-N,
#       _rulings/NNNN, optional § suffix), optionally in `/*/_ wrappers and optionally dated `, YYYY-MM-DD` (escape
#       valve: `— operator, 2026-09-20.`). NO Proper-Name arm (auditor 9a34643f F1): by
#       shape a name cannot be told from a capitalised comment (`— Verified`), and the arm had 0 corpus users of 9,598;
#       attribute a named person line-initially (`> **Name:** …`).
#   Matched CASE-SENSITIVELY (grep -qE, not -qiE): the `[Oo]perator` / `[Tt]he` arms spell out the only case latitude.
TRANSCRIPTION_RE='^>+[[:space:]]*(\*\*[^*]+(:\*\*|\*\*:)|([Oo]perator|foundation-[0-9]+|architect-[0-9]+|ARCH-[0-9]+|_rulings/[0-9]{4}):|[*_]{0,3}("[^"]*("[*_[:space:].,;:!?)]*)?|“[^”]*(”[*_[:space:].,;:!?)]*)?|`[^`]*(`[*_[:space:].,;:!?)]*)?)$)|(—|–)[[:space:]]*[`*_]*(([Tt]he )?[Oo]perator|foundation-[0-9]+|architect-[0-9]+|ARCH-[0-9]+|_rulings/[0-9]{4})[`*_]*( §[0-9][0-9a-z().]*)?(, [0-9]{4}-[0-9]{2}-[0-9]{2})?[[:space:].)*_]*$'
MAX_COMMITS=40    # cost guard: a boundary scan is a linter, not an archaeology dig
ONLY_CLASS=""     # --class <name>: restrict the scan to one class (default: all)
STAGED=0          # --staged: commit-time gate mode — judge the OUTGOING commit (added lines + message), exit 1 on breach
MSGFILE=""        # --msg <file>: the commit message file (commit-msg hook $1)

# auditor ac4caa28 O1: a value-flag given as the LAST argument used to hang forever —
# `shift 2` with one arg left fails WITHOUT shifting, so `$# -gt 0` never became false. Refuse it, exit 3,
# with a named reason (inv #5). An explicit empty value (`--since ""`) is still accepted, as before.
need_val() { [ "$1" -ge 2 ] || { echo "CREED-SCAN: UNREADABLE — $2 requires a value (none given). (exit 3)" >&2; exit 3; }; }
# auditor 0e08e6a4 O2: a value-flag followed by ANOTHER flag used to swallow that flag as its
# value — `--lane --staged` set LANE=--staged and SILENTLY dropped gate mode. No legitimate value here (a git
# ref, a lane, a count, a class name, a message-file path) begins with `--`, so refuse it, exit 3.
VALUE_FLAGS=" --since --until --lane --window --class --msg "
while [ $# -gt 0 ]; do
    case "$VALUE_FLAGS" in *" $1 "*) case "${2-}" in --*)
        echo "CREED-SCAN: UNREADABLE — $1 requires a value, got the flag '$2' instead. (exit 3)" >&2; exit 3 ;;
    esac ;; esac
    case "$1" in
        --since) need_val $# "$1"; SINCE="${2:-}"; shift 2 ;;
        --until) need_val $# "$1"; UNTIL="${2:-}"; shift 2 ;;
        --stamp) STAMP=1; shift ;;
        --lane)  need_val $# "$1"; LANE="${2:-}"; shift 2 ;;
        --window) need_val $# "$1"; WINDOW="${2:-3}"; shift 2 ;;
        --class) need_val $# "$1"; ONLY_CLASS="${2:-}"; shift 2 ;;
        --staged) STAGED=1; shift ;;                       # commit-time GATE mode (exit 1 on breach)
        --msg)   need_val $# "$1"; MSGFILE="${2:-}"; shift 2 ;;   # the outgoing commit message (commit-msg $1)
        -h|--help) sed -n '1,48p' "$0"; exit 0 ;;
        *) echo "CREED-SCAN: unknown argument '$1' (exit 3)" >&2; exit 3 ;;
    esac
done

# ---- lane label (best effort; never fatal — the scan is about the RECORD, not identity) ----
if [ -z "$LANE" ] && [ -r "_boot/BOOTSTRAP.md" ]; then
    LANE="$(sed -n 's/^lane:[[:space:]]*//p' _boot/BOOTSTRAP.md | head -1)"
fi
[ -z "$LANE" ] && LANE="unknown"

# ---- resolve the range ----
# auditor 32f63eec F1: --until with no EXPLICIT --since has no honest range. The default
# window is "last 10 from HEAD" and the marker is relative to a later boundary, so either one would pair a
# HEAD-relative start with a pinned end and print a label naming a range no pass scanned. Refuse, fail-closed,
# BEFORE the marker can fill SINCE (the same exit-3 shape as an unresolvable --until below).
if [ -n "$UNTIL" ] && [ -z "$SINCE" ]; then
    echo "CREED-SCAN: UNREADABLE — --until requires an explicit --since (a pinned end needs a pinned start). (exit 3)" >&2; exit 3
fi
if [ -z "$SINCE" ] && [ -r "$MARKER_FILE" ]; then
    SINCE="$(head -1 "$MARKER_FILE" | tr -d '[:space:]')"
fi
if [ -n "$SINCE" ] && ! git cat-file -e "${SINCE}^{commit}" 2>/dev/null; then
    echo "CREED-SCAN: marker '$SINCE' does not resolve; falling back to last 10 commits." >&2
    SINCE=""
fi
if [ -n "$UNTIL" ] && ! git cat-file -e "${UNTIL}^{commit}" 2>/dev/null; then
    echo "CREED-SCAN: UNREADABLE — --until '$UNTIL' does not resolve. (exit 3)" >&2; exit 3
fi
# auditor 9fb5f033 F1: ONE range end for EVERY pass. Before this, only the commit-body
# pass honored --until; pass (2) and class 7 scanned ${SINCE}..HEAD while the label printed SINCE..UNTIL,
# a label claiming a pinned range the pass did not scan (a false receipt).
SCAN_END="${UNTIL:-HEAD}"
if [ -n "$SINCE" ]; then
    RANGE="${SINCE}..${UNTIL:-HEAD}"
    RANGE_LABEL="$(git rev-parse --short "$SINCE")..$(git rev-parse --short "${UNTIL:-HEAD}")"
    # ⛔ HONEST LABEL: --max-count silently kept only the NEWEST $MAX_COMMITS while the label claimed
    # the whole range — a partial scan that read as a full one (DISC-ABSENCE-OF-RECORD: the denominator must be real).
    _rng_total="$(git rev-list --count "$RANGE" 2>/dev/null || echo 0)"
    if [ "${_rng_total:-0}" -gt "$MAX_COMMITS" ]; then
        RANGE_LABEL="${RANGE_LABEL} [TRUNCATED: newest ${MAX_COMMITS} of ${_rng_total} commits scanned — pin --until to scan an older window]"
    fi
else
    RANGE="-10"
    RANGE_LABEL="last-10-commits@$(git rev-parse --short HEAD)"
fi

# Enumerate commits. A FAILURE HERE IS FATAL, not an empty list — trap: `2>/dev/null` on an invalid
# pathspec turns a fatal into a FALSE ZERO, and a false zero reads exactly like a clean scan.
if [ -n "$SINCE" ]; then
    COMMITS="$(git rev-list --max-count="$MAX_COMMITS" "$RANGE")" || {
        echo "CREED-SCAN: UNREADABLE — git rev-list failed on '$RANGE'. (exit 3)" >&2; exit 3; }
else
    # --first-parent (ISSUE-CREED-SCAN-DEFAULT-WINDOW-FIRST-PARENT-ARTIFACT-DIFF-CROSSES-ADOPT-MERGE-2026-09-30):
    # the body pass and the artifact pass must read ONE frame. A date-ordered walk across an adopt merge
    # listed the spine's commits and skipped the lane's own.
    COMMITS="$(git rev-list --first-parent --max-count=10 HEAD)" || {
        echo "CREED-SCAN: UNREADABLE — git rev-list failed. (exit 3)" >&2; exit 3; }
fi

# DIFF_BASE — the one base every range-diff pass reads (artifacts · GOVCHECK · CRITERIA-SRC).
# With --since it is SINCE (unchanged). In the default window it is first-parent HEAD~10, EXCEPT that
# content brought in by a merge inside the window is excluded: the boundary scan reads "the seat's own
# durable outputs", and a merge's content is another seat's emission, already gated
# at its author's commit (the same rule the --staged block below applies to MERGE commits). Before this, a lane tip that is an adopt merge scanned the whole merged-in spine delta
# (a module lane: 261 files / 19,158 added lines; 276.6 s vs 11.7 s on main) and charged it to the lane.
# Mechanism: base = merge-tree(HEAD~10, newest in-window merge's 2nd parent). FALLBACK (labelled, never
# silent): a conflicted merge-tree, or an older in-window merge whose parent is not an ancestor of that
# 2nd parent, keeps the old first-parent base — it OVER-charges (fails toward more hits, never fewer).
DIFF_BASE="${SINCE:-HEAD~10}"
if [ -z "$SINCE" ] && git rev-parse -q --verify HEAD~10 >/dev/null; then
    _mrg="$(git rev-list --first-parent --merges --max-count=1 HEAD~10..HEAD)" || {
        echo "CREED-SCAN: UNREADABLE — git rev-list --merges failed. (exit 3)" >&2; exit 3; }
    if [ -n "$_mrg" ]; then
        _p2="$(git rev-parse -q --verify "${_mrg}^2")" || {
            echo "CREED-SCAN: UNREADABLE — ${_mrg}^2 does not resolve. (exit 3)" >&2; exit 3; }
        _mok=1
        for _m in $(git rev-list --first-parent --merges HEAD~10..HEAD); do
            for _p in $(git rev-list --parents -n1 "$_m" | cut -d' ' -f3-); do
                git merge-base --is-ancestor "$_p" "$_p2" || _mok=0
            done
        done
        _mrc=1
        if [ "$_mok" = 1 ]; then
            _mt="$(git merge-tree --write-tree --name-only --no-messages HEAD~10 "$_p2")"; _mrc=$?
            # A conflict OUTSIDE the scanned paths (e.g. `_boot/`, which every lane candidate resolves by
            # hand) cannot change what is charged, so it does not force the fallback. A conflict INSIDE a
            # scanned path would plant markers in the base, so it does.
            if [ "$_mrc" = 1 ]; then
                _mconf="$(printf '%s\n' "$_mt" | sed -n '2,$p' | grep -E '^(_orchestration/relay-outbox/|_rulings/|issues_register\.md$|_ratification/criteria/)' || true)"
                [ -z "$_mconf" ] && _mrc=0
            fi
        fi
        # LANE-AUTHORED PATHS KEEP THE FIRST-PARENT BASE (auditor 48cc2c3d F1). The reap is copy-by-file, so
        # a lane line that foundation reaps and the lane adopts back inside the window is ALSO in <merge>^2,
        # and the merge-tree base would swallow it: the author's own line would go uncharged (fails toward
        # FEWER hits). So every path a first-parent NON-merge commit in the window touched is reset to its
        # HEAD~10 entry in the base. Cost: merged-in lines in those same paths are charged too (fails toward
        # MORE hits, the only direction this frame may fail).
        _nown=0
        if [ "$_mrc" = 0 ]; then
            _own="$(git log --first-parent --no-merges --no-renames --format= --name-only HEAD~10..HEAD)" || {
                echo "CREED-SCAN: UNREADABLE — git log of lane-authored paths failed. (exit 3)" >&2; exit 3; }
            _own="$(printf '%s\n' "$_own" | grep -v '^$' | sort -u || true)"
            if [ -n "$_own" ]; then
                _nown="$(printf '%s\n' "$_own" | grep -c .)"
                _gidx="$(mktemp "${TMPDIR:-/tmp}/creedscan-idx.XXXXXX")" || {
                    echo "CREED-SCAN: UNREADABLE — mktemp for the base index failed. (exit 3)" >&2; exit 3; }
                _t0="$(printf '%s\n' "$_mt" | head -1)"
                _ok=1
                GIT_INDEX_FILE="$_gidx" git read-tree "$_t0" || _ok=0
                if [ "$_ok" = 1 ]; then
                    printf '%s\n' "$_own" | while IFS= read -r _f; do printf '0 %s\t%s\n' 0000000000000000000000000000000000000000 "$_f"; done \
                        | GIT_INDEX_FILE="$_gidx" git update-index --index-info || _ok=0
                fi
                if [ "$_ok" = 1 ]; then
                    _lst="$(printf '%s\n' "$_own" | while IFS= read -r _f; do git ls-tree HEAD~10 -- "$_f" || echo "LS-TREE-FAILED"; done)"
                    case "$_lst" in *LS-TREE-FAILED*) _ok=0 ;; esac
                    if [ "$_ok" = 1 ] && [ -n "$_lst" ]; then
                        printf '%s\n' "$_lst" | GIT_INDEX_FILE="$_gidx" git update-index --index-info || _ok=0
                    fi
                fi
                [ "$_ok" = 1 ] && { _mt="$(GIT_INDEX_FILE="$_gidx" git write-tree)" || _ok=0; }
                rm -f "$_gidx"
                [ "$_ok" = 1 ] || { echo "CREED-SCAN: UNREADABLE — re-basing lane-authored paths failed. (exit 3)" >&2; exit 3; }
            fi
        fi
        case "$_mrc" in
            0) DIFF_BASE="$(printf '%s\n' "$_mt" | head -1)"
               RANGE_LABEL="${RANGE_LABEL} [merged-in content excluded: base = HEAD~10 + $(git rev-parse --short "$_mrg")^2; lane-authored paths kept on the first-parent base: ${_nown}]" ;;
            1) RANGE_LABEL="${RANGE_LABEL} [MERGE-FRAME-FALLBACK: first-parent HEAD~10 base; merged-in text may be over-charged]" ;;
            *) echo "CREED-SCAN: UNREADABLE — git merge-tree failed (rc=$_mrc). (exit 3)" >&2; exit 3 ;;
        esac
    fi
fi

N_COMMITS=0
[ -n "$COMMITS" ] && N_COMMITS="$(printf '%s\n' "$COMMITS" | grep -c .)"

# ---------------------------------------------------------------------------
# CLASS TABLE (canon §4 :134 WRITTEN-IS-NOT-WIRED) — the DETECTION
# PATTERN per class (trigger regex / negation guard / requirement mode+shape / cite token / output
# prefix) stays HERE, keyed by class NAME, in the `class_pattern()` map immediately below. WHAT MOVED
# to `_index/governance.tsv` is the ROSTER — WHICH class names actually run, read from every row whose
# `wiring` column (col 10) is `scanner:<class>` — so a class's existence as a RUNNING RULE and its
# existence as a CURATED, WIRED governance-index entry can no longer silently disagree (one data-source
# change wires every scanner-class rule at once). Byte-identical patterns to the prior
# hardcoded table — this is a RELOCATION, not a re-derivation (`DISC-PRESERVATION-POLES`).
#
# WHY DEFERRAL (CLASS 6) STAYS HARDCODED, NOT INDEX-SOURCED: the governing ruling's own table
# says it plainly — "the 6th class, `deferral`, cites a CLAUDE.md numbered item outside this CORE set
# and has no match here" (`_index/annotations.tsv` curates disciplines.md §0 / CLAUDE.md invariants /
# curated contract clauses; CLAUDE.md item #11 is none of those). It remains the file's own explicit,
# ruled, hardcoded exception — exactly as this file's own header already says: "PLUS a SIXTH, ruled
# separately and explicitly ... DO NOT ADD A CLASS HERE WITHOUT AN ARCHITECT
# RULING." Appended AFTER the index-derived roster, same position (last) it held before.
#
# REQUIREMENT MODE (class_req_N): what must appear WITHIN the near-window for the line to be clean.
#   F = a literal cite token (grep -F)  — the five §0 creed classes: the discipline's own name.
#   E = a regex ALTERNATION (grep -E)   — the deferral class: "a NAMED BLOCKER", which is a SET of
#       phrasings, not one token. #11 does not name a discipline to cite; it demands a named,
#       checkable blocker, so the requirement is a shape, not a string.
#
# OUTPUT PREFIX (class_out_N): CREED = the boot-creed trigger->cite scanner. DEFER = the #11 class,
# which the governing ruling binds to its OWN literal labels so its silence can never be read as "#11
# satisfied". Two counters, two verdict lines — deliberately NOT pooled.
#
# class_pattern <class-name> <field>   field ∈ {regex, cite, neg, req_mode, req, out}
# ONE indirection point (`DISC-VIGILANCE-IS-FIELD-LOCAL`, this file's own cited discipline): every
# class's regex/cite/neg/req-mode/req/output-label lives in exactly this one case block, never
# duplicated elsewhere. Prints the requested field, or nothing + returns 1 if <class-name> is unknown
# here — the roster-builder below treats that as an unmapped `scanner:<class>` row (WARN, skip), and
# SPEC-GOVERNANCE-INDEX.md v0.2 §2 arm D treats it as DRIFT: "scanner: claims resolve only against the
# class roster read LIVE from creed-scan.sh's own class_name_N declarations".
# ---------------------------------------------------------------------------
class_pattern() {
    case "$1/$2" in
        absence/regex)          printf '%s' '(^|[^a-z])(no record|not found|never happened|zero hits|0 hits|nothing found|no such|absent at|[a-z]+-less)([^a-z]|$)' ;;
        absence/cite)           printf '%s' 'DISC-ABSENCE-OF-RECORD' ;;
        absence/neg)            printf '%s' '' ;;
        absence/req_mode)       printf '%s' 'F' ;;
        absence/req)            printf '%s' '' ;;
        absence/out)            printf '%s' 'CREED' ;;

        deploy-state/regex)     printf '%s' '(^|[^a-z])(is deployed|was deployed|is live|now live|is enabled|isActive|has landed|is landed|already landed|is wired|now wired)([^a-z]|$)' ;;
        deploy-state/cite)      printf '%s' 'DISC-VERIFY-DEPLOY-STATE-CLAIMS' ;;
        deploy-state/neg)       printf '%s' '' ;;
        deploy-state/req_mode)  printf '%s' 'F' ;;
        deploy-state/req)       printf '%s' '' ;;
        deploy-state/out)       printf '%s' 'CREED' ;;

        # ⚠ CITE TOKEN IS 'no-fake-closures', NOT the governance-index id 'inv#4' — this is the string
        # actually cited inline tree-wide (CLAUDE.md, disciplines.md, ledger/audit-findings.md all use
        # "no-fake-closures"; "inv #4" is a parenthetical companion label, never the searched token).
        # PRESERVED VERBATIM from the pre-C2 hardcoded table — swapping it for the index id would be a
        # silent behavior change, not a relocation.
        closure/regex)          printf '%s' '(^|[^a-z])(is done|are done|marked done|now resolved|is resolved|is closed|now closed|verified complete|fully cured)([^a-z]|$)' ;;
        closure/cite)           printf '%s' 'no-fake-closures' ;;
        closure/neg)            printf '%s' '' ;;
        closure/req_mode)       printf '%s' 'F' ;;
        closure/req)            printf '%s' '' ;;
        closure/out)            printf '%s' 'CREED' ;;

        # ⚠ NOUN SET NEUTRALIZED for genericizability: one domain content-noun was
        # REMOVED and replaced with engine-generic nouns. `lanes` is RETAINED deliberately — it is
        # canon vocabulary (the governance architecture's own term), not domain/site/vendor coupling.
        count/regex)            printf '%s' '(^|[^a-z])(all [0-9]+ |[0-9]+ of [0-9]+ (files|items|rows|records|entries|lanes|units)|[0-9]+/[0-9]+ (files|items|rows|records|entries|lanes|units))' ;;
        count/cite)             printf '%s' 'DISC-NO-INHERITED-COUNT' ;;
        count/neg)              printf '%s' '' ;;
        count/req_mode)         printf '%s' 'F' ;;
        count/req)              printf '%s' '' ;;
        count/out)              printf '%s' 'CREED' ;;

        operator-door/regex)    printf '%s' '(^|[^a-z])(operator (decision|door|go/no-go|sign-off)|routing to the operator|needs operator)([^a-z]|$)' ;;
        operator-door/cite)     printf '%s' 'DISC-ONE-DECISION-DOOR' ;;
        operator-door/neg)      printf '%s' '(no|zero|without an?|not an?|no new) (operator )?(decision )?door|door is closed|no operator door' ;;
        operator-door/req_mode) printf '%s' 'F' ;;
        operator-door/req)      printf '%s' '' ;;
        operator-door/out)      printf '%s' 'CREED' ;;

        # ---- DEFERRAL (CLAUDE.md #11). CLASS (i) ONLY: bare deferral, no blocker. HARDCODED
        # (see the note above the map) — not sourced from a governance-index scanner: row.
        # TRIGGER: deferral/banking language. Seeded from the RULED-REAL instances, not invented —
        # the governing ruling names "rides the next touch" / "non-urgent" / "batch it later" as "dispositions
        # wearing a dependency's clothes", and a prior "successor's first product move" was
        # charged as one.
        deferral/regex)         printf '%s' '(^|[^a-z])(defer(red|ring|ral)?|banked|bank it|punt(ed)?|postpone(d)?|shelved|rides the next|ride the next|next touch|batch(ed)? it later|batch later|non-urgent|not urgent|holding for|hold(ing)? off|revisit later|later pass|later cycle|next session|successors? first|leave (it |this )?(for|to) (the )?successor|will do at close|do it at close|circle back)([^a-z]|$)' ;;
        deferral/cite)          printf '%s' 'a NAMED blocker (CLAUDE.md #11)' ;;
        # Semantic-inverses (the governing ruling names the first three explicitly). These are the phrasings
        # that ASSERT the rule or REFUSE the deferral — charging them would make the linter fire on
        # every document that upholds #11, which is the fastest route to a muted detector.
        deferral/neg)           printf '%s' '(not|never|cannot|can not|may not|must not|no longer|is not|are not|was not|were not|rather than|instead of|refus|retract|lifted|removed|struck)[^.]{0,30}(defer|bank|punt|postpon|shelv|hold)|(driven|stated|ruled|executed|done)[ ,-]+not[ ,-]+(deferred|banked)|no deferral|without a hard dependency|except behind a hard dependency|deferral is|deferral-lifted|de-?ferral gate is removed|is not a deferral|not a bank|unbanked|un-banked' ;;
        deferral/req_mode)      printf '%s' 'E' ;;
        # REQUIREMENT: a NAMED BLOCKER adjacent to the deferral. #11: "A hard dependency is NAMED and
        # checkable" — a thing that CANNOT PROCEED until another thing completes.
        deferral/req)           printf '%s' '(hard dependenc|blocked by|blocker|depends on|dependent on|dependency|gated (on|by|behind)|pending |awaiting|waiting on|cannot proceed until|until .{1,40}(lands|completes|is ratified|is built|exists|resolves|returns)|requires |required before|needs .{1,40}first|no capacity|capacity)' ;;
        deferral/out)           printf '%s' 'DEFER' ;;

        *) return 1 ;;
    esac
}

# ---------------------------------------------------------------------------
# CLASS ROSTER — read from the governance index. Populates class_regex_N /
# class_cite_N / class_name_N / class_neg_N / class_req_mode_N / class_req_N / class_out_N for
# N=1..class_count, EXACTLY the variable shape the rest of this file (scan_blob, mint_resolves,
# SELFTEST) already consumes dynamically via `eval` — no downstream code changes needed.
#
# FAIL-CLOSED (inv #5 halt-loud; task brief): an unreadable index, or an index that yields ZERO
# resolvable `scanner:` rows, is NOT "scan nothing quietly" — it is a HALT, exit 3, before the class
# table exists at all. In --staged/--msg gate mode this fires before the gate can ever reach a PASS
# line, and the installed caller already fail-closes any non-{0,1} exit to REJECT (commit-msg-hook.sh:
# "scanner exited $rc (unreadable input) — fail-closed, never a silent pass") — so a broken index
# cannot silently pass a commit. A gate that checks nothing must not PASS.
# ---------------------------------------------------------------------------
# ⛔ INDEX SOURCE = THE SPINE, NEVER THE READER'S WORKTREE.
# The hooks run the SPINE's bytes of this file on every non-hub lane; C2 then read the index
# by a WORKTREE-relative path, i.e. from the lane's own branch — which is CORRECTLY not merged up to spine
# (currency is a READ). A lane whose branch copy carried 0 scanner: rows therefore failed closed on EVERY
# commit (2 of 7 branches at e47213f6: architect, a module lane). Canon FIX-SURFACE-DIVERGENCE class.
# RESOLUTION ORDER:
#   1. --staged run IN THE HUB's own worktree (resolve-lane spine_write=ALLOW) → the INDEX blob
#      (`git show :_index/governance.tsv`), so a commit that edits the index is judged by the index it commits;
#   2. the spine: `git show <ref>:_index/governance.tsv`, <ref> = CREED_INDEX_REF (a replica knob, as CREED_SPINE_REF) else
#      the ONE resolver scripts/spine-ref.sh (the one spine-ref resolver; the TRUNK_BRANCH slot, no literal; unresolvable = exit 3);
#   On a --staged run AT THE HUB, candidate 1 is the ONLY candidate (SET-0061, auditor 3ec40d8e F1): a 0-row /
#   unreadable staged index exits 3 and NEVER falls through to 2. Every other run — a lane, or a NON-staged run at
#   the hub (the SessionStart/Stop boundary scan) — has 2 as its only candidate (auditor a4d6a14d F1).
#   A candidate is ACCEPTED only if readable AND it carries ≥1 `scanner:` row; otherwise exit 3.
# The worktree copy is deliberately NOT a candidate: it is exactly the stale surface this cure removes.
# The chosen source is PRINTED so a reader sees which index judged the commit.
GOVERNANCE_TSV="_index/governance.tsv"
INDEX_REF="${CREED_INDEX_REF:-}"
_idx_candidates=""
if [ "$STAGED" -eq 1 ]; then
    _rl_line="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>/dev/null)" || _rl_line=""
    case " $_rl_line " in *" spine_write=ALLOW "*) _idx_candidates=":${GOVERNANCE_TSV}" ;; esac
fi
# HUB STAGED INDEX IS TERMINAL (auditor 3ec40d8e F1): at the hub the staged index is the index
# the commit LANDS, so it is the ONLY candidate. Falling through to the spine on a 0-row / deleted staged index
# judged a commit that zeroes the index by the OLD index — and it PASSed (fail-open). Now: accept or exit 3.
[ -n "$_idx_candidates" ] || [ -n "$INDEX_REF" ] || [ -f "$SPINE_REF_SH" ] || { echo "CREED-SCAN: UNREADABLE — SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2). A gate that checks nothing must not PASS. (exit 3)" >&2; exit 3; }
[ -n "$_idx_candidates" ] || { [ -n "$INDEX_REF" ] || INDEX_REF="$(bash "$SPINE_REF_SH")" && [ -n "$INDEX_REF" ] || { echo "CREED-SCAN: UNREADABLE — SPINE-REF-UNRESOLVED: $SPINE_REF_SH is unfilled and CREED_INDEX_REF is unset, so the governance index has no spine source (the one spine-ref resolver; inv #5). A gate that checks nothing must not PASS. (exit 3)" >&2; exit 3; }; _idx_candidates="${INDEX_REF}:${GOVERNANCE_TSV}"; }
_idx_content=""; INDEX_SOURCE=""; _idx_tried=""
for _idx_spec in $_idx_candidates; do
    if ! _idx_try="$(git show "$_idx_spec" 2>/dev/null)" || [ -z "$_idx_try" ]; then
        _idx_tried="${_idx_tried} ${_idx_spec}=unreadable"; continue
    fi
    _idx_n="$(printf '%s\n' "$_idx_try" | awk -F'\t' '/^#/{next} NF<11{next} $10 ~ /^scanner:./{n++} END{print n+0}')"
    if [ "${_idx_n:-0}" -eq 0 ]; then
        _idx_tried="${_idx_tried} ${_idx_spec}=0-scanner-rows"; continue
    fi
    _idx_content="$_idx_try"
    _idx_blob="$(git rev-parse --short "$_idx_spec" 2>/dev/null)"
    case "$_idx_spec" in
        :*) INDEX_SOURCE="STAGED-INDEX(:${GOVERNANCE_TSV}) blob ${_idx_blob:-?}" ;;
        *)  INDEX_SOURCE="SPINE(${INDEX_REF}) blob ${_idx_blob:-?}" ;;
    esac
    break
done
if [ -z "$_idx_content" ]; then
    echo "CREED-SCAN: UNREADABLE — governance index yields ZERO resolvable scanner: rows from every accepted source (tried:${_idx_tried}) (canon §4 written-is-not-wired: a scanner class table with no readable index is unwired, not silently empty). A gate that checks nothing must not PASS. (exit 3)" >&2
    exit 3
fi
echo "[index source: ${INDEX_SOURCE}]"

# Re-key rows to \x1f BEFORE any bash `read` (SPEC-GOVERNANCE-INDEX.md v0.2 §3 — the documented
# annot_lookup bug: bash `read` treats TAB as IFS-WHITESPACE and collapses adjacent EMPTY TAB fields,
# shifting every later field left; \x1f is non-whitespace so an empty field survives). Only id (col 1)
# and wiring (col 10) are needed here.
_GOV_ROWS="$(printf '%s\n' "$_idx_content" | awk -F'\t' '/^#/{next} NF<11{next} {printf "%s\037%s\n",$1,$10}')"

class_count=0
_idx_class_count=0
_seen_classes=""
if [ -n "$_GOV_ROWS" ]; then
    while IFS=$'\037' read -r _gid _gwiring; do
        [ -z "$_gid" ] && continue
        case "$_gwiring" in
            scanner:*)
                _gcls="${_gwiring#scanner:}"
                [ -z "$_gcls" ] && continue
                case " $_seen_classes " in *" $_gcls "*) continue ;; esac   # one row per class name wins
                if ! _p_regex="$(class_pattern "$_gcls" regex)"; then
                    echo "CREED-SCAN: WARN — governance index names scanner:${_gcls} (id=${_gid}) but this file's pattern map has no entry for '${_gcls}'; skipping (arm D of the governance-index probe should flag this as DRIFT)." >&2
                    continue
                fi
                _p_cite="$(class_pattern "$_gcls" cite)"
                _p_neg="$(class_pattern "$_gcls" neg)"
                _p_reqmode="$(class_pattern "$_gcls" req_mode)"
                _p_req="$(class_pattern "$_gcls" req)"
                _p_out="$(class_pattern "$_gcls" out)"
                class_count=$(( class_count + 1 ))
                _idx_class_count=$(( _idx_class_count + 1 ))
                eval "class_regex_${class_count}=\$_p_regex"
                eval "class_cite_${class_count}=\$_p_cite"
                eval "class_name_${class_count}=\$_gcls"
                eval "class_neg_${class_count}=\$_p_neg"
                eval "class_req_mode_${class_count}=\$_p_reqmode"
                eval "class_req_${class_count}=\$_p_req"
                eval "class_out_${class_count}=\$_p_out"
                _seen_classes="$_seen_classes $_gcls"
                ;;
        esac
    done <<< "$_GOV_ROWS"
fi

if [ "$_idx_class_count" -eq 0 ]; then
    echo "CREED-SCAN: UNREADABLE — governance index '$GOVERNANCE_TSV' yields ZERO resolvable scanner: rows. A gate that checks nothing must not PASS. (exit 3)" >&2
    exit 3
fi

# ---- append DEFERRAL last, hardcoded (see the note above class_pattern()) — same position it held
# before C2, so class_count lands at the same value (6) whenever the index carries its usual 5 rows. ----
class_count=$(( class_count + 1 ))
_p_regex="$(class_pattern deferral regex)"
_p_cite="$(class_pattern deferral cite)"
_p_neg="$(class_pattern deferral neg)"
_p_reqmode="$(class_pattern deferral req_mode)"
_p_req="$(class_pattern deferral req)"
_p_out="$(class_pattern deferral out)"
eval "class_regex_${class_count}=\$_p_regex"
eval "class_cite_${class_count}=\$_p_cite"
eval "class_name_${class_count}=deferral"
eval "class_neg_${class_count}=\$_p_neg"
eval "class_req_mode_${class_count}=\$_p_reqmode"
eval "class_req_${class_count}=\$_p_req"
eval "class_out_${class_count}=\$_p_out"

BREACHES=0
BREACH_OUT=""
DEFER_BREACHES=0     # kept SEPARATE from BREACHES by ruling — see the output contract at the top
DEFER_OUT=""

# has_cite <text-blob> <pattern> <mode>  -> 0 if the requirement is met within the blob
#   mode F = literal cite token (the five §0 classes)
#   mode E = regex alternation (the deferral class: "a named blocker" is a shape, not a token)
has_cite() {
    if [ "${3:-F}" = "E" ]; then
        printf '%s' "$1" | grep -qiE -- "$2"
    else
        printf '%s' "$1" | grep -qiF -- "$2"
    fi
}

# is_waived <line> <class> -> 0 if the line carries `WAIVE:<class> <reason of >= 8 words>`.
# Judgment-class gates only. The reason floor is structural (word count), not a quality judgment; a seat
# that waives by reflex shows up as a CREED-WAIVER count at every boundary, which is the point.
WAIVERS=0
WAIVER_OUT=""
is_waived() {
    printf '%s' "$1" | grep -qE "WAIVE:$2[[:space:]]+([^[:space:]]+[[:space:]]+){7}[^[:space:]]+"
}

# class_enabled <class-name> -> 0 if this class should run under the current --class filter
class_enabled() {
    [ -z "$ONLY_CLASS" ] && return 0
    [ "$ONLY_CLASS" = "$1" ] && return 0
    return 1
}

# scan_blob <label> <content-file> [charge-set-file]
# Reads a file of text, tests each line against every class, and looks for the required cite within
# +/- WINDOW lines. The WINDOW is why we slurp rather than stream: a cite one line below the claim
# is still "inline" to a human reader, and charging that would be a false positive we can cheaply avoid.
#
# CHARGE-SET (load-bearing): if a third arg is given, it is a file of line numbers, and ONLY those
# lines may be charged — the rest are read for CONTEXT only. This is what makes the scanner scan
# "register EDITS" (0152 §2b) rather than the whole artifact. Without it the scanner re-charges every
# historical line on every run: measured at 109 breaches over 6 commits, which is a flood, and a
# linter that cries on every sentence gets muted — worse than no linter at all.
scan_blob() {
    _label="$1"; _file="$2"; _charge="${3:-}"
    [ -s "$_file" ] || return 0
    _total="$(grep -c '' "$_file")"
    _i=0
    while IFS= read -r _line; do
        _i=$(( _i + 1 ))
        # skip trivial lines fast
        case "$_line" in ''|'---') continue ;; esac
        # charge-set filter: context lines are read, never charged
        if [ -n "$_charge" ] && ! grep -qx "$_i" "$_charge"; then continue; fi
        # STRUCTURAL SCOPE. The `>`/`|` byte was a proxy for "not the
        #   seat's own new claim"; the property replaces it. §2: a `|` table row is SCANNED (0 flood measured; its
        #   cite sits in-row or in the window). §3: a `>` line is SCANNED unless it is a transcription: (a) it
        #   is attributed BY POSITION (TRANSCRIPTION_RE); (b) relocation-fenced lines leave the charge set
        #   through the fence path below; (c) a line outside the edit set is context only (the filter above).
        #   SCAN_NO_TRANSCRIPTION=1 turns (a) off for the relocation (d) probe of a cut SOURCE: there the question
        #   is whether the text LEFT the source, and a quoted retention has not (auditor 0e4a1a59 F1).
        case "$_line" in '>'*)
            if [ "${SCAN_NO_TRANSCRIPTION:-0}" != 1 ] && printf '%s' "$_line" | grep -qE -- "$TRANSCRIPTION_RE"; then continue; fi ;;
        esac
        _c=1
        while [ "$_c" -le "$class_count" ]; do
            eval "_re=\$class_regex_${_c}; _cite=\$class_cite_${_c}; _cn=\$class_name_${_c}; _neg=\$class_neg_${_c}"
            eval "_mode=\$class_req_mode_${_c}; _out=\$class_out_${_c}"
            if [ "$_mode" = "E" ]; then eval "_req=\$class_req_${_c}"; else _req="$_cite"; fi
            if ! class_enabled "$_cn"; then _c=$(( _c + 1 )); continue; fi
            if [ -n "$_neg" ] && printf '%s' "$_line" | grep -qiE -- "$_neg"; then _c=$(( _c + 1 )); continue; fi
            if printf '%s' "$_line" | grep -qiE -- "$_re"; then
                _lo=$(( _i - WINDOW )); [ "$_lo" -lt 1 ] && _lo=1
                _hi=$(( _i + WINDOW )); [ "$_hi" -gt "$_total" ] && _hi="$_total"
                _ctx="$(sed -n "${_lo},${_hi}p" "$_file")"
                if ! has_cite "$_ctx" "$_req" "$_mode" && is_waived "$_line" "$_cn"; then
                    # A RECORDED waiver on the flagged line passes the gate, and is SURFACED here
                    # at every scan so the human disposition 0152 requires still happens (never silent).
                    WAIVERS=$(( WAIVERS + 1 ))
                    WAIVER_OUT="${WAIVER_OUT}CREED-WAIVER: ${_label}:${_i} | class=${_cn}
    > $(printf '%s' "$_line" | cut -c1-96)
"
                elif ! has_cite "$_ctx" "$_req" "$_mode"; then
                    _snip="$(printf '%s' "$_line" | cut -c1-96)"
                    if [ "$_out" = "DEFER" ]; then
                        DEFER_BREACHES=$(( DEFER_BREACHES + 1 ))
                        DEFER_OUT="${DEFER_OUT}DEFER-BREACH: ${_label}:${_i} | deferral with no named blocker
    > ${_snip}
"
                    else
                        BREACHES=$(( BREACHES + 1 ))
                        BREACH_OUT="${BREACH_OUT}CREED-BREACH: ${_label}:${_i} | class=${_cn} | missing-cite=${_cite}
    > ${_snip}
"
                    fi
                fi
            fi
            _c=$(( _c + 1 ))
        done
    done < "$_file"
}

TMPD="${TMPDIR:-/tmp}/creed-scan.$$"
mkdir -p "$TMPD" || { echo "CREED-SCAN: UNREADABLE — cannot create temp dir. (exit 3)" >&2; exit 3; }
trap 'rm -rf "$TMPD"' EXIT INT TERM

# ---------------------------------------------------------------------------
# --selftest : TWO POLES. A detector that only ever passes is not proven to detect anything, and a
# detector that only ever fires is not proven to discriminate. RED pole must be CHARGED; GREEN pole
# (same claim, WITH its inline cite) must be CLEAN. If either pole misbehaves the scanner is broken
# and says so with exit 3 — never a quiet "clean".
# ---------------------------------------------------------------------------
if [ "${SELFTEST:-0}" -eq 1 ]; then
    _fails=0
    printf '%s\n' \
      "The probe returned no record of that row." \
      "Filler line to separate the poles aaa." \
      "Filler line to separate the poles bbb." \
      "Filler line to separate the poles ccc." \
      "Filler line to separate the poles ddd." \
      "The probe returned no record of that row (DISC-ABSENCE-OF-RECORD: receipt, instrument live)." \
      > "$TMPD/self.txt"
    BREACHES=0; BREACH_OUT=""
    # Scope to the class these poles exercise: the selftest must assert the SCANNER, not inherit
    # whatever --class filter the caller passed (else `--class deferral SELFTEST=1` fails here for
    # the wrong reason — a pole failing because it never ran is not a detection failure).
    _save_only0="$ONLY_CLASS"; ONLY_CLASS="absence"
    scan_blob "selftest" "$TMPD/self.txt"
    ONLY_CLASS="$_save_only0"
    # RED pole = line 1 charged; GREEN pole = line 6 not charged  => exactly 1 breach expected
    if [ "$BREACHES" -eq 1 ] && printf '%s' "$BREACH_OUT" | grep -q 'selftest:1'; then
        echo "CREED-SELFTEST: PASS — red pole charged (line 1), green pole clean (line 6), breaches=1"
    else
        echo "CREED-SELFTEST: FAIL — expected exactly 1 breach at line 1, got ${BREACHES}" >&2
        printf '%s' "$BREACH_OUT" >&2
        _fails=1
    fi
    # ---- DEFERRAL class: THREE poles. The third is the whole point. ----
    # Poles are spaced 5 lines apart so one pole's near-window (+/- WINDOW) can never see the next
    # pole's blocker token — otherwise the RED pole would be cleaned by its neighbour and the
    # selftest would pass for the wrong reason.
    printf '%s\n' \
      "This item is deferred to a later pass." \
      "Filler line to separate the poles aaa." \
      "Filler line to separate the poles bbb." \
      "Filler line to separate the poles ccc." \
      "Filler line to separate the poles ddd." \
      "This item is deferred: blocked by the unlanded schema migration." \
      "Filler line to separate the poles eee." \
      "Filler line to separate the poles fff." \
      "Filler line to separate the poles ggg." \
      "Filler line to separate the poles hhh." \
      "This item is deferred, blocked by the auditor sentinel still running." \
      "Filler line to separate the poles iii." \
      "Filler line to separate the poles jjj." \
      "Filler line to separate the poles kkk." \
      "Filler line to separate the poles lll." \
      "This work is driven, not banked." \
      > "$TMPD/self6.txt"
    DEFER_BREACHES=0; DEFER_OUT=""; BREACHES=0; BREACH_OUT=""
    _save_only="$ONLY_CLASS"; ONLY_CLASS="deferral"
    scan_blob "selftest6" "$TMPD/self6.txt"
    ONLY_CLASS="$_save_only"
    # RED   (line 1)  = bare deferral, no blocker           -> MUST be charged
    # GREEN (line 6)  = deferral + a REAL named blocker     -> MUST be clean
    # THIRD (line 11) = deferral + a NAMED-but-FALSE blocker-> MUST be clean BY DESIGN (class ii)
    # ⚠ EACH POLE IS ASSERTED INDIVIDUALLY AND THE LINE NUMBER IS ANCHORED (`:1 |`, not `:1`).
    # An unanchored `grep -q 'selftest6:1'` ALSO MATCHES `selftest6:11` — so if the regexes ever
    # inverted (third pole charged, red pole clean) the count would still be 1 and an unanchored
    # check would PASS FOR THE WRONG REASON, certifying a detector that detects the opposite of
    # what it claims. Asserting each pole by name is what makes the third pole real evidence.
    _p_red=0;   printf '%s' "$DEFER_OUT" | grep -q 'selftest6:1 |'  && _p_red=1
    _p_green=0; printf '%s' "$DEFER_OUT" | grep -q 'selftest6:6 |'  && _p_green=1
    _p_third=0; printf '%s' "$DEFER_OUT" | grep -q 'selftest6:11 |' && _p_third=1
    # FOURTH pole (beyond the ruling's required three): the SEMANTIC-INVERSE negation guard. §3 names
    # "driven not banked" as a phrasing that must NOT charge. Proving it HERE makes the tuning-parity
    # criterion a MECHANISM check; asserting it with a grep for `class_neg_6=` would only prove the
    # variable EXISTS, never that it FIRES — and a guard that exists but never fires is the muted
    # linter this ruling warns about, wearing a passing test's clothes.
    _p_neg=0;   printf '%s' "$DEFER_OUT" | grep -q 'selftest6:16 |' && _p_neg=1
    if [ "$DEFER_BREACHES" -eq 1 ] && [ "$_p_red" -eq 1 ] && [ "$_p_green" -eq 0 ] && [ "$_p_third" -eq 0 ] && [ "$_p_neg" -eq 0 ]; then
        echo "DEFER-SELFTEST: PASS — red pole charged (line 1), green pole clean (line 6), breaches=1"
        echo "DEFER-SELFTEST: THIRD POLE PASS — line 11 names a FALSE blocker (\"auditor sentinel\", refuted"
        echo "    by the governing ruling: an auditor reads a PINNED sha, so a new commit cannot invalidate a running"
        echo "    audit) and is NOT charged. This is CORRECT AND INTENDED: it demonstrates the class-(ii)"
        echo "    blind spot rather than asserting it. A clean deferral scan is NOT #11 enforcement."
    else
        echo "DEFER-SELFTEST: FAIL — expected exactly 1 breach, at line 1 ONLY. Got breaches=${DEFER_BREACHES} red=${_p_red} green=${_p_green} third=${_p_third} neg=${_p_neg} (want 1/1/0/0/0)" >&2
        printf '%s' "$DEFER_OUT" >&2
        _fails=1
    fi
    [ "$_fails" -eq 0 ] || exit 3
    exit 0
fi

# ---- LINE-LEVEL SCAN (classes 1-6) ----
# ⛔ SKIPPED ENTIRELY under `--class govcheck`. CLASS 7 (L3) is a FILE-level pass and shares NOTHING
# with the line engine, so paying for the line scan to reach it is pure waste. This is not a micro-
# optimisation: over a wide historical range the line scan takes MINUTES, and a control that slow is a
# control nobody runs — which would make L3's own positive control the first thing to get skipped.
# `--class govcheck` returns in well under a second, so the failing arm stays cheap enough to actually fire.
# ===========================================================================================================
# --staged / --msg : COMMIT-TIME GATE. Same classes, same patterns (0152 §2a: invent
# nothing) — but judged on the OUTGOING commit, where the fix costs one line, instead of on pushed history,
# where an uncited emission is immutable and can only be owned. Exit 1 on breach.
# SCOPE: ADDED lines only (`git diff --cached -U0`), in the emitting set, + the whole message. History is never
# re-gated. MERGE / CHERRY-PICK / REVERT commits scan the MESSAGE ONLY: their staged content is another seat's
# emission, already gated at its author's commit (else a lane's adopt would be blocked on the hub's prose).
# ===========================================================================================================
# ---------------------------------------------------------------------------------------------------------
# CRITERIA-SRC — criterion provenance.
# A FILE-level pass like GOVCHECK (SET-0031): its OWN counter and label, never pooled with CREED/DEFER/
# GOVCHECK/MINT; it joins only the gate's exit code. Scope: ADDED lines of `_ratification/criteria/*.md`.
# Predicate: every added typed criterion `^\[(test|grep|exists|judgment|absent)\]` is governed by the
# NEAREST PRECEDING `#` line, and that line carries EXACTLY ONE `src:` in one of the three 0293 §3(a) forms:
#   src: _rulings/NNNN §<section>  ·  src: auditor <sha> <F#|O#>  ·  src: foundation <regression|preservation|record-integrity>
# A criterion ADDED under a pre-existing comment with no `src:` is a breach too (the comment governs it).
# Pre-existing, un-edited criteria are never charged (added lines only), so un-backfilled files do not block.
# csrc_scan <label> <artfile> <chargefile> -> appends to CSRC_OUT, bumps CSRC_BREACHES / CSRC_SCANNED.
CSRC_BREACHES=0; CSRC_SCANNED=0; CSRC_OUT=""
csrc_scan() {
    local _lab="$1" _art="$2" _chg="$3" _ln _gn _gt _k
    # Parse EXACTLY as ratify.sh's evaluator does (scripts/ratify.sh conformance-check: strip a leading "- " then
    # leading whitespace, THEN classify), so a bulleted "- [test] ..." criterion is judged, never skipped.
    awk 'NR==FNR { c[$1]=1; next }
         { l = $0; sub(/^- /, "", l); sub(/^[[:space:]]+/, "", l) }
         l ~ /^#/ { g=l; gn=FNR; next }
         l ~ /^\[(test|grep|exists|judgment|absent)\]/ { if (FNR in c) printf "%d\t%d\t%s\n", FNR, gn, g }' \
        "$_chg" "$_art" > "$TMPD/csrc.rows" || { echo "CREED-SCAN: UNREADABLE — criteria-src parse failed on ${_lab} (exit 3)" >&2; exit 3; }
    while IFS=$'\t' read -r _ln _gn _gt; do
        [ -z "$_ln" ] && continue
        CSRC_SCANNED=$((CSRC_SCANNED+1))
        _k="$(printf '%s' "$_gt" | grep -o 'src:' | grep -c .)"
        if [ "${_gn:-0}" -eq 0 ]; then
            CSRC_BREACHES=$((CSRC_BREACHES+1))
            CSRC_OUT="${CSRC_OUT}CRITERIA-SRC-BREACH: ${_lab}:${_ln} | class=criterion-no-src | no governing '#' comment above it
"
        elif [ "$_k" -ne 1 ] || ! printf '%s' "$_gt" | grep -qE 'src: (_rulings/[0-9][0-9][0-9][0-9] §[^[:space:]]+|auditor [0-9a-f]{7,40} [FO][0-9]+|foundation (regression|preservation|record-integrity))'; then
            CSRC_BREACHES=$((CSRC_BREACHES+1))
            CSRC_OUT="${CSRC_OUT}CRITERIA-SRC-BREACH: ${_lab}:${_ln} | class=criterion-no-src | governing comment :${_gn} carries ${_k} 'src:' (need exactly 1 of: _rulings/NNNN §x · auditor <sha> <F#|O#> · foundation <regression|preservation|record-integrity>)
    > $(printf '%s' "$_gt" | cut -c1-110)
"
        fi
    done < "$TMPD/csrc.rows"
}

if [ "$STAGED" -eq 1 ] || [ -n "$MSGFILE" ]; then
    GATE_BREACH=0
    GATE_OUT=""
    _gd="$(git rev-parse --git-dir)"
    CARRIED=0
    for _h in MERGE_HEAD CHERRY_PICK_HEAD REVERT_HEAD; do [ -e "$_gd/$_h" ] && CARRIED=1; done

    # ---- (1) the message (commit-msg $1). Git comment lines are stripped: they are not the emission. ----
    if [ -n "$MSGFILE" ]; then
        [ -r "$MSGFILE" ] || { echo "CREED-GATE: UNREADABLE — message file '$MSGFILE' (exit 3)" >&2; exit 3; }
        grep -v '^#' "$MSGFILE" > "$TMPD/msg.txt"
        scan_blob "msg" "$TMPD/msg.txt"
    fi

    STAGED_FILES=""
    if [ "$STAGED" -eq 1 ] && [ "$CARRIED" -eq 0 ]; then
        STAGED_FILES="$(git diff --cached --name-only --diff-filter=ACM -- \
            '_orchestration/relay-outbox' '_rulings' 'issues_register.md' '_orchestration/decision-log.md')" || {
            echo "CREED-GATE: UNREADABLE — git diff --cached failed (exit 3)" >&2; exit 3; }
    fi

    : > "$TMPD/added_all.txt"
    for f in $STAGED_FILES; do
        git show ":$f" > "$TMPD/art.txt" 2>/dev/null || continue
        git diff --cached -U0 -- "$f" \
          | grep -E '^@@' \
          | sed -E 's/^@@ -[0-9,]+ \+([0-9]+)(,([0-9]+))? @@.*/\1 \3/' \
          | awk '{s=$1; n=($2==""?1:$2); for(i=0;i<n;i++) print s+i;}' \
          | sort -n -u > "$TMPD/charge.txt"
        # Same attribution rule as the boundary scan (SET-0035): in a reaped ruling only the foundation
        # masthead is foundation's emission; the architect's verbatim body was gated at the architect's commit.
        case "$f" in
          _rulings/*.md)
            _mh="$(grep -nx -- '---' "$TMPD/art.txt" 2>/dev/null | head -1 | cut -d: -f1)"
            if [ -n "$_mh" ]; then
                awk -v b="$_mh" '$1 < b' "$TMPD/charge.txt" > "$TMPD/charge.m" 2>/dev/null || : > "$TMPD/charge.m"
                mv "$TMPD/charge.m" "$TMPD/charge.txt"
            fi ;;
          _orchestration/decision-log.md)
            # VERBATIM RELOCATION IS A MOVE, NOT AN EMISSION (same attribution rule as the reaped
            # ruling body above). §2.2 / `0281` item 3 relocate a cut file's whole pre-cut text into
            # the decision-log between `<<<TAG foundation-NNN` / `>>>TAG foundation-NNN` fence lines. Those bytes
            # were already committed; charging them charges the old text as a new emission. EXEMPT ONLY a fenced
            # body that is (a) wholly ADDED in this commit and (b) byte-identical (git-blob hash) to the HEAD blob
            # of a path this SAME commit modifies or deletes, i.e. the file being cut. Any edit to the body, an
            # unterminated fence, or a body matching no file cut in this commit stays fully chargeable.
            # (c) THE TEXT MUST ACTUALLY LEAVE THE SOURCE (auditor 352d6dac F1): --diff-filter=MD
            # admits a mere TOUCH of the source, so copying a file and appending one line to it passed. A fenced line
            # is exempt only if its exact text is ABSENT from the matching source's STAGED blob (empty if deleted);
            # every body line the source still carries stays chargeable. Whole-line set match, so it fails toward
            # charging (a retained blank or heading line is charged too, and carries no trigger).
            git diff --cached --name-only --diff-filter=MD > "$TMPD/reloc.cut" || {
                echo "CREED-GATE: UNREADABLE — git diff --cached failed listing cut files (exit 3)" >&2; exit 3; }
            : > "$TMPD/reloc.hashes"; : > "$TMPD/reloc.map"
            while IFS= read -r _rp; do
                [ -n "$_rp" ] || continue
                _rph="$(git rev-parse -q --verify "HEAD:$_rp" 2>/dev/null)" || continue
                printf '%s\n' "$_rph" >> "$TMPD/reloc.hashes"
                printf '%s\t%s\n' "$_rph" "$_rp" >> "$TMPD/reloc.map"
            done < "$TMPD/reloc.cut"
            awk '/^<<<[A-Z][A-Z0-9-]* foundation-[0-9]+$/ {o=NR; t=substr($0,4); next}
                 o && $0 == (">>>" t) {print o, NR; o=0}' "$TMPD/art.txt" > "$TMPD/reloc.fences"
            : > "$TMPD/reloc.exempt"
            while read -r _ro _rc; do
                [ -n "$_ro" ] || continue
                # (a) every body line must be in the charge set (wholly added now)
                _rn=$(( _rc - _ro - 1 ))
                _rin="$(awk -v a="$_ro" -v b="$_rc" '$1 > a && $1 < b' "$TMPD/charge.txt" | wc -l | tr -d ' ')"
                [ "$_rn" -gt 0 ] && [ "$_rin" -eq "$_rn" ] || continue
                # (b) body hash == HEAD blob of a file cut in this commit
                _rh="$(sed -n "$((_ro + 1)),$((_rc - 1))p" "$TMPD/art.txt" | git hash-object --stdin)" || continue
                grep -qxF -- "$_rh" "$TMPD/reloc.hashes" || continue
                # (c) the staged text of every source with that hash; a body line found there was not moved
                : > "$TMPD/reloc.kept"
                while IFS=$'\t' read -r _mh2 _mp; do
                    [ "$_mh2" = "$_rh" ] || continue
                    if git cat-file -e ":$_mp" 2>/dev/null; then
                        git show ":$_mp" >> "$TMPD/reloc.kept" || {
                            echo "CREED-GATE: UNREADABLE — cannot read the staged blob of cut source '$_mp' (exit 3)" >&2; exit 3; }
                        printf '\n' >> "$TMPD/reloc.kept"
                    fi
                done < "$TMPD/reloc.map"
                # (d) AN EDITED RETENTION IS NOT A MOVE (auditor 586b2e3c F1): (c) compares exact
                # lines, so a source keeping the trigger line with one byte changed passed. Re-run the class
                # predicate on the source's STAGED text: a fenced line stays chargeable if it breaches a class the
                # source still breaches (uncited). A source that is clean, or clean in that class, loses nothing.
                # Globals are saved and restored: these two scans are probes, never charges.
                _sv_b="$BREACHES" _sv_bo="$BREACH_OUT" _sv_d="$DEFER_BREACHES" _sv_do="$DEFER_OUT" _sv_w="$WAIVERS" _sv_wo="$WAIVER_OUT"
                BREACH_OUT="" DEFER_OUT=""
                # The source is judged with the transcription exemption OFF (0300 §3(a) is about authorship; here
                # the question is only whether the text left): a `> "<line>"` retention still breaches (0e4a1a59 F1).
                SCAN_NO_TRANSCRIPTION=1
                scan_blob "reloc-src" "$TMPD/reloc.kept"
                SCAN_NO_TRANSCRIPTION=0
                printf '%s' "$BREACH_OUT" | sed -n 's/^CREED-BREACH: reloc-src:[0-9]* | class=\([^ |]*\).*/\1/p' > "$TMPD/reloc.srccls"
                [ -n "$DEFER_OUT" ] && echo deferral >> "$TMPD/reloc.srccls"
                awk -v a="$_ro" -v b="$_rc" 'BEGIN{for(i=a+1;i<b;i++) print i}' > "$TMPD/reloc.body"
                BREACH_OUT="" DEFER_OUT=""
                scan_blob "reloc-body" "$TMPD/art.txt" "$TMPD/reloc.body"
                { printf '%s' "$BREACH_OUT" | sed -n 's/^CREED-BREACH: reloc-body:\([0-9]*\) | class=\([^ |]*\).*/\1 \2/p'
                  printf '%s' "$DEFER_OUT" | sed -n 's/^DEFER-BREACH: reloc-body:\([0-9]*\) .*/\1 deferral/p'; } > "$TMPD/reloc.bodycls"
                BREACHES="$_sv_b" BREACH_OUT="$_sv_bo" DEFER_BREACHES="$_sv_d" DEFER_OUT="$_sv_do" WAIVERS="$_sv_w" WAIVER_OUT="$_sv_wo"
                awk 'FILENAME == ARGV[1] { s[$1]=1; next } ($2 in s) { print $1 }' "$TMPD/reloc.srccls" "$TMPD/reloc.bodycls" > "$TMPD/reloc.still"
                # (e) A STRUCTURAL PREFIX IS NOT A MOVE (ISSUE-CREED-SCAN-STRUCTURAL-SKIP-2026-09-29 (a),
                # found by the lost ec1a1a6b audit's A12/A13): scan_blob skips `>*` / `|*` lines, so a source that keeps
                # the trigger line as `> <line>` or `|<line>` breaches nothing under (d), and (c)'s exact match missed
                # it. (c) now compares lines with the structural prefix/suffix (`>`, `|`, blanks) stripped on BOTH sides.
                # Line-level on purpose: stripping the whole source before the class-level (d) scan would put every
                # table row in play and could re-charge every fenced line of that class.
                # auditor 0e4a1a59 F1: (d) no longer skips `|` or bare `>` lines, so an
                # EDITED prefixed retention (`> <line>.`, a trigger in any table cell, a quoted `> "<line>"`) is a source
                # breach under (d) too; this exact-match leg stays for the byte-identical shapes.
                awk -v a="$_ro" -v b="$_rc" -v stillf="$TMPD/reloc.still" \
                    'function nz(s) { sub(/^[>| \t]+/, "", s); sub(/[| \t]+$/, "", s); return s }
                     BEGIN { while ((getline x < stillf) > 0) st[x]=1 }
                     FILENAME == ARGV[1] { k[$0]=1; kn[nz($0)]=1; next }
                     FNR > a && FNR < b && !($0 in k) && !(nz($0) in kn) && !(FNR in st) { print FNR }' \
                    "$TMPD/reloc.kept" "$TMPD/art.txt" >> "$TMPD/reloc.exempt"
            done < "$TMPD/reloc.fences"
            if [ -s "$TMPD/reloc.exempt" ]; then
                awk 'NR==FNR{x[$1]=1; next} !($1 in x)' "$TMPD/reloc.exempt" "$TMPD/charge.txt" > "$TMPD/charge.m"
                mv "$TMPD/charge.m" "$TMPD/charge.txt"
            fi ;;
        esac
        [ -s "$TMPD/charge.txt" ] || continue
        scan_blob "$f" "$TMPD/art.txt" "$TMPD/charge.txt"
        awk 'NR==FNR{c[$1]=1; next} (FNR in c)' "$TMPD/charge.txt" "$TMPD/art.txt" >> "$TMPD/added_all.txt"
    done

    # ---- (2) §GOVERNANCE-CHECK, STRUCTURAL (0226 §1.1). Targets: an ADDED ruling file, an ADDED architect
    #      ARCH- ruling in its outbox, an ADDED issue heading in the register. Exempt by FILENAME token only.
    GC_EXEMPT='RESTART-HANDOFF|GOVERNANCE-DELTA|CONSUMPTION|RECEIPT|CONFIRM|-ACK-|_ACK_|SET-MEMBER'
    gc_ref_resolves() {   # <ref> -> 0 if it names something that exists at HEAD or in the index
        local r p ln
        r="$(printf "%s" "$1" | sed -E "s/^[\`*(]+//; s/[\`*),;.:]+\$//")"
        case "$r" in
          _rulings/[0-9][0-9][0-9][0-9]*) ls _rulings/"${r#_rulings/}"* >/dev/null 2>&1 && return 0
                                         git ls-files --cached "_rulings/${r#_rulings/}*" | grep -q . && return 0 ;;
          _orchestration/relay-outbox/*)
                # A lane OUTBOX path is integration-EXCLUDED by design, so it can NEVER exist at spine HEAD — yet it is
                # how an architect relay cites a sibling relay before either is sealed (found by example: one relay
                # cites another by its outbox path; the verbatim body cannot be edited at seal). It resolves ONLY when
                # a ruling at HEAD or in the index names that exact path — i.e. a SEALED ruling's `Source` masthead line.
                # An unsealed outbox ref still fails, so this admits no ref the spine cannot verify.
                # WHOLE-LINE match on `<path>` (the seal masthead's Source line is exactly that): a plain substring match
                # FAILED OPEN — the citing ruling contains the path itself, so every outbox ref self-resolved (caught
                # by the red pole U of probes/set-gate/probe_govcheck_relay_ref.sh before landing).
                p="${r%%:*}"
                # (`git grep` has no -x: take its matching lines with -h and whole-line-compare them with grep -xF.)
                # SELF-CITE EXCLUDED (auditor 47572b87 F1): a citer carrying the path on its OWN line
                # (`<path>` alone) whole-line-matched ITSELF in the --cached search and resolved. The citer's own file
                # is excluded from both searches (GC_CITER, set by the caller), so only ANOTHER ruling can seal it.
                local _gx="_rulings"; [ -n "${GC_CITER:-}" ] && _gx=":(exclude)${GC_CITER}"
                git grep -hF -- "\`${p}\`" HEAD -- _rulings "$_gx" 2>/dev/null | command grep -qxF -- "\`${p}\`" && return 0
                git grep -hF --cached -- "\`${p}\`" -- _rulings "$_gx" 2>/dev/null | command grep -qxF -- "\`${p}\`" && return 0 ;;
          ARCH-[0-9]*|foundation-[0-9]*|architect-[0-9]*)
                git grep -qF -- "$r" HEAD -- _orchestration/decision-log.md _rulings 2>/dev/null && return 0
                git grep -qF --cached -- "$r" -- _orchestration/decision-log.md _rulings 2>/dev/null && return 0 ;;
        esac
        p="${r%%:*}"; ln=""; [ "$p" != "$r" ] && ln="${r#*:}"
        if [ -e "$p" ] || git cat-file -e ":$p" 2>/dev/null; then
            [ -z "$ln" ] && return 0
            ln="${ln%%[-,]*}"
            case "$ln" in *[!0-9]*|'') return 0 ;; esac
            local cnt; cnt="$(git show ":$p" 2>/dev/null | wc -l | tr -d " ")"; [ "${cnt:-0}" -gt 0 ] || cnt="$(wc -l < "$p" 2>/dev/null | tr -d " ")"
            [ "$ln" -le "${cnt:-0}" ] && return 0
            return 1
        fi
        git rev-parse -q --verify "${r}^{commit}" >/dev/null 2>&1 && return 0
        return 1
    }
    gc_check_blob() {   # <label> <file-of-added-content>
        local lab="$1" fb="$2" refs r n
        if ! grep -qE 'GOVERNANCE-CHECK:[^|]*(answered@|silent-or-contradictory)' "$fb"; then
            GATE_BREACH=$((GATE_BREACH+1))
            GATE_OUT="${GATE_OUT}GOVCHECK-GATE: ${lab} | no 'GOVERNANCE-CHECK: <topic> answered@<ref>|silent-or-contradictory' line (0226 §1.1a)
"
            return
        fi
        # Refs are taken ONLY from actual GOVERNANCE-CHECK: lines, and `<placeholder>` refs are skipped. Found by the
        # G3 pole (subagent, 2026-09-22): scanning the whole file for `answered@` charged prose that QUOTES the syntax
        # (`answered@<ref>`) and a ruling's own table of bad pole inputs, so a ruling documenting this gate could
        # never pass it.
        refs="$(grep -E 'GOVERNANCE-CHECK:' "$fb" | grep -oE 'answered@[^[:space:]]+' | sed 's/^answered@//' | grep -v '^[`*(]*<' || true)"
        for r in $refs; do
            gc_ref_resolves "$r" || {
                GATE_BREACH=$((GATE_BREACH+1))
                GATE_OUT="${GATE_OUT}GOVCHECK-GATE: ${lab} | answered@${r} does not resolve at HEAD (0226 §1.1b; forms: _rulings/NNNN · ARCH-/foundation-/architect-NNN · path[:line] · sha)
"; }
        done
        # (c) judgment-class: a silent-or-contradictory read must show what was searched within 3 lines.
        grep -nE 'GOVERNANCE-CHECK:[^|]*silent-or-contradictory' "$fb" | cut -d: -f1 | while read -r n; do
            if ! { sed -n "${n},$((n+3))p" "$fb" | grep -qiE "(searched|read:|read |checked)" && sed -n "${n},$((n+3))p" "$fb" | grep -qE "[A-Za-z0-9_~-]+/[A-Za-z0-9_./-]+|\.(md|sh|tsv|json|py|sql)"; }; then
                sed -n "${n}p" "$fb" | grep -q 'WAIVE:govcheck-evidence' && continue
                echo "GOVCHECK-GATE: ${lab}:${n} | silent-or-contradictory without what-was-searched (0226 §1.1c; WAIVE:govcheck-evidence <8+ words> allowed)"
            fi
        done > "$TMPD/gcc.txt"
        if [ -s "$TMPD/gcc.txt" ]; then
            GATE_BREACH=$((GATE_BREACH + $(grep -c '' "$TMPD/gcc.txt"))); GATE_OUT="${GATE_OUT}$(cat "$TMPD/gcc.txt")
"
        fi
    }
    if [ "$STAGED" -eq 1 ] && [ "$CARRIED" -eq 0 ]; then
        for f in $(git diff --cached --name-only --diff-filter=A -- '_rulings' '_orchestration/relay-outbox/architect'); do
            case "$f" in *.sig) continue ;; esac  # -232 R9 / -234 R3: a relay signature is never judged as a ruling
            case "$f" in _rulings/[0-9][0-9][0-9][0-9]-*.md|_orchestration/relay-outbox/architect/*ARCH-[0-9]*) ;; *) continue ;; esac
            printf '%s' "$f" | grep -qE "$GC_EXEMPT" && continue
            git show ":$f" > "$TMPD/gc.txt" 2>/dev/null || continue
            GC_CITER="$f"; gc_check_blob "$f" "$TMPD/gc.txt"; GC_CITER=""
        done
        # an ADDED issue heading in the register = a raise
        # A heading is a RAISE only if its ISSUE id does not already exist at HEAD. Found LIVE on the first installed
        # fire: editing an existing heading (e.g. marking it CLOSED) shows as an added `+###` line and
        # was charged as a new issue. Closing or annotating an issue is not a raise.
        git diff --cached -U0 -- issues_register.md | grep -E '^\+#{2,4} +ISSUE-' | sed 's/^+//' > "$TMPD/newissues.all"
        : > "$TMPD/newissues.txt"
        while IFS= read -r _hl; do
            _iid="$(printf '%s' "$_hl" | grep -oE 'ISSUE-[A-Za-z0-9_-]+' | head -1)"
            [ -n "$_iid" ] && git show HEAD:issues_register.md 2>/dev/null | grep -qF -- "$_iid" && continue
            printf '%s\n' "$_hl" >> "$TMPD/newissues.txt"
        done < "$TMPD/newissues.all"
        if [ -s "$TMPD/newissues.txt" ]; then
            git diff --cached -U0 -- issues_register.md | grep -E '^\+' | sed 's/^+//' > "$TMPD/regadd.txt"
            gc_check_blob "issues_register.md(new issue: $(head -1 "$TMPD/newissues.txt" | cut -c1-60))" "$TMPD/regadd.txt"
        fi
    fi

    # ---- (2b) MINT-GATE — CLASS 8, FILE-LEVEL (canon §4 :134
    #      WRITTEN-IS-NOT-WIRED). A commit that MINTS a new `disciplines.md §0` roster line (or a new
    #      numbered `inv#n` item in CLAUDE.md "## Binding invariants") with no resolvable wiring plan in
    #      `_index/annotations.tsv` is REJECTED at the earliest write — the seat minting the rule is still
    #      in the loop (DISC-AUTHZ-INPUT-VALIDATED-AT-EARLIEST-WRITE). Reads STAGED blobs only (`git show
    #      :disciplines.md`, `git show :_index/annotations.tsv`), same precedent as the RETIRED-TERMS
    #      guard (`pre-commit-hook.sh:18-23`). Own counter (MINT_BREACHES), own verdict label
    #      (`MINT-GATE:`), NEVER pooled with CREED/DEFER/GOVCHECK counts or output strings — only the
    #      commit's overall exit code is shared (TOTAL, below), exactly as GATE_BREACH already is.
    #      ADDS ONLY (DISC-VIGILANCE-IS-FIELD-LOCAL): an EDIT to an existing entry is never charged, or
    #      the gate fires on every touch and gets muted (creed-scan.sh:128-129, this file's own maxim).
    #      In non-staged (boundary/history) mode this pass does not run — it lives entirely inside the
    #      --staged gate block, same as (2) above.
    MINT_BREACHES=0
    MINT_OUT=""
    if [ "$STAGED" -eq 1 ] && [ "$CARRIED" -eq 0 ]; then
        # mint_extract_ids <roster-line> : id per line, ENTRY-HEAD + parenthetical-companion ids only,
        # never body prose — the exact split gen-governance-index.sh's parse_disc_ids uses, applied to
        # ONE already-located line (reused, not re-derived).
        mint_extract_ids() {
            printf '%s' "$1" | awk '
            {
                line = $0; head = line
                p = index(line, " — ")
                if (p > 0) head = substr(line, 1, p - 1)
                body = (p > 0) ? substr(line, p + 5) : ""
                s = head
                while (match(s, /\*\*(DISC-[A-Z0-9-]+|inv#[0-9]+)\*\*/)) {
                    print substr(s, RSTART + 2, RLENGTH - 4)
                    s = substr(s, RSTART + RLENGTH)
                }
                s = body
                while (match(s, /\(\+ \*\*(DISC-[A-Z0-9-]+)\*\*/)) {
                    print substr(s, RSTART + 5, RLENGTH - 7)
                    s = substr(s, RSTART + RLENGTH)
                }
            }'
        }
        # mint_added_lines <path> : line numbers ADDED to <path> in the outgoing commit — the same
        # hunk-header charge-set parse used throughout this file (e.g. :425-429), not re-derived.
        mint_added_lines() {
            git diff --cached -U0 -- "$1" 2>/dev/null \
              | grep -E '^@@' \
              | sed -E 's/^@@ -[0-9,]+ \+([0-9]+)(,([0-9]+))? @@.*/\1 \3/' \
              | awk '{s=$1; n=($2==""?1:$2); for(i=0;i<n;i++) print s+i;}' \
              | sort -n -u
        }
        # mint_resolves <wiring> <strength> : 0 if the claim resolves. Reuses C1's own arm-D validation
        # rules verbatim (contracts/SPEC-GOVERNANCE-INDEX.md v0.2 §2), not re-derived:
        #   scanner:<class> resolves only against THIS scanner's OWN live class_name_N table (never a
        #     second copy that can go stale the day a class is renamed/retired here);
        #   probe:<path> / gate:<hook|script> resolve on existence at the STAGED TREE ONLY (or an installed
        #     hook literal name) — never the working tree (auditor 104a038c F1); cite-only:<reason> resolves at >= 8 words; UNWIRED never resolves here
        #     (grandfather label — forbidden on a new mint, canon §4 :134).
        mint_resolves() {
            _mr_w="$1"; _mr_s="$2"
            [ -z "$_mr_w" ] && return 1
            [ "$_mr_s" = "UNWIRED" ] && return 1
            case "$_mr_w" in
                scanner:*)
                    _mr_val="${_mr_w#scanner:}"; _mr_i=1; _mr_hit=1
                    while [ "$_mr_i" -le "$class_count" ]; do
                        eval "_mr_cn=\$class_name_${_mr_i}"
                        [ "$_mr_val" = "$_mr_cn" ] && _mr_hit=0
                        _mr_i=$(( _mr_i + 1 ))
                    done
                    return "$_mr_hit" ;;
                probe:*)
                    _mr_val="${_mr_w#probe:}"
                    # ⛔ STAGED TREE ONLY (auditor 104a038c F1): the old `[ -e ]` fallback accepted a
                    # file that exists only in the WORKING TREE — a seat that forgot `git add` on the probe landed a
                    # rule whose only wiring is absent from the commit (the exact WRITTEN-IS-NOT-WIRED case).
                    git cat-file -e ":$_mr_val" 2>/dev/null && return 0
                    return 1 ;;
                gate:*)
                    _mr_val="${_mr_w#gate:}"
                    case "$_mr_val" in pre-commit|pre-merge-commit|commit-msg) return 0 ;; esac
                    # ⛔ STAGED TREE ONLY (auditor 104a038c F1): the old `[ -e ]` fallback accepted a
                    # file that exists only in the WORKING TREE — a seat that forgot `git add` on the probe landed a
                    # rule whose only wiring is absent from the commit (the exact WRITTEN-IS-NOT-WIRED case).
                    git cat-file -e ":$_mr_val" 2>/dev/null && return 0
                    return 1 ;;
                cite-only:*)
                    _mr_val="${_mr_w#cite-only:}"
                    _mr_wc="$(printf '%s' "$_mr_val" | wc -w | tr -d ' ')"
                    [ "${_mr_wc:-0}" -ge 8 ] && return 0
                    return 1 ;;
                *) return 1 ;;
            esac
        }
        : > "$TMPD/mint_ids.txt"
        # ---- source 1: disciplines.md §R registry ADDS (was §0:
        #      the roster body moved verbatim to §R, §0 is a pointer stub, the boot roster is generated) ----
        if git show :disciplines.md > "$TMPD/mint_disc.txt" 2>/dev/null; then
            awk '/^## §R([^0-9A-Za-z]|$)/{inside=1; next} /^## §1([^0-9A-Za-z]|$)/{inside=0} inside && /^- \*\*/{print NR}' \
                "$TMPD/mint_disc.txt" | sort -n -u > "$TMPD/mint_disc_s0.txt"
            mint_added_lines disciplines.md > "$TMPD/mint_disc_added.txt"
            comm -12 "$TMPD/mint_disc_s0.txt" "$TMPD/mint_disc_added.txt" > "$TMPD/mint_disc_hit.txt"
            while IFS= read -r _mln; do
                [ -z "$_mln" ] && continue
                _mhl="$(sed -n "${_mln}p" "$TMPD/mint_disc.txt")"
                mint_extract_ids "$_mhl" >> "$TMPD/mint_ids.txt"
            done < "$TMPD/mint_disc_hit.txt"
        fi
        # ---- source 2: CLAUDE.md "## Binding invariants" numbered-item ADDS ----
        if git show :CLAUDE.md > "$TMPD/mint_claude.txt" 2>/dev/null; then
            awk '/^## Binding invariants/{inside=1; next} /^## /{inside=0} inside && /^[0-9]+\. \*\*/{print NR}' \
                "$TMPD/mint_claude.txt" | sort -n -u > "$TMPD/mint_inv_lines.txt"
            mint_added_lines CLAUDE.md > "$TMPD/mint_claude_added.txt"
            comm -12 "$TMPD/mint_inv_lines.txt" "$TMPD/mint_claude_added.txt" > "$TMPD/mint_inv_hit.txt"
            while IFS= read -r _mln; do
                [ -z "$_mln" ] && continue
                _mhl="$(sed -n "${_mln}p" "$TMPD/mint_claude.txt")"
                _mnum="$(printf '%s' "$_mhl" | sed -E 's/^([0-9]+)\..*/\1/')"
                [ -n "$_mnum" ] && printf 'inv#%s\n' "$_mnum" >> "$TMPD/mint_ids.txt"
            done < "$TMPD/mint_inv_hit.txt"
        fi
        sort -u "$TMPD/mint_ids.txt" -o "$TMPD/mint_ids.txt" 2>/dev/null

        if [ -s "$TMPD/mint_ids.txt" ]; then
            git show :_index/annotations.tsv > "$TMPD/mint_annot.txt" 2>/dev/null || : > "$TMPD/mint_annot.txt"
            _mint_pass_ids=""
            while IFS= read -r _mid; do
                [ -z "$_mid" ] && continue
                # ADDS ONLY: an id whose entry/item already existed at HEAD is an EDIT, never charged.
                case "$_mid" in
                    inv#*)
                        _mnum="${_mid#inv#}"
                        if git show HEAD:CLAUDE.md 2>/dev/null \
                             | awk '/^## Binding invariants/{inside=1; next} /^## /{inside=0} inside' \
                             | grep -qE "^${_mnum}\. \*\*"; then
                            continue
                        fi ;;
                    *)
                        if git show HEAD:disciplines.md 2>/dev/null | grep -qF -- "**${_mid}**"; then
                            continue
                        fi ;;
                esac
                _mrow="$(awk -F'\t' -v id="$_mid" '/^#/{next} NF<8{next} $1==id{print; exit}' "$TMPD/mint_annot.txt")"
                if [ -z "$_mrow" ]; then
                    MINT_BREACHES=$((MINT_BREACHES+1))
                    MINT_OUT="${MINT_OUT}MINT-GATE: REJECT — ${_mid} minted with no wiring plan (canon §4 written-is-not-wired)
    > no _index/annotations.tsv row for ${_mid} in the staged tree
"
                    continue
                fi
                _mwiring="$(printf '%s' "$_mrow" | awk -F'\t' '{print $7}')"
                _mstrength="$(printf '%s' "$_mrow" | awk -F'\t' '{print $8}')"
                if mint_resolves "$_mwiring" "$_mstrength"; then
                    _mint_pass_ids="${_mint_pass_ids}${_mid} "
                else
                    MINT_BREACHES=$((MINT_BREACHES+1))
                    MINT_OUT="${MINT_OUT}MINT-GATE: REJECT — ${_mid} minted with no wiring plan (canon §4 written-is-not-wired)
    > wiring='${_mwiring:-<empty>}' strength='${_mstrength:-<empty>}' does not resolve (C1 arm-D validation)
"
                fi
            done < "$TMPD/mint_ids.txt"
            if [ -n "$_mint_pass_ids" ]; then
                MINT_OUT="${MINT_OUT}MINT-GATE: PASS — $(printf '%s' "$_mint_pass_ids" | wc -w | tr -d ' ') new mint(s) carry a resolvable wiring plan (${_mint_pass_ids})
"
            fi
        fi
    fi

    # ---- (2c) CRITERIA-SRC gate: REJECT an added criterion with no src:. ----
    if [ "$STAGED" -eq 1 ] && [ "$CARRIED" -eq 0 ]; then
        # ACMR, not ACM (auditor 7148a3fc F1): git detects renames by default, so a criteria file renamed in the
        # same commit is status R and ACM never scanned it. For an R row the hunks are taken with BOTH paths in the
        # pathspec (-M), so rename pairing holds and only lines added by the edit are judged, not the whole file.
        git diff --cached --name-status -M --diff-filter=ACMR -- '_ratification/criteria' > "$TMPD/csrc.ns" || {
            echo "CREED-GATE: UNREADABLE — git diff --cached failed on _ratification/criteria (exit 3)" >&2; exit 3; }
        while IFS="$(printf '\t')" read -r _cst _cp1 _cp2; do
            case "$_cst" in R*) _cold="$_cp1"; f="$_cp2" ;; *) _cold=""; f="$_cp1" ;; esac
            case "$f" in *.md) ;; *) continue ;; esac
            git show ":$f" > "$TMPD/csrc.art" 2>/dev/null || { echo "CREED-GATE: UNREADABLE — staged $f (exit 3)" >&2; exit 3; }
            git diff --cached -U0 -M -- ${_cold:+"$_cold"} "$f" > "$TMPD/csrc.diff" || {
                echo "CREED-GATE: UNREADABLE — git diff --cached -U0 failed on $f (exit 3)" >&2; exit 3; }
            grep -E '^@@' "$TMPD/csrc.diff" \
              | sed -E 's/^@@ -[0-9,]+ \+([0-9]+)(,([0-9]+))? @@.*/\1 \3/' \
              | awk '{s=$1; n=($2==""?1:$2); for(i=0;i<n;i++) print s+i;}' \
              | sort -n -u > "$TMPD/csrc.chg"
            [ -s "$TMPD/csrc.chg" ] || continue
            csrc_scan "$f" "$TMPD/csrc.art" "$TMPD/csrc.chg"
        done < "$TMPD/csrc.ns"
        if [ "$CSRC_SCANNED" -gt 0 ] && [ "$CSRC_BREACHES" -eq 0 ]; then
            CSRC_OUT="CRITERIA-SRC-GATE: PASS — ${CSRC_SCANNED} added criterion line(s) carry a governing src:
"
        fi
    fi

    # ---- (2d) CANON-READ-GATE — CLASS 9 (the governance-index canon-read gate; DISC-CANON-IN-DETAIL-
    #      BEFORE-ARCHITECTURE, operator verbatim at disciplines.md:283). An architecture-class artifact
    #      in the staged set — (a) an ADDED `_rulings/NNNN-*.md`, or (b) a staged change to the canon
    #      file / `.claude/agents/*.md` / `contracts/*.md` — without a `CANON-READ:` receipt whose cited
    #      sections ⊇ the RECOMPUTED change-class -> required-section map (never the receipt's own
    #      claimed classes — the anti-cheat) and whose cited sha == the canon blob at HEAD (resolved
    #      ONLY via scripts/canon-core.sh, never hardcoded) is REJECTED. Own counter (CANON_BREACHES),
    #      own labels (`CANON-READ-GATE:` / `CANON-READ-BREACH:`), pooled only into TOTAL below — same
    #      treatment as GATE_BREACH/MINT_BREACHES/CSRC_BREACHES.
    #      ⛔ NOT WAIVABLE (the operator called the underlying rule ABSOLUTE, disciplines.md:283): this
    #      pass never calls is_waived() and never looks for a `WAIVE:` token.
    #      Recompute source: `_index/canon-class-triggers.tsv` (content + path triggers per §5 class) +
    #      `_index/canon-section-map.tsv` (§5 class -> required canon sections). Both STAGED, never the
    #      working tree. An artifact matching NO class needs no receipt (the NON-ARCH case).
    CANON_BREACHES=0
    CANON_OUT=""
    if [ "$STAGED" -eq 1 ] && [ "$CARRIED" -eq 0 ]; then
      CT_FILE="_index/canon-class-triggers.tsv"
      CSM_FILE="_index/canon-section-map.tsv"
      if git cat-file -e ":$CT_FILE" 2>/dev/null && git cat-file -e ":$CSM_FILE" 2>/dev/null; then
        git show ":$CT_FILE" > "$TMPD/ct.tsv" 2>/dev/null
        git show ":$CSM_FILE" > "$TMPD/csm.tsv" 2>/dev/null

        CANON_RESOLVE_OK=1
        CANON_PATH=""
        CANON_SHA=""
        if [ -r "scripts/canon-core.sh" ]; then
            . scripts/canon-core.sh
            CANON_PATH="$(canon_resolve HEAD)" || CANON_RESOLVE_OK=0
        else
            CANON_RESOLVE_OK=0
        fi
        if [ "$CANON_RESOLVE_OK" = 1 ] && [ -n "$CANON_PATH" ]; then
            CANON_SHA="$(git rev-parse "HEAD:$CANON_PATH" 2>/dev/null)"
            [ -n "$CANON_SHA" ] || CANON_RESOLVE_OK=0
        fi
        : > "$TMPD/canon_headings.txt"
        if [ "$CANON_RESOLVE_OK" = 1 ]; then
            git show "HEAD:$CANON_PATH" > "$TMPD/canon.txt" 2>/dev/null
            grep -E '^#+ [0-9]' "$TMPD/canon.txt" \
              | sed -E 's/^#+ ([0-9]+(\.[0-9]+)?).*/§\1/' | sort -u > "$TMPD/canon_headings.txt"
        fi

        # canon_classes_for <path> <content-file> -> matched §5 class names (one per line), the UNION of
        # the path-rule hit (unconditional) and the content-rule hit (grep over <content-file>).
        canon_classes_for() {
            local _p="$1" _cf="$2" _cls _cre _pre
            : > "$TMPD/cls_hit.txt"
            # Content triggers judge PROSE: a token containing `/` is a path (e.g. a seal's own
            # `_orchestration/relay-outbox/…` Source line, where `\brelay\b` matches across the hyphen),
            # so it is removed before the content match. Path rules still read the artifact's path.
            sed -E 's#[^[:space:]`]*/[^[:space:]`]*##g' "$_cf" > "$TMPD/cls_prose.txt" 2>/dev/null || : > "$TMPD/cls_prose.txt"
            _cf="$TMPD/cls_prose.txt"
            while IFS=$'\t' read -r _cls _cre _pre; do
                case "$_cls" in \#*|'') continue ;; esac
                if [ -n "$_pre" ] && printf '%s' "$_p" | grep -qE "$_pre"; then
                    printf '%s\n' "$_cls" >> "$TMPD/cls_hit.txt"; continue
                fi
                if [ -n "$_cre" ] && [ -s "$_cf" ] && grep -qiE "$_cre" "$_cf"; then
                    printf '%s\n' "$_cls" >> "$TMPD/cls_hit.txt"
                fi
            done < "$TMPD/ct.tsv"
            sort -u "$TMPD/cls_hit.txt" 2>/dev/null
        }

        # required_sections_for <classes-file> -> §-tokens (one per line, deduped), union over csm.tsv
        # rows named by <classes-file> (each row's col 2 is a `|`-joined required-section set).
        required_sections_for() {
            local _c
            : > "$TMPD/req_sections.txt"
            while IFS= read -r _c; do
                [ -n "$_c" ] || continue
                awk -F'\t' -v c="$_c" '$1==c{print $2}' "$TMPD/csm.tsv" | tr '|' '\n' >> "$TMPD/req_sections.txt"
            done < "$1"
            sort -u "$TMPD/req_sections.txt" 2>/dev/null
        }

        # canon_receipt_check <blob-file> <required-sections-file> -> "PASS" or "FAIL <reason>" on
        # stdout. Tries EVERY `CANON-READ:` line in <blob-file>; PASSes on the first that satisfies
        # filename + sha(>=8 hex prefix) + every cited section exists as a canon heading + cited ⊇
        # required. WAIVE: is NEVER consulted here (the governing rule is absolute, not judgment-class).
        canon_receipt_check() {
            local _bf="$1" _reqf="$2" _line _best="" _cbase
            if [ "$CANON_RESOLVE_OK" != 1 ]; then printf 'FAIL canon-unresolvable\n'; return; fi
            if ! grep -qE '^CANON-READ:' "$_bf" 2>/dev/null; then printf 'FAIL no-receipt\n'; return; fi
            _cbase="$(basename "$CANON_PATH")"
            while IFS= read -r _line; do
                if ! printf '%s' "$_line" \
                    | grep -qE '^CANON-READ:[[:space:]]+[^@[:space:]]+@[0-9a-f]{8,40}[[:space:]]+sections=§[0-9]'; then
                    _best="malformed-receipt (does not match 'CANON-READ: <file>@<sha,>=8 hex> sections=§a,§b,... verdict=none|§N adds|§N contradicts': '$(printf '%s' "$_line" | cut -c1-120)')"
                    continue
                fi
                local _cf _csha _csecs _miss _badsec _sec
                _cf="$(printf '%s' "$_line" | sed -E 's/^CANON-READ:[[:space:]]+([^@[:space:]]+)@.*/\1/')"
                _csha="$(printf '%s' "$_line" | sed -E 's/^CANON-READ:[^@]+@([0-9a-f]{8,40}).*/\1/')"
                _csecs="$(printf '%s' "$_line" | sed -E 's/^.*sections=([^[:space:]]+).*/\1/' | tr ',' '\n' | sort -u)"
                if [ "$_cf" != "$_cbase" ] && [ "$_cf" != "$CANON_PATH" ]; then
                    _best="wrong-canon-file (cited '${_cf}', current is '${CANON_PATH}' per scripts/canon-core.sh at HEAD)"
                    continue
                fi
                case "$CANON_SHA" in
                    "$_csha"*) ;;
                    *) _best="stale-sha (cited '${_csha}' is not a prefix of the HEAD canon blob '${CANON_SHA}' for ${CANON_PATH})"; continue ;;
                esac
                _badsec=""
                for _sec in $_csecs; do
                    grep -qxF -- "$_sec" "$TMPD/canon_headings.txt" || _badsec="${_badsec}${_sec} "
                done
                if [ -n "$_badsec" ]; then
                    _best="bad-section (cited ${_badsec}not a heading of ${CANON_PATH} at HEAD)"
                    continue
                fi
                _miss="$(comm -23 "$_reqf" <(printf '%s\n' "$_csecs") 2>/dev/null)"
                if [ -n "$_miss" ]; then
                    _best="anti-cheat (cited sections do not cover the RECOMPUTED required set; missing $(printf '%s' "$_miss" | tr '\n' ',' | sed 's/,$//'))"
                    continue
                fi
                # VERDICT (the governing ruling): the block's third half, REQUIRED. Exactly one of
                # `verdict=none` | `verdict=§N adds` | `verdict=§N contradicts` (the ruled verdict words).
                # A block carrying the freshness and coverage halves but no verdict word is REJECTED. A cited §N must
                # be a heading of the canon at HEAD, the same test as the sections half.
                local _vd _vsec
                _vd="$(printf '%s' "$_line" | grep -oE 'verdict=(none|§[0-9]+(\.[0-9]+)?[[:space:]]+(adds|contradicts))([[:space:]]|$)' | head -1)"
                if [ -z "$_vd" ]; then
                    _best="no-verdict (the block needs verdict=none | verdict=§N adds | verdict=§N contradicts)"
                    continue
                fi
                _vsec="$(printf '%s' "$_vd" | sed -nE 's/^verdict=(§[0-9]+(\.[0-9]+)?).*/\1/p')"
                if [ -n "$_vsec" ] && ! grep -qxF -- "$_vsec" "$TMPD/canon_headings.txt"; then
                    _best="bad-verdict-section (verdict cites ${_vsec}, not a heading of ${CANON_PATH} at HEAD)"
                    continue
                fi
                # The governing ruling: an adds/contradicts verdict names a section the author
                # cited as READ (§N ∈ sections=); a verdict about an uncited section is an invention.
                if [ -n "$_vsec" ] && ! printf '%s\n' "$_csecs" | grep -qxF -- "$_vsec"; then
                    _best="canon-read-verdict-uncited (verdict names ${_vsec}, which is not in sections=)"
                    continue
                fi
                printf 'PASS\n'; return
            done < <(grep -E '^CANON-READ:' "$_bf")
            printf 'FAIL %s\n' "${_best:-no-valid-receipt}"
        }

        # ---- artifact class (a): an ADDED `_rulings/NNNN-*.md` — receipt must be IN THE RULING BODY. ----
        for f in $(git diff --cached --name-only --diff-filter=A -- '_rulings'); do
            case "$f" in _rulings/[0-9][0-9][0-9][0-9]-*.md) ;; *) continue ;; esac
            git show ":$f" > "$TMPD/cr_art.txt" 2>/dev/null || continue
            canon_classes_for "$f" "$TMPD/cr_art.txt" > "$TMPD/cr_cls.txt"
            [ -s "$TMPD/cr_cls.txt" ] || continue
            required_sections_for "$TMPD/cr_cls.txt" > "$TMPD/cr_req.txt"
            _res="$(canon_receipt_check "$TMPD/cr_art.txt" "$TMPD/cr_req.txt")"
            if [ "$_res" = "PASS" ]; then
                CANON_OUT="${CANON_OUT}CANON-READ-GATE: PASS — ${f} (classes=$(tr '\n' ',' < "$TMPD/cr_cls.txt" | sed 's/,$//')) carries a valid, class-complete CANON-READ: receipt in its own body
"
            else
                CANON_BREACHES=$((CANON_BREACHES+1))
                CANON_OUT="${CANON_OUT}CANON-READ-BREACH: ${f} | class=${_res#FAIL } | architecture-class (classes=$(tr '\n' ',' < "$TMPD/cr_cls.txt" | sed 's/,$//'); required=$(tr '\n' ',' < "$TMPD/cr_req.txt" | sed 's/,$//')) — receipt must be in the ruling body (canon-read gate; DISC-CANON-IN-DETAIL-BEFORE-ARCHITECTURE)
"
            fi
        done

        # ---- artifact class (b): a staged change to the canon file / .claude/agents/*.md /
        #      contracts/*.md — receipt may be in the commit message OR a ruling added by this SAME
        #      commit (two candidate locations; PASS if either carries a valid, covering receipt). ----
        B_FILES="$(git diff --cached --name-only --diff-filter=ACM -- '.claude/agents' 'contracts')"
        if [ -n "$CANON_PATH" ] \
           && git diff --cached --name-only --diff-filter=ACM -- "$CANON_PATH" 2>/dev/null | grep -qxF -- "$CANON_PATH"; then
            B_FILES="$(printf '%s\n%s\n' "$CANON_PATH" "$B_FILES")"
        fi
        # A canon CUT adds a NEW edition file under a NEW path; $CANON_PATH above is HEAD's (the
        # pre-cut) edition, so an ADDED edition never matches the diff-filter=ACM test on it, and the
        # cut — the only lawful canon change — escaped class (b) entirely
        # (ISSUE-CANON-READ-GATE-BLIND-TO-A-CANON-CUT-NEW-EDITION-FILE-ESCAPES-2026-10-08). Catch the
        # ADD itself: any staged ADDED path matching canon-core.sh's own `$CANON_RE` (never hardcoded).
        # The required receipt is unchanged below — file==$CANON_PATH (basename) and sha==$CANON_SHA —
        # i.e. the EDITION THE CUT AMENDS, never the new file's own name/sha: a receipt citing the new
        # file's name or sha is REJECTED as wrong-canon-file/stale-sha; only a receipt citing the
        # amended HEAD edition PASSes (the architect's two required poles for this cure).
        if [ -n "${CANON_RE:-}" ]; then
            CANON_NEW_EDITIONS="$(git diff --cached --name-only --diff-filter=A 2>/dev/null | grep -E "$CANON_RE")"
            [ -n "$CANON_NEW_EDITIONS" ] && B_FILES="$(printf '%s\n%s\n' "$CANON_NEW_EDITIONS" "$B_FILES")"
        else
            # FAIL-CLOSED (inv #5), mirroring gate-data-unreadable below: without canon-core.sh's CANON_RE a staged
            # canon cut cannot be recognised, so skipping this arm would re-open the escape it closes (pole 21).
            CANON_BREACHES=$((CANON_BREACHES+1))
            CANON_OUT="${CANON_OUT}CANON-READ-BREACH: (gate) | class=canon-core-unreadable | scripts/canon-core.sh did not supply CANON_RE, so a staged canon cut cannot be recognised (canon-read gate; DISC-CANON-IN-DETAIL-BEFORE-ARCHITECTURE)
"
        fi
        B_FILES="$(printf '%s\n' "$B_FILES" | grep -v '^$' | sort -u)"
        if [ -n "$B_FILES" ]; then
            : > "$TMPD/cr_msg.txt"
            [ -n "$MSGFILE" ] && [ -r "$MSGFILE" ] && grep -v '^#' "$MSGFILE" > "$TMPD/cr_msg.txt"
            : > "$TMPD/cr_sibling_rulings.txt"
            for _rf in $(git diff --cached --name-only --diff-filter=A -- '_rulings'); do
                case "$_rf" in
                    _rulings/[0-9][0-9][0-9][0-9]-*.md)
                        git show ":$_rf" >> "$TMPD/cr_sibling_rulings.txt" 2>/dev/null ;;
                esac
            done
            for f in $B_FILES; do
                [ -n "$f" ] || continue
                # bracket-expression anchors, not `\+\+\+`: BOTH BSD grep and this host's `grep` (ugrep)
                # throw "repetition-operator operand invalid" on a bare `^\+\+\+` ERE (auditor's own
                # ugrep-divergence note) — `[+]` has no quantifier reading in any grep flavor.
                git diff --cached -- "$f" | grep -E '^[+]' | grep -v '^[+][+][+]' | sed 's/^+//' > "$TMPD/cr_added.txt"
                canon_classes_for "$f" "$TMPD/cr_added.txt" > "$TMPD/cr_cls.txt"
                [ -s "$TMPD/cr_cls.txt" ] || continue
                required_sections_for "$TMPD/cr_cls.txt" > "$TMPD/cr_req.txt"
                _res_msg="$(canon_receipt_check "$TMPD/cr_msg.txt" "$TMPD/cr_req.txt")"
                _res_sib="$(canon_receipt_check "$TMPD/cr_sibling_rulings.txt" "$TMPD/cr_req.txt")"
                if [ "$_res_msg" = "PASS" ] || [ "$_res_sib" = "PASS" ]; then
                    CANON_OUT="${CANON_OUT}CANON-READ-GATE: PASS — ${f} (classes=$(tr '\n' ',' < "$TMPD/cr_cls.txt" | sed 's/,$//')) carries a valid, class-complete CANON-READ: receipt (message or a sibling ruling)
"
                else
                    CANON_BREACHES=$((CANON_BREACHES+1))
                    _reason="${_res_msg#FAIL }"
                    [ "$_res_msg" = "FAIL no-receipt" ] && [ "$_res_sib" != "FAIL no-receipt" ] && _reason="${_res_sib#FAIL }"
                    CANON_OUT="${CANON_OUT}CANON-READ-BREACH: ${f} | class=${_reason} | architecture-class (classes=$(tr '\n' ',' < "$TMPD/cr_cls.txt" | sed 's/,$//'); required=$(tr '\n' ',' < "$TMPD/cr_req.txt" | sed 's/,$//')) — receipt must be in the commit message or a ruling added by this commit (canon-read gate; DISC-CANON-IN-DETAIL-BEFORE-ARCHITECTURE)
"
                fi
            done
        fi
      else
        # FAIL-CLOSED (inv #5; DISC-CHILD-FAILURE-MUST-SURFACE): the recompute data is absent from the
        # staged index, so the gate cannot judge this commit. Never a silent skip: a commit that drops
        # either file would otherwise switch the gate off for itself and every commit after it.
        CANON_BREACHES=$((CANON_BREACHES+1))
        CANON_OUT="${CANON_OUT}CANON-READ-BREACH: (gate) | class=gate-data-unreadable | ${CT_FILE} and ${CSM_FILE} must both be in the staged index; the gate cannot recompute the change class without them (canon-read gate; DISC-CANON-IN-DETAIL-BEFORE-ARCHITECTURE)
"
      fi
    fi

    # ---- (3) §PREMISE-CHECK at ROUTE-TO-OPERATOR (0226 §1.2b): same patterns as the boundary PARK pass. ----
    [ -n "$MSGFILE" ] && cat "$TMPD/msg.txt" >> "$TMPD/added_all.txt"
    _pk_door='(operator door|operator pen|operator.{0,3}s pen|routing to the operator|needs the operator|awaiting the operator|takes the operator)'
    _pk_negate='(no operator door|none of the operator|no per-set (operator )?pen|no operator pen|without (a |an )?(per-set )?(operator )?pen|door: *none|no door)'
    _pk_what='(spend|cost cap|budget|custody|ratif|irreversible|apex|go/no-go|attest|publish)'
    if grep -qiE "$_pk_door" "$TMPD/added_all.txt" && ! grep -qiE "$_pk_negate" "$TMPD/added_all.txt" \
       && ! grep -qiE 'PREMISE-CHECK[^|]*premise-holds' "$TMPD/added_all.txt" \
       && ! grep -qiE "$_pk_what" "$TMPD/added_all.txt" \
       && ! grep -qE 'WAIVE:manufactured-door[[:space:]]+([^[:space:]]+[[:space:]]+){7}[^[:space:]]+' "$TMPD/added_all.txt"; then
        GATE_BREACH=$((GATE_BREACH+1))
        GATE_OUT="${GATE_OUT}PARK-GATE: operator-routing with NEITHER 'PREMISE-CHECK: … premise-holds@<ref>' NOR a WHAT-class marker (0226 §1.2b; WAIVE:manufactured-door <8+ words> allowed)
    > $(grep -iE "$_pk_door" "$TMPD/added_all.txt" | head -1 | cut -c1-96)
"
    fi

    TOTAL=$(( BREACHES + DEFER_BREACHES + GATE_BREACH + MINT_BREACHES + CANON_BREACHES + CSRC_BREACHES ))
    [ "$WAIVERS" -gt 0 ] && printf '%s' "$WAIVER_OUT"
    # MINT-GATE prints on its OWN label, unconditionally (PASS or REJECT lines, if any mint was found)
    # — same treatment as WAIVER_OUT above: informational, visible on stdout regardless of the eventual
    # exit code, never folded into BREACH_OUT/DEFER_OUT/GATE_OUT.
    [ -n "$MINT_OUT" ] && printf '%s' "$MINT_OUT"
    # CRITERIA-SRC prints on its OWN label, like MINT-GATE (PASS on stdout; breaches with the REJECT below).
    [ "$CSRC_BREACHES" -eq 0 ] && [ -n "$CSRC_OUT" ] && printf '%s' "$CSRC_OUT"
    # CANON-READ-GATE prints on its OWN label, like MINT-GATE/CRITERIA-SRC (PASS on stdout; breaches
    # with the REJECT below). NOT WAIVABLE — see the pass's own header comment.
    [ "$CANON_BREACHES" -eq 0 ] && [ -n "$CANON_OUT" ] && printf '%s' "$CANON_OUT"
    if [ "$TOTAL" -gt 0 ]; then
        { printf '%s' "$BREACH_OUT"; printf '%s' "$DEFER_OUT"; printf '%s' "$GATE_OUT"
          [ "$CSRC_BREACHES" -gt 0 ] && printf '%s' "$CSRC_OUT"
          [ "$CANON_BREACHES" -gt 0 ] && printf '%s' "$CANON_OUT"
          echo "CREED-GATE: REJECT — ${TOTAL} breach(es) in the outgoing commit (lane=${LANE}; carried=${CARRIED}; index=${INDEX_SOURCE})."
          echo "  Fix = add the cite / the GOVERNANCE-CHECK / the PREMISE-CHECK / the MINT-GATE wiring row / the criterion src: /"
          echo "  the CANON-READ: receipt (sections covering every recomputed class, current canon sha) on the flagged line."
          echo "  Judgment-class lines may carry 'WAIVE:<class> <reason of 8+ words>' instead (CANON-READ-GATE is NOT waivable) —"
          echo "  every waiver is surfaced at the next boundary scan. No --no-verify."; } >&2
        exit 1
    fi
    echo "CREED-GATE: PASS (lane=${LANE}; files=$(printf '%s\n' $STAGED_FILES | grep -c .); msg=$([ -n "$MSGFILE" ] && echo yes || echo no); waived=${WAIVERS}; carried=${CARRIED}; index=${INDEX_SOURCE})"
    exit 0
fi

if [ "$ONLY_CLASS" != "govcheck" ] && [ "$ONLY_CLASS" != "park" ] && [ "$ONLY_CLASS" != "criteria-src" ]; then
# ---- (1) commit BODIES ----
for sha in $COMMITS; do
    git log -1 --format='%B' "$sha" > "$TMPD/body.txt" 2>/dev/null
    scan_blob "commit:$(git rev-parse --short "$sha")" "$TMPD/body.txt"
done

# ---- (2) durable artifacts changed in the range (0152 §2b) ----
# relay-outbox deposits, ruling files, register edits.
if [ -n "$SINCE" ]; then
    CHANGED="$(git diff --name-only "${SINCE}..${SCAN_END}" -- \
        '_orchestration/relay-outbox' '_rulings' 'issues_register.md' 2>/dev/null)"
else
    CHANGED="$(git diff --name-only "${DIFF_BASE}..HEAD" -- \
        '_orchestration/relay-outbox' '_rulings' 'issues_register.md' 2>/dev/null)"
fi

for f in $CHANGED; do
    # With --until, charge the bytes AS OF the range end (the line numbers below are
    # parsed from a diff ending at SCAN_END, so reading the working tree would mix two frames).
    if [ -n "$UNTIL" ]; then
        git show "${SCAN_END}:$f" > "$TMPD/art.txt" 2>/dev/null || continue   # absent at end — nothing to charge
    else
        [ -f "$f" ] || continue          # deleted in range — nothing live to charge
        cp "$f" "$TMPD/art.txt" 2>/dev/null || continue
    fi
    # Build the CHARGE SET = line numbers ADDED in this range, parsed from -U0 hunk headers
    # (@@ -a,b +c,d @@ -> charge c..c+d-1). Only these are chargeable; the rest is context.
    if [ -n "$SINCE" ]; then _base="$SINCE"; else _base="$DIFF_BASE"; fi
    git diff -U0 "${_base}..${SCAN_END}" -- "$f" \
      | grep -E '^@@' \
      | sed -E 's/^@@ -[0-9,]+ \+([0-9]+)(,([0-9]+))? @@.*/\1 \3/' \
      | awk '{s=$1; n=($2==""?1:$2); for(i=0;i<n;i++) print s+i;}' \
      | sort -n -u > "$TMPD/charge.txt"
    # ── REAPED RULINGS: CHARGE THE MASTHEAD ONLY ──────────────────────────────────
    # A `_rulings/NNNN-*.md` file is TWO authorships in one blob: a foundation-written masthead, then
    # the ARCHITECT'S VERBATIM SOURCE below the `---` separator. The file says so itself:
    # "EVERYTHING BELOW THE RULE IS THE ARCHITECT'S VERBATIM SOURCE. Foundation added the masthead
    # above and NOTHING else."
    # ⛔ WITHOUT THIS, THE SCANNER CHARGES FOUNDATION FOR THE ARCHITECT'S WORDS — and it did: two real
    # breaches on a reaped ruling at :28 and :44, both inside the architect's body (masthead ends :16).
    # ⭐ THAT IS PRECISELY THE MISATTRIBUTION `CLAUDE.md §Auditor` FORBIDS — "attribute the underlying
    # commits to the ARCHITECT, their git author, never to foundation as the REAPING seat" — so the
    # detector was committing the exact error the contract warns about, one commit after I corrected
    # the contract. A reap is a DELIVERY, not an authorship.
    # The masthead IS foundation's, so it stays chargeable: this narrows attribution, it does not exempt.
    case "$f" in
      _rulings/*.md)
        _mh="$(grep -nx -- '---' "$TMPD/art.txt" 2>/dev/null | head -1 | cut -d: -f1)"
        if [ -n "$_mh" ]; then
            awk -v b="$_mh" '$1 < b' "$TMPD/charge.txt" > "$TMPD/charge.masthead" 2>/dev/null || : > "$TMPD/charge.masthead"
            mv "$TMPD/charge.masthead" "$TMPD/charge.txt"
        fi
        ;;
    esac
    [ -s "$TMPD/charge.txt" ] || continue
    scan_blob "$f" "$TMPD/art.txt" "$TMPD/charge.txt"
done
fi   # end line-level scan (skipped for --class govcheck)

# ---------------------------------------------------------------------------
# CLASS 7 — L3 RULING-WITHOUT-A-CHECK-CITE.
#
# WHY THIS IS A SEPARATE PASS AND NOT A 7TH ROW IN THE CLASS TABLE: the six classes above are
# LINE-level trigger->cite predicates. L3 is a FILE-level property — "this RULING carries no
# GOVERNANCE-CHECK anywhere in it". A line-level scan cannot express an absence over a whole file,
# so forcing it into the table would have produced a detector shaped like the table rather than
# shaped like the rule.
#
# ⛔ SCOPED FORWARD-ONLY, ON PURPOSE, AND THE CORPUS IS WHY. Measured at build time: 40 of 221
# rulings carry a check-cite (18%) — but 13 of the 20 MOST RECENT do (65%). The practice is recent
# and improving. A detector that charged every ruling lacking one would fire on 181 historical
# files on its first run. This file's own class-table comment is the governing principle: "a linter
# that cries on every sentence gets muted, and a muted linter is worse than none." So this charges
# ONLY rulings ADDED IN THE SCAN RANGE (--diff-filter=A). History is left alone deliberately; that
# is a stated scope limit, NOT a claim that the 181 are clean.
#
# EXEMPT FORMS — NAMED, VISIBLE AND AUDITABLE rather than hidden in a regex. CLAUDE.md
# §GOVERNANCE-CHECK's TRIGGER is CONDITIONAL: it fires on (a) raising an issue / routing a
# problem-or-blocker, or (b) reopening/re-deriving/re-litigating a settled decision. A RESTART
# HANDOFF or a GOVERNANCE DELTA does neither — it hands off or reports. Charging those would be
# charging a form for not doing something its form never does. Verified against the corpus: 0215
# and 0219 are both RESTART-HANDOFFs carrying no cite, and both are legitimately exempt.
GOVCHECK_EXEMPT_FORMS='RESTART-HANDOFF|GOVERNANCE-DELTA'
GOVCHECK_BREACHES=0
GOVCHECK_SCANNED=0
GOVCHECK_OUT=""

if [ -n "$SINCE" ]; then _gcbase="$SINCE"; else _gcbase="$DIFF_BASE"; fi
ADDED_RULINGS="$(git diff --diff-filter=A --name-only "${_gcbase}..${SCAN_END}" -- '_rulings' 2>/dev/null \
                 | grep -E '^_rulings/[0-9]{4}-.*\.md$' || true)"

for rf in $ADDED_RULINGS; do
    if [ -n "$UNTIL" ]; then
        # Judge the ruling AS OF the range end, not the working tree.
        git show "${SCAN_END}:$rf" > "$TMPD/gc_rf.txt" 2>/dev/null || continue
        _rf_read="$TMPD/gc_rf.txt"
    else
        [ -f "$rf" ] || continue
        _rf_read="$rf"
    fi
    # Exempt by FORM, matched on the filename slug (the form determination lives there by convention).
    if printf '%s' "$rf" | grep -qE "$GOVCHECK_EXEMPT_FORMS"; then continue; fi
    GOVCHECK_SCANNED=$((GOVCHECK_SCANNED+1))
    if ! grep -q 'GOVERNANCE-CHECK' "$_rf_read" 2>/dev/null; then
        GOVCHECK_BREACHES=$((GOVCHECK_BREACHES+1))
        GOVCHECK_OUT="${GOVCHECK_OUT}GOVCHECK-BREACH: ${rf}:1 | class=ruling-no-check-cite | missing-cite=GOVERNANCE-CHECK
    > a ruling was emitted with NO GOVERNANCE-CHECK line (RULE A: no raise without a citation)
"
    fi
done

# Printed on its OWN counter and its OWN label — never pooled with CREED/DEFER. Pooling would let a
# clean creed scan dilute a governance breach into one reassuring total (the same reason the two
# existing verdicts are kept apart).
if [ "$ONLY_CLASS" = "" ] || [ "$ONLY_CLASS" = "govcheck" ]; then
    if [ "$GOVCHECK_SCANNED" -eq 0 ]; then
        # ⛔ NOT a clean scan — there was NOTHING TO SCAN. Reporting "all clean" here would be a
        # receipt for work that never happened (DISC-ABSENCE-OF-RECORD applied to my own detector:
        # an absence is evidence only when the recorder had something to record).
        echo "GOVCHECK-CHECK: no rulings added in ${RANGE_LABEL} — nothing to check (this is NOT a clean-scan receipt)"
    elif [ "$GOVCHECK_BREACHES" -eq 0 ]; then
        echo "GOVCHECK-CHECK: all ${GOVCHECK_SCANNED} ruling(s) added in ${RANGE_LABEL} carry a GOVERNANCE-CHECK cite (lane=${LANE})"
    else
        printf '%s' "$GOVCHECK_OUT"
        echo "GOVCHECK-CHECK: ${GOVCHECK_BREACHES} of ${GOVCHECK_SCANNED} ruling(s) added in ${RANGE_LABEL} carry NO GOVERNANCE-CHECK cite (lane=${LANE}) — LINTER, disposition by a human; not a block."
        echo "    ⚠ SCOPE: charges only rulings ADDED in range; forms {${GOVCHECK_EXEMPT_FORMS}} are exempt by construction."
        echo "      This line is NOT a statement that older rulings carry cites — 181 of 221 did not at build time."
    fi
fi

# ---------------------------------------------------------------------------
# MANUFACTURED-DOOR DETECTOR — the semantic twin of the uncited-emission
# scan, and the ENFORCEMENT half of CLAUDE.md §PREMISE-CHECK.
#
# WHY EMISSION-LEVEL AND NOT A 7TH ROW IN THE LINE TABLE (same reasoning as the L3 pass above, and it is
# not a convenience): the requirement is DOCUMENT-SCOPED — "does this emission carry a PREMISE-CHECK
# ANYWHERE in it?" A `PREMISE-CHECK: … premise-holds` line legitimately sits far from the sentence that
# routes the door, so a near-window line predicate would charge correct emissions. Keeping it here also
# leaves class_count=6 true, so SET-0031's pin on that number stays honest rather than being quietly
# invalidated by a later build.
#
# WHAT IT CATCHES, IN ONE SENTENCE: a confident "THE ONLY OPERATOR DOOR: X" with NOTHING behind it —
# neither a premise re-derivation nor a genuine WHAT-class reason. That exact shape was carried to the
# operator TWICE in one session for a door that did not exist, and the cure would
# have WIDENED an authorization enforcer to solve a non-problem.
#
# ⛔ LINTER, NOT A PROOF GATE (the shape the operator set): false positives are ACCEPTABLE; a
# human dispositions them. It must never block an emission.
PARK_BREACHES=0; PARK_SCANNED=0; PARK_OUT=""
# TRIGGER — routing/asserting an operator decision. Deliberately narrow: a linter that cries on every
# mention of the operator gets muted, and a muted linter is worse than none.
# ⚠ DERIVED FROM THE MOTIVATING CORPUS, NOT FROM IMAGINATION — AND MY FIRST DRAFT FAILED THAT TEST.
# The first version listed plausible phrasings and reported "no manufactured doors" over a range containing
# BOTH commits that motivated it (d54a6237, 82de2e69): they say "which means operator pen" and "standing
# operator door:", neither of which my invented list matched, and it was case-sensitive besides.
# ⇒ A DETECTOR THAT CANNOT SEE ITS OWN MOTIVATING INSTANCES IS A FALSE ABSENCE WEARING A RECEIPT. Trigger
# is now matched case-INSENSITIVELY (park_scan_doc uses -i) against language taken from the real bodies.
_park_door='(operator door|operator pen|operator.{0,3}s pen|P4 AUTHORIZATION MODEL|routing to the operator|needs the operator|awaiting the operator|takes the operator)'
# DISCHARGE (a) — the premise was actually re-derived at pickup.
# `.*`, never `[^\n]*`: grep is already line-based (each line fed to it carries no embedded real
# newline), so `[^\n]*` was never needed for that — and in a POSIX ERE bracket `\n` is read as two
# literal characters (backslash, n), so `[^\n]*` excluded the LETTER n (and, under -i, N) from the
# match. Any PREMISE-CHECK item name containing an n (nearly all of them) never discharged: 9 of 9
# PARK-BREACH lines at the 2026-10-08 boot were false positives on commits that carried the premise
# line (ISSUE-PARK-LINTER-DISCHARGE-BRACKET-NEWLINE-EXCLUDES-LETTER-N-2026-10-08).
_park_ok='PREMISE-CHECK.*premise-holds'
# DISCHARGE (b) — a GENUINE WHAT-class reason, i.e. something only he can give (DISC-ONE-DECISION-DOOR).
# WHAT-class markers. `publish` is BARE on purpose: a post going live is irreversible and operator-attended
# (CONSTANTS:111), so a publish/defer emission routing to his pen is a GENUINE door, not a manufactured one.
# ⚠ TUNED ONCE, AND THE BITE WAS RE-VERIFIED AFTER TUNING — the two real manufactured doors (82de2e69,
# d54a6237) contain NO publish/spend/custody language, so widening here cannot discharge them. Verified by
# re-running the positive control, not by reasoning about it.
_park_what='(spend|cost cap|budget|custody|ratif|irreversible|apex|go/no-go|attestation|publish)'
# NEGATION GUARD — "NO operator door" is the DECLINING of a door, the exact opposite of manufacturing one.
# Without this the detector fires on every clean close-out that correctly reports an empty door.
# NEGATION GUARD — the DECLINING of a door is the exact opposite of manufacturing one, and these phrasings
# are frequent in clean close-outs ("no operator pen on any of them"). Without this the detector would fire
# hardest on the commits that are behaving correctly — the surest way to get a linter muted.
_park_negate='(no operator door|none of the operator|no per-set (operator )?pen|no operator pen|without (a |an )?(per-set )?(operator )?pen|NO PER-SET PEN|door: *none|nothing is owed by the operator|never owed|was never owed|no pen (was |is )?(owed|required)|standing class)'

park_scan_doc() {   # park_scan_doc <label> <file>
    local label="$1" f="$2"
    grep -qiE "$_park_door" "$f" 2>/dev/null || return 0
    grep -qiE "$_park_negate" "$f" 2>/dev/null && return 0
    PARK_SCANNED=$((PARK_SCANNED+1))
    grep -qiE "$_park_ok" "$f" 2>/dev/null && return 0
    grep -qiE "$_park_what" "$f" 2>/dev/null && return 0
    PARK_BREACHES=$((PARK_BREACHES+1))
    local ln; ln="$(grep -niE "$_park_door" "$f" 2>/dev/null | head -1 | cut -d: -f1)"
    PARK_OUT="${PARK_OUT}PARK-BREACH: ${label}:${ln:-1} | manufactured-operator-door | no PREMISE-CHECK + no WHAT-class marker
    > $(grep -iE "$_park_door" "$f" 2>/dev/null | head -1 | cut -c1-96)
"
}

if [ "$ONLY_CLASS" = "" ] || [ "$ONLY_CLASS" = "park" ]; then
    for sha in $COMMITS; do
        git log -1 --format='%B' "$sha" > "$TMPD/pbody.txt" 2>/dev/null
        park_scan_doc "commit:$(git rev-parse --short "$sha")" "$TMPD/pbody.txt"
    done
    if [ "$PARK_SCANNED" -eq 0 ]; then
        # NOT a clean scan — nothing TRIGGERED. Saying "no manufactured doors" here would be a receipt
        # for work that never happened (DISC-ABSENCE-OF-RECORD, turned on my own detector).
        echo "PARK-CHECK: no operator-door routing in ${RANGE_LABEL} — nothing to check (this is NOT a clean-scan receipt)"
    elif [ "$PARK_BREACHES" -eq 0 ]; then
        echo "PARK-CHECK: no manufactured doors in ${RANGE_LABEL} (${PARK_SCANNED} door-routing emission(s) scanned, all discharged)"
    else
        printf '%s' "$PARK_OUT"
        echo "PARK-CHECK: ${PARK_BREACHES} of ${PARK_SCANNED} door-routing emission(s) in ${RANGE_LABEL} carry NEITHER a PREMISE-CHECK premise-holds NOR a WHAT-class marker (lane=${LANE}) — LINTER, disposition by a human; not a block."
        echo "    ⚠ A door with nothing behind it is the shape that was carried to the operator twice for a non-problem."
    fi
fi

# ---- output ----
# The two verdicts are printed SEPARATELY and are never pooled into one number: they answer
# different questions, and merging them would let a clean deferral scan dilute a creed breach
# (or vice versa) into a single reassuring total.
# ⛔ Both verdicts below are SUPPRESSED under `--class govcheck`: the line scan did not run, and
# "0 breaches" from a scan that never happened is a FALSE RECEIPT — exactly the class this file exists
# to catch (DISC-ABSENCE-OF-RECORD: an absence is evidence only when the recorder actually ran).
if [ "$ONLY_CLASS" != "govcheck" ] && [ "$ONLY_CLASS" != "park" ] && [ "$ONLY_CLASS" != "deferral" ] && [ "$ONLY_CLASS" != "criteria-src" ]; then
    if [ "$BREACHES" -eq 0 ]; then
        # POSITIVE RECEIPT (0152 §2e): prove the recorder is LIVE rather than merely silent.
        echo "CREED-CHECK: no uncited emissions in ${RANGE_LABEL} (lane=${LANE}, ${N_COMMITS} commits scanned)"
    else
        printf '%s' "$BREACH_OUT"
        echo "CREED-CHECK: ${BREACHES} uncited emission(s) in ${RANGE_LABEL} (lane=${LANE}, ${N_COMMITS} commits scanned) — LINTER, disposition by a human; not a block."
    fi
fi

# ---- #11 deferral verdict — BOUND OUTPUT CONTRACT ----
# ⛔ The wording below is load-bearing, not cosmetic. It states ONLY what was checked (class i) and
# ALWAYS carries the out-of-scope note, so this line can never be read as "#11 is enforced". Do not
# "tidy" it into "#11 satisfied" / "no never-idle breach" — that is the exact false floor the ruling
# forbids, and it would make the scanner's silence mean something it cannot support.
if [ -z "$ONLY_CLASS" ] || [ "$ONLY_CLASS" = "deferral" ]; then
    if [ "$DEFER_BREACHES" -eq 0 ]; then
        echo "DEFER-CHECK: no unnamed deferral in ${RANGE_LABEL} (lane=${LANE}, ${N_COMMITS} commits scanned)"
    else
        printf '%s' "$DEFER_OUT"
        echo "DEFER-CHECK: ${DEFER_BREACHES} deferral(s) with no named blocker in ${RANGE_LABEL} (lane=${LANE}, ${N_COMMITS} commits scanned) — LINTER, disposition by a human; not a block."
    fi
    echo "    ⚠ SCOPE: class (i) BARE DEFERRAL only. A deferral that NAMES a blocker which is FALSE (class ii)"
    echo "      is OUT OF SCOPE BY CONSTRUCTION — un-mechanizable, enforced by persona +"
    echo "      auditor + operator. This line is NOT a statement that CLAUDE.md #11 is satisfied."
fi

# ---- CRITERIA-SRC boundary report ("boundary-scan mode reports it"). ----
# Same predicate as the gate, over criteria lines ADDED in the range. A LINTER here, never a block.
if [ -z "$ONLY_CLASS" ] || [ "$ONLY_CLASS" = "criteria-src" ]; then
    if [ -n "$SINCE" ]; then _cb="$SINCE"; else _cb="$DIFF_BASE"; fi
    # ACMR + both paths for an R row (auditor 7148a3fc F1), and a git failure is UNREADABLE exit 3 exactly as
    # the staged gate is (7148a3fc O1) — a boundary report that swallows a failed read prints a false "nothing".
    git diff --name-status -M --diff-filter=ACMR "${_cb}..${SCAN_END}" -- '_ratification/criteria' > "$TMPD/csrc.ns" || {
        echo "CREED-SCAN: UNREADABLE — git diff failed on _ratification/criteria over ${_cb}..${SCAN_END} (exit 3)" >&2; exit 3; }
    while IFS="$(printf '\t')" read -r _cst _cp1 _cp2; do
        case "$_cst" in R*) _cold="$_cp1"; f="$_cp2" ;; *) _cold=""; f="$_cp1" ;; esac
        case "$f" in *.md) ;; *) continue ;; esac
        git show "${SCAN_END}:$f" > "$TMPD/csrc.art" 2>/dev/null || {
            echo "CREED-SCAN: UNREADABLE — git show ${SCAN_END}:$f failed (exit 3)" >&2; exit 3; }
        git diff -U0 -M "${_cb}..${SCAN_END}" -- ${_cold:+"$_cold"} "$f" > "$TMPD/csrc.diff" || {
            echo "CREED-SCAN: UNREADABLE — git diff -U0 failed on $f over ${_cb}..${SCAN_END} (exit 3)" >&2; exit 3; }
        grep -E '^@@' "$TMPD/csrc.diff" \
          | sed -E 's/^@@ -[0-9,]+ \+([0-9]+)(,([0-9]+))? @@.*/\1 \3/' \
          | awk '{s=$1; n=($2==""?1:$2); for(i=0;i<n;i++) print s+i;}' \
          | sort -n -u > "$TMPD/csrc.chg"
        [ -s "$TMPD/csrc.chg" ] || continue
        csrc_scan "$f" "$TMPD/csrc.art" "$TMPD/csrc.chg"
    done < "$TMPD/csrc.ns"
    if [ "$CSRC_SCANNED" -eq 0 ]; then
        echo "CRITERIA-SRC-CHECK: no criterion lines added in ${RANGE_LABEL} — nothing to check (this is NOT a clean-scan receipt)"
    elif [ "$CSRC_BREACHES" -eq 0 ]; then
        echo "CRITERIA-SRC-CHECK: all ${CSRC_SCANNED} criterion line(s) added in ${RANGE_LABEL} carry a governing src: (lane=${LANE})"
    else
        printf '%s' "$CSRC_OUT"
        echo "CRITERIA-SRC-CHECK: ${CSRC_BREACHES} of ${CSRC_SCANNED} criterion line(s) added in ${RANGE_LABEL} carry NO valid governing src: (lane=${LANE}) — LINTER at the boundary; the commit gate REJECTs these."
    fi
fi

# Every recorded WAIVE: that passed the commit gate is surfaced here, at the boundary, so the
# human disposition 0152 requires still happens. A seat that waives by reflex shows up as this count.
if [ "$WAIVERS" -gt 0 ]; then
    printf '%s' "$WAIVER_OUT"
    echo "WAIVER-CHECK: ${WAIVERS} recorded waiver(s) in ${RANGE_LABEL} (lane=${LANE}) — each needs a human disposition."
fi

[ "$STAMP" -eq 1 ] && git rev-parse HEAD > "$MARKER_FILE"

exit 0
