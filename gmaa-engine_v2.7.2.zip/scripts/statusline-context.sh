#!/bin/bash
# scripts/statusline-context.sh — Claude Code statusLine command (field 5, and `null` tokens never 0).
# Reads the statusline JSON on stdin and writes ONE line, atomically, to <worktree>/.claude/context-pct:
#     <session_id> <total_input_tokens|null> <pct|null> <utc> <window|null>
# Keyed by session: the Stop hook ignores a line whose session_id is not its own (0315 §2(a)), so a relaunched
# seat never reads the dead session's reading. `null` pct/tokens = no reading yet (docs: "may be null early in
# the session"), never 0 — 0 is a real reading, not an absence (0330 §6). Field 5 (window) is appended so the
# existing `read -r SID TOK PCT _` readers are unchanged. Field names verified live at
# code.claude.com/docs/en/statusline: session_id, context_window.used_percentage,
# context_window.total_input_tokens, context_window.context_window_size.
# Prints the bar. Never fails the status line: any error prints a bare marker and exits 0.
set -u
IN="$(cat)"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
OUT="$ROOT/.claude/context-pct"

LINE="$(printf '%s' "$IN" | jq -r '
  [ (.session_id // "-"),
    (if .context_window.total_input_tokens == null then "null" else (.context_window.total_input_tokens | floor | tostring) end),
    (if .context_window.used_percentage == null then "null" else (.context_window.used_percentage | floor | tostring) end)
  ] | join(" ")' 2>/dev/null)"
if [ -z "$LINE" ]; then
  printf 'ctx ?\n'
  exit 0
fi
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
WINDOW="$(printf '%s' "$IN" | jq -r 'if .context_window.context_window_size == null then "null" else (.context_window.context_window_size | floor | tostring) end' 2>/dev/null)"
[ -z "$WINDOW" ] && WINDOW="null"
mkdir -p "$ROOT/.claude" 2>/dev/null
TMP="$OUT.$$"
printf '%s %s %s\n' "$LINE" "$UTC" "$WINDOW" > "$TMP" 2>/dev/null && mv -f "$TMP" "$OUT" 2>/dev/null

set -- $LINE
TOK="$2"; PCT="$3"
MODEL="$(printf '%s' "$IN" | jq -r '.model.display_name // ""' 2>/dev/null)"
case "$TOK" in ''|null|*[!0-9]*) TOKK="?" ;; *) TOKK="$((TOK / 1000))" ;; esac
printf '%sctx %s%% · %sk tok\n' "${MODEL:+[$MODEL] }" "$PCT" "$TOKK"
exit 0
