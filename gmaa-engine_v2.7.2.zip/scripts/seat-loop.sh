#!/bin/bash
# scripts/seat-loop.sh --session <name> [--auto-mode] — the relaunch loop the seat's tmux session runs (PROPOSAL
# §2.4). launch-orc.sh types `exec bash scripts/seat-loop.sh --session <name>`, so the tmux
# session ends when this loop ends. DEFAULT IS STOP: only a FRESH `restart` intent relaunches.
#   - RE-RESOLVED LAUNCH LINE (LAUNCH-CONTRACT): before EVERY launch the loop sources the worktree's
#     launch-orc.sh and calls its resolver (launch_lane_resolve + launch_line_resolve; one resolver, not a copy),
#     so a stamp edited after the loop started (remote_control, model tier, boot prompt) reaches the next relaunch.
#     The loop never receives, stores or replays a launch line. Each relaunch logs
#     `SEAT-LOOP: launch-line re-resolved changed=<yes|no>`. A resolution that fails, or a lane that differs from
#     the one this session started as, HALTs loud (`SEAT-LOOP-HALT: ... re-resolution`) and does NOT launch
#     (inv #5; never a fall-back to an earlier line).
#   - --session is the tmux session's own name (fixed for the session's life; the Remote Control name). --auto-mode
#     carries the launcher's opt-in mode option. Any other argument is refused (the frozen-argv form is retired).
#   - a stale intent left from before this run is cleared (and logged) before each launch;
#   - after the command exits, the intent is read and REMOVED (consumed once, P5);
#   - fresh = written at or after this run started (epoch field >= run start);
#   - `restart` -> relaunch in the same session (same qualified name, P12);
#     `shutdown`, no intent, or a stale one (crash, Ctrl-C, hand-typed /exit) -> end the loop and the session;
#   - RUNAWAY CAP (0315 §2(e)): a 4th restart within 1800 s stops the loop with
#     `SEAT-LOOP-HALT: <lane> 3 restarts in 30 min` in the pane and .claude/seat-loop.log, then waits for Enter
#     so the line stays visible (halt-loud, inv #5). Numbers: CAP=3, WINDOW_S=1800 (foundation may move them,
#     and must print them).
set -u
usage() { echo "usage: scripts/seat-loop.sh --session <name> [--auto-mode]" >&2; exit 2; }
SESSION=""; MODE_FLAG=""
while [ $# -gt 0 ]; do
  case "$1" in
    --session)   [ $# -ge 2 ] && [ -n "$2" ] || usage; SESSION="$2"; shift 2 ;;
    --auto-mode) MODE_FLAG="--permission-mode auto"; shift ;;
    *) echo "HALT(seat-loop): unknown argument '$1'. The loop takes no launch line; it re-resolves it from the stamp." >&2; usage ;;
  esac
done
[ -n "$SESSION" ] || usage
CAP=3
WINDOW_S=1800
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
D="$ROOT/.claude"; mkdir -p "$D"
LOG="$D/seat-loop.log"
LANE="$(sed -nE 's/^lane:[[:space:]]*([A-Za-z0-9_-]+).*/\1/p' "$ROOT/_boot/BOOTSTRAP.md" 2>/dev/null | head -1)"
LANE="${LANE:-unknown}"
note() { printf '%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" | tee -a "$LOG"; }
halt_resolve() {
  note "SEAT-LOOP-HALT: $LANE launch-line re-resolution failed: $1. Not launching (no fall-back to an earlier line)."
  echo "Press Enter to close this session."
  read -r _ || true
  exit 4
}

FIRST_LANE=""; PREV_LINE=""
RESTARTS=""   # space-separated epochs of accepted restarts
while :; do
  if [ -f "$D/seat-intent" ]; then
    note "SEAT-LOOP: cleared stale intent before launch: $(cat "$D/seat-intent")"
    rm -f "$D/seat-intent"
  fi
  # --- the one resolver, re-read from disk each launch ---
  [ -f "$ROOT/launch-orc.sh" ] || halt_resolve "no launch-orc.sh at $ROOT"
  # shellcheck source=/dev/null
  unset -f launch_lane_resolve launch_line_resolve 2>/dev/null
  . "$ROOT/launch-orc.sh" || halt_resolve "sourcing launch-orc.sh failed (rc=$?)"
  declare -F launch_line_resolve >/dev/null && declare -F launch_lane_resolve >/dev/null \
    || halt_resolve "launch-orc.sh defines no launch_lane_resolve/launch_line_resolve"
  launch_lane_resolve "$ROOT" || halt_resolve "lane: ${LL_ERR:-no reason given}"
  [ -z "$FIRST_LANE" ] && FIRST_LANE="$LL_LANE"
  [ "$LL_LANE" = "$FIRST_LANE" ] || halt_resolve "lane changed from '$FIRST_LANE' to '$LL_LANE' inside session '$SESSION'"
  LANE="$LL_LANE"
  launch_line_resolve "$ROOT" "$LANE" "$SESSION" "$MODE_FLAG" || halt_resolve "line: ${LL_ERR:-no reason given}"
  if [ -n "$PREV_LINE" ]; then
    note "SEAT-LOOP: launch-line re-resolved changed=$([ "$LL_LINE" = "$PREV_LINE" ] && echo no || echo yes) lane=$LANE"
  fi
  PREV_LINE="$LL_LINE"
  START="$(date +%s)"
  note "SEAT-LOOP: launch lane=$LANE cmd=$LL_LINE"
  "${LL_ARGV[@]}"
  RC=$?
  KIND=""; I_EPOCH=0
  if [ -f "$D/seat-intent" ]; then
    read -r KIND _ _ I_EPOCH _ < "$D/seat-intent" || true
    rm -f "$D/seat-intent"
  fi
  case "${I_EPOCH:-0}" in ''|*[!0-9]*) I_EPOCH=0 ;; esac
  if [ "$KIND" != "restart" ] || [ "$I_EPOCH" -lt "$START" ]; then
    note "SEAT-LOOP: end lane=$LANE rc=$RC intent=${KIND:-none}$([ -n "$KIND" ] && [ "$I_EPOCH" -lt "$START" ] && echo ' (stale)') -> stop (default)"
    exit 0
  fi
  NOW="$(date +%s)"
  KEPT=""; N=0
  for t in $RESTARTS; do
    if [ $((NOW - t)) -lt "$WINDOW_S" ]; then KEPT="$KEPT $t"; N=$((N + 1)); fi
  done
  if [ "$N" -ge "$CAP" ]; then
    note "SEAT-LOOP-HALT: $LANE $CAP restarts in $((WINDOW_S / 60)) min (cap=$CAP window=${WINDOW_S}s; restarts at:$KEPT; this would be #$((N + 1))). Not relaunching."
    echo "Press Enter to close this session."
    read -r _ || true
    exit 3
  fi
  RESTARTS="$KEPT $NOW"
  note "SEAT-LOOP: restart #$((N + 1)) in window (cap=$CAP window=${WINDOW_S}s) lane=$LANE"
done
