#!/usr/bin/env bash
# scripts/auditor-usage-record.sh — the E6b usage RECORDER (CLAUDE.md #9: LLM usage in a
#   mechanism is persisted durably, never sampled). Called by agents/post-commit-hook.sh after each auditor run.
# USAGE: auditor-usage-record.sh <run-json-file> <commit-sha> <lane> <wall-seconds> <auditor-rc>
#   <run-json-file> = stdout of `claude -p … --output-format json` (one result object).
# WRITES: one JSON row appended to ledger/auditor-usage.jsonl, and the run's `result` text appended to
#   ledger/audit-runs.log, each line tagged `LLM-AUDITOR-RESULT <sha8>: ` (the log stays human-readable).
#   The row carries `verdict` PRESENT|ABSENT|UNREADABLE; anything but PRESENT also logs `LLM-AUDIT-NO-VERDICT:`.
#   Each run also logs `LLM-AUDITOR-MODEL <sha8>: <model_usage keys, each with its outputTokens>` (or `: ABSENT` when the run
#   is UNREADABLE or carries no modelUsage; never a default), written just BEFORE the tagged result lines so the
#   log's existing tail grammar is unchanged (the model line is part of the receipt).
# NEVER FAILS THE HOOK (exit 0 always). NEVER ZERO-FILLS: output that does not parse is recorded as
#   "status":"UNREADABLE" with a reason, and every usage field is ABSENT, not 0 (DISC-ABSENCE-OF-RECORD: a
#   missing reading is not a zero reading).
# FRAME: total_cost_usd / costUSD are the LIST-PRICE figures claude -p reports. The auditor runs keyless on the
#   operator's Max plan, so they measure quota consumption, not money billed.
set -u
RUNJSON="${1:-}"; SHA="${2:-}"; LANE="${3:-}"; WALL="${4:-}"; RC="${5:-}"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
LEDGER="$ROOT/ledger/auditor-usage.jsonl"; LOG="$ROOT/ledger/audit-runs.log"
python3 - "$RUNJSON" "$SHA" "$LANE" "$WALL" "$RC" "$LEDGER" "$LOG" <<'PY' || true
import json, sys, datetime, re
runjson, sha, lane, wall, rc, ledger, log = sys.argv[1:8]
row = {"ts_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
       "sha": sha, "lane": lane, "auditor_rc": rc,
       "wall_s": float(wall) if wall.replace(".", "", 1).isdigit() else None,
       "cost_frame": "list-price USD as reported by claude -p; keyless Max plan = quota, not billed"}
def model_line(mu):
    # DISC-ABSENCE-OF-RECORD: no modelUsage reading is ABSENT, never a default model.
    if isinstance(mu, dict) and mu:
        parts = [f"{k}({v['outputTokens'] if isinstance(v, dict) and 'outputTokens' in v else 'ABSENT'})" for k, v in mu.items()]
        return f"LLM-AUDITOR-MODEL {sha[:8]}: " + ",".join(parts) + "\n"
    return f"LLM-AUDITOR-MODEL {sha[:8]}: ABSENT\n"
try:
    raw = open(runjson, encoding="utf-8", errors="replace").read()
except OSError as e:
    raw = None; row.update(status="UNREADABLE", reason=f"run output unreadable: {e}")
    try:
        with open(log, "a", encoding="utf-8") as f: f.write(model_line(None))
    except OSError: pass
if raw is not None:
    try:
        d = json.loads(raw)
        if not isinstance(d, dict) or "usage" not in d:
            raise ValueError("no usage object in the result")
        row.update(status="RECORDED", is_error=d.get("is_error"), subtype=d.get("subtype"),
                   duration_ms=d.get("duration_ms"), num_turns=d.get("num_turns"),
                   total_cost_usd=d.get("total_cost_usd"), usage=d.get("usage"),
                   model_usage=d.get("modelUsage"), session_id=d.get("session_id"))
        with open(log, "a", encoding="utf-8") as f: f.write(model_line(d.get("modelUsage")))
        res = d.get("result")
        if isinstance(res, str):
            # TAGGED (auditor 586b2e3c O1): the result is the run's last chat message, not a run record.
            # Each line carries the tag so the log's line grammar stays parseable and the message is attributable.
            with open(log, "a", encoding="utf-8") as f:
                for ln in res.rstrip("\n").split("\n"):
                    f.write(f"LLM-AUDITOR-RESULT {sha[:8]}: {ln}\n")
    except (ValueError, json.JSONDecodeError) as e:
        row.update(status="UNREADABLE", reason=f"run output is not a claude -p json result: {str(e)[:120]}")
        with open(log, "a", encoding="utf-8") as f:   # keep whatever the run printed, verbatim after the tag
            f.write(model_line(None))
            # TAGGED too (auditor 9d77bbbd O2): the unparseable branch kept the log's grammar broken.
            for ln in raw.rstrip("\n").split("\n"):
                f.write(f"LLM-AUDITOR-RAW {sha[:8]}: {ln}\n")
# VERDICT CHECK (ISSUE-LLM-AUDITOR-VERDICTLESS-EXIT-2026-09-29). A headless run that ends its turn
# while work runs in the background exits rc 0 with NO verdict; `status` cannot see that (it describes the usage
# reading, and probe_efficiency_budget.sh counts RECORDED rows' cost, so it is left alone). A verdict exists iff
# ledger/audit-findings.md has a level-2 `## ` heading that names the sha and is not a code-audit heading
# (validated: 2 of 56 rows flagged, exactly the two known losses; level-2 only since
# that fix). ABSENT is logged LOUD.
# The whole check is guarded: it may never cost the usage row below (the row is the recorder's first duty).
findings = ledger.rsplit("/", 1)[0] + "/audit-findings.md"
try:
    if len(sha) >= 7:
        try:
            # LEVEL-2 ONLY (auditor 9d77bbbd O1(b)): a `### O1 — <sha> …` finding heading inside
            # ANOTHER commit's block also named the sha (334 such `###` lines measured). Every verdict block
            # opens with a `## ` heading: 57 of 57 rows read PRESENT under this rule.
            heads = [l for l in open(findings, encoding="utf-8", errors="replace")
                     if re.match(r"## ", l) and not re.match(r"## Code audit", l)]
            row["verdict"] = "PRESENT" if any(sha[:7] in h for h in heads) else "ABSENT"
        except OSError as e:
            row["verdict"] = "UNREADABLE"; row["verdict_reason"] = f"audit-findings.md unreadable: {e}"
    else:
        row["verdict"] = "UNREADABLE"; row["verdict_reason"] = "no commit sha given"
    if row["verdict"] != "PRESENT":
        with open(log, "a", encoding="utf-8") as f:
            f.write(f"LLM-AUDIT-NO-VERDICT: {sha[:8]} lane={lane} rc={rc} wall_s={wall} verdict={row['verdict']} -- no LLM "
                    f"audit heading names this sha in ledger/audit-findings.md; a ...-CATCHUP audit is owed "
                    f"(agents/auditor-contract.md sec 5)\n")
except Exception as e:
    row["verdict"] = "UNREADABLE"; row["verdict_reason"] = f"verdict check failed: {str(e)[:120]}"
with open(ledger, "a", encoding="utf-8") as f:
    f.write(json.dumps(row, separators=(",", ":")) + "\n")
PY
exit 0
