#!/bin/bash
# scripts/subagent-commit-deny.sh — PreToolUse hook on Bash: a subagent never commits or pushes (canon 1.3).
# Keyed on `agent_id` ONLY (live hooks page: agent_id = "the subagent or in-process teammate the hook fires in";
# agent_type is ALSO present in the main seat under `claude --agent orc`, so it is never the discriminator).
#   - no agent_id                         -> exit 0, no output (the hub is never touched)
#   - agent_id + a `git commit|push|commit-tree` segment (also `git -C x commit`, leading env assignments,
#     &&/;/|-chained segments, env/command/sudo/exec prefixes, git aliases resolving to commit|push; and, after
#     quote and backslash stripping, "git" / \git, shell keywords and braces (if/then/do/{ }), and the
#     nice/timeout/ionice/stdbuf/caffeinate class of wrappers with their own arguments; relay 1586a: a wrapper named
#     by path (/usr/bin/nice, /usr/bin/env) is matched by its basename, a $'..' or $".." quote drops its $ with the
#     quotes, and a wrapper argument that is itself the word git (sudo -u git git commit) re-enters the git parse)
#                                         -> permissionDecision "deny" with the fixed named reason
#   - agent_id + a nested shell (-c / eval / xargs / $( / backtick) whose text names git + commit|push -> deny
#   - agent_id, jq missing or stdin unparseable: fail CLOSED when the raw stdin still shows a non-empty agent_id
#     (deny); when it does not, the call is not provably a subagent -> allow (exit 0). Zero model calls.
set -u
IN="$(cat)"
REASON="SUBAGENT-COMMIT-DENY: a subagent cannot commit or push (canon 1.3). Leave the change in the working tree and report it; the hub commits."
deny() {
  if command -v jq >/dev/null 2>&1; then
    jq -n --arg r "$REASON" '{hookSpecificOutput: {hookEventName: "PreToolUse", permissionDecision: "deny", permissionDecisionReason: $r}}'
  else
    printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"%s"}}\n' "$REASON"
  fi
  exit 0
}
AID=""; CMD=""; PARSED=0
if command -v jq >/dev/null 2>&1 && printf '%s' "$IN" | jq -e . >/dev/null 2>&1; then
  PARSED=1
  AID="$(printf '%s' "$IN" | jq -r '.agent_id // empty' 2>/dev/null)"
  CMD="$(printf '%s' "$IN" | jq -r '.tool_input.command // empty' 2>/dev/null)"
else
  # cannot parse: tell subagent-ness from the raw text only
  printf '%s' "$IN" | grep -Eq '"agent_id"[[:space:]]*:[[:space:]]*"[^"]' && deny
  exit 0
fi
[ -n "$AID" ] || exit 0
[ -n "$CMD" ] || exit 0
BAD='^(commit|push|commit-tree)$'
# nested-shell / substitution forms: be conservative on the raw text
if printf '%s' "$CMD" | grep -Eq '(^|[[:space:];&|(])(eval|xargs)([[:space:]]|$)|(^|[[:space:];&|(])(ba|z|da|k)?sh[[:space:]]+(-[A-Za-z]*c|-c)|\$\(|`'; then
  printf '%s' "$CMD" | grep -Eq '(^|[^[:alnum:]_-])git([^[:alnum:]_-].*)?[^[:alnum:]_-](commit|push|commit-tree)([^[:alnum:]_-]|$)' && deny
fi
SEGS="$(printf '%s\n' "$CMD" | tr '\n;&|()' '\n\n\n\n\n\n')"
while IFS= read -r seg; do
  # shellcheck disable=SC2206
  set -f; toks=($seg); set +f
  # strip quotes and backslashes from every token, so "git", 'git', $'git' and \git read as git (an ANSI-C or locale
  # quote's $ goes with its quote, relay 1586a)
  for j in "${!toks[@]}"; do t="${toks[$j]}"; t="${t//\$\'/\'}"; t="${t//\$\"/\"}"; t="${t//\"/}"; t="${t//\'/}"; t="${t//\\/}"; toks[$j]="$t"; done
  i=0; n=${#toks[@]}; W=0
  # skip leading shell keywords, env assignments, options and wrapper words. After a wrapper, up to 4 of its own
  # arguments (a duration, a niceness, a signal, a user) are skipped too, so `timeout 5 git` and `nice -n 10 git` reach git.
  while [ $i -lt $n ]; do
    t="${toks[$i]}"
    case "$t" in
      if|then|elif|else|do|while|until|'!'|'{'|'}'|time|'') i=$((i+1)) ;;
      [A-Za-z_]*=*|-*) i=$((i+1)) ;;
      *) # a wrapper word is matched by its basename, so /usr/bin/nice and /usr/bin/env are wrappers too (relay 1586a)
         case "${t##*/}" in
           env|command|sudo|doas|exec|nohup|builtin|nice|timeout|gtimeout|ionice|stdbuf|caffeinate|chrt|taskset|unbuffer) i=$((i+1)); W=4 ;;
           *) if [ $W -gt 0 ] && [ "$(basename "$t")" != git ]; then i=$((i+1)); W=$((W-1)); else break; fi ;;
         esac ;;
    esac
  done
  [ $i -lt $n ] || continue
  [ "$(basename "${toks[$i]}")" = "git" ] || continue
  # parse git's global options, then read the subcommand. If the "subcommand" is itself the word git, the first git was
  # a wrapper's argument (sudo -u git git commit, relay 1586a), so the parse re-enters at the second one.
  while :; do
    i=$((i+1))
    # skip git global options; -C/-c/--git-dir/--work-tree/--namespace take a separate value
    while [ $i -lt $n ]; do
      t="${toks[$i]}"
      case "$t" in
        -C|--git-dir|--work-tree|--namespace|--exec-path|--super-prefix) i=$((i+2)) ;;
        -c) v="${toks[$((i+1))]:-}"; case "$v" in alias.*) deny ;; esac; i=$((i+2)) ;;
        -c*) case "$t" in -calias.*) deny ;; esac; i=$((i+1)) ;;
        -*) i=$((i+1)) ;;
        *) break ;;
      esac
    done
    [ $i -lt $n ] && [ "$(basename "${toks[$i]}")" = git ] && continue
    break
  done
  if [ $i -ge $n ]; then continue; fi
  sub="${toks[$i]}"; sub="${sub//[\"\']/}"
  printf '%s' "$sub" | grep -Eq "$BAD" && deny
  # alias resolving to commit|push
  al="$(git config --get "alias.$sub" 2>/dev/null)" || al=""
  [ -n "$al" ] && printf '%s' "$al" | grep -Eq '(^|[^[:alnum:]_-])(commit|push|commit-tree)([^[:alnum:]_-]|$)' && deny
done <<EOF
$SEGS
EOF
exit 0
