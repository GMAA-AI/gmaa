#!/usr/bin/env bash
# gen-governance-index.sh — derive _index/governance.tsv from the tri-corpus (AC-1)
#
# CONTRACT: contracts/SPEC-GOVERNANCE-INDEX.md §1 (architect-authored).
# CUSTODY:  architect authors the spec; foundation builds this mechanism.
#
# SOURCES OF EXISTENCE (derived; these remain the SOLE source of WHAT EXISTS):
#   disciplines.md §0 DISC-INDEX        -> corpus=discipline
#   CLAUDE.md "Binding invariants"      -> corpus=invariant   (inv#1..N)
#   contracts/*.md                      -> corpus=contract    (file-level census; see SCOPE below)
#   _index/canon-section-map.tsv        -> corpus=canon       (CANON §n rows, keyed by change-class)
# SOURCE OF METADATA (curated):
#   _index/annotations.tsv              -> classes/triggers/check/blood/ship, keyed by id
#
# DRIFT IS FAIL-CLOSED IN BOTH DIRECTIONS (AC-1), OVER THE SET AC-1 ACTUALLY NAMES:
#   AC-1 reads "fails-closed on any disciplines.md §0 entry OR NAMED CONTRACT CLAUSE with no row" —
#   §0 entries and named clauses, NOT every contract FILE. So the two sets are kept distinct, because
#   collapsing them would either (a) block every commit on day one over ~100 uncurated file rows,
#   contradicting the ratified "A+B first, zero gate friction" sequence, or (b) silently drop the
#   fail-closed guard on the rules that actually fire at draft time.
#     CORE (fail-closed, exit 2):  corpus=discipline · corpus=invariant · curated `C-NAME §n` clause rows
#       - a §0 entry / invariant with no annotation row      -> UNANNOTATED-CORE drift
#       - an annotation row matching no corpus id at all     -> ORPHAN drift (a retired rule still indexed)
#       - a clause row whose PARENT contract file is gone    -> ORPHAN drift
#       - committed .tsv != freshly derived                  -> STALE drift
#     CENSUS (warn-only, exit 0):  corpus=contract file rows · corpus=canon section rows
#       - reported with denominators every run so under-curation is VISIBLE, never silent.
#   A curated clause row is ADDITIVE: it emits its own index row alongside its parent file row, and it
#   is NOT an orphan — SPEC §1's id grammar (`C-<NAME> §n`) sanctions exactly this.
#
# SCOPE LIMIT, STATED IN THE ARTIFACT (canon §13 / AC-6 — never represent detection as complete):
#   The contract census is FILE-level. Clause-level (`C-NAME §n`) rows are CURATED-ADDITIVE in
#   annotations.tsv, NOT a complete enumeration of every clause in every contract. This file says so,
#   the generated header says so, and no output claims otherwise.
#
# VERBS (the dispatcher — DISC-INVOCATION-CITES-THE-DISPATCHER; read this case block, not a prior receipt):
#   (none) | build   regenerate _index/governance.tsv in place
#   check            regenerate to a temp file and DIFF against the committed one; drift => exit 2
#   census           print the coverage census with denominators and the known-value control
#   self-test        run the parser against a synthetic fixture with a known answer (instrument control)
set -uo pipefail

REPO_ROOT="$(git rev-parse --show-toplevel)" || { echo "FATAL: not in a git repo" >&2; exit 3; }
cd "$REPO_ROOT" || exit 3

DISC_MD="disciplines.md"
CLAUDE_MD="CLAUDE.md"
CONTRACTS_DIR="contracts"
ANNOT="_index/annotations.tsv"
LAYERS="_index/layers.tsv"   # per-row layer sidecar, architect-curated
CANON_MAP="_index/canon-section-map.tsv"
# ENGINE_INV: the engine's invariant carrier. Each `## inv#N — <name>` heading in it is an invariant row
#   located at that file. The generator learns a carrier from the carrier itself and takes NO input from
#   the packaging join (the ship list is never a corpus source). Optional: a tree without it derives the
#   invariant corpus from CLAUDE.md alone.
ENGINE_INV=".claude/rules/engine/invariants.md"
OUT="_index/governance.tsv"
# MECHANISM ROWS (0247 §7 step 2, as amended by 0252 §7 + 0253 §5): index rows that are NOT a
#   single contract file / §0 entry / invariant / canon section — CANON (the one law document), MECH-WRITE,
#   MECH-AUDIT (agents/auditor-contract.md — the corpus gap 0247 §3 named), SPEND, READINESS. Each row carries its
#   own layer/disposition/target + the ruling it transcribes. An id may live in layers.tsv OR here, never both.
MECHS="_index/mechanisms.tsv"
# CANON_DOC via the ONE shared resolver, at the tree of the INDEX, so a commit that cuts a new
#   edition is indexed against the edition it commits. Was hardcoded `v1_6_1` (three editions stale).
source "$REPO_ROOT/scripts/canon-core.sh" || { echo "HALT: cannot source scripts/canon-core.sh" >&2; exit 3; }
CANON_DOC="$(canon_resolve "$(git write-tree 2>/dev/null)")" || { echo "HALT: no canon edition resolves at the index tree (canon-core.sh)" >&2; exit 3; }

die() { echo "HALT: $*" >&2; exit 3; }
for f in "$DISC_MD" "$CLAUDE_MD" "$ANNOT" "$CANON_MAP" "$MECHS"; do
    [[ -f "$f" ]] || die "required source missing: $f (halt-loud, no silent degradation — inv #5)"
done
[[ -d "$CONTRACTS_DIR" ]] || die "required source missing: $CONTRACTS_DIR/"

# ---------------------------------------------------------------------------
# extract_disc_section <file> : print the raw §R registry lines of a disciplines file
#   The roster body moved VERBATIM from §0 to §R; §0 is a
#   pointer stub and is NOT a source any more. The same window feeds scripts/gen-boot-roster.sh (via the
#   `disc-ids` verb below), so the index's discipline corpus and the boot roster share ONE parser.
# ---------------------------------------------------------------------------
extract_disc_section() {
    # Anchors are terminated ON PURPOSE: a bare /^## §R/ also matches "## §Rx" and a bare
    # /^## §1/ also matches a future "## §10", either of which silently changes the roster window.
    awk '/^## §R([^0-9A-Za-z]|$)/{inside=1; next} /^## §1([^0-9A-Za-z]|$)/{inside=0} inside && /^- \*\*/{print}' "$1"
}

# ---------------------------------------------------------------------------
# parse_disc_ids <file> : id<TAB>body  (one line per ID, so a 2-id roster line yields 2 rows)
#   A roster line may carry more than one id:
#     - co-equal pair:  **A** / **B** — ...
#     - parenthetical companion: ... (+ **B** — ...)
#   Retrieval is BY ID, so the index row count is the ID count, not the LINE count.
#   Ids are taken from the ENTRY HEAD only (before the first em-dash), never from the body prose —
#   body mentions are edges (interacts_with), not new entries.
# ---------------------------------------------------------------------------
parse_disc_ids() {
    extract_disc_section "$1" | awk '
    {
        line = $0
        head = line
        # entry head = everything before the first em-dash separator
        p = index(line, " — ")
        if (p > 0) head = substr(line, 1, p - 1)
        body = (p > 0) ? substr(line, p + 5) : ""
        # companion ids introduced inside the body as "(+ **DISC-X**" are real roster members
        n = 0
        s = head
        while (match(s, /\*\*(DISC-[A-Z0-9-]+|inv#[0-9]+)\*\*/)) {
            tok = substr(s, RSTART + 2, RLENGTH - 4)
            ids[++n] = tok
            s = substr(s, RSTART + RLENGTH)
        }
        s = body
        while (match(s, /\(\+ \*\*(DISC-[A-Z0-9-]+)\*\*/)) {
            tok = substr(s, RSTART + 5, RLENGTH - 7)
            ids[++n] = tok
            s = substr(s, RSTART + RLENGTH)
        }
        for (i = 1; i <= n; i++) printf "%s\t%s\n", ids[i], line
        n = 0; delete ids
    }'
}

# ---------------------------------------------------------------------------
# disc_edges <id> <body> : |-joined other DISC- ids mentioned in this entry (the declared-edge graph,
#   auto-extracted from the disciplines' own "Pairs with / Corollary of / GUARDS / Companion" prose —
#   SPEC §1 interacts_with. Auto-extraction keeps the graph current without hand maintenance.)
# ---------------------------------------------------------------------------
disc_edges() {
    local self="$1" body="$2"
    printf '%s' "$body" \
      | grep -o 'DISC-[A-Z0-9-]*' \
      | grep -v "^${self}\$" \
      | sort -u | paste -sd'|' - 2>/dev/null
}

# ---------------------------------------------------------------------------
# annotation lookup: id -> classes/triggers/check/blood/ship/wiring/strength (skips # comments and blanks)
#   wiring/strength ADDED v0.2 — annotations.tsv now carries 8
#   columns (id + 7 metadata); NF<8 replaces the prior NF<6 gate, both directions.
# ---------------------------------------------------------------------------
# ⚠ SEPARATOR IS \x1f (ASCII US), NOT \t — DELIBERATE, DO NOT "SIMPLIFY" BACK TO TAB.
#   bash `read` treats TAB as IFS-WHITESPACE, so consecutive tabs collapse into ONE delimiter and an
#   EMPTY field silently vanishes, shifting every later field left. The rows with an empty `triggers`
#   field are exactly the UNIVERSAL (classes='*') rows — the boot-creed core present in EVERY
#   shortlist — so the corruption lands on the most load-bearing rows and is invisible in the .tsv
#   itself (which is well-formed; only the bash read is wrong). \x1f is non-whitespace, so empty
#   fields are preserved. Caught by running the retriever on a real draft and reading the output.
annot_lookup() {
    awk -F'\t' -v want="$1" '
        /^#/ {next} NF<8 {next}
        $1==want { printf "%s\037%s\037%s\037%s\037%s\037%s\037%s\n", $2, $3, $4, $5, $6, $7, $8; found=1; exit }
        END { if(!found) exit 1 }
    ' "$ANNOT"
}

# layer_lookup: id -> S|W-generic|W-project from _index/layers.tsv. A SEPARATE sidecar, not an
#   annotations.tsv column: uncurated index rows have no annotation row, and every row must carry a layer.
#   Missing id => empty field; arm E of the governance-index probe FAILS a row with no/invalid layer.
layer_lookup() {   # prints "layer\037disposition\037target"; empty fields when the id is absent
    # layers.tsv first; then mechanisms.tsv (cols 4-6). mech_collisions() HALTs the build if an id is in both.
    local r=""
    [[ -r "$LAYERS" ]] && r="$(awk -F'\t' -v want="$1" '/^#/{next} NF<2{next} $1==want{printf "%s\037%s\037%s\n",$2,$3,$4; exit}' "$LAYERS")"
    [[ -z "$r" ]] && r="$(awk -F'\t' -v want="$1" '/^#/{next} NF<6{next} $1==want{printf "%s\037%s\037%s\n",$4,$5,$6; exit}' "$MECHS")"
    [[ -n "$r" ]] && printf '%s\n' "$r" || printf '\037\037\n'
}

annot_ids() { awk -F'\t' '/^#/{next} NF<8{next} {print $1}' "$ANNOT" | sort -u; }

# ---------------------------------------------------------------------------
# corpus_ids : every id that EXISTS, with its corpus and locate pointer
#   emits: id<TAB>corpus<TAB>locate<TAB>body
# ---------------------------------------------------------------------------
corpus_ids() {
    # --- disciplines -------------------------------------------------------
    parse_disc_ids "$DISC_MD" | while IFS=$'\t' read -r id body; do
        [[ -z "$id" ]] && continue
        printf '%s\tdiscipline\t%s#%s\t%s\n' "$id" "$DISC_MD" "$id" "$body"
    done

    # --- invariants: union of the engine carrier and CLAUDE.md "Binding invariants" ----------------
    #   (i) every `## inv#N — <name>` heading in $ENGINE_INV is a row located at that file;
    #   (ii) every item of CLAUDE.md `## Binding invariants` (`N. **...`) is a row; an id carried by both
    #   is located at the engine carrier and keeps its body from the CLAUDE.md line, an id only in
    #   CLAUDE.md locates at CLAUDE.md#binding-invariants, an id only in the engine carrier takes its
    #   heading line as body. Nothing but the heading and the `N. **` items is read.
    awk -F'\t' -v eng="$ENGINE_INV" '
        BEGIN {
            while ((getline line < eng) > 0)
                if (match(line, /^## inv#[0-9]+( |$)/)) {
                    id = substr(line, 4); sub(/[ ].*/, "", id)
                    if (!(id in inEng)) { inEng[id] = line; eord[++en] = id }
                }
            close(eng)
        }
        /^## Binding invariants/ {inside=1; next}
        /^## / {inside=0}
        inside && /^[0-9]+\. \*\*/ {
            n = $0; sub(/\..*/, "", n)
            id = "inv#" n
            seen[id] = 1
            loc = (id in inEng) ? eng : "CLAUDE.md#binding-invariants"
            printf "%s\tinvariant\t%s\t%s\n", id, loc, $0
        }
        END {
            for (i = 1; i <= en; i++) if (!(eord[i] in seen))
                printf "%s\tinvariant\t%s\t%s\n", eord[i], eng, inEng[eord[i]]
        }
    ' "$CLAUDE_MD"

    # --- contracts (FILE-level census; clause rows are curated-additive) ----
    #   A contract file whose basename IS a mechanisms.tsv id is that mechanism's spec (0247 §7 step 4 re-points the
    #   mechanism row's locate at it) — the mechanism row owns the id, so the file is NOT emitted a second time.
    local mech_ids; mech_ids="$(awk -F'\t' '/^#/{next} NF<7{next}{print $1}' "$MECHS" 2>/dev/null)"
    find "$CONTRACTS_DIR" -maxdepth 1 -name '*.md' -type f -print0 2>/dev/null \
      | while IFS= read -r -d '' cf; do
            base="$(basename "$cf" .md)"
            printf '%s\n' "$mech_ids" | grep -qxF -- "$base" && continue
            printf '%s\tcontract\t%s\t%s\n' "$base" "$cf" "contract file $base"
        done

    # --- canon sections (from the change-class map; deduped) ----------------
    awk -F'\t' '/^#/{next} NF<2{next} {
        split($2, secs, "|")
        for (i in secs) if (secs[i] != "") print secs[i] "\t" $1
    }' "$CANON_MAP" | sort -u | awk -F'\t' '{ cls[$1] = ($1 in cls) ? cls[$1] "|" $2 : $2 }
        END { for (s in cls) printf "CANON %s\tcanon\t'"$CANON_DOC"'#%s\tcanon section %s required for: %s\n", s, s, s, cls[s] }'

    # --- curated CLAUSE rows (additive over the file-level census; SPEC §1 id grammar `C-NAME §n`) ---
    #     A clause row is legitimate ONLY if its parent contract file exists. If the parent is gone the
    #     row is a genuine orphan and must fail closed — that is the drift this half is for.
    annot_ids | grep ' §' | while IFS= read -r cid; do
        parent="${cid%% §*}"
        if [[ -f "$CONTRACTS_DIR/$parent.md" ]]; then
            printf '%s\tcontract\t%s#%s\t%s\n' \
                "$cid" "$CONTRACTS_DIR/$parent.md" "${cid##* }" "curated clause row of $parent"
        fi
    done

    # mechanism rows (MECHS): id \t corpus \t locate \t layer \t disposition \t target \t ruling. `{CANON}` in
    #   locate expands to the resolved canon edition, so the CANON row can never point at a superseded one.
    awk -F'\t' -v canon="$CANON_DOC" '/^#/{next} NF<7{next} { loc=$3; gsub(/\{CANON\}/, canon, loc);
        printf "%s\t%s\t%s\tmechanism row (%s)\n", $1, $2, loc, $7 }' "$MECHS"
}

# mech_collisions: an id in BOTH layers.tsv and mechanisms.tsv has two layer sources — HALT, never pick one.
#   Also HALTs on a mechanisms row whose locate FILE is absent (a row pointing at nothing is not a row).
mech_collisions() {
    local dup bad
    dup="$(comm -12 <(awk -F'\t' '/^#/{next} NF<2{next}{print $1}' "$LAYERS" | sort -u) \
                    <(awk -F'\t' '/^#/{next} NF<7{next}{print $1}' "$MECHS" | sort -u))"
    [[ -z "$dup" ]] || die "id(s) in BOTH $LAYERS and $MECHS (two layer sources): $(printf '%s' "$dup" | tr '\n' ' ')"
    bad="$(awk -F'\t' -v canon="$CANON_DOC" '/^#/{next} NF<7{next} { loc=$3; gsub(/\{CANON\}/, canon, loc);
        sub(/#.*/, "", loc); print $1 "\t" loc }' "$MECHS" | while IFS=$'\t' read -r i l; do [[ -f "$l" ]] || printf '%s(%s) ' "$i" "$l"; done)"
    [[ -z "$bad" ]] || die "mechanisms.tsv row(s) locate an absent file: $bad"
    awk -F'\t' '/^#/{next} NF==0{next} NF<7{bad=bad $1 " "} END{ if (bad!="") { print "HALT: mechanisms.tsv row(s) with <7 columns: " bad > "/dev/stderr"; exit 3 } }' "$MECHS" || exit 3
}

# ---------------------------------------------------------------------------
# build_tsv : emit the full index to stdout
# ---------------------------------------------------------------------------
build_tsv() {
    local canon_blob head_sha untagged=0
    mech_collisions
    canon_blob="$(git hash-object "$CANON_DOC" 2>/dev/null || echo 'ABSENT')"
    head_sha="$(git rev-parse --short HEAD 2>/dev/null || echo 'UNKNOWN')"

    echo "# governance.tsv — DERIVED BUILD ARTIFACT. Do not hand-edit; run scripts/gen-governance-index.sh."
    echo "# Sources of existence: disciplines.md §0 · CLAUDE.md invariants · contracts/*.md · _index/canon-section-map.tsv · _index/mechanisms.tsv"
    echo "# Source of metadata:   _index/annotations.tsv (curated; join is fail-closed both directions)"
    echo "# Columns: id\tcorpus\tclasses\ttriggers\tinteracts_with\tlocate\tcheck\tblood\tship\twiring\tstrength\tlayer\tdisposition\ttarget"
    echo "# wiring/strength ADDED v0.2 (contracts/SPEC-GOVERNANCE-INDEX.md v0.2)."
    echo "#   wiring: scanner:<class> | probe:<path> | gate:<hook|script> | cite-only:<reason,>=8 words> | UNWIRED"
    echo "#   strength: PREDICATE | CITE-ONLY | UNWIRED. Validated by arm D of the governance-index probe."
    echo "# layer ADDED v0.3: S | W-generic | W-project, from _index/layers.tsv. Validated by arm E."
    echo "# disposition/target ADDED v0.4: KEEP | MERGE <survivor> | RETIRE <reason>."
    echo "#   Since v0.5 (0247 §7 step 3) ONLY KEEP rows are emitted; MERGE/RETIRE rows stay on record in"
    echo "#   _index/layers.tsv + _index/mechanisms.tsv (their files stay). 'census' prints the dropped counts."
    echo "#   ship (col 9) is DERIVED from layer since v0.4 (0247 §6): S, W-generic -> generic; W-project -> private. Never hand-set."
    echo "# SCOPE (canon §13 / AC-6 — NOT represented as complete): the contract census is FILE-level;"
    echo "#   clause-level rows are curated-additive, not an enumeration of every clause in every contract."
    echo "#   The cross-cutting detector is mechanical on classes/triggers/interacts_with ONLY; the"
    echo "#   semantic/emergent axis is NOT mechanically detectable and is carried by the §5(c) joint-"
    echo "#   coherence slot, which refuses to let the question go unasked and NEVER certifies coherence."
    # FRAME PINS: SOURCE coordinates ONLY. The canon blob is a genuine INPUT to this artifact.
    # ⛔ DO NOT ADD THE HEAD SHA HERE. It was here for one commit and had to be removed: `check`
    #    byte-compares the committed artifact against a FRESH derivation, so a HEAD sha baked into
    #    the artifact makes it STALE on EVERY COMMIT — the standing probe goes permanently RED for a
    #    reason that has nothing to do with governance content, and a permanently-red probe is
    #    indistinguishable from a broken one (it gets ignored, then disabled).
    #    The irony worth keeping: the line was added to HONOUR DISC-A-NUMBER-CARRIES-ITS-FRAME, and
    #    the frame label is what made the artifact self-invalidating. The lesson is not "skip the
    #    frame" — it is that a frame belongs on the MEASUREMENT (the census/receipt, which does print
    #    HEAD) and never inside the DERIVED ARTIFACT, which must be a pure function of its SOURCES.
    #    Caught by this mechanism's own standing probe on its first run after landing.
    echo "# Frame: canon ${CANON_DOC} git-blob ${canon_blob} (SOURCE pin; see the HEAD-sha note in build_tsv)."

    corpus_ids | sort -u | while IFS=$'\t' read -r id corpus locate body; do
        [[ -z "$id" ]] && continue
        local classes triggers check blood ship wiring strength edges a
        if a="$(annot_lookup "$id")"; then
            IFS=$'\037' read -r classes triggers check blood ship wiring strength <<< "$a"
        else
            # Fail-closed ship default; the census reports these so under-shipping is VISIBLE.
            # Default class is "<corpus>-ref", NOT "<corpus>-edit": an uncurated census row must not
            # collide with a REAL artifact class. Using "contract-edit" made all 84 contract file rows
            # match a genuine --class contract-edit retrieval, flooding the shortlist 104-of-139 and
            # burying the 12 rows that actually draw blood. A retriever that returns everything
            # retrieves nothing.
            classes="$corpus-ref"; triggers=""; check="UNANNOTATED — no curated predicate; see _index/annotations.tsv"
            blood="0"; ship="private"
            # wiring/strength ADDED v0.2: an uncurated row has no metadata row at all, so it is
            # grandfathered UNWIRED — never a fabricated cite-only reason for a row
            # nobody has curated.
            wiring="UNWIRED"; strength="UNWIRED"
        fi
        if [[ "$corpus" == "discipline" ]]; then
            edges="$(disc_edges "$id" "$body")"
        else
            edges=""
        fi
        local layer disposition target
        IFS=$'\037' read -r layer disposition target <<< "$(layer_lookup "$id")"
        # ship is DERIVED from layer (one column, not two). A row with no layer keeps the annotation's
        # value here; arm E of the probe fails that row anyway, so the fallback can never ship silently.
        case "$layer" in S|W-generic) ship="generic" ;; W-project) ship="private" ;; esac
        # STEP 3 (§7.3): MERGE/RETIRE rows LEAVE the index; their files stay (and their disposition
        #   stays on record in layers.tsv / mechanisms.tsv). A dropped row that is SCANNER-wired would silently
        #   switch a creed-scan class off — that is a HALT, never a quiet drop (the 3 gate-wired MERGE rows keep
        #   running as code; their survivors carry the wiring at step 6).
        case "$disposition" in
            MERGE|RETIRE)
                case "$wiring" in scanner:*) die "row '$id' is $disposition but scanner-wired ($wiring) — dropping it would disable that scanner class (0247 §7.3 guard)" ;; esac
                continue ;;
        esac
        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
            "$id" "$corpus" "$classes" "$triggers" "$edges" "$locate" "$check" "$blood" "$ship" "$wiring" "$strength" "$layer" "$disposition" "$target"
    done
}

# ---------------------------------------------------------------------------
# census : coverage numbers WITH denominators + the known-value control
# ---------------------------------------------------------------------------
do_census() {
    local roster_lines disc_ids annot_n corpus_n unann orphan
    roster_lines="$(extract_disc_section "$DISC_MD" | wc -l | tr -d ' ')"
    disc_ids="$(parse_disc_ids "$DISC_MD" | cut -f1 | sort -u | wc -l | tr -d ' ')"
    annot_n="$(annot_ids | wc -l | tr -d ' ')"
    corpus_n="$(corpus_ids | cut -f1 | sort -u | wc -l | tr -d ' ')"

    # KNOWN-VALUE CONTROL (DISC-A-NUMBER-CARRIES-ITS-FRAME: a census needs a known-value control).
    #   The known values are read from the live roster window by a plain line regex that is NOT parse_disc_ids,
    #   and name no id: (i) the first roster bullet's id must appear in the parser's output; (ii) the parser's id
    #   count must be >= the roster bullet count (a bullet carries one id or more, never fewer than one).
    #   A dead parser then fails loudly instead of returning a plausible zero. Zero bullets is a HALT, never a PASS.
    local ctl_re='^- \*\*(DISC-[A-Z0-9-]+|inv#[0-9]+)\*\*' ctl_first ctl_bullets ctl_parsed ctl_ok=1
    ctl_bullets="$(extract_disc_section "$DISC_MD" | grep -cE "$ctl_re")"
    ctl_first="$(extract_disc_section "$DISC_MD" | grep -E "$ctl_re" | head -1 | sed -E "s/${ctl_re}.*/\1/")"
    ctl_parsed="$(parse_disc_ids "$DISC_MD" | wc -l | tr -d ' ')"
    [[ "$ctl_bullets" -ge 1 && -n "$ctl_first" ]] || ctl_ok=0
    [[ "$ctl_ok" -eq 1 ]] && { parse_disc_ids "$DISC_MD" | cut -f1 | grep -qxF "$ctl_first" || ctl_ok=0; }
    [[ "$ctl_parsed" -ge "$ctl_bullets" ]] || ctl_ok=0
    if [[ "$ctl_ok" -eq 0 ]]; then
        echo "HALT: known-value control absent — first roster id ${ctl_first:-(none)} not parsed, or ${ctl_bullets} bullets > ${ctl_parsed} parsed ids; the §0 parser is broken; every count below is UNTRUSTWORTHY." >&2
        echo "      (DISC-A-NUMBER-CARRIES-ITS-FRAME: a census without a passing control reports nothing.)" >&2
        return 3
    fi

    # CORE set = the ids AC-1 names: §0 entries + invariants + curated clause rows. Fail-closed.
    local core_ids uncurated_n core_n census_n
    # NB: the clause-row test must be (corpus==contract AND id contains " §"), never a bare / §/ —
    # a bare match also catches every `CANON §n` row and would fail-close the whole canon census.
    core_ids="$(corpus_ids | awk -F'\t' '$2=="discipline" || $2=="invariant" || ($2=="contract" && $1 ~ / §/) {print $1}' | sort -u)"
    core_n="$(printf '%s\n' "$core_ids" | grep -c . )"
    census_n="$(corpus_ids | awk -F'\t' '$2=="contract" && $1 !~ / §/ {print $1} $2=="canon"{print $1}' | sort -u | wc -l | tr -d ' ')"
    unann="$(comm -23 <(printf '%s\n' "$core_ids") <(annot_ids) | wc -l | tr -d ' ')"
    orphan="$(comm -13 <(corpus_ids | cut -f1 | sort -u) <(annot_ids) | wc -l | tr -d ' ')"
    uncurated_n="$(comm -23 <(corpus_ids | awk -F'\t' '$2=="contract" && $1 !~ / §/ {print $1} $2=="canon"{print $1}' | sort -u) <(annot_ids) | wc -l | tr -d ' ')"

    echo "CENSUS (frame: measured at HEAD $(git rev-parse --short HEAD), denominators printed)"
    echo "  disciplines.md §R registry LINES ...... ${roster_lines}"
    echo "  disciplines.md §R addressable IDS ..... ${disc_ids}   <- index rows are per-ID, not per-line"
    echo "  corpus ids (all four corpora) ......... ${corpus_n}"
    echo "  annotation rows ....................... ${annot_n}"
    echo "  -- CORE (fail-closed half: §0 entries + invariants + curated clause rows) = ${core_n} --"
    echo "  UNANNOTATED-CORE ...................... ${unann}   <- any >0 REJECTS (AC-1)"
    echo "  ORPHAN (metadata matching no corpus id) ${orphan}   <- a retired rule still indexed; REJECTS"
    echo "  known-value control ................... PASS (first roster id ${ctl_first} parsed; ${ctl_parsed} ids over ${ctl_bullets} bullets)"
    echo "  -- CENSUS (warn-only half: contract FILE rows + canon section rows) --"
    echo "  uncurated census rows ................. ${uncurated_n} of ${census_n}   <- ship=private by fail-closed default"
    echo "     (these get default advisory rows, blood=0. Reported every run so under-curation is"
    echo "      VISIBLE and never silent — but they do NOT block, per the ratified A+B zero-friction order.)"
    if [[ "$unann" -gt 0 ]]; then
        echo "  --- UNANNOTATED-CORE ids (REJECTING) ---"
        comm -23 <(printf '%s\n' "$core_ids") <(annot_ids) | sed 's/^/    /'
    fi
    if [[ "$orphan" -gt 0 ]]; then
        echo "  --- ORPHAN ids (REJECTING) ---"
        comm -13 <(corpus_ids | cut -f1 | sort -u) <(annot_ids) | sed 's/^/    /'
    fi

    # -- WIRED census: every corpus id carries a strength value —
    #    curated CORE rows get an honest PREDICATE/CITE-ONLY classification from annotations.tsv col 8;
    #    every OTHER corpus id (the uncurated census half) is grandfathered UNWIRED (never hand-written).
    #    Denominator T = corpus_n (ALL corpora), a DIFFERENT population than core_n above — both printed,
    #    neither substituted for the other (DISC-A-NUMBER-CARRIES-ITS-FRAME).
    # STEP 3 visibility: rows the index no longer emits, by disposition (denominator = corpus ids).
    local d_merge=0 d_retire=0 d_keep=0 d_none=0 _cid _l _d _t
    while IFS= read -r _cid; do
        IFS=$'\037' read -r _l _d _t <<< "$(layer_lookup "$_cid")"
        case "$_d" in MERGE) d_merge=$((d_merge+1)) ;; RETIRE) d_retire=$((d_retire+1)) ;; KEEP) d_keep=$((d_keep+1)) ;; *) d_none=$((d_none+1)) ;; esac
    done < <(corpus_ids | cut -f1 | sort -u)
    echo "  -- STEP 3 (0247 §7.3): emitted KEEP=${d_keep} · dropped MERGE=${d_merge} RETIRE=${d_retire} · no-disposition=${d_none} of ${corpus_n} corpus ids --"

    local wired_predicate wired_citeonly wired_unwired
    wired_predicate="$(comm -12 <(awk -F'\t' '/^#/{next} NF<8{next} $8=="PREDICATE"{print $1}' "$ANNOT" | sort -u) <(printf '%s\n' "$core_ids") | wc -l | tr -d ' ')"
    wired_citeonly="$(comm -12 <(awk -F'\t' '/^#/{next} NF<8{next} $8=="CITE-ONLY"{print $1}' "$ANNOT" | sort -u) <(printf '%s\n' "$core_ids") | wc -l | tr -d ' ')"
    wired_unwired=$(( corpus_n - wired_predicate - wired_citeonly ))
    echo "  -- WIRING (every corpus id carries a strength; T = corpus_n, NOT core_n) --"
    echo "WIRED: predicate=${wired_predicate} cite-only=${wired_citeonly} unwired=${wired_unwired} of ${corpus_n}"
    return 0
}

# ---------------------------------------------------------------------------
# self-test : run the parser on a synthetic fixture with a KNOWN answer.
#   Proves the instrument measures, independent of the live corpus (DISC-PROBE-INPUT-PROVENANCE:
#   this is a SYNTHETIC-input result and proves only the synthetic case — it is an instrument
#   control, NOT evidence about the live roster).
# ---------------------------------------------------------------------------
do_self_test() {
    local fx rc=0 got
    fx="$(mktemp -t govidx-fixture)" || die "mktemp failed"
    {
        echo "## §0 — stub (a pointer; must NOT be parsed)"
        echo "- **DISC-FIXTURE-STUB** — must NOT be parsed; §0 is a pointer stub."
        echo "## §R — fixture"
        echo "- **DISC-FIXTURE-ALPHA** — a single-id entry. Pairs with **DISC-FIXTURE-BETA**."
        echo "- **DISC-FIXTURE-BETA** / **DISC-FIXTURE-GAMMA** — a co-equal two-id entry."
        echo "- **DISC-FIXTURE-DELTA** — an entry with a companion. (+ **DISC-FIXTURE-EPSILON** — the companion.)"
        echo "## §1 — not the roster"
        echo "- **DISC-FIXTURE-NEVER** — must NOT be parsed; it is outside §0."
    } > "$fx"

    echo "SELF-TEST (synthetic fixture; instrument control only — proves the parser, not the corpus)"
    got="$(extract_disc_section "$fx" | wc -l | tr -d ' ')"
    [[ "$got" == "3" ]] && echo "  roster LINES  expected 3  got $got  PASS" || { echo "  roster LINES  expected 3  got $got  FAIL"; rc=1; }

    got="$(parse_disc_ids "$fx" | cut -f1 | sort -u | wc -l | tr -d ' ')"
    [[ "$got" == "5" ]] && echo "  addressable IDS expected 5  got $got  PASS" || { echo "  addressable IDS expected 5  got $got  FAIL"; rc=1; }

    # the §0 stub entry must be invisible to the parser (§0 is no longer a source)
    if parse_disc_ids "$fx" | cut -f1 | grep -qx 'DISC-FIXTURE-STUB'; then
        echo "  §0 stub excluded  FAIL (DISC-FIXTURE-STUB parsed)"; rc=1
    else echo "  §0 stub excluded  PASS"; fi
    # the §1 entry must be invisible to the parser (scope containment)
    if parse_disc_ids "$fx" | cut -f1 | grep -qx 'DISC-FIXTURE-NEVER'; then
        echo "  §0 scope containment            FAIL (parsed an entry from §1)"; rc=1
    else
        echo "  §0 scope containment            PASS"
    fi

    # edge auto-extraction must find the declared partner and must NOT self-edge
    got="$(parse_disc_ids "$fx" | awk -F'\t' '$1=="DISC-FIXTURE-ALPHA"{print $2}' | head -1)"
    got="$(disc_edges "DISC-FIXTURE-ALPHA" "$got")"
    [[ "$got" == "DISC-FIXTURE-BETA" ]] && echo "  interacts_with edge             PASS" || { echo "  interacts_with edge             expected DISC-FIXTURE-BETA got '$got'  FAIL"; rc=1; }

    rm -f "$fx"
    [[ $rc -eq 0 ]] && echo "SELF-TEST: PASS" || echo "SELF-TEST: FAIL"
    return $rc
}

# ---------------------------------------------------------------------------
verb="${1:-build}"
case "$verb" in
    build)
        mkdir -p _index
        tmp="$(mktemp -t govidx)" || die "mktemp failed"
        build_tsv > "$tmp" || { rm -f "$tmp"; die "index derivation failed (child exit surfaced — DISC-CHILD-FAILURE-MUST-SURFACE)"; }
        mv "$tmp" "$OUT"
        echo "BUILT: $OUT ($(grep -vc '^#' "$OUT") rows)"
        do_census
        ;;
    check)
        [[ -f "$OUT" ]] || die "$OUT absent — run 'scripts/gen-governance-index.sh build' first"
        tmp="$(mktemp -t govidx)" || die "mktemp failed"
        build_tsv > "$tmp" || { rm -f "$tmp"; die "index derivation failed"; }
        if diff -q "$tmp" "$OUT" >/dev/null 2>&1; then
            rm -f "$tmp"
        else
            echo "DRIFT: $OUT is STALE — it does not match a fresh derivation." >&2
            diff "$OUT" "$tmp" | head -40 >&2
            rm -f "$tmp"
            exit 2
        fi
        cen="$(do_census)" || { echo "$cen" >&2; exit 3; }
        echo "$cen"
        o="$(echo "$cen" | sed -n 's/^  ORPHAN (metadata matching no corpus id) \([0-9]*\).*/\1/p')"
        u="$(echo "$cen" | sed -n 's/^  UNANNOTATED-CORE \.* \([0-9]*\).*/\1/p')"
        if [[ "${u:-0}" -gt 0 || "${o:-0}" -gt 0 ]]; then
            echo "DRIFT: fail-closed — ${u:-0} unannotated CORE id(s), ${o:-0} orphan annotation row(s)." >&2
            exit 2
        fi
        echo "GOVERNANCE-INDEX: CURRENT (no stale drift, no unannotated core ids, no orphans)"
        ;;
    census)    do_census ;;
    disc-ids)  # the addressable discipline ids of a disciplines file, in registry order, deduped.
               # The boot roster's membership function calls THIS, so it can never parse differently.
        f="${2:-$DISC_MD}"; [[ -r "$f" ]] || die "disc-ids: $f unreadable"
        parse_disc_ids "$f" | cut -f1 | awk '!seen[$0]++' ;;
    self-test) do_self_test ;;
    *) echo "usage: gen-governance-index.sh [build|check|census|self-test|disc-ids [file]]" >&2; exit 3 ;;
esac
