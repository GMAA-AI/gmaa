#!/usr/bin/env bash
# scripts/declared-spine-paths.sh
#
# The emitter that agents/pre-commit-hook.sh (SPINE_PATHS) and
# scripts/ratify.sh (SPINE_PREFIXES, ~:135) already reference and OPTIONALLY consume (-x-guarded
# append — see pre-commit-hook.sh:218-224 and ratify.sh:136-140) but which was ABSENT at HEAD.
# This file makes the emitter side of that already-wired optional-append contract real. It does
# NOT touch either consumer's own hand-kept base array — consumer edits (folding the two hand-kept
# lists down to this single source) are a separate, named operator-pen item
# ("`pre-commit-hook.sh` is P4 -> the consumer edit takes the operator's pen").
#
# Output contract: one spine path per line, sorted (LC_ALL=C), and NOTHING ELSE on stdout — both
# consumers read stdout line-by-line and append every non-empty line directly into their array, so
# any banner/diagnostic text on stdout would be swallowed as a bogus "spine path". `--count` prints
# only the denominator (the list's cardinality) and nothing else.
#
# The list below is transcribed verbatim from agents/pre-commit-hook.sh SPINE_PATHS as measured at
# authoring time (2026-09-23, HEAD 40267ac7): 19 entries. Confirmed at the same measurement to be
# the same SET (order aside) as scripts/ratify.sh SPINE_PREFIXES (also 19 entries). Kept in exactly
# ONE place here — probes/set-gate/probe_census_parity.sh is the standing check that this file and
# the two consumers' base lists stay the same set.

set -u

# ROLE LOOKUP (the one place a role path is read from the declared engine-path table). A path a shipped script
# needs for a ROLE (the hub's handoff file) is not typed into the script: it is the one row of _index/engine-paths.tsv
# whose `note` column carries the token `role:<role>`. FAIL-CLOSED and LOUD (inv #5): an unreadable table, no row for
# the role, or more than one row for it prints a named reason on stderr and returns 1; there is no default path.
# The table is read from ENGINE_PATHS_FILE when set (the test seam), else from the worktree this runs in.
engine_path_for_role() {  # <role> -> prints the path on stdout; rc 1 + `ENGINE-PATH-*:` reason on stderr
    local role="$1" tbl="${ENGINE_PATHS_FILE:-}" top out n
    if [[ -z "$tbl" ]]; then
        top="$(git rev-parse --show-toplevel 2>/dev/null)" || top="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
        tbl="$top/_index/engine-paths.tsv"
    fi
    [[ -r "$tbl" ]] || { echo "ENGINE-PATH-UNREADABLE: $tbl is not readable; cannot resolve role:$role (no default path is assumed)" >&2; return 1; }
    out="$(awk -F'\t' -v r="role:$role" '$0 !~ /^#/ && $1 != "path" && NF >= 4 { k = split($4, a, /[ ;,]+/); for (i = 1; i <= k; i++) if (a[i] == r) { print $1; break } }' "$tbl")" \
        || { echo "ENGINE-PATH-UNREADABLE: awk failed over $tbl" >&2; return 1; }
    n=$(printf '%s' "$out" | grep -c .)
    [[ "$n" -ge 1 ]] || { echo "ENGINE-PATH-NO-ROW: $tbl has no row whose note carries 'role:$role'" >&2; return 1; }
    [[ "$n" -eq 1 ]] || { echo "ENGINE-PATH-AMBIGUOUS: $tbl has $n rows whose note carries 'role:$role'" >&2; return 1; }
    printf '%s\n' "$out"
}

build_spine_paths() {  # fills SPINE_PATHS; the handoff entry comes from the table
    local handoff
    handoff="$(engine_path_for_role handoff)" || return 1
    SPINE_PATHS=(
    "ledger/"
    "dag/"
    "issues_register.md"
    "CHECKLIST.md"
    "contracts/"
    "_orchestration/STATE.md"
    "_orchestration/decision-log.md"
    "_orchestration/lane-provisioning.md"
    "PENDING-SET.md"
    "_ratification/"
    "$handoff"
    "sql/"
    "migrations/"
    "agents/"
    "scripts/"
    "skill/"
    "src/"
    ".claude/agents/"
    ".claude/settings.json"
    )
}

# ⛔ LIVE-CONTRACT GUARD. Both consumers ALREADY call this file whenever it exists and is
# executable, and APPEND every line it prints to their base array as the ADOPTER'S EXTRA declared spine paths
# (pre-commit-hook.sh:218-224 "append the adopter's DECLARED spine paths … to the base census"; ratify.sh
# :136-140 same). Printing the 19 base paths by DEFAULT would inject 19 duplicates into the live gates the
# moment this file lands. So, until the consumer edit (operator pen, G7) switches them to --canonical:
#   (default)     print ONLY the adopter-declared EXTRAS (DECLARED_EXTRA below — empty for this project)
#   --canonical   print the full canonical list (the parity probe's input; the future single source)
#   --count       the canonical cardinality
#   --role <r>    the path of the one _index/engine-paths.tsv row whose note carries role:<r> (fail-closed; the consumers' handoff path)
DECLARED_EXTRA=()

case "${1:-}" in
    --count)     build_spine_paths || exit 1; printf '%s\n' "${#SPINE_PATHS[@]}"; exit 0 ;;
    --canonical) build_spine_paths || exit 1; printf '%s\n' "${SPINE_PATHS[@]}" | LC_ALL=C sort; exit 0 ;;
    --role)      [[ -n "${2:-}" ]] || { echo "usage: $0 --role <role>" >&2; exit 2; }; engine_path_for_role "$2"; exit $? ;;
    "")          [[ ${#DECLARED_EXTRA[@]} -gt 0 ]] && printf '%s\n' "${DECLARED_EXTRA[@]}" | LC_ALL=C sort; exit 0 ;;
    *)           echo "usage: $0 [--canonical|--count|--role <role>]" >&2; exit 2 ;;
esac
