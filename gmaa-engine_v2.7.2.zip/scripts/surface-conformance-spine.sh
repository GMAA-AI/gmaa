#!/usr/bin/env bash
# scripts/surface-conformance-spine.sh — run the SPINE's surface-conformance probe bytes. A deliberate
# mirror of scripts/creed-scan-spine.sh: executing origin/main's
# bytes means a probe change reaches every lane with NO per-lane sync — lanes read the spine, never merge it.
# This runner is deliberately tiny so it almost never needs to change itself.
#
# FAIL-CLOSED (DISC-CHILD-FAILURE-MUST-SURFACE): the spine probe unreadable => an explicit UNREADABLE line and
# exit 3, never a silent or clean-looking verdict. Callers (boot-check.sh) run it under `|| true`: canon :156
# "detect-and-surface, never a synchronous emit-block" — a drifted surface produces a recorded FAIL, not a
# boot that will not start. SURFACE_SPINE_REF overrides the ref ONLY for the fail-closed test pole (R3).
#
# 0397 §2.2 / §3 member 2 — THE "PROBE BRANCH": the probe itself stays lane-agnostic (its bytes are
# the spine's, shared by every caller); dormancy is a HUB-ONLY concept, so the reclassification happens HERE,
# in the wrapper, never inside the probe. A NAMED-DORMANT lane's RED row (DRIFT|ABSENT|EXTERNAL|RULES-STALE)
# is rewritten to DORMANT, excluded from RED/the VERDICT, and counted in a `dormant=N` field on the summary
# line (N = the number of DISTINCT dormant lanes reclassified, not raw rows). A lane NOT in the table is
# untouched (control pole: it still reads DRIFT). The dormancy table is read like the probe bytes — spine
# first, labelled local fallback — so a lane never needs its own sync for this to apply.
set -u
# the spine ref (the one spine-ref resolver): SURFACE_SPINE_REF if set (a replica/test knob), else the ONE resolver scripts/spine-ref.sh;
# no resolution is a HALT by name, never a literal fallback (inv #5).
REF="${SURFACE_SPINE_REF:-}"
SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"   # beside this script only (0507 R2)
[ -n "$REF" ] || [ -f "$SPINE_REF_SH" ] || { echo "SURFACE-CONFORM: UNREADABLE — SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2) (exit 3)"; exit 3; }
[ -n "$REF" ] || REF="$(bash "$SPINE_REF_SH")" || { echo "SURFACE-CONFORM: UNREADABLE — SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and SURFACE_SPINE_REF unset (the one spine-ref resolver) (exit 3)"; exit 3; }
P="probes/governance/probe_surface_conformance_v1.sh"
DTSV="_index/lane-dormancy.tsv"

_dormant_lanes() {  # stdout: one dormant lane name per line (empty if the table is unreadable)
  local rows src
  rows="$(git show "${REF}:${DTSV}" 2>/dev/null)"
  if [ -n "$rows" ]; then src="SPINE(${REF})"; else rows="$(cat "${DTSV}" 2>/dev/null)"; src="LOCAL-FALLBACK(${REF} unreadable)"; fi
  if [ -z "$rows" ]; then echo "[dormancy table source: UNREADABLE — ${DTSV} absent at ${REF} and locally; no reclassification applied]" >&2
  else echo "[dormancy table source: ${src}]" >&2
  fi
  printf '%s\n' "$rows" | awk -F'\t' '!/^#/ && NF>=1 && $1!="" && $1!="lane" {print $1}'
}

# Pure stdin->stdout transform (unit-testable on a synthetic fixture without the real multi-worktree probe —
# SURFACE_SPINE_SELFTEST=1 reads the fixture from stdin instead of invoking the spine probe bytes).
_reclassify_dormant() {  # $1 = newline-separated dormant lane list
  DORMANT_LANES="$1" perl -e '
    my %dormant;
    for my $l (split /\n/, $ENV{DORMANT_LANES}) { $dormant{$l} = 1 if length $l; }
    my $removed = 0; my %dlanes;
    while (<STDIN>) {
      if (/^SURFACE-CONFORM: worktree=/ && /\blane=(\S+)/) {
        my $lane = $1;
        if ($dormant{$lane} && /\bverdict=(DRIFT|ABSENT|EXTERNAL|RULES-STALE)\b/) {
          my $orig = $1;
          s/\bverdict=(?:DRIFT|ABSENT|EXTERNAL|RULES-STALE)\b/verdict=DORMANT (named-dormant lane; was $orig)/;
          $removed++; $dlanes{$lane} = 1;
          print; next;
        }
      }
      if (/^SURFACE-CONFORM: \d+ rows over/) {
        if (/\bRED=(\d+)\b/) { my $newred = $1 - $removed; s/\bRED=\d+\b/RED=$newred/; }
        chomp;
        print "$_ dormant=" . (scalar keys %dlanes) . "\n";
        next;
      }
      if (/^VERDICT: FAIL \((\d+) of (\d+) rows RED/) {
        my ($oldred, $tot) = ($1, $2);
        my $newred = $oldred - $removed;
        if ($newred <= 0) { print "VERDICT: PASS\n"; }
        else { print "VERDICT: FAIL ($newred of $tot rows RED: DRIFT|ABSENT|EXTERNAL|RULES-STALE)\n"; }
        next;
      }
      print;
    }
  '
}

DLANES="$(_dormant_lanes)"

if [ "${SURFACE_SPINE_SELFTEST:-0}" = "1" ]; then
  _raw="$(cat)"
else
  T="$(mktemp "${TMPDIR:-/tmp}/surface-spine.XXXXXX")" || { echo "SURFACE-CONFORM: UNREADABLE — mktemp failed (exit 3)"; exit 3; }
  trap 'rm -f "$T"' EXIT
  if ! { git show "${REF}:${P}" > "$T" 2>/dev/null && [ -s "$T" ]; }; then
    echo "SURFACE-CONFORM: UNREADABLE — ${REF}:${P} could not be read. This is NOT a verdict. Fetch, then re-run."
    exit 3
  fi
  echo "[surface-conformance source: SPINE(${REF}) blob $(git rev-parse --short "${REF}:${P}" 2>/dev/null)]"
  _raw="$(SURFACE_REF="${REF}" bash "$T" "$@" 2>&1)"
fi

_out="$(printf '%s\n' "$_raw" | _reclassify_dormant "$DLANES")"

# SEAT-LINE join (canon 7.5): the seat-line presence probe runs from the SPINE's bytes too (same mirror shape) and its
# verdict is folded into THIS runner's summary + VERDICT, so boot-check's SURFACE-CONFORM-CHECK line carries it with no
# change to boot-check.sh. Green: the denominator line gains a ` seat-line=K/M` suffix. Red: the failing subjects print as
# RED rows, RED += their count, VERDICT FAIL. Unreadable probe/canon: UNREADABLE, exit 3 (fail closed). Skipped under
# SURFACE_SPINE_SELFTEST (a fixture on stdin has no repo to measure).
if [ "${SURFACE_SPINE_SELFTEST:-0}" != "1" ]; then
  SP75="probes/governance/probe_seat_line_75_v1.sh"
  S2="$(mktemp "${TMPDIR:-/tmp}/seatline-spine.XXXXXX")" || { echo "SURFACE-CONFORM: UNREADABLE — seat-line mktemp failed (exit 3)"; exit 3; }
  if ! { git show "${REF}:${SP75}" > "$S2" 2>/dev/null && [ -s "$S2" ]; }; then
    rm -f "$S2"; printf '%s\n' "$_out" | grep -v '^VERDICT:'
    echo "SURFACE-CONFORM: UNREADABLE — ${REF}:${SP75} could not be read. This is NOT a verdict. Fetch, then re-run."
    exit 3
  fi
  _sl="$(SEAT_LINE_REF="${REF}" bash "$S2" 2>&1)"; _slrc=$?; rm -f "$S2"
  if [ "$_slrc" -eq 3 ] || { [ "$_slrc" -ne 0 ] && [ "$_slrc" -ne 1 ]; }; then
    printf '%s\n' "$_out" | grep -v '^VERDICT:'
    echo "SURFACE-CONFORM: UNREADABLE — seat-line probe rc=${_slrc}: $(printf '%s\n' "$_sl" | grep -m1 'UNREADABLE' | sed 's/^SEAT-LINE: //')"
    exit 3
  fi
  _slsum="$(printf '%s\n' "$_sl" | sed -n 's/^SEAT-LINE: \([0-9]*\) of \([0-9]*\) subjects.*/\1\/\2/p' | head -1)"
  _slbad="$(printf '%s\n' "$_sl" | grep -E '^SEAT-LINE: .* verdict=(MISSING|ABSENT)$' || true)"
  _slred=0; [ -n "$_slbad" ] && _slred="$(printf '%s\n' "$_slbad" | grep -c .)"
  _out="$(SL_BAD="$_slbad" SL_RED="$_slred" SL_SUM="$_slsum" perl -e '
    my @bad = grep { length } split /\n/, $ENV{SL_BAD}; my $n = $ENV{SL_RED};
    my @in = <STDIN>; my $out = "";
    $out .= "$_\n" for @bad;                       # RED rows first, like the probe rows
    for (@in) {
      if (/^SURFACE-CONFORM: \d+ rows over/) {
        chomp; s/^SURFACE-CONFORM: (\d+) rows/"SURFACE-CONFORM: " . ($1 + $n) . " rows"/e; s/\bRED=(\d+)\b/"RED=" . ($1 + $n)/e; $_ .= " seat-line=$ENV{SL_SUM}\n";
      }
      if (/^VERDICT: PASS$/ && $n > 0) { $_ = "VERDICT: FAIL ($n of " . (split m{/}, $ENV{SL_SUM})[1] . " seat-line subjects lack the canon 7.5 line)\n"; }
      elsif (/^VERDICT: FAIL \((\d+) of (\d+) rows RED/ && $n > 0) { my $t = $1 + $n; $_ = "VERDICT: FAIL ($t of " . ($2 + $n) . " rows RED: DRIFT|ABSENT|EXTERNAL|RULES-STALE|SEAT-LINE)\n"; }
      $out .= $_;
    }
    print $out;' <<EOS
$_out
EOS
)"
fi
printf '%s\n' "$_out"
if printf '%s\n' "$_out" | grep -qx 'VERDICT: PASS'; then exit 0
elif printf '%s\n' "$_out" | grep -q '^VERDICT: FAIL'; then exit 1
elif printf '%s\n' "$_out" | grep -q '^SURFACE-CONFORM: UNREADABLE'; then exit 3
else exit 3
fi
