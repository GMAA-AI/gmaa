#!/usr/bin/env bash
# scripts/inbox-age-filer.sh -- canon 7.4(b) inbox-age liveness, filed from OUTSIDE the seat.
# Reads the oldest UNCONSUMED relay-inbox item per lane from the ONE age computation in scripts/status.sh
# (`status.sh --inbox-age-raw`; no second algorithm here) and, past the declared threshold, FILES one OPEN register
# entry per lane in the register. Idempotent: a lane that already has an OPEN INBOX-AGE entry is not filed again.
# Fail closed: an age that cannot be computed prints UNREADABLE and exits 3 (never a silent 0, never a silent skip).
#
# THRESHOLD (declared, adopter-editable; foundation rules the value): INBOX_AGE_THRESHOLD_HOURS, default below.
# Seams (probe use): INBOX_AGE_REGISTER (register file), INBOX_AGE_STATUS (the status script), INBOX_AGE_NOW_DATE,
# INBOX_AGE_DOORBELL (the doorbell script path; default scripts/doorbell.sh), INBOX_AGE_LANESURFACE (scripts/lane-surface.sh).
# MEASURED HALF (the outside-the-seat detector and the ack verb are one answer, not two): for a lane PAST threshold that has no open entry yet, the filer
# calls `doorbell.sh ack <lane> <lane-baseline-sha>` and files the verdict. ack counts `<ref>..origin/<lane-branch>`, so its
# baseline must sit ON THE LANE BRANCH (a spine commit is rarely an ancestor of a lane branch, and the count would then be
# the lane's whole unmerged history). The delivery commit is field 4 of status.sh --inbox-age-raw (the spine commit that landed
# the oldest unconsumed item); the baseline is the last commit on origin/<lane-branch> whose committer time is at or before the
# delivery commit's committer time. The branch comes from lane_branch in scripts/lane-surface.sh (the ONE indirection point
# doorbell.sh ack uses; no name-pattern guess), after the same `git fetch -q origin <branch>` ack runs. A branch with no commit
# at or before delivery was born after it: every commit on it is after delivery, so it is ALIVE-UNCONSUMED without an ack call
# (ack cannot express "the root itself"; no count is invented). An unresolvable branch is UNREADABLE (fail closed). Verdict: rc 0 `ACK: <lane> advanced N commit(s)` -> ALIVE-UNCONSUMED (the lane
# moved after delivery and did not consume); rc 3 + `NO consume-ack` -> SILENT (no motion since delivery); anything else
# (UNRESOLVED / UNREADABLE / other rc) -> UNREADABLE for that lane, exit 3, nothing filed. Never a filing without the verdict.
# No ack call below threshold (no fetch on the common path) and none for a lane that already has an open entry.
# Output: one `INBOX-AGE-FILER: lane=<l> oldest=<h>h threshold=<h>h <FILED ack=<v>|EXISTS|OK|UNREADABLE>` line per lane.
# Exit: 0 all lanes computed (filed or not) | 3 any lane UNREADABLE or the register/status unreadable.
set -u
INBOX_AGE_THRESHOLD_HOURS="${INBOX_AGE_THRESHOLD_HOURS:-24}"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "INBOX-AGE-FILER: UNREADABLE -- not in a git worktree"; exit 3; }
cd "$ROOT" || { echo "INBOX-AGE-FILER: UNREADABLE -- cannot cd to $ROOT"; exit 3; }
REG="${INBOX_AGE_REGISTER:-$ROOT/issues_register.md}"
ST="${INBOX_AGE_STATUS:-$ROOT/scripts/status.sh}"
DB="${INBOX_AGE_DOORBELL:-$ROOT/scripts/doorbell.sh}"
LS="${INBOX_AGE_LANESURFACE:-$ROOT/scripts/lane-surface.sh}"
case "$INBOX_AGE_THRESHOLD_HOURS" in ''|*[!0-9]*) echo "INBOX-AGE-FILER: UNREADABLE -- INBOX_AGE_THRESHOLD_HOURS='$INBOX_AGE_THRESHOLD_HOURS' is not a whole number"; exit 3 ;; esac
[[ -r "$REG" && -w "$REG" ]] || { echo "INBOX-AGE-FILER: UNREADABLE -- register not readable+writable: $REG"; exit 3; }
[[ -r "$ST" ]] || { echo "INBOX-AGE-FILER: UNREADABLE -- $ST absent"; exit 3; }
[[ -r "$LS" ]] || { echo "INBOX-AGE-FILER: UNREADABLE -- $LS absent (lane_branch, the one branch indirection)"; exit 3; }
. "$LS"
utc() { date -u -r "$1" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d "@$1" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null; }
RAW="$(bash "$ST" --inbox-age-raw 2>/dev/null)"; rc=$?
[[ $rc -eq 0 && -n "$RAW" ]] || { echo "INBOX-AGE-FILER: UNREADABLE -- status.sh --inbox-age-raw rc=$rc, rows=$(printf '%s' "$RAW" | grep -c .)"; exit 3; }
THR=$(( INBOX_AGE_THRESHOLD_HOURS * 3600 ))
TODAY="${INBOX_AGE_NOW_DATE:-$(date -u +%Y-%m-%d)}"
fail=0
while IFS=$'\t' read -r lane cnt secs dsha; do
  [[ -n "$lane" ]] || continue
  if [[ "$cnt" == UNREADABLE || "$secs" == UNREADABLE ]]; then
    echo "INBOX-AGE-FILER: lane=${lane} oldest=UNREADABLE threshold=${INBOX_AGE_THRESHOLD_HOURS}h UNREADABLE"; fail=1; continue
  fi
  if [[ "$cnt" == 0 || "$secs" == - ]]; then
    echo "INBOX-AGE-FILER: lane=${lane} oldest=- threshold=${INBOX_AGE_THRESHOLD_HOURS}h OK (0 unconsumed)"; continue
  fi
  case "$secs" in ''|*[!0-9]*) echo "INBOX-AGE-FILER: lane=${lane} oldest=UNREADABLE threshold=${INBOX_AGE_THRESHOLD_HOURS}h UNREADABLE"; fail=1; continue ;; esac
  hrs=$(( secs / 3600 ))
  if [[ "$secs" -lt "$THR" ]]; then
    echo "INBOX-AGE-FILER: lane=${lane} oldest=${hrs}h threshold=${INBOX_AGE_THRESHOLD_HOURS}h OK (${cnt} unconsumed)"; continue
  fi
  up="$(printf '%s' "$lane" | tr 'a-z' 'A-Z')"
  if grep -Eq "ISSUE-INBOX-AGE-${up}-PAST-THRESHOLD-[0-9-]+ \(P[0-9], OPEN" "$REG"; then
    echo "INBOX-AGE-FILER: lane=${lane} oldest=${hrs}h threshold=${INBOX_AGE_THRESHOLD_HOURS}h EXISTS (open entry; not re-filed)"; continue
  fi
  case "${dsha:-}" in *[!0-9a-f]*|'') dsha="" ;; esac
  [[ ${#dsha} -eq 40 ]] || { echo "INBOX-AGE-FILER: lane=${lane} oldest=${hrs}h threshold=${INBOX_AGE_THRESHOLD_HOURS}h UNREADABLE (no delivery commit in status.sh field 4; ack not measurable)"; fail=1; continue; }
  pre="INBOX-AGE-FILER: lane=${lane} oldest=${hrs}h threshold=${INBOX_AGE_THRESHOLD_HOURS}h UNREADABLE"
  dct="$(git show -s --format=%ct "${dsha}^{commit}" 2>/dev/null)"
  case "$dct" in ''|*[!0-9]*) echo "${pre} (delivery commit ${dsha} has no readable committer time; baseline not computable)"; fail=1; continue ;; esac
  branch="$(lane_branch "$lane" 2>/dev/null)" || { echo "${pre} (no branch declared for '${lane}' in the lane manifest; lane_branch)"; fail=1; continue; }
  git fetch -q origin "$branch" 2>/dev/null || true
  git rev-parse -q --verify "origin/${branch}^{commit}" >/dev/null 2>&1 || { echo "${pre} (cannot resolve origin/${branch}; motion not measured)"; fail=1; continue; }
  bsha="$(git rev-list -1 --before="$dct" "origin/${branch}" 2>/dev/null)" || { echo "${pre} (git rev-list on origin/${branch} failed)"; fail=1; continue; }
  dutc="$(utc "$dct")"; bnote=""; arc="-"; verdict=""
  if [[ -z "$bsha" ]]; then
    verdict=ALIVE-UNCONSUMED; bnote=" (branch born after delivery)"
    ackline="no ack call: origin/${branch} has no commit at or before the delivery commit (committer time ${dutc} UTC), so every commit on it is after delivery"
    bdesc="none (branch born after delivery)"
  else
    bct="$(git show -s --format=%ct "$bsha" 2>/dev/null)"; butc="$(utc "$bct")"
    [[ "$bsha" =~ ^[0-9a-f]{40}$ && -n "$butc" && -n "$dutc" ]] || { echo "${pre} (baseline ${bsha:-none} has no readable committer time)"; fail=1; continue; }
    bdesc="${bsha} (committer time ${butc} UTC)"
    ackout="$(bash "$DB" ack "$lane" "$bsha" 2>&1 </dev/null)"; arc=$?
    ackline="$(printf '%s\n' "$ackout" | grep -E 'ACK: |NO consume-ack|UNRESOLVED|UNREADABLE' | head -1)"
    if [[ $arc -eq 0 && "$ackline" == *"ACK: ${lane} advanced "* ]]; then verdict=ALIVE-UNCONSUMED
    elif [[ $arc -eq 3 && "$ackline" == *"NO consume-ack"* ]]; then verdict=SILENT; fi
  fi
  if [[ -z "$verdict" ]]; then
    echo "INBOX-AGE-FILER: lane=${lane} oldest=${hrs}h threshold=${INBOX_AGE_THRESHOLD_HOURS}h UNREADABLE (ack rc=${arc}: ${ackline:-no ack line})"; fail=1; continue
  fi
  {
    printf '\n> **ISSUE-INBOX-AGE-%s-PAST-THRESHOLD-%s (P2, OPEN; filed by scripts/inbox-age-filer.sh, canon 7.4(b)).** ' "$up" "$TODAY"
    printf 'Lane `%s` holds %s unconsumed relay-inbox item(s); the oldest has waited %sh (UTC, age = now minus the committer time of the commit that landed it on the spine, per status.sh), past the declared threshold of %sh (INBOX_AGE_THRESHOLD_HOURS). ' \
      "$lane" "$cnt" "$hrs" "$INBOX_AGE_THRESHOLD_HOURS"
    printf 'Delivery commit %s (committer time %s UTC). Baseline = the last commit on origin/%s (lane_branch of %s) at or before that time: %s. ' "$dsha" "$dutc" "$branch" "$lane" "$bdesc"
    if [[ -n "$bsha" ]]; then printf 'Measured by `doorbell.sh ack %s %s` (rc %s), verdict %s: %s ' "$lane" "$bsha" "$arc" "$verdict" "$ackline"
    else printf 'Verdict %s%s: %s ' "$verdict" "$bnote" "$ackline"; fi
    printf 'Next action: read the lane inbox (`scripts/status.sh`), consume or route; close by editing OPEN to CLOSED here with the consume evidence (inv #4).\n'
  } >> "$REG" || { echo "INBOX-AGE-FILER: lane=${lane} UNREADABLE -- register append failed"; fail=1; continue; }
  echo "INBOX-AGE-FILER: lane=${lane} oldest=${hrs}h threshold=${INBOX_AGE_THRESHOLD_HOURS}h FILED ack=${verdict}${bnote} (ISSUE-INBOX-AGE-${up}-PAST-THRESHOLD-${TODAY})"
done <<< "$RAW"
[[ $fail -eq 0 ]] || exit 3
exit 0
