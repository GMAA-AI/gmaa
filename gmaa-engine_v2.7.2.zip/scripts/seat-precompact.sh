#!/bin/bash
# scripts/seat-precompact.sh — PreCompact hook, matcher `auto` (P19).
# B6 says restart, not compact. An AUTO compaction of a SEAT is blocked with a reason that carries the B6.1
# instruction, so a block is never silent. `manual` (/compact, the B6.3 bridge) is never matched here.
# Scope, from the live docs (code.claude.com/docs/en/hooks):
#   - `agent_id` is "Present only when the hook fires inside a subagent call" -> a subagent may compact.
#   - a session with no own-session statusline line in .claude/context-pct is not an interactive seat
#     (headless `claude -p` auditors share this worktree and have no status line) -> allowed.
# Stated cost (docs, PreCompact): a block on a compaction "triggered to recover from a context-limit error"
# makes the current request fail. At the 1M window auto-compact fires near ~967K, far past the 50/70% B6 lines,
# so a seat reaching it has ignored two latched injections; failing loud there is the halt-loud posture (inv #5).
set -u
IN="$(cat)"
TRIGGER="$(printf '%s' "$IN" | jq -r '.trigger // empty' 2>/dev/null)"
[ "$TRIGGER" = "auto" ] || exit 0
AGENT_ID="$(printf '%s' "$IN" | jq -r '.agent_id // empty' 2>/dev/null)"
[ -z "$AGENT_ID" ] || exit 0
SID="$(printf '%s' "$IN" | jq -r '.session_id // empty' 2>/dev/null)"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
L_SID=""
[ -f "$ROOT/.claude/context-pct" ] && read -r L_SID _ < "$ROOT/.claude/context-pct"
[ -n "$SID" ] && [ "$L_SID" = "$SID" ] || exit 0
jq -n '{decision: "block", reason: "B6 (CLAUDE.md s7): seats restart, they do not auto-compact. Externalize per B6.1 now (WIP committed; handoff surface written and committed), then run scripts/seat-exit.sh restart as your last act. /compact by hand stays available as the B6.3 mid-WP bridge."}'
exit 0
