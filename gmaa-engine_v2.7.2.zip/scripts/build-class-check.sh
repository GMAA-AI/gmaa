#!/usr/bin/env bash
# build-class-check.sh — the §3 BUILD-CLASS PREDICATE GATE (P1–P4), fail-closed.
#
# CONTRACT: contracts/SPEC-BUILD-CLASS-STANDING-APPROVAL.md v0.3 — §1 (predicate) · §3 (this gate) · §6 (AC-B1..B7)
#
# WHAT IT DECIDES
#   A ratification set is BUILD-CLASS iff P1..P4 ALL hold. BUILD-CLASS ⇒ closes under the operator's
#   standing CLASS ratification with NO per-set operator pen. ANY failure ⇒ operator pen required.
#
# ADD-ONLY CLAUSE — the ONE exception to "undeclared/denied ⇒ FAIL".
#   A member whose ENTIRE surface set is drawn from {.claude/settings.json, agents/standing-probes.yaml,
#   _knowledge/standing-probes.yaml} is build-class-eligible for THOSE surfaces IFF the member's own STAGED
#   bytes (index blob `:path`) vs committed HEAD ONLY ADD entries (auditor 95036032 F1 cure — see FRAME below):
#   settings.json may grow `permissions.deny` and/or `hooks`, and may SHRINK `permissions.allow`
#   (remove-only — any allow ADDITION still takes the pen), with every other key
#   byte-identical (python3 `json`, canonical compare); standing-probes.yaml may gain new `- id:` runlist
#   entries, with every EXISTING id's body byte-identical (python3 `yaml`). Any removal, any edit to an
#   existing entry, or any change outside those two settings.json fields ⇒ the clause does NOT fire and the
#   path falls straight through to the UNCHANGED P1/P2 evaluation (fail-closed; this is the ONLY carve-in
#   in the file — everything else stays byte-identical in behaviour, P2/P4 precedence included).
#   FRAME: the gate is consulted only PRE-LANDING (ratify assess / --standing-class; pre-commit coverage),
#   so the member's bytes are STAGED there. OLD = `HEAD:<path>`, NEW = `:<path>` (index). Nothing staged ⇒
#   no member diff ⇒ the clause does not fire. The working tree is never read. (Replaces the pre-cure frame
#   `c^:<path>` vs `HEAD:<path>`, which judged the PREVIOUS commit — auditor 95036032 F1, HIGH.) Evaluable
#   ONLY in packet mode; an ad-hoc `--footprint` run can never satisfy this clause, by construction.
#
# ⛔ LISTS ARE DATA, NEVER LITERALS.
#    P1, P2 AND P4 all come from $PREDICATE_TSV — ONE operative rule-tagged file (shape (b)).
#    Nothing below hardcodes a governed path. A predicate amendment is therefore a DATA change, not a
#    gate rebuild — and the gate can never silently drift from the predicate it claims to enforce.
#    ⚠ CORRECTED: these lines previously named $FOOTPRINT_TSV and $MANIFEST_TSV, two
#    variables this script has never read since shape (b) collapsed the two files into one. The USAGE
#    block below documented them as the ENV OVERRIDES for "testing + both-polarity proofs" — so a reader
#    following it would set a variable with NO effect, run against the REAL operative data, and believe
#    the gate had read their fixture. A false-green TEST INTERFACE on a gate is the same defect class as
#    a false-green gate. Found when a mechanical acceptance criterion had to consume the documented
#    interface: wrong as prose for weeks, wrong as data in one run.
#
# ⛔ FAIL-CLOSED IS THE WHOLE POINT (spec §3).
#    Unreadable data · missing data file · unparseable packet · zero members · undeclared occupant ·
#    any P-failure  ⇒  NOT build-class ⇒ operator pen. There is NO path through this script that
#    reaches "PASS" by DEFAULT; PASS is only ever reached by affirmative evidence on all four.
#    (A missing $PREDICATE_TSV does not degrade to "allow everything" — it HALTs. That is deliberate:
#     the P1/P2 operative lists are not foundation's to author, exactly as P4's were not.)
#
# ⛔ THIS SCRIPT IS ITSELF IN THE P4 MANIFEST (spec §1 P4 · AC-B5). A set that edits THIS FILE is
#    therefore NOT build-class and takes the operator's pen — the gate cannot authorise its own rewrite.
#
# USAGE
#   scripts/build-class-check.sh <packet.md>              # e.g. _ratification/SET-0021.md
#   scripts/build-class-check.sh --footprint <path>...    # ad-hoc footprint (assembly-time preview)
#   env: PREDICATE_TSV overrides the declared operative data path (testing + both-polarity proofs).
#        This is the ONLY data-path override this script reads; verify with
#        `PREDICATE_TSV=/nonexistent/x.tsv scripts/build-class-check.sh <packet>` -> rc=2 HALT.
#
# EXIT CODES (consumed by pre-commit / ratify / the auditor's reproduction)
#   0 = BUILD-CLASS PASS      (no operator pen required under the standing class)
#   1 = NOT build-class       (a named P failed  ⇒ operator pen required)  ← a NORMAL, expected outcome
#   2 = HALT (fail-closed)    (unreadable/missing input ⇒ treat as NOT build-class, and say why)

set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "build-class-check: not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2

# ONE operative data file holds all three lists (shape b).
# Schema: rule<TAB>path<TAB>kind<TAB>why<TAB>scope (header line first)   with rule ∈ P1-ALLOW | P2-DENY | P4-ENFORCER.
# The file is itself a P4-ENFORCER row (self-protecting): a set editing it is never build-class.
PREDICATE_TSV="${PREDICATE_TSV:-_index/authz-enforcers.tsv}"

halt() { printf 'build-class: HALT — %s\n' "$*"; exit 2; }
fail() { printf 'build-class: FAIL — %s\n' "$*"; }

# ---------------------------------------------------------------- inputs
[ $# -ge 1 ] || halt "usage: build-class-check.sh <packet.md> | --footprint <path>..."

FOOTPRINT=()
if [ "$1" = "--footprint" ]; then
    shift
    [ $# -ge 1 ] || halt "--footprint given with no paths"
    FOOTPRINT=("$@")
    SRC_DESC="ad-hoc footprint (${#FOOTPRINT[@]} path(s))"
else
    PACKET="$1"
    [ -f "$PACKET" ] || halt "packet not readable: $PACKET"
    # Footprint = every 'surfaces:' path on a MEMBERS line. Comma/space separated; a member may
    # declare several. We take the text AFTER 'surfaces:' and split it.
    while IFS= read -r surf; do
        surf="${surf//,/ }"
        for p in $surf; do
            case "$p" in ''|'·') continue ;; esac
            FOOTPRINT+=("$p")
        done
    done < <(sed -n '/^## MEMBERS/,/^## /p' "$PACKET" | sed -n 's/.*surfaces:[[:space:]]*//p')
    SRC_DESC="packet $PACKET (${#FOOTPRINT[@]} declared surface(s))"
    # FAIL-CLOSED: a packet we cannot read members out of is not a packet we may approve.
    [ "${#FOOTPRINT[@]}" -gt 0 ] || halt "no MEMBERS/surfaces parsed from $PACKET (fail-closed: an unparseable footprint is never build-class)"
fi

# ---------------------------------------------------------------- data (never literals)
[ -f "$PREDICATE_TSV" ] || halt "operative predicate data MISSING: $PREDICATE_TSV (ARCHITECT-authored — the predicate is not the assembler's to write; without it P1/P2/P4 are unevaluable ⇒ operator pen)"
[ -r "$PREDICATE_TSV" ] || halt "operative predicate data unreadable: $PREDICATE_TSV"

# Only WHOLE-LINE comments are stripped. (Deliberately NOT `s/#.*$//`: an inline '#' inside the
# free-text `why` column would otherwise truncate a real row and silently shrink a governed list.)
# The first non-comment, non-blank line is the column-header line: it is skipped as data, and the `scope` column is found by
# NAME in it. Columns 1/2 (rule, path) are what the predicate reads; the scope column is validated, never used to filter (the
# verdict on every origin set is unchanged). AC-B6: a header with no `scope` column, or a data row whose scope is not
# engine|origin, is UNREADABLE (HALT, fail-closed), never a default.
data_rows() {
    grep -vE '^[[:space:]]*#' "$PREDICATE_TSV" | grep -vE '^[[:space:]]*$' \
      | awk -F'\t' 'NR==1{next} {print}'
}
HDR_LINE="$(grep -vE '^[[:space:]]*#' "$PREDICATE_TSV" | grep -vE '^[[:space:]]*$' | head -n 1)"
SCOPE_IDX="$(printf '%s\n' "$HDR_LINE" | awk -F'\t' '{for(i=1;i<=NF;i++) if($i=="scope"){print i; exit}}')"
[ -n "$SCOPE_IDX" ] || halt "UNREADABLE: $PREDICATE_TSV header line (first non-# line) has no 'scope' column — fail-closed, never a default"
BAD_SCOPE="$(data_rows | awk -F'\t' -v i="$SCOPE_IDX" '{s=$i; sub(/[[:space:]]+$/,"",s); if(s!="engine" && s!="origin"){print $1 " " $2 " scope=[" s "]"}}' | head -n 1)"
[ -z "$BAD_SCOPE" ] || halt "UNREADABLE: $PREDICATE_TSV has a row whose scope is not engine|origin ($BAD_SCOPE) — parse failure, never a default"

read_rule() {
    data_rows | awk -F'\t' -v r="$1" '$1==r{print $2}' | sed -e 's/[[:space:]]*$//' -e '/^$/d'
}

P1_ALLOW=();     while IFS= read -r l; do [ -n "$l" ] && P1_ALLOW+=("$l");     done < <(read_rule P1-ALLOW)
P2_DENY=();      while IFS= read -r l; do [ -n "$l" ] && P2_DENY+=("$l");      done < <(read_rule P2-DENY)
P4_ENFORCER=(); while IFS= read -r l; do [ -n "$l" ] && P4_ENFORCER+=("$l"); done < <(read_rule P4-ENFORCER)

# FAIL-CLOSED on a degenerate list. An empty ALLOW cannot approve anything; an empty ENFORCER list
# would silently stop protecting the authorization model while still reading green.
[ "${#P1_ALLOW[@]}" -gt 0 ]    || halt "P1-ALLOW parsed to ZERO patterns ($PREDICATE_TSV) — fail-closed rather than allow-all"
[ "${#P4_ENFORCER[@]}" -gt 0 ] || halt "P4-ENFORCER parsed to ZERO paths ($PREDICATE_TSV) — an empty exclusion list would silently approve edits to the authorization model"

# glob match helper: pattern 'scripts/**' matches 'scripts/x/y'; exact paths match exactly.
matches() { # $1=path $2=pattern
    local path="$1" pat="$2"
    case "$pat" in
        */\*\*) [[ "$path" == "${pat%\*\*}"* ]] && return 0 ;;
        *\*)    [[ "$path" == ${pat} ]] && return 0 ;;      # shell glob, intentionally unquoted
        *)      [ "$path" = "$pat" ] && return 0 ;;
    esac
    return 1
}
matches_any() { local p="$1"; shift; local pat; for pat in "$@"; do matches "$p" "$pat" && return 0; done; return 1; }

# ---------------------------------------------------------------- ADD-ONLY CLAUSE
ADD_ONLY_ELIGIBLE=(".claude/settings.json" "agents/standing-probes.yaml" "_knowledge/standing-probes.yaml")
ADD_ONLY_EXEMPT=()
ADD_ONLY_NOTES=()

# bash 3.2 note: `${arr[@]}` on a ZERO-element array throws "unbound variable" under `set -u` (fixed only
# in bash >=4.4) — the SAME reason the pre-existing P2_DENY loop below guards with `${#arr[@]} -gt 0`
# before ever expanding `[@]`. ADD_ONLY_EXEMPT starts and often stays empty, so it needs the same guard;
# ADD_ONLY_ELIGIBLE is a fixed 3-element literal and can never be empty.
is_add_only_eligible_path() { local p="$1" q; for q in "${ADD_ONLY_ELIGIBLE[@]}"; do [ "$p" = "$q" ] && return 0; done; return 1; }
is_add_only_exempt()        { local p="$1" q; [ "${#ADD_ONLY_EXEMPT[@]}" -gt 0 ] || return 1; for q in "${ADD_ONLY_EXEMPT[@]}"; do [ "$p" = "$q" ] && return 0; done; return 1; }

# FRAME (auditor 95036032 F1 cure): the gate is consulted only BEFORE a member lands — at `ratify assess`
# / `ratify --standing-class` and in the pre-commit coverage check, where the member's bytes are STAGED.
# So the diff judged is OLD = committed HEAD vs NEW = the STAGED index blob (`:path`) — the member's own
# bytes. The prior frame (last commit touching the path, `c^` vs HEAD) judged the PREVIOUS change and
# exempted the staged one unseen: after one remove-only commit a staged `Bash(*)` allow PASSed.
# Nothing staged (index == HEAD) ⇒ there is no member diff to judge ⇒ the clause does NOT fire (fail-closed
# to P1/P2). The WORKING TREE is never read (an unstaged/untracked edit is not the member).
# $1 = one of ADD_ONLY_ELIGIBLE -> 0 (verified add-only) | 1 (not add-only, or unevaluable -> fail-closed)
add_only_diff_ok() {
    local p="$1" hb ib tf_old tf_new rc out
    hb="$(git rev-parse -q --verify "HEAD:$p" 2>/dev/null)" || { ADD_ONLY_NOTES+=("$p: absent at HEAD — cannot evaluate"); return 1; }
    ib="$(git rev-parse -q --verify ":$p" 2>/dev/null)"     || { ADD_ONLY_NOTES+=("$p: absent from the index (staged deletion?) — cannot prove add-only"); return 1; }
    [ "$hb" != "$ib" ] || { ADD_ONLY_NOTES+=("$p: nothing staged (index == HEAD ${hb:0:8}) — no member diff to judge; clause does not fire"); return 1; }
    tf_old="$(mktemp)" || { ADD_ONLY_NOTES+=("$p: mktemp failed"); return 1; }
    tf_new="$(mktemp)" || { rm -f "$tf_old"; ADD_ONLY_NOTES+=("$p: mktemp failed"); return 1; }
    git cat-file blob "$hb" > "$tf_old" 2>/dev/null
    git cat-file blob "$ib" > "$tf_new" 2>/dev/null
    case "$p" in
        .claude/settings.json)
            out="$(python3 - "$tf_old" "$tf_new" <<'PYEOF'
import copy, json, sys
from collections import Counter


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def canon(x):
    return json.dumps(x, sort_keys=True, default=str)


try:
    old = load(sys.argv[1])
    new = load(sys.argv[2])
    if not isinstance(old, dict) or not isinstance(new, dict):
        raise ValueError("top level must be a JSON object")

    old_perm = old.get("permissions", {})
    new_perm = new.get("permissions", {})
    old_perm = old_perm if isinstance(old_perm, dict) else {}
    new_perm = new_perm if isinstance(new_perm, dict) else {}
    old_deny = old_perm.get("deny", [])
    new_deny = new_perm.get("deny", [])
    if not isinstance(old_deny, list) or not isinstance(new_deny, list):
        raise ValueError("permissions.deny must be a list")
    oc, nc = Counter(old_deny), Counter(new_deny)
    deny_ok = all(nc[k] >= v for k, v in oc.items())

    # permissions.allow may only SHRINK (remove-only = tightening).
    # Any allow entry present in NEW beyond its count in OLD is an ADDITION ⇒ operator pen.
    old_allow = old_perm.get("allow", [])
    new_allow = new_perm.get("allow", [])
    if not isinstance(old_allow, list) or not isinstance(new_allow, list):
        raise ValueError("permissions.allow must be a list")
    oac, nac = Counter(old_allow), Counter(new_allow)
    allow_ok = all(oac[k] >= v for k, v in nac.items())

    old_hooks = old.get("hooks", {})
    new_hooks = new.get("hooks", {})
    hooks_ok = isinstance(old_hooks, dict) and isinstance(new_hooks, dict)
    if hooks_ok:
        for k, v in old_hooks.items():
            if k not in new_hooks:
                hooks_ok = False
                break
            ov = v if isinstance(v, list) else [v]
            nv = new_hooks[k] if isinstance(new_hooks[k], list) else [new_hooks[k]]
            ocnt = Counter(canon(x) for x in ov)
            ncnt = Counter(canon(x) for x in nv)
            if not all(ncnt[ck] >= cv for ck, cv in ocnt.items()):
                hooks_ok = False
                break

    patched = copy.deepcopy(old)
    if not isinstance(patched.get("permissions"), dict):
        patched["permissions"] = {}
    patched["permissions"]["deny"] = new_deny
    if "allow" in old_perm or "allow" in new_perm:
        patched["permissions"]["allow"] = new_allow
    patched["hooks"] = new_hooks if isinstance(new_hooks, dict) else old_hooks
    nothing_else_changed = canon(patched) == canon(new)

    ok = deny_ok and allow_ok and hooks_ok and nothing_else_changed
    print("deny_ok=%s allow_ok=%s hooks_ok=%s nothing_else_changed=%s (deny +%d, allow -%d)" % (
        deny_ok, allow_ok, hooks_ok, nothing_else_changed, sum((nc - oc).values()),
        sum((oac - nac).values())))
    sys.exit(0 if ok else 1)
except Exception as ex:
    print("exception: %s" % ex)
    sys.exit(1)
PYEOF
)"; rc=$? ;;
        agents/standing-probes.yaml|_knowledge/standing-probes.yaml)
            out="$(python3 - "$tf_old" "$tf_new" <<'PYEOF'
import json, sys
try:
    import yaml
except Exception as ex:
    print("PyYAML unavailable: %s" % ex)
    sys.exit(1)


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def canon(x):
    return json.dumps(x, sort_keys=True, default=str)


try:
    old = load(sys.argv[1]) or {}
    new = load(sys.argv[2]) or {}
    old_list = old.get("standing_probes")
    new_list = new.get("standing_probes")
    if not isinstance(old_list, list) or not isinstance(new_list, list):
        raise ValueError("standing_probes must be a list in both versions")

    def index_by_id(lst):
        m = {}
        for e in lst:
            if not isinstance(e, dict) or "id" not in e:
                raise ValueError("a standing_probes entry is missing 'id'")
            eid = e["id"]
            if eid in m:
                raise ValueError("duplicate id: %s" % eid)
            m[eid] = e
        return m

    old_m, new_m = index_by_id(old_list), index_by_id(new_list)
    removed = [e for e in old_m if e not in new_m]
    changed = [e for e in old_m if e in new_m and canon(old_m[e]) != canon(new_m[e])]
    added = [e for e in new_m if e not in old_m]
    ok = not removed and not changed
    print("added=%d removed=%s changed=%s" % (
        len(added), ",".join(removed) or "none", ",".join(changed) or "none"))
    sys.exit(0 if ok else 1)
except Exception as ex:
    print("exception: %s" % ex)
    sys.exit(1)
PYEOF
)"; rc=$? ;;
        *) out="unsupported add-only path"; rc=1 ;;
    esac
    rm -f "$tf_old" "$tf_new"
    ADD_ONLY_NOTES+=("$p (HEAD..index): $([ "$rc" -eq 0 ] && echo PASS || echo FAIL) — $out")
    return $rc
}

# Group the packet's MEMBERS by member (never the flattened FOOTPRINT, which has lost member boundaries):
# "a member whose ONLY surfaces are…" is a per-member test. A member with even ONE non-eligible surface
# gets NO exemption for ANY of its paths — the rest of that member's footprint is unaffected.
if [ -n "${PACKET:-}" ]; then
    while IFS= read -r memline; do
        msurf="$(printf '%s\n' "$memline" | sed -n 's/.*surfaces:[[:space:]]*//p')"
        [ -n "$msurf" ] || continue
        msurf="${msurf//,/ }"
        MPATHS=()
        for p in $msurf; do
            case "$p" in ''|'·') continue ;; esac
            MPATHS+=("$p")
        done
        [ "${#MPATHS[@]}" -gt 0 ] || continue
        all_eligible=1
        for p in "${MPATHS[@]}"; do is_add_only_eligible_path "$p" || { all_eligible=0; break; }; done
        [ "$all_eligible" -eq 1 ] || continue
        member_ok=1
        for p in "${MPATHS[@]}"; do add_only_diff_ok "$p" || member_ok=0; done
        [ "$member_ok" -eq 1 ] || continue
        for p in "${MPATHS[@]}"; do ADD_ONLY_EXEMPT+=("$p"); done
    done < <(sed -n '/^## MEMBERS/,/^## /p' "$PACKET" | grep -E '^- .*surfaces:')
fi

# ---------------------------------------------------------------- evaluate P1..P4
VERDICT=0
P1_BAD=(); P2_BAD=(); P4_BAD=()

# EVAL PRECEDENCE: DENY (P2 + P4) BEATS ALLOW (P1).
# A carve-out file sitting INSIDE a P1 glob is NOT build-class — e.g. `agents/**` is allowed while
# `agents/pre-commit-hook.sh` is a P4-ENFORCER, so the broad allow must never rescue the carve-out.
# Each rule is evaluated independently and every violation is reported, so a failing set names ALL
# the reasons at once rather than one-at-a-time across reruns.
# ADD-ONLY CARVE-IN: P4 is evaluated UNCONDITIONALLY for every path, exempt or not — the
# clause never touches P4 (by construction none of ADD_ONLY_ELIGIBLE is ever a P4-ENFORCER row). P1/P2 are
# skipped only for a path THIS RUN proved add-only (ADD_ONLY_EXEMPT); every other path takes the unchanged
# path below, byte-identical to pre-§3b behaviour.
for p in "${FOOTPRINT[@]}"; do
    if matches_any "$p" "${P4_ENFORCER[@]}"; then P4_BAD+=("$p"); fi
    if is_add_only_exempt "$p"; then continue; fi
    if [ "${#P2_DENY[@]}" -gt 0 ] && matches_any "$p" "${P2_DENY[@]}"; then P2_BAD+=("$p"); fi
    # P1 is a membership test, not a veto: an occupant matching NO allow-glob is undeclared ⇒ refused.
    if ! matches_any "$p" "${P1_ALLOW[@]}"; then P1_BAD+=("$p"); fi
done

# P3 — irreversibility. NOT fully derivable from a footprint, so it is fail-closed on a DECLARATION:
# the packet must carry an explicit 'p3-reversible: YES' line. An assembler assertion is a weak
# control and is labelled as such here rather than dressed up: the auditor reproduces it post-merge
# (AC-B4). Absent/!=YES ⇒ NOT build-class. The footprint-derived half is already covered by P2.
P3_OK=0
if [ "${1:-}" != "--footprint" ] && [ -n "${PACKET:-}" ]; then
    if grep -qiE '^[[:space:]]*-?[[:space:]]*p3-reversible:[[:space:]]*YES[[:space:]]*$' "$PACKET"; then P3_OK=1; fi
else
    P3_OK=2   # ad-hoc footprint preview: P3 is undeterminable without a packet
fi

# ---------------------------------------------------------------- report
echo "── build-class predicate (SPEC-BUILD-CLASS-STANDING-APPROVAL §1) ──"
echo "   source:   $SRC_DESC"
echo "   data:     $PREDICATE_TSV (${#P1_ALLOW[@]} P1-ALLOW · ${#P2_DENY[@]} P2-DENY · ${#P4_ENFORCER[@]} P4-ENFORCER; DENY beats ALLOW)"
if [ "${#ADD_ONLY_NOTES[@]}" -gt 0 ]; then
    echo "   add-only:"
    for n in "${ADD_ONLY_NOTES[@]}"; do echo "     $n"; done
fi
if [ "${#ADD_ONLY_EXEMPT[@]}" -gt 0 ]; then
    echo "   add-only exempt (P1/P2 bypassed for these paths only): ${ADD_ONLY_EXEMPT[*]}"
fi

if [ "${#P1_BAD[@]}" -gt 0 ]; then fail "P1 footprint outside the governance-plumbing allowlist: ${P1_BAD[*]}"; VERDICT=1; fi
if [ "${#P2_BAD[@]}" -gt 0 ]; then fail "P2 touches a spend/custody/publish/data/authz surface: ${P2_BAD[*]}"; VERDICT=1; fi
if [ "${#P4_BAD[@]}" -gt 0 ]; then fail "P4 touches the AUTHORIZATION MODEL (manifest path — document, enforcer, this gate, or the manifest itself): ${P4_BAD[*]}"; VERDICT=1; fi
case "$P3_OK" in
    0) fail "P3 reversibility NOT DECLARED in packet (need a 'p3-reversible: YES' line) — fail-closed"; VERDICT=1 ;;
    2) fail "P3 undeterminable from an ad-hoc footprint (no packet) — fail-closed; run against the packet"; VERDICT=1 ;;
esac

if [ "$VERDICT" -eq 0 ]; then
    echo "build-class: PASS — P1 ✓ P2 ✓ P3 ✓ P4 ✓ (standing class applies; NO per-set operator pen)"
    exit 0
fi
echo "build-class: FAIL — NOT build-class ⇒ OPERATOR PEN REQUIRED (WHAT-class)"
exit 1
