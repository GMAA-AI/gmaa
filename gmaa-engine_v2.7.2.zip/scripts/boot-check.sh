#!/usr/bin/env bash
# scripts/boot-check.sh — boot-discipline PRESENCE + live-currency gate.
# Canonical, ALL-LANES. ONE script; every lane's
# _boot/BOOTSTRAP.md adds only the CALL, never the logic. Also invoked by the harness
# SessionStart hook (settings.json) so PRESENCE is harness-enforced, not agent willpower.
#
# WHAT IT FIXES: the old resolve-lane STALE-BOOT nudge was a
# FALSE-GREEN — soft (non-fatal, stderr-swallowed by `eval "$(resolve-lane.sh)"`),
# CHECKLIST-age-only, and keyed on a SELF-STAMPED DATE (one stamp bought 7d of silence).
# This gate measures a *read* not an *edit*: currency = a live git-delta anchored on the
# DELIBERATE `absorbed_through_sha:` marker, and it EMITS a visible line
# with LIVE values so a stale state is self-evident on its face (Q3).
#
# TEETH: Tier 1 (this visible mandatory emit) + Tier 2 (harness inject).
# Layer 3 = the creed linter (scripts/creed-scan.sh): a boundary-time DETECT-AND-SURFACE scan, never a block. This file is a SURFACE:
# it exits 0 except for the BOOT-RECORD HALT (section 7: rc 3 = BOOT_RECORD_HALT_RC, printed after every other line), and
# settings.json runs it under `|| true`. Its warnings instruct; they do not stop anything.
#
# EXIT CONTRACT (the whole of it): rc 0, or rc BOOT_RECORD_HALT_RC (3) when section 7 prints `BOOT-RECORD: HALT missing=` or
# `BOOT-RECORD: UNREADABLE`, or section 9 prints `SEAT-HOST-HALT` (then the LAST line); no other exit leaves 0. The harness SessionStart hook runs it under `|| true`
# and never sees the rc. A caller that RUNS boot-check to MEASURE its output (a byte count, a line census, a grep of a
# captured file) passes `--measure`: the run is the same run, its output is printed byte-identical (stdout+stderr merged on
# stdout), and the exit is 0 iff rc was 0, or rc was BOOT_RECORD_HALT_RC with exactly one `^BOOT-RECORD: HALT missing=` line
# AND exactly one `^[creed-scan source: ` line (the section-5 line; a probe that stops short of it is not complete). Any other
# rc, rc 3 with no HALT line (UNREADABLE), or rc 3 with no completion line keeps its non-zero rc, fail-closed, with a
# BOOT-CHECK-MEASURE: REFUSED line on stderr. This is the ONE definition of that acceptance; callers do not re-implement it.
set -uo pipefail
BOOT_RECORD_HALT_RC=3
BOOT_MEASURE_FAULT_RC=2
if [[ "${1:-}" == "--measure" ]]; then
  _bm_f="$(mktemp "${TMPDIR:-/tmp}/bootcheck-measure.XXXXXX")" \
    || { echo "BOOT-CHECK-MEASURE: UNREADABLE -- mktemp failed" >&2; exit "$BOOT_MEASURE_FAULT_RC"; }
  bash "${BASH_SOURCE[0]}" > "$_bm_f" 2>&1; _bm_rc=$?
  cat "$_bm_f"
  _bm_halt="$(grep -c '^BOOT-RECORD: HALT missing=' "$_bm_f")"; _bm_done="$(grep -c '^\[creed-scan source: ' "$_bm_f")"
  rm -f "$_bm_f"
  if [[ $_bm_rc -eq 0 ]]; then exit 0; fi
  if [[ $_bm_rc -eq $BOOT_RECORD_HALT_RC && "$_bm_halt" == 1 && "$_bm_done" == 1 ]]; then exit 0; fi
  echo "BOOT-CHECK-MEASURE: REFUSED -- rc=${_bm_rc} halt_lines=${_bm_halt} completion_lines=${_bm_done} (accepted only at rc 0, or rc ${BOOT_RECORD_HALT_RC} with exactly one BOOT-RECORD: HALT line and exactly one completion line)" >&2
  exit "$_bm_rc"
fi
SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"   # beside this script only (0507 R2); resolved before the cd below
WT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
cd "$WT_ROOT" || exit 0
lane="$(sed -n 's/^lane:[[:space:]]*//p' _boot/BOOTSTRAP.md 2>/dev/null | head -1)"; lane="${lane:-unknown}"

# (1) disciplines §0 PRESENCE — surface the all-seats roster. Under the Tier-2 SessionStart
#     hook this stdout is injected into context, making `disciplines=§0-loaded` true-by-
#     construction (standing-guard #3), not a claim.
# === READ THE GOVERNANCE SURFACE FROM THE SPINE, NOT THE READER'S OWN BRANCH. ===
# This previously read `disciplines.md` by RELATIVE path, so "the roster loaded at boot" was really
# "the roster ON THIS LANE'S BRANCH". Measured 2026-09-14: 6 of 6 lane branches booted
# on a roster 3-10 entries stale while the spine was current, and the STALEST was the architect — the
# seat that cites these entries in every ruling it writes.
# Adopting FROM TRUNK at read-time needs NO write: the lane commits nothing, its tree stays clean, and
# the spine-protected surface is never edited by a lane. Same principle as `.claude/agents/`
# (canonical-from-trunk, non-divergeable) applied at boot instead of at merge.
[[ -f "$SPINE_REF_SH" ]] || { echo "HALT(boot-check): SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2); no boot surface can be read from the spine (inv #5: no literal fallback)"; exit 3; }
GOV_REF="$(bash "$SPINE_REF_SH")" && [[ -n "$GOV_REF" ]] || { echo "HALT(boot-check): SPINE-REF-UNRESOLVED -- $SPINE_REF_SH is unfilled; no boot surface can be read from the spine (the one spine-ref resolver; inv #5: no literal fallback)"; exit 3; }  # the ONE resolver (the TRUNK_BRANCH slot)
GOV_SRC="SPINE(${GOV_REF})"
# === the boot roster is GENERATED at _index/boot-roster.md by
# scripts/gen-boot-roster.sh from disciplines.md §R + _index/annotations.tsv. §0 is a pointer stub. This used
# to print a hand-kept §0 body (27,788 B); it now prints the generated roster (E2 bar 8,192 B), still SPINE-read.
ROSTER_PATH="_index/boot-roster.md"
GOV_TEXT="$(git show "${GOV_REF}:${ROSTER_PATH}" 2>/dev/null)"
if [[ -z "${GOV_TEXT}" ]]; then
  GOV_TEXT="$(cat "${ROSTER_PATH}" 2>/dev/null)"
  GOV_SRC="LOCAL-FALLBACK(${GOV_REF} unreadable — roster may be STALE)"
fi
echo "── boot roster (${ROSTER_PATH}, generated from disciplines.md §R) — all-seats standing roster [source: ${GOV_SRC}] (load every boot; full text §R/§1, retrieve on trigger) ──"
if [[ "${GOV_SRC}" == LOCAL-FALLBACK* ]]; then
  echo "  ⚠ SURFACE-WARN (not a halt): could not read ${GOV_REF}:${ROSTER_PATH} — falling back to THIS BRANCH's copy, which may be STALE. Fetch, then re-run; do NOT treat the roster below as current."
fi
if ! printf '%s\n' "${GOV_TEXT}" | grep -E '^- \*\*DISC'; then
  echo "  ⚠ SURFACE-WARN (not a halt): boot roster not found (${ROSTER_PATH}) — investigate before proceeding (do not silently degrade)."
fi
# Drift signal: a lane whose own copy differs from the spine is told so EXPLICITLY rather than
# discovering it when a successor audits the fleet.
_gov_local="$(grep -cE '^- \*\*DISC' "${ROSTER_PATH}" 2>/dev/null || true)"; _gov_local="${_gov_local:-0}"
_gov_spine="$(printf '%s\n' "${GOV_TEXT}" | grep -cE '^- \*\*DISC' || true)"
if [[ "${_gov_local}" != "${_gov_spine}" ]]; then
  echo "  ⚠ ROSTER-DRIFT: this branch carries ${_gov_local} §0 entries, the spine carries ${_gov_spine}. The roster ABOVE is the spine's (authoritative); your branch copy is stale and will be adopted at the next currency-sync."
fi
# Staleness of the SPINE roster against the SPINE's own sources (0292 §4: no hand-maintained roster may drift).
# Runs the spine's generator over the spine's sources, so a lane's stale branch copy cannot mask it. Warn only.
if [[ "${GOV_SRC}" == SPINE* ]]; then
  _gen="$(git show "${GOV_REF}:scripts/gen-boot-roster.sh" 2>/dev/null)"
  if [[ -n "${_gen}" ]]; then
    _fresh="$(bash -c "${_gen}" gen-boot-roster.sh render --ref "${GOV_REF}" 2>/dev/null)" || _fresh=""
    if [[ -z "${_fresh}" ]]; then
      echo "  ⚠ ROSTER-STALE-CHECK: could not render ${GOV_REF}'s roster from its sources (generator refused) — run 'bash scripts/gen-boot-roster.sh render --ref ${GOV_REF}' to see why."
    elif [[ "${_fresh}" != "${GOV_TEXT}" ]]; then
      echo "  ⚠ ROSTER-STALE: ${GOV_REF}:${ROSTER_PATH} does not match a fresh render of ${GOV_REF}'s own sources — foundation runs 'scripts/gen-boot-roster.sh build' and lands it."
    fi
  fi
fi

# (2) register open-count — a PRESENCE signal, INDICATIVE not authoritative. The register is a
#     HYPOTHESIS surface (inv#4): the emit proves it's in-view; it does NOT license routing on
#     the raw count without a grep-closeout.
#     Window-plan row 11: HTML-comment templates are excluded (never count a template as data). The strip
#     removes ONLY the `<!-- … -->` spans (multi-line or inline). NOT the 2.5.7 extract's `sed '/<!--/,/-->/d'`:
#     a range that opens on a one-line comment runs to the NEXT `-->` line, so at 855f1b21 it deleted
#     issues_register.md:2657 to EOF (kept 2656 of 3503 lines; 47 -> 45). An unclosed `<!--` is kept (over-count,
#     never a silent drop). perl absent -> the count is UNREADABLE, never the unstripped number.
if command -v perl >/dev/null 2>&1 && [[ -r issues_register.md ]]; then
  OPEN=$(perl -0777 -pe 's/<!--.*?-->//gs' issues_register.md | grep -oiE '\*\*Status:\*\* *\**open' | wc -l | tr -d ' ')
else
  OPEN="UNREADABLE"
fi
[[ -z "$OPEN" ]] && OPEN="?"

# (3) CHECKLIST currency — LIVE git-delta anchored on the DELIBERATE absorbed_through_sha (Q2).
#     NOT `git log -1 CHECKLIST.md` (which false-greens on any cosmetic edit).
ANCHOR=$(sed -n 's/^\*\*absorbed_through_sha:\*\*[[:space:]]*//p' CHECKLIST.md 2>/dev/null | grep -oE '[0-9a-f]{7,40}' | head -1)
if [[ -n "$ANCHOR" ]] && git cat-file -e "$ANCHOR" 2>/dev/null; then
  DELTA=$(git rev-list --count "${ANCHOR}..HEAD" -- CHECKLIST.md issues_register.md disciplines.md _rulings dispatch 2>/dev/null || echo "?")
  ANCHOR_SHOW="${ANCHOR:0:8}"
else
  DELTA="NO-ANCHOR"; ANCHOR_SHOW="unset"
fi
RELAYS=$(find dispatch -maxdepth 1 -name 'RELAY*.md' ! -name 'RELAY-TO-*' -newer CHECKLIST.md 2>/dev/null | wc -l | tr -d ' ')

# (Q3) emit — LIVE values, never a fixed "OK". Absence of this line on a boot = protocol omission.
echo "BOOT-CHECK: lane=${lane} disciplines=§0-loaded register=${OPEN}-open(indicative;grep-closeout-before-routing) checklist-delta=${DELTA}-commits-since-${ANCHOR_SHOW} relays-newer=${RELAYS}"

# (Q3b) MODE-CHECK — window-plan row 10 (canon §7.1 step 6 + §8).
#   This hook can print only the CONFIGURED mode: the SessionStart stdin carries no `permission_mode` (measured
#   2026-10-06: 5 keys, cwd/hook_event_name/session_id/source/transcript_path). The OBSERVED mode is the
#   `OBSERVED-MODE:` line that scripts/observed-mode.sh prints from the UserPromptSubmit stdin at the first prompt.
#   A launch flag overrides the configured default, so the two lines may differ; that difference is the receipt.
MODE_CFG="$(jq -r '.permissions.defaultMode // "unset"' "$WT_ROOT/.claude/settings.json" 2>/dev/null)" || MODE_CFG=""
[[ -n "$MODE_CFG" ]] || MODE_CFG="UNREADABLE"
echo "MODE-CHECK: configured=${MODE_CFG} (CONFIGURED-NOT-OBSERVED; observed = the OBSERVED-MODE line at the first prompt, UserPromptSubmit stdin)"

# (4) HOOK-CURRENCY (SET-AUTH-IMPL-01 item 2; C-SET-AUTHORIZATION §2) — the installed pre-commit
#     spine gate MUST be byte-current with its source; a stale/absent/inert gate SILENTLY PASSES
#     (invariant #5). Emitted at EVERY boot with LIVE values so the M6(i) set-coverage gate can never
#     go inert unnoticed (the motivating defect: M6(i) source committed f-368 but not installed → the
#     gate did not fire). The fail-closed-AT-THE-WIRE complement (a self-verifying hook that REFUSES
#     commits on drift + auto-install) activates at install time — see the SET-AUTH-IMPL-01 report.
HOOK_SRC="$WT_ROOT/agents/pre-commit-hook.sh"
HOOKS_DIR="$(git config --get core.hooksPath 2>/dev/null)"
if [[ -n "$HOOKS_DIR" ]]; then
  case "$HOOKS_DIR" in /*) : ;; *) HOOKS_DIR="$WT_ROOT/$HOOKS_DIR" ;; esac   # relative → resolve to worktree root
else
  HOOKS_DIR="$(git rev-parse --path-format=absolute --git-common-dir 2>/dev/null)/hooks"
fi
INSTALLED_HOOK="$HOOKS_DIR/pre-commit"
# The installed hooks live in the SHARED $GIT_COMMON_DIR/hooks and are canonical on the SPINE. Compare to
# the spine ref's bytes (GOV_REF), never this worktree's branch copy: a lane whose branch copy is stale used to read DRIFT
# for a hook that was fine (the architect's standing pre-merge-commit=DRIFT).
_hook_state() {  # <installed-path> <spine-path>
  local canon
  canon="$(git rev-parse -q --verify "${GOV_REF}:$2" 2>/dev/null)" || { echo "NO-SOURCE"; return; }
  [[ -f "$1" ]] || { echo "ABSENT"; return; }
  [[ "$(git hash-object "$1" 2>/dev/null)" == "$canon" ]] || { echo "DRIFT"; return; }
  # Byte-canonical but without its exec bit, git skips the hook: it is dead, never CURRENT (the installer re-arms it).
  if [[ -x "$1" ]]; then echo "CURRENT"; else echo "NOT-EXEC"; fi
}
HOOK_STATE="$(_hook_state "$INSTALLED_HOOK" agents/pre-commit-hook.sh)"
if [[ -f "$INSTALLED_HOOK" ]] && grep -q 'set-coverage gate (M6(i)' "$INSTALLED_HOOK" 2>/dev/null; then M6I="installed"; else M6I="NOT-installed"; fi
# Forced merge-path (SET-AUTH-IMPL-01 item 3, §2): the pre-merge-commit hook must also be byte-current
# with its source — an absent/stale pre-merge-commit hook SILENTLY lets a raw `git merge` bypass M6(ii).
PMC_SRC="$WT_ROOT/agents/pre-merge-commit-hook.sh"
INSTALLED_PMC="$HOOKS_DIR/pre-merge-commit"
PMC_STATE="$(_hook_state "$INSTALLED_PMC" agents/pre-merge-commit-hook.sh)"
CMSG_STATE="$(_hook_state "$HOOKS_DIR/commit-msg" agents/commit-msg-hook.sh)"   # commit-time gate
echo "HOOK-CHECK: pre-commit=${HOOK_STATE} M6(i)-set-coverage=${M6I} pre-merge-commit=${PMC_STATE} commit-msg=${CMSG_STATE}"
if [[ "$HOOK_STATE" != "CURRENT" || "$M6I" != "installed" || "$PMC_STATE" != "CURRENT" || "$CMSG_STATE" != "CURRENT" ]]; then
  echo "  ⚠ SURFACE-WARN (not a halt; C-SET-AUTHORIZATION §2 · invariant #5): spine gates NOT fully enforcing — pre-commit=${HOOK_STATE}/${M6I}, pre-merge-commit=${PMC_STATE} (forced merge-path). A stale/absent gate SILENTLY PASSES (M6(i) coverage) or lets a raw \`git merge\` bypass M6(ii) (pre-merge-commit). Re-install with scripts/install_pre_commit_hook.sh, then re-run for 'pre-commit=CURRENT M6(i)-set-coverage=installed pre-merge-commit=CURRENT'. Do NOT rely on the gates until then."
fi

# ── (4a) SURFACE-CONFORMANCE — the pre-genesis compensating control (canon v1.6.5 §4 :158) ─────────────────────
# The compensating control for STATE-PRE-GENESIS: per-worktree blob equality over every surface READ FROM THE
# WORKTREE, run from SPINE bytes (scripts/surface-conformance-spine.sh — the creed-scan-spine.sh mirror, so the
# probe reaches every lane with no per-lane sync). A LINE, never a halt (canon :156; exit 0 except the BOOT-RECORD HALT, rc 3, the last line printed; see header).
# The SURFACE-WARN line above is RETAINED (preservation pole); what this adds is a RECORDED verdict.
# HYGIENE (CLAUDE.md B6.5): the boot shows the verdict, a per-worktree RED census and at most 10 RED rows —
# (the census keys on the row-INITIAL `worktree=`: each row carries `worktree=` twice -- the lane worktree, then the
#  worktree blob -- and a greedy `.* worktree=` grouped by blob; ISSUE-BOOT-CHECK-RED-CENSUS-GROUPS-BY-BLOB)
# never the full row set (the standing probe ledgers that). A runner fault prints its UNREADABLE line verbatim.
if [[ -f "$WT_ROOT/scripts/surface-conformance-spine.sh" ]] || git cat-file -e "${GOV_REF}:scripts/surface-conformance-spine.sh" 2>/dev/null; then
  _sc_run="$WT_ROOT/scripts/surface-conformance-spine.sh"
  [[ -f "$_sc_run" ]] || { _sc_run="$(mktemp -d "${TMPDIR:-/tmp}/scrun.XXXXXX")/surface-conformance-spine.sh"; git show "${GOV_REF}:scripts/surface-conformance-spine.sh" > "$_sc_run" 2>/dev/null; cp "$SPINE_REF_SH" "${_sc_run%/*}/spine-ref.sh" 2>/dev/null; }   # the spine copy runs beside this script's resolver (0507 R2)
  # Window-plan row 16 (canon §4: executing copy == canonical, PER WORKTREE): a seat's boot measures ITS OWN
  # worktree (the probe's --worktree, forwarded by the runner), not the whole fleet. The fleet view stays one
  # explicit command away (`bash scripts/surface-conformance-spine.sh`) and in the standing probe.
  _sc_out="$(bash "$_sc_run" --red-only --worktree "$WT_ROOT" 2>&1)"; _sc_rc=$?
  _sc_verdict="$(printf '%s\n' "$_sc_out" | grep -E '^VERDICT:|^SURFACE-CONFORM: UNREADABLE' | head -1)"
  _sc_denom="$(printf '%s\n' "$_sc_out" | grep -E '^SURFACE-CONFORM: [0-9]+ rows over' | head -1)"
  echo "SURFACE-CONFORM-CHECK: rc=${_sc_rc} · ${_sc_verdict:-UNREADABLE — runner emitted no verdict (exit ${_sc_rc})} · ${_sc_denom#SURFACE-CONFORM: }"
  if [[ ${_sc_rc} -eq 1 ]]; then
    printf '%s\n' "$_sc_out" | grep -E '^SURFACE-CONFORM: worktree=' | sed -E 's/^SURFACE-CONFORM: worktree=([^ ]+) .* verdict=([A-Z-]+).*/\1 \2/' | sort | uniq -c | awk '{printf "    RED %s × %s %s\n", $1, $2, $3}'
    printf '%s\n' "$_sc_out" | grep -E '^SURFACE-CONFORM: worktree=' | head -10 | sed 's/^/    /'
    echo "    (full rows: bash scripts/surface-conformance-spine.sh — the standing probe ledgers the verdict)"
  fi
else
  echo "SURFACE-CONFORM-CHECK: not-yet-at-${GOV_REF} (the conformance probe runner is absent at the spine and locally)"
fi

# ── (4a') GOVERNANCE PROBES — the spine runner fires on every lane at boot, which is what
# "wired" means. One summary line + any non-PASS probe line. A line, never a halt (exit 0 except the BOOT-RECORD HALT, rc 3, the last line printed; see header).
if [[ -f "$WT_ROOT/scripts/governance-probes-spine.sh" ]] || git cat-file -e "${GOV_REF}:scripts/governance-probes-spine.sh" 2>/dev/null; then
  _gp_run="$WT_ROOT/scripts/governance-probes-spine.sh"
  [[ -f "$_gp_run" ]] || { _gp_run="$(mktemp -d "${TMPDIR:-/tmp}/gprun.XXXXXX")/governance-probes-spine.sh"; git show "${GOV_REF}:scripts/governance-probes-spine.sh" > "$_gp_run" 2>/dev/null; cp "$SPINE_REF_SH" "${_gp_run%/*}/spine-ref.sh" 2>/dev/null; }   # the spine copy runs beside this script's resolver (0507 R2)
  _gp_out="$(bash "$_gp_run" 2>&1)"; _gp_rc=$?
  echo "GOV-PROBES-CHECK: rc=${_gp_rc} · $(printf '%s\n' "$_gp_out" | grep -E '^GOV-PROBES:' | tail -1 | sed 's/^GOV-PROBES: //')"
  printf '%s\n' "$_gp_out" | grep -E '^GOV-PROBE: ' | grep -v 'rc=0 VERDICT: PASS' | sed 's/^/    /'
fi

# ── (4a'') AUDITOR LIVENESS — finding 2: the WIRED NON-AUDITOR CALLER ─────────────────────
# probe_auditor_liveness_v1.py is exclude_from_auditor BY DESIGN (a dead auditor cannot run its own liveness check),
# so its caller must be outside the auditor and mechanized: this boot line. It runs the SPINE's probe bytes (like the
# lines above) against THIS worktree's working ledger (AUDITOR_LIVENESS_ROOT), because the working audit-runs.log is
# the probe's input. Scope: the audit hub only (lane=foundation), where the post-commit auditor writes that ledger;
# other lanes print the scope line, never a PASS. A LINE, never a halt (exit 0 except the BOOT-RECORD HALT, rc 3, the last line printed; see header); rc 1 = FAIL, rc 3 = UNREADABLE.
_al_path="probes/foundation/probe_auditor_liveness_v1.py"
if [[ "$lane" != "foundation" ]]; then
  echo "AUDITOR-LIVENESS-CHECK: n/a on lane=${lane} (scope: the audit hub, lane=foundation, whose working ledger the probe reads) — NOT a PASS"
elif [[ -f "$WT_ROOT/$_al_path" ]] || git cat-file -e "${GOV_REF}:${_al_path}" 2>/dev/null; then
  _al_run="$(mktemp "${TMPDIR:-/tmp}/alrun.XXXXXX")"; _al_src="SPINE(${GOV_REF})"
  git show "${GOV_REF}:${_al_path}" > "$_al_run" 2>/dev/null || { cp "$WT_ROOT/$_al_path" "$_al_run"; _al_src="LOCAL-FALLBACK(${GOV_REF} unreadable)"; }
  _al_out="$(AUDITOR_LIVENESS_ROOT="$WT_ROOT" python3 "$_al_run" 2>&1)"; _al_rc=$?
  rm -f "$_al_run"
  echo "AUDITOR-LIVENESS-CHECK: rc=${_al_rc} · $(printf '%s\n' "$_al_out" | grep -E '^VERDICT:' | tail -1) [source: ${_al_src}]"
  [[ ${_al_rc} -eq 0 ]] || printf '%s\n' "$_al_out" | grep -vE '^VERDICT:' | sed 's/^/    /'
else
  echo "AUDITOR-LIVENESS-CHECK: UNREADABLE — ${_al_path} absent at ${GOV_REF} and locally"
fi

# ── (4a''') AUDIT-READ SCOPE — P-A, loop-cure member A4 ───────────────────────────────────────────────
# A boot reads the handoff + dispatch/LATEST.md + the inbox. Audit passes are read ONLY if they carry an F or a
# DIVERGED. This line lists them, over the audit blocks naming a commit in absorbed_through_sha..HEAD. An F is a
# `### F<n>` heading, a DIVERGED/FAIL verdict, or a code finding NOT classed `logged` by A3 (an unclassed legacy
# finding counts: fails toward MORE reading). An unresolvable anchor says UNREADABLE and asks for every pass.
if [[ "${lane:-}" == foundation ]]; then
  if [[ -n "${ANCHOR:-}" ]] && git cat-file -e "${ANCHOR}^{commit}" 2>/dev/null && [[ -r ledger/audit-findings.md ]]; then
    _ar_out="$(git rev-list "${ANCHOR}..HEAD" | python3 -c '
import re, sys
win = set(l.strip() for l in sys.stdin if l.strip())
def inwin(h): return any(w.startswith(h) for w in win)
blocks = []; cur = None
for n, line in enumerate(open("ledger/audit-findings.md", encoding="utf-8", errors="replace"), 1):
    m = re.match(r"## (LLM|Code) audit\S*\s[^`]*`([0-9a-f]{7,40})`", line)
    if m:
        cur = {"kind": m.group(1), "sha": m.group(2), "line": n, "f": False}; blocks.append(cur); continue
    if cur is None: continue
    if re.match(r"### F[0-9]", line) or re.match(r"\*\*Verdict for .*DIVERGED", line) or re.match(r"\*\*Verdict for `[^`]+`[^:]*:\**\s*FAIL\b", line): cur["f"] = True
    if cur["kind"] == "Code" and re.match(r"\s*- FINDING ", line) and "[A3 class=logged]" not in line: cur["f"] = True
inw = [b for b in blocks if inwin(b["sha"])]
hit = [b for b in inw if b["f"]]
print("%d %d %s" % (len(hit), len(inw), " ".join("%s@:%d(%s)" % (b["sha"][:8], b["line"], b["kind"]) for b in hit)))
' 2>/dev/null)"
    read -r _ar_k _ar_n _ar_list <<< "$_ar_out"
    if [[ -n "${_ar_n:-}" ]]; then
      echo "AUDIT-READ-CHECK: ${_ar_k} of ${_ar_n} audit block(s) since ${ANCHOR:0:8} carry F/DIVERGED — read ONLY these at boot: ${_ar_list:-none} (the other $((_ar_n - _ar_k)) are not boot reads)"
    else
      echo "AUDIT-READ-CHECK: UNREADABLE — the classifier produced no output; read every pass since ${ANCHOR:0:8}"
    fi
  else
    echo "AUDIT-READ-CHECK: UNREADABLE — absorbed_through_sha '${ANCHOR:-none}' unresolvable or ledger/audit-findings.md unreadable; read every pass since the last stamp"
  fi
fi

# ── (4a'''') E12 INHERITANCE ─────────────────────────────────────────────────────────────────────────
# An E12 breach is a pressure line, not a ship-gate FAIL. The boundary that ended the last session wrote its register line
# (scripts/audit-seal.sh). This boot RE-PRINTS each `E12-PB HALT:` line so the seat that inherits the breach sees it.
# The counts come from grep -c over a captured variable (no grep -q under pipefail: SIGPIPE race).
if [[ -r probes/budget/probe_efficiency_budget.sh ]]; then
  _e12_out="$(bash probes/budget/probe_efficiency_budget.sh --e12-only 2>&1)"; _e12_rc=$?
  if [[ $_e12_rc -ne 0 ]]; then
    echo "E12-CHECK: UNREADABLE — probes/budget/probe_efficiency_budget.sh --e12-only exited ${_e12_rc}: $(printf '%s\n' "$_e12_out" | tail -1)"
  else
    _e12_h="$(printf '%s\n' "$_e12_out" | grep -c '^  E12-PB HALT: ')"
    _e12_u="$(printf '%s\n' "$_e12_out" | grep -cE '^  E12-PB REPORT .*(NO RECORD|UNSCORED)')"
    echo "E12-CHECK: ${_e12_h} HALT line(s) · ${_e12_u} of 3 ratio(s) NO RECORD/UNSCORED (never a PASS) · a pressure axis, never a ship-gate FAIL"
    printf '%s\n' "$_e12_out" | sed -n 's/^  \(E12-PB HALT: \)/    \1/p'
  fi
else
  echo "E12-CHECK: UNREADABLE — probes/budget/probe_efficiency_budget.sh absent in this worktree"
fi

# ── (4c) TRACKER-CHECK ────────────────────────────────────────────────────────────────────
# Every ruling that ASSIGNS A BUILD carries a CHECKLIST line citing its number. Assignment is read
# from a machine line, never prose: from the floor on, each ruling's own `BUILD: <owner> <item>` / `BUILD: none`
# line (the architect self-binds); an optional backfill table (_index/ruling-builds.tsv, mechanical
# re-measurement) answers the rulings that carry none.
# FLOOR: when the table is present, the floor is the value of its one declared header line `# floor: NNNN`
# (four digits), read here; it is never derived from the rows and never a literal in this script. A present
# table without exactly one well-formed floor line HALTs, named (an unknown input halts, it never defaults).
# When the table is absent (the designed state of an adopter tree) the floor is 0001 and the line says so.
# Zero model calls. A LINE, never a halt-the-boot (exit 0 except the BOOT-RECORD HALT, rc 3, the last line printed; see header); the HALT named here is the
# register-style HALT this gate is FOR, not a script abort.
TRK_HALT=""
TRK_NOBUILD=""     # a ruling >= the floor with no BUILD: line and no table row (its own list; a HALT, never a PASS)
TRK_TBL_IDS=" "    # ruling ids the backfill table answers (any column-4 value; NONE already halts in the table loop)
TRK_TBL_N=0; TRK_LIVE_N=0; TRK_BUILD_N=0; TRK_BNONE_N=0; TRK_VIA_TBL_N=0
TRK_FLOOR=1; TRK_FLOORHALT=""; TRK_TBL_PRESENT=0
if [[ -f _index/ruling-builds.tsv ]]; then
  TRK_TBL_PRESENT=1
  TRK_TSV="$(cat _index/ruling-builds.tsv 2>/dev/null)"
  _trk_fl_n="$(printf '%s\n' "$TRK_TSV" | command grep -cE '^#[[:space:]]*floor:')"
  if [[ "$_trk_fl_n" -eq 0 ]]; then
    TRK_FLOORHALT="no-floor-line (_index/ruling-builds.tsv present, no '# floor: NNNN' header line)"
  elif [[ "$_trk_fl_n" -gt 1 ]]; then
    TRK_FLOORHALT="multiple-floor-lines (${_trk_fl_n} '# floor:' header lines in _index/ruling-builds.tsv; exactly one is declared)"
  else
    _trk_fl_line="$(printf '%s\n' "$TRK_TSV" | command grep -E '^#[[:space:]]*floor:')"
    if [[ "$_trk_fl_line" =~ ^\#\ floor:\ ([0-9]{4})[[:space:]]*$ ]]; then
      TRK_FLOOR=$((10#${BASH_REMATCH[1]}))
    else
      TRK_FLOORHALT="malformed-floor-line (expected '# floor: NNNN', four digits; read: ${_trk_fl_line})"
    fi
  fi
  while IFS=$'\t' read -r _trk_r _trk_o _trk_i _trk_c; do
    [[ "$_trk_r" =~ ^[0-9]{4}$ ]] || continue
    TRK_TBL_N=$((TRK_TBL_N + 1)); TRK_TBL_IDS="${TRK_TBL_IDS}${_trk_r} "
    [[ "$_trk_c" == "NONE" ]] && TRK_HALT="${TRK_HALT} ${_trk_r}"
  done <<< "$TRK_TSV"
fi
# Live rulings past the backfill window: read each one's own BUILD: line directly (no table needed going forward).
# Same method as the backfill table: only genuine CHECKLIST item lines count (front-matter prose such as the absorb
# stamp cites rulings as authority and would otherwise satisfy every check forever).
TRK_ITEMS="$(command grep -E '^- \[[ x]\]' CHECKLIST.md 2>/dev/null)"
for _trk_f in _rulings/*.md; do
  [[ -n "$TRK_FLOORHALT" ]] && break
  [[ -f "$_trk_f" ]] || continue
  _trk_num="$(basename "$_trk_f" | sed -n 's/^\([0-9]\{4\}\)-.*/\1/p')"
  [[ -n "$_trk_num" ]] || continue
  (( 10#$_trk_num >= TRK_FLOOR )) 2>/dev/null || continue
  TRK_LIVE_N=$((TRK_LIVE_N + 1))
  # relay 1581: the machine line only — its first token is BUILD:, after an optional list marker and bold. A mid-prose
  # mention is never a BUILD line; the FIRST machine line is read, not the first mention (ISSUE-AUDIT-90155D06 F1).
  _trk_bline="$(command grep -m1 -E '^(- )?(\*\*)?BUILD:[[:space:]]' "$_trk_f" 2>/dev/null)"
  if [[ -z "$_trk_bline" ]]; then
    # 0430 §2/§3: no BUILD: line — a backfill-table row answers it (NONE there already halts); no row = NO-BUILD-LINE.
    case "$TRK_TBL_IDS" in
      *" ${_trk_num} "*) TRK_VIA_TBL_N=$((TRK_VIA_TBL_N + 1)) ;;
      *) TRK_NOBUILD="${TRK_NOBUILD} ${_trk_num}" ;;
    esac
    continue
  fi
  TRK_BUILD_N=$((TRK_BUILD_N + 1))
  if [[ "$_trk_bline" =~ ^(-\ )?\*\*BUILD: ]]; then
    # bold form `- **BUILD: <value>** <prose>`: the value ends at the closing ** (relay 1581 Ask 2; 0397:54)
    _trk_bval="$(printf '%s' "$_trk_bline" | sed -E 's/^(- )?\*\*BUILD:[[:space:]]*//; s/\*\*.*$//; s/[[:space:]]+$//')"
  else
    _trk_bval="$(printf '%s' "$_trk_bline" | sed -E 's/^(- )?BUILD:[[:space:]]*//; s/\*+[[:space:]]*$//')"
  fi
  [[ -n "${TRK_TRACE:-}" ]] && echo "TRACKER-VALUE: ${_trk_num} ${_trk_bval}"
  case "$_trk_bval" in [Nn]one*) TRK_BNONE_N=$((TRK_BNONE_N + 1)); continue ;; esac
  if ! command grep -qE "_rulings/${_trk_num}|\`${_trk_num}\`" <<< "$TRK_ITEMS"; then
    TRK_HALT="${TRK_HALT} ${_trk_num}"
  fi
done
_trk_nb_n="$(printf '%s' "$TRK_NOBUILD" | wc -w | tr -d ' ')"
_trk_floor4="$(printf '%04d' "$TRK_FLOOR")"
if [[ "$TRK_TBL_PRESENT" -eq 1 ]]; then _trk_pre="table ${TRK_TBL_N} rows"; else _trk_pre="no backfill table; floor 0001"; fi
_trk_den="${_trk_pre}; live ${TRK_LIVE_N} rulings >=${_trk_floor4}: ${TRK_BUILD_N} carry BUILD: (${TRK_BNONE_N} none), ${TRK_VIA_TBL_N} answered by a table row, ${_trk_nb_n} with neither"
if [[ -n "$TRK_FLOORHALT" ]]; then
  echo "TRACKER-CHECK: HALT ${TRK_FLOORHALT}"
elif [[ -n "${TRK_HALT// /}" || -n "${TRK_NOBUILD// /}" ]]; then
  echo "TRACKER-CHECK: HALT${TRK_HALT}${TRK_NOBUILD:+ · NO-BUILD-LINE${TRK_NOBUILD}} (${_trk_den})"
elif [[ "$TRK_LIVE_N" -eq 0 ]]; then
  echo "TRACKER-CHECK: EMPTY (0 rulings) (${_trk_den})"
else
  echo "TRACKER-CHECK: PASS (backfill table + live BUILD: scan; 0 missing CHECKLIST lines; ${_trk_den})"
fi

# ── (4a''''') BACKGROUNDED-SESSIONS (0398 §2 item 3) ─────────────────────────────────────────
# The restart answers the exit dialog with option 1 (0402 §5: stop tasks, log IN-FLIGHT), so a backgrounded session
# here is one the send did not create (an older backgrounding, a harness spare, a manual one). This line is
# the successor's reading list (0398 §3: one ASSESS line per item). A receipt, never a verdict; boot exits 0 except the BOOT-RECORD HALT (rc 3, the last line printed; see header).
if [[ -r scripts/backgrounded-sessions.sh ]]; then
  bash scripts/backgrounded-sessions.sh 2>&1 | head -25
else
  echo "BACKGROUNDED-SESSIONS: UNREADABLE — scripts/backgrounded-sessions.sh absent in this worktree"
fi

# ── (4b) DECLARED CONDITION — canon v1.6.5 §12 (:321 "visible while tolerated") ──
# The STATE-PRE-GENESIS row lives in contracts/CONSTANTS.md §4. It is read FROM THE SPINE like the §0 roster
# (lanes read the spine, never merge it), with a LABELLED local fallback. It is a LINE, never a
# halt (exit 0 except the BOOT-RECORD HALT, rc 3, the last line printed; see header). The compensating control is the surface-conformance probe
# (the conformance probe); until that probe exists at the spine, the line says so instead of implying a run.
_pg_src="SPINE(${GOV_REF})"
_pg_row="$(git show "${GOV_REF}:contracts/CONSTANTS.md" 2>/dev/null | grep -F 'STATE-PRE-GENESIS' | head -1)"
if [[ -z "${_pg_row}" ]]; then
  _pg_row="$(grep -F 'STATE-PRE-GENESIS' contracts/CONSTANTS.md 2>/dev/null | head -1)"
  _pg_src="LOCAL-FALLBACK(${GOV_REF} row unreadable)"
fi
if [[ -n "${_pg_row}" ]]; then
  if git cat-file -e "${GOV_REF}:probes/governance/probe_surface_conformance_v1.sh" 2>/dev/null; then
    _pg_cc="see SURFACE-CONFORM line"
  else
    _pg_cc="not-yet-run (the conformance probe not yet at ${GOV_REF})"
  fi
  echo "STATE: PRE-GENESIS (declared — CONSTANTS §4; source ${_pg_src}) · compensating control: surface-conformance ${_pg_cc} at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
elif git cat-file -e "${GOV_REF}:seats.yaml" 2>/dev/null || [[ -f seats.yaml ]]; then
  # THIRD STATE: no pre-genesis row AND the genesis artifact present = the state
  # genesis PRODUCES — the correct adopter line, not an anomaly. The artifact is the one the canon names:
  # v1.6.5 §12 (:320) "the seat manifest (`seats.yaml`), the generators, and the regenerated folder→lane map
  # are genesis artifacts". Checked at the spine first, then locally (labelled), like the row above.
  _gs_src="SPINE(${GOV_REF})"; git cat-file -e "${GOV_REF}:seats.yaml" 2>/dev/null || _gs_src="LOCAL"
  echo "STATE: GENESIS (ratified; seats.yaml present — source ${_gs_src})"
else
  # Only a GENUINELY unknown state earns the investigate line: no row AND no genesis artifact.
  echo "STATE: (declared-condition line SKIPPED — no STATE-PRE-GENESIS row and no genesis artifact (seats.yaml) readable at ${GOV_REF} or locally; investigate before proceeding, do not silently degrade)"
fi

# Non-fatal integrator nudge (stdout, NOT stderr — the old gate's fatal flaw): a real delta
# means a genuine absorb is owed. This is Tier 1/2 (visible); it never blocks boot.
# 0397 §2.1 / §3 member 1: the absorb is a READ OF THE INDEX (commit subjects), not of the diffs.
# A commit's diff opens ONLY on one of three NAMED triggers:
#   (1) flagged  — the AUDIT-READ-CHECK line above names it F or DIVERGED;
#   (2) own-path — its subject names a path THIS SESSION'S FIRST WORK ITEM touches. There is no machine
#       source for "the session's first work item" at boot time (it is chosen AFTER boot) — this is a
#       DECLARED input, read from env var BOOT_CHECK_OWN_PATH if the caller sets it before invoking this
#       script; absent that declaration the count is honestly "unset", never guessed or defaulted to 0-as-pass;
#   (3) ruling-seal-ACT — its subject is a ruling seal ("sealed as _rulings/NNNN") whose TO line names
#       foundation to ACT (opening the one-line TO header of the named ruling is a targeted read, not a diff).
# Everything else is absorbed BY SUBJECT ONLY (git log --format=%s, the list $DELTA already counts).
if [[ "$DELTA" != "0" && "$DELTA" != "NO-ANCHOR" && "$DELTA" != "?" ]]; then
  # flagged=F: reuse the AUDIT-READ-CHECK count computed above (foundation-scope only; other lanes don't run
  # that block, so F reads n/a there rather than a fabricated 0).
  if [[ "${lane:-}" == foundation && -n "${_ar_k:-}" ]]; then FLAGGED="${_ar_k}"; else FLAGGED="n/a(AUDIT-READ-CHECK is foundation-scope)"; fi
  # own-path=P: a DECLARED, documented input (trigger 2 has no machine source — see comment above).
  if [[ -n "${BOOT_CHECK_OWN_PATH:-}" ]]; then
    OWNPATH_N=$(git log --format=%s "${ANCHOR}..HEAD" -- "${BOOT_CHECK_OWN_PATH}" 2>/dev/null | wc -l | tr -d ' ')
    OWNPATH="${OWNPATH_N}(BOOT_CHECK_OWN_PATH=${BOOT_CHECK_OWN_PATH})"
  else
    OWNPATH="unset(no BOOT_CHECK_OWN_PATH declared this session — trigger 2 cannot fire)"
  fi
  echo "  ⇒ absorb-by-subject (0397 §2.1): unabsorbed=${DELTA} flagged=${FLAGGED} own-path=${OWNPATH}. Read ${DELTA} commit SUBJECT(s) since ${ANCHOR_SHOW}; open a DIFF only on trigger (1) flagged F/DIVERGED, (2) own-path (declared above), or (3) ruling-seal-ACT (subject says 'sealed as _rulings/NNNN' AND that ruling's TO line names foundation to ACT). Then re-stamp **absorbed_through_sha:** in CHECKLIST front-matter."
elif [[ "$DELTA" == "NO-ANCHOR" ]]; then
  echo "  ⇒ no absorbed_through_sha marker in CHECKLIST front-matter — stamp one on your next genuine absorb (a DELIBERATE act, never a side-effect of an edit)."
fi

# ── (5) CREED BREACH SCAN — the RESTART pole ──────────────────────────
# Scans the PRIOR session's committed record for trigger→cite breaches and prints the call-out
# BESIDE the creed, so a breach that escaped a hard-killed session is still surfaced at next boot.
# LINTER, never a block: creed-scan.sh exits 0 on findings by design, and `|| true` guards the
# UNREADABLE (exit 3) path so a scanner fault can never prevent a boot. A missed call-out is
# recoverable; a boot that will not start is not.
# Run the SPINE's scanner bytes, not this worktree's (stale on 6/6 lanes).
if [[ -x "$WT_ROOT/scripts/creed-scan-spine.sh" ]]; then
  bash "$WT_ROOT/scripts/creed-scan-spine.sh" 2>&1 || true
else
  echo "CREED-CHECK: SKIPPED — scripts/creed-scan-spine.sh not present on this branch (adopt trunk to wire the spine-bytes boundary scan)."
fi

# ── (6) SEAT-BOOT-ASSESS (0398 §3; REPORT-ONLY — the send selects option 1 (0402 §5), never option 2, so
# this boot NEVER passes --execute; nothing is stopped or ended by this call, only printed) ──
# Appended last so every earlier line (BOOT-CHECK:, TRACKER-CHECK, BACKGROUNDED-SESSIONS, STATE,
# CREED-CHECK) keeps its order. A failing child surfaces by name, never swallowed by a bare `|| true`.
if [[ -r scripts/seat-boot-assess.sh ]]; then
  _sba_out="$(bash scripts/seat-boot-assess.sh 2>&1)"; _sba_rc=$?
  printf '%s\n' "$_sba_out"
  [[ $_sba_rc -eq 0 ]] || echo "SEAT-BOOT-ASSESS: FAILED — scripts/seat-boot-assess.sh exited ${_sba_rc}"
else
  echo "SEAT-BOOT-ASSESS: UNREADABLE — scripts/seat-boot-assess.sh absent in this worktree"
fi

# ── (7) INBOX-AGE FILER (canon 7.4(b); the WIRED NON-SEAT CALLER of inbox-age liveness) ──
# A lane cannot file a register entry about its OWN unread mail, so this runs on the audit hub (lane=foundation),
# which reads EVERY lane's inbox through scripts/status.sh and files one OPEN register entry per lane whose oldest
# unconsumed item is past the declared threshold. Appended after (6) so every earlier line keeps its order. A LINE,
# never a halt (exit 0 except the BOOT-RECORD HALT, rc 3, the last line printed; see header); an age that cannot be computed prints UNREADABLE by name.
if [[ "${lane:-}" != foundation ]]; then
  echo "INBOX-AGE-FILER: n/a on lane=${lane:-?} (scope: the audit hub, lane=foundation, which reads every lane's inbox) -- NOT a PASS"
elif [[ -r scripts/inbox-age-filer.sh ]]; then
  _iaf_out="$(bash scripts/inbox-age-filer.sh 2>&1)"; _iaf_rc=$?
  printf '%s\n' "$_iaf_out"
  [[ $_iaf_rc -eq 0 ]] || echo "INBOX-AGE-FILER: FAILED -- scripts/inbox-age-filer.sh exited ${_iaf_rc} (UNREADABLE lane or register above)"
else
  echo "INBOX-AGE-FILER: UNREADABLE -- scripts/inbox-age-filer.sh absent in this worktree"
fi

# ── (8) BOOT-RECORD — canon §7.1 step 7 "record before work" (the state-source HALT) ──────────────────────────
# The seat's DECLARED state-source list is the one its charter ALREADY names (_boot/CHARTER-<lane>.md, the
# state-source map); this block authors no list, it only checks that every declared path exists at its
# $REPO_ROOT-relative path (.claude/agents/orc.md CANONICAL STATE "HARD GUARD": a declared source missing -> halt loud).
# PARSE RULE (deterministic; the probe pins it): (a) charter = _boot/CHARTER-<lane>.md, lane from _boot/BOOTSTRAP.md;
# (b) the map = from the first line that starts "- **state-source map" or "## STATE-SOURCE MAP" (case-insensitive)
# up to, not including, the next line that starts "- **", "## " or "# "; (c) newlines joined, "(...)" parentheticals
# dropped (prose, never a declaration); (d) each backtick span with no whitespace that contains "/" or ends in
# ".<ext>" is a declared path (bare words such as an env-var name are skipped); (e) one "{a,b}" brace expands to one
# path per member; (f) a trailing "/**" or "/" checks the DIRECTORY, any other "*" glob needs >=1 match, anything
# else needs to exist. No charter, or a map that yields zero paths = UNREADABLE (a lane with no map is not a PASS).
# EXIT CONTRACT: the one place this script leaves 0 -- BOOT_RECORD_HALT_RC (3) on HALT or UNREADABLE, after every line above
# printed (see the header for `--measure`, the one acceptance a measuring caller uses).
# The SessionStart hook runs `bash scripts/boot-check.sh 2>&1 || true`: the harness never sees this rc; the visible
# BOOT-RECORD line in the injected context is the boot-time surface, the rc is for scripted callers and probes.
BOOT_RECORD_RC=0
_br_expand() {  # <path-with-optional-brace> -> one path per line
  if [[ "$1" =~ ^(.*)\{([^{}]*)\}(.*)$ ]]; then
    local _pre="${BASH_REMATCH[1]}" _mid="${BASH_REMATCH[2]}" _post="${BASH_REMATCH[3]}" _m _old_ifs="$IFS"
    IFS=','; for _m in $_mid; do _br_expand "${_pre}${_m}${_post}"; done; IFS="$_old_ifs"
  else
    printf '%s\n' "$1"
  fi
}
_br_charter="_boot/CHARTER-${lane}.md"
if [[ ! -r "$_br_charter" ]]; then
  echo "BOOT-RECORD: UNREADABLE charter=${_br_charter} (no charter for lane=${lane}; a lane with no declared state-source map is not a PASS)"
  BOOT_RECORD_RC="$BOOT_RECORD_HALT_RC"
else
  _br_map="$(awk 'f==0 && (tolower($0) ~ /^- \*\*state-source map/ || tolower($0) ~ /^## state-source map/) {f=1; print; next} f==1 && ($0 ~ /^- \*\*/ || $0 ~ /^#+ /) {exit} f==1 {print}' "$_br_charter" | tr '\n' ' ' | sed -E 's/\([^()]*\)//g; s/\([^()]*\)//g')"
  _br_decl="$(printf '%s\n' "$_br_map" | grep -oE '`[^`]+`' | tr -d '`' | grep -vE '[[:space:]]' | grep -E '/|\.[A-Za-z]+$')"
  _br_n=0; _br_ok=0; _br_miss=""
  if [[ -n "$_br_decl" ]]; then
    while IFS= read -r _br_d; do
      while IFS= read -r _br_p; do
        [[ -n "$_br_p" ]] || continue
        _br_n=$((_br_n + 1))
        _br_t="$_br_p"; _br_found=0
        case "$_br_t" in
          */\*\*) _br_t="${_br_t%/**}"; [[ -d "$_br_t" ]] && _br_found=1 ;;
          */) [[ -d "$_br_t" ]] && _br_found=1 ;;
          *\**) compgen -G "$_br_t" >/dev/null 2>&1 && _br_found=1 ;;
          *) [[ -e "$_br_t" ]] && _br_found=1 ;;
        esac
        if [[ $_br_found -eq 1 ]]; then _br_ok=$((_br_ok + 1)); else _br_miss="${_br_miss:+${_br_miss},}${_br_p}"; fi
      done <<< "$(_br_expand "$_br_d")"
    done <<< "$_br_decl"
  fi
  if [[ $_br_n -eq 0 ]]; then
    echo "BOOT-RECORD: UNREADABLE charter=${_br_charter} (no state-source map, or a map that declares no path; a lane with no declared list is not a PASS)"
    BOOT_RECORD_RC="$BOOT_RECORD_HALT_RC"
  elif [[ -n "$_br_miss" ]]; then
    echo "BOOT-RECORD: HALT missing=${_br_miss} (declared in ${_br_charter}) · ${_br_ok} of ${_br_n} declared sources present · record before work: do not proceed until the named source exists or the charter is corrected"
    BOOT_RECORD_RC="$BOOT_RECORD_HALT_RC"
  else
    echo "BOOT-RECORD: PASS ${_br_ok} of ${_br_n} declared sources present (${_br_charter})"
  fi
fi
# ── end BOOT-RECORD ──
# ── (9) SEAT-HOST — a fork or daemon-hosted continuation of a seat conversation is not the seat ───────────────────
# The ONE predicate is scripts/seat-host-guard.sh (classify). From the SessionStart hook, stdin is the hook JSON (a
# pipe); from a hand run it is not, and the guard falls back to $CLAUDE_CODE_SESSION_ID and .claude/seat-boot.log.
# On a halt the SEAT-HOST-HALT line is printed LAST and the rc is BOOT_RECORD_HALT_RC (3), so BOOT-ACK is not emitted
# over it. A headless `claude -p` (source startup) is never halted. Silent when this session is the seat.
if [[ -r scripts/seat-host-guard.sh ]]; then
  _sh_in=""; [[ -p /dev/stdin ]] && { IFS= read -r -t 2 -d '' _sh_in || true; }   # bounded: a held-open pipe never hangs a boot
  _sh_line="$(printf '%s' "$_sh_in" | bash scripts/seat-host-guard.sh classify 2>/dev/null)"; _sh_rc=$?
  if [[ $_sh_rc -eq 3 ]]; then
    echo "$_sh_line"
    BOOT_RECORD_RC="$BOOT_RECORD_HALT_RC"
  fi
fi
exit "$BOOT_RECORD_RC"
