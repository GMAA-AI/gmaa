#!/bin/bash
# scripts/resolve-project.sh — the PROJECT token of this worktree's seat.
# Reads `project:` from the front-matter of <worktree>/_boot/BOOTSTRAP.md (stamped at provisioning,
# canon §7.3: "stamped-at-provisioning-never-at-launch"). Never derives it from a folder, a remote or
# an argument. Absent or malformed => HALT exit 2 with a named reason (no fallback, inv #5).
#
# Usage: scripts/resolve-project.sh [<worktree-root>]   (default: git rev-parse --show-toplevel)
# Prints: project=<token>        token grammar [a-z0-9-]+ (no ':' or '.', tmux target syntax, C7(b))
# Also used for the other stamp fields of the restart set:
#   scripts/resolve-project.sh --field handoff|remote_control [<worktree-root>]  -> prints the raw value
#   (exit 1 = field absent, which is legal for these two; the caller decides).
#   scripts/resolve-project.sh --config-dir [<worktree-root>]  -> the seat's Claude Code config directory
#   (the ONE account mapping): no `account:` field => $HOME/.claude (exit 0); `account: <a>`
#   => $HOME/.claude-<a> (exit 0) after the grammar check. A malformed value, or a mapped directory that does not
#   exist, HALTs exit 2 with a named reason. No lane-based default (R1.4): the account comes only from the stamp.
# An unreadable stamp HALTs exit 2 in every mode (it is never read as "field absent").
set -u

FIELD="project"
if [ "${1:-}" = "--field" ]; then
  FIELD="${2:?--field needs a name}"; shift 2
elif [ "${1:-}" = "--config-dir" ]; then
  FIELD="--config-dir"; shift
fi
ROOT="${1:-$(git rev-parse --show-toplevel 2>/dev/null)}"
[ -n "$ROOT" ] || { echo "HALT(resolve-project): not inside a git worktree" >&2; exit 2; }
BOOT="$ROOT/_boot/BOOTSTRAP.md"
[ -f "$BOOT" ] || { echo "HALT(resolve-project): no _boot/BOOTSTRAP.md at $ROOT" >&2; exit 2; }
[ -r "$BOOT" ] || { echo "HALT(resolve-project): $BOOT is unreadable" >&2; exit 2; }

# front-matter only: the lines between the first two '---' lines.
fm_value() {
  awk -v k="$1" '
    NR==1 && $0!="---" { exit }
    NR>1 && $0=="---" { exit }
    NR>1 { n=index($0, ":"); if (n>0 && substr($0,1,n-1)==k) { v=substr($0,n+1); sub(/^[ \t]+/,"",v); sub(/[ \t]+$/,"",v); print v; exit } }
  ' "$BOOT"
}

if [ "$FIELD" = "--config-dir" ]; then
  ACCT="$(fm_value account)"
  if [ -z "$ACCT" ]; then printf '%s\n' "$HOME/.claude"; exit 0; fi
  case "$ACCT" in
    *[!a-z0-9-]*|-*|*-)
      echo "HALT(resolve-project): account '$ACCT' is malformed in $BOOT (grammar [a-z0-9-]+, no leading/trailing '-'; the stamp value composes a path)." >&2
      exit 2 ;;
  esac
  DIR="$HOME/.claude-$ACCT"
  # An absent directory is not a default: Claude Code would create an unauthenticated one and the seat would boot
  # to a login prompt in a detached pane. This proves the directory was provisioned, NOT that its login is live
  # (macOS keys the credentials to the directory in the Keychain); /status at boot is the receipt for that.
  [ -d "$DIR" ] || {
    echo "HALT(resolve-project): account '$ACCT' maps to '$DIR', which does not exist (provision it first: CLAUDE_CONFIG_DIR='$DIR' claude, then log in)." >&2
    exit 2; }
  printf '%s\n' "$DIR"
  exit 0
fi

VAL="$(fm_value "$FIELD")"
if [ "$FIELD" != "project" ]; then
  [ -n "$VAL" ] || exit 1
  printf '%s\n' "$VAL"
  exit 0
fi

if [ -z "$VAL" ]; then
  echo "HALT(resolve-project): no 'project:' field in the front-matter of $BOOT." >&2
  echo "  The project key is stamped at provisioning; launch never falls back to a bare name." >&2
  exit 2
fi
case "$VAL" in
  *[!a-z0-9-]*|-*|*-)
    echo "HALT(resolve-project): project '$VAL' is malformed (grammar [a-z0-9-]+, no leading/trailing '-'; ':' and '.' are tmux target syntax, C7(b))." >&2
    exit 2 ;;
esac
printf 'project=%s\n' "$VAL"
