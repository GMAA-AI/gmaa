#!/usr/bin/env bash
# scripts/observed-mode.sh — UserPromptSubmit hook: the OBSERVED-MODE boot receipt (window-plan row 10).
# Canon §7.1 step 6 + §8: the boot receipt is the session's OBSERVED mode, never the requested flag or the config
# file. A hook reads `permission_mode` from its OWN stdin JSON, which the harness passes from
# the running session, and prints `OBSERVED-MODE: <value> (source: hook stdin <event>)`.
# Which event carries it (verified 2026-10-06 on Claude Code 2.1.280, one `claude -p --permission-mode plan`
# replica with `defaultMode: acceptEdits` configured): SessionStart stdin carries NO permission_mode;
# UserPromptSubmit stdin carries it, and it read `plan` (the flag), not `acceptEdits` (the config).
#
# Printed (stdout = added to the seat's context) on the first prompt of a session and again whenever the mode
# changes inside it; silent otherwise, so it costs one line per session. State: .claude/observed-mode
# (gitignored by `.claude/*`), one line `<session_id>\t<mode>`.
# HALT-LOUD, never inferred: no jq, unparseable stdin or an absent field prints `OBSERVED-MODE: unknown (...)`
# with the reason. It never falls back to settings.json; that is MODE-CHECK's configured line in boot-check.sh.
# Never blocks the prompt: always exit 0.
set -u
IN="$(cat)"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || ROOT="${CLAUDE_PROJECT_DIR:-.}"
ST="$ROOT/.claude/observed-mode"
EV="UserPromptSubmit"
if ! command -v jq >/dev/null 2>&1; then
  echo "OBSERVED-MODE: unknown (source: hook stdin $EV; jq not found, the field was not read)"; exit 0
fi
SID="$(printf '%s' "$IN" | jq -r '.session_id // empty' 2>/dev/null)"
EVR="$(printf '%s' "$IN" | jq -r '.hook_event_name // empty' 2>/dev/null)"
[[ -n "$EVR" ]] && EV="$EVR"
MODE="$(printf '%s' "$IN" | jq -r '.permission_mode // empty' 2>/dev/null)"
if [[ -z "$MODE" ]]; then
  REASON="the stdin carried no permission_mode"
  printf '%s' "$IN" | jq -e . >/dev/null 2>&1 || REASON="the stdin was not JSON"
  echo "OBSERVED-MODE: unknown (source: hook stdin $EV; $REASON)"; exit 0
fi
PREV="$(cat "$ST" 2>/dev/null)"
NOW="$(printf '%s\t%s' "${SID:-nosession}" "$MODE")"
[[ "$PREV" == "$NOW" ]] && exit 0
mkdir -p "$ROOT/.claude" 2>/dev/null
printf '%s\n' "$NOW" > "$ST" 2>/dev/null
echo "OBSERVED-MODE: $MODE (source: hook stdin $EV)"
exit 0
