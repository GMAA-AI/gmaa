#!/usr/bin/env bash
# canon-core.sh — the ONE canon-edition resolver, SOURCED by every script that reads the canon.
#
# "ONE resolver, shared — never a second copy." Two copies of one rule
# drift; the reconciler had drifted to a hard-coded `v1_6_1` while governance.sh resolved dynamically.
#
# canon_resolve <ref>  -> prints the CURRENT canon path at <ref> (e.g. GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_5.md)
#                         exit 1 (prints nothing) when no canon matches — callers HALT, never default.
# Anchored so the `_PUBLIC` cut is excluded; `sort -V` is correct across double digits
# (v1_6_5 < v1_6_10 < v1_7). Never hardcode an edition: it goes stale at the next cut and reads a
# superseded edition while reporting success.
CANON_RE='^GOVERNED_MULTI_AGENT_ARCHITECTURE_v[0-9_]+\.md$'

canon_resolve() {
    local ref="$1" c
    c="$(git ls-tree -r --name-only "$ref" 2>/dev/null | grep -E "$CANON_RE" | sort -V | tail -1)"
    [ -n "$c" ] || return 1
    printf '%s\n' "$c"
}
