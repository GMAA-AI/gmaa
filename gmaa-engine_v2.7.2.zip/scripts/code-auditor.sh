#!/usr/bin/env bash
# scripts/code-auditor.sh — the CODE half of the audit split. Fires on EVERY commit, zero model calls. Covers what
#   canon §4 requires every commit: receipt presence, register discipline, path/tier-triggered
#   standing-invariant probes, and file_state. The LLM reproduction pass (agents/post-commit-hook.sh,
#   the `claude -p` block) still runs, but only on a judgment-class trigger or a daily boundary —
#   this script never invokes a model and is the auditor that runs on each commit in between.
#
# USAGE: scripts/code-auditor.sh <commit-sha> <lane>
#   Called from agents/post-commit-hook.sh's backgrounded subshell, BEFORE the LLM decision.
#
# CONTRACT (binding on this script):
#   - Deterministic. No network calls except the SQL standing probes already run via
#     scripts/run_sql.sh (unchanged credential path: sources .env like every other apply/probe
#     script in this repo).
#   - NEVER fails the commit: always exits 0, regardless of what it finds.
#   - NEVER silently runs nothing: prints "ran N of M eligible" for the standing-probe pass.
#   - HALT-LOUD (own output, not process exit) on an unreadable _index/probe-tiers.tsv or
#     agents/standing-probes.yaml — continues the OTHER steps rather than aborting the whole run.
#   - Reads agents/standing-probes.yaml (P2-DENY — read-only, never edited by this script) and
#     _index/probe-tiers.tsv (data; this is its first live consumer).
#   - Writes ONLY ledger/audit-findings.md, ledger/audit-runs.log, ledger/receipts.jsonl — the
#     same two+one files the LLM auditor writes (agents/audit-system-prompt.md "Output format" +
#     the E6b usage recorder), append-only.
#
# WIRING NOTE (probe eligibility "daily"/"retire-candidate" cadence): this script writes one
#   `CODE-AUDITOR-PROBE id=<id> date=<UTC-date> ...` line per probe it actually invokes, to
#   ledger/audit-runs.log. That line is ALSO the persisted "last run" record the *next* commit's
#   daily-cadence eligibility check reads (grep for today's date) — self-contained, no new state
#   file needed, matches the existing convention that audit-runs.log is the liveness record.
#
# Gotchas handled: macOS /bin/bash 3.2 (no associative arrays — the heavy lifting below is a
# `python3 -` heredoc, same idiom as scripts/auditor-usage-record.sh); BSD tools not required here
# since git/python3 do all the work; `command grep`/no GNU-only flags in the bash wrapper.
set -u

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COMMIT_SHA="${1:-}"
LANE="${2:-UNRESOLVED}"

if [[ -z "$COMMIT_SHA" ]]; then
    echo "CODE-AUDITOR: HALT-LOUD -- no commit sha argument given; nothing to audit." >&2
    exit 0
fi

mkdir -p "$REPO_ROOT/ledger"

if ! command -v python3 >/dev/null 2>&1; then
    echo "CODE-AUDITOR: HALT-LOUD -- python3 not on PATH; the code auditor cannot run for ${COMMIT_SHA}. Commit succeeded; audit SKIPPED (deterministic pass only -- the LLM pass, if triggered, is unaffected)." >&2
    exit 0
fi

python3 - "$REPO_ROOT" "$COMMIT_SHA" "$LANE" <<'PY'
import sys, os, re, json, subprocess, hashlib, datetime, fnmatch

repo_root, sha, lane = sys.argv[1:4]
os.chdir(repo_root)

NOW = datetime.datetime.now(datetime.timezone.utc)
NOW_ISO = NOW.strftime("%Y-%m-%dT%H:%M:%SZ")
TODAY = NOW.strftime("%Y-%m-%d")
SHORT = sha[:8]
EMPTY_TREE = "4b825dc642cb6eb9a060e54bf8d69288fbee4904"

findings = []          # human-readable FINDING strings (never blocks; just reported)
halts = []             # HALT-LOUD strings (unreadable substrate)

def run(cmd, timeout=None):
    """Run a git/shell command; return (rc, combined-output-str). Never raises."""
    try:
        p = subprocess.run(cmd, cwd=repo_root, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
        return p.returncode, p.stdout.decode("utf-8", errors="replace")
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode("utf-8", errors="replace")
        return 124, out + "\n[CODE-AUDITOR] TIMEOUT after %ss" % timeout
    except FileNotFoundError as e:
        return 127, "[CODE-AUDITOR] command not found: %s" % e

def git(*args, timeout=None):
    return run(["git"] + list(args), timeout=timeout)

# ---------------------------------------------------------------------------------------------
# (1) CHANGED FILES — same parent-resolution the hook itself uses (first-parent on merges).
# ---------------------------------------------------------------------------------------------
rc, _ = git("rev-parse", "-q", "--verify", sha + "^2")
is_merge = (rc == 0)
if is_merge:
    parent = sha + "^1"
    _, cf_out = git("diff", "--name-only", parent, sha)
else:
    rc2, _ = git("rev-parse", "-q", "--verify", sha + "^")
    parent = (sha + "^") if rc2 == 0 else EMPTY_TREE
    _, cf_out = git("diff-tree", "--no-commit-id", "--name-only", "-r", sha)
changed_files = [l for l in cf_out.splitlines() if l.strip()]

# ---------------------------------------------------------------------------------------------
# helper: added lines (this commit's diff) for one tracked path, vs the resolved parent above.
# ---------------------------------------------------------------------------------------------
def added_lines_for(path):
    rc, out = git("diff", "--no-color", parent, sha, "--", path)
    if rc != 0:
        return []
    lines = []
    for l in out.splitlines():
        if l.startswith("+++") or l.startswith("---"):
            continue
        if l.startswith("+"):
            lines.append(l[1:])
    return lines

def path_exists_at_sha(path):
    rc, _ = git("cat-file", "-e", sha + ":" + path)
    return rc == 0

# ---------------------------------------------------------------------------------------------
# (2) RECEIPT PRESENCE / FILE_STATE — every line ADDED to ledger/receipts.jsonl this commit must
#     be valid JSON carrying the required keys, and any probe_path/standing_probe_path it names
#     must resolve at this commit.
# ---------------------------------------------------------------------------------------------
receipt_lines = added_lines_for("ledger/receipts.jsonl") if "ledger/receipts.jsonl" in changed_files else []
receipts_valid = 0
receipts_invalid = 0
receipts_path_ok = 0
receipts_path_checked = 0
REQUIRED_RECEIPT_KEYS = ("receipt_id", "actor")
for i, rl in enumerate(receipt_lines):
    rl_stripped = rl.strip()
    if not rl_stripped:
        continue
    try:
        obj = json.loads(rl_stripped)
    except (ValueError, json.JSONDecodeError) as e:
        receipts_invalid += 1
        findings.append("FINDING receipt-presence: ledger/receipts.jsonl added-line %d is not valid JSON (%s): %r"
                         % (i, str(e)[:100], rl_stripped[:160]))
        continue
    missing = [k for k in REQUIRED_RECEIPT_KEYS if not obj.get(k)]
    if missing:
        receipts_invalid += 1
        findings.append("FINDING receipt-presence: %s missing required key(s) %s" % (obj.get("receipt_id", "<no-id>"), missing))
    else:
        receipts_valid += 1
    for pk in ("probe_path", "standing_probe_path"):
        pv = obj.get(pk)
        if isinstance(pv, str) and pv:
            receipts_path_checked += 1
            if path_exists_at_sha(pv):
                receipts_path_ok += 1
            else:
                findings.append("FINDING file_state: %s cites %s=%r which does not resolve at %s"
                                 % (obj.get("receipt_id", "<no-id>"), pk, pv, SHORT))

# ---------------------------------------------------------------------------------------------
# (3) REGISTER DISCIPLINE — an added CLOSED/RESOLVED line in issues_register.md must cite a
#     closeout: a commit sha, a file path, or a receipt id (all as backtick-quoted tokens, this
#     repo's own convention throughout the file). Report-only, never blocks.
# ---------------------------------------------------------------------------------------------
register_lines = added_lines_for("issues_register.md") if "issues_register.md" in changed_files else []
CLOSE_WORD_RE = re.compile(r'\b(CLOSED|RESOLVED)\b')
BACKTICK_RE = re.compile(r'`([^`]+)`')
SHA_RE = re.compile(r'^[0-9a-f]{7,40}$')
RECEIPT_RE = re.compile(r'^R-\d{8}T\d{6}Z')
PATH_RE = re.compile(r'^[\w.\-]+/[\w./\-]+$')          # contains a slash -> looks like a repo path
ORDINAL_RE = re.compile(r'^[A-Za-z][\w]*-\d+$')          # e.g. SET-0039; a path (has a slash, e.g. contracts/<name>.md) is handled by PATH_RE instead

def line_cites_closeout(line):
    for tok in BACKTICK_RE.findall(line):
        t = tok.strip()
        if SHA_RE.match(t) or RECEIPT_RE.match(t) or PATH_RE.match(t) or ORDINAL_RE.match(t):
            return True
    return False

register_close_lines = 0
register_uncited = 0
for l in register_lines:
    if CLOSE_WORD_RE.search(l):
        register_close_lines += 1
        if not line_cites_closeout(l):
            register_uncited += 1
            findings.append("FINDING register-discipline: issues_register.md added line carries CLOSED/RESOLVED with no backtick-quoted sha/path/receipt-id/ordinal citation: %r"
                             % (l.strip()[:200]))

# ---------------------------------------------------------------------------------------------
# (4) STANDING PROBES — select by _index/probe-tiers.tsv; run each probe's own command from
#     agents/standing-probes.yaml (read-only); apply the yaml's emit rules; emit receipts.
# ---------------------------------------------------------------------------------------------
TIERS_PATH = os.path.join(repo_root, "_index", "probe-tiers.tsv")
YAML_PATH = os.path.join(repo_root, "agents", "standing-probes.yaml")

tier_rows = []          # list of dict(id, tier, triggers[list of glob], note)
tiers_readable = True
try:
    with open(TIERS_PATH, "r", encoding="utf-8") as f:
        tsv_text = f.read()
    if not tsv_text.strip():
        raise ValueError("empty file")
    for raw in tsv_text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        parts = raw.split("\t")
        if len(parts) < 3:
            continue
        pid, tier, trig = parts[0].strip(), parts[1].strip(), parts[2].strip()
        note = parts[3].strip() if len(parts) > 3 else ""
        triggers = [] if trig in ("-", "") else trig.split("|")
        tier_rows.append({"id": pid, "tier": tier, "triggers": triggers, "note": note})
    if not tier_rows:
        raise ValueError("no data rows parsed")
except (OSError, ValueError) as e:
    tiers_readable = False
    halts.append("HALT-LOUD: _index/probe-tiers.tsv unreadable (%s) -- standing-probe pass SKIPPED entirely for %s. This is a gap, not a silent pass: 0 of unknown eligible ran." % (str(e)[:160], SHORT))

yaml_entries = {}
yaml_readable = True
if tiers_readable:
    try:
        import yaml as _yaml
    except ImportError as e:
        yaml_readable = False
        halts.append("HALT-LOUD: python3 'yaml' module unavailable (%s) -- cannot read agents/standing-probes.yaml; standing-probe pass SKIPPED for %s." % (str(e)[:160], SHORT))
    if yaml_readable:
        try:
            with open(YAML_PATH, "r", encoding="utf-8") as f:
                doc = _yaml.safe_load(f)
            entries = (doc or {}).get("standing_probes")
            if not entries:
                raise ValueError("no 'standing_probes:' list found")
            for e in entries:
                if isinstance(e, dict) and e.get("id"):
                    yaml_entries[e["id"]] = e
            if not yaml_entries:
                raise ValueError("standing_probes list parsed but yielded 0 usable entries")
        except (OSError, ValueError) as e:
            yaml_readable = False
            halts.append("HALT-LOUD: agents/standing-probes.yaml unreadable/malformed (%s) -- standing-probe pass SKIPPED for %s." % (str(e)[:160], SHORT))

def glob_matches_any(path, globs):
    return any(fnmatch.fnmatch(path, g) for g in globs)

def _receipts_for(receipts_text_cache, pid):
    """Every receipt whose PARSED standing_probe_id == pid, in ledger order.
    (auditor 9377873c F1): the ledger carries BOTH the spaced form `"standing_probe_id": "x"`
    (1610 of 3661 lines) and the compact form (153). A substring marker saw only the compact form, so 8 of 16
    eligible ids read "never emitted" (false wiring-init sentinels) and 4 read a STALE prior (duplicate
    cadence). Prior art: audit-findings.md:89044 ("JSON-parse ... on the standing_probe_id field")."""
    rows = []
    for line in receipts_text_cache:
        if pid not in line:          # cheap pre-filter only; the decision is made on the parsed field
            continue
        try:
            obj = json.loads(line)
        except (ValueError, json.JSONDecodeError):
            continue
        if isinstance(obj, dict) and obj.get("standing_probe_id") == pid:
            rows.append(obj)
    return rows

def emitted_today(receipts_text_cache, pid):
    """True if a standing-probe receipt for pid was already emitted today (UTC)."""
    for obj in _receipts_for(receipts_text_cache, pid):
        ts = str(obj.get("probe_last_run_at_utc", ""))
        if ts.startswith(TODAY):
            return True
    return False

def latest_receipt_status(receipts_text_cache, pid):
    """Most recent auditor_status recorded for pid (ledger order), or None if never emitted."""
    rows = _receipts_for(receipts_text_cache, pid)
    return rows[-1].get("auditor_status") if rows else None

def ran_today_in_runs_log(runs_log_text, pid):
    marker = "CODE-AUDITOR-PROBE id=%s date=%s" % (pid, TODAY)
    return marker in runs_log_text

RECEIPTS_JSONL = os.path.join(repo_root, "ledger", "receipts.jsonl")
try:
    with open(RECEIPTS_JSONL, "r", encoding="utf-8") as f:
        receipts_cache = f.readlines()
except OSError:
    receipts_cache = []

RUNS_LOG = os.path.join(repo_root, "ledger", "audit-runs.log")
try:
    with open(RUNS_LOG, "r", encoding="utf-8") as f:
        runs_log_text = f.read()
except OSError:
    runs_log_text = ""

eligible = [r for r in tier_rows if r["tier"] != "excluded"]
ran_records = []        # (id, tier, verdict_token, reason) for probes actually invoked
skipped_records = []    # (id, tier, reason) for eligible-but-not-run this commit
new_standing_receipts = []
runs_log_probe_lines = []

def _signal_text(out, pass_sig, fail_sig):
    """(auditor 9377873c F2 Defect A): drop LEGEND lines before looking for signals. A line
    carrying BOTH signals ("PASS if equal. FAIL with diff if not.") describes the verdict; it is not one.
    Prior art, recorded 8x (audit-findings.md:88683 ... :93258): "Classify on the verdict line"."""
    if not pass_sig or not fail_sig:
        return out
    return "\n".join(l for l in out.split("\n") if not (pass_sig in l and fail_sig in l))

def _violation_rows(out):
    """(F2 Defect B): the window probes print a `Violations (file:line:content):` header then
    one `path:NNN:content` row per violation, and NO violation_count token. Count those rows."""
    rows, inside = 0, False
    for l in out.split("\n"):
        if l.startswith("Violations"):
            inside = True
            continue
        if inside and re.match(r'^[^\s:][^:]*:[0-9]+:', l):
            rows += 1
    return rows if inside else None

def classify(rc, out, expected_rc, pass_sig, fail_sig, window):
    sig = _signal_text(out, pass_sig, fail_sig)
    if rc == expected_rc and pass_sig in sig and fail_sig not in sig:
        return "PASS", None
    if fail_sig in sig:
        if window:
            vmax = window.get("violation_count_max")
            vclass = window.get("violation_class")
            m = re.search(r'violation_count[=:]\s*(\d+)', out)
            cm = re.search(r'violation_class[=:]\s*([A-Za-z0-9_]+)', out)
            if m:
                count = int(m.group(1))
                cls_ok = (cm is None) or (vclass is None) or (cm.group(1) == vclass)
                if vmax is not None and count <= int(vmax) and cls_ok:
                    return "PARTIAL_FAIL_EXPECTED", "count=%d class_ok=%s" % (count, cls_ok)
            else:
                rows = _violation_rows(out)
                if rows is not None and vmax is not None and rows <= int(vmax):
                    return "PARTIAL_FAIL_EXPECTED", ("count=%d (file:line rows under the Violations header) <= max %s; "
                        "class %s NOT mechanically verifiable (the probe does not print a class)" % (rows, vmax, vclass))
            # Could not confirm the window's own numbers from output -- fail CLOSED (report as a
            # true regression rather than silently accepting an unverified partial-fail carve-out).
            return "FAIL", "fail_signal present, partial_fail_window declared but violation_count could not be parsed from output -- treated as regression (fail-closed)"
        return "FAIL", None
    return "RUN_ERROR", "rc=%s (expected %s), neither pass_signal nor fail_signal present on a verdict line" % (rc, expected_rc)

VERDICT_TO_STATUS = {
    "PASS": "STANDING_PROBE_PASS",
    "PARTIAL_FAIL_EXPECTED": "STANDING_PROBE_PARTIAL_FAIL_EXPECTED",
    "FAIL": "STANDING_PROBE_REGRESSION",
    "RUN_ERROR": "STANDING_PROBE_RUN_ERROR",
}

PROBE_TIMEOUT = int(os.environ.get("CODE_AUDITOR_PROBE_TIMEOUT", "120"))

if tiers_readable and yaml_readable:
    for row in eligible:
        pid, tier, triggers = row["id"], row["tier"], row["triggers"]
        entry = yaml_entries.get(pid)
        if entry is None:
            skipped_records.append((pid, tier, "id in probe-tiers.tsv but absent from agents/standing-probes.yaml (FINDING)"))
            findings.append("FINDING standing-probes: probe-tiers.tsv names id=%s but agents/standing-probes.yaml has no such entry" % pid)
            continue

        if tier in ("daily", "retire-candidate"):
            if ran_today_in_runs_log(runs_log_text, pid):
                skipped_records.append((pid, tier, "already ran today (%s tier, once-per-UTC-day)" % tier))
                continue
        elif tier in ("per-commit-on-trigger", "gate-candidate"):
            matched = any(glob_matches_any(f, triggers) for f in changed_files) if triggers else False
            if not matched:
                skipped_records.append((pid, tier, "no changed file matched trigger globs: %s" % ("|".join(triggers) or "-")))
                continue
        else:
            skipped_records.append((pid, tier, "unrecognized tier %r in probe-tiers.tsv" % tier))
            continue

        # --- Invoke the probe exactly as its yaml entry names it. ---
        probe_path = entry.get("path")
        runner = entry.get("runner", "bash")
        expected_rc = entry.get("expected_exit_code", 0)
        pass_sig = entry.get("pass_signal", "")
        fail_sig = entry.get("fail_signal", "")
        window = entry.get("partial_fail_window")

        if runner == "scripts/run_sql.sh" or (probe_path or "").endswith(".sql"):
            cmd = ["bash", "scripts/run_sql.sh", probe_path]
        elif runner in ("bash", "sh"):
            cmd = ["bash", probe_path]
        elif runner == "python3":
            cmd = ["python3", probe_path]
        else:
            cmd = [runner, probe_path]

        rc, out = run(cmd, timeout=PROBE_TIMEOUT)
        out_hash = hashlib.sha256(out.encode("utf-8", errors="replace")).hexdigest()
        verdict, detail = classify(rc, out, expected_rc, pass_sig, fail_sig, window)
        ran_records.append((pid, tier, verdict, detail))
        runs_log_probe_lines.append("CODE-AUDITOR-PROBE id=%s date=%s sha=%s verdict=%s rc=%s hash=%s"
                                     % (pid, TODAY, SHORT, verdict, rc, out_hash[:16]))

        status = VERDICT_TO_STATUS[verdict]
        prior_status = latest_receipt_status(receipts_cache, pid)
        cadence = entry.get("cadence_emit_per_day")

        emit = False
        rule = None
        if prior_status is None:
            emit, rule = True, "d"      # wiring-init sentinel
        elif status in ("STANDING_PROBE_REGRESSION", "STANDING_PROBE_RUN_ERROR"):
            emit, rule = True, "a"
        elif status != prior_status:
            emit, rule = True, "b"
        elif cadence and not emitted_today(receipts_cache, pid):
            emit, rule = True, "c"

        if emit:
            asserts_first_line = (entry.get("asserts") or "").strip().splitlines()[0] if entry.get("asserts") else ""
            receipt_id = "R-%sZ-STANDING-%s" % (NOW.strftime("%Y%m%dT%H%M%S"), pid)
            note = "Emit rule (%s) %s (code-auditor, deterministic, 0 model calls). %s%s" % (
                rule, status, asserts_first_line[:140], ("; " + detail) if detail else "")
            receipt = {
                "receipt_id": receipt_id,
                "actor": "code-Auditor",
                "ring": 2,
                "commit": sha,
                "standing_probe_id": pid,
                "standing_probe_path": probe_path,
                "auditor_status": status,
                "probe_exit_code": rc,
                "probe_output_hash": out_hash,
                "probe_last_run_at_utc": NOW_ISO,
                "supersedes_receipt_id": None,
                "auditor_notes": note,
            }
            new_standing_receipts.append(receipt)
            # Reflect this new receipt in the in-memory cache immediately so a LATER probe in this
            # same run (there is only one row per id today, but this guards a future re-run) sees it.
            receipts_cache.append(json.dumps(receipt, separators=(",", ":")) + "\n")
else:
    for row in eligible:
        skipped_records.append((row["id"], row["tier"], "tiers/yaml unreadable this run"))

# ---------------------------------------------------------------------------------------------
# A3 (loop-cure member A3): class EVERY finding. A finding that names no path which is a row of
# _index/ship-carriers.tsv (the shipping manifest) is `logged`, never routed, unless it names a blocker. An
# unreadable manifest fails toward MORE attention (`routed`), never toward silence.
# ---------------------------------------------------------------------------------------------
def _a3_carriers():
    try:
        with open(os.path.join(repo_root, "_index", "ship-carriers.tsv"), encoding="utf-8") as fh:
            return {l.split("\t", 1)[0].strip() for l in fh if l.strip() and not l.startswith("#") and l.split("\t")[1:2] != ["origin-only"]}
    except OSError:
        return None
A3_CARRIERS = _a3_carriers()
A3_BLOCKER = re.compile(r"\b(blocker|blocks|blocking|HALT)\b", re.I)
A3_PATH = re.compile(r"[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)+|[A-Za-z0-9_-]+\.(?:md|sh|tsv|jsonl|json|py|sql|yaml)")
def a3_class(fnd):
    if A3_CARRIERS is None: return "routed(manifest-unreadable)"
    if A3_BLOCKER.search(fnd): return "routed(names-a-blocker)"
    if set(A3_PATH.findall(fnd)) & A3_CARRIERS: return "routed(manifest-path)"
    return "logged"
findings = ["%s [A3 class=%s]" % (fnd, a3_class(fnd)) for fnd in findings]

# ---------------------------------------------------------------------------------------------
# WRITE-OUT — receipts.jsonl (append), audit-findings.md (append block), audit-runs.log (append).
# ---------------------------------------------------------------------------------------------
if new_standing_receipts:
    with open(RECEIPTS_JSONL, "a", encoding="utf-8") as f:
        for r in new_standing_receipts:
            f.write(json.dumps(r, separators=(",", ":")) + "\n")

ran_summary = ", ".join("%s(%s,%s)" % (i, t, v) for i, t, v, _d in ran_records) or "(none)"
skip_summary = ", ".join("%s(%s: %s)" % (i, t, reason) for i, t, reason in skipped_records) or "(none)"
n_denominator = len(eligible)
n_ran = len(ran_records)

lines_log = []
lines_log.append("CODE-AUDITOR %s lane=%s %s ran=%d eligible=%d findings=%d halts=%d"
                  % (SHORT, lane, NOW_ISO, n_ran, n_denominator, len(findings), len(halts)))
for h in halts:
    lines_log.append("  " + h)
lines_log.extend("  " + l for l in runs_log_probe_lines)
if skipped_records:
    lines_log.append("  SKIPPED: " + skip_summary)
with open(RUNS_LOG, "a", encoding="utf-8") as f:
    f.write("\n".join(lines_log) + "\n")

block = []
block.append("## Code audit -- `%s` (lane=%s) -- %s" % (SHORT, lane, NOW_ISO))
block.append("")
block.append("Deterministic pass, 0 model calls (`scripts/code-auditor.sh`).")
block.append("")
block.append("**Changed files:** %d." % len(changed_files))
block.append("")
block.append("**Receipt presence / file_state:** %d line(s) added to `ledger/receipts.jsonl`; %d valid, %d invalid. probe_path/standing_probe_path existence: %d/%d resolve."
              % (len(receipt_lines), receipts_valid, receipts_invalid, receipts_path_ok, receipts_path_checked))
block.append("")
block.append("**Register discipline:** `issues_register.md` %s this commit. %d CLOSED/RESOLVED line(s) added; %d missing an explicit sha/path/receipt-id citation (FINDING, not a block)."
              % ("changed" if "issues_register.md" in changed_files else "unchanged", register_close_lines, register_uncited))
block.append("")
if halts:
    block.append("**HALT-LOUD:**")
    for h in halts:
        block.append("- " + h)
    block.append("")
block.append("**Standing probes:** ran %d of %d eligible (denominator excludes `exclude_from_auditor` rows per `_index/probe-tiers.tsv`)." % (n_ran, n_denominator))
block.append("- RAN: " + ran_summary)
block.append("- SKIPPED: " + skip_summary)
if new_standing_receipts:
    block.append("- Emitted %d standing-probe receipt(s): %s" % (len(new_standing_receipts), ", ".join(r["standing_probe_id"] for r in new_standing_receipts)))
else:
    block.append("- Emitted 0 standing-probe receipt(s) (PASS-on-PASS/no-cadence-due for everything RAN; the CODE-AUDITOR-PROBE lines above are the liveness record).")
block.append("")
if findings:
    block.append("**Findings (%d, report-only -- never blocks the commit):**" % len(findings))
    for fnd in findings:
        block.append("- " + fnd)
    block.append("")
verdict = "FINDINGS-ONLY (%d)" % len(findings) if findings else "PASS"
block.append("**Verdict for `%s` (code-Auditor, deterministic): %s.** 0 model calls." % (SHORT, verdict))
block.append("")

with open(os.path.join(repo_root, "ledger", "audit-findings.md"), "a", encoding="utf-8") as f:
    f.write("\n".join(block) + "\n")

print("CODE-AUDITOR: %s lane=%s ran %d of %d eligible standing probes; %d finding(s); %d halt(s). Findings/receipts/log written."
      % (SHORT, lane, n_ran, n_denominator, len(findings), len(halts)))
for h in halts:
    print("CODE-AUDITOR: %s" % h)
PY
exit 0
