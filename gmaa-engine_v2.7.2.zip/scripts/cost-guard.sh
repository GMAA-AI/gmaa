#!/usr/bin/env bash
set -uo pipefail

# scripts/cost-guard.sh — REQ-COST runtime cost brake (C-SET-AUTHORIZATION §2.4).
#
# WHY THIS EXISTS. The cost-governance triad's RUNTIME boundary was documented as an enforcement
# while the bytes did not run: the usage WRITE path (one durable row per metered call) existed, the
# READ/SUM-before-the-next-metered-call HALT did not. A metered run with no spend brake is the gap.
# Doctrine may not assert an enforcement the bytes don't run — this file is the bytes. The ledger
# read is the project's (the USAGE READER, below); the brake is this file.
#
# USAGE
#   cost-guard.sh check --unit <unit_id> [--cohort <id,id,...>] [--auth=<reader-mode>] [--verbose]
#   --auth=<value> is passed to the usage reader unchanged; its meaning is the reader's.
# EXIT CODES — CLOSED SET (the house shape; mirrors reconciliation-diff.sh / C-RECONCILIATION-DIFF)
#   0  under cap        — proceed
#   2  at/over cap      — HALT-LOUD `COST-CAP unit=… spent=… cap=…`; caller MUST NOT auto-continue
#   3  unreadable       — HALT. Never "assume zero". Reading nothing must never read as $0 spent.
#   4  usage error      — bad invocation (not a verdict; distinct from 3 so a caller cannot read a
#                         typo as a cost verdict)
#
# THE EXIT-3 DISCIPLINE IS THE LOAD-BEARING ONE. The F-A scar was a cost signal read from sampled
# telemetry that silently dropped rows; the failure this whole class produces is ABSENCE READ AS
# AGREEMENT. A run that cannot see the ledger must never exit 0. Every failure path below defaults
# to 3, and the sentinel-line protocol exists so that a partial/garbled read is INDISTINGUISHABLE
# from no read — both fail closed.
#
# CALL SITE (§2.4): TOP of the next metered gate (+ once at cohort enqueue) — BEFORE the call is
# fired, never after the prior write. A guard that runs after the spend is a report, not a brake.
#
# PRICING IS CONFIG, NOT CODE: contracts/COST-CAPS.md is the single slot. Two copies of a pricing
# rule drift — that is a standing register lesson — so this script parses that file and holds no
# rates of its own. An unfilled/unparseable slot is exit 3, never a default.

REPO="$(cd "$(dirname "$0")/.." && pwd)"
CAPS_FILE="$REPO/contracts/COST-CAPS.md"
SENTINEL="COSTGUARD_ROW"

die_usage(){ echo "cost-guard.sh: USAGE — $*" >&2; exit 4; }
halt_unreadable(){ echo "COST-GUARD UNREADABLE — $* (HALT; refusing to assume \$0 spent)" >&2; exit 3; }

# need_val — cure for ISSUE-TRAILING-VALUE-FLAG-SPINS-FOREVER-IN-FIVE-SCRIPTS (SET-0083 shape,
# carried from scripts/creed-scan.sh need_val()/flag-swallow guard, auditor ac4caa28 O1 / 0e08e6a4
# O2). `--unit`/`--cohort` used to hang forever as the LAST argument: `shift 2` with one arg left
# fails WITHOUT shifting, so `[ $# -gt 0 ]` never becomes false. Call BEFORE reading `$2`/shifting:
# refuses (1) no value given and (2) the next arg is itself a `--flag` (no legitimate value here —
# a numeric id/list — begins with `--`, so it would otherwise be silently swallowed as this flag's
# value).
# DELIBERATE DEPARTURE from the SET-0083 "exit 3" literal (flagged for foundation/architect
# review): THIS FILE documents exit 3 as a CLOSED-SET, already-wired meaning — "unreadable [cost]
# side; never assume $0 spent" (line ~18/41) — distinct from exit 4 "usage error (not a verdict; …
# so a caller cannot read a typo as a cost verdict)". Routing a malformed CLI through exit 3 here
# would be exactly the conflation that distinction exists to prevent, so this is wired through
# die_usage() (exit 4) instead — same named-stderr shape, this file's own existing usage-error code.
need_val() { [ "$1" -ge 2 ] || die_usage "$2 requires a value (none given)"; case "${3-}" in --*) die_usage "$2 requires a value, got the flag '$3' instead" ;; esac; }

# ── args ────────────────────────────────────────────────────────────────────────────────────────
verb="${1:-}"; shift || true
[ "$verb" = "check" ] || die_usage "unknown verb '${verb:-<empty>}' — only 'check' is defined"

UNIT=""; COHORT=""; AUTH=""; VERBOSE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --unit)    need_val $# "--unit" "${2:-}"; UNIT="${2:-}"; shift 2 ;;
    --cohort)  need_val $# "--cohort" "${2:-}"; COHORT="${2:-}"; shift 2 ;;
    --auth=*)  AUTH="${1#--auth=}"; shift ;;
    --verbose) VERBOSE=1; shift ;;
    *) die_usage "unknown flag '$1'" ;;
  esac
done
[ -n "$UNIT" ] || die_usage "--unit <unit_id> is required"
[[ "$UNIT" =~ ^[0-9]+$ ]] || die_usage "--unit must be numeric (got '$UNIT')"
if [ -n "$COHORT" ]; then
  [[ "$COHORT" =~ ^[0-9]+(,[0-9]+)*$ ]] || die_usage "--cohort must be a comma-separated id list (got '$COHORT')"
  # A unit outside its own declared cohort is a CALLER ERROR, not a $0 reading. Without this the
  # CTE's IN-list would exclude the unit, the unit row would sum to 0.00, and the guard would PASS
  # a unit it never looked at — a fail-open of exactly the class exit 3 exists to prevent.
  printf '%s' ",$COHORT," | grep -q ",$UNIT," \
    || die_usage "--unit $UNIT is not a member of --cohort $COHORT (a unit outside its cohort would read as \$0.00)"
fi

# ── caps slot (config) ──────────────────────────────────────────────────────────────────────────
# An unfilled slot on a metered path is a HALT (§2.4 "Unfilled caps on a metered path → HALT"),
# NOT a permissive default. Parsed from the fenced `caps:` block of contracts/COST-CAPS.md.
[ -f "$CAPS_FILE" ] || halt_unreadable "caps slot absent at contracts/COST-CAPS.md"

cap_get(){ grep -E "^[[:space:]]*$1:" "$CAPS_FILE" | head -1 | sed -E 's/^[^:]*:[[:space:]]*//' | tr -d '"'"'"' \r'; }

PER_UNIT="$(cap_get per_unit_usd)"
PER_COHORT="$(cap_get per_cohort_usd)"
FAIL_CLOSED="$(cap_get fail_closed_if_unreadable)"

[[ "$PER_UNIT" =~ ^[0-9]+(\.[0-9]+)?$ ]] || halt_unreadable "per_unit_usd unfilled/unparseable in caps slot (got '${PER_UNIT:-<empty>}')"
[ "$FAIL_CLOSED" = "true" ] || halt_unreadable "fail_closed_if_unreadable is not true in caps slot — refusing to run a brake that can fail open"
if [ -n "$COHORT" ]; then
  [[ "$PER_COHORT" =~ ^[0-9]+(\.[0-9]+)?$ ]] || halt_unreadable "per_cohort_usd unfilled/unparseable (got '${PER_COHORT:-<empty>}')"
fi

# Per-meter rates, USD per 1M tokens, keyed by model family. Cache rates are DERIVED in the slot
# (cache_read = 0.1x input, cache_write@5m = 1.25x input) and stated there explicitly so the
# arithmetic is auditable without reading this script.
OPUS_IN="$(cap_get opus_input_usd_per_mtok)";     OPUS_OUT="$(cap_get opus_output_usd_per_mtok)"
OPUS_CR="$(cap_get opus_cache_read_usd_per_mtok)"; OPUS_CW="$(cap_get opus_cache_write_usd_per_mtok)"
SON_IN="$(cap_get sonnet_input_usd_per_mtok)";     SON_OUT="$(cap_get sonnet_output_usd_per_mtok)"
SON_CR="$(cap_get sonnet_cache_read_usd_per_mtok)"; SON_CW="$(cap_get sonnet_cache_write_usd_per_mtok)"
for v in "$OPUS_IN" "$OPUS_OUT" "$OPUS_CR" "$OPUS_CW" "$SON_IN" "$SON_OUT" "$SON_CR" "$SON_CW"; do
  [[ "$v" =~ ^[0-9]+(\.[0-9]+)?$ ]] || halt_unreadable "a prices: entry is unfilled/unparseable in the caps slot"
done

# ── the read ────────────────────────────────────────────────────────────────────────────────────
# The usage ledger is the project's substrate, so the read is a separate command: the USAGE READER
# (COST-CAPS §2.4). It receives the parsed inputs in its environment and prints the sentinel rows this
# script parses below: `<SENTINEL> unit <id> <calls> <usd>`, plus `<SENTINEL> cohort 0 <calls> <usd>`
# when a cohort is given. CACHE TOKENS MUST BE PRICED by the reader: on a cached workload they are
# most of the spend, and a reader that priced only input+output would pass a unit near its cap.
# An absent reader is exit 3, never a pass; a reader that exits non-zero is exit 3.
READER="${COST_USAGE_READER:-$REPO/scripts/cost-usage-reader.sh}"
if [ ! -f "$READER" ] || [ ! -x "$READER" ]; then
  echo "COST-GUARD: UNREADABLE — usage reader absent (scripts/cost-usage-reader.sh; the adopter supplies its reader, COST-CAPS §2.4)" >&2
  exit 3
fi
export UNIT COHORT AUTH VERBOSE SENTINEL OPUS_IN OPUS_OUT OPUS_CR OPUS_CW SON_IN SON_OUT SON_CR SON_CW
out="$("$READER")"
rc=$?

# rc!=0, or the sentinel missing, or a non-numeric total => UNREADABLE => exit 3.
# A partial or garbled read is deliberately indistinguishable from no read: both fail closed.
[ "$rc" = 0 ] || halt_unreadable "usage reader exit $rc (auth=${AUTH:-unset})"

unit_line="$(printf '%s\n' "$out" | grep -F "$SENTINEL" | grep -F ' unit ' | head -1)"
[ -n "$unit_line" ] || halt_unreadable "no $SENTINEL unit row in the query result (auth=${AUTH:-unset})"
unit_spent="$(printf '%s' "$unit_line" | awk '{print $NF}')"
unit_calls="$(printf '%s' "$unit_line" | awk '{print $(NF-1)}')"
[[ "$unit_spent" =~ ^[0-9]+(\.[0-9]+)?$ ]] || halt_unreadable "unit total not numeric (got '$unit_spent')"

status=0
over_unit="$(awk -v s="$unit_spent" -v c="$PER_UNIT" 'BEGIN{print (s+0 >= c+0) ? 1 : 0}')"
if [ "$over_unit" = 1 ]; then
  echo "COST-CAP unit=$UNIT spent=$unit_spent cap=$PER_UNIT calls=$unit_calls — HALT-LOUD, no auto-continue" >&2
  status=2
else
  echo "cost-guard: OK unit=$UNIT spent=$unit_spent cap=$PER_UNIT calls=$unit_calls"
fi

if [ -n "$COHORT" ]; then
  coh_line="$(printf '%s\n' "$out" | grep -F "$SENTINEL" | grep -F ' cohort ' | head -1)"
  [ -n "$coh_line" ] || halt_unreadable "no $SENTINEL cohort row in the query result"
  coh_spent="$(printf '%s' "$coh_line" | awk '{print $NF}')"
  coh_calls="$(printf '%s' "$coh_line" | awk '{print $(NF-1)}')"
  [[ "$coh_spent" =~ ^[0-9]+(\.[0-9]+)?$ ]] || halt_unreadable "cohort total not numeric (got '$coh_spent')"
  over_coh="$(awk -v s="$coh_spent" -v c="$PER_COHORT" 'BEGIN{print (s+0 >= c+0) ? 1 : 0}')"
  if [ "$over_coh" = 1 ]; then
    echo "COST-CAP cohort=$COHORT spent=$coh_spent cap=$PER_COHORT calls=$coh_calls — HALT-LOUD, no auto-continue" >&2
    status=2
  else
    echo "cost-guard: OK cohort=$COHORT spent=$coh_spent cap=$PER_COHORT calls=$coh_calls"
  fi
fi

exit "$status"
