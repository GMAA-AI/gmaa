#!/bin/bash
# scripts/seat-boot-assess.sh [--execute] — 0398 §3, the successor's boot-time ASSESS step (amends 0387 §2:
# classification moves from the predecessor's exit to the successor's boot; member 0, landed, already moved
# the SEND side to answer the exit dialog; 0402 §5 re-pinned that answer from option 2 to option 1 (stop tasks,
# log IN-FLIGHT) — this script is the other half, "the restarted lane assesses", for any session still found.
#
# For every backgrounded session and orphan shell scripts/backgrounded-sessions.sh enumerates, classifies
# every item it carries (subagent ledger rows + its own tasks/*.output shells) by the ONE classifier
# (scripts/subagent-lib.sh; the same rules 0387 §2 names: WORKING/MONITORING/IDLE/STUCK) and prints one line
# per item:
#   ASSESS <old sid|-> <kind> <id> <class> <action> <output path>(<reason>)
# action = keep (that item is WORKING) or stop (a session with nothing WORKING is ended; an orphan
# MONITORING/IDLE/STUCK shell is ended on its own, 0387 §2's P8/P9 action column moved here by 0398 §3).
#
# REPORT ONLY by default (no process touched): scripts/boot-check.sh calls it this way on EVERY boot. That
# default matters because SessionStart also fires for a sibling session sharing this worktree (headless
# auditors, a subagent spawned moments earlier) — "end the predecessor" is the successor's restart-boot act,
# never a side-effect of an unrelated session starting; see the build report's open issue on this boundary.
# The mutating half runs only with --execute, a seat's own deliberate act.
#
# Ends a session that carries nothing WORKING via `claude stop <id>` (the harness's own verb, confirmed
# live by a prior hand-run — the earlier "no CLI verb" finding is refuted), falling back to `kill -TERM <pid>`
# only when `stop` fails and a pid is known; logs the pair `SEAT-BACKGROUNDED <old> -> <new>` /
# `SEAT-BACKGROUND-ENDED <old> <utc>` (0398 §3's own shape) to .claude/seat-loop.log.
# Ends an orphan shell (no owning session; the harness has no CLI verb for a bare shell) via `kill -TERM`
# and logs `ASSESS-DONE <pid> stopped <utc>` (the same hand-run's own shape, kept so a grep over
# seat-loop.log never needs two forms for "I stopped something").
#
# Test seams (same names scripts/backgrounded-sessions.sh and scripts/subagent-lib.sh already use):
# BG_ROOT, BG_CLAUDE_BIN, TASK_DIR_BASE, TRANSCRIPT_DIR, NOW_EPOCH.
# Always exits 0; an unreadable source prints UNREADABLE, never a silent count of 0 (DISC-ABSENCE-OF-RECORD).
set -u
EXECUTE=""
for a in "$@"; do [ "$a" = "--execute" ] && EXECUTE=1; done
ROOT="${BG_ROOT:-$(git rev-parse --show-toplevel 2>/dev/null)}" || ROOT=""
[ -n "$ROOT" ] || { echo "SEAT-BOOT-ASSESS: UNREADABLE — not inside a git worktree"; exit 0; }
D="$ROOT/.claude"
# shellcheck source=scripts/subagent-lib.sh
. "$ROOT/scripts/subagent-lib.sh" 2>/dev/null || { echo "SEAT-BOOT-ASSESS: UNREADABLE — scripts/subagent-lib.sh unreadable"; exit 0; }
CLAUDE_BIN="${BG_CLAUDE_BIN:-claude}"
NEW_SID="${CLAUDE_CODE_SESSION_ID:-successor}"
NOW="$(sa_now)"
utcnow() { date -u +%Y-%m-%dT%H:%M:%SZ; }

J="$("$CLAUDE_BIN" agents --json --cwd "$ROOT" 2>/dev/null)"
if ! printf '%s' "$J" | jq -e 'type == "array"' >/dev/null 2>&1; then
  echo "SEAT-BOOT-ASSESS: UNREADABLE — '${CLAUDE_BIN} agents --json --cwd ${ROOT}' gave no JSON array"
  exit 0
fi

# assess_session_items <old_sid> -> prints one TAB line per carried item (kind id class-and-reason out) to
# stdout; return code 0 iff at least one item is WORKING (bash boolean: 0 = true), so the caller never has
# to re-derive the keep/stop decision from the printed text.
assess_session_items() {
  local sid="$1" any_working=1 line class tdir f tid cmd
  while IFS=$'\t' read -r _ aid _ st _ tp; do
    [ -n "$aid" ] || continue
    [ -n "$tp" ] && [ -e "$tp" ] || tp="UNRESOLVED"
    line="$(sa_classify_subagent "$D" "$sid" "$aid" "$st" "$NOW" "$(sa_intent_epoch "$D" "$sid")")"
    class="${line%% *}"
    [ "$class" = WORKING ] && any_working=0
    printf 'subagent\t%s\t%s\t%s\n' "$aid" "$line" "$tp"
  done < <(sa_live "$D" "$sid")
  tdir="$(sa_task_dir "$ROOT" "$sid")"
  if [ -d "$tdir" ]; then
    for f in "$tdir"/*.output; do
      [ -e "$f" ] || continue
      [ -L "$f" ] && continue
      sa_shell_done "$f" && continue
      tid="$(basename "$f" .output)"
      cmd="$(sa_shell_cmd "$ROOT" "$sid" "$tid")"
      line="$(sa_classify_shell "$f" "$cmd" "$NOW")"
      class="${line%% *}"
      [ "$class" = WORKING ] && any_working=0
      printf 'shell\t%s\t%s\t%s\n' "$tid" "$line" "$f"
    done
  fi
  return "$any_working"
}

end_session() {
  local sid="$1" pid="$2" ok=1 t
  [ -n "$EXECUTE" ] || return 0
  if "$CLAUDE_BIN" stop "$sid" >/dev/null 2>&1; then
    ok=0
  elif [ -n "$pid" ] && kill -TERM "$pid" 2>/dev/null; then
    ok=0
  fi
  if [ "$ok" -eq 0 ]; then
    printf 'SEAT-BACKGROUNDED %s -> %s\n' "$sid" "$NEW_SID" >> "$D/seat-loop.log" 2>/dev/null
    printf 'SEAT-BACKGROUND-ENDED %s %s\n' "$sid" "$(utcnow)" >> "$D/seat-loop.log" 2>/dev/null
  else
    t="$(utcnow)"
    echo "SEAT-BACKGROUND-END-FAILED $sid $t"
    printf 'SEAT-BACKGROUND-END-FAILED %s %s\n' "$sid" "$t" >> "$D/seat-loop.log" 2>/dev/null
  fi
}

NSESS=0
while IFS=$'\x1f' read -r id pid; do
  [ -n "$id" ] || continue
  NSESS=$((NSESS + 1))
  ITEMS="$(assess_session_items "$id")"; HAS_WORKING=$?
  if [ -z "$ITEMS" ]; then
    echo "ASSESS $id session - IDLE stop n/a(no-carried-items)"
  else
    while IFS=$'\t' read -r kind iid line out; do
      [ -n "$iid" ] || continue
      class="${line%% *}"; reason="${line#* }"
      action="stop"; [ "$class" = WORKING ] && action="keep"
      echo "ASSESS $id $kind $iid $class $action ${out}(${reason})"
    done <<< "$ITEMS"
  fi
  [ "$HAS_WORKING" -ne 0 ] && end_session "$id" "$pid"
done < <(printf '%s' "$J" | jq -r '.[] | select(.kind == "background") | [(.id // .sessionId // "?"), (.pid // "" | tostring)] | join("\u001f")')

# orphan harness shells (ppid 1, the shell-snapshot wrapper), the same source
# scripts/backgrounded-sessions.sh reads. They carry no owning session, so there is no SEAT-BACKGROUNDED
# pair for one — a MONITORING/IDLE/STUCK orphan is ended on its own via kill -TERM, logged ASSESS-DONE.
NORPH=0
while read -r pid ppid cmd; do
  [ "$ppid" = 1 ] || continue
  case "$cmd" in *"/.claude/shell-snapshots/snapshot-"*) : ;; *) continue ;; esac
  cwd="$(lsof -a -p "$pid" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -1)"
  case "$cwd" in "$ROOT"|"$ROOT"/*) : ;; *) continue ;; esac
  NORPH=$((NORPH + 1))
  what="$(printf '%s' "$cmd" | sed -n 's/.* eval //p' | sed 's/ < \/dev\/null.*//' | cut -c1-120)"
  line="$(sa_classify_shell "" "$what" "$NOW")"
  class="${line%% *}"; reason="${line#* }"
  action="stop"; [ "$class" = WORKING ] && action="keep"
  echo "ASSESS - shell pid${pid} $class $action ${what:-?}(${reason})"
  if [ "$action" = stop ] && [ -n "$EXECUTE" ]; then
    kill -TERM "$pid" 2>/dev/null
    printf 'ASSESS-DONE pid%s stopped %s\n' "$pid" "$(utcnow)" >> "$D/seat-loop.log" 2>/dev/null
  fi
done < <(ps -axo pid=,ppid=,command= 2>/dev/null)
echo "SEAT-BOOT-ASSESS: ${NSESS} session(s), ${NORPH} orphan shell(s) assessed$([ -n "$EXECUTE" ] && echo ' (--execute)' || echo ' (report-only)')"
exit 0
