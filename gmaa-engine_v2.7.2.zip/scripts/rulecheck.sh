#!/usr/bin/env bash
# rulecheck.sh — draft-time governance retriever (AC-2)
#
# CONTRACT: contracts/SPEC-GOVERNANCE-INDEX.md §2 (architect-authored).
# CUSTODY:  architect authors the spec; foundation builds this mechanism.
#
# WHAT IT IS: given a draft, mechanically LOCATE the rules that govern it, so conformance stops being
# a memory habit (DISC-VIGILANCE-IS-FIELD-LOCAL: the cure is structural, not vigilant).
#   shortlist = {classes=='*'} ∪ {rows whose triggers match the draft} ∪ interacts_with-closure
#
# HARD CONSTRAINTS (SPEC §2): pure grep/awk over _index/governance.tsv. NO LLM · NO network ·
#   NO metered cost · deterministic · idempotent. Two runs over the same bytes give the same bytes.
#
# WHAT IT DOES NOT DO (canon §13 / AC-6 — honest scope, never represented as complete):
#   It surfaces rows by CLASS and by REGEX TRIGGER and follows DECLARED edges. It cannot detect the
#   semantic/emergent axis — rules that interact for reasons nobody wrote down. That axis is carried
#   by the §5(c) joint-coherence slot, which forces the question to be ASKED and never certifies the
#   answer. A clean RULECHECK is "no DECLARED rule was missed", never "this draft is conformant."
#
# VERBS (the dispatcher — DISC-INVOCATION-CITES-THE-DISPATCHER; read THIS case block, never a prior receipt):
#   rulecheck.sh <draft-file>          retrieve for a draft file's body
#   rulecheck.sh --class <class>[,..]  retrieve for explicit artifact class(es), no file needed
#   rulecheck.sh <draft-file> --class <class>   both (union)
#   rulecheck.sh --self-test           seeded-hit probe: a PLANTED trigger must surface its row
#   rulecheck.sh --classes             list the class vocabulary present in the index
# EXIT: 0 = shortlist emitted (or empty-but-universal) · 2 = a blood=1 row matched and --strict given
#       · 3 = halt (missing index / unreadable draft)
set -uo pipefail

REPO_ROOT="$(git rev-parse --show-toplevel)" || { echo "FATAL: not in a git repo" >&2; exit 3; }
cd "$REPO_ROOT" || exit 3
IDX="_index/governance.tsv"

die() { echo "HALT: $*" >&2; exit 3; }

DRAFT=""; CLASSES=""; STRICT=0; MODE="retrieve"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --class)     CLASSES="${CLASSES}${CLASSES:+,}${2:-}"; shift 2 ;;
        --strict)    STRICT=1; shift ;;
        --self-test) MODE="self-test"; shift ;;
        --classes)   MODE="classes"; shift ;;
        -h|--help)   MODE="help"; shift ;;
        -*)          die "unknown flag: $1 (see the dispatcher case block in this file)" ;;
        *)           DRAFT="$1"; shift ;;
    esac
done

[[ "$MODE" == "help" ]] && { sed -n '2,30p' "$0"; exit 0; }
[[ -f "$IDX" ]] || die "$IDX absent — run scripts/gen-governance-index.sh build first (inv #5: no silent degradation)"

# ---------------------------------------------------------------------------
# retrieve <body-text> <classes-csv> : emit id<TAB>corpus<TAB>locate<TAB>check<TAB>blood<TAB>why
#   Match reasons are kept DISTINCT (universal / class / trigger / edge) so the receipt shows WHY a
#   row is present — a shortlist that cannot explain itself cannot be audited.
# ---------------------------------------------------------------------------
retrieve() {
    local body="$1" classes="$2" bodyf clsf
    bodyf="$(mktemp -t rcbody)" || die "mktemp failed"
    printf '%s' "$body" > "$bodyf"
    clsf="$(mktemp -t rccls)" || die "mktemp failed"
    printf '%s' "$classes" | tr ',' '\n' | grep -v '^$' > "$clsf" || true

    awk -F'\t' -v bodyfile="$bodyf" -v clsfile="$clsf" '
    BEGIN {
        # slurp the draft body (lowercased once; triggers are matched case-insensitively)
        body = ""
        while ((getline line < bodyfile) > 0) body = body "\n" tolower(line)
        nsel = 0
        while ((getline c < clsfile) > 0) if (c != "") sel[c] = 1
    }
    /^#/ { next }
    NF < 9 { next }
    {
        id=$1; corpus=$2; classes=$3; triggers=$4; edges=$5; locate=$6; check=$7; blood=$8; ship=$9
        ID[NR]=id; CORPUS[NR]=corpus; CLASSES[NR]=classes; TRIG[NR]=triggers
        EDGES[NR]=edges; LOC[NR]=locate; CHK[NR]=check; BLOOD[NR]=blood
        byid[id]=NR
        n=NR
        why = ""
        if (classes == "*") why = "universal"
        if (why == "" && length(sel) > 0) {
            split(classes, cs, "|")
            for (i in cs) if (cs[i] in sel) { why = "class:" cs[i]; break }
        }
        if (why == "" && triggers != "" && body != "") {
            if (body ~ tolower(triggers)) why = "trigger"
        }
        if (why != "") { WHY[NR] = why; hit[id] = NR }
    }
    END {
        # interacts_with closure: surfacing A surfaces its DECLARED partners (SPEC §5(b)).
        # Fixed-point, so a chain A->B->C is followed; edge-added rows are labelled as such.
        changed = 1
        while (changed) {
            changed = 0
            for (i in hit) {
                r = hit[i]
                if (EDGES[r] == "") continue
                split(EDGES[r], es, "|")
                for (j in es) {
                    e = es[j]
                    if (e == "" || (e in hit)) continue
                    if (e in byid) { hit[e] = byid[e]; WHY[byid[e]] = "edge<-" i; changed = 1 }
                }
            }
        }
        for (i in hit) { r = hit[i]
            printf "%s\t%s\t%s\t%s\t%s\t%s\n", ID[r], CORPUS[r], LOC[r], CHK[r], BLOOD[r], WHY[r] }
    }' "$IDX" | sort -t$'\t' -k5,5r -k1,1
    rm -f "$bodyf" "$clsf"
}

emit_receipt() {
    local rows="$1" draftlabel="$2" blood_n total_n
    total_n="$(printf '%s\n' "$rows" | grep -c . || true)"
    blood_n="$(printf '%s\n' "$rows" | awk -F'\t' '$5=="1"' | grep -c . || true)"
    local idx_blob; idx_blob="$(git hash-object "$IDX" 2>/dev/null || echo UNKNOWN)"

    echo "RULECHECK: draft=${draftlabel} matched=${total_n} blood=${blood_n}"
    echo "  frame: index git-blob ${idx_blob} at HEAD $(git rev-parse --short HEAD 2>/dev/null || echo UNKNOWN); retrieval is grep/awk only (no LLM, no network)"
    echo ""
    printf '%s\n' "$rows" | awk -F'\t' 'NF>=6 {
        mark = ($5=="1") ? "[BLOOD]" : "[     ]"
        printf "%s %-46s %-10s %s\n", mark, $1, "("$6")", $3
        printf "         check: %s\n", $4
    }'
    echo ""
    if [[ "${blood_n:-0}" -gt 0 ]]; then
        echo "  ${blood_n} BLOOD row(s): each must read EVALUATED (outcome cited inline) or WAIVED (reason inline)."
    fi
    echo "  SCOPE (canon §13): declared rules only — class, regex trigger, declared edges. The"
    echo "  semantic/emergent axis is NOT detected here. A clean RULECHECK means no DECLARED rule was"
    echo "  missed; it does NOT mean the draft is conformant."
    if [[ "${total_n:-0}" -gt 1 ]]; then
        local corpora; corpora="$(printf '%s\n' "$rows" | cut -f2 | sort -u | grep -c . || true)"
        if [[ "${corpora:-0}" -ge 2 ]]; then
            echo ""
            echo "  JOINT-COHERENCE SLOT (SPEC §5(c), fail-closed on absence): this shortlist spans ${corpora}"
            echo "  corpora. State in one line whether these rules INTERACT for this draft, and on what evidence."
            echo "  JOINT-COHERENCE: <your answer here — absence of this line is the finding>"
        fi
    fi
}

case "$MODE" in
  classes)
    awk -F'\t' '/^#/{next} NF>=9 {split($3,c,"|"); for(i in c) if(c[i]!="") print c[i]}' "$IDX" | sort | uniq -c | sort -rn
    ;;
  self-test)
    # SEEDED-HIT PROBE (AC-2): plant a trigger for a KNOWN row and assert that row surfaces.
    # DISC-PROBE-INPUT-PROVENANCE: synthetic input — proves the retriever, not any real draft.
    rc=0
    echo "SELF-TEST (seeded-hit probe; synthetic input — proves the retriever, not a real draft)"
    # SYNTHETIC FIXTURE INDEX (portable fixtures). The self-test used to seed LIVE rows
    #   (DISC-WIDEN-PRESERVES-TRUST, the ruling-architecture edge graph) — 0247 §7 step 3 dropped both from the index
    #   (MERGE into C-DB; the merged rows' edges collapse into their survivors), and the instrument control failed for
    #   a reason unrelated to the retriever. An instrument control must not depend on what the live index holds; the
    #   live index is judged by the governance-index probe (arms B/D/E), not here.
    fx="$(mktemp -t rcfixture)" || die "mktemp failed"
    trap 'rm -f "$fx"' EXIT
    {
        printf '# synthetic rulecheck fixture — 9+ columns, same schema as _index/governance.tsv\n'
        printf 'FIX-SEED\tdiscipline\tmigration\tCHECK constraint|DROP.*ADD\t\tfixture#seed\tseed check\t1\tgeneric\n'
        printf 'FIX-UNIVERSAL\tinvariant\t*\t\t\tfixture#universal\tuniversal check\t1\tgeneric\n'
        printf 'FIX-CLASS-A\tdiscipline\truling-architecture\t\tFIX-PARTNER\tfixture#a\tclass check\t0\tgeneric\n'
        printf 'FIX-PARTNER\tdiscipline\tinfra\t\t\tfixture#partner\tpartner check\t0\tgeneric\n'
    } > "$fx"
    LIVE_IDX="$IDX"   # kept for pole (6), which judges the LIVE triggers
    IDX="$fx"

    # (1) seeded hit: a planted trigger must surface its row
    seed="This migration will DROP and re-ADD a CHECK constraint to widen the allowed kinds."
    out="$(retrieve "$seed" "")"
    if printf '%s' "$out" | cut -f1 | grep -qx 'FIX-SEED'; then
        echo "  seeded trigger surfaces its row ........ PASS"
    else echo "  seeded trigger surfaces its row ........ FAIL"; rc=1; fi

    # (2) universal rows are ALWAYS in, even for an empty draft
    out="$(retrieve "" "")"
    if printf '%s' "$out" | cut -f1 | grep -qx 'FIX-UNIVERSAL'; then
        echo "  universal row present on empty draft ... PASS"
    else echo "  universal row present on empty draft ... FAIL"; rc=1; fi

    # (3) NEGATIVE CONTROL: an unrelated draft must NOT surface the seeded row.
    #     Without this, a retriever that returns EVERYTHING would score 100% on (1) and (2).
    out="$(retrieve "The weather today is mild and the office plants need water." "")"
    if printf '%s' "$out" | cut -f1 | grep -qx 'FIX-SEED'; then
        echo "  negative control (must NOT match) ...... FAIL (returns unrelated rows)"; rc=1
    else echo "  negative control (must NOT match) ...... PASS"; fi

    # (4) interacts_with closure: an edge-reached row must appear labelled as an edge
    out="$(retrieve "" "ruling-architecture")"
    if printf '%s' "$out" | awk -F'\t' '$1=="FIX-PARTNER" && $6=="edge<-FIX-CLASS-A"' | grep -q .; then
        echo "  interacts_with closure reaches a row ... PASS"
    else echo "  interacts_with closure reaches a row ... FAIL"; rc=1; fi

    # (5) determinism/idempotence (SPEC §2)
    a="$(retrieve "$seed" "migration")"; b="$(retrieve "$seed" "migration")"
    if [[ "$a" == "$b" ]]; then echo "  deterministic across two runs .......... PASS"
    else echo "  deterministic across two runs .......... FAIL"; rc=1; fi

    # (6) KIND-SCOPED NEUTRAL-CORPUS POLE. Unlike (1)-(5) this runs against the
    #     LIVE index on purpose: it judges the live contract/canon TRIGGERS, not the retriever. A contract or
    #     canon row exists to fire on DOMAIN IDENTIFIERS, so any such row surfacing on generic English is an
    #     over-match and a FAIL that names the row. Discipline/invariant rows MAY surface (they fire on prose).
    #     Fail-closed: a missing fixture, a short fixture, or an unreadable live index is a FAIL, never a skip.
    nfx="probes/governance-index/fixtures/neutral-prose.txt"
    if [[ ! -r "$LIVE_IDX" || ! -r "$nfx" ]]; then
        echo "  neutral corpus: 0 contract/canon rows .. FAIL (unreadable: $LIVE_IDX or $nfx)"; rc=1
    else
        nbody="$(grep -v '^#' "$nfx")"
        nlines="$(printf '%s\n' "$nbody" | grep -c . || true)"
        IDX="$LIVE_IDX"
        if [[ "${nlines:-0}" -lt 200 ]]; then
            echo "  neutral corpus: 0 contract/canon rows .. FAIL (fixture has ${nlines} prose lines; floor 200)"; rc=1
        else
            # ONE classifier, shared by (6) and (6r): the red pole must exercise the very expression (6) relies on
            # (auditor 75d82ca0 F1 — a red pole with its own filter proves the retriever, not the pole).
            overmatch() { awk -F'\t' '$2=="contract" || $2=="canon" {printf "%s%s(%s)", s, $1, $6; s=" "}'; }
            over="$(retrieve "$nbody" "" | overmatch)"
            if [[ -z "$over" ]]; then
                echo "  neutral corpus: 0 contract/canon rows .. PASS (${nlines} lines)"
            else echo "  neutral corpus: 0 contract/canon rows .. FAIL (over-match: ${over})"; rc=1; fi
            # (6r) RED POLE: the same corpus with ONE seeded contract identifier MUST surface a contract row,
            #      or pole (6) is proven unable to fail (a pole never seen red is presence theatre).
            red="$(retrieve "${nbody}"$'\n'"The editor then calls sp_fixture_approve, a stored procedure, to approve the item." "" | overmatch)"
            if [[ "$red" == *"C-DB("* ]]; then
                echo "  neutral corpus red pole (seeded id) .... PASS (the pole can fail)"
            else echo "  neutral corpus red pole (seeded id) .... FAIL (a seeded contract id did not surface)"; rc=1; fi
        fi
        IDX="$fx"
    fi

    # (7) POSITIVE-CORPUS POLE (spec X8). Every contract/canon row of the LIVE index
    #     must surface, with reason trigger or class, on its OWN purpose sentence in positive-prose.tsv, and the
    #     fixture must cover exactly the live contract/canon ids. An under-match is cured by WIDENING the row, never
    #     by rewording the sentence. (7r) red pole: the same check with one sentence blanked MUST name that id.
    #     Fail-closed: an unreadable fixture or index is a FAIL.
    pfx="probes/governance-index/fixtures/positive-prose.tsv"
    if [[ ! -r "$LIVE_IDX" || ! -r "$pfx" ]]; then
        echo "  positive corpus: every row surfaces .... FAIL (unreadable: $LIVE_IDX or $pfx)"; rc=1
    else
        IDX="$LIVE_IDX"
        # posmiss <fixture-file>: prints each id whose own sentence does NOT surface it (the ONE classifier, shared by 7 and 7r)
        posmiss() {
            local pid psent pwhy
            while IFS=$'\t' read -r pid psent; do
                [[ -z "$pid" || "$pid" == \#* ]] && continue
                pwhy="$(retrieve "$psent" "" | awk -F'\t' -v i="$pid" '$1==i {print $6}')"
                [[ "$pwhy" == "trigger" || "$pwhy" == class:* ]] || printf '%s ' "$pid"
            done < "$1"
        }
        want="$(awk -F'\t' '!/^#/ && NF>=9 && ($2=="contract" || $2=="canon") {print $1}' "$LIVE_IDX" | sort)"
        # sort -u: a row may carry extra CLASS sentences; each is scored alone by posmiss(),
        # and id coverage compares the DISTINCT ids, so a duplicate id is not an "extra" row.
        have="$(grep -v '^#' "$pfx" | cut -f1 | grep . | sort -u)"
        pmiss="$(posmiss "$pfx")"
        if [[ "$want" != "$have" ]]; then
            echo "  positive corpus: every row surfaces .... FAIL (fixture ids != live contract/canon ids: missing [$(comm -23 <(printf '%s\n' "$want") <(printf '%s\n' "$have") | tr '\n' ' ')] extra [$(comm -13 <(printf '%s\n' "$want") <(printf '%s\n' "$have") | tr '\n' ' ')])"; rc=1
        elif [[ -z "$pmiss" ]]; then
            echo "  positive corpus: every row surfaces .... PASS ($(printf '%s\n' "$have" | grep -c .) of $(printf '%s\n' "$want" | grep -c .))"
        else echo "  positive corpus: every row surfaces .... FAIL (under-match: ${pmiss% })"; rc=1; fi
        # (7r) RED POLE: blank the FIRST row's sentence; the shared classifier must name exactly that id.
        pfirst="$(grep -v '^#' "$pfx" | grep . | head -1 | cut -f1)"
        pred="$(mktemp -t rcpos)" || die "mktemp failed"
        grep -v '^#' "$pfx" | awk -F'\t' -v i="$pfirst" 'BEGIN{OFS="\t"} $1==i {$2="The weather today is mild."} {print}' > "$pred"
        if [[ " $(posmiss "$pred")" == *" $pfirst "* ]]; then
            echo "  positive corpus red pole (blanked) ..... PASS (the pole can fail)"
        else echo "  positive corpus red pole (blanked) ..... FAIL (a blanked sentence still surfaced $pfirst)"; rc=1; fi
        rm -f "$pred"
        IDX="$fx"
    fi

    [[ $rc -eq 0 ]] && echo "SELF-TEST: PASS" || echo "SELF-TEST: FAIL"
    exit $rc
    ;;
  retrieve)
    body=""; label="${DRAFT:-<no file>}"
    if [[ -n "$DRAFT" ]]; then
        [[ -r "$DRAFT" ]] || die "draft not readable: $DRAFT"
        body="$(cat "$DRAFT")" || die "could not read draft: $DRAFT"
    fi
    [[ -z "$DRAFT" && -z "$CLASSES" ]] && die "nothing to check: give a <draft-file> and/or --class X"
    [[ -n "$CLASSES" ]] && label="${label} --class ${CLASSES}"
    rows="$(retrieve "$body" "$CLASSES")"
    emit_receipt "$rows" "$label"
    if [[ "$STRICT" -eq 1 ]] && printf '%s\n' "$rows" | awk -F'\t' '$5=="1"' | grep -q .; then exit 2; fi
    exit 0
    ;;
esac
