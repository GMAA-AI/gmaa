#!/bin/bash
# scripts/seat-b6-stop.sh — Stop hook, beside the unchanged creed-scan entry. Three duties, in order,
# all keyed by THIS session_id:
#   1. E11: append `<utc> <session_id> <total_input_tokens> <pct>` to .claude/e11-tokens.log when the statusline
#      line is this session's AND its token reading is numeric (a `case` guard, like the B6 percent check below;
#      REPORT only, never scored; 0317 §2(iii); 0330 §6 — a null/non-numeric reading appends nothing).
#   0b. EVERY-STOP GUARD (0426 §4, which amends 0425 §5; numbered 0b so duties 2 and 3 keep their numbers; prior art: the
#      v1 orchestrator-keep-working.sh, whose stop_hook_active early exit is the loop guard): on EVERY Stop of an
#      orc|architect seat session (`agent_type` orc or architect, no `agent_id`, event Stop, no watchdog; the headless
#      auditor `claude -p` carries no agent_type, a subagent carries agent_id) a stop with `stop_hook_active` false
#      PROCEEDS iff (i) the owed set is empty, OR (ii) `last_assistant_message` carries a well-formed
#      `NAMED-WAIT: <item> on <seat> (—|--|-) <ender>` line and EVERY such line is legitimate (that seat was rung in
#      this turn: a Bash call running `doorbell.sh ring <seat>` AND a commit in this turn carrying a line for it, see
#      gt_lined (0495 R2(1): a ring with no line is a bare ring and counts for nothing); or the clause cites
#      `rung@<sha>` and `git rev-parse --verify <sha>^{commit}` succeeds (0495 R2(2)); or the seat is the operator and
#      the line cites DISC-ONE-DECISION-DOOR; or the ender carries a clock time with its frame, Z or UTC or an ISO stamp), OR (iii)
#      the turn hands off its own continuation (an own-session seat-intent, or a background task with status
#      running or pending). Otherwise it BLOCKS once (the next stop arrives with stop_hook_active true and proceeds).
#      Owed set, read from the record and never from the transcript's own check line: every seat = the lane's own
#      reader, `scripts/inbox.sh check` (the hub's delegates to inboxf.sh, whose N new already counts the unreaped
#      lane outbox mail), run with its consume-state write files diverted to a temp dir (INBOX_SHOWN_FILE,
#      INBOXF_SHOWN_FILE, INBOXF_SCREENED_FILE) so no consume state moves; N>0 new = owed. At a session's FIRST
#      stop only (<= 1 genuine prompt in the transcript) also the handoff surface's `## NEXT` item 1
#      (`scripts/seat-exit.sh next-state`, the one grammar). Facts (code.claude.com/docs/en/hooks, read 2026-10-12):
#      Stop input carries `stop_hook_active`, `last_assistant_message`, `background_tasks`, `transcript_path` (may
#      lag only the current turn's latest messages); 8 consecutive continuations is the harness cap; block =
#      stdout `{"decision":"block","reason":...}` exit 0; `systemMessage` = a warning shown to the user. Any error
#      inside the guard = a named HOOK-ERROR (seat-loop.log + systemMessage) and the stop proceeds (fail-open, loud).
#      GUARD_TRACE=1 (test seam) prints each tool call's ring class and each NAMED-WAIT verdict to stderr.
#   2. EXIT: a `.claude/seat-intent` written by THIS session (scripts/seat-exit.sh) -> send `/exit` to this seat's
#      own pane ($TMUX_PANE), DETACHED, after the turn has ended (0315 §2(c)), only when the exit predicate holds
#      (live subagents, recheck; 0336/0337); the sent-marker is per INTENT and a lost send is re-sent, max 3 (0337 §4).
#   3. B6: otherwise, key on total_input_tokens carried, never the pct:
#      >= 250,000 soft (restart at the next WP/wave boundary), >= 350,000 hard (never open a new WP), each
#      LATCHED once per session per level (.claude/b6-injected; hard also latches soft), printing the pct beside
#      the tokens. No WP counter (0344 §3), no mid-WP ceiling (0318 §1(b)). An own-session line whose token
#      reading is not numeric injects `B6 unevaluable: tokens not reported (pct=<P>)` once per session and falls
#      back to nothing (0344 §2(d); no percentage stand-in, inv #5).
# A foreign session's line (headless auditors share this worktree) triggers nothing. Always exits 0.
# Stop output shape verified live (code.claude.com/docs/en/hooks, "Stop decision control"):
# hookSpecificOutput.additionalContext = non-error feedback; the conversation continues.
# SEND_CMD (test seam only): the probe sets it to a recorder; unset = tmux.
set -u
IN="$(cat)"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
D="$ROOT/.claude"
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
# 0425 §5: unparseable input is no longer a silent exit (inv #5). Valid JSON with an empty session_id still is.
if ! printf '%s' "$IN" | jq -e 'type=="object"' >/dev/null 2>&1; then
  mkdir -p "$D" 2>/dev/null
  printf 'HOOK-ERROR %s seat-b6-stop input-unparseable\n' "$UTC" >> "$D/seat-loop.log" 2>/dev/null
  printf '%s\n' '{"systemMessage":"HOOK-ERROR: seat-b6-stop.sh could not parse its Stop input; the stop guard did not run and the stop proceeds."}'
  exit 0
fi
SID="$(printf '%s' "$IN" | jq -r '.session_id // empty' 2>/dev/null)"
[ -n "$SID" ] || exit 0
mkdir -p "$D" 2>/dev/null
SEND="${SEND_CMD:-tmux}"
# 0402 §5 item 1: seconds between the /exit Enter and the pane read that decides the option-1 key.
CONFIRM_DELAY="${CONFIRM_DELAY:-3}"

# --- own-session statusline reading (fields: sid tokens pct utc window) ---
TOK=""; PCT=""; OWN=""
if [ -f "$D/context-pct" ]; then
  read -r L_SID L_TOK L_PCT _ < "$D/context-pct" || true
  if [ "${L_SID:-}" = "$SID" ]; then TOK="$L_TOK"; PCT="$L_PCT"; OWN=1; fi
fi

# --- 1. E11 (numeric token readings only; null/non-numeric appends nothing, 0330 §6) ---
# (the watchdog is not a turn end: it appends nothing)
case "${SEAT_WATCHDOG:+wd}$TOK" in
  wd*|''|null|*[!0-9]*) : ;;
  *) printf '%s %s %s %s\n' "$UTC" "$SID" "$TOK" "$PCT" >> "$D/e11-tokens.log" 2>/dev/null ;;
esac

# --- 0b. EVERY-STOP GUARD (0426 §4; see the header) ---
GSYS=""; GBLOCK=""
gt_err() {  # $1 = named reason; loud (log + systemMessage), never fatal: the stop proceeds
  printf 'HOOK-ERROR %s seat-b6-stop %s\n' "$UTC" "$1" >> "$D/seat-loop.log" 2>/dev/null
  GSYS="${GSYS:+$GSYS }HOOK-ERROR: seat-b6-stop.sh stop guard: $1; the guard did not complete and the stop proceeds."
}
# Current turn = the entries after the LAST genuine user prompt (type user, content a string, or an array holding a
# text block and no tool_result block; isMeta entries are system injections, not prompts). Emits
# {ngen: genuine prompts in the transcript, calls: [{name, cmd}] of the current turn}. ngen <= 1 = this is the
# session's FIRST turn (derived from the transcript; no marker).
GT_JQ='
  def genuine: .type=="user" and (.isMeta != true) and (
    (.message.content|type)=="string" or
    ((.message.content|type)=="array" and any(.message.content[]; type=="object" and .type=="text") and all(.message.content[]; type!="object" or .type!="tool_result")));
  . as $a
  | ([range(0; $a|length) | select($a[.] | genuine)]) as $g
  | ($g | last // -1) as $li
  | $a[($li+1):] as $cur
  | { ngen: ($g|length),
      start: (if $li < 0 then null else (try ($a[$li].timestamp | sub("\\.[0-9]+Z$"; "Z") | fromdateiso8601 | floor) catch null) end),
      calls: [ $cur[] | select(.type=="assistant") | .message.content | arrays | .[] | select(type=="object" and .type=="tool_use")
               | {name: .name, cmd: ((.input.command // .input.file_path // .input.pattern // "") | tostring)} ] }'
# Rings in a list of Bash commands: the seat token of every segment that runs `doorbell.sh ring <seat>` (any path
# prefix; bash/sh/zsh [-c] allowed in front; token-exact; a segment that merely echoes the text is no ring).
RING_JQ='
  [ .[]? | split("\n")[] | split("[;&|]+"; "g")[]
    | gsub("[\"\\x27]"; "") | split("[[:space:]]+"; "g") | map(select(length > 0))
    | map(select(test("^[A-Za-z_][A-Za-z0-9_]*=") | not))
    | (if length >= 2 and (.[0] | test("^(bash|sh|zsh)$")) then (if .[1] == "-c" then .[2:] else .[1:] end) else . end)
    | (if length >= 1 then (.[0] |= ltrimstr("$(") | .[0] |= ltrimstr("(")) else . end)
    | select(length >= 3 and (.[0] | test("(^|/)doorbell\\.sh$")) and .[1] == "ring")
    | .[2] ]'
# Every well-formed `NAMED-WAIT: <item> on <seat> (—|--|-) <ender>` clause of the final message, each judged on its OWN seat:
# legit = its seat was rung this turn, OR seat operator + the same clause cites DISC-ONE-DECISION-DOOR, OR the ender
# carries a clock time WITH its frame (hh:mm[:ss] then Z|UTC, or an ISO yyyy-mm-ddThh:mm; a bare 14:00 does not count).
# CLAUSE SPLIT: one line may name several waits. After the line's `NAMED-WAIT:` marker the rest is cut into clauses at
# (a) `;` followed by a clause that itself reads `[NAMED-WAIT: ]<item> on <seat> (—|--|-) `, or (b) a second `NAMED-WAIT:`
# marker on the same line. A `;` inside an ender that does not open such a clause stays in that ender. A line whose first
# non-prefix character is a backtick (a code-quoted example of the grammar) is no wait: the prefix class has no backtick.
WAIT_JQ='
  def clock: test("(^|[^0-9:])[0-9]{1,2}:[0-9]{2}(:[0-9]{2})?[[:space:]]*(Z|UTC)([^A-Za-z]|$)") or test("[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}");
  def cut: split("[[:space:]]*;[[:space:]]+(?=(?:NAMED-WAIT:[[:space:]]+)?[^;]*?[[:space:]]on[[:space:]]+(?:the[[:space:]]+)?[^[:space:]]+[[:space:]]+(?:—|--|-)[[:space:]])|[[:space:]]+(?=NAMED-WAIT:[[:space:]])"; null);
  [ ($lam | split("\n")[]) as $l
    | ($l | capture("^[[:space:]>*_-]*NAMED-WAIT:[[:space:]]+(?<rest>[^[:space:]].*)$")? // empty) as $m
    | ($m.rest | cut[])
    | sub("^NAMED-WAIT:[[:space:]]+"; "") as $c
    | ($c | capture("^(?<item>[^[:space:]].*?)[[:space:]]+on[[:space:]]+(?:the[[:space:]]+)?(?<seat>[^[:space:]]+)[[:space:]]+(?:—|--|-)[[:space:]]+(?<ender>[^[:space:]].*)$")?)
    | . + {line: $c}   # line = the clause text, so the door cite is judged per clause
    | . as $w
    | ($rung | index($w.seat) != null) as $rang
    | ((($w.seat | ascii_downcase) == "operator") and ($w.line | contains("DISC-ONE-DECISION-DOOR"))) as $door
    | ($w.ender | clock) as $clk
    | ([$w.line | scan("rung@([0-9a-f]{7,40})(?![0-9A-Za-z])") | .[0]] | any(.[]; . as $s | (($ARGS.named.oksha // []) | index($s)) != null)) as $rat
    | $w + {rang: $rang, door: $door, clock: $clk, rung_at: $rat, legit: ($rang or $door or $clk or $rat)} ]'
# gt_lined <rung json> <turn-start epoch> (0495 R1(a), R2(1)): sets GT_LINED to the rung seats that have a committed LINE
# behind the ring. The line = a commit on HEAD whose committer time is at or after the turn's genuine prompt (the
# transcript's own stamp) and that touches: for a lane, its own message surface (lane-surface.sh lane_surface,
# derived from the lane's declared spine_write class; ACK.log lives there); for the hub (spine_write
# ALLOW), the rung lane's _orchestration/relay-inbox/<seat>/ or dispatch/LATEST.md. Returns 1 when the line cannot be
# measured (already gt_err'd, named): the caller proceeds like transcript-unreadable, never a silent pass or a guess.
gt_lined() {
  local in="$1" t0="$2" rl lane cls surf s hit ct
  GT_LINED="[]"
  case "$t0" in ''|null|*[!0-9]*) gt_err ring-line-unmeasurable:turn-start-unstamped; return 1 ;; esac
  rl="$(cd "$ROOT" && bash scripts/resolve-lane.sh 2>/dev/null)" || { gt_err ring-line-unmeasurable:lane-unresolved; return 1; }
  lane="$(printf '%s\n' "$rl" | sed -n 's/^lane=\([^ ]*\).*/\1/p' | tr -d "'\"")"
  cls="$(printf '%s\n' "$rl" | sed -n '/^lane=/s/.* spine_write=\([^ ]*\).*/\1/p' | tr -d "'\"")"
  [ -n "$lane" ] && [ -n "$cls" ] || { gt_err ring-line-unmeasurable:lane-unparsed; return 1; }
  if [ "$cls" != ALLOW ]; then
    surf="$(cd "$ROOT" && . scripts/lane-surface.sh 2>/dev/null && lane_surface "$lane" 2>/dev/null)" || { gt_err "ring-line-unmeasurable:no-surface-for-$lane"; return 1; }
  fi
  while IFS= read -r s; do
    [ -n "$s" ] || continue
    if [ "$cls" = ALLOW ]; then hit="$(git -C "$ROOT" log -1 --format='%H %ct' HEAD -- "_orchestration/relay-inbox/$s/" dispatch/LATEST.md 2>/dev/null)" || { gt_err ring-line-unmeasurable:git-log-failed; return 1; }
    else hit="$(git -C "$ROOT" log -1 --format='%H %ct' HEAD -- "$surf" 2>/dev/null)" || { gt_err ring-line-unmeasurable:git-log-failed; return 1; }
    fi
    ct="${hit#* }"
    if [ -n "$hit" ] && [ "$ct" -ge "$t0" ] 2>/dev/null; then
      GT_LINED="$(printf '%s' "$GT_LINED" | jq -c --arg s "$s" '. + [$s]')"
      [ -z "${GUARD_TRACE:-}" ] || printf 'GT-RING-LINE seat=%s line=%s\n' "$s" "${hit%% *}" >&2
    else
      [ -z "${GUARD_TRACE:-}" ] || printf 'GT-RING-LINE seat=%s line=none (bare ring)\n' "$s" >&2
    fi
  done < <(printf '%s' "$in" | jq -r '.[]' 2>/dev/null | sort -u)
  return 0
}
# gt_inbox: run the lane's own reader (scripts/inbox.sh check; the hub's delegates to inboxf.sh) exactly as the seat
# would, with its three consume-state WRITE files diverted to a temp dir (env overrides INBOX_SHOWN_FILE,
# INBOXF_SHOWN_FILE, INBOXF_SCREENED_FILE; unset = today's paths). The screened ids are COPIED in so the read is the
# seat's own read. Sets GT_INBOX_N (count) / returns 1 on a reader error (already gt_err'd).
gt_inbox() {
  local td out line pat rc
  GT_INBOX_N=""; GT_INBOX_LINE=""
  [ -f "$ROOT/scripts/inbox.sh" ] || { gt_err reader-missing; return 1; }
  td="$(mktemp -d "${TMPDIR:-/tmp}/stop-guard.XXXXXX" 2>/dev/null)" || { gt_err reader-tmpdir-failed; return 1; }
  : > "$td/shown"; : > "$td/fshown"
  [ -f "$D/inboxf-screened" ] && cp "$D/inboxf-screened" "$td/screened" 2>/dev/null
  out="$(cd "$ROOT" && INBOX_SHOWN_FILE="$td/shown" INBOXF_SHOWN_FILE="$td/fshown" INBOXF_SCREENED_FILE="$td/screened" bash scripts/inbox.sh check 2>/dev/null)"; rc=$?
  rm -f "$td/shown" "$td/fshown" "$td/screened"; rmdir "$td" 2>/dev/null
  if [ "$rc" -ne 0 ]; then gt_err "reader-failed-rc$rc"; return 1; fi
  # the hub's check line is its LAST line; a spoke's is its FIRST (relay bodies follow it and may quote the tag)
  line="$(printf '%s\n' "$out" | command grep -E '^INBOXF-CHECK: ' | tail -1)"
  [ -n "$line" ] || line="$(printf '%s\n' "$out" | command grep -E '^INBOX-CHECK: ' | head -1)"
  pat='^(INBOX|INBOXF)-CHECK: [^ ]+ ([0-9]+) new'
  GT_INBOX_LINE="$line"
  if [[ "$line" =~ $pat ]]; then GT_INBOX_N="${BASH_REMATCH[2]}"; return 0; fi
  pat='^(INBOX|INBOXF)-CHECK: [^ ]+ empty'
  if [[ "$line" =~ $pat ]]; then GT_INBOX_N=0; return 0; fi
  gt_err reader-line-unparseable; return 1
}
stop_guard() {
  local lam tp tv rung waits nw nbad why owed h f st tmp files c nm cmd r
  [ "$(printf '%s' "$IN" | jq -r '.hook_event_name // empty' 2>/dev/null)" = Stop ] || return 0
  [ -z "${SEAT_WATCHDOG:-}" ] || return 0
  case "$(printf '%s' "$IN" | jq -r '.agent_type // empty' 2>/dev/null)" in orc|architect) ;; *) return 0 ;; esac
  [ -z "$(printf '%s' "$IN" | jq -r '.agent_id // empty' 2>/dev/null)" ] || return 0
  # LOOP GUARD (v1 orchestrator-keep-working.sh): the stop that follows a stop-hook continuation proceeds
  [ "$(printf '%s' "$IN" | jq -r '.stop_hook_active // false' 2>/dev/null)" = true ] && return 0
  # (iii) the turn hands off its own continuation: an own-session seat-exit intent, or a background task in flight
  if [ -f "$D/seat-intent" ]; then
    read -r _ gt_isid _ < "$D/seat-intent" || true
    [ "${gt_isid:-}" = "$SID" ] && return 0
  fi
  printf '%s' "$IN" | jq -e '[(.background_tasks // [])[]? | select((.status // "" | ascii_downcase) | IN("running","pending"))] | length > 0' >/dev/null 2>&1 && return 0
  lam="$(printf '%s' "$IN" | jq -r '.last_assistant_message // empty' 2>/dev/null)"
  tp="$(printf '%s' "$IN" | jq -r '.transcript_path // empty' 2>/dev/null)"
  tv=""; rung="[]"
  # 0495 R2(2): the rung@<sha> citations of the final message that resolve to a commit here (git rev-parse --verify)
  oksha="[]"
  while IFS= read -r r; do
    [ -n "$r" ] || continue
    git -C "$ROOT" rev-parse -q --verify "${r}^{commit}" >/dev/null 2>&1 && oksha="$(printf '%s' "$oksha" | jq -c --arg s "$r" '. + [$s]')"
  done < <(printf '%s\n' "$lam" | /usr/bin/grep -oE 'rung@[0-9a-f]{7,40}' | sed 's/^rung@//' | sort -u)
  gt_transcript() {  # reads the transcript once; 0 = tv holds the current-turn view
    [ -z "$tv" ] || return 0
    if [ -z "$tp" ] || [ ! -r "$tp" ]; then return 1; fi
    tv="$(jq -s -c "$GT_JQ" "$tp" 2>/dev/null)" || tv=""
    printf '%s' "$tv" | jq -e 'type=="object"' >/dev/null 2>&1 || { tv=""; return 1; }
    rung="$(printf '%s' "$tv" | jq -c "[.calls[] | select(.name==\"Bash\") | .cmd] | $RING_JQ" 2>/dev/null)" || rung="[]"
    [ -n "$rung" ] || rung="[]"
    if [ -n "${GUARD_TRACE:-}" ]; then  # test seam: one line per tool call of the turn
      while IFS= read -r c; do
        [ -n "$c" ] || continue
        nm="$(printf '%s' "$c" | jq -r '.name')"; cmd="$(printf '%s' "$c" | jq -r '.cmd')"
        r="$(printf '%s' "$cmd" | jq -Rsc "[.] | $RING_JQ" 2>/dev/null)"
        if [ "$nm" = Bash ] && [ -n "$r" ] && [ "$r" != "[]" ]; then printf 'GT-CALL RING %s %s\n' "$r" "$(printf '%s' "$cmd" | tr '\n' ' ' | cut -c1-100)" >&2
        else printf 'GT-CALL - %s %s\n' "$nm" "$(printf '%s' "$cmd" | tr '\n' ' ' | cut -c1-100)" >&2; fi
      done < <(printf '%s' "$tv" | jq -c '.calls[]' 2>/dev/null)
    fi
    return 0
  }
  [ -z "${GUARD_TRACE:-}" ] || gt_transcript || true   # test seam: the per-call table is printed even when no verdict needs the transcript
  # (ii) a well-formed NAMED-WAIT whose every line is legitimate
  why="no-named-wait"
  if printf '%s\n' "$lam" | /usr/bin/grep -q 'NAMED-WAIT'; then why="malformed-named-wait"; fi
  waits="$(jq -nc --arg lam "$lam" --argjson rung '[]' --argjson oksha "$oksha" "$WAIT_JQ" 2>/dev/null)" || waits="[]"
  nw="$(printf '%s' "$waits" | jq 'length' 2>/dev/null)"; nw="${nw:-0}"
  [ "$nw" -gt 0 ] || [ -z "${GUARD_TRACE:-}" ] || printf 'GT-WAIT NONE well-formed-lines=0 (%s)\n' "$why" >&2
  if [ "$nw" -gt 0 ]; then
    # a ring has to be read from the turn's tool calls; the transcript is needed unless every line proves itself
    nbad="$(printf '%s' "$waits" | jq '[.[] | select((.door or .clock or .rung_at) | not)] | length' 2>/dev/null)"; nbad="${nbad:-0}"
    if [ "$nbad" -gt 0 ]; then
      if ! gt_transcript; then gt_err transcript-unreadable; return 0; fi
      # 0495 R2(1): a ring counts only with its committed line; the seats rung with no line drop out (bare rings). An
      # unmeasurable line is a named HOOK-ERROR (gt_lined) and the stop proceeds, as for transcript-unreadable.
      if [ "$rung" != "[]" ]; then
        if gt_lined "$rung" "$(printf '%s' "$tv" | jq -r '.start // empty' 2>/dev/null)"; then rung="$GT_LINED"; else return 0; fi
      fi
      waits="$(jq -nc --arg lam "$lam" --argjson rung "$rung" --argjson oksha "$oksha" "$WAIT_JQ" 2>/dev/null)" || waits="[]"
    fi
    [ -z "${GUARD_TRACE:-}" ] || printf '%s' "$waits" | jq -r '.[] | "GT-WAIT \(if .legit then "LEGIT" else "UNLEGIT" end) seat=\(.seat) rang=\(.rang) door=\(.door) clock=\(.clock) rung_at=\(.rung_at)"' >&2
    if printf '%s' "$waits" | jq -e 'all(.[]; .legit)' >/dev/null 2>&1; then return 0; fi
    why="unlegit-named-wait:$(printf '%s' "$waits" | jq -r '[.[] | select(.legit | not) | .seat] | join(",")' 2>/dev/null)"
  fi
  # (i) the owed set, read from the record (never the transcript's own check line; no consume state written)
  owed=""
  if gt_inbox; then
    if [ "${GT_INBOX_N:-0}" -gt 0 ]; then owed="the inbox holds $GT_INBOX_N new relay(s) ($GT_INBOX_LINE)"; fi
  fi
  if [ -z "$owed" ]; then
    # first stop of the session only: the handoff surface's '## NEXT' item 1 (0425 §2-§4)
    if gt_transcript; then
      if [ "$(printf '%s' "$tv" | jq -r '(.ngen // 0) <= 1' 2>/dev/null)" = true ]; then
        h="$(bash "$ROOT/scripts/resolve-project.sh" --field handoff "$ROOT" 2>/dev/null)" || h=""
        if [ -n "$h" ] && [ -f "$ROOT/scripts/seat-exit.sh" ]; then
          if [ -f "$ROOT/${h%/}" ]; then files="${h%/}"
          else
            files="$(git -C "$ROOT" log -1 -G'^## NEXT' --name-only --format= -- "$h" 2>/dev/null)" || { gt_err handoff-git-failed; files=""; }
            files="$(printf '%s\n' "$files" | /usr/bin/grep '\.md$')"
          fi
          tmp="$D/.stop-guard-next.$$"
          while IFS= read -r f; do
            [ -n "$f" ] || continue
            git -C "$ROOT" show "HEAD:$f" > "$tmp" 2>/dev/null || continue
            st="$(bash "$ROOT/scripts/seat-exit.sh" next-state "$tmp" 2>/dev/null)"
            if [ "$st" = ITEM ]; then owed="the handoff $f carries an open '## NEXT' item 1"; break; fi
          done <<< "$files"
          rm -f "$tmp"
        fi
      fi
    else
      gt_err transcript-unreadable-first-stop-half
    fi
  fi
  [ -n "$owed" ] || return 0
  GBLOCK="STOP GUARD (0426 §4; 0109 §6 inv 4): this turn ended neither WORKING nor in a legitimate NAMED-WAIT while $owed. End WORKING (act on the first owed item now), or end with one line \`NAMED-WAIT: <item> on <seat> — <what would end it>\` and ring that seat this turn (scripts/doorbell.sh ring <lane>) with a committed line behind the ring (0495 R1: a lane's outbox ACK.log line or relay; the hub's inbox relay or dispatch/LATEST.md), or, when nothing is new for that seat, cite rung@<sha> of the commit carrying your last line and ring nothing. Only the operator under DISC-ONE-DECISION-DOOR, or a clock-time ender in UTC, needs no ring."
  printf 'STOP-GUARD-BLOCK %s %s %s | %s\n' "$UTC" "$SID" "$owed" "$why" >> "$D/seat-loop.log" 2>/dev/null
}
stop_guard
if [ -n "$GSYS" ]; then
  # a guard error rides the stop's single JSON document: later output is buffered and merged with the systemMessage.
  # (No detached child can inherit fd 3: the guard only runs with no own-session intent, so duty 2 never sends.)
  GOUT="$D/.stop-out.$$"; exec 3>&1 1>"$GOUT"
  gt_merge() {
    exec 1>&3 3>&-
    if [ -s "$GOUT" ] && jq -e 'type=="object"' "$GOUT" >/dev/null 2>&1; then jq -c --arg s "$GSYS" '. + {systemMessage: $s}' "$GOUT"
    else jq -nc --arg s "$GSYS" '{systemMessage: $s}'; fi
    rm -f "$GOUT"
  }
  trap gt_merge EXIT
fi
if [ -n "$GBLOCK" ]; then jq -n --arg r "$GBLOCK" '{decision: "block", reason: $r}'; exit 0; fi

# --- 2. EXIT on an own-session intent ---
# The exit predicate, ONE definition, run by this hook at every own-session turn end AND by the watchdog
# (SEAT_WATCHDOG=1, armed by seat-exit.sh) exactly once at the deadline:
#   (i)   every live ledger entry of THIS session is gone, or past its effective cap + ABANDON_AFTER_MIN
#         (scripts/subagent-lib.sh); entries past the cap print SUBAGENT-STALE once, and are abandoned (recorded
#         in .claude/subagents-abandoned) at the send, never silently;
#   (ii)  seat-exit.sh's own checks re-pass now, at the current HEAD (`seat-exit.sh recheck`);
#   (iii) the intent is still present (it is: we are inside this branch).
# A failed check: the hook logs `SEAT-EXIT-WAIT <check>` and injects it ONCE per intent per check (latched); the
# watchdog logs `SEAT-EXIT-WATCHDOG-REFUSED <check>` and ends. Neither loops.
# SEND RE-ARM (0337 §4, cures ISSUE-SEAT-EXIT-ONE-SHOT-BLIND-SEND): the sent-marker is keyed by the INTENT
# (session_id + the intent's epoch), not by the session. If this hook fires for an intent already marked sent,
# the session is still alive, so that send was LOST: log `SEAT-EXIT-LOST`, send again. At most 3 sends per
# intent; then `SEAT-EXIT-GAVE-UP` + one injected line telling the seat to /exit by hand (inv #5).
if [ -f "$D/seat-intent" ]; then
  read -r I_KIND I_SID _ I_EPOCH _ < "$D/seat-intent" || true
  if [ "${I_SID:-}" = "$SID" ] && [ -n "${TMUX_PANE:-}" ]; then
    # shellcheck source=scripts/subagent-lib.sh
    . "$ROOT/scripts/subagent-lib.sh" 2>/dev/null || { echo "SEAT-EXIT-WAIT $UTC $SID lib-unreadable" >> "$D/seat-loop.log"; exit 0; }
    case "${I_EPOCH:-}" in ''|*[!0-9]*) I_EPOCH="" ;; esac
    WD="${SEAT_WATCHDOG:-}"; NOW="$(sa_now)"; WAIT=""; WHY=""
    while IFS=$'\t' read -r _ aid _ st _ _; do
      [ -n "$aid" ] || continue
      age=$((NOW - st)); cap="$(sa_eff_cap "$st" "$I_EPOCH")"
      if [ "$age" -ge "$cap" ] && ! /usr/bin/grep -qx "$SID $aid" "$D/subagent-stale" 2>/dev/null; then
        printf '%s %s\n' "$SID" "$aid" >> "$D/subagent-stale"
        printf 'SUBAGENT-STALE %s %s %s age=%ss cap=%ss\n' "$UTC" "$SID" "$aid" "$age" "$cap" >> "$D/seat-loop.log"
      fi
      [ "$age" -lt $((cap + ABANDON_AFTER_MIN * 60)) ] && WAIT="$WAIT $aid(${age}s/${cap}s)"
    done < <(sa_live "$D" "$SID")
    if [ -n "$WAIT" ]; then WHY="subagents-live:$WAIT"
    else
      RC_OUT="$(cd "$ROOT" && SEAT_SID="$SID" bash "$ROOT/scripts/seat-exit.sh" recheck 2>&1)" \
        || WHY="recheck: $(printf '%s' "$RC_OUT" | tr '\n' ' ' | cut -c1-300)"
    fi
    if [ -n "$WHY" ]; then
      if [ -n "$WD" ]; then
        printf 'SEAT-EXIT-WATCHDOG-REFUSED %s %s %s\n' "$UTC" "$SID" "$WHY" >> "$D/seat-loop.log"; exit 0
      fi
      printf 'SEAT-EXIT-WAIT %s %s %s\n' "$UTC" "$SID" "$WHY" >> "$D/seat-loop.log"
      CAT="${WHY%%:*}"
      if ! /usr/bin/grep -qx "$SID $I_EPOCH $CAT" "$D/seat-exit-wait" 2>/dev/null; then
        printf '%s %s %s\n' "$SID" "$I_EPOCH" "$CAT" >> "$D/seat-exit-wait"
        jq -n --arg m "SEAT-EXIT pending, not sent yet: $WHY. Subagents: integrate each deliverable as it hands back (commit it, or name its path in the handoff). The exit fires at the first turn end where every check passes, or from the watchdog at the deadline." \
          '{hookSpecificOutput: {hookEventName: "Stop", additionalContext: $m}}'
      fi
      exit 0
    fi
    M_SID=""; M_EP=""; M_N=""
    [ -f "$D/seat-exit-sent" ] && { read -r M_SID M_EP M_N < "$D/seat-exit-sent" || true; }
    N=0; [ "$M_SID" = "$SID" ] && [ "$M_EP" = "$I_EPOCH" ] && N="${M_N:-0}"
    [ "$N" = gaveup ] && exit 0
    case "$N" in ''|*[!0-9]*) N=0 ;; esac
    [ "$N" -ge 1 ] && printf 'SEAT-EXIT-LOST %s %s %s %s\n' "$UTC" "$SID" "$I_EPOCH" "$N" >> "$D/seat-loop.log"
    if [ "$N" -ge 3 ]; then
      printf '%s %s gaveup\n' "$SID" "$I_EPOCH" > "$D/seat-exit-sent"
      printf 'SEAT-EXIT-GAVE-UP %s %s %s after %s sends\n' "$UTC" "$SID" "$I_EPOCH" "$N" >> "$D/seat-loop.log"
      [ -n "$WD" ] || jq -n --arg m "SEAT-EXIT-GAVE-UP: /exit was sent ${N} times for this intent and this session is still alive. Type /exit in this pane by hand now; the loop then relaunches (restart) or ends (shutdown)." \
        '{hookSpecificOutput: {hookEventName: "Stop", additionalContext: $m}}'
      exit 0
    fi
    # (The agent-view precondition that stood here is removed: the exit dialog is answered with option 1, which needs
    # no agent view, and the seat settings turn agent view off so no move path opens.)
    # BOUNDARY SEAL (MECH-AUDIT, loop-cure member A1): ONE `[audit] seal` per restart boundary, written here,
    # after every exit check has passed and before the first send. A re-send (N >= 1) does not seal again. A failed
    # seal KEEPS its sentinels and does NOT send /exit (inv #5): the seat is told once, and the next turn end retries.
    if [ "$N" -eq 0 ]; then
      SEAL_OUT="$(cd "$ROOT" && bash "$ROOT/scripts/audit-seal.sh" "${I_KIND:-restart}" 2>&1)"; SEAL_RC=$?
      printf '%s\n' "$SEAL_OUT" | sed "s/^/SEAT-SEAL $UTC $SID /" >> "$D/seat-loop.log"
      if [ "$SEAL_RC" -ne 0 ]; then
        printf 'SEAL-FAILED %s %s rc=%s\n' "$UTC" "$SID" "$SEAL_RC" >> "$D/seat-loop.log"
        [ -n "$WD" ] && exit 0
        jq -n --arg m "SEAL-FAILED at the restart boundary (rc=${SEAL_RC}); /exit was NOT sent. $(printf '%s' "$SEAL_OUT" | tr '\n' ' ' | cut -c1-300) Fix the cause, then end the turn again (the intent stands)." \
          '{hookSpecificOutput: {hookEventName: "Stop", additionalContext: $m}}'
        exit 0
      fi
      # 0397 §3 member 3, wired right after audit-seal.sh at this same restart boundary (N -eq 0, once per
      # boundary, never on a re-send). FAIL-SAFE BY DESIGN (unlike the audit seal above): a seal-rulings
      # failure never blocks the restart and never swallows silently (DISC-CHILD-FAILURE-MUST-SURFACE) — it
      # prints a named SEAL-RULINGS-FAILED line to the loop log and the turn's own exit proceeds unchanged.
      SR_OUT="$(cd "$ROOT" && bash "$ROOT/scripts/seal-rulings.sh" --commit 2>&1)"; SR_RC=$?
      printf '%s\n' "$SR_OUT" | sed "s/^/SEAT-SEAL-RULINGS $UTC $SID /" >> "$D/seat-loop.log"
      if [ "$SR_RC" -ne 0 ]; then
        printf 'SEAL-RULINGS-FAILED %s %s rc=%s (non-blocking; /exit proceeds)\n' "$UTC" "$SID" "$SR_RC" >> "$D/seat-loop.log"
      fi
    fi
    sa_abandon "$D" "$SID" "$NOW" "$I_EPOCH"
    printf '%s %s %s\n' "$SID" "$I_EPOCH" "$((N + 1))" > "$D/seat-exit-sent"
    # 0444 R3: the send + 0387 verifier have ONE definition, `scripts/seat-exit.sh send`, shared with the watchdog;
    # run by absolute path (byte-identical to the block that stood here; parity-checked at the cut).
    SEND_CMD="$SEND" CONFIRM_DELAY="$CONFIRM_DELAY" bash "$ROOT/scripts/seat-exit.sh" send "$ROOT" "$SID" "$TMUX_PANE" \
      "${I_KIND:-?}" "$((N + 1))" ${WD:+watchdog} 2>/dev/null
    exit 0
  fi
fi
[ -n "${SEAT_WATCHDOG:-}" ] && { printf 'SEAT-EXIT-WATCHDOG-REFUSED %s %s no-own-intent\n' "$UTC" "$SID" >> "$D/seat-loop.log"; exit 0; }

# --- 3. B6 injection (absolute tokens carried) ---
# A foreign session's line (or none) is no reading for this session: nothing (headless auditors share the tree).
[ -n "$OWN" ] || exit 0
SOFT=250000; HARD=350000
case "$TOK" in
  ''|null|*[!0-9]*)
    # 0344 §2(d): the token reading is not numeric -> one line per session, then nothing; never a pct stand-in.
    /usr/bin/grep -qx "$SID unevaluable" "$D/b6-injected" 2>/dev/null && exit 0
    printf '%s unevaluable\n' "$SID" >> "$D/b6-injected"
    jq -n --arg m "B6 unevaluable: tokens not reported (pct=${PCT:-none})" '{hookSpecificOutput: {hookEventName: "Stop", additionalContext: $m}}'
    exit 0 ;;
esac
LEVEL=""
if [ "$TOK" -ge "$HARD" ]; then LEVEL=hard; elif [ "$TOK" -ge "$SOFT" ]; then LEVEL=soft; fi
[ -n "$LEVEL" ] || exit 0
if /usr/bin/grep -qx "$SID $LEVEL" "$D/b6-injected" 2>/dev/null; then exit 0; fi
printf '%s %s\n' "$SID" "$LEVEL" >> "$D/b6-injected"
[ "$LEVEL" = hard ] && printf '%s soft\n' "$SID" >> "$D/b6-injected"
case "$PCT" in ''|null|*[!0-9]*) PCTS="pct not reported" ;; *) PCTS="${PCT}% of the running window" ;; esac
if [ "$LEVEL" = hard ]; then
  MSG="B6 boundary (CLAUDE.md s7 B6.2): context ${TOK} tokens carried (${PCTS}). Never OPEN a new WP above ~350K tokens carried. Finish or park the current WP, externalize per B6.1 (WIP committed; your handoff surface written and committed), then run scripts/seat-exit.sh restart as your last act."
else
  MSG="B6 boundary (CLAUDE.md s7 B6.2): context ${TOK} tokens carried (${PCTS}). Past ~250K tokens carried: RESTART at the next WP or wave boundary (no mid-WP restart). At that boundary externalize per B6.1, then run scripts/seat-exit.sh restart as your last act."
fi
jq -n --arg m "$MSG" '{hookSpecificOutput: {hookEventName: "Stop", additionalContext: $m}}'
exit 0
