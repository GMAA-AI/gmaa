#!/usr/bin/env bash
# scripts/governance.sh <topic...> — GOVERNANCE-CHECK Phase 2 (cite-before-raise / cite-before-reopen).
#
# WHY: "no settled decision is re-raised" (issues_register header). Phase 1 = the orc.md invariant (self-run,
# skippable). This is Phase 2: an enforcer that greps the CHRONOLOGICAL INDEX independent of an agent's own
# compliance — the same way the post-commit auditor hook fires regardless of the persona. Run it BEFORE
# raising an issue / routing a "blocker" / reopening a settled decision.
#
# READ ORDER (supersession-aware — the LATEST dated state wins, never the first match):
#   1. decision-log.md    (already ruled?)
#   2. issues_register.md  (already resolved? at what LATEST state?)
#   3. contracts/**        (the current frozen rule the above point to)
#   4. _rulings/**         (the BINDING ruling log — "a ruling not in _rulings/ does not exist")
#   5. the canon           (GOVERNED_MULTI_AGENT_ARCHITECTURE_v*.md — the governance model itself)
# Sourced from the SPINE via `git show main:` / `git grep main` so it is correct from ANY lane worktree, and
# so a lane reads CURRENT governance rather than its own branch copy (operator 2026-09-22: "the lanes are
# supposed to be able to read the spine, never write to it"). Read-only; zero API/SQL.
#
# ⭐ L1 LANDED HERE. BEFORE: this script read 3 of the 5 surfaces
# `CLAUDE.md §GOVERNANCE-CHECK` names — `_rulings` and the canon appeared 0 times each (measured with a
# positive control: decision-log/issues_register/contracts appeared 5/6/5 in the same file). The adjudicator
# seat is REQUIRED to cite `_rulings/**` inline and had NO mechanical path to it. The governing ruling
# asks for these two "in addition to its current three surfaces" — so they are ADDED, nothing is replaced.
#
# ⛔ THE PROPERTY THAT MATTERS MOST — THIS TOOL MUST NOT MANUFACTURE A FALSE ABSENCE.
# A retriever that silently reads nothing and prints "silent-or-contradictory" LICENSES a raise the record
# already answers — which is the single most expensive failure shape this system has (CLAUDE.md
# §GOVERNANCE-CHECK). So every surface read is CHECKED, and an unreadable surface HALTs LOUD (exit 3) rather
# than degrading into a clean-looking "no hits" (inv #5 halt-loud-over-silent-degradation;
# DISC-CHILD-FAILURE-MUST-SURFACE — distinguish "empty because nothing" from "empty because it FAILED";
# DISC-ABSENCE-OF-RECORD — an absence is evidence ONLY when the recording mechanism is proven live).
# The SURFACES READ line is printed on EVERY run, hit or miss, so the denominator is always on the record.
#
# NOTE on `grep`: this is a bash script, so `grep` is the real grep. It does NOT inherit the interactive
# ugrep shim that under-matches certain quoted patterns (ISSUE-AGENT-TYPED-GREP-…-DOUBLE-QUOTE-2026-09-22,
# P2). A maintainer testing these pipelines by hand in a terminal SHOULD use `command grep`.
#
# Usage:  scripts/governance.sh <keyword> [more keywords...]      # ORs the keywords into one case-insensitive pattern
# Emits:  GOVERNANCE-CHECK: <topic> answered@<refs>   (DO NOT raise/reopen — cite the ref)
#     or: GOVERNANCE-CHECK: <topic> silent-or-contradictory   (raise/reopen IS legitimate; attach this read)
# Exit:   0 = answered · 1 = silent-or-contradictory · 2 = usage · 3 = HALT (a surface could not be read)
set -u

[[ $# -ge 1 ]] || { echo "usage: governance.sh <keyword> [more keywords...]" >&2; exit 2; }
topic="$*"
# Build a case-insensitive ERE from all args (space-separated -> alternation).
pat=""; for w in "$@"; do w="${w//[^A-Za-z0-9_.-]/}"; [[ -n "$w" ]] || continue; pat="${pat:+$pat|}$w"; done
[[ -n "$pat" ]] || { echo "governance.sh: no usable keyword after sanitising '$topic'" >&2; exit 2; }

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "governance.sh: not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2
eval "$(scripts/resolve-lane.sh 2>/dev/null)" 2>/dev/null || true
lane="${lane:-?}"

halt() { echo "GOVERNANCE-CHECK: HALT — $*" >&2; echo "  REFUSING to print a 'silent-or-contradictory' verdict on an unread surface: that would license a raise the record may already answer (inv #5)." >&2; exit 3; }

# ── Surface 1+2: the chronological index, read from the spine ────────────────
DLOG="$(git show main:_orchestration/decision-log.md 2>/dev/null)" \
  || halt "cannot read main:_orchestration/decision-log.md"
IREG="$(git show main:issues_register.md 2>/dev/null)" \
  || halt "cannot read main:issues_register.md"

# ── Surface 5: THE CANON — resolved DYNAMICALLY, never hardcoded ─────────────
# A hardcoded `v1_6_5` goes stale at the next cut and would read a superseded edition while reporting
# success (the CLAUDE.md §Reference pointer did exactly this, three editions deep). Anchored so the
# `_PUBLIC` cut is excluded; `sort -V` verified correct across double digits (v1_6_5 < v1_6_10 < v1_7).
# ONE shared resolver — the reconciler sources the same function.
source "$(dirname "${BASH_SOURCE[0]}")/canon-core.sh" || halt "cannot source scripts/canon-core.sh (the shared canon resolver)"
CANON="$(canon_resolve main)"
[[ -n "$CANON" ]] || halt "no canon file matched ^GOVERNED_MULTI_AGENT_ARCHITECTURE_v[0-9_]+\.md\$ at main — the canon is a REQUIRED read-order surface"

# ── Run the five reads ───────────────────────────────────────────────────────
# 1) decision-log hits (line-numbered; agent applies supersession — newest dated entry wins)
dlog_hits="$(printf '%s\n' "$DLOG" | grep -niE "$pat" 2>/dev/null | head -10 || true)"
# 2) issues_register hits (ISSUE headers + Status carry the LATEST resolved/reopened state)
ireg_hits="$(printf '%s\n' "$IREG" | grep -niE "$pat" 2>/dev/null | head -10 || true)"
# 3) contracts whose filename matches the topic (the frozen rule)
cfiles="$(git ls-tree -r --name-only main -- contracts 2>/dev/null | grep -iE "$pat" 2>/dev/null || true)"

# 4) _rulings/** — BOTH by slug and by CONTENT, newest ordinal FIRST (higher ordinal = later = supersedes).
#    Slug-only would miss a ruling whose subject is in its body; content-only would miss a ruling whose
#    slug names the topic in words its body never repeats. Both, because either alone is a false absence.
rul_files="$(git ls-tree -r --name-only main -- _rulings 2>/dev/null | grep -iE "$pat" 2>/dev/null | sort -r | head -10 || true)"
rul_body="$(git grep -niE "$pat" main -- '_rulings/*.md' 2>/dev/null | sed 's|^main:||' | sort -r | head -10 || true)"

# 5) the canon
canon_hits="$(git grep -niE "$pat" main -- "$CANON" 2>/dev/null | sed 's|^main:||' | head -10 || true)"

hit=0; [[ -n "$dlog_hits$ireg_hits$cfiles$rul_files$rul_body$canon_hits" ]] && hit=1

HEAD_SHA="$(git rev-parse --short main 2>/dev/null || echo '?')"
echo "── GOVERNANCE-CHECK (lane=$lane · topic='$topic' · through main HEAD $HEAD_SHA) ──"
# The denominator, on EVERY run — hit or miss. A verdict whose surface-set is invisible is not a receipt.
echo "   SURFACES READ (5/5): decision-log · issues_register · contracts/** · _rulings/** · $CANON"

if [[ "$hit" -eq 1 ]]; then
  echo "GOVERNANCE-CHECK: ${topic} answered@[index-hits-below] — READ the LATEST dated state, then CITE it. DO NOT re-raise/re-derive."
  if [[ -n "$dlog_hits" ]]; then echo; echo "  decision-log.md (§ ruled? — newest dated entry wins):"; printf '%s\n' "$dlog_hits" | sed 's/^/    /'; fi
  if [[ -n "$ireg_hits" ]]; then echo; echo "  issues_register.md (resolved? at what LATEST state? read the full RESOLVED->REOPENED->RE-CLOSED chain):"; printf '%s\n' "$ireg_hits" | sed 's/^/    /'; fi
  if [[ -n "$cfiles"    ]]; then echo; echo "  contracts/** (the frozen rule):"; printf '%s\n' "$cfiles" | sed 's/^/    /'; fi
  if [[ -n "$rul_files" ]]; then echo; echo "  _rulings/** BY SLUG (BINDING — newest ordinal first; a ruling not in _rulings/ does not exist):"; printf '%s\n' "$rul_files" | sed 's/^/    /'; fi
  if [[ -n "$rul_body"  ]]; then echo; echo "  _rulings/** BY CONTENT (open the highest ordinal FIRST — later ordinals supersede earlier ones):"; printf '%s\n' "$rul_body" | sed 's/^/    /'; fi
  if [[ -n "$canon_hits" ]]; then echo; echo "  the canon ($CANON — the governance model itself; amendments by versioned revision only):"; printf '%s\n' "$canon_hits" | sed 's/^/    /'; fi
  echo; echo "  RULE: if the read covers your topic -> the issue does not exist; drop it, cite the ref. Only silence/contradiction licenses a raise."
  echo "  ⚠ A HIT IS NOT DISPOSITIONED UNTIL IT IS OPENED (DISC-ABSENCE-OF-RECORD §1(4)) — dismissing a hit from its path is an inference wearing a receipt's clothes."
  exit 0
else
  echo "GOVERNANCE-CHECK: ${topic} silent-or-contradictory — no chronological-index hit through main HEAD $HEAD_SHA."
  echo "  All 5 surfaces above were READ SUCCESSFULLY and are genuinely empty for this pattern (an unreadable surface would have HALTed at exit 3, never reached this line)."
  echo "  A raise/reopen IS legitimate. Attach this read as evidence: the 5 surfaces, the HEAD, and the gap."
  exit 1
fi
