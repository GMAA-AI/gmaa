#!/usr/bin/env bash
# scripts/pending-set.sh — the pending-set ledger instrument (M1/M2 of the set-level
# authorization mechanism; canon §4). Three verbs:
#
#   list                    read-only: print the ledger's THE SET rows (any seat)
#   member <id> ...         module-side: write a member entry to this lane's relay-outbox
#                           (fail-closed: empty --surfaces is REFUSED). §4a: the member is an
#                           EXTENSIBLE multi-substrate permanent-record MANIFEST — --declared-effects
#                           'db: …; make: …; wp: …' admits cross-substrate declarations (git today,
#                           every declared substrate later, no redesign); U4B checks declared-effect vs §5 structure.
#   reap <member-file>      foundation-only: append a `pending` row to PENDING-SET.md
#
# PROVENANCE (set-gate Phase-1, P1.1/P1.2 per the BYTE-GROUNDED lift map):
#   LIFTED from GMAA frozen 7a179264d5091ce0f8eabad754495786e48c8fce
#   (build/releases/v2.5.4.2/work/scripts/pending-set.sh). The GMAA copy was itself
#   genericized FROM our origin PENDING-SET.md maintenance law (canon §4) with identity
#   stripped + mechanism whole, so this is a near-verbatim re-lift — no `executor`→`<execution-lane>`
#   translation is needed (the mechanism references no lane by name; lane identity comes
#   from LOCATION via scripts/resolve-lane.sh, the same resolver our cold-boot seat +
#   pre-commit hook consume). PENDING-SET.md itself is spine-owned — a module lane that
#   stages it is REJECTED by agents/pre-commit-hook.sh; members reach the ledger only
#   through foundation's `reap`. Consumes our _orchestration/relay-outbox/<lane>/ convention.
#   The machine set-membership schema this instrument reads/writes lives in PENDING-SET.md
#   `## THE SET` (| # | member id | lane | branch@sha-range | surfaces touched | status |).

# --- LAZY loader for the single authorization-input predicate. ---
# ⛔ THE REGRESSION THIS FIXES: this block used to SOURCE the validator EAGERLY at
# load time and exit non-zero when absent. The installed pre-commit hook is SHARED by every worktree
# while the validator lives on `main`, so EVERY commit in EVERY non-main worktree fail-closed —
# including commits staging NO spine path, which would never parse a surfaces token. 5 of 7 worktrees
# were frozen. ***A fail-closed check must fire on the INPUT IT JUDGES, never on every caller that
# merely loads the file.*** Still fail-closed — but at the point of use, where the refusal is true.
_load_surftok() {
    local f; f="$(git rev-parse --show-toplevel 2>/dev/null)/scripts/surfaces-token.sh"
    if [[ -r "$f" ]]; then . "$f"; return 0; fi
    echo "REFUSED: shared surfaces-token validator missing at $f (fail-closed — no private fallback predicate). Reached ONLY because a surfaces token had to be parsed here." >&2
    return 1
}

set -u

LEDGER_NAME="PENDING-SET.md"

die()  { echo "pending-set: $*" >&2; exit 1; }
halt() { echo "pending-set HALT: $*" >&2; exit 3; }
repo_root() { git rev-parse --show-toplevel 2>/dev/null || die "not inside a git worktree (fail-closed)."; }

# need_val — cure for ISSUE-TRAILING-VALUE-FLAG-SPINS-FOREVER-IN-FIVE-SCRIPTS (SET-0083 shape,
# carried verbatim from scripts/creed-scan.sh need_val()/flag-swallow guard, auditor ac4caa28 O1 /
# 0e08e6a4 O2). A value-flag given as the LAST argument used to hang forever here: every arm below
# does `x="${2:-}"; shift 2`, and `shift 2` with one arg left fails WITHOUT shifting, so
# `[[ $# -gt 0 ]]` never becomes false. Call BEFORE reading `$2`/shifting, with the pre-shift `$#`
# and the flag name: refuses (1) no value given (only the flag left) and (2) the next arg is
# itself a `--flag` (no legitimate value here — a lane list, a REQ-/SET- id, a prose string —
# begins with `--`, so it would otherwise be silently swallowed as this flag's value). Exit 3 (new
# here; this file's prior non-zero code was 1 for every error) — named, never a silent default.
need_val() { [[ "$1" -ge 2 ]] || halt "$2: requires a value (none given)."; case "${3-}" in --*) halt "$2: requires a value, got the flag '$3' instead." ;; esac; }

# Resolve THIS worktree's lane fail-closed. Never default to foundation on an unresolved lane.
resolve_lane() {
    local root resolver
    root="$(repo_root)"; resolver="$root/scripts/resolve-lane.sh"
    [[ -x "$resolver" ]] || die "lane resolver missing/not-executable at $resolver (fail-closed)."
    local line
    line="$("$resolver")" || die "lane UNRESOLVED (resolver exit != 0) — cannot prove authority (fail-closed)."
    eval "$line"   # -> lane= role= version= spine_write= blob= ...
    [[ -n "${lane:-}" ]] || die "resolver emitted no lane (fail-closed)."
}

# --- REQ-FOOTPRINT (C-SET-AUTHORIZATION §2.2) — the set-identity mint registry. ---
# The `## SET-IDENTITY` table in PENDING-SET.md binds a requirement_id → its ONE minted set_id +
# the architect-authored footprint (lanes/substrates/exclusive), transcribed at dispatch. The
# assemble-time coverage gate reads footprint.lanes from here; reap enforces the stagger against it.
# Columns: | requirement_id | set_id | footprint.lanes | footprint.substrates | exclusive | minted-at |
#
# registry_row <requirement_id> → prints TAB-separated `set_id \t lanes \t substrates \t exclusive`
# for a minted requirement (exit 0), or exits 1 if the requirement has no row. Read-only (any seat).
registry_row() {
    local root ledger want; root="$(repo_root)"; ledger="$root/$LEDGER_NAME"; want="$1"
    [[ -f "$ledger" ]] || return 1
    awk -v want="$want" -F'|' '
        /^<!--/ {inc=1} inc && /-->/ {inc=0; next} inc {next}
        /^## SET-IDENTITY/ {inreg=1; next}
        /^## / && inreg {inreg=0}
        inreg && /^\|[[:space:]]*REQ-/ {
            r=$2; gsub(/^[ \t]+|[ \t]+$/,"",r)
            if (r==want) {
                s=$3; l=$4; b=$5; e=$6
                gsub(/^[ \t]+|[ \t]+$/,"",s); gsub(/^[ \t]+|[ \t]+$/,"",l)
                gsub(/^[ \t]+|[ \t]+$/,"",b); gsub(/^[ \t]+|[ \t]+$/,"",e)
                print s"\t"l"\t"b"\t"e; found=1; exit
            }
        }
        END { if (!found) exit 1 }
    ' "$ledger"
}

# registry <requirement_id>  — read-only: print the TAB row for a requirement (any seat; used by ratify.sh assemble).
cmd_registry() {
    local reqid="${1:-}"
    [[ -n "$reqid" ]] || die "registry: missing <requirement_id>."
    registry_row "$reqid" || die "registry: no minted set-identity for '$reqid' (fail-closed)."
}

# mint <requirement_id> --footprint-lanes 'a,b' [--footprint-substrates 's'] [--exclusive true|false]
# Foundation-only. Mints the ONE set_id for a requirement (idempotent — a re-mint with a MATCHING
# footprint returns the same set_id; a DIFFERING footprint HALTs). No footprint.lanes → REFUSED
# (§2.2: no footprint → not dispatchable). Allocates the next SET-NNNN across the registry + _ratification/.
cmd_mint() {
    local reqid="${1:-}"; shift || true
    [[ -n "$reqid" ]] || die "mint: missing <requirement_id>.  usage: pending-set.sh mint REQ-<id> --footprint-lanes 'a,b' [--footprint-substrates 's'] [--exclusive true|false]"
    [[ "$reqid" =~ ^REQ-[A-Za-z0-9._-]+$ ]] || die "mint: requirement_id must match REQ-<id> (got '$reqid')."
    local lanes="" substrates="" exclusive="true"
    while [[ $# -gt 0 ]]; do case "$1" in
        --footprint-lanes)      need_val $# "--footprint-lanes" "${2:-}";      lanes="${2:-}";      shift 2 ;;
        --footprint-substrates) need_val $# "--footprint-substrates" "${2:-}"; substrates="${2:-}"; shift 2 ;;
        --exclusive)            need_val $# "--exclusive" "${2:-}";            exclusive="${2:-}";  shift 2 ;;
        *) die "mint: unknown arg '$1'." ;;
    esac; done
    # FAIL-CLOSED (§2.2(a)): a requirement with no declared footprint.lanes is not dispatchable.
    [[ -n "${lanes// /}" ]] || die "REFUSED — mint needs a non-empty --footprint-lanes (§2.2: no footprint → not dispatchable; fail-closed)."
    resolve_lane   # foundation is the SOLE minter (dispatch-time identity is foundation's pen)
    [[ "${lane:-}" == "foundation" ]] || die "mint REFUSED — only the foundation lane mints set-identity (got lane='${lane:-?}'; fail-closed)."
    local root ledger; root="$(repo_root)"; ledger="$root/$LEDGER_NAME"
    [[ -f "$ledger" ]] || die "no $LEDGER_NAME at repo root."
    grep -q '^## SET-IDENTITY' "$ledger" || die "mint: $LEDGER_NAME has no '## SET-IDENTITY' section (fail-closed; seed the registry section first)."
    # Idempotent: an existing mint returns its set_id; a footprint change is REFUSED (architect-owned).
    local existing; existing="$(registry_row "$reqid" 2>/dev/null || true)"
    if [[ -n "$existing" ]]; then
        local esid elanes esubs; esid="$(printf '%s' "$existing" | cut -f1)"; elanes="$(printf '%s' "$existing" | cut -f2)"; esubs="$(printf '%s' "$existing" | cut -f3)"
        [[ "$elanes" == "$lanes" ]] || die "mint HALT — '$reqid' is already minted as $esid with footprint.lanes [$elanes]; refusing to re-mint with [$lanes]. The footprint is architect-owned — change it in the spec + re-author, never via a silent re-mint (fail-closed)."
        # RULING 1c: compare SUBSTRATES SYMMETRICALLY WITH LANES. Before this, substrates were
        # parsed and never compared, so a re-mint with a DIFFERING --footprint-substrates returned the
        # existing set_id and silently wrote NOTHING — a FAIL-OPEN (the seat believes the footprint moved
        # and it did not), contradicting this function's own header contract ("a DIFFERING footprint HALTs").
        # Normalize the registry's '—' empty-placeholder to '' so an omitted flag still matches an empty cell.
        local _esubs_n="$esubs" _subs_n="$substrates"
        [[ "$_esubs_n" == "—" ]] && _esubs_n=""
        [[ -n "$_subs_n" || -z "$_esubs_n" ]] && [[ "$_esubs_n" != "$_subs_n" ]] && die "mint HALT — '$reqid' is already minted as $esid with footprint.substrates [${esubs}]; refusing to re-mint with [${substrates:-—}]. The footprint is architect-owned — change it in the spec + re-author, never via a silent re-mint (fail-closed). (RULING 1c: substrates are compared symmetrically with lanes; the prior silent no-op was a fail-open.)"
        echo "$esid"; return 0
    fi
    # Allocate the next SET-NNNN = max(registry set_ids, _ratification/SET-*.md) + 1.
    local maxreg maxrat n setid now
    maxreg="$(awk -F'|' '
        /^## SET-IDENTITY/{r=1;next} /^## /&&r{r=0}
        r && $0 ~ /SET-[0-9][0-9][0-9][0-9]/ { s=$3; gsub(/[^0-9]/,"",s); if(s+0>m)m=s+0 }
        END{print m+0}' "$ledger")"
    maxrat="$(ls "$root"/_ratification/SET-*.md 2>/dev/null | sed -E 's#.*/SET-([0-9]{4})\.md#\1#' | sort -n | tail -1)"
    n=$(( ( 10#${maxreg:-0} > 10#${maxrat:-0} ? 10#${maxreg:-0} : 10#${maxrat:-0} ) + 1 ))
    setid="$(printf 'SET-%04d' "$n")"
    now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    # Append the registry row immediately after the |---| separator under SET-IDENTITY.
    awk -v row="| $reqid | $setid | ${lanes} | ${substrates:-—} | ${exclusive:-true} | $now |" '
        /^## SET-IDENTITY/ {inreg=1}
        {print}
        inreg && /^\|[-]+\|/ && !done {print row; done=1}
    ' "$ledger" > "$ledger.tmp" && mv "$ledger.tmp" "$ledger"
    echo "$setid"
}

cmd_list() {
    local root ledger; root="$(repo_root)"; ledger="$root/$LEDGER_NAME"
    [[ -f "$ledger" ]] || die "no $LEDGER_NAME at repo root."
    # Print THE SET rows: table rows under '## THE SET', skipping the header row, the
    # |---| separator, and any HTML-commented example. A row starts '| <digit>'.
    # NOTE: matches the section headed EXACTLY '## THE SET' (the machine-membership table);
    # the first-exercise HISTORICAL ledger lives under a differently-titled heading
    # so this parser never conflates the two.
    awk '
        /^<!--/ {inc=1} inc && /-->/ {inc=0; next} inc {next}
        /^## THE SET[[:space:]]*$/ {inset=1; next}
        /^## / && inset {inset=0}
        inset && /^\|[[:space:]]*[0-9]+[[:space:]]*\|/ {print}
    ' "$ledger"
}

cmd_member() {
    local id="${1:-}"; shift || true
    [[ -n "$id" ]] || die "member: missing <id>.  usage: pending-set.sh member <id> --requirement-id REQ-<id> --set-id SET-NNNN --intent '…' --surfaces 'a,b' [--invariants '…'] [--receipts '…'] [--deps '…'] [--declared-effects 'db: …; make: …; wp: …']"
    local intent="" surfaces="" invariants="" receipts="" deps="" effects="" reqid="" setid=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --intent)     need_val $# "--intent" "${2:-}";     intent="${2:-}";     shift 2 ;;
            --surfaces)   need_val $# "--surfaces" "${2:-}";   surfaces="${2:-}";   shift 2 ;;
            --invariants) need_val $# "--invariants" "${2:-}"; invariants="${2:-}"; shift 2 ;;
            --receipts)   need_val $# "--receipts" "${2:-}";   receipts="${2:-}";   shift 2 ;;
            --deps)       need_val $# "--deps" "${2:-}";       deps="${2:-}";       shift 2 ;;
            # REQ-FOOTPRINT (§2.2): the member's parent requirement + the set_id minted for it. A WP is
            # not dispatchable without a requirement_id (the §2.1 corollary applied to footprint); the
            # set_id is foundation-minted ONCE per requirement and stamped on every WP + member.
            --requirement-id) need_val $# "--requirement-id" "${2:-}"; reqid="${2:-}"; shift 2 ;;
            --set-id)         need_val $# "--set-id" "${2:-}";         setid="${2:-}"; shift 2 ;;
            # §4a — the member is a MULTI-SUBSTRATE permanent-record MANIFEST: not just git surfaces but
            # every change it wants to make permanent (data writes/DDL · substrate records · …).
            # EXTENSIBLE by design: any 'substrate: effect' entries (';'-separated) are admitted without
            # redesign; U4B's forward `effect-matches-§5` predicate checks each vs the §5 structure-of-record.
            --declared-effects|--effects) need_val $# "--declared-effects" "${2:-}"; effects="${2:-}"; shift 2 ;;
            *) die "member: unknown arg '$1'." ;;
        esac
    done
    # FAIL-CLOSED: a member entry with an empty surfaces list is REFUSED (M2 acceptance).
    [[ -n "${surfaces// /}" ]] || die "REFUSED — member entry needs a non-empty --surfaces list (fail-closed; an unstated blast radius cannot be set-evaluated)."
    # DISC-AUTHZ-INPUT-VALIDATED-AT-EARLIEST-WRITE — validate the token HERE,
    # at the earliest write, where the AUTHOR can still fix it. The coverage gate stays the
    # backstop; it must no longer be the FIRST detector (it only fires after the ratify pen).
    _load_surftok || die "REFUSED — cannot load the shared surfaces-token validator (see above)."
    surfaces_token_assert "$surfaces" "member" || die "REFUSED — malformed --surfaces token (see above)."
    [[ -n "${intent// /}"   ]] || die "REFUSED — member entry needs a non-empty --intent (fail-closed)."
    # FAIL-CLOSED (REQ-FOOTPRINT §2.2(a)/(b)): a member with no parent requirement_id is not dispatchable;
    # a member with no minted set_id cannot be set-evaluated (the stagger cannot be checked).
    [[ -n "${reqid// /}" ]] || die "REFUSED — member entry needs a --requirement-id REQ-<id> (§2.2(a): a WP is not dispatchable without a parent requirement; fail-closed)."
    [[ -n "${setid// /}" ]] || die "REFUSED — member entry needs a --set-id SET-NNNN (§2.2(b): the set_id foundation minted for this requirement — 'pending-set.sh mint <requirement_id> …'; fail-closed)."
    [[ "$setid" =~ ^SET-[0-9]{4}$ ]] || die "REFUSED — --set-id must be SET-NNNN (got '$setid')."
    resolve_lane   # sets $lane; modules contribute members, never the packet
    local root outdir out branch head stat
    root="$(repo_root)"
    outdir="$root/_orchestration/relay-outbox/$lane"
    mkdir -p "$outdir"
    out="$outdir/SET-MEMBER-$id.md"
    branch="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo '?')"
    head="$(git rev-parse --short HEAD 2>/dev/null || echo '?')"
    stat="$(git diff --stat 2>/dev/null | tail -n 20)"
    {
        echo "# SET-MEMBER-$id — pending-set member entry"
        echo
        echo "- member id: $id"
        echo "- lane: $lane"
        echo "- requirement id: $reqid"
        echo "- set id: $setid"
        echo "- branch@sha: ${branch}@${head}"
        echo "- intent: $intent"
        echo "- surfaces touched: $surfaces"
        echo "- declared effects (multi-substrate manifest; §3/§4a): ${effects:-git-surfaces-only}"
        echo "- invariants touched: ${invariants:-none-declared}"
        echo "- evidence receipts: ${receipts:-none-declared}"
        echo "- self-declared dependencies: ${deps:-none-declared}"
        echo
        echo '## git diff --stat (working tree)'
        echo '```'
        echo "${stat:-<clean>}"
        echo '```'
    } > "$out"
    echo "wrote member entry: ${out#$root/}"
}

cmd_reap() {
    local mf="${1:-}"
    [[ -n "$mf" && -f "$mf" ]] || die "reap: member file not found: '${mf:-<none>}'."
    resolve_lane   # foundation is the SOLE writer of the ledger row
    [[ "${lane:-}" == "foundation" ]] || die "reap REFUSED — only the foundation lane appends ledger rows (got lane='${lane:-?}'; fail-closed)."
    local root ledger id mlane mbr msurf n
    root="$(repo_root)"; ledger="$root/$LEDGER_NAME"
    [[ -f "$ledger" ]] || die "no $LEDGER_NAME at repo root."
    id="$(awk -F': ' '/^- member id:/ {print $2; exit}' "$mf")"
    mlane="$(awk -F': ' '/^- lane:/ {print $2; exit}' "$mf")"
    mbr="$(awk -F': ' '/^- branch@sha:/ {print $2; exit}' "$mf")"
    msurf="$(awk -F': ' '/^- surfaces touched:/ {print $2; exit}' "$mf")"
    [[ -n "$id" && -n "$msurf" ]] || die "reap REFUSED — member file missing id or surfaces (fail-closed)."
    # Second earliest-write point: never admit a malformed token INTO the ledger,
    # because `assemble` copies the ledger row straight into the packet the gate later reads.
    _load_surftok || die "reap REFUSED — cannot load the shared surfaces-token validator (see above)."
    surfaces_token_assert "$msurf" "reap" || die "reap REFUSED — malformed surfaces token in member file $mf (see above)."
    # REQ-FOOTPRINT (§2.2(a)/(b)) — the member must carry a requirement_id + a minted set_id that MATCHES
    # the SET-IDENTITY registry. No requirement_id → not dispatchable; no mint → HALT; a different set_id
    # than the one minted for this requirement → HALT (the stagger: two set_ids for one requirement evade the set).
    local mreq msid regrow regsid
    mreq="$(awk -F': ' '/^- requirement id:/ {print $2; exit}' "$mf")"
    msid="$(awk -F': ' '/^- set id:/ {print $2; exit}' "$mf")"
    [[ -n "$mreq" ]] || die "reap REFUSED — member file '$id' has no 'requirement id' (§2.2(a): not dispatchable without a parent requirement; fail-closed)."
    [[ -n "$msid" ]] || die "reap REFUSED — member file '$id' has no 'set id' (§2.2(b): mint a set_id before reaping; fail-closed)."
    regrow="$(registry_row "$mreq" 2>/dev/null || true)"
    [[ -n "$regrow" ]] || die "reap HALT — requirement '$mreq' has NO minted set_id in the SET-IDENTITY registry (§2.2(b): a WP whose requirement_id has no minted set_id → HALT; run 'pending-set.sh mint $mreq --footprint-lanes …' first). Fail-closed."
    regsid="$(printf '%s' "$regrow" | cut -f1)"
    [[ "$msid" == "$regsid" ]] || die "reap HALT — THE STAGGER (§2.2(b)): member '$id' carries set_id '$msid' but requirement '$mreq' is minted as '$regsid'. A 2nd dispatch of the same requirement under a different set_id is refused (two set_ids for one requirement = staggering to evade the set). Fail-closed."
    # Next row number = current max in THE SET + 1.
    n="$(cmd_list | awk -F'|' '{gsub(/ /,"",$2); if($2+0>m)m=$2+0} END{print m+1}')"
    # Insert a `pending` row immediately after the |---| separator under THE SET.
    awk -v row="| $n | $id | $mlane | $mbr | $msurf | pending |" '
        /^## THE SET[[:space:]]*$/ {inset=1}
        {print}
        inset && /^\|[-]+\|/ && !done {print row; done=1}
    ' "$ledger" > "$ledger.tmp" && mv "$ledger.tmp" "$ledger"
    echo "reaped member '$id' as row $n (status: pending)."
}

main() {
    local verb="${1:-}"; shift || true
    case "$verb" in
        list)     cmd_list "$@" ;;
        mint)     cmd_mint "$@" ;;
        registry) cmd_registry "$@" ;;
        member)   cmd_member "$@" ;;
        reap)     cmd_reap "$@" ;;
        ""|-h|--help) echo "usage: pending-set.sh {list | mint REQ-<id> --footprint-lanes 'a,b' [--footprint-substrates 's'] [--exclusive true|false] | registry REQ-<id> | member <id> --requirement-id REQ-<id> --set-id SET-NNNN --intent … --surfaces … [--declared-effects 'db: …; make: …; wp: …'] | reap <member-file>}" ;;
        *) die "unknown verb '$verb' (expected: list | mint | registry | member | reap)." ;;
    esac
}
main "$@"
