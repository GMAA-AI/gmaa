#!/usr/bin/env bash
# scripts/lane_currency_gate.sh — STEP-1 PHASE-2(b): module-lane currency sync.
#
# Brings a MODULE lane CURRENT with the integration trunk (content-fresh) while
# PRESERVING the lane's identity and RE-STAMPING its rule-currency field. This is the
# spine->module MIRROR of scripts/reap_at_merge.sh (module->spine): same
# `git checkout HEAD -- _boot` move, but run in the MODULE worktree it preserves the
# MODULE's identity instead of the foundation's.
#
# CURRENCY MECHANISM (architect-ruled HOW-class 2026-06-24): pull-on-validate — a lane
# re-syncs to the merged HEAD + runs the skill-integrity probe at pickup; behind-HEAD =>
# cannot-propose. HARD FENCE: MERGED/committed truth ONLY — this adopts the integration
# trunk's spine VERBATIM; it NEVER propagates unmerged sibling work.
#
# RUN CONTEXT: cwd inside the TARGET MODULE worktree (e.g. <repo-root>/<module-lane>).
# The integrator may run it on behalf of an idle lane by cd-ing into that sibling. It
# refuses to run on the foundation lane (foundation IS the trunk).
#
# HARD-GATE (HALT on ANY ambiguity — do NOT serialize silently; surface to integrator):
#   - no in-progress merge/rebase, no index.lock, attached HEAD;
#   - clean working tree (a module worktree writes no ledger, so ANY dirt = a possible
#     active holder => ambiguity => HALT). [holder-detection is structural pending a
#     formal lane-lock mechanism; that is an architect HOW-decision if one is wanted.]
#
# STEPS: hard-gate -> merge-from-trunk (R1 adopt-from-trunk: MERGE_HEAD==TRUNK_SHA, spine
# adopted byte-identical) -> IDENTITY-PRESERVE _boot (keep module's) -> RULE re-stamp
# (rules_manifest -> live scripts/rules_manifest.sh hash; HALT-AND-RE-STAMP if stale;
# first run with no field = manifest-bootstrap, surface-as-such NOT a fault) -> skill probe
# -> commit on module branch (D3+R1 gate must PASS) -> integrator-notify.
#
# COST: zero Anthropic / zero metered (pure git + sha + file ops; the module post-commit
# hook emits a lane MARKER only, no auditor).
#
# Authority: chat-Architect STEP-1 sequence ratification 2026-06-24 (proceed phase 2 a->c).
set -u

# ---- 0. resolve own (module) worktree + lane ----------------------------------------
SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"   # beside this script only (0507 R2); resolved before the cd below
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "HALT: not in a git worktree"; exit 1; }
cd "$REPO_ROOT" || { echo "HALT: cannot cd $REPO_ROOT"; exit 1; }
RESOLVER="$REPO_ROOT/scripts/resolve-lane.sh"
[[ -x "$RESOLVER" ]] || { echo "HALT: resolver missing/not-exec at $RESOLVER"; exit 1; }
# Capture ONLY stdout — resolve-lane emits key=value assignments on STDOUT and ALL
# diagnostics (STALE-BOOT / LANE-UNRESOLVED / LANE-MISMATCH) on STDERR. The old `2>&1`
# folded stderr INTO the eval string; a STALE-BOOT line ("…delta -> run scripts/boot-check.sh…")
# then eval'd its literal "-> run" as a `> run` redirect, creating a spurious `run` file the
# clean-tree hard-gate below rejected (self-inflicted deadlock on any STALE-BOOT lane).
if ! LANE_LINE="$("$RESOLVER" 2>/dev/null)"; then
    echo "HALT: lane UNRESOLVED — cannot prove identity (never default). Resolver diagnostics:" >&2
    "$RESOLVER" >/dev/null || true   # re-emit STDERR diagnostics to the terminal
    exit 3
fi
eval "$LANE_LINE"   # stdout = ONLY lane= role= version= spine_write= blob= (eval-safe)
LANE="${lane:?}"
if [[ "$LANE" == "foundation" ]]; then
    echo "HALT: currency-gate syncs a MODULE lane to the trunk; this worktree is foundation (the trunk)."; exit 1
fi
echo "[currency] lane=$LANE worktree=$REPO_ROOT (pre-sync HEAD=$(git rev-parse --short HEAD))"

# ---- 1. HARD-GATE (HALT on ambiguity) -----------------------------------------------
GITDIR="$(git rev-parse --git-dir)"
HALT_GATE=0
# (a) no in-progress operation
if [[ -e "$GITDIR/MERGE_HEAD" || -d "$GITDIR/rebase-merge" || -d "$GITDIR/rebase-apply" ]]; then
    echo "  HARD-GATE FAIL: an in-progress merge/rebase exists ($GITDIR)."; HALT_GATE=1
fi
if [[ -e "$GITDIR/index.lock" ]]; then
    echo "  HARD-GATE FAIL: index.lock present ($GITDIR/index.lock) — another git op may be live."; HALT_GATE=1
fi
# (b) attached HEAD on the expected module branch
HEAD_BRANCH="$(git symbolic-ref -q --short HEAD || echo '<detached>')"
# === resolve the lane's OWN branch from its bootstrap, never a hardcoded prefix. ===
# The old predicate was `module/$LANE`, which is UNSATISFIABLE for every non-module lane:
#   architect -> lane 'architect', branch 'architect'  (needed 'module/architect')
#   the execution lane -> branch 'exec'  (needed 'module/<execution-lane>')
# So the fan-out instrument had NO PATH to either seat — not "hasn't run yet", but CANNOT run.
# `worktree_branch:` is already the canonical lane<->branch map (scripts/resolve-lane.sh reads it
# to cross-check identity), so this reuses an existing authority instead of inventing one.
EXPECTED_BRANCH="$(sed -n 's/^worktree_branch:[[:space:]]*//p' "$REPO_ROOT/_boot/BOOTSTRAP.md" 2>/dev/null | head -1)"
if [[ -z "${EXPECTED_BRANCH// /}" ]]; then
    echo "  HARD-GATE FAIL: _boot/BOOTSTRAP.md carries no 'worktree_branch:' field — cannot PROVE which branch this lane owns (fail-closed; never guess identity)."; HALT_GATE=1
elif [[ "$HEAD_BRANCH" != "$EXPECTED_BRANCH" ]]; then
    echo "  HARD-GATE FAIL: HEAD is '$HEAD_BRANCH', expected '$EXPECTED_BRANCH' (from _boot/BOOTSTRAP.md worktree_branch; detached/wrong branch)."; HALT_GATE=1
fi
# (c) clean working tree — ANY dirt = ambiguity (module writes no ledger)
DIRTY="$(git status --porcelain)"
if [[ -n "$DIRTY" ]]; then
    echo "  HARD-GATE FAIL: working tree not clean (in-flight=only-expected violated):"
    echo "$DIRTY" | sed 's/^/    /'; HALT_GATE=1
fi
if [[ "$HALT_GATE" -ne 0 ]]; then
    echo "HALT: hard-gate ambiguity for lane=$LANE — surfacing to integrator, NOT serializing silently."; exit 2
fi
echo "  HARD-GATE PASS: clean · attached HEAD=module/$LANE · no in-progress op · no index.lock"

# ---- 2. resolve integration trunk (subvert-resistant; works pre-bootstrap) -----------
# The trunk is the branch half of the ONE spine-ref resolver's output (the one spine-ref resolver: `${ref#origin/}`), which
# carries the TRUNK_BRANCH slot as its local-bytes anchor (0505 R1; the 0424 s2.2 property). It replaces the old
# derivation from the lane map's foundation row and its literal trunk fallback: to read the spine you must already
# know the trunk, so that derivation was circular at an adopter. No resolution is a HALT by name (inv #5).
[[ -f "$SPINE_REF_SH" ]] || { echo "HALT: SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2)."; exit 1; }
_SR="$(bash "$SPINE_REF_SH")" && [[ -n "$_SR" ]] \
    || { echo "HALT: SPINE-REF-UNRESOLVED -- $SPINE_REF_SH unfilled; the trunk branch cannot be resolved (the one spine-ref resolver)."; exit 1; }
TRUNK_BRANCH="${_SR#origin/}"; TRUNK_SRC="scripts/spine-ref.sh (${_SR})"
[[ -n "$TRUNK_BRANCH" ]] || { echo "HALT: cannot resolve trunk branch (scripts/spine-ref.sh printed '${_SR}')."; exit 1; }
TRUNK_SHA="$(git rev-parse -q --verify "$TRUNK_BRANCH" 2>/dev/null)" || { echo "HALT: trunk '$TRUNK_BRANCH' unresolved."; exit 1; }
echo "  trunk=$TRUNK_BRANCH @ ${TRUNK_SHA:0:12} (src: $TRUNK_SRC)"

BEHIND="$(git rev-list --count "HEAD..$TRUNK_BRANCH")"
AHEAD="$(git rev-list --count "$TRUNK_BRANCH..HEAD")"
echo "  position: behind=$BEHIND ahead=$AHEAD (ahead = module-local commits not on trunk)"

# ---- 3. merge-from-trunk (content-fresh; R1 adopt-from-trunk) ------------------------
MERGED=0
if [[ "$BEHIND" -gt 0 ]]; then
    echo "[currency] merging trunk into module/$LANE (--no-ff --no-commit)…"
    # SANCTIONED-SYNC SENTINEL, belt-and-suspenders.
    # `--no-commit` means pre-merge-commit does NOT fire today, so this export is NOT load-bearing yet.
    # It exists so that a future refactor of this gate to an AUTO-COMMITTING merge cannot brick the very
    # lanes this gate exists to sync: without it, the new module-side guard would reject the sanctioned
    # path itself. Exact mirror of the trunk side's REAP_AT_MERGE=1 reasoning.
    export LANE_CURRENCY_SYNC=1
    git merge --no-ff --no-commit "$TRUNK_BRANCH" >/dev/null 2>&1 || true   # may pause on conflict

    # IDENTITY-PRESERVE: keep the MODULE's _boot + its own _orchestration/relay-outbox/ (ours =
    # this worktree's HEAD), never adopt trunk's. exclude_to_head restores the module's HEAD
    # versions then unstages trunk's ADDED files (e.g. trunk's CHARTER-foundation.md, which a plain
    # `checkout HEAD -- _boot` would LEAK INTO the module — ISSUE-BOOT-EXCLUSION-ADDS-LEAK-2026-06-25);
    # worktree untouched (identity-safe, NOT rm -rf), fail-closed identity guard. The module's own
    # relay-outbox/ surfaces SURVIVE the re-sync (the invisible-failure case — never wiped).
    exclude_to_head() {  # returns nonzero on identity-guard failure
        local ex f
        for ex in "$@"; do
            git checkout HEAD -- "$ex" 2>/dev/null || true
            while IFS= read -r f; do
                [[ -n "$f" ]] && git rm --cached --quiet --ignore-unmatch -- "$f" >/dev/null 2>&1 || true
            done < <(git diff --cached --name-only HEAD -- "$ex" 2>/dev/null)
        done
        git ls-files --cached -- _boot/BOOTSTRAP.md | grep -q .
    }
    exclude_to_head _boot _orchestration/relay-outbox || {
        echo "HALT: identity guard — _boot/BOOTSTRAP.md missing post-exclusion; aborting merge."
        git merge --abort 2>/dev/null || git reset --hard HEAD; exit 2; }

    # === A SUCCESSFUL SYNC MUST LEAVE A CLEAN TREE. ===
    # exclude_to_head() UNSTAGES trunk's integration-excluded additions but deliberately leaves the
    # FILES ON DISK (identity-safe, NOT rm -rf). Those untracked leftovers then trip THIS GATE'S OWN
    # clean-tree hard-gate on the NEXT run, so the mechanism disabled its own next invocation:
    # every lane could sync exactly ONCE without an integrator clearing it by hand,
    # measured across three successful syncs across module lanes, all trunk-identical.
    # ***A mechanism that can run exactly once is not a fan-out.***
    # SAFETY: the hard-gate above already PROVED the tree was CLEAN before the merge, so anything
    # untracked under these paths NOW is merge residue by construction. The lane's OWN relay-outbox
    # files are TRACKED on its branch and are therefore untouched by `git clean`.
    git clean -fdq -- _boot _orchestration/relay-outbox 2>/dev/null || true

    # HALT-LOUD on any conflict OUTSIDE the integration-excluded paths.
    UNMERGED="$(git ls-files -u | awk '{print $4}' | sort -u | grep -vE '^(_boot/|_orchestration/relay-outbox/)' || true)"
    if [[ -n "$UNMERGED" ]]; then
        echo "HALT: merge conflict OUTSIDE integration-excluded paths — needs integrator ruling:"
        echo "$UNMERGED" | sed 's/^/  - /'
        git merge --abort 2>/dev/null || git reset --hard HEAD
        exit 2
    fi
    MERGED=1
else
    echo "[currency] already contains trunk (behind=0); no merge — checking re-stamp + skill only."
fi

# ---- 4. RULE re-stamp (_boot rules_manifest -> live hash; IDENTITY-PRESERVE) ---------
LIVE_HASH="$(bash "$REPO_ROOT/scripts/rules_manifest.sh" 2>/dev/null)" || { echo "HALT: rules_manifest.sh failed."; exit 1; }
[[ -n "$LIVE_HASH" ]] || { echo "HALT: empty rules-manifest hash."; exit 1; }
BOOT="$REPO_ROOT/_boot/BOOTSTRAP.md"
CUR_HASH="$(awk '/^---[[:space:]]*$/{d++; next} d==1 && index($0,"rules_manifest:")==1{s=$0; sub("^rules_manifest:[[:space:]]*","",s); print s; exit}' "$BOOT")"
RESTAMP_STATUS="current"
if [[ "$CUR_HASH" != "$LIVE_HASH" ]]; then
    if [[ -z "$CUR_HASH" ]]; then
        RESTAMP_STATUS="manifest-bootstrap (no rules_manifest field yet — EXPECTED first run, NOT a fault)"
    else
        RESTAMP_STATUS="HALT-AND-RE-STAMP (stale ${CUR_HASH:0:12} -> live ${LIVE_HASH:0:12})"
    fi
    # Re-stamp ONLY the rules_manifest field; never touch lane/role/worktree_branch/
    # spine_write/provisioned_*/bootstrap_version (IDENTITY-PRESERVE).
    TMP="$(mktemp)"
    awk -v hash="$LIVE_HASH" '
      BEGIN{d=0; done=0}
      /^---[[:space:]]*$/ { d++;
        if (d==2 && !done) { print "rules_manifest: " hash; done=1 }
        print; next }
      d==1 && index($0,"rules_manifest:")==1 { print "rules_manifest: " hash; done=1; next }
      { print }
    ' "$BOOT" > "$TMP" && mv "$TMP" "$BOOT"
    git add _boot 2>/dev/null || true
    echo "  RULE re-stamp: $RESTAMP_STATUS"
else
    echo "  RULE re-stamp: already current (${LIVE_HASH:0:12})"
fi

# ---- 5. skill-integrity probe (pull-on-validate) ------------------------------------
SKILL_PROBE="$REPO_ROOT/probes/c-skill/probe_skill_install_integrity_v1.sh"
SKILL_RESULT="(probe absent)"
if [[ -x "$SKILL_PROBE" ]]; then
    if SKILL_OUT="$(bash "$SKILL_PROBE" 2>&1)"; then
        SKILL_RESULT="PASS"
    else
        SKILL_RESULT="FAIL"
        echo "HALT: skill-integrity probe FAILED — installed skills drift from committed home:"
        echo "$SKILL_OUT" | sed 's/^/  /'
        [[ "$MERGED" -eq 1 ]] && { git merge --abort 2>/dev/null || git reset --hard HEAD; echo "  (merge aborted; lane unchanged)"; }
        exit 2
    fi
    echo "  skill-integrity: $SKILL_RESULT"
else
    # A declared check that cannot run says so: never silence, never PASS (inv #5).
    echo "  skill-integrity: NOT-RUN (probes/c-skill/probe_skill_install_integrity_v1.sh absent; a project-supplied probe)"
fi

# ---- 6. commit on module branch (D3 + R1 adopt-from-trunk must PASS) -----------------
COMMITTED_SHA=""
if [[ "$MERGED" -eq 1 ]]; then
    if ! git diff --cached --quiet 2>/dev/null || [[ -e "$GITDIR/MERGE_HEAD" ]]; then
        git commit -q --no-edit -m "currency-sync: adopt trunk ${TRUNK_SHA:0:12} + _boot rules re-stamp (IDENTITY-PRESERVE; R1 adopt-from-trunk)" \
            || { echo "HALT: currency commit REJECTED (D3/R1 pre-commit gate) — surface stderr above."; exit 1; }
        COMMITTED_SHA="$(git rev-parse --short HEAD)"
    fi
elif ! git diff --cached --quiet 2>/dev/null; then
    # behind=0 but a re-stamp was staged -> a tiny _boot-only commit (allowed: _boot not spine)
    git commit -q -m "currency: _boot rules re-stamp (${LIVE_HASH:0:12}; IDENTITY-PRESERVE)" \
        || { echo "HALT: re-stamp commit REJECTED — surface stderr above."; exit 1; }
    COMMITTED_SHA="$(git rev-parse --short HEAD)"
fi

# ---- 7. integrator-notify ------------------------------------------------------------
NEW_BOOT_BLOB="$(git hash-object "$BOOT")"
NEW_HEAD="$(git rev-parse --short HEAD)"
echo "──────────────────────────────────────────────────────────────────"
echo "INTEGRATOR-NOTIFY: lane=$LANE moved @${NEW_HEAD}  (was behind=$BEHIND of $TRUNK_BRANCH@${TRUNK_SHA:0:12})"
echo "  re-stamp     : $RESTAMP_STATUS"
echo "  skill-probe  : $SKILL_RESULT"
echo "  _boot blob   : $NEW_BOOT_BLOB"
if [[ "$NEW_BOOT_BLOB" != "$blob" ]]; then
    echo "  >>> MANIFEST UPDATE OWED (foundation/integrator): _orchestration/lane-provisioning.md row '$LANE'"
    echo "      blob $blob -> $NEW_BOOT_BLOB  (module cannot self-edit spine; integrator updates on main)."
fi
echo "──────────────────────────────────────────────────────────────────"
exit 0
