#!/bin/bash
# scripts/subagent-ledger.sh <start|stop|session-start> — the live-subagent ledger (the per-subagent bound rule,
# as amended). Hook input JSON on stdin. Always exits 0: a ledger hook never blocks.
#   start          SubagentStart: append  session_id agent_id agent_type start_epoch start_utc agent_transcript_path
#                  (agent_transcript_path is in SubagentStart input per the live hooks page;
#                  0337 §3(c) assumed it was not, so the path is recorded here, at the source).
#   stop           SubagentStop: remove that (session_id, agent_id). The usage record joins THIS
#                  hook when the console set builds it (0336 §2(a): one hook, no second entry).
#   session-start  SessionStart: ONLY for a SEAT session (input carries `agent_type`, present under `--agent`
#                  per the live hooks page; headless `claude -p` auditors run without --agent,
#                  agents/post-commit-hook.sh:406). It moves the leftover entries of EARLIER SEAT sessions of this
#                  worktree to .claude/subagents-abandoned, then prints every abandon line not yet shown to a
#                  seat as `SUBAGENT-ABANDONED …` into this boot's context. One seat per worktree, so an earlier
#                  seat session is over. An auditor's entries are never moved by a seat's boot and never block
#                  it (0337 §3(d)); an auditor's own boot moves nothing. A seat boot also prints and clears the
#                  previous seat session's .claude/untracked-since-boot as `UNTRACKED-SINCE-BOOT <path>` (0340 §1).
set -u
MODE="${1:-}"
IN="$(cat)"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
D="$ROOT/.claude"; mkdir -p "$D" 2>/dev/null
# shellcheck source=scripts/subagent-lib.sh
. "$ROOT/scripts/subagent-lib.sh" 2>/dev/null || exit 0
j() { printf '%s' "$IN" | jq -r "$1 // empty" 2>/dev/null; }
SID="$(j .session_id)"
[ -n "$SID" ] || exit 0

case "$MODE" in
  start)
    AID="$(j .agent_id)"; [ -n "$AID" ] || exit 0
    AT="$(j .agent_type)"; TP="$(j .agent_transcript_path)"
    printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$SID" "$AID" "${AT:--}" "$(sa_now)" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$TP" >> "$D/subagents-live"
    ;;
  stop)
    AID="$(j .agent_id)"; [ -n "$AID" ] || exit 0
    sa_drop "$D" "$SID" "$AID"
    ;;
  session-start)
    [ -n "$(j .agent_type)" ] || exit 0          # not a seat: move nothing, print nothing
    printf '%s\n' "$SID" >> "$D/seat-sessions"   # this worktree's seat sessions, for the next seat boot
    if [ -f "$D/subagents-live" ]; then
      now="$(sa_now)"
      for s in $(awk -F'\t' -v me="$SID" '$1!=me {print $1}' "$D/subagents-live" | sort -u); do
        /usr/bin/grep -qxF -- "$s" "$D/seat-sessions" 2>/dev/null || continue
        sa_abandon "$D" "$s" "$now" ""
      done
    fi
    if [ -f "$D/subagents-abandoned" ]; then
      shown="$(cat "$D/subagents-abandoned.shown" 2>/dev/null || echo 0)"
      case "$shown" in ''|*[!0-9]*) shown=0 ;; esac
      total="$(wc -l < "$D/subagents-abandoned" | tr -d ' ')"
      if [ "$total" -gt "$shown" ]; then
        tail -n +"$((shown + 1))" "$D/subagents-abandoned" | while IFS= read -r l; do
          printf 'SUBAGENT-ABANDONED %s  (recover from its transcript; clear nothing, this is the record)\n' "$(printf '%s' "$l" | tr '\t' ' ')"
        done
        echo "$total" > "$D/subagents-abandoned.shown"
      fi
    fi
    # The previous seat session's untracked-since-boot list (written by seat-exit.sh at intent),
    # printed once into this seat's boot, then cleared. Never blocks. An auditor boot never reaches this line.
    if [ -f "$D/untracked-since-boot" ]; then
      while IFS= read -r p; do
        [ -n "$p" ] && printf 'UNTRACKED-SINCE-BOOT %s  (created in the previous seat session, not committed: integrate it or delete it)\n' "$p"
      done < "$D/untracked-since-boot"
      rm -f "$D/untracked-since-boot"
    fi
    ;;
esac
exit 0
