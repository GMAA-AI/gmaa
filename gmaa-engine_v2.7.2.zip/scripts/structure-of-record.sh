#!/usr/bin/env bash
# scripts/structure-of-record.sh — the §5 check-reference gate (C-SET-AUTHORIZATION §5).
#
#   list                                   enumerate the on-record systems + currency/completeness
#   check <system> [--needs-live] [--max-age <days>]
#                                          FAIL-CLOSED consult:
#                                            - absent record  → HALT (blind check; rule 1 completeness)
#                                            - malformed       → HALT
#                                            - --needs-live and currency != LIVE-VERIFIED → HALT (rule 2)
#                                            - --needs-live --max-age N and last-live-verified older
#                                              than N days (or unparseable) → HALT (rule 2 currency)
#                                            - else PASS (prints currency)
#
# The mechanism the U4B `effect-matches-§5` criterion consults when a set member declares a
# cross-substrate effect (§4a manifest): a `db:`/`make:`/`wp:`/… effect needs `--needs-live` (a LIVE
# substrate); a git `surfaces:` effect targets system `git-spine` (LIVE-by-construction). READ-ONLY
# (any seat); the RECORD itself is written ONLY by foundation (U7). Secrets never enter the record.
set -u
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "structure-of-record: not in a git worktree (fail-closed)." >&2; exit 3; }
DIR="$ROOT/contracts/structure-of-record"
die()  { echo "structure-of-record: $*" >&2; exit 1; }
halt() { echo "structure-of-record HALT: $*" >&2; exit 3; }

# need_val — cure for ISSUE-TRAILING-VALUE-FLAG-SPINS-FOREVER-IN-FIVE-SCRIPTS (SET-0083 shape,
# carried verbatim from scripts/creed-scan.sh need_val()/flag-swallow guard, auditor ac4caa28 O1 /
# 0e08e6a4 O2). `--max-age) max_age="${2:-}"; shift 2 ;;` used to hang forever as the LAST argument:
# `shift 2` with one arg left fails WITHOUT shifting, so `[[ $# -gt 0 ]]` never becomes false. Call
# BEFORE reading `$2`/shifting: refuses (1) no value given and (2) the next arg is itself a
# `--flag` (no legitimate value here — a day count — begins with `--`, so it would otherwise be
# silently swallowed as this flag's value). Routed through halt() (exit 3, this file's existing
# fail-closed code) — a named stderr reason, never a silent default.
need_val() { [[ "$1" -ge 2 ]] || halt "$2: requires a value (none given)."; case "${3-}" in --*) halt "$2: requires a value, got the flag '$3' instead." ;; esac; }

field() { sed -n "s/^- $2:[[:space:]]*//p" "$1" | head -1; }

resolve_file() {   # <name> → path (by filename, else by `- system:` id); empty if none
    local name="$1"
    [[ -f "$DIR/$name.md" ]] && { echo "$DIR/$name.md"; return; }
    local f
    for f in "$DIR"/*.md; do
        [[ "$(basename "$f")" == README.md ]] && continue
        [[ "$(field "$f" system)" == "$name" ]] && { echo "$f"; return; }
    done
    echo ""
}

epoch() {  # YYYY-MM-DD → epoch seconds, portable (GNU then BSD); empty on failure
    date -d "$1" +%s 2>/dev/null || date -j -f "%Y-%m-%d" "$1" +%s 2>/dev/null || echo ""
}

cmd_list() {
    [[ -d "$DIR" ]] || halt "no structure-of-record directory at contracts/structure-of-record (blind — nothing on record)."
    printf '%-34s %-22s %-12s %s\n' "system" "currency" "completeness" "last-live-verified"
    local f
    for f in "$DIR"/*.md; do
        [[ "$(basename "$f")" == README.md ]] && continue
        printf '%-34s %-22s %-12s %s\n' \
            "$(field "$f" system)" "$(field "$f" currency)" "$(field "$f" completeness)" "$(field "$f" last-live-verified)"
    done
}

cmd_check() {
    local name="${1:-}"; shift || true
    [[ -n "$name" ]] || die "check: <system> required."
    local needs_live=0 max_age=""
    while [[ $# -gt 0 ]]; do case "$1" in
        --needs-live) needs_live=1; shift ;;
        --max-age)    need_val $# "--max-age" "${2:-}"; max_age="${2:-}"; shift 2 ;;
        *) die "check: unknown arg '$1'." ;;
    esac; done
    local f; f="$(resolve_file "$name")"
    # RULE 1 — completeness: an absent record is a BLIND CHECK → HALT (can't check what isn't on record).
    [[ -n "$f" ]] || halt "NO structure-of-record for system '$name' — a BLIND CHECK (§5 rule 1). Foundation must document contracts/structure-of-record/$name.md before a change touching it can be conform-checked. Fail-closed."
    local sys cur comp llv
    sys="$(field "$f" system)"; cur="$(field "$f" currency)"; comp="$(field "$f" completeness)"; llv="$(field "$f" last-live-verified)"
    [[ -n "$sys" && -n "$cur" && -n "$comp" ]] || halt "malformed record ${f#$ROOT/} (missing system/currency/completeness) — fail-closed."
    if [[ "$needs_live" -eq 1 ]]; then
        # RULE 2 — currency: a LIVE-substrate effect needs a LIVE-VERIFIED record.
        [[ "$cur" == "LIVE-VERIFIED" ]] || halt "system '$sys' is currency=$cur (needs LIVE-VERIFIED) — a check against a LIVE substrate on a not-live-verified record gives a FALSE verdict (§5 rule 2, DISC-CORPUS-IS-MEMORY). The live-authorized executor must live-read + foundation re-stamp before this effect is conform-checkable. Fail-closed."
        if [[ -n "$max_age" ]]; then
            local e_llv e_now age_days
            e_llv="$(epoch "$llv")"; e_now="$(date +%s)"
            [[ -n "$e_llv" ]] || halt "system '$sys' last-live-verified='$llv' is unparseable — cannot prove currency within $max_age days (fail-closed)."
            age_days=$(( (e_now - e_llv) / 86400 ))
            [[ "$age_days" -le "$max_age" ]] || halt "system '$sys' last-live-verified='$llv' is ${age_days}d old (> --max-age ${max_age}d) — STALE (§5 rule 2). Re-verify live before checking. Fail-closed."
        fi
    fi
    echo "structure-of-record OK: system '$sys' PRESENT · currency=$cur · completeness=$comp · last-live-verified=$llv"
}

main() {
    local verb="${1:-}"; shift || true
    case "$verb" in
        list)  cmd_list "$@" ;;
        check) cmd_check "$@" ;;
        ""|-h|--help) echo "usage: structure-of-record.sh {list | check <system> [--needs-live] [--max-age <days>]}" ;;
        *) die "unknown verb '$verb' (expected: list | check)." ;;
    esac
}
main "$@"
