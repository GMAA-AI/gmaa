#!/usr/bin/env bash
# scripts/inbox.sh — lane-resolved SPINE-inbox reader (routing; architect-ratified 2026-06-26).
#
# WHY: the inbox is stored on the spine and read CROSS-REF (`git show main:…`); the module branch
# never carries inbox writes (integration-excluded by design — keeps the branch clean + stops inbox
# content leaking back to spine). Consequence: inbound is NOT filesystem-visible in the module
# worktree — a plain `ls`/Read MISSES it (the silent-miss / fail-open the routing ratify left open).
# This helper is the seamless read; the INBOX-CHECK invariant (orc.md) is the liveness half.
#
# INVARIANT (orc.md, binding for module lanes): run this as the FIRST action of EVERY turn and emit
#   INBOX-CHECK: <lane> <N new | empty>
# If N new → CONSUME-BEFORE-PROCEED: read + reconcile the inbound BEFORE the intended turn, THEN
# `consume`. The last-seen marker advances ONLY on explicit consume (you ACTED) — NEVER on a plain
# read, else a glanced-past read marks seen and recreates the silent-miss one layer down.
#
# Usage:
#   scripts/inbox.sh                  # check: emit INBOX-CHECK line + bodies of NEW messages (no advance).
#                                     #   Also snapshots the DISPLAYED set to .claude/inbox-shown.
#   scripts/inbox.sh consume NAME... --premise holds@<ref>|refuted@<ref>   # premise REQUIRED
#   scripts/inbox.sh consume --all    # mark consumed ONLY what the LAST check displayed (shown-snapshot ∩
#                                     #   still-pending) — NOT the live spine set. A relay arriving after the
#                                     #   check survives (no swallow-unread). HALTs if no prior check ran.
#
# Identity: lane resolves from _boot via scripts/resolve-lane.sh (the single identity-definition site;
# never re-implemented here). Exit 3 = HALT on unresolved lane (never default to foundation).
set -u

SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"   # beside this script only (0507 R2); resolved before the cd below
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "inbox.sh: not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2

EVAL="$(scripts/resolve-lane.sh)" || { echo "inbox.sh: HALT — lane unresolved (resolve-lane.sh non-zero)" >&2; exit 3; }
eval "$EVAL"
: "${lane:?inbox.sh: HALT — lane empty after resolve}"

# ── HUB DELEGATION ─────────────────────────────
# WHY: `inboxf.sh` landed at SET-0026 and the direction-aware bell points to it — but it had ZERO auto
# callers, so it was WIRED FOR THE RING AND NOT FOR THE REFLEX. A hub session that boots and types the
# reflexive `inbox.sh` (no bell) got a TRUE-but-useless `empty`, which is the exact defect the whole
# transport fix exists to kill. SET-0026:40 named this residual and routed it.
#
# ⭐ WHY THIS ONE LINE REPLACES A PERSONA EDIT: SET-0026 treated "orc.md / architect.md / settings.json
#    all say run `inbox.sh` first" as needing a `.claude/agents/**` change — a SPINE_PATHS
#    AUTHORIZATION-surface edit it correctly refused to fold into a release-critical member. Once the
#    hub DELEGATES, every surface naming `inbox.sh` is AUTOMATICALLY CORRECT: the hub types it and gets
#    the sweep; a module lane types it and gets its inbox. The persona edit is SUBSUMED, not deferred —
#    the correct answer is put behind the name every surface already types.
#
# The hub is identified by its AUTHORITY CLASS from its own `_boot/BOOTSTRAP.md` (spine_write == ALLOW),
# never by a hardcoded lane name — the same per-class-not-per-name rule that `lane-surface.sh` applies
# (a name pattern is false for 2 of 6 lanes; a declared class is true for all of them).
# ⛔ AMENDED (hub-delegation predicate): the predicate was `!= DENY`, which collapsed THREE
#    classes to two and captured the execution lane's `apply-receipts-only` — handing a spoke the hub sweep. The hub is
#    `== ALLOW` ONLY (the writer archetype, canon v1.6.5 §1.1); DENY, apply-receipts-only and any future class
#    fall through to the leaf read of relay-inbox/<lane>/. inboxf.sh now also refuses non-ALLOW callers (pole 7).
if [[ "${spine_write:-DENY}" == "ALLOW" ]]; then
    if [[ -r "$REPO_ROOT/scripts/inboxf.sh" ]]; then
        exec bash "$REPO_ROOT/scripts/inboxf.sh" "$@"   # delegate the WHOLE verb: check | seed | consume
    fi
    # FAIL-CLOSED: never silently return the narrow read to the hub — that IS the defect.
    echo "inbox.sh: HALT — this is the HUB lane (spine_write='${spine_write:-?}') and scripts/inboxf.sh is missing/unreadable." >&2
    echo "  The narrow single-directory read is WRONG for the hub: lane→hub delivery is outbox+reap, and" >&2
    echo "  relay-outbox/** is integration-EXCLUDED, so a module payload exists ONLY on its own branch." >&2
    echo "  Returning 'empty' here would be TRUE AND USELESS — the exact failure this delegation prevents." >&2
    exit 4
fi

INBOX="_orchestration/relay-inbox/${lane}"
MARKER=".claude/inbox-seen"   # gitignored (.claude/* except !.claude/agents/); per-worktree = per-lane
SHOWN="${INBOX_SHOWN_FILE:-.claude/inbox-shown}"   # (INBOX_SHOWN_FILE: write-side override, the Stop guard only) gitignored snapshot: the names the MOST-RECENT check displayed. `consume --all`
                              # is bounded by this set (never the live spine set) — closes the TOCTOU swallow
                              # where a relay landing AFTER a check but BEFORE a blind consume --all was marked
                              # seen unread (silent message-loss; ISSUE-INBOX-CONSUME-ALL-SWALLOWS-UNREAD).

# ── SHARED CONSUME STATE MACHINE ──────────────
# `inbox.sh` and `inboxf.sh` are two FRONT DOORS over ONE state machine. Until now each carried its own
# copy of the seen/mark logic — and TWO COPIES OF A RULE DRIFT. This particular rule decides whether a
# relay is silently marked read, so a drift here re-creates the silent-miss class one layer down, which
# is the exact failure this whole transport effort exists to kill.
# ⛔ DELIBERATELY MINIMAL: only the ENGINE is shared. This script keeps its own display logic verbatim
#    because module-lane OUTPUT must not change (SET-0027 AC-3). Unify what can drift, not what is correct.
# Resolve sibling libraries from THIS SCRIPT'S own directory, never from $REPO_ROOT: a script invoked
# against another worktree must still find ITS OWN libraries (the documented `cd <lane> && bash
# <main>/scripts/...` pattern). And FAIL LOUD — a missing library that degrades to "nothing is seen"
# silently resurrects every consumed message (DISC-CHILD-FAILURE-MUST-SURFACE).
_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_source_sibling() {
    local lib="$_SELF_DIR/$1"
    [[ -r "$lib" ]] || { echo "$(basename "$0"): HALT — required library missing/unreadable: $lib" >&2
                         echo "  Refusing to continue: without it the seen-state would silently read as EMPTY," >&2
                         echo "  which resurrects every consumed message as unread. Fail loud, never degrade." >&2
                         exit 5; }
    . "$lib"
}
_source_sibling consume-core.sh
core_init "$MARKER" "$SHOWN"; core_consume_guard() { local rr; rr="$(core_relay_check "$INBOX_REF" "${INBOX}/${1}" foundation)" || { echo "inbox.sh consume: $rr -- NOT consumed" >&2; return 1; }; }

# ⛔ THE SPINE IS READ AT THE SPINE REF (scripts/spine-ref.sh), LIKE THE HUB (window plan row 4; canon s4 HEAD
#    readback: sequence state comes from a readback of the record, never a seat-local mirror). A local `main`
#    is a mirror that only matches the record where the lane shares the hub's object store; in a separate
#    clone it is stale. `INBOX_REF` is for probes only.
INBOX_REF="${INBOX_REF:-}"; [ -n "$INBOX_REF" ] || [ -f "$SPINE_REF_SH" ] || { echo "inbox.sh: HALT — SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2)" >&2; exit 3; }
[ -n "$INBOX_REF" ] || INBOX_REF="$(bash "$SPINE_REF_SH")" || { echo "inbox.sh: HALT — SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and INBOX_REF unset (the one spine-ref resolver; inv #5: no literal fallback)" >&2; exit 3; }  # INBOX_REF = replica/test knob; else the ONE resolver
list_pending() {  # spine inbox relay names (the one relay-name predicate, consume-core.sh); empty if no dir for this lane
  # row 17: each name's CURRENT blob is noted for the shared core, BEFORE the name is
  # printed, so the seen-state can tell an item amended after consume from one already read.
  local mode type blob name
  while IFS=$' \t' read -r mode type blob name; do
    core_is_relay_name "$name" || continue
    core_note_blob "$name" "$blob"
    printf '%s\n' "$name"
  done < <(git ls-tree "${INBOX_REF}:${INBOX}/" 2>/dev/null)
  return 0
}
core_enumerate() { list_pending; }   # the shared core's source enumerator (consume --all intersects with it)
is_seen() { core_is_seen "$1"; }   # delegates: ONE definition of "seen", in consume-core.sh

cmd="${1:-check}"
case "$cmd" in
  check)
    new=(); refused=()
    while IFS= read -r f; do
      [[ -n "$f" ]] || continue
      core_is_current "$f" || { rr="$(core_relay_check "$INBOX_REF" "${INBOX}/${f}" foundation)" && new+=("$f") || refused+=("$rr"); }      # unseen, or amended after consume (row 17)
    done <<< "$(list_pending)"
    # SNAPSHOT the shown set (overwrite every check). consume --all may ONLY mark THESE seen — never
    # the live spine set — so a relay that lands AFTER this check is not in the snapshot and always
    # survives a subsequent consume --all. Truncate first so an empty check leaves an empty snapshot.
    mkdir -p "$(dirname "$SHOWN")"; : > "$SHOWN"
    if [[ ${#new[@]} -eq 0 ]]; then
      echo "INBOX-CHECK: ${lane} $([[ ${#refused[@]} -gt 0 ]] && echo "0 new · ${#refused[@]} refused-unverified" || echo empty)"; for rr in ${refused[@]+"${refused[@]}"}; do echo "$rr"; done
      # Visibility: an empty inbox is never a mysterious blank — show what WAS consumed so a
      # previously-consumed (or wrongly-swallowed) message is auditable at a glance.
      if [[ -s "$MARKER" ]]; then
        echo "  ($(grep -c . "$MARKER") consumed to date; most recent: $(tail -1 "$MARKER" 2>/dev/null))"
      fi
      exit 0
    fi
    printf '%s\n' "${new[@]}" >> "$SHOWN"
    echo "INBOX-CHECK: ${lane} ${#new[@]} new$([[ ${#refused[@]} -gt 0 ]] && echo " · ${#refused[@]} refused-unverified")"; for rr in ${refused[@]+"${refused[@]}"}; do echo "$rr"; done
    for f in "${new[@]}"; do
      amd="$(core_amended "$f")" && echo "AMENDED-AFTER-CONSUME: ${f} (${amd})"
      echo "===== NEW: ${INBOX}/${f} ====="
      git show "${INBOX_REF}:${INBOX}/${f}"
      echo "===== END: ${f} ====="
      echo
    done
    echo "[consume only after acting: scripts/inbox.sh consume ${new[*]} --premise holds@<ref>|refuted@<ref> ]"
    ;;
  consume)
    shift
    core_take_premise "$@" || exit 2                       # no premise, no consume
    set -- ${CORE_ARGS[@]+"${CORE_ARGS[@]}"}               # bash-3.2-safe empty-array expansion
    mkdir -p "$(dirname "$MARKER")"; : >> "$MARKER"
    in_shown() { [[ -f "$SHOWN" ]] && grep -qxF "$1" "$SHOWN"; }
    if [[ "${1:-}" == "--all" ]]; then
      # STRICT: consume ONLY what the most-recent check DISPLAYED (SHOWN ∩ still-pending ∩ unseen).
      # NEVER the live spine-pending set — that blind sweep is the swallow-unread bug (a relay arriving
      # between check and consume was marked seen without ever being read). Absent snapshot = HALT-LOUD.
      [[ -f "$SHOWN" ]] || { echo "inbox.sh consume --all: HALT — no shown-snapshot; run \`scripts/inbox.sh\` (check) first (consume --all only marks what a prior check displayed)" >&2; exit 3; }
      # the intersection is the shared core's (window plan row 2): ONE carrier for both doors
      n="$(core_consume_all)" || exit 3
      echo "inbox.sh: consumed ${n} shown+pending message(s) for ${lane} (shown-snapshot bound; un-shown arrivals preserved)"
    else
      [[ $# -eq 0 ]] && { echo "inbox.sh consume: name(s) required (or --all)" >&2; exit 2; }
      for f in "$@"; do
        in_shown "$f" || echo "inbox.sh consume: WARNING — '$f' was not in the last check's shown-set (did you read it? consuming by explicit request)" >&2
        core_consume_one "$f" || exit 2
      done
      echo "inbox.sh: consumed ${*} for ${lane}"
    fi
    ;;
  migrate)
    # row 17 cutover: every legacy seen line gets its item's current blob, so
    # nothing re-shows now and the first amendment after this does. Prints the count it migrated.
    list_pending >/dev/null
    echo "inbox.sh: seen-lines migrated $(core_migrate) for ${lane}"
    ;;
  *)
    echo "inbox.sh: unknown cmd '$cmd' (use: check | consume | migrate)" >&2; exit 2 ;;
esac
