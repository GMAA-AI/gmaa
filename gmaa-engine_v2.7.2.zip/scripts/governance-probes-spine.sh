#!/usr/bin/env bash
# scripts/governance-probes-spine.sh — run the SPINE's governance probe bytes at a boundary: a boot-runner
# or spine-runner that fires on every lane satisfies "wired" (SPEC-GOVERNANCE-INDEX).
# Same shape as creed-scan-spine.sh / surface-conformance-spine.sh: each probe's bytes come from origin/main (so a
# probe change reaches every lane with no per-lane sync), and each measures THIS worktree
# (every listed probe resolves its root with `git rev-parse --show-toplevel`).
# ROSTER (explicit, denominator printed): the SET-0044 probes whose verdict is ruled, not disputed. The
# completeness probe is the caller of the greenlight deny-class engine (its verdict is the engine poles; the coverage
# checks it prints are reported, not verdict-driving), so a FAIL there is a broken engine, not a disputed gap.
# APPLICATION: the v1.6.5 APPLICATION floor probe is on this BOOT-RUN path and reads RED at
# every boot until APPLIED = N. That red is the real state and the intended pressure; it is never quieted with a waiver.
# SEAT-DEFS: every agent def in this worktree is loadable, makes no false Read-only class
# claim, and carries no key or allow-list of its own. A lane whose defs predate the cure reads FAIL until it adopts.
# FAIL-CLOSED: a probe unreadable at the spine prints UNREADABLE for that probe and the runner exits 3; it never
# reports a clean board it did not run. A probe that runs but exits 3 with no VERDICT line (its own UNREADABLE,
# e.g. a lane worktree without the APPLICATION table) is UNREADABLE too, never FAIL (SET-0118). Callers run it under `|| true` (a line, never a halt — canon :156).
set -u
# the spine ref (the one spine-ref resolver): GOV_PROBES_SPINE_REF if set (a replica/test knob), else the ONE resolver scripts/spine-ref.sh;
# no resolution is a HALT by name, never a literal fallback (inv #5).
REF="${GOV_PROBES_SPINE_REF:-}"
SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"   # beside this script only (0507 R2)
[ -n "$REF" ] || [ -f "$SPINE_REF_SH" ] || { echo "GOV-PROBES: UNREADABLE — SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2) (exit 3)"; exit 3; }
[ -n "$REF" ] || REF="$(bash "$SPINE_REF_SH")" || { echo "GOV-PROBES: UNREADABLE — SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled and GOV_PROBES_SPINE_REF unset (the one spine-ref resolver) (exit 3)"; exit 3; }
PROBES="spine-census-parity:probes/set-gate/probe_census_parity.sh single-writer-manifest:probes/governance/probe_single_writer_manifest.sh governance-index-drift:probes/governance-index/probe_governance_index_v1.sh application:probes/governance/probe_application_v1.sh seat-defs:probes/governance/probe_seat_defs_v1.sh subagent-commit-deny:probes/governance/probe_subagent_commit_deny_v1.sh completeness:probes/governance/probe_completeness_v1.sh"
D="$(mktemp -d "${TMPDIR:-/tmp}/govprobes.XXXXXX")" || { echo "GOV-PROBES: UNREADABLE — mktemp failed (exit 3)"; exit 3; }
trap 'rm -rf "$D"' EXIT
n=0; pass=0; fail=0; unr=0
for spec in $PROBES; do
  id="${spec%%:*}"; path="${spec#*:}"; n=$((n+1))
  if git show "${REF}:${path}" > "$D/$id.sh" 2>/dev/null && [ -s "$D/$id.sh" ]; then
    out="$(bash "$D/$id.sh" 2>&1)"; rc=$?
    v="$(printf '%s\n' "$out" | grep -E '^VERDICT:' | tail -1)"
    if [ $rc -eq 0 ] && printf '%s' "$v" | grep -q '^VERDICT: PASS'; then pass=$((pass+1)); echo "GOV-PROBE: $id rc=0 ${v}"
    elif [ $rc -eq 3 ] && [ -z "$v" ]; then
      # The probe ran and reported UNREADABLE itself (exit 3, no verdict line; the roster convention). That is
      # not a measurement, so it is never filed as FAIL (auditor 1b9813b0 F1).
      why="$(printf '%s\n' "$out" | grep -E 'UNREADABLE' | head -1)"
      unr=$((unr+1)); echo "GOV-PROBE: $id UNREADABLE — probe exit 3, no verdict (${why:-no UNREADABLE line printed}) (not a verdict)"
    else fail=$((fail+1)); echo "GOV-PROBE: $id rc=$rc ${v:-NO VERDICT LINE}"; fi
  else unr=$((unr+1)); echo "GOV-PROBE: $id UNREADABLE — ${REF}:${path} could not be read (not a verdict)"; fi
done
echo "GOV-PROBES: ${pass} PASS · ${fail} FAIL · ${unr} UNREADABLE of ${n} (source SPINE(${REF}))"
[ $unr -gt 0 ] && exit 3
[ $fail -gt 0 ] && exit 1
exit 0
