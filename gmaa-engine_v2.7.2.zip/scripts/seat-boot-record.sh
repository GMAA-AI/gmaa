#!/bin/bash
# scripts/seat-boot-record.sh — SessionStart hook (handoff check).
# Appends `<session_id> <HEAD sha> <utc> <source>` to <worktree>/.claude/seat-boot.log so seat-exit.sh can
# test "the handoff surface changed since THIS session's boot sha". An append log keyed by session, never a
# single overwritten file: headless `claude -p` auditors run in the same worktree (agents/post-commit-hook.sh
# `cd "$REPO_ROOT"`) and fire SessionStart too. Kept to the last 500 lines. Always exits 0 (never blocks a boot).
set -u
IN="$(cat)"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
SID="$(printf '%s' "$IN" | jq -r '.session_id // empty' 2>/dev/null)"
SRC="$(printf '%s' "$IN" | jq -r '.source // "-"' 2>/dev/null)"
[ -n "$SID" ] || exit 0
HEAD_SHA="$(git -C "$ROOT" rev-parse HEAD 2>/dev/null)" || exit 0
LOG="$ROOT/.claude/seat-boot.log"
mkdir -p "$ROOT/.claude" 2>/dev/null
printf '%s %s %s %s\n' "$SID" "$HEAD_SHA" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "${SRC:--}" >> "$LOG" 2>/dev/null
if [ "$(wc -l < "$LOG" 2>/dev/null || echo 0)" -gt 500 ]; then
  tail -n 500 "$LOG" > "$LOG.$$" 2>/dev/null && mv -f "$LOG.$$" "$LOG"
fi
# Seat-host guard (record): a fork or daemon-hosted continuation in this worktree is not the seat. The ONE predicate
# (scripts/seat-host-guard.sh) appends SEAT-HOST-HALT to .claude/seat-loop.log and rings foundation from a module lane;
# boot-check.sh prints the same line LAST with rc 3. This hook still never blocks a boot.
[ -f "$ROOT/scripts/seat-host-guard.sh" ] && printf '%s' "$IN" | bash "$ROOT/scripts/seat-host-guard.sh" record >/dev/null 2>&1
exit 0
