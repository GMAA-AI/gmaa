# GMAA Engine Map: every file in the engine and what it does

**What this is.** The inventory of the engine, spec to code: ten areas, every file with its role, each anchored to the canon section it implements. It describes engine v2.7.2 at canon pin v1.6.9 (`GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_9.md`); `PROVENANCE.tsv` carries each file's origin and hash. **Read this before you look for anything; if a file is not listed here, it is not part of the engine.**

**Core read.** The files marked **Core read, every seat** are read end to end by every seat before its first act in the project; those marked **Core read, by role** are read whole by the seats `CLAUDE.md` names under its Core read section, which also gives the receipt line (`CORE-READ:`) each seat prints when the read is done.

**The shape of the whole thing in one paragraph.** The canon states one correction: authorize the set, not the change, with an integrator seat assessing and an independent human ratifying. The engine is that correction made mechanical, in layers that check one another: identity derived from location and halted on mismatch (area 2); a harness plane that denies before any agent decides (area 3); a set ledger, an assembler and a ratification line (area 4); a work lifecycle with no edge from in-progress to closed except an audited receipt (area 5); merge-time backstops (area 6); transport that lives outside every participant (area 7); and an audit layer whose invariants are probed, not asserted, with a governance index that makes "cite before raise" a command (area 8). Areas 9 and 10 are how an adopter gets in and how a recipient verifies what it got.

---

## 1 The specification layer, the law everything below implements

**Canon anchor: the whole document.**

| File | Role |
|---|---|
| `GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_9.md` | The specification, carried at the package root so every adopter holds the exact law its engine version conforms to. CC BY 4.0, licensed separately from the engine. Nothing executes it; everything below is checked against it. earlier releases carried it in a canon directory; since v2.7 it is at the root. **Core read, every seat.** |
| `.claude/rules/engine/invariants.md` | The engine invariants as a harness rules file, loaded by the runtime into every session alongside the operating contract. **Core read, every seat.** |
| `CLAUDE.md` | The condensed hot operating surface every session loads: cold-boot identity, the context lifecycle, the binding invariant shapes, seat topology, slot pointers, and the canon §7.5 line under the shipped probe's match. Package-authored; the origin's own is not shipped. **Core read, every seat.** |

The canon's own instantiation checklist (§12) is the adopter's entry point into it; area 9 carries the files that walk it.

## 2 Identity, seat lifecycle, and the restart loop

**Canon anchors: §1.0 definitions, §1.1 seats and surfaces, §2 one session one seat, §7 the seat manifest and governed lifecycle (§7.1 Boot-0, §7.2 provisioning, §7.3 project-qualified identity, §7.4 liveness, §7.5 the line every seat carries). Contract: `contracts/LAUNCH-CONTRACT.md`.**

The design law of this area: identity comes from location, is derived on both sides of the spawn boundary, and the two derivations must agree or the seat halts. New at v2.7 against v2.6: the seat ends itself and is relaunched by a loop its tmux session runs, with hooks at session start, prompt, compaction and stop that record and enforce the boundary; the operator's stop verb is the only thing that breaks the loop.

| File | What it is and what runs it |
|---|---|
| `_boot/BOOTSTRAP.md` | The stamp: lane, project, session name, branch, fixed at provisioning. Read at boot by the launcher and the resolver; never asserted at runtime. Ships as the fill skeleton. **Core read, every seat.** |
| `_boot/CHARTER-foundation.md` | The shipped foundation charter, opening on the canon §7.5 line, read at Boot-0. The adopter authors its other charters from this shape before those seats exist. **Core read, every seat.** |
| `contracts/LAUNCH-CONTRACT.md` | The seat contract: where seats live, how they launch, who they are, how their worktrees end. **Core read, by role.** |
| `_orchestration/lane-provisioning.md` | The lane provisioning manifest: spine-owned, integrator-written; each lane's seat resolves identity from its worktree at cold boot. |
| `_index/lane-dormancy.tsv` | Lanes named dormant: the roster entry and territory persist, no sync runs. Ships with its header and the engine's rows. |
| `docs/SEATS_skeleton.yaml` | The shape of `seats.yaml`, the adopter's seat roster (one `seats:` key), copied to the root at genesis. The roster itself is not shipped; it is read at genesis by the boot check, the assembler, the build-class probe and the surface-conformance probe. It declares no spine paths (see area 3). |
| `launch-orc.sh` | The fleet seat launcher, one copy at the root: resolves the lane from the stamp, refuses double-launch on the exact qualified session name, creates the named tmux session running the seat loop, prints an observed-facts receipt. |
| `scripts/launch-orc.sh` | The same launcher bytes under `scripts/`, the copy the loop and the probes name; the root copy is the one the adopter deposits in each worktree. |
| `scripts/seat-loop.sh` | The relaunch loop the seat's tmux session runs: launches the session, waits for its self-exit, relaunches on restart, stops on shutdown. |
| `scripts/seat-exit.sh` | A seat ends itself, restart or shutdown: run by the seat as its last act, it validates and writes the intent and sends no keystroke; the stop hook then sends the exit, and the loop relaunches or ends. |
| `scripts/seat-exit-cue.sh` | The prompt hook that turns the operator's word into the seat-exit verb cue. |
| `scripts/seat-b6-stop.sh` | The stop hook, three duties in order keyed by the session: the token log line, the exit on a fresh intent from `scripts/seat-exit.sh`, and the context threshold latch; the every-stop guard (owed inbox, named waits) runs inside them, and the audit seal and the hub read are called from within. |
| `scripts/seat-precompact.sh` | The pre-compaction hook (auto matcher): the boundary record before context is compacted. |
| `scripts/seat-boot-record.sh` | The session-start hook: records the boot and checks for a handoff. |
| `scripts/seat-boot-assess.sh` | The successor's boot-time assess step over the handoff it inherits; `--execute` acts on it. |
| `scripts/seat-host-guard.sh` | The one "is this session the seat?" predicate, classify or record; what keeps a subagent or a stray shell from acting as the seat. |
| `scripts/seat-stop.sh` | The operator's tool: shut a seat down and do not restart it; the one break in the loop. |
| `scripts/statusline-context.sh` | The runtime status line command: context fields from the record, never a zero for a null. |
| `scripts/observed-mode.sh` | The prompt hook that writes the observed-mode boot receipt. |
| `scripts/backgrounded-sessions.sh` | The successor's reading list over backgrounded sessions at boot. |
| `scripts/resolve-lane.sh` | The shared identity resolver: lane equals worktree folder name, cross-checked against the stamp, halt on mismatch. Consumed by boot-check, the hooks, the doorbell, the reaper, the keys. |
| `scripts/resolve-project.sh` | The §7.3 project-token resolver: reads the stamped project field, composes `{project}-{lane}` for the tmux namespace, never guesses. |
| `scripts/lane-surface.sh` | The one indirection point for which branch a lane is on and which surface it reads; sourced by the inbox readers, the doorbell and the stop hook. |
| `scripts/spine-ref.sh` | The one spine-ref resolver: which ref is the spine for this checkout, read through the lane resolver. |
| `scripts/boot-check.sh` | The boot-discipline presence and live-currency gate, one script for all lanes, fired from the session-start hook so presence is harness-enforced. |
| `probes/governance/probe_seat_restart_poles.sh` | Red and green poles over the whole restart set above: launcher, loop, exit, stop, hooks, status line. |
| `probes/governance/probe_seat_line_75_v1.sh` | The seat-line presence probe: the canon §7.5 line in the stamp, the contract and every seat surface. |
| `probes/governance/probe_seat_defs_v1.sh` | The agent-definition probe for canon §1.3: every shipped definition leads with loadable frontmatter and the subagent boundary. |
| `probes/governance/probe_window_plan_boot.sh` | Red and green poles for the boot rows of the window plan: observed mode, the boot record, the exit cue. |
| `probes/governance/probe_window_plan_row7.sh` | Window plan row 7: identity comes from location only; the resolver keeps no branch-to-lane map and reads no manifest, the launcher keeps no folder-to-lane map, the hub read filters on the stamped project. |

**The agent-definition roster (`.claude/agents/`), canon §1.0 "agent definition" and §1.3 subagent classes.** Three definitions ship at v2.7 (v2.6 shipped seven; the four dropped were origin-specific workers, out by the origin's own ship set):

| Definition | Class and boundary |
|---|---|
| `.claude/agents/orc.md` | The role-neutral orchestrator seat definition; the folder it launches in resolves whether it is foundation (spine write allowed) or a module lane (denied). The one definition that is a seat, not a subagent. |
| `.claude/agents/architect.md` | The optional code-resident architect seat: reads everything at HEAD read-only, rules HOW-class, writes exactly one territory on its own branch, never commits to the spine, never executes mechanisms. |
| `.claude/agents/general-purpose.md` | Bounded fan-out worker for foundation: authoring-only by default, never commits, halts loud on ambiguity. |

## 3 The harness plane and single-writer enforcement

**Canon anchors: §1.1 single-writer invariant, §1.2 the two-plane authorization model, §1.3 subagents, §6 transport identity (seat keys), §8 permission architecture. Contract: `contracts/MECH-WRITE.md`.**

This area answers one question mechanically: can anyone but foundation land bytes on the spine, and can any session do what its seat may not? The answer is layered: a harness hook denies before the model acts, a commit hook denies at the commit, a push hook denies at the push, and a key per seat signs what passes. The server-side twin of the push hook is held, not shipped: the contracts name it as a check an adopter supplies on a forge the seats do not administer, and no shipped file listens on a workstation.

| File | What it is and what runs it |
|---|---|
| `.claude/settings.json` | The harness plane itself, §8 in file form: 48 allow, 1 ask, 10 deny rules, and the hook wirings that make the runtime enforce the engine: session start (boot-check, boot record, subagent ledger), prompt (observed mode, exit cue), pre-compaction, pre-tool-use on Bash (greenlight, background deny, subagent commit deny) and on every tool (subagent cap), stop and session end (creed scan, the stop hook), subagent start and stop (the ledger), and the status line. Every hook fails closed. Vendor-neutral at the pin: no cloud-CLI rule remains. |
| `contracts/MECH-WRITE.md` | Who may write where, and how a write reaches the trunk: the write law the hooks below enforce. **Core read, by role.** |
| `scripts/greenlight-policy.sh` | The pre-tool-use policy hook on every Bash call: auto-approves a call whose every segment is provably in policy, otherwise stays silent so the call falls through to the static allow, ask and deny lists; it emits a deny itself for one narrow class, the hook-bypass tokens. The adopter's own deny classes are the rows of the table below. |
| `_index/greenlight-deny-classes.tsv` | The adopter-declared deny classes the greenlight reads. Ships empty by design: an adopter's own cloud or tool denies are its rows. |
| `scripts/seat-bg-deny.sh` | The pre-tool-use hook that denies backgrounded shells from a seat. |
| `scripts/subagent-commit-deny.sh` | The pre-tool-use hook: a subagent never commits or pushes (canon §1.3). |
| `scripts/subagent-cap.sh` | The pre-tool-use hook on every tool: the per-subagent wall-clock cap. |
| `scripts/subagent-ledger.sh` | The live-subagent ledger, written at session start and at every subagent start and stop; what the cap and the host guard read. |
| `scripts/subagent-lib.sh` | Sourced, never run: the one shared definition of a subagent's bound. |
| `probes/governance/probe_subagent_commit_deny_v1.sh` | Two halves, one verdict: the deny hook's poles (a subagent's commit and push deny in every wrapped form, the hub's commit passes, garbled input fails closed), and no agent-team primitive enabled. |
| `probes/governance/probe_completeness_v1.sh` | The default-mode allow-list completeness probe: every class the engine's enforcers must cover is covered. |
| `_index/completeness-classes.tsv` | The classes and wrappers that probe checks against; `scope` names the engine rows and the adopter's own. |
| `agents/pre-commit-hook.sh` | The hard gate, canonical source for `.git/hooks/pre-commit`: resolves the committing lane, reads the declared spine paths, blocks a module or executor commit touching any of them, and carries the set-coverage check on foundation's own authored-spine commits. |
| `agents/commit-msg-hook.sh` | The commit-time gate on the message: the creed scan over the staged change and its message. |
| `agents/pre-merge-commit-hook.sh` | The forced-merge-path guard: a merge commit reaches the spine only through the reaper. |
| `agents/pre-push-hook.sh` | The push boundary: every commit a push carries is signed by the key of the seat that made it. |
| `scripts/install_pre_commit_hook.sh` | Installs the four git-side hooks above into `.git/hooks/`; its presence is what boot and audit verify. |
| `scripts/declared-spine-paths.sh` | The spine-path emitter: one protected path per line from its own hand-kept list plus the handoff row of `_index/engine-paths.tsv`; the pre-commit hook and the assembler keep their own base arrays and append this emitter's output. An adopter that needs a spine path of its own edits these engine rows (not a slot at v2.7). |
| `probes/set-gate/probe_census_parity.sh` | Drives every registered enforcer's membership test against the one census, both forms, fail-closed on an undriveable enforcer. |
| `probes/governance/probe_single_writer_manifest.sh` | The single-writer invariant as a probe over the manifest: one writer per spine path. |
| `scripts/governance-probes-spine.sh` | Runs the spine's governance probe bytes at a boundary, so a lane cannot probe itself with its own copy. |
| `scripts/seat-keys.sh` | Seat signing keys (canon §6): registry to allowed signers, commit and relay verification, the registry probe; also the lane-sync candidate verb (`adopt-candidate`), which judges a trunk-cut sync candidate by its parents and tree (a conflict resolved under `_boot/` admitted, an unresolved `_boot/` entry or a conflict outside `_boot/` refused by name) before the lane signs it. |
| `scripts/secret-scan.sh` | The commit-time credential scan over the added lines of the staged change. |
| `scripts/surfaces-token.sh` | The single `surfaces:` authorization-input predicate, read by the ledger and the gates. |
| `contracts/THREAT-MODEL.md` | The threat model of the v2.7 governance package: what each layer above is for, and what it does not claim. |

## 4 Set-level authorization, the thesis in executable form

**Canon anchors: §4 enforcement mechanisms, §10 ratification flow. Contracts: `contracts/C-SET-AUTHORIZATION.md`, `contracts/C-RATIFICATION-PACKET.md`, `contracts/COST-CAPS.md`, `contracts/SPEC-BUILD-CLASS-STANDING-APPROVAL.md`.**

This is the machinery the whole architecture exists to carry: the set, not the change, is what gets authorized, with foundation assembling and assessing and the independent human ratifying. New at v2.7: the build-class predicate, a standing approval for a named class of acts that need no pen, proven in both polarities.

| File | What it is and what runs it |
|---|---|
| `contracts/C-SET-AUTHORIZATION.md` | The governing model: the round-trip flow, the enforced mechanisms (conformance, footprint coverage, joint-edge coherence, the cost brake), the member-as-manifest rule, the check-reference, the definition of done. **Core read, by role.** |
| `contracts/C-RATIFICATION-PACKET.md` | The packet schema `ratify.sh assemble` writes and the operator's decision taxonomy reads. **Core read, by role.** |
| `contracts/COST-CAPS.md` | The declared cost envelope the cost brake prices against, two adopter slots. |
| `contracts/CONSTANTS.md` | The generated generic subset of the origin's constants: only the declared state condition that `scripts/boot-check.sh` reads; every project operational constant stays with the declaring project. |
| `contracts/READINESS.md` | When an output may be called ready: the readiness bar every return and packet is held to. |
| `contracts/SPEC-BUILD-CLASS-STANDING-APPROVAL.md` | The build-class standing approval: the class of acts that proceed without a pen, its predicate and its proof bar. |
| `scripts/pending-set.sh` | The ledger instrument, three verbs: `list` (any seat, read-only), `member` (a module writes its manifest entry to its own outbox, refused without surfaces), `reap` (foundation-only: append the pending row to the ledger; the verb the upgrade runbook relies on). |
| `scripts/ratify.sh` | The engine's heart: `assemble` reads the ledger and every member entry, computes joint edges against the substrate table, writes the packet; `assess` records foundation's reasoning; `ratify` records the operator's single decision line. Foundation-only, resolver-gated. |
| `scripts/cost-guard.sh` | The cost brake: reads the usage ledger, prices rows against the caps, closed exit-code set, unreadable ledger halts. Vendor-neutral at the pin. |
| `scripts/criteria-redpole.sh` | The mechanical half of the auditor's criteria-adequacy check: a set's criteria must have a red pole. |
| `scripts/structure-of-record.sh` | The check-reference gate: a packet cites the structure of record it was judged against. |
| `scripts/build-class-check.sh` | The build-class predicate gate, four checks, fail-closed: is this act in the standing class, or does it need the pen. |
| `_index/authz-enforcers.tsv` | Operative data for the build-class predicate: which enforcer covers which authorization input; `scope` is `engine` or `origin`. |
| `_index/substrates.tsv` | The substrate vocabulary a declared-effects key is read against by `assemble`; engine rows ship, the adopter adds its own with scope `origin`. |
| `_index/engine-paths.tsv` | Declared engine paths: the files the shipped engine itself writes or reads at run time, the fourth exit of the footprint rule. **Core read, by role.** |
| `probes/set-gate/probe_footprint_coverage_flip.sh` | `assemble` refuses a set that does not cover its requirement's declared footprint; flip-proven. |
| `probes/set-gate/probe_semantic_hunt_flip.sh` | The semantic-hunt slot is unskippable: a merge decision refuses on a missing or incomplete hunt. |
| `probes/build-class/probe_build_class_predicate_v1.sh` | Standing probe over the predicate's operative data. |
| `probes/build-class/proof_arming_both_polarity_v1.sh` | The build-class completion bar as a runnable instrument: the gate seen to pass and seen to fail. |
| `docs/EXPORT-set-authorization.md` | The methodology export: the thesis, enforcement and first-execution method as a portable narrative, written for reading rather than running. |

## 5 The work lifecycle, dispatch to audited closure

**Canon anchors: §3 discipline rules, §4 receipts. Schemas: the `schema/` directory whole.**

| File | Role |
|---|---|
| `schema/state-machine.md` | The work-package lifecycle with the no-fake-closures property as graph structure: no edge from in-progress to closed; only an auditor-reproduced receipt closes. |
| `schema/work-package.md` | The typed shape of the unit of work. |
| `schema/receipt.md` | The typed shape of the proof it ran. |
| `schema/verification.md` | Four rings, the probe-guard rule and the acceptance function. |
| `schema/concurrency.md` | The parallel-worker ceiling under which lanes and workers overlap, named by class. |
| `dispatch/LATEST.md` | The live hub pointer, spine-protected, so status is read from a file rather than a screenshot; ships as the skeleton. |
| `docs/OPERATING-DISCIPLINE.md` | Completion, verification and state that survives a restart: the contract form of canon §3. |
| `disciplines.md` | The standing disciplines, each with its trigger and its cite, which the creed scan reads at every boundary. One prose line carries an upstream catalogue-identifier word (known residue, cured at 2.8). **Core read, every seat.** |
| `_index/boot-roster.md` | The generated boot roster: which disciplines every seat reads at boot, rendered from `disciplines.md`. |
| `scripts/gen-boot-roster.sh` | Renders the boot roster from the disciplines and their annotations. |

## 6 Merge, reap, and lane currency

**Canon anchor: §7.2 retirement as the mirror of provisioning.**

| File | What it is and what runs it |
|---|---|
| `scripts/reap_at_merge.sh` | Audit-at-merge, the merge-time backstop: substrate guard, the forced-merge-path sentinel, the five-state prefix match. Run by foundation at every module merge. |
| `scripts/reaper.sh` | The worktree-lifecycle reaper: reap-at-merge cleanup, stale-lock reaping, the force-remove guard. Lane-agnostic. |
| `scripts/reap-safe.sh` | The standing reap guard: a reap never removes a worktree whose lane still holds unmerged work. |
| `scripts/set-membership.sh` | No cherry-pick, as one sourced function with two callers: the merge reaper and the pre-merge hook. |
| `scripts/lane_currency_gate.sh` | The spine-to-module mirror of reap: brings a module lane content-fresh with the trunk without letting it touch the spine. |
| `probes/set-gate/probe_module_adopt_merge_guard.sh` | The module-adopt merge guard acceptance probe. |
| `.gitattributes` | Union-merge for a lane's ignore file at a currency sync, so a lane never loses its own ignores to the trunk's. Package-authored from the origin's rule. |

## 7 Communication, relay, transport integrity, and escalation

**Canon anchors: §5 communication architecture (transport lives outside every participant), §4 the reconciliation diff. Contract: `contracts/SPEC-DOORBELL.md`. Protocol: `_knowledge/COORDINATION.md`.**

| File | What it is and what runs it |
|---|---|
| `scripts/inbox.sh` | The lane-resolved spine-inbox reader, the hub-and-spoke relay engine. Every lane's first action each turn. |
| `scripts/inboxf.sh` | The hub read: foundation's boundary instrument over every lane's outbox. Carries one sibling-folder default an adopter's path overrides (known residue). |
| `scripts/consume-core.sh` | The one consume, seen and shown state machine both readers source. |
| `scripts/doorbell.sh` | The doorbell wrapper: tmux is the bell, the git inbox is the transport, payload never rides the bell, a dropped bell delays and never loses. |
| `scripts/signal.sh` | The durable operator-to-seat signal: directives become files. |
| `scripts/status.sh` | Observable state without attaching to a pane. |
| `scripts/inbox-age-filer.sh` | Canon §7.4(b) inbox-age liveness, filed from outside the seat. |
| `contracts/SPEC-DOORBELL.md` | The transport contract: relays move by git, the doorbell wakes, reconciliation proves arrival. **Core read, by role.** |
| `_knowledge/COORDINATION.md` | The coordination protocol: hub-and-spoke, inbox and outbox, the integrator clauses, the module-to-foundation asymmetry. Ships as the generic integrator protocol. **Core read, every seat.** |
| `scripts/reconciliation-diff.sh` | Canon §4's bidirectional transport-integrity check, one mechanism: both sides enumerate, the difference is named, empty-both-sides is an error. Carries one sibling-folder default an adopter's path overrides (known residue). |
| `probes/reconciliation-diff/README.md` | The seen-to-fail evidence index for the reconciliation diff's acceptance poles. |
| `probes/reconciliation-diff/probe_ac1_ac6_battery_v1.sh` | Acceptance battery AC1 to AC6 over the diff. |
| `probes/reconciliation-diff/probe_ac7_ac8_seeded_poles_v1.sh` | The seeded poles AC7 and AC8. |
| `probes/reconciliation-diff/probe_ac9_zero_zero_unreadable_v1.sh` | AC9: both sides enumerating empty must exit 3, never 0. |
| `probes/governance/probe_hub_reachability.sh` | Every lane can ring the hub under the hub's current session name. |
| `probes/governance/probe_hub_reachability_poles.sh` | Its poles; pole 1 reads live state (declared residue at 2.7). |
| `probes/governance/probe_window_plan_transport.sh` | Red and green poles for the transport rows of the window plan: inbox, hub read, consume core, lane surface. |
| `probes/set-gate/probe_consume_premise.sh` | Premise-at-pickup poles: a consumed relay carries the premise it was consumed under. |
| `probes/set-gate/probe_inbox_consume_parity.sh` | The hub's consume interface and the lane's agree. |
| `probes/set-gate/probe_govcheck_relay_ref.sh` | The governance-check gate resolves a relay reference on a lane outbox path. |
| `docs/examples/escalation-003.md` | The shipped worked example of a lane reaching an authorization boundary it cannot resolve, so an adopter's first conflict has a filed precedent. Package-authored. |

## 8 Standing audit, the governance index, and the record

**Canon anchors: §4 enforcement mechanisms (invariants are probed, not asserted), §13 the completeness firewall. Contract: `contracts/SPEC-GOVERNANCE-INDEX.md`.**

Two halves: the audit that fires on every commit and at every seat boundary, and the governance index that turns the record into something a command can cite.

**The audit half:**

| File | What it is and what runs it |
|---|---|
| `agents/post-commit-hook.sh` | The lane-aware reap-then-audit hook, canonical source for `.git/hooks/post-commit`: module marker and push, foundation reap plus push plus doorbell, then the auditor. |
| `scripts/install_post_commit_hook.sh` | Its installer. |
| `agents/auditor-contract.md` | The post-commit auditor: re-run, never trust; observe, never author. |
| `agents/audit-system-prompt.md` | The system prompt the hook launches the model half with, opening on the canon §7.5 line. |
| `scripts/code-auditor.sh` | The code half of the audit split: fires on every commit, zero model calls, covers what a script can prove. |
| `scripts/auditor-usage-record.sh` | The usage recorder: model usage in the audit written to the ledger the budget probe reads. |
| `scripts/audit-seal.sh` | The one seal writer at a boundary: restart, shutdown or manual; called by the stop hook, the seat exit, the boot check, the merge reaper and the post-commit hook. |
| `scripts/seal-rulings.sh` | The ruling seal form, mechanized: a ruling's content half and its masthead sealed together. |
| `agents/standing-probes.yaml` | The declared registry of the seven standing probes with path, run_by and schedule: auditor liveness, the two set-gate flips, the build-class predicate, governance-index drift, hub reachability, auditor model pin. An invariant's health is its streak here, not its prose. |
| `_index/probe-tiers.tsv` | The tier of each standing probe: gate candidate, per commit on trigger, or excluded; what the code auditor schedules by. |
| `probes/auditor/probe_auditor_model_pin_v1.sh` | The auditor runs on the pinned model, not whatever the harness defaults to. |
| `probes/foundation/probe_auditor_liveness_v1.py` | Liveness of the post-commit trigger itself, checked from outside the participant. Above 8-character commit abbreviation its Arm A reports a false FAIL, never a false PASS (declared residue, cure named for 2.8). |
| `probes/budget/probe_efficiency_budget.sh` | The budget probe: the hot files stay under their byte caps; a measuring instrument, not a judgment. |
| `probes/governance/probe_loop_cure_e12.sh` | The loop-cure poles: the audit seal, the code auditor and the ledger instruments cannot re-enter themselves. |
| `issues_register.md` | The single append-aware defect and named-wait record, hypotheses not facts, seeded empty. |
| `scripts/audit_issue_register.py` | The register's discipline tool: push-drift flagging and register-shape enforcement. |
| `scripts/check_orchestration_freshness.sh` | The orchestration-freshness probe body over the session-state surface and the decision log. |

**The governance-index half:**

| File | What it is and what runs it |
|---|---|
| `contracts/SPEC-GOVERNANCE-INDEX.md` | The governance index, its retrievers, and the commit-time creed gate. **Core read, by role.** |
| `scripts/gen-governance-index.sh` | Derives the index from the tri-corpus: contracts, canon and disciplines, joined to the curated annotations. |
| `_index/governance.tsv` | The derived index itself (a build artifact, never hand-edited): regenerated at package build by the shipped `scripts/gen-governance-index.sh` within a ruled line bound; against the pin's blob it differs in exactly one comment line, the frame line that names the public canon's blob instead of the origin's internal one. The one `derived` row of the package. |
| `_index/annotations.tsv` | Curated metadata for the index rows, the join partner of the derived id set. |
| `_index/layers.tsv` | Per-row layer and disposition for the index. |
| `_index/mechanisms.tsv` | Index rows that are not a single contract file, entry, invariant or canon section. |
| `_index/preservation.tsv` | Where each merged or retired row's protection now lives. |
| `_index/coverage-baseline.tsv` | The before side of the rule that net governance coverage may not decrease. |
| `_index/canon-class-triggers.tsv` | Each canon change class mapped to a content trigger and a path trigger. |
| `_index/canon-section-map.tsv` | Change class to the canon sections a change of that class must cite. |
| `contracts/RETIRED-TERMS.tsv` | Mechanisms retired by ruling that must not reappear on a law surface; the creed scan reads it. |
| `scripts/creed-scan.sh` | The boundary-time trigger-to-cite breach scanner: a discipline's trigger in a change without its cite is a breach. |
| `scripts/creed-scan-spine.sh` | Runs the spine's creed-scan bytes at a boundary (stop and session end), never a lane's copy. |
| `scripts/governance.sh` | Cite-before-raise: no settled decision is re-raised without citing the record, as a command. |
| `scripts/rulecheck.sh` | The draft-time governance retriever: which rows a draft must cite. |
| `probes/governance-index/probe_governance_index_v1.sh` | Standing probe for the index and its retriever: drift between the corpus and the index is a failure. |
| `probes/governance-index/fixtures/positive-prose.tsv` | One domain sentence per index row, the retriever's positive fixture. |
| `scripts/canon-core.sh` | The one canon-edition resolver, sourced by the governance index generator, the creed scan, the governance retriever, the reconciliation diff and two reconciliation probes; three governance probes name the canon file directly. |
| `scripts/rules_manifest.sh` | The scoped rules-manifest hash over the guard, resolver and coordination clauses, so rule drift is a fingerprint change. |
| `probes/governance/probe_surface_conformance_v1.sh` | The surface-conformance probe, checks A1 to A8: every seat surface carries what the canon says it carries. Its spine-host row makes no network call: NO-SOURCE when the reference carries no pre-commit hook source, else PENDING-CUSTODY by name, never CURRENT. |
| `scripts/surface-conformance-spine.sh` | Runs the spine's surface-conformance bytes, never a lane's copy. |
| `probes/governance/probe_application_v1.sh` | The application floor for the canon's teachings: each teaching is carried by a named file. |
| `_index/application-carriers.tsv` | The teaching source of record and its carrier table, one row per teaching. |
| `probes/governance/probe_governance_fleet_divergence_v1.sh` | Retired pointer stub, kept so a cite resolves; subsumed by the surface-conformance probe. |

## 9 Instantiation, adoption, and upgrade

**Canon anchors: §11 packaging and adoption, §12 instantiation checklist. All package-authored.**

| File | Role |
|---|---|
| `WHY-GMAA.md` | The first file an adopter reads and gives a chat session: what the architecture is, the failure it exists to stop, what each shipped mechanism does for the adopter, what it costs, when it fits and when it does not, the five adoption phases, the nine decisions, and exactly what a session asked to assess fit is being asked to do. |
| `WHY-GMAA.rtf` | Its rich-text rendering. |
| `ADOPTION-COVER.md` | The adoption itself: the five phases (decide, the gate, the folder, the fills, genesis as one command and the lane step), what a fresh adoption prints at boot and what each line means, how later seats are provisioned, both version axes. |
| `ADOPTION-COVER.rtf` | The same cover in rich text for a reader without a Markdown viewer. |
| `GETTING-STARTED-LINUX-MAC.md` | The adopter's walk from a blank machine to a launched foundation seat: install, sign in, the folder, the chat phases, the one command `bash genesis.sh` from `genesis.conf` and its named steps (`fill`, `check`, `seed`, `enroll`, `hooks`, the launch), `genesis.sh lane` for each roster seat, the seeded-fault proof; troubleshooting keyed to the commands' own halt lines. |
| `genesis.sh` | The onboarding verb in command form (canon §11). With no argument it reads `genesis.conf`, verifies `MANIFEST.sha256` at a fresh unzip (before anything is filled; a timestamp marker records it), and runs, in order, each step still undone: `fill` (replaces one slot in every file that carries it), `check` (names what is missing; refuses an allow-listed subagent with no definition file), `seed` (stamps foundation, seeds every declared fill path and the record files, initialises git on the trunk, commits, pushes to `origin`, runs the boot check), `enroll` (foundation's key, the roster row, the derived registry), `hooks` (the five hook files, re-run safe; confirms every lane), and the launch. `lane <lane>` lands one provisioning set for a roster seat (worktree, stamp, row, inbox, charter, key) as foundation's signed commit through the hooks, then binds the lane's key in its worktree and commits its stamp with it; it resumes at the lane's signing step if an earlier run landed the set and stopped. `explain` lists every file each step writes. |
| `GETTING-STARTED-LINUX-MAC.rtf` | Its rich-text rendering. |
| `CHECKLIST.md` | The instantiation checklist as a working plan document: the canon §12 list in executable order, with progress. |
| `OPERATOR-GUIDE.pdf` | The operator-side companion: what the human at the apex does and answers. |
| `OPERATOR-CHAT-SETUP.md` | The chat-side setup page: project, bootstrap, and why a session wakes up lost without them. |
| `OPERATOR-CHAT-SETUP.rtf` | Its rich-text rendering. |
| `SLOTS.md` | The single inventory of every adopter slot and fill, one row each, checked both ways against the shipped slot table; the slots are filled by `genesis.sh fill` and the registry fill is derived by `genesis.sh enroll`; names the literal `origin` for the adopter's substrate rows. |
| `_index/adopter-slots.tsv` | The adopter-fill slot table the engine's probes read; the machine twin of `SLOTS.md`. |
| `docs/FOUNDATION.md` | The project rationale and invariants skeleton, shipped with authoring instructions for the adopting project's chat architect. **Core read, by role.** |
| `docs/CHARTER_skeleton.md` | The shape of a seat's charter (`_boot/CHARTER-<seat>.md`): the shipped foundation charter's schema with fills, and the state-source map heading `scripts/boot-check.sh` parses. The Phase 4 session writes each seat's charter from it; foundation commits it before `genesis.sh lane`. |
| `docs/CHAT-SEAT-PROJECT-INSTRUCTIONS_skeleton.md` | The chat-seat charter skeleton, the §1.1 chat-seat law instantiated per project. |
| `docs/FIELD-EVIDENCE_skeleton.md` | The conformed field-evidence log schema, canon §4, seeded per project. |
| `docs/BOOT-CHECK-PROPAGATION.md` | How the one boot-check script reaches every lane by call, never by copy, and stays there. |
| `docs/ENGINE-UPDATE.md` | The upgrade runbook: how an adopter takes a new engine release over its filled slots, by hand, each step proven against the shipped scripts. No classifier ships. |
| `FIRST-SET.md` | The first unit of work after genesis, one lane and one requirement from dispatch to a ratified merge, every verb in order with the lines a measured run of this engine printed; the rule that a lane commits only outside the spine paths. |
| `FIRST-SET.rtf` | Its rich-text rendering. |
| `SUBAGENTS.md` | The subagent roster as the ninth Phase 4 decision: canon §1.3's four classes, the `tools:` line per class, the roster through `PROJECT_AGENT_ALLOWLIST`, loadability proven by one live spawn; `genesis.sh check` refuses by name an allow-listed subagent with no definition file. |
| `SUBAGENTS.rtf` | Its rich-text rendering. |
| `00-PASTE-THIS.txt` | The Phase 1 paste: the lines a prospective adopter gives a chat session with the decision kit attached, which make the session prove its reading before it judges and end with adopt or do not adopt. Also the decision kit's first file. |
| `genesis.conf.example` | The shape of `genesis.conf`, the file `bash genesis.sh` reads: the project token, the remote, and the six slot values, one per line. |

## 10 Release integrity and the release envelope

**Canon anchor: §11 packaging and adoption (the versioned manifest and the companion sealed archive).**

**In-zip integrity and provenance:**

| File | Role |
|---|---|
| `MANIFEST.sha256` | The per-file fingerprint manifest, one row per shipped file; `shasum -c` inside the unzipped package is the adopter's second verify surface. Its own sha256 is the package self-sha. |
| `PROVENANCE.tsv` | One row per file: kind (origin, derived, canon, package), disposition, source at the pin and sha256. The extraction law and the pin are in its header. |
| `CHANGELOG.md` | The versioned public account, both axes on every entry, slot-contract changes under their own heading, known residue by class. |
| `CITATION.cff` | The citation metadata, both axes carried. |
| `ENGINE-MAP.md` | This file: the inventory of the engine, every zip path a row with its role and canon anchor, the core-read files marked. Re-derived at every release; the release gate checks it against the zip both ways (0 missing, 0 extra, 0 duplicate). **Core read, every seat.** |

**The loose release layer, beside the zip** (not zip members; listed here so the envelope is whole): `README.md` the front door and the map of the release; `README.rtf` its rich-text rendering; `LICENSE.md` the licensing envelope, engine under Apache 2.0 with the Commons Clause, the canon file carved out under CC BY 4.0; copies of `MANIFEST.sha256` and `PROVENANCE.tsv`; and `SHA256SUMS`, seven rows (the engine zip, the decision kit zip, the two copies, the README pair and the license), the first verify surface, checked before anything is unzipped. The zip carries no license or README member of its own: the license reaches a zip-only recipient through the cover's pointer and the release page, which is why the loose layer travels with the zip.

---

## Execution wiring, the whole engine as a timeline

**At adoption:** `SHA256SUMS` verifies the downloads; the decision kit's paste (`00-PASTE-THIS.txt`) has a chat session read `WHY-GMAA.md`, the canon and the cover and say adopt or do not adopt; the operator decides; the same session, with the Phase 4 files attached and the canon and this map read end to end, settles the nine decisions and returns `docs/FOUNDATION.md`, `seats.yaml`, the coordination sections, the subagent definitions, the charters and `genesis.conf`; then, in the unzipped package, `bash genesis.sh` verifies `MANIFEST.sha256` at the fresh unzip and runs `fill`, `check`, `seed`, `enroll`, `hooks` and the launch in order (`MANIFEST.sha256` verified at the fresh unzip, the two Phase 4 files skipped; `scripts/install_pre_commit_hook.sh` refuses until every writing lane is confirmed), and foundation, after its core read, lands each other roster seat with `genesis.sh lane`; the adopter's deny classes and substrate rows go into their tables as its first governed work.

**At seat launch:** the operator runs `launch-orc.sh` in the worktree; it resolves the stamp through `scripts/resolve-lane.sh` and `scripts/resolve-project.sh`, refuses double-launch, and creates `{project}-{lane}` running `scripts/seat-loop.sh`; the session loads `.claude/agents/orc.md`; the session-start hooks fire `scripts/boot-check.sh`, `scripts/seat-boot-record.sh` and the subagent ledger; the seat derives identity, reads its charter and `dispatch/LATEST.md`, then its inbox.

**Per prompt and per tool call:** the prompt hooks record observed mode and read the exit cue; on every Bash call the greenlight policy, the background deny and the subagent commit deny run; on every tool the subagent cap runs.

**Per change:** foundation dispatches into an inbox and rings `scripts/doorbell.sh`; the lane works on its branch; the reconciliation diff is run by hand when arrival is in question (no hook runs it); the state machine admits no closure without an audited receipt.

**Per commit:** `.git/hooks/pre-commit` reads the declared spine paths at HEAD and blocks non-writer spine writes and uncovered foundation writes; the commit-msg hook runs the creed scan; the pre-push hook verifies the seat's signature; `.git/hooks/post-commit` reaps, pushes and launches the auditor, whose code half runs every time.

**Per set:** members enter the ledger via `scripts/pending-set.sh`; `ratify.sh assemble` computes joint edges against the substrate table and writes the packet; `assess` records foundation's reasoning; the cost brake is run by hand before each metered call (`cost-guard.sh check`; the assembler does not call it); acts in the build class pass `scripts/build-class-check.sh` without a pen; everything else waits for the operator's one decision line, which `ratify.sh ratify` records; foundation merges, `scripts/reap_at_merge.sh` backstops.

**At every seat boundary:** the seat runs `scripts/seat-exit.sh` as its last act, which writes the intent; when the turn ends the stop hook runs the creed scan on the spine's bytes, writes the audit seal through `scripts/audit-seal.sh`, reads the hub, and on the fresh intent sends the exit; the loop relaunches the seat, unless the intent was shutdown or the operator's `scripts/seat-stop.sh` said otherwise.

**Continuously:** the seven standing probes run on their schedules by tier, ledgered; the budget probe holds the hot files under their caps; the index probe holds the governance index to its corpus.

## Coverage account

**The engine zip is 189 files, every one a row above, and 6 loose files beside it** (README.md, README.rtf, LICENSE.md, SHA256SUMS and the two zips; `gmaa-decide_v2.7.2.zip` is four of the zip's members copied flat). By area: area 1 carries 3; area 2 carries 33; area 3 carries 25; area 4 carries 20; area 5 carries 10; area 6 carries 7; area 7 carries 21; area 8 carries 41; area 9 carries 24; area 10 carries 5; total 189. Every zip path appears exactly once across the tables and every table path exists in the zip; the release gate re-runs that check at every candidate and fails on one missing, extra or duplicate row.

By provenance, `PROVENANCE.tsv`'s own kinds: 150 origin files byte-equal to the upstream pin (the upstream's whole functional closure: the wired scripts, hooks and probes, and its contracts, indexes and documents), 1 derived index (the governance index, regenerated by the shipped generator, one frame line differing from the pin's blob), 1 public canon, 35 package-authored members (the adoption documents and their renderings, the skeletons, `genesis.sh`, and this map), plus the manifest and the provenance table: 189.

Two absences are load-bearing and named: `seats.yaml` does not ship (the adopter's roster, written in Phase 4 from the skeleton; `genesis.sh` reads it and derives the registry from it, and the boot check reads it as the genesis marker from the moment it exists), and no update classifier ships (the upgrade runbook is manual).
