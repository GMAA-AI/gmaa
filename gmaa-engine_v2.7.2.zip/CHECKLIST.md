# CHECKLIST: your project's plan and its progress

**absorbed_through_sha:** (fill: the commit you have absorbed governance through; at genesis, the genesis commit, stamped in the commit after it; foundation re-stamps this line after each absorb)

This file is the operator's sequence: the work in order, each item checked when it is done on evidence. The boot check reads the line above to see whether governance has moved since the last absorb, and it reads the checklist items below; keep both forms exactly as shown.

## Plan
- [ ] (fill: the first item of work, stated so its completion can be checked)
