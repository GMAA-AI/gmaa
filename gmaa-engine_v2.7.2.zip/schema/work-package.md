# Work-Package Schema

## Per-WP file format

A work package lives at `work-packages/<wp_id>.md` and has this shape:

```markdown
# WP <wp_id> — <one-line title>

| Field | Value |
|---|---|
| wp_id | <wp_id; globally unique; e.g., P0.1, WP-A-MIG-100, WP-B-GATE-0c1> |
| track | <harness | contract | verification-spine | substrate-remediation | A | B | C | D | E | F | uat | live-fire | measurement | reconciliation> |
| phase | 0 | 1 | 2 | 3 | 4 |
| state | OPEN | IN_PROGRESS | AWAITING_RECEIPT | VERIFIED | CLOSED | REOPENED |
| branch | wp/<wp_id-kebab-cased> (per `schema/state-machine.md` branch discipline; one-to-one) — exception: P0.1 genesis WP uses `(genesis; no branch)` |
| dependencies | [<wp_id>, ...]  (other WPs that must be CLOSED before this WP's state can transition OPEN → IN_PROGRESS) |
| worker | orc | chat-Architect | code-Auditor | track-lead-{X} | worker-{ephemeral} | migration-runner | make-deploy | solution-deploy | wp-provisioner | operator |
| created_at | <ISO 8601 UTC> |
| state_history | <append-only list of (from_state, to_state, ts, actor, reason_or_receipt_id) tuples> |

## Acceptance

<bullet list of acceptance criteria — what receipt(s) license CLOSED>

## Artifacts

<file paths produced by this WP (relative to repo root); annotate each>

## Receipts

<list of receipt_ids in ledger/receipts.jsonl for this WP; append-only>

## Body

<the actual content of the work — design decisions, results, evidence>

## Escalation log

<append-only record of STOP-AND-SURFACE events, six-tier self-resolution exhausts, contract-ambiguity routings>

## §Self-probe

<how the receipt's probe verifies this WP's acceptance criteria; what an Auditor reproduces>
```

## Naming convention

- `P0.<n>` — Phase 0 work packages (per EXECUTION_PLAN §4 Phase 0 table). `P0.1` through `P0.6` + `P0.C` (live-infra characterize) + `P0.X` (substrate close).
- `WP-{TRACK}-{KIND}-{seq}` — Phase 1+ work packages. Examples: `WP-A-MIG-0001` (Track A substrate migration), `WP-B-GATE-0c1` (Track B gate worker), `WP-C-SCREEN-LIST-VIEW` (Track C screen), `WP-D-FLOW-NOTIFY-TRIGGER` (Track D), `WP-E-WORKFLOW-INTAKE` (Track E workflow), `WP-F-ENV-PROVISION` (Track F).
- `WP-UAT-J{n}-{case}` — Phase 2 UAT cases.
- `WP-PHASE-3-{n}` — Phase 3.

## Owner conventions

- **orc** owns the DAG + ledger + frontier + dispatch + escalation routing. Does NOT execute domain work in Phase 1+ — dispatches to track leads.
- **chat-Architect** owns contracts (Phase 0 P0.3 + P0.6) + contract-ambiguity rulings (escalations). Does NOT execute work packages.
- **Track Lead** owns track decomposition + Ring-2 verification + worker integration.
- **Worker (ephemeral)** owns one work package: produces artifact + emits receipt + terminates.
- **code-Auditor** independently reproduces every Ring-2/3 probe; observe-and-report only; never authors or fixes.
- **Specialist deploy class** runs deploy actions under service-account credentials (migration-runner / make-deploy / solution-deploy / wp-provisioner).
- **Operator** four touchpoints only (repo standup [DONE on this commit], the substrate tail, account creation as-needed, first-live-release go/no-go).

## Reference

- State transitions: `schema/state-machine.md` (explicit NO `IN_PROGRESS → CLOSED` edge).
- Receipt shape: `schema/receipt.md`.
- Verification rings: `schema/verification.md`.
- Concurrency: `schema/concurrency.md`.
