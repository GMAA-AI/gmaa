# Receipt Schema

## The receipt is the unit of trust

Every Ring-1 / Ring-2 / Ring-3 verification pass emits one receipt. Receipts are append-only to `ledger/receipts.jsonl`. Never edited after write — corrections are NEW receipts that reference the prior `receipt_id`.

## JSON-line shape (one receipt per line in ledger/receipts.jsonl)

```json
{
  "receipt_id": "R-<YYYYMMDDTHHMMSSZ>-<seq>",
  "wp_id": "<work-package id from schema/work-package.md>",
  "case_id": "<optional; UAT cases set this; harness/contract receipts null>",
  "verification_ring": 0 | 1 | 2 | 3,
  "ring0": {
    "tools_run": {"<tool_name>": <exit_code>, ...},
    "all_pass": true | false,
    "notes": "<optional; e.g., 'py_compile + ruff + mypy for Python artifact; sql_parse for SQL artifact'>"
  },
  "artifact_paths": ["<repo-relative path>", ...],
  "probe_path": "<repo-relative path to committed re-runnable probe>",
  "probe_last_run_at_utc": "<ISO 8601 UTC>",
  "probe_exit_code": 0 | <int>,
  "probe_output_summary": "<short; full output captured at probes/<scope>/<timestamp>.txt>",
  "probe_output_hash": "<sha256 of probe output file>",
  "git_commit": "<commit sha at probe-run time; PENDING_COMMIT if pre-commit>",
  "auditor_status": "PENDING" | "REPRODUCED" | "DIVERGED" | "WAIVED",
  "auditor_run_at_utc": "<ISO 8601 or null>",
  "auditor_notes": "<text or null>",
  "rework_attempt": 0 | <int>,
  "supersedes_receipt_id": "<prior receipt_id this receipt supersedes, or null>",
  "timestamp": "<ISO 8601 UTC; when receipt was emitted>",
  "actor": "orc | chat-Architect | code-Auditor | track-lead-X | worker-Y | migration-runner | make-deploy | solution-deploy | wp-provisioner | operator"
}
```

### Ring 0 block — required (per `schema/verification.md` §1 + §8.5)

The `ring0` block is **mandatory** per architect relay 2026-05-24. A worker MAY NOT emit a receipt for an artifact failing Ring 0 (i.e., `ring0.all_pass = false` is grounds for self-healing rework per `schema/state-machine.md` §Self-healing-backward-edges, NOT receipt emission for a clean state).

The block records per-tool exit codes:
- **Python artifacts:** `{"py_compile": 0, "ruff": 0, "mypy": 0}` (worker runs all 3; any non-zero → rework).
- **SQL artifacts:** `{"sql_parse": 0}` (worker runs syntactic parse-validation; e.g., dry-run or sqlfluff).
- **Workflow/integration definitions:** `{"schema_validate": 0}` (worker runs the platform's schema validator).
- **Low-code platform app:** `{"app_check_formula": 0, "app_check_datasource": 0}` (worker runs the platform's app checker).
- **Bash/shell scripts:** `{"shellcheck": 0, "bash_n": 0}` (shellcheck + `bash -n` syntactic check).
- **Markdown/contract docs:** `{"markdown_parse": 0}` (light parse-validation; no link-check by default).

`ring0.all_pass = true` ⇔ every tool returned exit 0. Receipts with `all_pass = false` are rejected at emission time by worker discipline (rework loops back per `schema/state-machine.md` §Self-healing-backward-edges).

### rework_attempt + supersedes_receipt_id (per architect relay 2026-05-24 §8.4 BOUNDED RETRY)

- `rework_attempt = 0` for the first emission of a WP's receipt. Incremented on each backward-edge rework (probe fail / Ring 0 fail / Auditor DIVERGED).
- `supersedes_receipt_id` = the prior `receipt_id` this receipt supersedes (when reworking after a fail). The prior receipt stays in the ledger (rule 4 — append-only); this field marks the supersede chain.
- On `rework_attempt = 3+` → orc HALTS self-looping this WP + logs to `_escalations/<escalation-id>.md` per the BOUNDED-RETRY guard (`schema/verification.md` §8.4).

## Verification rings

| Ring | Scope | Allowed inputs | Mechanism |
|---|---|---|---|
| **1 — Unit** | Per work package | Fixtures / fakes permitted | the language's unit-test runner; the substrate's test harness (sprocs); the platform's schema validator; the platform's app checker |
| **2 — Contract conformance** | Per subsystem | Live environment, read-only probes | Per-object catalog existence probes; per-object grant-catalog probes; API shape assertions; low-code-platform data-source binding assertions |
| **3 — Live-data integration** | Canonical path end-to-end | **Live data only — no hand-INSERT** | One real product walked research → approval → promotion → publish → verified WP draft |

## Acceptance function (bifurcated per architect pin 2026-05-25 — v1.3)

```
CLOSED              ⇔ receipt_exists ∧ probe_exit_0 ∧ ring0_all_pass ∧ auditor_REPRODUCED
CLOSED-PROVISIONAL  ⇔ receipt_exists ∧ probe_exit_0 ∧ ring0_all_pass ∧ auditor_WAIVED (live-surface; honest admission)
                                                                       ∧ operator-spot-audit-owed
```

CLOSED-PROVISIONAL → CLOSED requires operator-spot-audit REPRODUCED per `schema/state-machine.md` §States row CLOSED-PROVISIONAL.

No exceptions. Documentation-only closures rejected by construction (`state-machine.md` explicit NO `IN_PROGRESS → CLOSED` edge). **The prior `auditor_concurs` shorthand (which historically read as "REPRODUCED OR WAIVED+freshness") is WITHDRAWN** as a fake-closure backdoor per `schema/verification.md` §4.1 — WAIVED on live-surface licenses CLOSED-PROVISIONAL only; never plain CLOSED. The 24h freshness window guards staleness, not independence.

## Probe-guard rule (universal)

Every claim of "applied / done / live / verified" **must cite a committed, re-runnable probe by path**. If no probe is cited, the claim is downgraded to "asserted — NOT verified" and the work package does **not** close.

- **Per-object assertions only.** A catalog existence check for each named object.
- **Aggregate proofs are forbidden.** Never `COUNT(*) FROM sys.procedures`. An aggregate cannot distinguish *missing X* from *surplus Y*.
- **GRANT proofs are per-object** rows from the grant catalog, filtered to the expected grantee.
- Probes live at versioned paths (`probes/<scope>/probe_<name>_<v>.sql`), are SP-context-safe, and are committed in the same change as the artifact they verify.

## Boundary caveat

A catalog existence check run as the workload identity may conflate "absent" with "no permission" from non-Owner contexts. Probes that test existence from the workload context must differentiate: probe the object catalog (also subject to perm visibility) AND the grant catalog for the expected grantee. If a probe surfaces ambiguity, the receipt records `WAIVED` with explicit notes; an Owner-context cross-check probe is filed as a follow-up WP.

## Receipt rules (binding)

1. **Append-only.** Never edit a receipt; corrections are NEW receipts.
2. **Probe-cited.** Every receipt has a `probe_path` resolving to a committed file.
3. **Output-hashed.** The `probe_output_hash` is the sha256 of the committed output file; the Auditor re-runs the probe, hashes the output, and compares.
4. **Worker-emitted.** The worker that does the WP emits the receipt. Auditor never emits; only sets `auditor_status` + `auditor_run_at_utc` + `auditor_notes` via a NEW receipt that supersedes (cite prior receipt_id) — never via in-place edit.
5. **Failing receipts reopen WPs.** `probe_exit_code != 0` → WP `AWAITING_RECEIPT → REOPENED` (never `CLOSED`).
6. **Diverged receipts reopen WPs.** `auditor_status = DIVERGED` → WP `VERIFIED → REOPENED`.
7. **WAIVED is CLOSED-PROVISIONAL only** (per architect pin 2026-05-25 v1.3 amendment). Auditor can WAIVE Ring-2/3 receipts where Auditor cannot reach the live surface (file-state-scope boundary per `agents/auditor-contract.md` §Interim-cover); WAIVED on live-surface licenses **CLOSED-PROVISIONAL** (not plain CLOSED) and routes the WP to operator-spot-audit per `schema/verification.md` §4.2. The prior "WAIVED licenses CLOSED if probe is freshness-window-current (24h)" rule is **WITHDRAWN** as a fake-closure backdoor — freshness guards staleness, not independence. CLOSED-PROVISIONAL → CLOSED only via operator-spot-audit REPRODUCED.

## ID convention

`receipt_id = R-<YYYYMMDDTHHMMSSZ>-<seq>` where `seq` is a 3-digit zero-padded counter within the same second. Append-only file order = receipt order = chronological order; no reordering.
