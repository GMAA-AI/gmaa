# Engine invariants

Four binding invariants ship with the engine. They bind every seat, regardless of the project's
own data substrate, connectors, or domain. Numbering follows the origin project's own invariant
list; the engine carries only the entries that are generic. Any other invariant a project declares
for its own substrate or connectors stays in that project's own configuration, never here.

## inv#1 — LIVE-DATA-ONLY
No hand-INSERT smoke/bypass path; all validation runs through the canonical pipeline. The
pipeline's own probe is substrate-specific and is supplied by the project, not by this rule.

## LEAST-PRIVILEGE-WRITER
The workload identity that agents run under is read-only against the substrate by default;
privileged operations route through a separately-authenticated, human-owned path. The rule is
verified continuously by a standing probe, not asserted. The probe is substrate-specific and is
supplied by the project, not by this rule.

## inv#4 — No fake closures
No fake closure: Status is a hypothesis; closure needs enumerated state-fixing evidence; RETRACT on
a refuted premise, never silently mark it "fixed."

## inv#5 — Halt-loud over silent-degradation
Halt loud with a named reason; no lexical fallback, no silent default, no degraded continue. A
failure that could silently downgrade to a guess must instead stop and name what is missing.

## Scope
This file is the carrier for exactly these four ids. A project may wire each invariant to its own
scanner, probe, or gate; this file states the rule those mechanisms enforce, not the mechanism
itself.
