# CLAUDE.md: operating contract for this project's seats

> Current law only. Your project's history, scars and superseded text live in `_orchestration/decision-log.md` and your own ruling log, never here. The canon (`GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_9.md`) governs where this file is silent or disagrees. Your project's own facts live in `docs/FOUNDATION.md`.

> Section labels (`§0`, `§Core read`, `§7`, `§Boot creed`, `§GOVERNANCE-CHECK` and the rest) are fixed names that the shipped scripts and `disciplines.md` cite. They are not a numbered sequence, and no section is missing.

## §0 · Cold-boot identity (role-generic, binding)

Before ANY other action, resolve your lane from your OWN worktree: `eval "$(scripts/resolve-lane.sh)"`. It reads `_boot/BOOTSTRAP.md` at your worktree root (`git rev-parse --show-toplevel`), cross-checks the stamped `lane` against your actual branch, and prints `lane / role / version / spine_write / blob`. Then emit `BOOT-ACK: lane=$lane version=$version blob=$blob mode=pending-observation`. **Identity comes from LOCATION, never from chat.** If the resolver exits non-zero (no `_boot/BOOTSTRAP.md`, an unset or mismatched lane): **HALT**. Do not guess identity, do not assume the integrator role, do not act on another lane's bootstrap (`_knowledge/COORDINATION.md` §13). A module lane (`spine_write: DENY`) commits only to its own branch and never applies to the spine.

## §Core read · read the law before you act (binding, ALL seats)

Before your first ruling, provisioning act, dispatch or authored commit in this project, read the core files **end to end**: not a search, not a skim, not the sections a task seems to need. A seat that acts on a partial read invents rules, and an invented rule is a breach of the binding invariants below.

**Core, every seat:**
1. `GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_9.md`, the canon. It is the law; everything else implements it.
2. `ENGINE-MAP.md`, the inventory: every file in the engine and what it does. Look there before you look for anything.
3. this file, `.claude/rules/engine/invariants.md` and `disciplines.md`.
4. `_knowledge/COORDINATION.md`: who owns which surface, and how work moves between seats.
5. your own `_boot/CHARTER-<lane>.md` and `_boot/BOOTSTRAP.md`.

**Core, by role, also end to end:**
- **foundation:** `contracts/MECH-WRITE.md`, `contracts/C-SET-AUTHORIZATION.md`, `contracts/C-RATIFICATION-PACKET.md`, `contracts/LAUNCH-CONTRACT.md`, `contracts/SPEC-DOORBELL.md`, `_index/engine-paths.tsv`, and the genesis section of `ADOPTION-COVER.md`.
- **architect:** the foundation list, plus `contracts/SPEC-GOVERNANCE-INDEX.md` and `docs/FOUNDATION.md`.
- **lane and executor:** `contracts/MECH-WRITE.md`, `contracts/SPEC-DOORBELL.md`, `contracts/C-SET-AUTHORIZATION.md`.

**The receipt.** When the read is done, print one line and write the same line into your first handoff: `CORE-READ: <lane> canon@<first 8 of its git blob> map@<blob> coordination@<blob> + <N> files, each read whole`. The blob ids make the line checkable: a receipt naming a blob that is not at HEAD was not read from this tree.

**When it repeats.** At your first boot in a project, and again after any set that changes the canon, `ENGINE-MAP.md` or `_knowledge/COORDINATION.md`. A restart with the same blobs cites the earlier receipt and does not re-read.

**If you do not know, look before you rule.** A question the canon, the map or a contract answers is never answered from your own reasoning. Search the package, and do not stop at the first search that finds nothing. Only when the record is silent does the question go up the ladder.

**Wiring, declared.** In this release the rule is cite-only: the `CORE-READ:` line is its only observable, and no shipped script checks it (the engine's commit gate checks a `CANON-READ:` receipt on architecture-class commits; this line has the same shape so that a later release can check it the same way). Written is not wired (canon §4); do not read this section as a mechanism.

## §7 · Context lifecycle (binding, ALL seats)

**RESTART-PREFERRED, COMPACT-AS-BRIDGE.** The repo is memory; the context window is workspace. A compaction summary is **memory, not evidence**: never assert a done or exists claim from your own summary. A restart re-grounds from HEAD; that is what this boot surface is for.
- **Externalize, then reset.** Never end or compact with load-bearing state only in context. First: work committed, `dispatch/LATEST.md` written, open items in `issues_register.md`. Last act: `scripts/seat-exit.sh restart`; the operator's word `exit` or `shutdown` means `shutdown`.
- **Restart at boundaries.** A work-package close or a wave close is a restart point. Carrying a large context into the next work package is the failure; restart instead. Cold boot is minutes.
- **`/compact` is a mid-work bridge only**, always with focus instructions (work id, files, constraints, next step), and a mandatory re-ground against the repo before the next mutating action.
- **An auto-compaction is a finding:** log one line to `issues_register.md` and continue.
- **Hygiene:** large reads go to subagents (summaries with citations back); `/clear` between unrelated tasks; filter output.

## §Boot creed and trigger-to-cite (binding, ALL seats)

- **Presence:** `scripts/boot-check.sh` loads the boot roster (`_index/boot-roster.md`) from the spine at every boot.
- **"Fan-out" means subagents only.** It never means additional lanes; whether another seat is needed is the architect's decision (canon §2).
- **Trigger to cite:** cite the entry inline before an emission of these kinds; an uncited one is refused at the receiving seat. `scripts/creed-scan.sh` (a linter) scans the committed record.

| Before emitting... | Cite inline (the `disciplines.md` entry) |
|---|---|
| an absence: "not found", "no record", anything "-less" | **DISC-ABSENCE-OF-RECORD** (label receipt versus inference; print the denominator) |
| done, pass, resolved, closed | **no-fake-closures** (invariant 4) |
| an inherited count or proposition carried into a ruling | **DISC-NO-INHERITED-COUNT** (print the denominator) |
| a decision routed to the operator | **DISC-ONE-DECISION-DOOR** |
| an operator directive acted on | **DISC-DIRECTIVE-PROVENANCE** |

## §GOVERNANCE-CHECK · cite before you raise, cite before you reopen (binding, ALL seats)

- **Trigger:** about to (a) raise an issue or route a problem, or (b) reopen or re-derive a settled decision.
- **Read order** (the latest dated state wins): `_orchestration/decision-log.md`, then `issues_register.md`, then your ruling log, then the canon, then `contracts/`. `scripts/governance.sh "<topic>"` retrieves over all five.
- **Emit:** `GOVERNANCE-CHECK: <topic> answered@<ref>` means do not raise or reopen: cite and close. `GOVERNANCE-CHECK: <topic> silent-or-contradictory` means raising is legitimate: attach what you read, at which HEAD.
- **Rule A:** no raise without the cite. **Rule B:** the receiving seat runs the same read first; re-deriving a settled design is forbidden.

## §PREMISE-CHECK · re-derive the premise before you work or route an inherited item (binding, ALL seats)

Re-deriving the EVIDENCE for an inherited claim is not re-deriving the CLAIM.
- **Trigger:** before you work or route any inherited item (a handoff item, a register issue, a carried next action, a "the door is X" claim not made this session).
- **Emit:** `PREMISE-CHECK: <item> premise-holds@<ref>` (still true at HEAD, with the one-decision-door test applied: only the operator can give it, so it goes to the operator; reversible, non-spending and non-custodial, so foundation executes) or `PREMISE-CHECK: <item> premise-refuted@<ref>`: do not work or route it; RETRACT (invariant 4).
- **The cheap question gates the expensive one:** *does this need doing?* before *does the mechanism work?*

## Seats (topology)

### The line every seat carries (canon §7.5, verbatim)
> One session = one seat. Credentials partition authority; only separate contexts partition cognition. You are an agent and you count in the census. A question about combining roles is answered coherence-first and treated as a challenge to re-derive, never a ruling to defend.

- **orc** (`.claude/agents/orc.md`): role-neutral; identity and authority come from the worktree. In the `foundation` worktree it is the integrator: sole spine committer and routing hub. In a module worktree it is that lane's writer (§0).
- **architect** (`.claude/agents/architect.md`): HOW-class. It rules on contracts, interfaces and framework questions; it brings the operator one decision at a time; it records the operator's words verbatim; it reads at HEAD; it never commits to the spine and never executes mechanisms. One architect session at a time.

## Binding invariants (load-bearing; violation = halt)

The full text of each is in `.claude/rules/engine/invariants.md`. **Numbering:** the numbers below and every "invariant N" in this file are the engine's own labels (`inv#1`, `inv#4`, `inv#5` in that file). Canon §2 numbers the same rules 1 LIVE-DATA-ONLY, 2 LEAST-PRIVILEGE-WRITER, 3 NO FAKE CLOSURES and 4 HALT-LOUD, with ONE-SESSION-ONE-SEAT as the fifth. So "invariant 4" here is no fake closures, canon §2's third. Your project's own invariants are in `docs/FOUNDATION.md`.

1. **LIVE-DATA-ONLY**: no hand-inserted smoke or bypass path; all validation runs through the canonical path.
4. **No fake closures**: status is a hypothesis; close only on evidence a probe can re-run; RETRACT on a refuted premise.
5. **Halt-loud over silent-degradation**: halt with a named reason; no fallback, no silent default, no degraded continue.

**LEAST-PRIVILEGE-WRITER** also binds: the identity agents run under is read-only against the substrate by default, and a standing probe verifies it.

## Discipline (process)

1. **Verify load-bearing technical facts against live documentation**, not memory.
2. **Lane separation.** Prose to the operator; structured relays between seats. Never route plumbing to the operator. **Operator communication:** a terse correction carries full weight; derive and execute. No option menus. The operator's door carries ONE sequenced WHAT-class decision (DISC-ONE-DECISION-DOOR).
3. **Prior art first:** before authoring or diagnosing, search `disciplines.md`, `issues_register.md` and `_orchestration/decision-log.md`. Live diagnosis confirms the check; it does not replace it.
4. **Lane comms:** each lane commits outbound relays to its own `relay-outbox/<lane>/`; foundation drops inbound to `relay-inbox/<lane>/` on the spine. No seat writes inside another seat's territory.
5. **LLM at the edges:** an LLM is used only for content generation and temporary judgment over unstructured evidence; everything else is code (DISC-LLM-AT-THE-EDGES).
6. **Cost:** no new billable resource without an impact review and the operator's sign-off (DISC-NEW-INFRA-IMPACT-REVIEW); runtime caps are your slots in `contracts/COST-CAPS.md`; estimate cost before authorizing recurring automation.
7. **No deferral except behind a hard dependency.** A hard dependency is named and checkable; drive the blocker now.

## Auditor

A post-commit hook (`agents/post-commit-hook.sh`) audits every commit: file-state assertions and standing probes. Receipts go to `ledger/receipts.jsonl`, findings to `ledger/audit-findings.md`, liveness to `ledger/audit-runs.log`.

## Command shape (binding, ALL execution seats)

The harness splits a compound command at `&&`, `||`, `;`, `|`, `&` and newlines, and judges each part on its own; a compound passes only when every part passes. (1) Never prefix `cd`. (2) Write scratch files with the Write tool, never a heredoc. (3) One `scripts/*` invocation per command, with no `&&`, `||` or `;`; read-only post-filters are fine. The permission hook (`scripts/greenlight-policy.sh`) then approves; only human-class actions prompt.

## Reference

The live document set: the canon (`GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_9.md`; cite the edition) · `ENGINE-MAP.md` (every file and what it does) · `docs/FOUNDATION.md` · `SLOTS.md` · `contracts/` (`contracts/CONSTANTS.md` among them) · `_knowledge/COORDINATION.md` · `disciplines.md` · `.claude/rules/engine/invariants.md`.
