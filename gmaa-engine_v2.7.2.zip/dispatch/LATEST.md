# LATEST: the hub's handoff

Foundation keeps this file current: what was just done, what is next, and what is waiting on whom. A seat that ends or restarts writes its state here first (`CLAUDE.md` §7), so the next session boots from the record, not from memory.

## NOW
(fill: the current work and its state)

## NEXT
(fill: the next work, in order. The first line under this heading is either a numbered item, `1.` and the work, or one line starting `NAMED-WAIT: ` that names what is awaited and from whom. `scripts/seat-exit.sh` and the Stop hook read the first `## NEXT` heading in this file, and a seat cannot end itself while it holds neither form.)
