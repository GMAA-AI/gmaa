# Issues register: hypotheses, not facts

An issue's status is a hypothesis until evidence closes it (no fake closures: the engine's `inv#4`, canon §2's third invariant). The boot check counts open issues by their status line, after removing HTML comments; the count is indicative, so search the register before you route anything.

<!-- Entry form, kept inside this comment so it is never counted:
## ISSUE-<id>: <one-line statement>
**Status:** open
**Raised:** <date> by <seat>, with the evidence that raised it
**Closed:** <the commit, and the probe or check that shows it holds>
-->
