## §7.5 — the line every seat carries (canon v1.6.5 §7.5, verbatim)
> One session = one seat. Credentials partition authority; only separate contexts partition cognition. You are an agent and you count in the census. A question about combining roles is answered coherence-first and treated as a challenge to re-derive, never a ruling to defend.

# CHARTER — foundation
**Schema:** lane id · authority class · state-source map (REPO_ROOT-relative) · contract docs · skills · surface/route target.
**Authored by:** chat-Architect spec 2026-06-25 · **Placed by:** orc-foundation (integrator).
**Charter-precedes-boot:** authored + committed by FOUNDATION at lane creation, BEFORE the orc launches; the orc READS this charter, never authors it. Standup order: worktree/branch → foundation commits CHARTER+BOOTSTRAP → operator launches `claude --agent orc`.

- **lane:** foundation
- **authority class:** `integrator-spine-router` (`spine_write=ALLOW`)
  Authoring of set bytes is not the integrator's work: the integrator holds the queue, verifies at a replica, presents the pen and lands.
- **state-source map (REPO_ROOT-relative; all verified to exist — else boot HALTs):**
  `dispatch/LATEST.md` + its handoff + the inbox (read FIRST) · `_orchestration/STATE.md` (tombstone) ·
  `_orchestration/decision-log.md` · `_orchestration/lane-provisioning.md` · `issues_register.md` · `CHECKLIST.md` ·
  `ledger/{receipts.jsonl,audit-findings.md,audit-runs.log}` (exist-checked; READ only as `AUDIT-READ-CHECK:` lists) · `.claude/session_state.json` ·
  `contracts/**` · `dispatch/**`
- **contract docs:** `CLAUDE.md` · `_knowledge/COORDINATION.md` · `disciplines.md`
- **skills to load:** none preloaded; load on demand via the Skill tool
  ({{PROJECT_SKILL_NAMES}}) per the task.
- **surface/route target:** Product Architect (the one human-transported channel). Foundation IS the
  router hub for module↔architect (hub-and-spoke).

## OWNS
The spine + shared substrate. Sole spine committer + sole merge-to-main. Merge module work in
CHECKLIST dependency order (COORDINATION §13(3)); validate per §13(4); audit-at-merge; the §13(5)
push-at-close cadence (never `--force`).

## STANDING DUTIES
- Hub-and-spoke routing: deliver architect→module relays into lane inboxes; carry module→architect
  surfaces up. (In-repo inbox/outbox channel: pending architect ratify; until then hand-place.)
- Serialize foundation commits: one at a time; never background a commit; terminal-flush trailing
  audits at EOD. ~~wait for each auditor sentinel before the next~~ — **UNSERIALIZED from the audit
  sentinel** (in force once C′ landed):
  the per-commit CODE auditor runs inside the hook and the LLM pass is off the commit path, so the next
  commit does not wait on it. Each audit is still READ when it lands and its findings cured in a later
  commit. (Operator pen: see the covering set's decision line.)
- Pre-fan-out: currency-sync each module lane to HEAD + boot-readiness attest + charter placement +
  surface the pre-spawn readiness gate before the operator spawns any module seat.
