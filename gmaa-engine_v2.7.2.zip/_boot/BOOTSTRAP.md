---
lane: (fill: this worktree's lane name, equal to its folder name)
role: (fill: integrator for foundation; this lane's role class otherwise)
bootstrap_version: (fill: a version string for this stamp, raised whenever the stamp changes)
spine_write: (fill: ALLOW for foundation only; DENY for every other lane)
worktree_branch: (fill: the branch this worktree has checked out; main for foundation)
project: (fill: your project token, lowercase letters, digits and hyphens only)
handoff: (fill: the path of this lane's handoff surface; dispatch/LATEST.md for foundation)
---
# BOOTSTRAP: this worktree's identity stamp

Every worktree carries its own copy of this file, filled for that worktree and committed in the set that provisions the seat, before the seat is ever launched (canon §7.1, §7.2). A seat reads its identity from here at every boot (`scripts/resolve-lane.sh`), never from chat.

**The keys above** are read from the front matter only:
- `lane` must equal the worktree's folder name. On a `module/<x>` branch it must be `<x>`.
- `worktree_branch` must equal the branch this worktree has checked out, or the seat halts.
- `spine_write: ALLOW` is valid only on the trunk branch, and only foundation carries it.
- `project` names the project on this machine; the seat's tmux session is `<project>-<lane>`. It is required, and a malformed value halts the launcher.
- `handoff` names the file or folder where this seat writes its handoff before it ends itself. `scripts/seat-exit.sh` refuses a restart or shutdown while the key is absent, and the Stop hook reads the same surface.

**Optional keys** you may add to the front matter: `account: <name>` runs this seat's sessions under `$HOME/.claude-<name>` (lowercase letters, digits and hyphens; the directory must already exist and be logged in); `remote_control:` is read by the launcher when present.

**The line every seat carries** (canon §7.5). A seat reads this stamp first at a cold boot, so the stamp carries the line word for word, and `probes/governance/probe_seat_line_75_v1.sh` checks that it does:

> One session = one seat. Credentials partition authority; only separate contexts partition cognition. You are an agent and you count in the census. A question about combining roles is answered coherence-first and treated as a challenge to re-derive, never a ruling to defend.

An unfilled stamp halts the seat. That is correct: fill it, commit it, then launch.
