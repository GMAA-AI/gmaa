# Lane Provisioning Manifest

Spine-owned, integrator-written (COORDINATION.md §13(1)). Cold-boot identity
provisioning per §13(2): each lane's seat resolves identity from its worktree
`_boot/BOOTSTRAP.md` via `scripts/resolve-lane.sh` and emits
`BOOT-ACK: lane=… version=… blob=…`. Foundation confirms the right seat loaded by
matching the ack against the row below. The `blob` is `git hash-object` of that
lane's `_boot/BOOTSTRAP.md` (content-addressed; integrity-evident).
| lane | branch | bootstrap_version | spine_write | blob (git hash-object) | provisioned_utc | operator |
|------|------|------|------|------|------|------|
| | | | | | | |
