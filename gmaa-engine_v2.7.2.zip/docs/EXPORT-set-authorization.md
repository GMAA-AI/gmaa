# Set authorization: the architecture, its enforcement and how to prove it

This note is a reading guide to set authorization in this engine. The binding text is `contracts/C-SET-AUTHORIZATION.md` (the spec of record) and `contracts/C-RATIFICATION-PACKET.md` (the packet). Where this note and those two files differ, the files govern.

## 1. The thesis
**The unit of authorization is the set, not the change.** Review one change at a time and each change is judged alone: the joint evaluation never runs, and an incoherence in how members interact reaches the trunk unseen. Serial transport, one commit at a time, hides the set but does not dissolve it. Set authorization evaluates the whole set at the apply boundary, on top of per-change review and never in place of it.

## 2. The round trip
```
DOWN  architect: spec with explicit acceptance criteria
      foundation: determines the set, dispatches work packages
      lanes: each executes its own work package on its own branch
UP    lanes: submit
      foundation: assembles the set, runs (A) coherence and (B) conformance
        both pass  -> foundation asks -> operator authorizes (--by) -> foundation alone writes and reaps the whole set
        any fails  -> the owning lane redoes it -> unresolved -> architect -> (operator) -> back down
```
- Foundation determines the set. Membership is never a lane nominating itself.
- **The set's boundary is the requirement**, never effort or lane count. One lane with work and no other is the set. A requirement spread over two or more lanes is one all-or-nothing set. Foundation may not stagger one requirement into isolated work packages to make sets smaller: the declared footprint (section 5) binds this.
- Both checks are required. The architect assesses and adjudicates. The architect never carries the operator's pen, and never writes the record.

## 3. The packet
One file per set, under `_ratification/`, written only by foundation. Its sections, per `contracts/C-RATIFICATION-PACKET.md` §2:
- the HEADER;
- the MEMBERS;
- the CONFLICT SWEEP ("none found" is a claim that needs its sweep receipt);
- the COHERENCE CHECKS (only checks that make sense on the joint set);
- the BRIEFING, with grounded alternatives for a contested member;
- exactly one operator DECISION LINE, with its rationale class;
- the POST-DECISION record.

The decision is one of five, and never a bare no: **RATIFIED · RATIFIED-WITH-SEQUENCE · AMENDED · HELD** (parked against a named trigger) **· REJECTED.** An AMENDED set is a new set (the SUBSET RULE). Returned work reaches main only inside a later ratified set (NO-CHERRY-PICK).

## 4. The tooling
- `scripts/pending-set.sh` mints a requirement's set and writes member entries.
- `scripts/ratify.sh` is the state machine over the packet:
  - `assemble --cures <ids>|none` computes the mechanical joint edges and writes the packet;
  - `assess` takes foundation's assessment, which comes before the pen;
  - `conformance-check` and `conformance` record each member's verdict;
  - `hunt` records the semantic hunt: how foundation looked for an incoherence the mechanical edges cannot see, and its verdict;
  - `ratify --by '<operator>' --rationale-class in-band|OUT-OF-BAND` stamps the decision.

  Each verb after `assemble` takes the set id, `SET-NNNN`. The full flags are in the header of `scripts/ratify.sh`, and `docs/ENGINE-UPDATE.md` B6 writes out each line. `ratify` refuses on an empty assessment, on an empty or unresolved semantic hunt, on an unresolved joint edge, and on any member verdict of FAIL or MISSING. There is no override.
- `ratify --standing-class` is the one pen-free close: it covers a build-class set that passes `scripts/build-class-check.sh` live, under the operator's standing class grant (`contracts/SPEC-BUILD-CLASS-STANDING-APPROVAL.md`).
- `scripts/reap_at_merge.sh <module-lane>` lands a module lane's ratified members.

## 5. The gates (each fails closed)
| Leg | Where it is enforced |
|---|---|
| A module lane proposes and never commits the spine | `agents/pre-commit-hook.sh`, module-DENY |
| Every spine path foundation stages is covered by a ratified, unconsumed set | `agents/pre-commit-hook.sh` (coverage lapses once the set's members commit) |
| Coherence: mechanical joint edges, a shared-record edge, and a required semantic-hunt block | `scripts/ratify.sh` |
| Conformance: each member against its work package's machine-checkable criteria | `scripts/ratify.sh conformance-check` |
| Footprint: the assembled lanes cover the requirement's declared lanes, else `HALT: FOOTPRINT-MISS` | `scripts/ratify.sh assemble` |
| No cherry-pick: a branch that is not a ratified member never reaches the merge tree | `scripts/reap_at_merge.sh` |
| Forced merge path: a trunk merge without the reap sentinel is rejected | `agents/pre-merge-commit-hook.sh` |
| Every commit a push carries is signed by its lane's key | `agents/pre-push-hook.sh` |
| The installed hooks are the shipped ones | `scripts/boot-check.sh`, hook currency |

**Disclosed residue, not a hole:** a fast-forward merge creates no merge commit, so no merge hook fires. It cannot happen while the reap stays `--no-ff`. Setting `merge.ff=false` as a belt is rejected, because it would send the routine fast-forward sync into the reject path. The structural close is tracked forward. **The cost brake** (`scripts/cost-guard.sh`) is wired but does not yet stop spend: it exits 3 by name until you supply its usage reader, `scripts/cost-usage-reader.sh` (see `SLOTS.md`).

## 6. Definition of done, and the biting proof
A set-authorization capability is done only when it bites on real data (`contracts/C-SET-AUTHORIZATION.md` §6):
- **A:** real lanes and proposals, with no synthetic member.
- **B:** the real substrate, through the canonical path.
- **C:** both polarities, live, against the installed gate:
  - a covered member lands through the same gate that refused it while it was uncovered;
  - a real violation is rejected by a normal commit or merge, never a bypass. The gate exits non-zero, HEAD is unchanged and the tree is clean.
- **D:** provenance travels. Each rejection leaves a receipt naming the lane, the path, the gate, the rule and the verbatim stderr, and real shas throughout.

The planted-fault probes under `probes/set-gate/` are the engine's own proofs that these gates can fail. Run them after any change to a gate.

## 7. Roles
- **Architect:** writes the spec and its acceptance criteria, assesses the biting proof, adjudicates escalations. Executes no mechanism, carries no pen, writes no record.
- **Foundation:** decomposes the work, mints the set, assembles and assesses, asks for the decision, and is the only writer of the record and the only reaper.
- **Lanes:** each executes its own work package on its own branch, and proposes spine changes through the reap path.
- **Operator:** holds the one pen, after the assessment.

`docs/examples/escalation-003.md` walks one escalation through this flow.
