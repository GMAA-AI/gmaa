# Worked example: a lane reaches an authorization boundary it cannot resolve

> A neutral case study, with placeholder names throughout. It shows the **shape** of an escalation when a module lane reaches a coherence boundary it cannot resolve on its own. It is not an incident report.

## Context
A project runs three lanes:
- `foundation`: the integrator, the only lane that commits to the spine, and the routing hub.
- `module-a`: a module lane, `spine_write: DENY` in its `_boot/BOOTSTRAP.md`. It works on its own branch.
- `module-b`: a second module lane, with the same write boundary.

The set rule (canon §4; `contracts/C-RATIFICATION-PACKET.md`): changes that touch a shared object clear a joint check, as one set, before any member merges. No lane can authorize its own merge of something another lane reads.

## What happened
`module-a` finished a work package, `WP-A-07`, which changed a shared interface that `module-b` also reads. Its own checks were clean, so `module-a` declared it as a member with `scripts/pending-set.sh member`.

Foundation assembled the set (`scripts/ratify.sh assemble SET-NNNN --requirement-id REQ-<id> --cures none`). The packet's COHERENCE CHECKS section (`contracts/C-RATIFICATION-PACKET.md` §2) showed the conflict: `module-b` had an in-flight work package, `WP-B-03`, whose branch assumed the old shape of the interface.

**Why `module-a` could not resolve it alone:**
- `spine_write: DENY` means it cannot merge itself.
- The joint check is a set-level evaluation. It needs `module-b`'s in-flight branch, which `module-a` does not author.
- Marking its own member ratified on the strength of its own clean audit would bypass the boundary. Line-item ratification does not exist (§5, SUBSET RULE).

## The escalation path
```
module-a    declares WP-A-07 as a member (branch@<sha>, receipts attached)
            notes: "touches a shared interface; a joint check is needed"

foundation  assembles SET-NNNN: members WP-A-07 (module-a) and WP-B-03 (module-b, in flight)
            the conflict sweep confirms the contradiction
            BRIEFING: two grounded alternatives (below)
            routes to the architect: the conflict is a HOW-class call (the shape of an interface),
            not a go or no-go

architect   reads both branches at their heads
            rules alternative (b); rationale class in-band (resolvable from the record)

foundation  writes the ruling into the packet's assessment (ratify.sh assess SET-NNNN --file <assessment>)

operator    signs the DECISION LINE: AMENDED
            (ratify.sh ratify SET-NNNN --by '<operator>' --rationale-class in-band --decision AMENDED)
            WP-A-07 is retained; WP-B-03 goes back to module-b

foundation  relays the return to module-b's inbox and rings its doorbell
            (the producer-ring obligation, contracts/SPEC-DOORBELL.md §2)
            the AMENDED set is a new set: WP-A-07 re-enters assembly and joint
            re-validation before it merges
```

## The alternatives briefed
- **(a) Hold both.** Park the set until `WP-B-03` finishes against the old interface, then rebuild `WP-A-07` against the joint shape. Two work packages blocked, and the change to the shared object is delayed.
- **(b) Shim, then sequence.** Merge `WP-A-07` with a compatibility shim that keeps the old shape beside the new one for one release cycle. Return `WP-B-03` to `module-b`, to re-author against the new interface. One time-bounded shim, one re-author pass, and no hold on `WP-A-07`.

The architect chose (b).

## The properties this exercised
| Property | Where it fired |
|---|---|
| Authorization is by set, not by member | `contracts/C-RATIFICATION-PACKET.md` §1: no member merges until its set's packet carries a decision |
| SUBSET RULE | §5: the AMENDED set is a new set, and its retained member is re-validated jointly |
| NO-CHERRY-PICK | §5: the returned `WP-B-03` reaches main only inside a future ratified set |
| LOOP GUARD | §5: if the same set is returned twice, the architect is escalated automatically |
| INDEPENDENCE | §5: foundation assembled and validated, the operator ratified, and the auditor reproduces after the merge |
| The ring completes the relay | `contracts/SPEC-DOORBELL.md` §2: foundation's return to `module-b` is not complete until the bell rings |

## What it does not show
- The content of the interface. That is left out on purpose.
- Any real project's domain, tooling or substrate.
- An out-of-band decision, one whose deciding fact lives outside the record (a cutover, a hold, a commitment; §4). This conflict was in-band, so the architect ruled the HOW and the operator signed the decision line.

*Adapt the lane names, work-package ids and objects to your own project.*
