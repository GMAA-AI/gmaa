# CHARTER: <seat> (a skeleton; copy to `_boot/CHARTER-<seat>.md` and fill every "(fill: ...)")
**Schema:** lane id · authority class · state-source map (REPO_ROOT-relative) · contract docs · skills · surface/route target. The shape is the shipped `_boot/CHARTER-foundation.md`'s; keep the bullet labels exactly, since `scripts/boot-check.sh` parses the state-source map by its heading (a line that starts `- **state-source map`), reads every path it names, and halts the seat's boot on any path that does not exist.
**Authored by:** (fill: the chat architect, with the date) · **Placed by:** you, into `foundation/_boot/`, before the seat is provisioned. `bash genesis.sh lane <seat>` refuses to run without it, and commits it inside the seat's provisioning set (canon §7.2).
**Charter-precedes-boot:** the seat reads this charter at every boot and never authors it. Copy the §7.5 line every seat carries from `_boot/CHARTER-foundation.md`, verbatim, above this schema line.

- **lane:** (fill: the seat name, equal to its worktree folder and its `seats.yaml` entry)
- **authority class:** (fill: the class token from `contracts/LAUNCH-CONTRACT.md`: `integrator-spine-router` for foundation, `execution-apply-receipt-writer` for the executor, whose stamp carries `spine_write: apply-receipts-only`, and `module-single-writer` for a lane, whose stamp carries `spine_write: DENY`)
  (fill: one sentence on what this class does and does not do)
- **state-source map (REPO_ROOT-relative; every path must exist in this tree, else boot HALTs):**
  `dispatch/LATEST.md` + its handoff + the inbox (read FIRST) ·
  `_orchestration/decision-log.md` · `_orchestration/lane-provisioning.md` · `issues_register.md` · `CHECKLIST.md` ·
  `contracts/**` · `dispatch/**`
  (add only paths that exist; name no file the engine has retired)
- **contract docs:** `CLAUDE.md` · `_knowledge/COORDINATION.md` · `disciplines.md`
- **skills to load:** none preloaded; load on demand via the Skill tool per the task.
- **surface/route target:** (fill: foundation, the hub, for a lane; the operator's channel for foundation)

## CORE READ
(`CLAUDE.md`, Core read: end to end before the seat's first act) the canon · `ENGINE-MAP.md` · `CLAUDE.md` · `.claude/rules/engine/invariants.md` · `disciplines.md` · `_knowledge/COORDINATION.md` · this charter and `_boot/BOOTSTRAP.md`; then, by role, keep the one line that is this seat's and delete the others:
  foundation: `contracts/MECH-WRITE.md` · `contracts/C-SET-AUTHORIZATION.md` · `contracts/C-RATIFICATION-PACKET.md` · `contracts/LAUNCH-CONTRACT.md` · `contracts/SPEC-DOORBELL.md` · `_index/engine-paths.tsv` · the genesis section of `ADOPTION-COVER.md`
  lane or executor: `contracts/MECH-WRITE.md` · `contracts/SPEC-DOORBELL.md` · `contracts/C-SET-AUTHORIZATION.md`

## OWNS
(fill: the seat's territory in one sentence, as `seats.yaml` and `_orchestration/lane-provisioning.md` state it; a lane commits only outside the spine paths; the executor commits only under `ledger/apply-receipts/` and its own restart row `ledger/restarts/<lane>.tsv`, and every build it makes, whatever path it touches, travels there as a patch foundation lands)

## STANDING DUTIES
(fill: the duties this seat performs every session, one line each: the inbox read first, the work, the outbox relay, the close)

## NEVER
(fill: what this class never does; for a lane: never commits to the spine, never carries rulings, never widens its own credentials)
