# OPERATING-DISCIPLINE: completion, verification and state that survives a restart

> **The throughline.** Every claim of progress must reduce to something a command can confirm. The goal and the state must live in files a seat reloads, not in a context window it loses. Give the work that scaffold and it drives to completion. Withhold it, and no amount of prompting to "be disciplined" will hold.

This note is the working form of two binding invariants in `.claude/rules/engine/invariants.md`: **inv#4, No fake closures**, and **inv#5, Halt-loud over silent-degradation**. It applies to every seat, the auditor included. No seat is exempt.

## Completion: what "done" means
A task is complete only when a named command exits 0 and its output appears in the report. The words *done*, *working*, *fixed*, *passing*, *complete*, *shipped* and *closed* are void unless the command and its exit status stand beside them. A success claim with no command behind it is a fake closure.

**Bind your project's commands here** (a fill; the engine rows are already wired):

| Class | Command | Passes when |
|---|---|---|
| Build or typecheck | (fill: your build command) | exit 0 |
| Tests | (fill: your test runner) | exit 0 |
| Standing probes | each entry in `agents/standing-probes.yaml` | exit 0 and its pass signal |
| Boot state | `bash scripts/boot-check.sh` | its lines read clean for this lane |
| Commit audit | runs on every commit (`agents/post-commit-hook.sh`) | a receipt in `ledger/receipts.jsonl`, no new finding in `ledger/audit-findings.md` |
| Issue closure | the entry in `issues_register.md` | its evidence is enumerated (a commit sha, a receipt, a probe run), not asserted |

A claim that reduces to none of these is a hypothesis, and is labelled as one. Reporting an unverified change as finished is the most expensive failure mode there is.

## Verification at the end of a turn
The engine wires two Stop hooks in `.claude/settings.json`: `scripts/creed-scan-spine.sh`, which runs the spine's creed scan at the boundary, and `scripts/seat-b6-stop.sh`. **Neither runs your build or test suite.** A Stop hook that runs your suite and blocks the turn while it is red is yours to wire against your own commands. Until you wire it and have seen it block, do not cite it as enforcement: a stated gate is not a gate.

The post-commit auditor guards what has already landed in git. A verification hook guards what a seat may call finished. They are not redundant.

## State that survives a restart
Context windows are lost; disk is not. Anything that must outlive the current window lives in a file, and those files are read at the start of every session, before the first action.

**Read first, every session:**
1. `CLAUDE.md`, the operating contract;
2. `_boot/BOOTSTRAP.md`, this worktree's identity;
3. the inbox: `scripts/inbox.sh` (`scripts/inboxf.sh` for foundation);
4. `CHECKLIST.md`, what ships next, and its `absorbed_through_sha:`;
5. `issues_register.md`, so that no settled decision is re-raised;
6. the lane's handoff surface named by `handoff:` in its bootstrap (`dispatch/LATEST.md` for foundation).

**Write as you work:**
- a finding, risk or discipline breach goes in `issues_register.md`, not in chat;
- a relay to another seat goes in your own `relay-outbox/<lane>/`, and foundation drops inbound relays on the spine;
- before you end, write your handoff to the surface your bootstrap names (`scripts/seat-exit.sh` refuses a restart or shutdown while the `handoff:` key is absent).

**The rule.** What is not in a committed file does not persist, and is not assumed across sessions. A claim made in chat that never landed in a file dies with the window.

## How the invariants bind
- **inv#4, No fake closures:** the completion rule above, the commit audit, and a verification hook once you wire one. A refuted premise is retracted, never quietly marked fixed.
- **inv#5, Halt-loud over silent-degradation:** the read-first list surfaces a missing or stale input at session start. A probe that cannot read its input prints UNREADABLE by name; it is not retried until it goes quiet.
- **inv#1, LIVE-DATA-ONLY:** every pass condition above is a real command against the real system, never a described one.
- **LEAST-PRIVILEGE-WRITER:** the identity agents run under is read-only against your substrate by default. The standing probe that verifies it is yours to supply.
