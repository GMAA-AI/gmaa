# ENGINE-UPDATE: moving an adopted project to a new engine release

Foundation runs this runbook. The update is a change to your project like any other, so it lands only inside a set your apex ratifier ratifies. **2.7 ships no update classifier.** The steps below are manual: each one names the files to compare and the shipped command to run. Never overwrite a file you have not classified, and never resolve a moved slot on your own.

If you are moving from v2.5.7 or v2.6, read `CHANGELOG.md` first. v2.7 is a new extraction, not a patch: the v2.5.7 slots are retired, and a v2.5.7 fill does not carry over.

## B0 · Check every lane's stamp, before anything propagates
For each lane worktree `<wt>`, run:
- `scripts/resolve-project.sh <wt>`. It must exit 0. It halts with exit 2, naming the reason, when `project:` in `<wt>/_boot/BOOTSTRAP.md` is absent or malformed.
- `scripts/resolve-lane.sh`, from inside `<wt>`. It must exit 0. Exit 3 means the lane is unresolved, or its stamp and its branch disagree.

A lane that fails either check gets nothing from this update until its stamp is fixed. Propagating onto an unstamped lane fails silently on every such lane, so this check always comes first.

## B1 · Verify the new release
Beside the new zip, `shasum -a 256 -c SHA256SUMS` must print OK for every file. Inside the unzipped release, `shasum -a 256 -c MANIFEST.sha256` must print OK for every row. A release you cannot verify is a stop.

## B2 · Classify every path, by hand
You need three things: the old release's `MANIFEST.sha256` and `PROVENANCE.tsv`, the new release's copies of the same two files, and your project tree. For each path in either manifest:

| The path is | And | Class | Action |
|---|---|---|---|
| in both manifests, hashes equal | | UNCHANGED | nothing to do |
| in both, hashes differ | your file equals the OLD hash | ENGINE-DELTA | take the new file |
| in both, hashes differ | your file differs from the OLD hash, and the path carries a slot listed in `SLOTS.md` or `_index/adopter-slots.tsv` | PRESERVE-FILL | take the new file, then re-apply your fill, if the slot's contract is unchanged (B3) |
| in both, hashes differ | your file differs from the OLD hash, and the path is a `package` row in `PROVENANCE.tsv` (a skeleton you filled) | PRESERVE-GENERATED | keep yours; read the new skeleton for anything new it asks for |
| in both, hashes differ | any other case where your file differs from the OLD hash | CONFLICT | foundation rules on the file before anything is applied; never overwrite it |
| only in the NEW manifest | | ADDED | take the new file |
| only in the OLD manifest | | REMOVED | the new `CHANGELOG.md` says why; remove it only inside the set (B6) |

Some files are in no manifest: the records your own operation creates, for example `seats.yaml`, `_rulings/`, `PENDING-SET.md`, the ledger files and the relay and dispatch folders. `_index/engine-paths.tsv` lists the ones the engine reads or writes. Never touch them in an update.

To list the paths whose hash changed, run this in a directory holding both manifests, the old one saved as old.sha256 and the new one as new.sha256:

```
join -1 2 -2 2 <(sort -k2 old.sha256) <(sort -k2 new.sha256) | awk '$2 != $3 {print $1}'
```

## B3 · Stop on a moved slot
Read the new `CHANGELOG.md` entry for a heading named exactly `Slot-contract changes`. If a slot you have filled is listed there, **halt the update**. Take the old contract line, the new one and your fill to your operator. The update resumes only on that ruling. If the heading is absent, every existing fill keeps working.

## B4 · Prove the updated tree
Run these on the tree with the update applied, before anything propagates:
- `bash scripts/boot-check.sh`;
- every probe in `agents/standing-probes.yaml`. The set-gate probes under `probes/set-gate/` are the engine's seeded-fault tests: each plants its own fault and must see it caught.

Any red stops the update here. Never propagate a tree you cannot prove.

## B5 · Propagate, lane by lane
From inside each module lane's worktree, run `scripts/lane_currency_gate.sh`. It refuses to run on the foundation lane. Re-run B0 for each lane at this point: a lane provisioned after B0 gets no free pass. After each sync, read back the lane's HEAD.

## B6 · The update rides a ratified set
The changed files are the members. Run each line from foundation's worktree. `REQ-<id>` is a requirement id you choose for the update, and `SET-NNNN` is the id that `mint` prints:
1. `scripts/pending-set.sh mint REQ-<id> --footprint-lanes '<every lane the update touches>'`. It prints the set's `SET-NNNN`.
2. For each member: `scripts/pending-set.sh member <member-id> --requirement-id REQ-<id> --set-id SET-NNNN --intent '<what it changes>' --surfaces '<its paths>'`, then `scripts/pending-set.sh reap _orchestration/relay-outbox/foundation/SET-MEMBER-<member-id>.md`.
3. `scripts/ratify.sh assemble SET-NNNN --requirement-id REQ-<id> --cures none`.
4. `scripts/ratify.sh assess SET-NNNN --file <your assessment>` (or `--text '...'`).
5. For each member: `scripts/ratify.sh conformance-check SET-NNNN <member-id>`. For a criterion only judgment can grade, record the verdict with `scripts/ratify.sh conformance SET-NNNN <member-id> --verdict PASS|FAIL --method judgment --evidence '...'`.
6. `scripts/ratify.sh hunt SET-NNNN --method '<how you hunted>' --candidates '<what you checked>' --residual '<what is left>' --verdict CLEAR`. `ratify` refuses while this section of the packet is empty.
7. `scripts/ratify.sh ratify SET-NNNN --by '<your apex ratifier>' --rationale-class in-band --decision RATIFIED`, the operator's pen.
8. Members commit under the set. `scripts/reap_at_merge.sh <module-lane>` lands a lane's members.

The full flags of each verb are in the header of its script. No member commits before the decision line. The pre-commit hook refuses a foundation commit that stages a spine path no ratified set covers.

*A later release may ship a classifier that does B2 mechanically. Until one ships, B2 is this table, applied by foundation and recorded in the set's assessment.*
