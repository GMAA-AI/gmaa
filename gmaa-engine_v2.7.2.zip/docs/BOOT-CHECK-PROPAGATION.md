# BOOT-CHECK propagation: how the boot gate reaches every lane, and stays there

The boot gate is one script that every lane runs at session start. This note says what its parts are, how each reaches a lane, and how to verify that it did.

## The gate's parts
1. **`scripts/boot-check.sh`**: one script for all lanes. It prints visible lines with live values, so a stale state shows on its face. Among them:
   - **CHECKLIST currency:** a live git delta from the `absorbed_through_sha:` marker in `CHECKLIST.md` to HEAD;
   - **hook currency:** whether the installed pre-commit hook is the shipped one;
   - **the boot record.**

   It exits 0, except on a boot-record halt or a seat-host halt (exit 3). Its warnings instruct; they do not stop the session.
2. **`.claude/settings.json`, `hooks.SessionStart`**: runs `scripts/boot-check.sh` at the start of every session, under `|| true`. Its presence is therefore enforced by the harness, not by the agent remembering.
3. **`scripts/resolve-lane.sh`**: resolves the lane from the worktree's `_boot/BOOTSTRAP.md` and cross-checks the stamp against the branch. It exits 3 when unresolved. A caller must not default to foundation on exit 3.
4. **The `absorbed_through_sha:` line in `CHECKLIST.md`**: the commit the lane has absorbed governance through. Foundation moves it deliberately, after reading the commits it covers.
5. **The lane's `_boot/BOOTSTRAP.md` stamp**: the identity that parts 1 and 3 read (`lane:` and the other front-matter keys).

## Parts 1 to 4 reach a lane only by currency sync
Parts 1 to 4 are spine files. They reach a module lane only through `scripts/lane_currency_gate.sh`, run inside that lane's worktree, with a read-back of the lane's HEAD. **Landing a commit on foundation is not landing it on every lane.** After any governance change, check each lane:
- (a) the change's commit is an ancestor of the lane's HEAD;
- (b) the pre-commit hook is installed, and `scripts/boot-check.sh` prints hook currency clean;
- (c) `scripts/boot-check.sh` is present and executable.

A fan-out you have not verified is the false green this gate exists to catch.

## Part 5 is not propagated by merge
`_boot/**` is lane-provisioning metadata, not module work. When `scripts/reap_at_merge.sh` merges a module lane, it restores foundation's own `_boot/**` after computing the merge tree, and `scripts/lane_currency_gate.sh` keeps the module's own `_boot/` when it syncs from the trunk. So each lane's stamp is written per lane at standup, when foundation writes that lane's charter and bootstrap.

## The `.gitignore` union rule
A currency sync adopts the trunk's version of every spine path. A lane's `.gitignore` is the exception: it union-merges, so a lane never loses its own ignore lines to the trunk's copy. The package ships this as `.gitattributes` (`.gitignore merge=union`), a built-in git merge driver that needs no per-clone setup. The six engine lines every `.gitignore` carries are a fill from `ADOPTION-COVER.md`.
