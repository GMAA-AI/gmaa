# FIELD-EVIDENCE, *(fill: your project's name)* (append-only; canon §4 "Field-evidence log")

Every project keeps an append-only log of thesis-relevant incidents. One entry per incident. Numbering is
project-prefixed: `<PREFIX>-E-nnn`, where `<PREFIX>` is your project's short prefix *(fill: it here)*. A PENDING entry is a claim, not evidence: ineligible for the canonical
ledger and for publication until its EVIDENCE resolves to receipts. Publication posture is per-entry and mandatory
(absent = internal).

| Field | Content |
|---|---|
| ID | `<PREFIX>-E-nnn` |
| DATE | ISO date |
| CLASS | Appendix A taxonomy class (canon) |
| INCIDENT | what happened, stated plainly |
| DETECTION | how it was caught (probe · auditor · operator · adopter report · seeded fault) |
| EVIDENCE | receipts: paths + shas + probe outputs; or `PENDING first HEAD` (greenfield convention) |
| LESSON / CURE | what changed, and where it landed (path + sha) |
| THESIS MAPPING | which invariant / mechanism it exercises |
| PUBLICATION | `internal` · `publishable` · `published:<ref>` |

**A seeded fault (canon §12 step 8) is one entry in two writes.**
- **Before the set is minted, sealed:** the ID, the DATE, `CLASS: seeded fault`, who planted it (the chat architect or the operator, never foundation), and `SEALED: sha256 <hash of the planter's description file>`. Write nothing else: not what the fault is, not which set or member carries it, and no member's hash. The planter writes the description (the set, the faulty member and the fault) in a file kept outside every seat's tree, and the sealed hash is that file's, so the seat that judges can neither read the answer nor find the member by hashing what it reaps.
- **After foundation has presented its packet, revealed:** the INCIDENT (the fault, now described), DETECTION (what the judging machinery printed, and whether it named the faulty member before the pen was presented), EVIDENCE (the packet's path and sha, the description file the planter now shows, and its sha256 recomputed and equal to the sealed one, which proves the description was fixed before the set was minted), and CAUGHT or MISSED. A miss is recorded as a miss. Genesis is not complete until a seeded fault is caught.

---

## Entries

*(none yet)*
