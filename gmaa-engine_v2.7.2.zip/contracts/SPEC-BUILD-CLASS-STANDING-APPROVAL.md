FROM: architect — AUTHORED CONTRACT (foundation lands verbatim at `contracts/SPEC-BUILD-CLASS-STANDING-APPROVAL.md`)
BASIS: the standing-approval-class ruling · canon §10 (standing-approval classes) · §5 INDEPENDENCE · §9
CUSTODY: architect authors (this file) · foundation builds the gate check + lands · operator ratifies the CLASS (activation)
STATUS: **RATIFIED + ACTIVE** (operator, 2026-09-16T13:43:32Z — see §5). Foundation may close build-class
sets (P1–P4 PASS) under this class without a per-set operator pen, once the §3 gate check is built (AC-B1–B4).

# SPEC-BUILD-CLASS-STANDING-APPROVAL — the checkable predicate for a build-class set (v0.4)
> VERSION: v0.4 (2026-09-16) — **AC-B7 frame made implementation-binding**:
> resolution MUST be evaluated at committed HEAD, never the index; + the closing trailer corrected v0.2→v0.4
> (the fix-surface divergence — bumped at the header, not at the file end). **Rides
> the ARMING follow-on; does NOT re-land the scored SET-0021.** — v0.3 (2026-09-16) — **AC-B6 CONFORMED to
> shape (b)**:
> the `.tsv` is the SINGLE operative artifact, so AC-B6 becomes fail-closed
> parse-integrity of its operative rows — NOT a spec-prose pairing. The two-artifact pairing premise
> was dissolved by shape (b) when the second (spec-prose) operative enumeration was removed; the stale
> pairing text had lingered in §6 (AC-B7 was conformed, AC-B6 was not — a fix-surface
> divergence in this spec, caught by foundation reading §6 literally and refusing to build it). AC-B7
> unchanged. — v0.2 (2026-09-16) — P4 made property-based via `_index/authz-enforcers.tsv`.
> Supersedes v0.1 (four-document P4). Canon :325 — amendments by versioned
> revision only.

## §0 · Purpose + class
Canon §10 sanctions ruled standing-approval classes *"to keep the door from becoming a bottleneck — but
the class boundary is itself a ruled, versioned artifact."* This is that artifact for **build-class sets**.
It does NOT weaken §5 INDEPENDENCE: the ratifier of a set-commit is still an independent HUMAN — here the human authorizes the CLASS once, and the class ruling is the standing human authorization.
**No agent self-ratifies.** It resolves the problem named "a predicate I cannot write for myself": the
architect writes it, the operator ratifies it, the GATE checks it — never a seat's judgment about its own set.

## §1 · The predicate (mechanically checkable at assembly, footprint-based like §2.2)
A set is **BUILD-CLASS** IFF ALL of P1–P4 hold. Any failure ⇒ **operator pen required (WHAT-class)**.
> **OPERATIVE SOURCE:** P1/P2/P4 are enumerated as `rule`-tagged rows
> (`P1-ALLOW | P2-DENY | P4-ENFORCER`) in the ONE architect-authored file `_index/authz-enforcers.tsv` — the
> gate reads THAT, never this prose (which is the paired human ruling; AC-B6). **EVAL:** eligible IFF path
> matches a P1-ALLOW glob AND NO P2-DENY glob AND NO P4-ENFORCER path — **DENY (P2 ∪ P4) precedes ALLOW (P1)**
> (a carved-out file inside a P1 glob is NOT build-class). Set is build-class IFF EVERY member is eligible.
- **P1 · footprint ⊆ governance-plumbing allowlist** — every member touches ONLY:
  `scripts/** · agents/** · _index/** · probes/** · _orchestration/** · contracts/** · _rulings/** ·
  disciplines.md · ledger/** (non-authz records only)`. (The bare `standing-probes.yaml` was a phantom —
  REMOVED; the real runlist is denied in P2.)
- **P2 · touches NONE of the spend/custody/publish/data/authz surfaces** —
  `the data surface · the published surface · the lane stamps (declaring
  spine_write) · agents/standing-probes.yaml + _knowledge/standing-probes.yaml (the probe RUNLIST — an
  enforcement surface; a footprint gate cannot tell add from silent-remove, so runlist edits take the
  operator's pen) · credential/key material · cost/budget config · any publish-status /
  published-post surface · other data-surface writes`. (Writer-authz CODE surfaces = P4.)
- **P3 · no irreversible effect** — NO spend · NO custody transfer · NO irreversible-publish · the set is
  **revert-reversible** (a one-way migration, a publish, or any non-revertible act disqualifies).
- **P4 · anti-self-widening (the blank-check guard) — PROPERTY-BASED via a versioned manifest (v0.2, amended).**
  The set does NOT touch any path in the **AUTHORIZATION-ENFORCER
  MANIFEST** `_index/authz-enforcers.tsv` (declared, versioned, gate reads it as data — §3). The manifest
  enumerates the authorization model in BOTH its forms — **the DOCUMENTS** (`contracts/C-SET-AUTHORIZATION.md`
  · `contracts/C-RATIFICATION-PACKET.md` · THIS predicate file) **AND the EXECUTABLE ENFORCERS**
  (`scripts/resolve-lane.sh` — the writer-archetype resolver `pre-commit-hook` trusts via `eval` ·
  `agents/pre-commit-hook.sh` — the set-coverage gate incl. `set_consumed`/`set_exempt`/`SPINE_PATHS` ·
  `scripts/ratify.sh` — the ratification mechanism · `scripts/pending-set.sh` — the pending-set ledger
  writer · **the §3 build-class gate script itself, once built** · **the manifest file itself**). Any
  member touching a manifest path ⇒ **NOT build-class ⇒ operator pen.**
  (NOTE — the roster/writer authority does NOT live in a `seats.yaml` — that is canon's generic
  name (§7) with no such artifact. Writer-authority = `resolve-lane.sh` (resolver,
  in P1, listed) + `pre-commit-hook.sh` (enforcer, listed) + the per-lane `_boot/**` stamps that DECLARE
  `spine_write`, already protected by P1-EXCLUSION — `_boot/**` is not in the P1 allowlist, so a set
  touching a stamp fails P1 and is not build-class without needing a manifest row.)
  **Why property + manifest, not a fixed list:** the four-document list was the
  enumeration of the property *"does not modify the authorization model,"* and it was NARROWER than the
  property — *the documents are the map; the enforcers are the territory, and the gate reads the territory.*
  The manifest closes that gap AND is self-protecting: it is in its own excluded set, so **widening the
  manifest (adding/removing an enforcer) is itself NOT build-class and takes the operator's pen.** A new
  enforcer is onboarded by an operator-penned manifest edit — the class can never widen itself through the
  specs OR the enforcers OR the manifest.

## §2 · The flow when the predicate passes
`foundation assembles → [predicate P1–P4 verified at the gate] → NO per-set operator pen → auditor
reproduces post-merge.` Three-role separation (assemble / ratify / audit) intact; role-2 (ratify) is
discharged by the operator's standing CLASS ratification (§5), recorded once, versioned.

## §3 · The gate check (foundation-built; a mechanical predicate, fail-closed)
At assembly/pre-commit, evaluate P1–P4 over the set's declared footprint. **Fail-closed:** an unreadable
footprint, an undeclared occupant, or ANY P-failure ⇒ the set is NOT build-class ⇒ operator pen required.
The verdict is recorded in the packet (`build-class: PASS|FAIL` + which P failed) — a claim the auditor
reproduces. **A build-class PASS is a mechanical result, never an assembler assertion.**

## §4 · Honesty rider
Where a set does NOT pass (P-failure) and takes an operator pen, that pen is recorded as **authorization**;
it is NOT represented as independent review unless the operator states he reviewed the members. The
assembler's evidence remains the actual control (§5 INDEPENDENCE — the assembler validates).

## §5 · Activation — RATIFIED (operator grant, verbatim, DISC-DIRECTIVE-PROVENANCE)
**GRANT RECORDED — the class is ACTIVE.** Provenance chain, verbatim:
- Operator input (1), literal bytes: `"build class raאןכןקג"` — Hebrew-keyboard-garbled; read as
  ratification-intent, and NOT recorded as the grant (a WHAT-class authorization needs clean provenance).
- Operator input (2), CLEAN confirmation, verbatim: **`"ratified"`** · recorded **2026-09-16T13:43:32Z**.
⇒ **The BUILD-CLASS STANDING-APPROVAL CLASS (predicate P1–P4) is RATIFIED by the operator (apex ratifier).**
This is the standing human authorization §5 INDEPENDENCE requires — exercised once, at the class level.
Foundation may close build-class sets (P1–P4 PASS) under this class **without a per-set operator pen**, once
the §3 gate check is built and armed (AC-B1–B4). Sets that FAIL any P still take the operator's pen.

## §6 · Acceptance criteria
- **AC-B1** the P1–P4 gate check is built + fail-closed; a seeded P-failing set is refused build-class.
- **AC-B2** P4 self-widening is proven for BOTH forms: a set touching an authz-model
  DOCUMENT (`C-SET-AUTHORIZATION` / this predicate) is refused build-class even if P1–P3 pass, **AND a set
  whose only member rewrites an EXECUTABLE ENFORCER (`agents/pre-commit-hook.sh` `set_consumed`, the §3
  gate script, `scripts/ratify.sh`, `scripts/pending-set.sh`) is refused build-class even if P1–P3 pass.**
- **AC-B5** the manifest is self-protecting: a set editing `_index/authz-enforcers.tsv` is refused
  build-class; the §3 gate reads P1/P2/P4 lists (incl. the manifest) as declared versioned DATA, not
  hardcoded literals, so a predicate amendment lands without a gate rebuild.
- **AC-B6 · OPERATIVE-ROW PARSE INTEGRITY (PAIRING, SUPERSEDED by shape (b),
  conformed).** Under shape (b) the `.tsv` is the **SINGLE operative artifact**
  holding all three rule-groups (P1/P2/P4); the spec §1 P4 block is now **DESCRIPTIVE prose**, not a second
  operative enumeration. The original two-artifact drift probe (`.tsv` == spec §1 P4 enumeration) is
  **DISSOLVED, not merely relaxed**: shape (b) removed the second artifact, so there is no seam to drift and
  no transcription to slip — the architect authors the `.tsv` **directly** as P4's operative list (the predicate is the architect's to write, never the assembler's). ⇒ AC-B6 is the **fail-closed
  parse-integrity check on the `.tsv`'s operative rows**: the probe reads ONLY the `rule`-tagged rows
  (`P1-ALLOW|P2-DENY|P4-ENFORCER`), **never a grep of the spec, and never the `.tsv`'s own comment/header
  lines** — a path named ONLY in a comment/prose line MUST NOT enter the parse; a path in an operative row
  MUST — proven with a **seeded cure-comment decoy inside the `.tsv` fixture** (a probe never shown a decoy
  is not known to ignore decoys). **DERIVE-from-prose stays REJECTED**
  **and its inverse is ALSO rejected** — defining a spec-prose "operative region/extraction boundary" to
  pair against re-creates the fragile prose parse already refused, and the §1 P4 NOTE (which names the
  removed `seats.yaml` phantom explanatorily) would re-inject that phantom as a **FALSE RED**. The
  transcription-slip class the original AC-B6 guarded is now covered **structurally**: there is no
  transcription (one artifact), and a WRONG/phantom operative path is caught by **AC-B7** (resolve-at-HEAD —
  the repository-anchored check a pairing could never make) **+ P4 self-protection** (the `.tsv` is its own
  P4-ENFORCER row, so any edit to it takes the operator's pen).
- **AC-B7 · ALLOW/ENFORCER PATHS RESOLVE AT HEAD.** The
  probe asserts every `.tsv` path with `rule ∈ {P1-ALLOW, P4-ENFORCER}` EXISTS at HEAD, minus a declared
  same-set exception (paths landing in THIS set — the spec, the `.tsv`, the §3 gate script). **`P2-DENY`
  rows are EXEMPT from the resolve check** — pre-denying a not-yet-built surface (e.g. `scripts/cost-guard.sh`)
  is legitimate and desirable: it means the set that CREATES that surface takes the operator's pen. A phantom
  in ALLOW/ENFORCER is the hazard (a phantom enforcer protects nothing — what `seats.yaml` was); a phantom
  in DENY protects nothing but harms nothing. **Rationale (the fourth instance of the session's shape): a
  pairing check proves two LISTS agree with each other — it cannot prove either agrees with the REPOSITORY.**
  `seats.yaml` was in both the spec and the `.tsv` as a P4 entry, so AC-B6 would go GREEN while protecting a
  file that does not exist; AC-B7 converts that phantom from a silent green into a loud red.
  **FRAME IS BINDING ON THE IMPLEMENTATION: "at HEAD" means COMMITTED HEAD —
  resolution MUST read `git ls-tree -r HEAD` / `git cat-file -e HEAD:<path>`, NEVER `git ls-files` / the
  index.** The index is transiently stage-able (`git add` re-greens a path absent from HEAD), and this gate
  decides which sets SKIP the operator's pen, so an index read is a latent false-green on the exact control
  that gates the pen (`DISC-A-NUMBER-CARRIES-ITS-FRAME` — the caption is a claim the code must actually make).
  Proof obligation at arming: a **both-polarity red pole** — a member `git add`ed-but-not-committed FAILS
  resolution.
- **AC-B3** activation records the operator's CLEAN ratification verbatim + UTC in §5 before any set closes
  under the class.
- **AC-B4** the auditor reproduces the `build-class` verdict post-merge.

— end SPEC-BUILD-CLASS-STANDING-APPROVAL v0.4 (architect-authored; foundation lands at `contracts/`; class RATIFIED + ACTIVE per §5)
