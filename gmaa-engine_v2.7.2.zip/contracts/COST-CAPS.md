# COST-CAPS — the runtime cost-brake SLOT (SPEND · REQ-COST · C-SET-AUTHORIZATION §2.4)

**This file is CONFIG, not code.** `scripts/cost-guard.sh` holds no rates of its own and parses
this slot on every run. Two copies of a pricing rule drift — a standing register lesson — so there
is exactly one copy and it is here. **An unfilled or unparseable entry is `exit 3` (HALT), never a
permissive default** (§2.4: *"Unfilled caps on a metered path → HALT (unfilled slot)"*).

**Operator-movable.** The cap numbers are the operator's dial. Changing one is a one-line edit
here — never a code change, never a redeploy.

**GMAA boundary (§2.4):** the generic package ships `cost-guard.sh` + this slot **EMPTY**. The
numbers below are origin-private and do not travel.

---

## caps

```
per_unit_usd: {{COST_CAP_PER_UNIT_USD}}
per_cohort_usd: {{COST_CAP_PER_COHORT_USD}}
fail_closed_if_unreadable: true
```

`fail_closed_if_unreadable: true` is asserted here **and** re-checked by the script, which refuses
to run at all if it is anything else. A brake with a fail-open switch is not a brake.

---

## prices — USD per 1,000,000 tokens

```
opus_input_usd_per_mtok: 5.00
opus_output_usd_per_mtok: 25.00
opus_cache_read_usd_per_mtok: 0.50
opus_cache_write_usd_per_mtok: 6.25
sonnet_input_usd_per_mtok: 3.00
sonnet_output_usd_per_mtok: 15.00
sonnet_cache_read_usd_per_mtok: 0.30
sonnet_cache_write_usd_per_mtok: 3.75
```

**Base rates** (`claude-opus-4-8` $5/$25 · `claude-sonnet-4-6` $3/$15) are read from the live
Anthropic model/pricing reference, **not from memory** (CLAUDE.md §Discipline 5). `claude-opus-4-5`
prices at the Opus rate — the repo's own `gate_dispatcher.py:68` records the L2 §285b
retirement as *"opus-4-5 legacy retired -> opus-4-8 (**same price**, current line)"*.

**Cache rates are DERIVED, and the derivation is stated here so the arithmetic is auditable without
reading the script:** cache read = **0.1×** input · cache write (5-minute TTL) = **1.25×** input.
(1-hour TTL writes are 2× — if any gate ever opts into the 1h TTL, add a separate rate rather than
averaging.)

**Never drop the cache terms to "simplify" the pricing.**

---

## unit / cohort — what the ids MEAN here (§2.4 "`unit_id` adopter-named")

- **unit = the adopter-named per-unit id** on the usage row the guard sums over.
- **cohort = an explicit unit-id list**, passed as `--cohort <id,id,…>`. The guard refuses any other
  form, and it never infers a cohort from a time window, which would be a denominator of its own invention.

---

## Call site

`scripts/cost-guard.sh check --unit <unit_id> [--cohort <id,id,…>]` at the **TOP of the next
metered gate**, and once at cohort enqueue — **before** the call fires, never after the prior write.
A guard that runs after the spend is a report, not a brake.

**Failure asymmetry (§2.4, load-bearing):** a usage-**WRITE** failure is log-and-continue (a usage
write must not crash a verdict). A usage-**READ** failure at check is a **HALT**. A missing row
after a successful call is a FINDING; a missing ledger at check is a HALT.

*Authored by the exec lane 2026-09-15 (drive-order item E). Spine paths are set-gated: this file and
`scripts/cost-guard.sh` need a covering ratified set to LAND — foundation assembles, the operator's
pen ratifies.*
