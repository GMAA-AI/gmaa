# THREAT-MODEL — the v2.7 governance package (origin's architecture)

**Status: RATIFIED.** Authored by foundation, before step I. Written from the S specs' lens lines. No control is claimed live unless its spec says so. S specs: MECH-SEAT = `LAUNCH-CONTRACT.md` · MECH-WRITE · MECH-TRANSPORT =
`SPEC-DOORBELL.md` · MECH-ENFORCE = `SPEC-GOVERNANCE-INDEX.md` · MECH-AUDIT = `agents/auditor-contract.md` · MECH-CHANGE-AUTH =
`C-SET-AUTHORIZATION.md`.

## 1 — What runs where
- **Seats** (worktree + branch + tmux session): a hub (`main`, sole spine writer), N module lanes
  (`spine_write: DENY`, own branch only), one architect (own branch; rules, never executes), one
  execution lane limited to apply-receipts. Launch = `claude --agent <def>` in tmux (MECH-SEAT §1-3).
- **Local git hooks** on the committing machine: `pre-commit` (single-writer + ratified-set coverage), `commit-msg`
  (the creed scan), `pre-merge-commit` (forces the reap path), `post-commit` (seals the prior audit, auto-rings
  inboxes) (MECH-WRITE §2-4; MECH-TRANSPORT §2; MECH-ENFORCE §4).
- **A Claude-Code-only `PreToolUse` hook** (`greenlight-policy.sh`) auto-approves a Bash call only when every segment
  is provably in policy; otherwise it falls through to a human prompt (MECH-WRITE §4).
- **The auditor**: per commit a deterministic code pass (0 model calls) from the post-commit hook; a headless
  `claude -p` pass only on a judgment-class path-trigger or daily (C′). Writes
  only the ledger, re-runs cited probes itself (MECH-AUDIT §1-2,§6).
- **Probes**: the budget and governance-index probes measure the S-spec cap and index drift, read-only
  (MECH-ENFORCE §2).
- **Transport**: the git inbox/outbox is the durable payload path; a tmux doorbell is a wake-only
  convenience: it can drop, the payload cannot (MECH-TRANSPORT §1-2).
*Source: MECH-SEAT §2-3 · MECH-WRITE §2-4 · MECH-TRANSPORT §1-2 · MECH-ENFORCE §2,§4 · MECH-AUDIT §1-2,§5.*

## 2 — Permissions per component
- **Spine single-writer** : foundation (`main`) is the sole spine writer. Module lanes only PROPOSE spine
  changes, landed through `reap_at_merge.sh`. The architect writes only its own branch; the execution lane writes
  only `ledger/apply-receipts/**` (MECH-WRITE §1).
- **Every authored DESIGN/AUTHORIZATION path rides a ratified set**; a "standing maintenance set" that keeps
  accepting members is refused by design (MECH-WRITE §2).
- **Build-class vs operator pen**: a set whose members all pass P1-P4 (plumbing-only footprint; no spend, custody,
  publish or data surface; reversible; no self-widening) closes WITHOUT a per-set operator pen, under a standing class the operator ratified once. Any
  P-failure, or a set touching the authorization model's own document or its executable enforcer, is refused
  build-class and takes the operator's own pen (self-protecting).
- **Ratification (`U5`)**: `ratify --by` (or `--standing-class` for a build-class set) is foundation-only, refuses
  on an empty assessment or an unresolved edge (MECH-CHANGE-AUTH §2).
*Source: MECH-WRITE §1-2 · `SPEC-BUILD-CLASS-STANDING-APPROVAL.md` §5-6 (not an S spec) · MECH-CHANGE-AUTH §2.*

## 3 — Trust boundaries
- **Identity comes from worktree location** (`_boot/BOOTSTRAP.md`, cross-checked against the branch), never from
  chat, and is **unsigned** in every lens-carrying spec — a file on the operator's disk, not an identity-provider
  claim.
- **Every mechanism's enforcement is local-machine only until the custody act.** Five of six twin lines name
  the HELD check (MECH-WRITE §5); MECH-AUDIT's reads "none".
- **The harness boundary is real**: git hooks bind "any client"; the `PreToolUse` tool gate binds Claude Code only
  (MECH-WRITE §8). A seat running git from a plain shell is outside the tool gate's reach entirely.
- **Remote Control** (lands with the restart-automation set): a seat session becomes steerable from the
  operator's claude.ai account; compromise of that account controls every such seat. A remote approval is
  harness-plane, inside ratified authority; the receipt says `requested … (configured)`, never observed.
*Source: the lens lines of MECH-SEAT §6 · MECH-WRITE §8 · MECH-TRANSPORT §6 · MECH-ENFORCE §8 · MECH-AUDIT §8.*

## 4 — What is bypassable, and by whom
- **A human or agent with a plain shell, outside Claude Code**, is never seen by the `PreToolUse` gate (§3); only the LOCAL git hooks constrain that actor; they block, but whoever runs them can remove them.
- **A seat that uninstalls its own local pre-commit hook bypasses the single-writer gate entirely** (MECH-WRITE §8).
- **`git commit --no-verify`/`-n`, `git -c core.hooksPath`** are the one denied class inside Claude Code
  (`greenlight-policy.sh`); nothing analogous runs outside the harness.
- **`git merge --no-verify`** is denied too (MECH-WRITE); only a plain shell skips the hook (C-SET-AUTHORIZATION §2).
- **A fast-forward merge of a module into the trunk fires no merge-commit hook at all** — outside `pre-merge-commit`'s
  reach. Residual: no structural bar; it is avoided only because the trunk is no module tip's ancestor today (MECH-CHANGE-AUTH §2b).
- **`AUDITOR_CMD` set to an off-PATH name skips the auditor's model session**, per process. The skip is logged and
  the sentinel still written, but the session is never caught up — "a test seam, not configuration" (MECH-AUDIT §6).
- **The boundary creed-scan runs (SessionStart/Stop/SessionEnd) are LINTERS ONLY**; only the commit-time scan can REJECT (MECH-ENFORCE §4).
- **Prompt injection:** seats act on content they did not author (relays, dispatches, fetched pages, tool output). An
  injected instruction can steer a seat inside its own write territory and tool allowances; the single-writer and
  set-coverage gates still bind at commit. Not built: a provenance check on inbound content.
- **Settings scopes:** permissions merge the tracked `.claude/settings.json` with the untracked `settings.local.json`
  and the user `~/.claude/settings.json`; anyone with disk write can widen a seat unseen. Not built: surface-conformance
  covers `settings.json` only, not `settings.local.json`.
*Source: MECH-WRITE §4,§8 · MECH-CHANGE-AUTH §2b · MECH-AUDIT §6 · MECH-ENFORCE §4.*

## 5 — Residual risks and known not-built controls
- **MECH-CHANGE-AUTH sits 2 B under its packaging cap.** `C-SET-AUTHORIZATION.md` authorizes every change-set, and
  is 8,190 B against an 8,192 B cap with the five lens lines and the limit line (budget probe at `989bc233`: S cap PASS, LENS 5 of 5).
- **Anti-gaming / coherence / cost-brake slots installed; the runtime brake is not armed**: `REQ-FOOTPRINT`,
  `REQ-HUNT` and `REQ-COST` (MECH-CHANGE-AUTH §2) are installed (`pending-set.sh`, `ratify.sh`, the COST-CAPS slot +
  `cost-guard.sh`); the runtime brake is not armed (0423 L-G3).
- **The runtime cost guard is wired but not live**: `cost_guard.py` fails closed in code but is **not stopping
  spend** pending deploy/parity verification — not an active guard (CLAUDE.md discipline #10).
- **`GOVERNANCE-CHECK` is a retrieval tool plus a detector, not a compulsory gate** (CLAUDE.md §GOVERNANCE-CHECK).
- **The repo is `STATE-PRE-GENESIS`** (declared, not a defect): seat defs, permission settings, lane map are
  hand-maintained; genesis-keyed guarantees are INERT; compensating control = the
  surface-conformance probe (`contracts/CONSTANTS.md` §4).
- **No structural fast-forward bar** on the trunk merge path; `merge.ff=false` was tried and withdrawn (MECH-CHANGE-AUTH §8).
- **Subagents** run with their seat's permissions; "the writer's commit act is never delegated downward" (canon :72) has
  only a PARTIAL carrier (a commit gate on subagents waits on a live-docs check).
- **Secrets** live in the local environment or `.env`, never in the record by rule. Built: the pre-commit hook runs
  `scripts/secret-scan.sh` on staged added lines, refusing known credential shapes; scanner errors fail closed.
  No entropy check: an unlisted token would still reach the spine.
*Source: budget probe · MECH-CHANGE-AUTH §2,§8 · CLAUDE.md #10, §GOVERNANCE-CHECK · CONSTANTS.md §4.*
