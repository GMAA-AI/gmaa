# CONSTANTS — GENERATED generic subset (scripts/gen-ship-tree.sh; ship-carriers row 37). Only the
# declared STATE condition scripts/boot-check.sh reads ships; every project operational constant
# (the domain constants of §1-§3/§5-§9) stays at origin and never ships.

## §4 — Operational invariants (BINDING)

| Invariant | Statement | Cross-ref |
|---|---|---|
| STATE-PRE-GENESIS (a DECLARED CONDITION — not an invariant, not a defect) | This project was adopted by RETROFIT: canon v1.6.5 §12's genesis never ran as one ratified set — there is no `seats.yaml`, no generators, no regenerated folder→lane map. The seat defs (`.claude/agents/`), the permission settings (`.claude/settings.json`) and the lane map (`_orchestration/lane-provisioning.md`) are HAND-MAINTAINED by declaration. Every genesis-keyed guarantee — canon §7 generation law, the declared-vs-actual roster gate — is INERT here. Compensating control = the surface-conformance probe (Unit A), keyed to each worktree's `_boot/BOOTSTRAP.md` stamp + `git worktree list`, never `seats.yaml`. Exit condition = a ratified genesis-equivalent run. Visible while tolerated: `scripts/boot-check.sh` prints the `STATE: PRE-GENESIS` line every boot. | canon v1.6.5 §12 `:309-321`; surface-conformance Unit B; CHECKLIST TRACK 1; `issues_register.md` `ISSUE-STATE-PRE-GENESIS-DECLARED-CONDITION-2026-09-23` |
