# READINESS — when an output may be called ready

**Spec of record for READINESS.** Binds every publish or release gate that marks an artifact
"ready," independent of the project's own checklist format or publish mechanism.

## §1 The rule
An output is READY only when every check in its versioned checklist can actually fire against the
served artifact: a red pole exists for the check, AND the production caller supplies the check's
real inputs. A check that returns SKIPPED_NA (or an equivalent always-skip result) in every caller
is presence theatre, not a check, and the artifact is not READY on its strength.

## §2 Terms
- **Versioned checklist** — whatever list of checks the project's own publish or release gate
  declares for a given artifact type. This contract does not define that list; it binds what
  counts as satisfying it.
- **Red pole** — a reachable negative case the check can fail on, exercised at least once. A check
  that is green by construction (it can never fail) does not count.
- **The production caller supplies the check's inputs** — the check runs against the actual served
  artifact at release time, never against a synthetic fixture or a cached stand-in.

## §3 Enforcement (project-supplied)
This contract states the generic rule. The checklist's own format, the probe or script that walks
it, and the specific publish or release gate that calls that probe are project-specific and are
declared in the project's own configuration, not here.

## §4 Acceptance (proved only by a run)
R1 a checklist item with no red pole never counts toward READY · R2 a checklist item whose
production caller never supplies real inputs never counts toward READY · R3 a checklist item that
returns SKIPPED_NA in every caller never counts toward READY · R4 an artifact is READY only when
every remaining item passes against the served artifact.
