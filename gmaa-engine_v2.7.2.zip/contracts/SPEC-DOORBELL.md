# MECH-TRANSPORT — relays move by git; the doorbell wakes; reconciliation proves arrival

**Spec of record for MECH-TRANSPORT** (the ONLY document for this mechanism, ≤ 8 KB). It absorbs
SPEC-RECONCILIATION-DIFF and C-RECONCILIATION-DIFF (MERGE, `_index/layers.tsv`). Architect authors; foundation builds.
Prior texts (git blobs, frame `git-blob` @ `612cc795`): SPEC-DOORBELL v0.3 `25bc55da`, SPEC-RECONCILIATION-DIFF v0.1
`cb434c2d`, C-RECONCILIATION-DIFF `734a8077`. The two merged files stay at their paths as record, bannered.

## §1 Transport (binding)
- **The git inbox IS the transport.** Inbound: `_orchestration/relay-inbox/<lane>/` on spine, written only by the hub.
  Outbound: `_orchestration/relay-outbox/<lane>/<YYYY-MM-DD>-NN-<topic>.md` on the lane's OWN branch
  (integration-excluded; the hub reads it cross-branch). No seat writes in another seat's territory.
- **Every ring has a committed line behind it:** a relay, or one line `<utc> got <ref> read@<sha> — <clause>` appended
  to `ACK.log` in the lane's message surface (one file per lane), and for the hub its inbox relay or `dispatch/LATEST.md`.
- **Read every turn, first:** a lane runs `scripts/inbox.sh` (the hub runs `scripts/inboxf.sh`, which reads each lane
  outbox, the architect outbox and the DMZ) and emits `INBOX-CHECK: <lane> <N new | empty>`.
- **Consume only after acting, with the premise:** `inbox.sh consume <name> --premise holds@<ref>|refuted@<ref>`.
  The verb refuses without a premise. A read never advances the marker.

## §2 Doorbell = the wake layer, never the transport (`scripts/doorbell.sh`)
- **A dropped bell DELAYS, never LOSES:** the payload is durable in git and the next INBOX-CHECK catches it. tmux
  `send-keys` is never a transport (it drops silently with exit 0).
- **R1** resolve the pane by tmux `session_name` == lane; zero or several matches → HALT-LOUD.
- **R2** two-phase send: the literal wake token, then `Enter` as a separate call; verify the submit.
- **R3** interactive `ring`: a bad target exits non-zero with a named reason. Never exit 0 silently.
- **R4** a ring is done only when the target's consume-ack lands (`doorbell.sh ack`); `ack` reads the `ACK.log` line.
- **R5** the wake string is a fixed token, never the payload.
- **Producer-ring obligation (Ruling 1, binding, verbatim):**
  > "On committing to `relay-inbox/<lane>/` a payload that requires the target orc to act, ringing that lane's doorbell is part of **COMPLETING** the output — not a discretionary follow-up. The ring completes the output; the R4 consume-ack closes it. A committed-but-unrung actionable notify-output is an **INCOMPLETE** output, same class as a payload written but never committed. **DEFAULT TO RING:** if it is unclear whether a payload requires action, RING. A redundant wake is a cheap no-op turn (INBOX-CHECK idempotent, flat-rate on Max); a missed wake strands the lane and needs a human. The only non-ring cases are (a) payloads definitionally informational — no expected response, correctly served by the lane's next natural turn — and (b) lanes the ring genuinely cannot reach (not in tmux / session absent), handled by the §1/§23 safety property and SURFACED, never silently skipped."
- **§22 qualification (binding, verbatim):**
  > "The doorbell LAYER is architecturally optional — the durable git inbox is correct and lossless without it. That is the §23 'delays never loses' SAFETY property: the backstop for GENUINE drops (lane not in tmux, dead session, raced send). It is NOT license to skip a needed ring. When the layer is live and a lane is idle awaiting an actionable payload, the ring is OBLIGATORY per Ruling 1. Optionality is a property of the layer's existence and its drop-robustness — never permission to choose not to ring."
- **Bidirectional**: a lane that surfaces, completes or halts rings the hub (`ring foundation`).
- **Auto-fire backstop** (`agents/post-commit-hook.sh` §1c, hub only): every `relay-inbox/<lane>/` path in a commit
  rings that lane once per commit, without judging "needs action". It never blocks the commit. An unreachable lane is
  written as `unrung: <lane> (<reason>) <sha> <ts>` to `ledger/doorbell.log`.
- **Remote control:** only an explicitly set tmux `@remote_control` on the session suppresses the auto-ring (surfaced
  as `unrung: … (remote-control-active)`). Attachment alone never suppresses; idle is never remote-control-active.

## §3 Reconciliation = did the authored thing arrive (`scripts/reconciliation-diff.sh`)
`reconciliation-diff.sh --surface <manifest|pending-set|origin-engine> [--no-fetch] [--engine-root PATH]`
- **Exit set (closed):** 0 reconciled (both directions empty, fresh reference) · 2 DIVERGENCE (named per direction;
  never auto-continues) · 3 UNREADABLE (a side unread, a stale ref, or BOTH sides empty) · 1 usage.
- **Properties:** both directions printed, always · read-only, cross-checks and never replaces the ledger · decided by
  content (object identity), never ancestry · fetch first, or label `AS-OF-LAST-FETCH` and exit 3 · print the
  denominator and surface paths before any count · state what it cannot see.
- **Surfaces, named for what they measure:** `manifest` = architect outbox ↔ spine inbox pairing (sent-no-reply /
  reply-no-sender); `pending-set` = packet ↔ criteria consistency; `origin-engine` = canon body (resolved by
  `scripts/canon-core.sh`) + the settings permission baseline vs the packaged engine, by byte-hash, valid only on
  untemplated artifacts (beyond that: presence and provenance, never bytes).
- **Reap rule in force:** reap by FILE, never by directory. `scripts/reap-safe.sh` refuses a directory pathspec and is
  run by hand; nothing calls it.

## §4 Not built (stated so no reader mistakes this spec for full coverage)
- **Canon §4's manifest-vs-HEAD diff** ("rulings that never arrived") — `manifest` measures reply pairing instead.
- **Reap receipts** (`ledger/reap-receipts/*.reap.json`, 0 present) and **`scripts/reconcile-outbox.sh`** (absent).
- **Change B** (ledger rows vs membership derived from branch state).
- `STRANDED-OUTBOX` in `inboxf.sh` and `doorbell.sh stuck`.

## §5 Acceptance (proved only by a run)
L1 `ring <live-lane>` lands and is consume-acked · L2 a bad target gives non-zero + a named reason · L3 an inbox
commit auto-rings, one ring per lane per commit · L4 an unreachable lane is written `unrung:` and the commit is not
blocked · L5 `@remote_control` suppresses and surfaces · R1 each `reconciliation-diff.sh` surface exits 3 on an
unread side and on zero/zero.

## §6 Enterprise lens
- **Server-side twin:** the HELD pre-receive check (MECH-WRITE §5; no workstation listener) refuses a push that writes an outbox, inbox or relay dir outside
  the pusher's lane, and a relay whose `.sig` does not verify as its FROM seat.
  The bell and the reconciler run on the operator's machine.
- **Identity source:** the lane comes from the worktree's `_boot/BOOTSTRAP.md` (`scripts/resolve-lane.sh`) and the git
  author. Neither is signed.
- **Role model:** the hub is the sole spine writer and sole inbox writer. Each lane writes only its own outbox.
- **Install/upgrade path:** `scripts/install_post_commit_hook.sh` installs the post-commit hook (hooks are shared across worktrees). Lanes run as named tmux
  sessions (operator custody).
- **Harness binding:** Claude Code in tmux. The wake token is typed into the pane, and the seat def's per-turn
  INBOX-CHECK is what makes a wake do anything.

**Limit (verbatim):** *"S binds a seat that has not read it only to the extent its enforcer cannot be
bypassed by that seat. With local hooks (v1.6.5) that is an honest-operator property at n = 1; the server-side twin
(canon v1.6.6 candidate) is what makes it a guarantee."*

History: git log -- contracts/SPEC-DOORBELL.md · decision-log · _rulings/
