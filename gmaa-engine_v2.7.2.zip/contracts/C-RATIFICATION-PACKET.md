# C-RATIFICATION-PACKET — Set-Level Authorization Mechanism (v1.0)

AUTHOR: chat-Architect · DATE: 2026-07-08
STATUS: authored on ack (F1 split: architect contract → orc builds mechanism)
PLACE AT: `main/contracts/C-RATIFICATION-PACKET.md` (+ `_knowledge/` symlink) · extract to `_rulings/` per B2
BASIS: RELAY-2026-07-08 §F1 + §F1.1 (ruled verbatim; this page is the schema rendering, no semantic additions) · thesis §8 taxonomy · SPEC-COHERENCE v0.2/v0.3 at HEAD in `contracts/`

---

## §1 — Object and gate

`_ratification/SET-NNNN.md` on the SPINE. Integrator (orc-f) assembles at wave close; module lanes contribute member entries via their own branches and NEVER write the packet. **MERGE GATE:** no member branch merges to main until its set's packet carries a decision line of RATIFIED or RATIFIED-WITH-SEQUENCE (then in stated order). Per-WP Ring-2 + auditor unchanged — the COMMIT unit is what changes. Composes with the state machine: merge stays VERIFIED→CLOSED; merge AUTHORIZATION becomes set-scoped.

## §2 — Packet schema (one file per set)

```
SET-NNNN
├─ HEADER: set id · wave id · assembled-by (orc-f) · assembled-at (UTC) · HEAD sha at assembly · presented-after
├─ MEMBERS (one block per pending change):
│    wp_id · lane · branch@sha · one-line intent · receipts (paths) ·
│    cross-lane touchpoints · shared-substrate objects touched
├─ CONFLICT SWEEP: subagent sweep of live docs + codebase across the joint set —
│    findings listed with evidence paths; "none found" is a claim requiring the sweep receipt
├─ COHERENCE CHECKS: each set-level check run · result · evidence path
│    (set-level = evaluable only on the JOINT set; a check any member passes alone doesn't belong here)
├─ BRIEFING: grounded alternatives for any member the assembler flags as contestable
├─ DECISION LINE (operator, exactly one; §3 taxonomy) + rationale + RATIONALE CLASS (§4)
└─ POST-DECISION: merge order executed (if -WITH-SEQUENCE) · auditor reproduction ref
```

**Rendering, and the `presented-after` field.** Each HEADER field renders in the packet file as its own line, `- <field>: <value>`; a field never shares a line with another, because the merge gate reads a HEADER field by its own line and takes the whole value (`agents/pre-commit-hook.sh`, the `- HEAD sha at assembly:` reader: the value is the assembly sha and nothing else). `presented-after` carries `NONE`, or every packet presented and unlanded at assembly time, `SET-NNNN[, SET-NNNN…]`, in presentation order, read from the PENDING-SET ledger's `evaluated (into SET-X)` cells. A packet whose value is not `NONE` is judged at the stacked tree: the spine HEAD plus the parked bytes of every listed packet, applied in that order; if any listed packet is then HELD, AMENDED or REJECTED, every packet presented after it is void and re-assembles on the new base.

## §3 — Decision taxonomy (F1.1; closed set; never a bare no)

| Line | Effect |
|---|---|
| `RATIFIED` | orc-f merges the set |
| `RATIFIED-WITH-SEQUENCE` | merges in the stated order, no other change |
| `AMENDED` | per-member dispositions; **SUBSET RULE applies (§5)** |
| `HELD` | set → PARKED against a NAMED trigger (event/date recorded); re-surfaces on trigger; never limbo |
| `REJECTED` | per-member dispositions + rationale + the briefing's grounded alternatives |

State-machine additions (schema/state-machine.md, ruled): VERIFIED→RETURNED (branch PRESERVED; WP reopened carrying rationale + alternatives; relayed to proposing lane's inbox via doorbell) · VERIFIED→PARKED · RETURNED→IN_PROGRESS or ABANDONED (reaper-archived per SPEC-REAPER, never deleted).

## §4 — Rationale class (recorded on ALL outcomes)

`in-band` (resolvable from system-of-record facts) vs `OUT-OF-BAND` (deciding fact lives outside the store — cutover, hold, strategy, commitment). Recorded on ratifications AND rejections — out-of-band decisions in either direction are thesis obligation-2 evidence. The packet is the collection instrument; tallies feed F4.

## §5 — Binding invariants

- **SUBSET RULE:** an AMENDED set is a NEW set. Retained members re-enter packet assembly + JOINT re-validation before any merge — removing a member can change joint coherence. Line-item ratification does not exist. Anything weaker reintroduces per-change authorization through the side door and falsifies the thesis in its own reference implementation.
- **NO-CHERRY-PICK (D3-enforced):** RETURNED content reaches main ONLY inside a future ratified set. Cherry-picking a returned branch = boundary bypass = discipline violation.
- **LOOP GUARD:** same set RETURNED twice → automatic architect escalation (repeat rejection usually signals contract ambiguity, not defective work).
- **INDEPENDENCE:** the assembler validates; the operator ratifies; the auditor reproduces post-merge. No seat holds two of those three roles for the same set.

## §5a — JOINT-EDGE LIFECYCLE: the RESOLUTION CONTRACT

*Added because this contract was **SILENT** on `resolution:` — the convention lived only in the enforcer
(`scripts/ratify.sh`) and the packet template, and they **disagreed**. That silence is why the gap survived
to the first set that ever exercised it (SET-0011, the only packet of 8 to carry a joint edge).*

A joint edge detected at assembly (`## JOINT-EDGES`) has exactly **two** states:

| state | line shape | meaning |
|---|---|---|
| **UNRESOLVED** | `- UNRESOLVED · <edge text>` | detected, not yet dispositioned. **Blocks every MERGE decision.** |
| **RESOLVED** | `- RESOLVED · <edge text>` **+** a following `resolution: <rationale>` line | dispositioned, with the WHY on the record. |

**An edge is RESOLVED iff BOTH conditions hold.** The gate enforces **STRUCTURE, two checks** — never intent:

- **(i)** REFUSE a MERGE decision on **any** remaining `- UNRESOLVED · ` line.
- **(ii)** REFUSE a MERGE decision on **any** `- RESOLVED · ` line **lacking** a following `resolution:` line
  (scanning to the next `^- ` edge or `^## ` section). *A bare prefix-flip with no recorded rationale is a
  rubber-stamp: **the operator ratifies against the WHY, not the label.***

**Why BOTH, and not either alone.** Prefix-only (flip it, gate keys on the prefix) permits a rationale-less
rubber-stamp. Rationale-only (leave `- UNRESOLVED ·`, look for a following line) leaves the operator reading
*"UNRESOLVED"* over an edge that is in fact resolved — an **incoherent ratification surface that invites a
false refusal**. Requiring both yields a self-consistent artifact **and** an enforced, recorded disposition.

**AMENDED/HELD/REJECTED do NOT refuse on unresolved edges** — they are the *correct* responses to them.

**Resolving an edge is NOT the way to clear a FALSE edge.** An edge that is an artifact of a corrupt input
(e.g. a mis-declared `footprint.substrates`) is cleared by **correcting the input and RE-ASSEMBLING under the
SUBSET RULE (§5)** — never by writing a `resolution:` line over it. Writing a rationale onto a
self-contradictory edge (*"UNDECLARED-SUBSTRATE outside [db]"* marked *"actually it's declared"*) **papers a
fixed-bug artifact into the substrate the operator ratifies against.** For a **pre-operator** packet
(ASSESSMENT/CONFORMANCE/HUNT/RATIFICATION all still empty) that re-assembly is **foundation-side and spends
NO operator decision** — AMENDED is the operator's judgment about a *reviewed* set, and does not apply to a
never-decided skeleton built against corrupt inputs.

**Enforcer:** `scripts/ratify.sh` `cmd_ratify` (checks (i) and (ii)). **DOC and CODE share this one source —
if they drift again, THIS section is authoritative and the code conforms to it.**

## §6 — Acceptance

Mechanism proven only via F2's J6/J7 journeys (post SPEC-COHERENCE ratification): a seeded joint incoherence CAUGHT at assembly, demonstrably NOT catchable per-member, one non-RATIFIED walk exercising the RETURNED machinery, receipts per F3. Firewall F4 in force: this contract existing ≠ thesis proven; never claim proven-complete.
