# MECH-ENFORCE — the governance index, its retrievers, and the commit-time creed gate

**Spec of record for MECH-ENFORCE** (the ONLY document for this mechanism, ≤ 8 KB). It carries Findings 1
and 3 of its governing ruling. Architect authors; foundation builds. Prior text (v0.1–v0.4): git blob
`dc2dc9ae` (frame `git-blob` @ `612cc795`).

## §1 The index — `_index/governance.tsv` (DERIVED; never hand-edited)
- **Built by** `scripts/gen-governance-index.sh build|check|census|self-test`. `check` byte-compares the committed file
  against a fresh derivation. Standing probe `governance-index-drift` runs it after every commit.
- **Columns:** `id · corpus · classes · triggers · interacts_with · locate · check · blood · ship · wiring · strength ·
  layer · disposition · target`. Readers guard on a lower-bound `NF` and never split a row with bash `read` on tabs.
- **Existence** comes from `disciplines.md §R`, the CLAUDE.md invariants, `contracts/*.md`, `_index/canon-section-map.tsv`
  and `_index/mechanisms.tsv`. **Metadata** comes from `_index/annotations.tsv` (curated, keyed by id; the join is
  fail-closed both ways). **Layer / disposition / target** come from `_index/layers.tsv` (architect-curated, landed
  verbatim) or `mechanisms.tsv`; an id in both HALTs. `ship` is derived from `layer` (S, W-generic → generic;
  W-project → private).
- **Only KEEP rows are emitted.** MERGE and RETIRE rows leave the index; their files stay. A dropped row that is
  `scanner:`-wired HALTs the build. Loss of any other protection is caught by the budget probe (P1/P2, §6).
- **`wiring`** is exactly one of `scanner:<class>` (a class `creed-scan.sh` runs) · `probe:<path>` (exists, tests this
  rule) · `gate:<hook|script>` (can REJECT a violation of this rule) · `cite-only:<reason ≥ 8 words>` · `UNWIRED`
  (uncurated rows only). **`strength`** is derived: PREDICATE · CITE-ONLY · UNWIRED.

## §2 The standing probe — `probes/governance-index/probe_governance_index_v1.sh`
Arms: **A** generator instrument control (synthetic fixture) · **B** `check` (no drift, no unannotated core id, no orphan annotation) · **C** retriever
controls · **D** every wiring claim resolves (scanner class read live from `creed-scan.sh`; path exists; cite-only
word floor) · **E** every row has a valid layer, a valid disposition and a target where required. Any arm failing →
FAIL. The hub reads its worktree; a lane reads `origin/main`.

## §3 Retrieval (no model, no network)
- `scripts/rulecheck.sh <draft | --class X>` — shortlist = universal rows ∪ trigger matches ∪ the `interacts_with`
  closure, as a `RULECHECK:` block. Standalone: no gate consumes it.
- `scripts/governance.sh <topic>` — the GOVERNANCE-CHECK retriever over five surfaces (decision-log, register,
  `_rulings/**`, the canon resolved by version, `contracts/**`). An unreadable required surface exits 3 and emits no
  verdict: false absence would license the very raise the record already answers.

## §4 The creed gate — `scripts/creed-scan.sh`
- **Commit time:** `agents/commit-msg-hook.sh` runs `creed-scan.sh --staged --msg <file>` on the outgoing commit
  (the hub runs its staged copy; every other lane runs the spine copy). A breach → `CREED-GATE: REJECT`.
  `--no-verify` is denied by MECH-WRITE's tool gate.
- **Boundaries:** SessionStart (via `scripts/boot-check.sh`), Stop and SessionEnd run `scripts/creed-scan-spine.sh`
  over the seat's own commits since the last boundary. There it is a LINTER: findings print, nothing blocks.
- **Line classes** come from the index's `scanner:` rows: `absence` · `deploy-state` · `closure` · `count` ·
  `operator-door` · `deferral`. Each fires on a trigger phrase with no required cite on the same line.
- **Structural gates (Finding 1)** run whether or not any row names them; the engine requires them:
  **GOVERNANCE-CHECK** — an added ruling, architect ARCH ruling or register issue must carry
  `GOVERNANCE-CHECK: <topic> answered@<ref> | silent-or-contradictory`; `answered@` must resolve;
  `silent-or-contradictory` must say what was searched. **MINT-GATE** — a new `disciplines.md §R` id needs a
  resolvable wiring plan. **PREMISE/PARK** — routing a decision to the operator needs `PREMISE-CHECK … premise-holds`
  or a WHAT-class marker. **DEFER** — a deferral needs a named blocker on the same line.
- **Waiver:** `WAIVE:<class> <reason of ≥ 8 words>` on the line; every waiver re-surfaces at the next boundary.
- **Finding 3 (verbatim):** *the engine refuses to run with an empty roster; the shipped W-generic pack satisfies it; an
  adopter who strips W-generic must supply ≥ 1 scanner rule.* (0 `scanner:` rows from every accepted source → exit 3.)

## §5 Change-class → required canon sections (architect-authored; source of `_index/canon-section-map.tsv`)
| change-class | required canon sections (⊇) |
|---|---|
| seat population / lane / territory boundary | §1.0 · §1.1 · §1.3 · §2 · §7.2 |
| authorization / custody model | §1.2 · §6 · §10 |
| transport / relay architecture | §5 · §6 · §9 |
| set-gate / ratification machinery | §4 · §10 · §13 (+ `contracts/C-SET-AUTHORIZATION.md`) |
| subagent / parallelism | §1.3 |
| seat lifecycle / provisioning / boot | §7 · §7.1 · §7.2 · §7.3 |
| permission / harness plane | §8 |
| packaging / adoption / genericization | §11 · §12 |
| "what the architecture IS" (any claim) | §1 (§1.0–§1.3) |

## §6 Not built (stated so no reader mistakes this spec for full coverage)
- The v0.1 **pre-commit assess-gate** (recomputed `RULECHECK:` receipt; blood rows EVALUATED or WAIVED): no hook
  or script outside `scripts/rulecheck.sh` names it (git grep over agents/ scripts/ .claude/).
  The **canon gate** half is struck: built as CANON-READ-GATE (`scripts/creed-scan.sh:1148-1413`).
- The **register-read receipt** (AC-9), the fail-closed **joint-coherence slot**, the **leak-lens probe** (AC-7).
- **Pattern map to data** (Finding 2): regex · cite · mode per class are still a hard-coded `case` in
  `creed-scan.sh`; owed as `_index/scanner-patterns.tsv`, loaded by the engine, exit 3 on a roster class with no row.
- The per-disposition preservation poles live in the budget probe (P1/P2), not here.

## §7 Acceptance
X1 `gen-governance-index.sh check` = CURRENT · X2 the standing probe PASSES, and a seeded bad `scanner:` class gives one
`DRIFT:` line · X3 a staged uncited `count` line is REJECTED at commit and the cited line PASSES · X4 an added ruling
with no GOVERNANCE-CHECK line is REJECTED · X5 an empty scanner roster exits 3 · X6 a seeded trigger surfaces its row
in `rulecheck.sh`. · X7 0 contract/canon rows surface on the ≥200-line neutral fixture (red: a seeded id surfaces) ·
X8 every contract/canon row surfaces on its own `positive-prose.tsv` sentence (red: a blanked one fails).

## §8 Enterprise lens
- **Server-side twin:** the HELD pre-receive check (MECH-WRITE §5; no workstation listener) runs main's `creed-scan.sh --staged` and `gen-governance-index.sh check`
  on each pushed commit and refuses on a fail.
- **Identity source:** the committing worktree's lane (`resolve-lane.sh`) decides which scanner copy runs. Unsigned.
- **Role model:** the architect curates layer and disposition; foundation builds the generator, annotations and gate;
  every seat is scanned the same way.
- **Install/upgrade path:** the `commit-msg` hook (boot `HOOK-CHECK:` compares it with canonical). Lanes read the
  scanner and index from the spine, so an index change reaches every lane without a sync.
- **Harness binding:** a git hook (any client) plus Claude Code `SessionStart` / `Stop` / `SessionEnd` hooks.

**Limit (verbatim):** *"S binds a seat that has not read it only to the extent its enforcer cannot be
bypassed by that seat. With local hooks (v1.6.5) that is an honest-operator property at n = 1; the server-side twin
(canon v1.6.6 candidate) is what makes it a guarantee."*

History: git log -- contracts/SPEC-GOVERNANCE-INDEX.md · decision-log · _rulings/
