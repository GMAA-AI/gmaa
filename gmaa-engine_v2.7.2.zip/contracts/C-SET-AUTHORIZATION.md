# MECH-CHANGE-AUTH — the set-authorization model

**Spec of record for MECH-CHANGE-AUTH** (C-SET-AUTHORIZATION — the ONLY doc for this mechanism, ≤ 8 KB;
cut, substance-preserving). GMAA thesis: *"the unit of
authorization is the SET, not the change."* Prior text v0.1–v0.11 (git blob `97108f5f`, 51,060 B, operator
quotes included) is relocated VERBATIM in the decision-log fence `C-SET-AUTH-PRECUT` (landing entry); each `[pre §n]`
tag below names its span there.

## §L Law [pre §L]
Evidence-first + binding invariants #1–#5 + the disciplines bind every check below; where this and a standing
law conflict, the LAW governs.

## §1 The round-trip (canon §10's ratification flow) [pre §1]
DOWN: architect spec → foundation determines the SET, dispatches WPs → lanes execute own WP. UP: lanes submit →
foundation assembles, checks (A) coherence + (B) conformance → both pass → operator `--by` → foundation-only
writes (whole-set reap) → fail → owning lane redo → unresolved → architect → (operator) → back down.
- **R1** Foundation determines the set; membership is never lane self-nomination.
- **R2** Boundary = the REQUIREMENT, never effort/lane-count. One lane, no other ready → that IS the set (never
  held for unrelated lanes). ≥2 lanes → ONE all-or-nothing set. Foundation is BARRED from staggering one
  requirement into isolated WPs — bound by a DECLARED FOOTPRINT (§2.2).
- **R3** Both checks required: coherence + conformance.
- **R4** Pass ⇒ foundation asks, operator authorizes, foundation-only writes (U7). Architect assesses/adjudicates,
  never solicits/carries the `--by`, never writes the record.
- **R5** Fail ⇒ owning lane → unresolved → architect → (operator) → down; a failed member stays barred.

## §2 Enforcement — fail-closed, no leg on convention [pre §2]
| Leg | Mechanism | WIRE |
|---|---|---|
| D3 propose-not-commit | `pre-commit-hook.sh` module-DENY | installed+firing |
| U4A coherence | `ratify.sh` M4 joint-edge + M6(i) | installed+enforcing |
| U4B conformance | `ratify.sh` conformance-check (§2.1) | ratify-time |
| U5 operator authorize | `ratify --by`; REFUSES empty-assess+unresolved-edge | installed |
| U6 fail→return | non-RATIFIED barred from reap (M6(ii)) | installed+enforcing |
| U7 foundation-only write | `ratify.sh`+`reap_at_merge.sh`+custody fork | installed |
| FOOTPRINT-COVERAGE | `ratify.sh assemble`: `assembled_lanes ⊇ footprint.lanes` | §2.2 |
| SEMANTIC-HUNT slot | `ratify.sh` required HUNT block, REFUSE on UNABLE/missing | §2.3 |
| COST-BRAKE | `cost-guard.sh check`: exit 2 over-cap/3 unreadable → HALT | wired, not yet stopping spend |

**Covering law:** UNREADABLE never PASSes — REFUSE or demand a signed slot; no LLM inside a detector stamps a
verdict; doctrine never asserts an enforcement the bytes do not run. **WIRE:** hooks are currency-verified at
boot (installed ≠ source → HALT-LOUD). **Forced merge-path:** `pre-merge-commit-hook.sh` REJECTS any trunk merge
lacking sentinel `REAP_AT_MERGE=1` (no message escape: forgeable). A fast-forward residual fires no hook (does
not occur while reap stays `--no-ff`; close = tracked-forward ff-bar; no `merge.ff=false` belt, which would
reject the routine ff sync). **Biting proof:** each gate REJECTS a real violation against the live hook (§6 C).

### §2.1 U4B conformance [pre §2.1]
Each WP carries explicit, machine-checkable acceptance criteria (architect-owned; none → not dispatchable).
STRUCTURED verdict where checkable, else BOUNDED JUDGMENT AT THE EDGE (DISC-LLM-AT-THE-EDGES, cost-gated if
metered). `ratify` REFUSES on FAIL **or MISSING**, no override. Verdict+evidence: `_ratification/SET-NNNN.md`.

### §2.2 Footprint-coverage (anti-gaming: check coverage, not intent) [pre §2.2]
Spec declares `requirement_id` + `footprint.lanes` (required occupants, may be ONE) + optional `substrates`/
`exclusive`. No footprint or `requirement_id` → dispatch REFUSES. `set_id` mints once per `requirement_id`; a
2nd dispatch under a different `set_id` → HALT; none minted → HALT. Assemble: mixed `requirement_id`/`set_id` →
HALT; `assembled_lanes ⊇ footprint.lanes` else `HALT: FOOTPRINT-MISS`, never assess-aroundable; an extra lane →
`UNDECLARED-OCCUPANT` edge. Single-lane → vacuous+valid.

### §2.3 Joint-edge coherence (3 layers; incompleteness is UNSKIPPABLE) [pre §2.3]
A (mechanical): path overlap, shared-unforkable, dependency cycle. B (mechanical): two members citing the same
SoR id → `SHARED-RECORD` edge. C (REQUIRED slot): `SEMANTIC HUNT` block — hunt-at/method/candidates-or-ZERO/
risk/verdict. UNABLE or missing → `ratify --decision RATIFIED` REFUSES; CLEAR+zero-candidates+no-method →
REFUSE; EDGE-NAMED joins JOINT-EDGES. MERGE only on CLEAR or every edge resolved. No LLM stamps CLEAR; edges =
NONE does NOT mean coherent.

### §2.4 Cost-brake (read the ledger you write; unreadable = HALT) [pre §2.4]
One durable row per metered call via the sanctioned C-DB mechanism, never sampled telemetry. Caps are a SLOT
(`per_unit_usd`, `per_cohort_usd`, operator-movable, `fail_closed_if_unreadable: true`); unfilled → HALT.
`cost-guard.sh check` before the next metered call: 0 under · 2 over HALT-LOUD · 3 unreadable HALT.
Usage-WRITE = log-and-continue (a missing row = FINDING); READ at check = HALT.

## §3 Coverage consumed on landing; the spine is the SoR [pre §2a, §4]
A ratified set authorizes its `surfaces:` ONLY until CONSUMED (members `committed`); consumption LAPSES coverage
(no blank check). `set_consumed()` in `pre-commit-hook.sh`; unreadable ⇒ CONSUMED. The gate's own machinery
rides a consumed set too, except the irreducible bootstrap (both-polarity proof + surfaced record + auditor
reproduction). `surfaces:` is one path per line; malformed REJECTS. A non-git change is DOCUMENTED in the spine
by FOUNDATION (U7), the ledger future proposals check against.

## §5 Member manifest + structure-of-record [pre §3, §5]
A member declares every permanent change across ALL substrates (git + every declared substrate), checked against
`contracts/structure-of-record/` (`scripts/structure-of-record.sh`) — **{config · objects · MODEL · domain
invariants}**, secrets excluded. A missing entry is a BLIND CHECK and HALTs.

## §6 Definition of Done (the `--by` gate) [pre §6]
**A** real lanes/proposals, no synthetic member. **B** real substrate, canonical pipeline (#1). **C** both
accept+reject polarities, live, against the installed gate. **D** provenance travels (real SHAs).

## §7 Custody, open door [pre §7, §8]
Architect authors/adjudicates own branch · foundation orchestrates, sole spine writer (U7) · the live-reader lane
live-proves · module lanes single-writer own branch. Every spine write is ratified-member · enumerated-exempt ·
break-glass; default: an expedited single-member set with the operator's `--by`.

## §8 On DoD pass → package to GMAA (leak-lens, gated) [pre §9]
GENERIC architecture+methodology only; leak-lens strips origin-private specifics. Architect authors the
writeup; foundation is sole DMZ writer/transporter; nothing ships before DoD passes.

## §9 Enterprise lens
- **Server-side twin:** the HELD pre-receive check (MECH-WRITE §5) re-runs M6(i)/M6(ii) + the ratify gate per push.
- **Identity source:** `--by` carries the pen's words; identity is the OS login the pen was recorded under, matched
  to the registry's apex-ratifier row. It attests the account and host, not the person's presence: a seat runs under the same login.
- **Role model:** architect (author/adjudicate) · foundation (orchestrate, sole writer) · lanes (propose) ·
  operator (sole `--by`).
- **Install/upgrade path:** `ratify.sh`/`pending-set.sh`/hooks are spine-tracked; machinery changes ride a set
  (§3) except the bootstrap carve-out.
- **Harness binding:** git hooks + CLI scripts, harness-neutral.

**Limit (verbatim):** *"S binds a seat that has not read it only to the extent its enforcer
cannot be bypassed by that seat. With local hooks (v1.6.5) that is an honest-operator property at n = 1; the
server-side twin (canon v1.6.6 candidate) is what makes it a guarantee."*
