#!/usr/bin/env bash
# r13 (2026-11-08): lane's closing gate is the new seat's own confirm-lanes line (a lane reaped after its work merged no longer halts the next provisioning). The executor's class (origin rulings 0564 and 0565): a seat whose roster row carries spine_write: apply-receipts-only is stamped in that class, with handoff ledger/apply-receipts/ and rules_manifest, and its row names the class. Its stamp reaches its branch as the lane's own signed adopt (scripts/seat-keys.sh adopt-candidate) of a trunk-signed sync candidate that lane cuts after the set lands: parents (the branch tip, the landed set), the set's tree with _boot/BOOTSTRAP.md replaced and nothing else. At most one seat carries the class.
# r12 (2026-11-08): check tests jq and the python3 yaml module; the DONE line names the first turn's INBOX-CHECK line.
# r11 (2026-11-07): from an adopter's field report: lane fast-forwards the new lane's branch to the landed set (the lane's tree carries its own charter; before, it held every charter but its own), and every inbox marker is .gitkeep, the name scripts/inbox.sh and scripts/status.sh skip (.keep was counted as an unconsumed relay).
# r10 (2026-11-07): the roster reader marks an empty field with '-' so a chat entry's empty worktree survives the TAB read (r9's chat check never fired; never issued).
# r9 (2026-11-07): the manifest verify prints the rows that failed before it halts; seats.yaml may carry chat seats (surface: chat; canon v1.6.9 section 1.1), which check reads by name, role and operator and lane and enroll refuse by name.
# genesis.sh: stand up your project on the engine. One command, or its steps by name.
#
#   bash genesis.sh                             Phase 5, Part 1, whole: reads genesis.conf, verifies the manifest at a fresh
#                                               unzip, then fill, check, seed, enroll foundation, hooks, launch; halts by
#                                               name; a re-run resumes
#   bash genesis.sh check                       what is still missing before genesis can run
#   bash genesis.sh fill <SLOT> <value>         fill one slot (SLOTS.md section 1) in every file that carries it
#   bash genesis.sh seed <project> [<remote>]   stamp, seed, git init on main, first commit, push (runs once)
#   bash genesis.sh enroll <lane>               a seat's signing key, recorded and bound
#   bash genesis.sh hooks [--no-launch]         the git hooks (five files), the first signed commit, then the launch
#   bash genesis.sh lane <lane>                 Phase 5, Part 2, foundation only: one provisioning set for a roster seat
#   bash genesis.sh explain                     every file each command writes, and why
#
# This is the engine's onboarding verb in its command form (canon section 11: "a command, or an adoption document
# executed by the adopting sessions ... Either form generates the governance files and hand-writes none of them").
# It is a package-authored file: it is not part of the upstream engine, it changes no engine file except to fill a
# slot you name, and everything it does is listed under `explain`. Run it from inside foundation/ (the unzipped
# package). `seed` runs once; every other step may be run again and does only what is still undone. Each stops with a
# named reason the moment something is not as the documents say.
#
# Inputs it reads: genesis.conf (the one-command form; genesis.conf.example shows its eight lines), seats.yaml (your
# roster, written in Phase 4 from docs/SEATS_skeleton.yaml), _index/adopter-slots.tsv (the slot table),
# _index/engine-paths.tsv (the seed list). It is the one shipped file that reads seats.yaml.
set -u

say()  { printf 'GENESIS: %s\n' "$*"; }
halt() { printf 'GENESIS: HALT %s\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || halt "$1 is not installed (README, Prerequisites)"; }

ROOT="$(pwd)"
[ -f "$ROOT/MANIFEST.sha256" ] && [ -f "$ROOT/launch-orc.sh" ] && [ -f "$ROOT/_index/adopter-slots.tsv" ] \
  || halt "run this from inside the unzipped package folder (foundation/): MANIFEST.sha256 and launch-orc.sh must be here"
if command -v sha256sum >/dev/null 2>&1; then SHA="sha256sum"; else SHA="shasum -a 256"; fi
PY=python3
IN_LANE=0   # set by `lane`, so enroll prints the set's NEXT lines, not a seat's

# ---- seats.yaml reader: the flat shape docs/SEATS_skeleton.yaml gives (one list under seats:, scalar fields) --------
# Prints one TAB row per seat: worktree seat archetype operator allowlist_profile branch spine_write login host apex public_key
read_seats() {
  $PY - "$ROOT/seats.yaml" <<'EOF'
import sys, re
p = sys.argv[1]
try: lines = open(p, encoding='utf-8').read().split('\n')
except FileNotFoundError: print('NOFILE'); sys.exit(0)
seats, cur = [], None
for raw in lines:
    l = raw.split(' #', 1)[0].rstrip() if not raw.lstrip().startswith('#') else ''
    if not l.strip(): continue
    m = re.match(r'^\s*-\s+(\w+):\s*(.*)$', l)
    if m:
        cur = {}; seats.append(cur); k, v = m.group(1), m.group(2)
    else:
        m = re.match(r'^\s+(\w+):\s*(.*)$', l)
        if not m or cur is None: continue
        k, v = m.group(1), m.group(2)
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in '"\'': v = v[1:-1]
    cur[k] = v
keys = ['worktree','seat','archetype','operator','allowlist_profile','branch','spine_write','login','host','apex','public_key','surface']
for s in seats: print('\t'.join((s.get(k, '') or '-') for k in keys))   # '-' marks an empty field: a TAB-separated row with an empty leading field would collapse under read
EOF
}

seats_ok() {   # exit 0 when the roster is complete enough for genesis; prints the problems otherwise
  local rows bad=0 n_apex=0 n_found=0 n_ar=0 wt seat arch op prof br sw login host apex pub surface   # all local: enroll calls this from inside lane
  rows="$(read_seats)"
  [ "$rows" = "NOFILE" ] && { say "seats.yaml is missing: the Phase 4 session writes it from docs/SEATS_skeleton.yaml; place it here"; return 1; }
  [ -z "$rows" ] && { say "seats.yaml has no seats: entries"; return 1; }
  while IFS=$'\t' read -r wt seat arch op prof br sw login host apex pub surface; do
    for v in wt seat arch op prof br sw login host apex pub surface; do [ "${!v}" = - ] && eval "$v="; done
    if [ "$surface" = chat ]; then   # a chat seat (canon section 1.1, 6): name, role and operator only; no worktree, branch or key
      [ -n "$seat" ] || { say "a chat seat has no seat: name"; bad=1; }
      case "$arch" in ""|"(fill"*) say "chat seat '$seat': archetype is not filled"; bad=1 ;; esac
      case "$op" in ""|"(fill"*) say "chat seat '$seat': operator is not filled"; bad=1 ;; esac
      [ "$apex" = "true" ] && n_apex=$((n_apex+1))
      continue
    fi
    [ -z "$wt" ] && continue
    [ "$wt" = "$seat" ] || { say "seat '$seat': worktree '$wt' must equal the seat name (folder equals lane)"; bad=1; }
    case "$op" in ""|"(fill"*) say "seat '$seat': operator is not filled"; bad=1 ;; esac
    case "$prof" in ""|"(fill"*) say "seat '$seat': allowlist_profile is not filled"; bad=1 ;; esac
    [ "$apex" = "true" ] && n_apex=$((n_apex+1))
    if [ "$wt" = "foundation" ]; then
      n_found=$((n_found+1))
      [ "$sw" = "ALLOW" ] || { say "foundation: spine_write must be ALLOW"; bad=1; }
    else
      case "$sw" in
        DENY) ;;
        apply-receipts-only) n_ar=$((n_ar+1)) ;;   # the executor's class (canon section 1.1; origin rulings 0564, 0565)
        *) say "seat '$seat': spine_write must be DENY, or apply-receipts-only for the executor (only foundation writes the spine)"; bad=1 ;;
      esac
      case "$br" in ""|main) say "seat '$seat': branch must be the lane's own (module/$seat), never main"; bad=1 ;; esac
    fi
  done <<< "$rows"
  [ "$n_found" = 1 ] || { say "seats.yaml must carry exactly one foundation entry (found $n_found)"; bad=1; }
  [ "$n_apex" = 1 ] || { say "seats.yaml must carry exactly one seat with apex: true (found $n_apex)"; bad=1; }
  [ "$n_ar" -le 1 ] || { say "seats.yaml carries $n_ar seats with spine_write: apply-receipts-only; the class is the executor's, one seat"; bad=1; }
  return $bad
}

seat_field() {  # seat_field <lane> <column 1..11>
  read_seats | awk -F'\t' -v l="$1" -v c="$2" '$1==l {v=$c; if (v=="-") v=""; print v; exit}'
}

slot_names() { awk -F'\t' '!/^#/ && $1!="path" {print $2}' "$ROOT/_index/adopter-slots.tsv" | sort -u; }

unfilled_slots() {  # prints "SLOT path" for every slot token still present in its file
  awk -F'\t' '!/^#/ && $1!="path" {print $1"\t"$2}' "$ROOT/_index/adopter-slots.tsv" | while IFS=$'\t' read -r path slot; do
    [ -f "$ROOT/$path" ] || { echo "$slot $path (file missing)"; continue; }
    grep -q "{""{$slot}""}" "$ROOT/$path" && echo "$slot $path"
  done
}

# ---- genesis.conf reader: KEY=VALUE lines, # comments; prints KEY<TAB>VALUE; the caller checks completeness ----------
read_conf() {
  [ -f "$ROOT/genesis.conf" ] || return 1
  $PY - "$ROOT/genesis.conf" <<'EOF'
import sys
for raw in open(sys.argv[1], encoding='utf-8'):
    l = raw.rstrip('\n')
    if not l.strip() or l.lstrip().startswith('#') or '=' not in l: continue
    k, v = l.split('=', 1); print(k.strip() + '\t' + v.strip())
EOF
}

conf_value() { read_conf | awk -F'\t' -v k="$1" '$1==k {print $2; exit}'; }

conf_missing() {  # prints the names of the lines genesis.conf lacks or leaves as a placeholder
  local k v
  for k in PROJECT REMOTE $(slot_names); do
    v="$(conf_value "$k")"
    case "$v" in ""|"<"*">") echo "$k" ;; esac
  done
}

# ---- check ----------------------------------------------------------------------------------------------------------
# the manifest verify: only at a fresh unzip (every slot unfilled, no repository yet); writes a marker check reads later.
# The two shipped files Phase 4 replaces before this runs (docs/FOUNDATION.md and _knowledge/COORDINATION.md, the cover's
# placement step) are skipped: an adopter who followed the documents has already replaced them, by design.
PHASE4_REPLACED='docs/FOUNDATION.md _knowledge/COORDINATION.md'
manifest_verify() {  # returns 1 when the manifest does not verify; 0 when it verifies or is not a fresh unzip
  local n p rows; n=$(unfilled_slots | wc -l | tr -d ' ')
  [ "$n" = 7 ] && [ ! -d "$ROOT/.git" ] || return 0
  say "package: verifying MANIFEST.sha256 (a fresh unzip: nothing filled yet; the two files Phase 4 replaces are skipped)"
  rows="$(cd "$ROOT" && cat MANIFEST.sha256)"; for p in $PHASE4_REPLACED; do rows="$(printf '%s\n' "$rows" | grep -v " $p\$")"; done
  if ( cd "$ROOT" && printf '%s\n' "$rows" | $SHA -c - >/dev/null 2>&1 ); then say "package intact ($(printf '%s\n' "$rows" | grep -c .) of $(grep -c . "$ROOT/MANIFEST.sha256") manifest rows verified; $(echo $PHASE4_REPLACED | wc -w | tr -d ' ') skipped as yours)"; mkdir -p "$ROOT/.claude" && date -u +%Y-%m-%dT%H:%M:%SZ > "$ROOT/.claude/genesis-manifest-verified"; return 0
  else
    say "MANIFEST.sha256 does not verify: stop, re-download, verify against SHA256SUMS. The rows that failed (first five):"
    ( cd "$ROOT" && printf '%s\n' "$rows" | $SHA -c - 2>/dev/null | grep -v ': OK$' | head -5 | sed 's/^/  /' )
    say "  to list every row: $SHA -c MANIFEST.sha256 | grep -v ': OK\$'"
    return 1
  fi
}
verb_check() {
  local bad=0 n m
  n=$(unfilled_slots | wc -l | tr -d ' ')
  if [ "$n" = 7 ] && [ ! -d "$ROOT/.git" ]; then
    manifest_verify || bad=1
  elif [ -f "$ROOT/.claude/genesis-manifest-verified" ]; then
    say "package: MANIFEST.sha256 was verified at the fresh unzip ($(cat "$ROOT/.claude/genesis-manifest-verified")) and is not re-checked after the fills (the slot files differ by design)"
  else
    say "package: MANIFEST.sha256 was not verified by this script (its first run came after a fill or a seed); the proof is a fresh unzip verified against SHA256SUMS"
  fi
  for t in git tmux python3 ssh-keygen perl jq; do command -v "$t" >/dev/null 2>&1 && say "tool $t: present" || { say "tool $t: MISSING (README, Prerequisites)"; bad=1; }; done
  python3 -c 'import yaml' >/dev/null 2>&1 && say "python3 module yaml: present" || { say "python3 module yaml: MISSING (README, Prerequisites: PyYAML)"; bad=1; }
  if command -v claude >/dev/null 2>&1; then say "claude: present"; else say "claude: not on PATH (GETTING-STARTED, Step 2); needed at launch, not for seed"; fi
  if [ -f "$ROOT/genesis.conf" ]; then
    m="$(conf_missing | tr '\n' ' ')"
    [ -z "$m" ] && say "genesis.conf: complete (PROJECT, REMOTE and the six slots)" || say "genesis.conf: lines missing or still a placeholder: $m(the one-command form needs them; the named steps do not)"
  else
    say "genesis.conf: absent (the Phase 4 session writes it; genesis.conf.example shows its eight lines; the named steps run without it)"
  fi
  if [ "$n" = 0 ]; then say "slots: every slot is filled"; else say "slots: $n still unfilled (from genesis.conf by bash genesis.sh, or: bash genesis.sh fill <SLOT> <value>):"; unfilled_slots | sed 's/^/  /'; bad=1; fi
  if seats_ok; then say "seats.yaml: complete (foundation present, one apex, every code seat beyond it on its own branch, chat seats by name, role and operator)"; else bad=1; fi
  if [ -f "$ROOT/docs/FOUNDATION.md" ]; then n=$(grep -c '(fill' "$ROOT/docs/FOUNDATION.md"); say "docs/FOUNDATION.md: $n fill prompts left (your Phase 4 record; nothing shipped reads them, 0 is the goal)"; else say "docs/FOUNDATION.md is missing"; bad=1; fi
  if [ -f "$ROOT/_knowledge/COORDINATION.md" ]; then n=$(grep -c 'an adopter writes its own' "$ROOT/_knowledge/COORDINATION.md"); say "_knowledge/COORDINATION.md: $n project-specific sections still unwritten (your Phase 4 record; foundation boots reading it, 0 is the goal)"; else say "_knowledge/COORDINATION.md is missing"; bad=1; fi
  # the subagent roster (SUBAGENTS.md, the ninth decision): every allow-listed name has its definition file
  local al miss=""; al="$(conf_value PROJECT_AGENT_ALLOWLIST)"
  [ -n "$al" ] || al="$(grep -o 'Agent([^)]*)' "$ROOT/.claude/agents/orc.md" 2>/dev/null | head -1 | sed 's/^Agent(//; s/)$//')"
  case "$al" in ""|"<"*|*"{"*) say "subagents: the allow-list is not filled yet (genesis.conf PROJECT_AGENT_ALLOWLIST, or the slot); its names are checked once it is" ;;
    *) for a in $(printf '%s' "$al" | tr ',' ' '); do [ -f "$ROOT/.claude/agents/$a.md" ] || miss="$miss $a"; done
       [ -z "$miss" ] && say "subagents: every allow-listed name has its definition ($(printf '%s' "$al" | tr ',' ' '))" || { say "subagents: allow-listed name(s) with no .claude/agents/<name>.md:$miss (SUBAGENTS.md; place each definition before genesis)"; bad=1; } ;;
  esac
  if [ -d "$ROOT/.git" ]; then say "git: this folder is already a repository (seed has run, or this is not a fresh unzip)"; else say "git: not yet a repository (seed will git init on main)"; fi
  [ -x "$ROOT/launch-orc.sh" ] || { say "launch-orc.sh is not executable: the zip was unpacked with a tool that drops file modes; unzip again with unzip"; bad=1; }
  [ $bad = 0 ] && say "READY for: bash genesis.sh (or its steps by name: seed <project> <remote>, enroll foundation, hooks)" || say "NOT READY: fix the lines above, then run check again"
  return $bad
}

# ---- fill -------------------------------------------------------------------------------------------------------------
verb_fill() {
  [ $# -eq 2 ] || halt "usage: fill <SLOT> <value>"
  local slot="$1" val="$2" n=0
  [ -n "$val" ] || halt "the value is empty"
  case "$val" in *'{'*|*'}'*) halt "the value may not contain braces" ;; esac
  while IFS=$'\t' read -r path s; do
    [ "$s" = "$slot" ] || continue
    [ -f "$ROOT/$path" ] || halt "$path is missing"
    grep -q "{""{$slot}""}" "$ROOT/$path" || { say "$path: $slot already filled"; n=$((n+1)); continue; }
    $PY - "$ROOT/$path" "$slot" "$val" "$path" <<'EOF'
import sys
p, slot, val = sys.argv[1:4]
t = open(p, encoding='utf-8').read(); tok = '{' + '{' + slot + '}' + '}'
open(p, 'w', encoding='utf-8').write(t.replace(tok, val))
print('GENESIS: filled', slot, 'in', sys.argv[4], '(' + str(t.count(tok)) + ' place' + ('s' if t.count(tok) != 1 else '') + ')')
EOF
    n=$((n+1))
  done < <(awk -F'\t' '!/^#/ && $1!="path" {print $1"\t"$2}' "$ROOT/_index/adopter-slots.tsv")
  [ $n -gt 0 ] || halt "no slot named $slot in _index/adopter-slots.tsv (SLOTS.md section 1 lists them)"
}

# ---- seed -------------------------------------------------------------------------------------------------------------
verb_seed() {
  [ $# -ge 1 ] && [ $# -le 2 ] || halt "usage: seed <project> [<remote-url-or-path>]"
  local project="$1" remote="${2:-}"
  need git; need python3
  echo "$project" | grep -Eq '^[a-z0-9][a-z0-9-]*$' || halt "project token must be lowercase letters, digits and hyphens: '$project'"
  [ ! -e "$ROOT/.git" ] || halt ".git already exists here: seed runs once, on a fresh unzip"
  [ "$(basename "$ROOT")" = "foundation" ] || halt "this folder is named '$(basename "$ROOT")'; the engine lives in <parent>/foundation/ (folder equals lane)"
  unfilled_slots | grep -q . && halt "slots still unfilled; run: bash genesis.sh check"
  seats_ok || halt "seats.yaml is not complete; run: bash genesis.sh check"
  local operator; operator="$(seat_field foundation 4)"
  say "seeding foundation for project '$project' (operator: $operator)"
  $PY - "$ROOT" "$project" "$operator" <<'EOF' || halt "seeding stopped; nothing was committed (the lines above name the reason)"
import os, sys, datetime
root, project, operator = sys.argv[1:4]; os.chdir(root); bad = 0
def w(p, s): open(p, 'w', encoding='utf-8').write(s)
def r(p): return open(p, encoding='utf-8').read()
# 1. the identity stamp: _boot/BOOTSTRAP.md front matter
b = '_boot/BOOTSTRAP.md'; t = r(b).split('\n')
want = {'lane': 'foundation', 'role': 'integrator', 'bootstrap_version': '1', 'spine_write': 'ALLOW',
        'worktree_branch': 'main', 'project': project, 'handoff': 'dispatch/LATEST.md'}
for i, l in enumerate(t):
    k = l.split(':', 1)[0]
    if k in want and l.startswith(k + ': (fill'): t[i] = k + ': ' + want.pop(k)
if want: print('GENESIS: stamp keys not in fill form:', sorted(want)); bad += 1
else: w(b, '\n'.join(t)); print('GENESIS: stamped _boot/BOOTSTRAP.md (lane foundation, project ' + project + ')')
# 2. the declared fill paths (_index/engine-paths.tsv, class fill): empty files and directories, exactly as declared
n = 0
for l in open('_index/engine-paths.tsv', encoding='utf-8'):
    c = l.rstrip('\n').split('\t')
    if l.startswith('#') or len(c) < 2 or c[1] != 'fill' or os.path.exists(c[0]): continue
    if c[0] == 'PENDING-SET.md':
        w(c[0], '# PENDING-SET: the set-membership ledger (spine-owned; foundation writes it through scripts/pending-set.sh)\n\n'
                '## SET-IDENTITY\n| requirement_id | set_id | footprint.lanes | footprint.substrates | exclusive | minted-at |\n|---|---|---|---|---|---|\n\n'
                '## THE SET\n| # | member id | lane | branch@sha-range | surfaces touched | status |\n|---|---|---|---|---|---|\n')
    elif '.' in os.path.basename(c[0]):
        os.makedirs(os.path.dirname(c[0]) or '.', exist_ok=True); open(c[0], 'w').close()
    else:
        os.makedirs(c[0], exist_ok=True); open(os.path.join(c[0], '.gitkeep'), 'w').close()
    n += 1
print('GENESIS: seeded', n, 'declared fill paths')
# 3. the four record files the engine appends to (declared fill upstream; the index lists them as written until 2.8)
for p in ['_orchestration/decision-log.md', 'ledger/receipts.jsonl', 'ledger/audit-findings.md', 'ledger/audit-runs.log']:
    os.makedirs(os.path.dirname(p), exist_ok=True)
    if not os.path.exists(p): open(p, 'w').close()
print('GENESIS: seeded the four record files (decision log, receipts, audit findings, audit runs)')
# 4. the rulings directory and the ignore rules
os.makedirs('_rulings', exist_ok=True); open('_rulings/.gitkeep', 'a').close()
gi = ['.claude/*', '!.claude/agents/', '!.claude/settings.json', '!.claude/rules/', 'ledger/doorbell.log', '.tmp/']
pre = r('.gitignore').split('\n') if os.path.exists('.gitignore') else []
add = [x for x in gi if x not in pre]
if add: open('.gitignore', 'a', encoding='utf-8').write(''.join(x + '\n' for x in add))
print('GENESIS: .gitignore carries the six engine lines (' + str(len(add)) + ' added)')
# 5. the one charter edit: the state-source map names a file nothing creates
c = '_boot/CHARTER-foundation.md'; t = r(c); e = ' `_orchestration/STATE.md` (tombstone) ·'
if t.count(e) == 1: w(c, t.replace(e, '', 1)); print('GENESIS: charter state-source map: STATE.md entry removed')
elif t.count(e) == 0: print('GENESIS: charter state-source map: STATE.md entry already absent')
else: print('GENESIS: charter anchor appears', t.count(e), 'times; expected 1'); bad += 1
# 6. the handoff and the checklist: first entries
d = 'dispatch/LATEST.md'; t = r(d).split('\n')
for i, l in enumerate(t):
    if l.startswith('(fill: the current work'): t[i] = 'Genesis: foundation stood up by genesis.sh seed.'
    if l.startswith('(fill: the next work'): t[i] = "1. Enroll foundation's seat key (bash genesis.sh enroll foundation), then install the hooks (bash genesis.sh hooks)."
w(d, '\n'.join(t))
k = 'CHECKLIST.md'; t = r(k).split('\n')
for i, l in enumerate(t):
    if l.startswith('- [ ] (fill:'): t[i] = "- [ ] Enroll foundation's key and install the hooks (genesis.sh enroll, genesis.sh hooks)."
w(k, '\n'.join(t)); print('GENESIS: dispatch/LATEST.md and CHECKLIST.md carry their first entries')
# 7. foundation's row in the lane-provisioning manifest (the blob is git hash-object of the stamp, computed after git init below)
p = '_orchestration/lane-provisioning.md'; t = r(p); e = '| | | | | | | |'
if t.count(e) != 1: print('GENESIS: lane-provisioning anchor appears', t.count(e), 'times; expected 1'); bad += 1
else:
    now = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    w(p, t.replace(e, '| foundation | main | 1 | ALLOW | BLOB-PENDING | ' + now + ' | ' + operator + ' |', 1))
    print("GENESIS: foundation's row written to _orchestration/lane-provisioning.md")
sys.exit(1 if bad else 0)
EOF
  local blob; blob="$(git hash-object _boot/BOOTSTRAP.md)"
  $PY - "$ROOT/_orchestration/lane-provisioning.md" "$blob" <<'EOF'
import sys
p, blob = sys.argv[1:3]; t = open(p, encoding='utf-8').read()
open(p, 'w', encoding='utf-8').write(t.replace('BLOB-PENDING', blob, 1))
EOF
  say "git init on main, genesis commit"
  git init -q -b main "$ROOT" || halt "git init failed (git 2.28 or later is needed for -b)"
  git -C "$ROOT" add -A
  git -C "$ROOT" -c commit.gpgsign=false commit -q --no-verify -m "genesis: foundation stood up (genesis.sh seed; project $project)" \
    || halt "the genesis commit failed (set git user.name and user.email, then: git commit)"
  local g; g="$(git -C "$ROOT" rev-parse --short HEAD)"
  say "genesis commit $g"
  $PY - "$ROOT/CHECKLIST.md" "$(git -C "$ROOT" rev-parse HEAD)" <<'EOF'
import sys, re
p, sha = sys.argv[1:3]; t = open(p, encoding='utf-8').read()
t2 = re.sub(r'^\*\*absorbed_through_sha:\*\* .*$', '**absorbed_through_sha:** ' + sha, t, count=1, flags=re.M)
if t2 == t: print('GENESIS: CHECKLIST.md has no absorbed_through_sha line in the shipped form'); sys.exit(1)
open(p, 'w', encoding='utf-8').write(t2)
EOF
  git -C "$ROOT" add CHECKLIST.md && git -C "$ROOT" -c commit.gpgsign=false commit -q --no-verify -m "genesis: absorb marker stamped with the genesis commit" || halt "the marker commit failed"
  if [ -n "$remote" ]; then
    git -C "$ROOT" remote add origin "$remote" || halt "could not add the remote"
    git -C "$ROOT" push -q -u origin main || halt "push to origin failed; the engine reads the spine at origin/main, so fix the remote and run: git push -u origin main"
    say "main pushed to origin ($remote)"
  else
    say "NO REMOTE GIVEN: the engine reads the spine at origin/main. Before launch: git remote add origin <url>; git push -u origin main"
  fi
  say "lane resolves as: $(bash scripts/resolve-lane.sh 2>&1 | grep -o 'lane=[a-z0-9-]*' | head -1)"
  say "boot check: $(bash scripts/boot-check.sh 2>&1 | grep -o 'BOOT-RECORD: [A-Z]* [0-9]* of [0-9]*' | head -1)"
  bash scripts/boot-check.sh 2>&1 | grep -o 'STATE: [A-Z-]*' | head -1 | sed 's/^/GENESIS: /'
  say "DONE seed. NEXT: bash genesis.sh enroll foundation"
}

# ---- enroll -------------------------------------------------------------------------------------------------------------
verb_enroll() {
  [ $# -eq 1 ] || halt "usage: enroll <lane>"
  local lane="$1" row pub login host apex
  need git; need ssh-keygen
  [ -d "$ROOT/.git" ] || halt "not a repository yet: run seed first"
  seats_ok || halt "seats.yaml is not complete; run: bash genesis.sh check"
  [ "$(read_seats | awk -F'\t' -v l="$lane" '$2==l{print $12; exit}')" != chat ] || halt "$lane is a chat seat (surface: chat) in seats.yaml: it has no worktree and no key; nothing to enroll"
  [ -n "$(seat_field "$lane" 1)" ] || halt "no seat named '$lane' in seats.yaml; add it there first (the roster is the source of truth)"
  if [ "$lane" != foundation ]; then
    awk -F'|' -v l="$lane" '/^\|/ {a=$2; gsub(/^[ \t]+|[ \t]+$/,"",a); if (a==l) f=1} END{exit !f}' "$ROOT/_orchestration/lane-provisioning.md" \
      || halt "lane '$lane' has no row in _orchestration/lane-provisioning.md yet: its provisioning set (bash genesis.sh lane $lane, in foundation's session) writes the worktree, the stamp and the row, and enrolls it"
  fi
  if [ -n "$(seat_field "$lane" 11)" ]; then
    say "$lane already carries a public key in seats.yaml; regenerating the registry only"
  else
    say "generating $lane's key on this machine (scripts/seat-keys.sh keygen)"
    row="$(bash scripts/seat-keys.sh keygen "$lane" 2>&1)" || { printf '%s\n' "$row" >&2; halt "keygen refused (the lines above say why; SEAT_KEYS_DIR_NAME must be filled first)"; }
    printf '%s\n' "$row" | grep -vE '^[a-z0-9-]*	|^registry row to add' | sed 's/^/  /'
    pub="$(printf '%s\n' "$row" | awk -F'\t' -v l="$lane" '$1==l && NF>=4 {print $4; exit}')"
    [ -n "$pub" ] || halt "keygen printed no registry row for $lane"
    login="$(id -un)"; host="$(hostname -s 2>/dev/null || hostname)"
    $PY - "$ROOT/seats.yaml" "$lane" "$pub" "$login" "$host" <<'EOF' || halt "could not record the key in seats.yaml"
import sys, re
p, lane, pub, login, host = sys.argv[1:6]
t = open(p, encoding='utf-8').read()
# locate this seat's block: from its "- worktree: <lane>" line to the next "- worktree:" line
m = re.search(r'^(\s*-\s+worktree:\s*' + re.escape(lane) + r'\b.*?)(?=^\s*-\s+worktree:|\Z)', t, flags=re.M | re.S)
if not m: print('GENESIS: seat block for', lane, 'not found'); sys.exit(1)
blk = m.group(1); b2 = blk
b2, n = re.subn(r'^(\s*public_key:\s*)""', lambda mm: mm.group(1) + '"' + pub + '"', b2, count=1, flags=re.M)
if n != 1: print('GENESIS: public_key: "" line not found in', lane, "'s entry"); sys.exit(1)
b2 = re.sub(r'^(\s*login:\s*)"\(fill:[^"]*"', lambda mm: mm.group(1) + '"' + login + '"', b2, count=1, flags=re.M)
b2 = re.sub(r'^(\s*host:\s*)"\(fill:[^"]*"', lambda mm: mm.group(1) + '"' + host + '"', b2, count=1, flags=re.M)
open(p, 'w', encoding='utf-8').write(t.replace(blk, b2, 1))
print('GENESIS: seats.yaml: public key recorded for', lane, '(login ' + login + ', host ' + host + ')')
EOF
  fi
  # the registry, derived whole from seats.yaml: one row per seat that has a key; 7 TAB columns; apex or -
  read_seats | awk -F'\t' 'BEGIN{OFS="\t"} $11!="" && $11!="-" {print $1, $6, $4, $11, $8, $9, ($10=="true" ? "apex" : "-")}' > "$ROOT/_orchestration/seat-keys.tsv"
  [ -f "$ROOT/_orchestration/seat-keys-revoked.txt" ] || : > "$ROOT/_orchestration/seat-keys-revoked.txt"
  say "registry _orchestration/seat-keys.tsv rewritten from seats.yaml ($(grep -c . "$ROOT/_orchestration/seat-keys.tsv") rows)"
  bash scripts/seat-keys.sh check-registry --apex 2>&1 | sed 's/^/  /' | tail -3
  bash scripts/seat-keys.sh check-registry --apex >/dev/null 2>&1 || halt "the registry does not pass check-registry --apex (one apex row, 7 columns per row)"
  git -C "$ROOT" add seats.yaml _orchestration/seat-keys.tsv _orchestration/seat-keys-revoked.txt
  if [ -x "$ROOT/.git/hooks/pre-commit" ]; then
    [ "$IN_LANE" = 1 ] && say "the hooks are armed: the key row is staged with the rest of $lane's provisioning set" \
      || say "the hooks are armed: the row is staged, not committed. Foundation commits it through the armed hooks as its own signed commit, after the seat's provisioning set has landed; genesis.sh never commits past an armed hook."
  else
    git -C "$ROOT" -c commit.gpgsign=false commit -q --no-verify -m "enroll $lane (key record)" || say "nothing new to commit for $lane"
    say "the enrolling commit is unsigned by necessity: no hook exists yet and signing binds after it (the next step, hooks, makes the first signed commit)"
    git -C "$ROOT" remote get-url origin >/dev/null 2>&1 && { git -C "$ROOT" push -q origin main || halt "push failed"; }
  fi
  if [ "$lane" = foundation ]; then
    bash scripts/seat-keys.sh setup-signing foundation 2>&1 | grep -o 'SEAT-KEYS: setup-signing [A-Z]*.*' | head -1 | sed 's/^/  /'
    bash scripts/seat-keys.sh setup-signing foundation >/dev/null 2>&1 || halt "setup-signing failed for foundation"
  elif [ "$IN_LANE" = 0 ]; then
    say "NEXT for $lane: inside its own worktree run: bash scripts/seat-keys.sh setup-signing $lane"
  fi
  [ "$IN_LANE" = 1 ] && return 0
  bash scripts/seat-keys.sh confirm-lanes 2>&1 | grep -o 'SEAT-KEYS: confirm-lanes [A-Z]*.*' | head -1 | sed 's/^/  /'
  say "DONE enroll $lane. $( [ "$lane" = foundation ] && echo 'NEXT: bash genesis.sh hooks' || echo 'Then: bash genesis.sh hooks (confirms the lane; the hooks stay as installed)')"
}

# ---- hooks ------------------------------------------------------------------------------------------------------------
verb_hooks() {
  local launch=1; [ "${1:-}" = "--no-launch" ] && launch=0
  need git
  [ -d "$ROOT/.git" ] || halt "not a repository yet: run seed first"
  if ! bash scripts/seat-keys.sh confirm-lanes >/dev/null 2>&1; then
    bash scripts/seat-keys.sh confirm-lanes 2>&1 | grep -E 'UNCONFIRMED|HALT|FAIL|confirm-lanes' | sed 's/^/  /'
    halt "confirm-lanes does not PASS (the lines above name the lane): every writing seat needs its registry row at HEAD and setup-signing in its own worktree before the hooks confirm it"
  fi
  local noop=0 pre=0 out
  [ -x "$ROOT/.git/hooks/pre-commit" ] && [ -x "$ROOT/.git/hooks/post-commit" ] && pre=1
  say "installing the pre-commit hook and the three beside it (the spine-write boundary: pre-commit, commit-msg, pre-merge-commit, pre-push)"
  out="$(bash scripts/install_pre_commit_hook.sh 2>&1)"; printf '%s\n' "$out" | grep -E 'REFUSED|HALT|NO-OP|INSTALLED|installed' | sed 's/^/  /'
  printf '%s\n' "$out" | grep -qE 'REFUSED|HALT' && halt "the pre-commit installer refused (the lines above say why)"
  printf '%s\n' "$out" | grep -q '^NO-OP' && noop=$((noop+1))
  [ -x "$ROOT/.git/hooks/pre-commit" ] || halt "the pre-commit hook is not installed"
  say "installing the post-commit hook (the auditor)"
  out="$(bash scripts/install_post_commit_hook.sh 2>&1)"; printf '%s\n' "$out" | grep -E 'REFUSED|HALT|NO-OP|INSTALLED|installed|prerequisites' | sed 's/^/  /'
  printf '%s\n' "$out" | grep -qE 'REFUSED|HALT' && halt "the post-commit installer refused (the lines above say why)"
  printf '%s\n' "$out" | grep -q '^NO-OP' && noop=$((noop+1))
  [ -x "$ROOT/.git/hooks/post-commit" ] || halt "the post-commit hook is not installed"
  local h miss=""; for h in pre-commit commit-msg pre-merge-commit pre-push post-commit; do [ -x "$ROOT/.git/hooks/$h" ] || miss="$miss $h"; done
  [ -z "$miss" ] && say "five hook files installed: pre-commit commit-msg pre-merge-commit pre-push post-commit" || halt "hook file(s) missing after install:$miss"
  if [ "$pre" = 1 ]; then
    say "the hooks were already armed before this run (re-installed only where drifted): nothing to commit. $(bash scripts/seat-keys.sh confirm-lanes 2>&1 | grep -o 'SEAT-KEYS: confirm-lanes [A-Z]*.*' | head -1)"
    say "boot check: $(bash scripts/boot-check.sh 2>&1 | grep -o 'BOOT-RECORD: [A-Z]* [0-9]* of [0-9]*' | head -1)"
    say "DONE hooks (re-run)."
    [ "$launch" = 1 ] && verb_launch; return 0
  fi
  $PY - "$ROOT/CHECKLIST.md" "$(git -C "$ROOT" rev-parse HEAD)" <<'EOF'
import sys, re
p, sha = sys.argv[1:3]; t = open(p, encoding='utf-8').read()
open(p, 'w', encoding='utf-8').write(re.sub(r'^\*\*absorbed_through_sha:\*\* .*$', '**absorbed_through_sha:** ' + sha, t, count=1, flags=re.M))
EOF
  $PY - "$ROOT/CHECKLIST.md" <<'EOF'
p = 'CHECKLIST.md'; t = open(p, encoding='utf-8').read()
t = t.replace("- [ ] Enroll foundation's key and install the hooks (genesis.sh enroll, genesis.sh hooks).", "- [x] Enroll foundation's key and install the hooks (genesis.sh enroll, genesis.sh hooks).\n- [ ] Provision every other seat in seats.yaml (genesis.sh lane <lane>, one set each), then run the seeded-fault proof (canon section 12, step 8) and record it in docs/FIELD-EVIDENCE.", 1)
open(p, 'w', encoding='utf-8').write(t)
EOF
  say "first signed commit through the armed hooks"
  git -C "$ROOT" add CHECKLIST.md
  git -C "$ROOT" commit -q -m "genesis: hooks armed; absorb marker re-stamped" 2>&1 | grep -o 'SEAT-KEYS: hook-precommit [A-Z]*' | head -1 | sed 's/^/  /'
  bash scripts/seat-keys.sh verify-commit foundation HEAD 2>&1 | grep -o 'SEAT-KEYS: verify-commit [A-Z]*.*' | head -1 | sed 's/^/  /'
  bash scripts/seat-keys.sh verify-commit foundation HEAD >/dev/null 2>&1 || halt "HEAD does not verify as foundation's signed commit"
  git -C "$ROOT" remote get-url origin >/dev/null 2>&1 && { git -C "$ROOT" push -q origin main || halt "push failed"; }
  say "boot check: $(bash scripts/boot-check.sh 2>&1 | grep -o 'BOOT-RECORD: [A-Z]* [0-9]* of [0-9]*' | head -1)"
  say "NOTE: the auditor just wrote its first lines to ledger/audit-findings.md and ledger/audit-runs.log; foundation commits them as its records at its first turn. That is the engine working, not a dirty tree to clean."
  say "DONE hooks."
  [ "$launch" = 1 ] && verb_launch
  return 0
}

# ---- launch (the end of hooks; also the end of the one-command form) ---------------------------------------------------
verb_launch() {
  need tmux
  local project sess
  project="$(bash scripts/resolve-project.sh 2>/dev/null)"; project="${project#project=}"
  [ -n "$project" ] || halt "the project token could not be read from _boot/BOOTSTRAP.md (scripts/resolve-project.sh)"
  sess="$project-foundation"
  if tmux has-session -t "=$sess" 2>/dev/null; then
    say "foundation is already running as $sess. Attach: tmux attach -t =$sess (read the header before you type)"; return 0
  fi
  if [ -n "${CLAUDE_CODE_CHILD_SESSION:-}" ] || [ -n "${CLAUDECODE:-}" ]; then
    say "this command is running inside a Claude Code session: launching foundation detached, with the session's own harness variables unset for the seat"
    env -u CLAUDECODE -u CLAUDE_CODE_CHILD_SESSION -u CLAUDE_CODE_ENTRYPOINT ./launch-orc.sh --detach > .claude/genesis-launch.log 2>&1 \
      || { grep -E '^HALT' .claude/genesis-launch.log | sed 's/^/  /'; halt "the launcher did not start the seat (.claude/genesis-launch.log; GETTING-STARTED, Troubleshooting)"; }
    grep -E '^session' .claude/genesis-launch.log | sed 's/^/  /'
    say "foundation is running as $sess."
    say "End this session with /exit, then: tmux attach -t =$sess and read the header before you type."
    return 0
  fi
  say "launching foundation attached: this window becomes the seat's session $sess. Read the header before you type."
  exec ./launch-orc.sh
}

# ---- the one-command form: genesis.conf, then every Part 1 step that is still undone -------------------------------------
verb_all() {
  local m k v
  [ -f "$ROOT/genesis.conf" ] || halt "genesis.conf is absent: the Phase 4 session writes it (genesis.conf.example shows its eight lines); or run the steps by name"
  m="$(conf_missing | tr '\n' ' ')"
  [ -z "$m" ] || halt "genesis.conf lines missing or still a placeholder: $m"
  say "genesis.conf read: project $(conf_value PROJECT), remote $(conf_value REMOTE), six slots"
  manifest_verify || halt "the package does not verify; nothing is filled"
  for k in $(slot_names); do
    v="$(conf_value "$k")"
    unfilled_slots | awk '{print $1}' | grep -qx "$k" && verb_fill "$k" "$v" || say "slot $k: already filled"
  done
  verb_check || halt "not ready (the lines above name what is missing)"
  if [ -d "$ROOT/.git" ]; then say "seed: already done (this folder is a repository)"; else verb_seed "$(conf_value PROJECT)" "$(conf_value REMOTE)"; fi
  if [ -n "$(seat_field foundation 11)" ] && [ -s "$ROOT/_orchestration/seat-keys.tsv" ]; then say "enroll foundation: already done (its key is in seats.yaml and the registry)"; else verb_enroll foundation; fi
  verb_hooks
}

# ---- lane: Phase 5 Part 2, one provisioning set for a roster seat (foundation only) -----------------------------------------
verb_lane() {
  [ $# -eq 1 ] || halt "usage: lane <lane>"
  local lane="$1" branch arch operator project parent wt blob now out sw handoff stampf rman cand_s cand_p cand_t cand_c cand_n cand_ref
  need git; need ssh-keygen
  [ -d "$ROOT/.git" ] || halt "not a repository yet: run bash genesis.sh first"
  bash scripts/resolve-lane.sh 2>/dev/null | grep -q '^lane=foundation' || halt "lane runs only in foundation's worktree (scripts/resolve-lane.sh must say lane=foundation here)"
  [ -x "$ROOT/.git/hooks/pre-commit" ] && [ -x "$ROOT/.git/hooks/post-commit" ] || halt "the hooks are not armed yet: run bash genesis.sh hooks first (a provisioning set lands only through them)"
  seats_ok || halt "seats.yaml is not complete; run: bash genesis.sh check"
  [ "$lane" != foundation ] || halt "foundation is stood up by seed, enroll and hooks, not by lane"
  [ "$(read_seats | awk -F'\t' -v l="$lane" '$2==l{print $12; exit}')" != chat ] || halt "$lane is a chat seat (surface: chat) in seats.yaml: it has no worktree and no key; nothing to provision"
  [ -n "$(seat_field "$lane" 1)" ] || halt "no seat named '$lane' in seats.yaml; the roster is the source of truth: add it there first, then lane"
  branch="$(seat_field "$lane" 6)"; arch="$(seat_field "$lane" 3)"; operator="$(seat_field "$lane" 4)"; sw="$(seat_field "$lane" 7)"
  # the class decides two things: the stamp's handoff, and how the stamp reaches the branch (step 6)
  if [ "$sw" = apply-receipts-only ]; then handoff="ledger/apply-receipts/"; stampf="$ROOT/.claude/genesis-stamp-$lane.md"
  else sw=DENY; handoff="_orchestration/relay-outbox/$lane/LATEST.md"; stampf=""; fi
  [ -f "$ROOT/_boot/CHARTER-$lane.md" ] || halt "no _boot/CHARTER-$lane.md: the charter precedes provisioning (canon section 7.2); ask your chat architect for it, place it there, then run lane again"
  parent="$(dirname "$ROOT")"; wt="$parent/$lane"
  local resume=0
  if ! awk -F'|' -v l="$lane" '/^\|/ {a=$2; gsub(/^[ \t]+|[ \t]+$/,"",a); if (a==l) f=1} END{exit f}' "$ROOT/_orchestration/lane-provisioning.md"; then
    # the row is on the spine: either the lane is provisioned, or an earlier run landed the set and stopped before the lane signed
    if [ -e "$wt" ] && { [ -f "$wt/_boot/BOOTSTRAP.md" ] || [ -n "$stampf" ]; } && { [ -z "$stampf" ] || [ -f "$stampf" ]; } && ! git -C "$wt" log --format=%s 2>/dev/null | grep -q "^provision $lane: identity stamp"; then
      resume=1; say "resuming $lane: its row and its worktree exist and its stamp is not yet committed with its own key; the set is not re-landed"
    else
      halt "$lane already has a row in _orchestration/lane-provisioning.md: it is provisioned. For its key only: bash genesis.sh enroll $lane; for its confirmation: bash genesis.sh hooks"
    fi
  fi
  if [ "$resume" = 0 ]; then
  [ ! -e "$wt" ] || halt "$wt already exists; a provisioning set creates the worktree, so remove or rename what is there first"
  git -C "$ROOT" diff --cached --quiet || halt "the index is not empty: commit or unstage what is staged, so the provisioning set lands alone"
  git -C "$ROOT" remote get-url origin >/dev/null 2>&1 || halt "no remote named origin: the lane's commits are judged against the spine at origin/main"
  project="$(bash scripts/resolve-project.sh 2>/dev/null)"; project="${project#project=}"
  [ -n "$project" ] || halt "the project token could not be read from _boot/BOOTSTRAP.md"
  say "provisioning set for $lane: worktree $wt on branch $branch (archetype $arch, operator $operator, project $project)"
  # 1. the worktree, by the engine's own reaper (foundation-only; it stamps the owner and logs the act)
  out="$(bash scripts/reaper.sh add "$wt" "$branch" 2>&1)" || { printf '%s\n' "$out" | tail -3 | sed 's/^/  /'; halt "scripts/reaper.sh add refused (the lines above say why)"; }
  printf '%s\n' "$out" | grep -E '^added worktree' | sed 's/^/  /'
  [ -d "$wt" ] || halt "the worktree was not created at $wt"
  # 2. the lane's identity stamp (the shape the engine's lane stamps carry). A DENY lane's stamp is written in its own worktree and
  #    committed below by the lane's key. The executor's class may commit nothing outside ledger/apply-receipts/, so its stamp is
  #    written beside foundation (.claude/, ignored by git), never into its worktree, and reaches its branch in step 6 by the adopt.
  rman=""
  if [ -n "$stampf" ]; then
    cp -p "$wt/_boot/BOOTSTRAP.md" "$stampf" || halt "could not copy the stamp template to $stampf"
    rman="$(cd "$ROOT" && bash scripts/rules_manifest.sh 2>/dev/null)"; [ -n "$rman" ] || halt "scripts/rules_manifest.sh printed no hash"
  fi
  $PY - "${stampf:-$wt/_boot/BOOTSTRAP.md}" "$lane" "$arch" "$branch" "$project" "$sw" "$handoff" "$rman" <<'EOF' || halt "could not write the lane's stamp"
import sys
p, lane, arch, branch, project, sw, handoff, rm = sys.argv[1:9]
t = open(p, encoding='utf-8').read().split('\n')
want = {'lane': lane, 'role': arch, 'bootstrap_version': '1', 'spine_write': sw, 'worktree_branch': branch,
        'project': project, 'handoff': handoff}
if rm: want['rules_manifest'] = rm
d = 0; end = None
for i, l in enumerate(t):
    if l.startswith('---'):
        d += 1
        if d == 2: end = i
        continue
    if d != 1: continue
    k = l.split(':', 1)[0]
    if k in want: t[i] = k + ': ' + want.pop(k)
if 'rules_manifest' in want and end is not None: t.insert(end, 'rules_manifest: ' + want.pop('rules_manifest'))
if want: print('GENESIS: stamp keys absent from the front matter:', sorted(want)); sys.exit(1)
open(p, 'w', encoding='utf-8').write('\n'.join(t)); print('GENESIS: stamped ' + lane + "'s _boot/BOOTSTRAP.md (lane " + lane + ', spine_write ' + sw + ', branch ' + branch + ')')
EOF
  blob="$(git hash-object "${stampf:-$wt/_boot/BOOTSTRAP.md}")"
  # 3. the row on the spine, the lane's inbound surface, the charter
  now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  $PY - "$ROOT/_orchestration/lane-provisioning.md" "| $lane | $branch | 1 | $sw | $blob | $now | $operator |" <<'EOF' || halt "could not write the provisioning row"
import sys
p, row = sys.argv[1:3]; t = open(p, encoding='utf-8').read().split('\n')
last = max(i for i, l in enumerate(t) if l.startswith('|'))
t.insert(last + 1, row); open(p, 'w', encoding='utf-8').write('\n'.join(t)); print('GENESIS: ' + row.split('|')[1].strip() + "'s row written to _orchestration/lane-provisioning.md (stamp blob " + row.split('|')[5].strip()[:12] + ')')
EOF
  mkdir -p "$ROOT/_orchestration/relay-inbox/$lane" && : > "$ROOT/_orchestration/relay-inbox/$lane/.gitkeep"   # .gitkeep: the name the shipped readers (scripts/inbox.sh, scripts/status.sh) skip
  say "_orchestration/relay-inbox/$lane/ created on the spine (only foundation writes there; the lane's outbox lives on its branch and scripts/pending-set.sh creates it at first use)"
  git -C "$ROOT" add "_orchestration/lane-provisioning.md" "_orchestration/relay-inbox/$lane/.gitkeep" "_boot/CHARTER-$lane.md"
  git -C "$ROOT" add -u -- _orchestration/decision-log.md ledger/reaper-runs.log 2>/dev/null   # the reaper's own record of the act, when it wrote one
  # 4. the key, recorded and staged with the set
  IN_LANE=1; verb_enroll "$lane"; IN_LANE=0
  # 5. the set lands: foundation's one signed commit through the armed hooks, pushed
  say "committing the provisioning set on main through the armed hooks (foundation's signed commit)"
  git -C "$ROOT" commit -q -m "provision $lane: worktree on $branch, stamp blob $blob, charter, inbox, key row (genesis.sh lane)" > "$ROOT/.claude/genesis-lane.log" 2>&1 \
    || { grep -E 'REJECT|SEAT-KEYS: hook-precommit' "$ROOT/.claude/genesis-lane.log" | head -3 | sed 's/^/  /'; halt "the provisioning commit was refused (.claude/genesis-lane.log names it)"; }
  grep -o 'SEAT-KEYS: hook-precommit [A-Z]*' "$ROOT/.claude/genesis-lane.log" | head -1 | sed 's/^/  /'
  git -C "$ROOT" push -q origin main || halt "push of main failed; the set is committed on main. Push it by hand from foundation (git push origin main), then run: bash genesis.sh lane $lane, which resumes at the lane's signing step"
  say "the set landed as foundation's commit $(git -C "$ROOT" rev-parse --short HEAD), pushed to origin/main"
  # 5b. the lane's branch was cut before the set landed; fast-forward it so the lane's own tree carries its charter, its row and its inbox
  #     (a DENY lane only: the executor's class reaches the landed set through its adopt in step 6, which takes the place of this)
  if [ -z "$stampf" ]; then
  git -C "$wt" merge -q --ff-only main >/dev/null 2>&1 || halt "could not fast-forward $wt to the landed set (git -C $wt merge --ff-only main); the lane's tree must carry its own charter before it boots"
  say "$lane's branch fast-forwarded to the landed set: its tree carries _boot/CHARTER-$lane.md and its provisioning row"
  fi
  fi
  if [ "$resume" = 1 ]; then
    git -C "$ROOT" push -q origin main || halt "push of main failed; push it by hand from foundation (git push origin main), then run: bash genesis.sh lane $lane"
    branch="$(git -C "$wt" rev-parse --abbrev-ref HEAD 2>/dev/null)"; [ -n "$branch" ] || halt "could not read the branch of $wt"
    if [ -n "$stampf" ]; then   # the executor's class: the stamp written before the set, and the blob its row names
      blob="$(git hash-object "$stampf")"
      [ "$blob" = "$(awk -F'|' -v l="$lane" '/^\|/ {a=$2; gsub(/^[ \t]+|[ \t]+$/,"",a); if (a==l) {b=$6; gsub(/^[ \t]+|[ \t]+$/,"",b); print b; exit}}' "$ROOT/_orchestration/lane-provisioning.md")" ] \
        || halt "$stampf is not the stamp blob $lane's provisioning row names; restore it from that blob (git cat-file blob <row blob> > $stampf), then run lane again"
    fi
  fi
  # 6. the lane signs: its signing configuration in its worktree, its stamp committed with its own key, its branch pushed
  # (the registry is read at origin/main: the lane's branch was cut before the set landed, so its own tree does not carry the row yet)
  # setup-signing binds the key to the lane the worktree resolves, from the worktree's own stamp. The executor's class stamp is not on
  # its branch until the adopt, and the adopt needs no local change to the stamp; so the class stamp is in the worktree only while
  # setup-signing binds, and the branch's copy is restored before the adopt.
  if [ -n "$stampf" ]; then cp "$stampf" "$wt/_boot/BOOTSTRAP.md" || halt "could not place the class stamp in $wt for setup-signing"; fi
  out="$(cd "$wt" && bash scripts/seat-keys.sh setup-signing "$lane" --ref origin/main 2>&1)" || { [ -z "$stampf" ] || git -C "$wt" checkout -q HEAD -- _boot/BOOTSTRAP.md; printf '%s\n' "$out" | grep 'SEAT-KEYS' | tail -1 | cut -c1-200 | sed 's/^/  /'; halt "setup-signing failed for $lane in $wt (the line above says why)"; }
  printf '%s\n' "$out" | grep -o 'SEAT-KEYS: setup-signing PASS' | head -1 | sed 's/^/  /'
  if [ -n "$stampf" ]; then git -C "$wt" checkout -q HEAD -- _boot/BOOTSTRAP.md || halt "could not restore $wt/_boot/BOOTSTRAP.md from its branch before the adopt"; fi
  if [ -z "$stampf" ]; then
  git -C "$wt" add _boot/BOOTSTRAP.md
  git -C "$wt" commit -q -m "provision $lane: identity stamp (signed with the lane's key)" > "$ROOT/.claude/genesis-lane-stamp.log" 2>&1 \
    || { grep -E 'REJECT|SEAT-KEYS: hook-precommit' "$ROOT/.claude/genesis-lane-stamp.log" | head -3 | sed 's/^/  /'; halt "the lane's stamp commit was refused in $wt (.claude/genesis-lane-stamp.log names it)"; }
  grep -o 'SEAT-KEYS: hook-precommit [A-Z]*' "$ROOT/.claude/genesis-lane-stamp.log" | head -1 | sed 's/^/  /'
  else
  # 6 (the executor's class; origin ruling 0565 R2). Foundation cuts C: parents (P, S), where P is the lane branch's tip (the trunk
  # commit it was cut at) and S the landed set on origin/main; tree = S's tree with _boot/BOOTSTRAP.md replaced by the class stamp
  # and nothing else; signed with the trunk's key; at refs/heads/foundation/<lane>-sync-candidate-<n>, pushed. The lane then makes
  # its own signed A from C (scripts/seat-keys.sh adopt-candidate) and fast-forwards to it; C never lands on the lane's branch.
  git -C "$wt" diff --quiet -- _boot/BOOTSTRAP.md && git -C "$wt" diff --cached --quiet -- _boot/BOOTSTRAP.md || halt "$wt has a local change to _boot/BOOTSTRAP.md; the adopt fast-forwards over it: restore it (git -C $wt checkout -- _boot/BOOTSTRAP.md), then run lane again"
  [ "$(git hash-object "$stampf")" = "$blob" ] || halt "the stamp at $stampf is not the blob the provisioning row names ($blob)"
  [ "$(cd "$ROOT" && bash scripts/rules_manifest.sh 2>/dev/null)" = "$(awk '/^---/{d++; next} d==1 && index($0,"rules_manifest:")==1{sub("^rules_manifest:[[:space:]]*",""); print; exit}' "$stampf")" ] \
    || halt "the stamp's rules_manifest is not scripts/rules_manifest.sh over the landed set; the rule surfaces changed since the stamp was written"
  cand_s="$(git -C "$ROOT" rev-parse origin/main)"; cand_p="$(git -C "$wt" rev-parse HEAD)"
  [ "$cand_p" != "$cand_s" ] && git -C "$ROOT" merge-base --is-ancestor "$cand_p" "$cand_s" || halt "$lane's branch tip $cand_p is not a strict ancestor of origin/main $cand_s; the first-provisioning candidate needs it to be"
  git -C "$ROOT" hash-object -w "$stampf" >/dev/null || halt "could not write the stamp's blob"
  cand_t="$(GIT_INDEX_FILE="$ROOT/.git/genesis-cand.index" sh -c 'git -C "$1" read-tree "$2" && git -C "$1" update-index --cacheinfo "100644,$3,_boot/BOOTSTRAP.md" && git -C "$1" write-tree' _ "$ROOT" "$cand_s" "$blob")"; rm -f "$ROOT/.git/genesis-cand.index"
  [ -n "$cand_t" ] || halt "could not build the candidate's tree"
  [ -z "$(git -C "$ROOT" diff --no-renames --name-only "$cand_s" "$cand_t" | grep -vx '_boot/BOOTSTRAP.md')" ] || halt "the candidate's tree differs from the landed set outside _boot/BOOTSTRAP.md"
  cand_c="$(git -C "$ROOT" commit-tree -S "$cand_t" -p "$cand_p" -p "$cand_s" -m "provision $lane: identity stamp (class $sw; a trunk-signed sync candidate, adopted by the lane's own key)" 2>"$ROOT/.claude/genesis-lane-stamp.log")" \
    || halt "foundation could not sign the candidate (.claude/genesis-lane-stamp.log names it)"
  cand_n=1; while git -C "$ROOT" rev-parse -q --verify "refs/heads/foundation/$lane-sync-candidate-$cand_n" >/dev/null; do cand_n=$((cand_n+1)); done
  cand_ref="refs/heads/foundation/$lane-sync-candidate-$cand_n"
  git -C "$ROOT" update-ref "$cand_ref" "$cand_c" "" || halt "could not write $cand_ref"
  git -C "$ROOT" push -q origin "$cand_ref:$cand_ref" >> "$ROOT/.claude/genesis-lane-stamp.log" 2>&1 || halt "push of $cand_ref failed (.claude/genesis-lane-stamp.log names it)"
  say "foundation cut and pushed $lane's sync candidate $cand_ref ($(git -C "$ROOT" rev-parse --short "$cand_c"); parents ${cand_p:0:9} ${cand_s:0:9}; the set's tree with the class stamp)"
  out="$(cd "$wt" && bash scripts/seat-keys.sh adopt-candidate "$cand_ref" 2>&1)" || { printf '%s\n' "$out" | grep 'SEAT-KEYS' | tail -2 | cut -c1-220 | sed 's/^/  /'; halt "adopt-candidate refused in $wt (the lines above say why)"; }
  printf '%s\n' "$out" | grep -o 'SEAT-KEYS: adopt-candidate PASS' | head -1 | sed 's/^/  /'
  [ "$(git -C "$wt" rev-parse HEAD:_boot/BOOTSTRAP.md)" = "$blob" ] || halt "$lane's branch does not carry the stamp blob its row names after the adopt"
  fi
  git -C "$wt" push -q -u origin "$branch" || halt "push of $branch failed"
  say "$lane resolves in its worktree as: $(cd "$wt" && bash scripts/resolve-lane.sh 2>&1 | grep -o 'lane=[a-z0-9-]*' | head -1)"
  out="$(bash scripts/seat-keys.sh confirm-lanes 2>&1)"; printf '%s\n' "$out" | grep -o 'SEAT-KEYS: confirm-lanes [A-Z]*.*' | sed 's/^/  /'
  # the gate is the seat just provisioned; another lane whose worktree was reaped after its work merged prints UNCONFIRMED above
  # and is not this set's to fix (bash genesis.sh hooks prints every lane's confirmation)
  printf '%s\n' "$out" | grep -q "^SEAT-KEYS: confirm-lanes CONFIRMED $lane " || halt "$lane is not CONFIRMED by scripts/seat-keys.sh confirm-lanes after its set (its line above says why)"
  say "NOTE: the auditor wrote to ledger/audit-findings.md and ledger/audit-runs.log at the set's commit; foundation commits them as its records."
  say "DONE lane $lane. Its operator launches it from $wt with ./launch-orc.sh (session $project-$lane); its first turn runs scripts/inbox.sh and prints INBOX-CHECK: $lane empty until the first relay lands (the folder's .gitkeep marker is not a relay). When every seat in seats.yaml is provisioned: the seeded-fault proof (ADOPTION-COVER.md, Phase 5)."
}

# ---- explain ------------------------------------------------------------------------------------------------------------
verb_explain() {
cat <<'EOF'
genesis.sh writes these files and nothing else. Every one is your project's record or a slot you named.

(no argument)  reads genesis.conf: PROJECT=<token>, REMOTE=<url or path>, and the six slots of _index/adopter-slots.tsv by
           name (COST_CAP_PER_UNIT_USD, COST_CAP_PER_COHORT_USD, PROJECT_AGENT_ALLOWLIST, TRUNK_BRANCH, SEAT_KEYS_DIR_NAME,
           PROJECT_SKILL_NAMES); verifies MANIFEST.sha256 at a fresh unzip (the marker under check); then runs, in order, each step
           that is still undone: fill, check, seed, enroll foundation, hooks, launch. It writes nothing else of its own:
           every file below is written by the step named.
check    .claude/genesis-manifest-verified, a timestamp, written when it verifies MANIFEST.sha256 at a fresh unzip (the one
           command and a named check each write it; the two files Phase 4 replaces are skipped); nothing else (it also refuses by name an allow-listed subagent with no
           .claude/agents/<name>.md: SUBAGENTS.md).
fill     the files _index/adopter-slots.tsv names for the slot you give: the double-brace SLOT token is replaced in place.
seed     _boot/BOOTSTRAP.md (front matter: lane foundation, role integrator, bootstrap_version 1, spine_write ALLOW,
           worktree_branch main, your project token, handoff dispatch/LATEST.md)
         every path _index/engine-paths.tsv declares as fill, created empty (PENDING-SET.md with its two section headers)
         _orchestration/decision-log.md, ledger/receipts.jsonl, ledger/audit-findings.md, ledger/audit-runs.log (empty)
         _rulings/ (empty) and six lines in .gitignore (.claude/* with three exceptions, ledger/doorbell.log, .tmp/)
         _boot/CHARTER-foundation.md: the one entry in the state-source map that nothing creates is removed
         dispatch/LATEST.md and CHECKLIST.md: their first NOW, NEXT and plan lines
         _orchestration/lane-provisioning.md: foundation's row (the stamp's git blob id, the UTC time, the operator)
         git init on main; the genesis commit; CHECKLIST.md's absorbed_through_sha stamped with it, in a second commit;
           the remote origin added and main pushed when you give one
enroll   seats.yaml: the seat's public_key, login and host (the private key is written outside every worktree by
           scripts/seat-keys.sh keygen and is never committed)
         _orchestration/seat-keys.tsv and seat-keys-revoked.txt: derived whole from seats.yaml; committed only while no
           hook is armed (foundation's own enrollment); afterwards staged, for foundation to commit through the armed
           hooks (lane does this inside the seat's provisioning set)
         the worktree's signing configuration (scripts/seat-keys.sh setup-signing)
hooks    .git/hooks: five files by the two installers (pre-commit, commit-msg, pre-merge-commit, pre-push; post-commit),
           never versioned; CHECKLIST.md re-stamped and its first item checked, committed through the armed hooks as the
           first signed commit; then the launch (./launch-orc.sh: attached from a terminal; detached from inside a Claude
           Code session, with the two lines to follow). Run again with the hooks already armed, it installs nothing,
           commits nothing, prints the lane confirmation and the boot check, and launches unless --no-launch
lane     <parent>/<lane>: the worktree on the seat's branch (scripts/reaper.sh add), and in it _boot/BOOTSTRAP.md (lane,
           role from the roster's archetype, bootstrap_version 1, spine_write DENY, the branch, your token, handoff
           _orchestration/relay-outbox/<lane>/LATEST.md), committed on the lane's branch with the lane's own key;
         for the executor's class (spine_write: apply-receipts-only in seats.yaml) the stamp carries that class, handoff
           ledger/apply-receipts/ and rules_manifest; it is written first to .claude/genesis-stamp-<lane>.md (ignored by git),
           then foundation signs a sync candidate at refs/heads/foundation/<lane>-sync-candidate-<n> (pushed), and the
           lane's own key adopts it (scripts/seat-keys.sh adopt-candidate): the stamp lands on the branch as the lane's commit;
           .claude/genesis-lane.log and .claude/genesis-lane-stamp.log, the two commits' hook output (ignored by git)
         on main: the lane's row in _orchestration/lane-provisioning.md (the stamp's blob), _orchestration/relay-inbox/<lane>/
           (the lane's inbound surface; only foundation writes there), _boot/CHARTER-<lane>.md staged (you placed it),
           the key row (enroll), the reaper's log lines: one signed commit by foundation through the armed hooks, pushed
         the lane's signing configuration in its worktree; its branch pushed. No agent definition is written: the shipped
           .claude/agents/orc.md resolves to every seat by location, and the launcher picks it for every lane but architect

Why these and not more: canon section 11 says the onboarding verb "generates the governance files and hand-writes
none of them". Everything above is a generated record of your own decisions (seats.yaml, genesis.conf, the slots, the
project token, the charters you placed) or an empty file the shipped scripts append to. No engine file is rewritten.
EOF
}

case "${1:-}" in
  "")      verb_all ;;
  check)   verb_check ;;
  fill)    shift; verb_fill "$@" ;;
  seed)    shift; verb_seed "$@" ;;
  enroll)  shift; verb_enroll "$@" ;;
  hooks)   shift; verb_hooks "$@" ;;
  lane)    shift; verb_lane "$@" ;;
  explain) verb_explain ;;
  *) sed -n '2,13p' "$0"; exit 2 ;;
esac
