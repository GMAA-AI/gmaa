# COORDINATION.md — repo-as-shared-truth protocol

**Author:** Product Architect
**Date:** 2026-05-28
**Status:** v1.0 — operator binds
**Companion:** `SYSTEM_ARCHITECTURE` (carries a pointer to this doc; this doc is authoritative for coordination)

---

## §0 — project-specific; an adopter writes its own (canon §7, §12)

## §1 — project-specific; an adopter writes its own (canon §7, §12)

### §1.X — project-specific; an adopter writes its own (canon §7, §12)

## §2 — project-specific; an adopter writes its own (canon §7, §12)

### §2.X — project-specific; an adopter writes its own (canon §7, §12)

## §3 — Canonical surfaces (read-first)

1. **`STATE.md`** (integrator-written; the existing authoritative-writer contract). Pins **current HEAD SHA** + **the deployed SHA**. Updated on every state transition. This is the anti-stale-premise surface — read it FIRST; if your local read lags the pinned SHA, re-sync before acting.
2. **Decision-log** (integrator-maintained; `_orchestration/decision-log.md`). One line per cross-agent ask:
   `id | from→to | ask | owner | STATUS ∈ {OPEN, ACTED, SUPERSEDED, CLOSED} | note`
   The **feedback edge** is the part that was missing: when an implementer takes a better path than a relay prescribed, they mark that relay **SUPERSEDED + one-line why** — closing the loop to the author instead of going dark.
3. **Lane table** (§1 of this doc; the project's own).

One log, not a pile of `dispatch/` files a reader's tool truncates.

---

## §4 — Protocols

1. **Read-first.** Read `STATE.md` (+ relevant contracts) before acting. Treat a read older than the pinned HEAD SHA as stale.
2. **Relay → logged.** Every cross-agent ask gets a decision-log line with a STATUS. Supersession is explicit (§3.2), never silent.
3. **Freshness guard.** Before lifting another lane's output (port/vendor), check its version marker / SHA. No porting behind the author's current state (the bundle-drift fix).
4. **One-owner-per-surface** (§1).
5. **Altitude (the recalibration).** The architect specifies *contract, invariant, acceptance, verify-gates, architecture* — **not** implementation mechanism. The implementer, with live context, owns mechanism and is free to improve on it (marking the relay SUPERSEDED per §3.2). Constraints (LIVE-DATA-ONLY, sproc-only, source-of-truth) are *not* mechanism and remain binding.

---

## §5 — Self-enforcement

The auditor catches `STATE.md`-propagation misses but they can sit PENDING. Wire a standing check into the auditor runlist: **a state-changing commit that doesn't update `STATE.md` (and the decision-log, where a relay status changed) is flagged loud at commit.** This turns recurring propagation misses from PENDING findings into a blocking gate — the protocol holds itself up instead of relying on memory.

---

## §6 — Operator role

The operator **binds decisions** (the things only the operator can bind) and steps out of being the **transport layer** for routine state — which now lives in the repo. The operator still carries architect↔integrator and chat-class-seat→integrator where a committer is needed, and stays in the loop for urgent or ambiguous routing. Fewer paste-carries, same authority.

---

### §4.3.X — project-specific; an adopter writes its own (canon §7, §12)

## §7 — project-specific; an adopter writes its own (canon §7, §12)

## §8 — project-specific; an adopter writes its own (canon §7, §12)

## §9 — project-specific; an adopter writes its own (canon §7, §12)

## §10 — project-specific; an adopter writes its own (canon §7, §12)

## §11 — Parallel-spawn pattern and mechanism ownership

**Disjoint-scope parallel spawning needs no per-spawn ratify.** Tracks can spawn in parallel when their file scope is provably disjoint (substrate/backend, view layer, docs are the usual partition; the project declares its own).

> **Extended by §13(4):** disjointness is judged on TWO surfaces — code scope AND spine-write target — not file scope alone. The §11 parallel-spawn pattern is otherwise unchanged.

Files that several workers must extend (shared registration or index files) serialize those workers; workers on separate files do not conflict. When a track lands, the next worker in queue may spawn.

**Bytes and mechanism are the implementer's.** The implementer with live context owns the bytes and the mechanism and is free to improve on what a relay prescribed (marking it SUPERSEDED per §3.2); the architect specifies contract, invariant and acceptance (§4.5).

## §12 — project-specific; an adopter writes its own (canon §7, §12)

---

## §13 — Integrator operating clauses (Slice 0)

**Authority:** chat-Architect 2026-06-22; AOA §11 chain (§11.1 scope ratified 2026-06-22). Class A. Extends §1 one-owner-per-surface to the full spine; consistent with the project's lane table.

**(1) Spine + single writer:**
- Spine = integration trunk, the one database, the append-only receipts ledger, the work-package DAG, `issues_register.md`, `CHECKLIST.md`, the frozen contracts, `_orchestration/STATE.md` + the decision-log. Read by all lanes; written only by the integrator.
- **Shared substrate + D3 enforcement [amended 2026-06-24, chat-Architect]:** the integrator-owned write set is the spine above PLUS the shared substrate: the paths `contracts/MECH-WRITE.md` §1 names as spine-owned and the authz table (`_index/authz-enforcers.tsv`) denies to module lanes. The original §13(1) enumeration predated these being identified as integrator-owned — this records the gap-closure, NOT a new permission. The D3 pre-commit gate (`agents/pre-commit-hook.sh`, consuming `scripts/resolve-lane.sh`) fail-closed REJECTS any module-branch commit to a spine OR shared-substrate path; module-authored content to any of them is a PROPOSAL to the integrator via reap-at-merge, never a module spine-write. Decisive rationale for the substrate inclusion: `scripts/resolve-lane.sh` and the hooks are themselves part of the enforcement layer — a module-writable enforcement layer would be a guard able to disable its own guard.
- Foundation orc = sole integrator and sole committer to the spine. The architect and the chat-class seats read and propose; never commit. Frozen-contract changes need architect ratification, then the integrator commits.
- **Designation ↔ path note:** a seat's display label (for example the chat architect seat's) may change over time. Dated references in landed rulings/dispatches/receipts keep their era's title (correct history). **Infrastructure PATHS are NOT renamed** — `relay-outbox/architect/`, `relay-inbox/…`, queue filenames, and agent-def paths stay; renaming a live path for a label breaks tooling and is barred. Label may change; paths unchanged.
- Monotonic issue counter, single ledger append, single DAG update are safe by construction: exactly one writer.

**(2) Per-track boot context [extended 2026-06-23 — location-bootstrap, AOA §11 chain]:**
- Identity bootstraps from LOCATION, not from chat. Foundation provisions each lane's stamped `_boot/BOOTSTRAP.md` at a fixed worktree-relative path before the seat boots, and records the lane in the spine manifest `_orchestration/lane-provisioning.md` {lane, branch, bootstrap_version, `git hash-object` blob, provisioned_utc}.
- A cold seat's FIRST action resolves its lane from its OWN worktree (`scripts/resolve-lane.sh`: worktree-root → `_boot/BOOTSTRAP.md` → stamped lane), adopts that identity, and emits `BOOT-ACK: lane=… version=… blob=…`. It never infers identity from chat and never inherits the generic contract as foundation.
- The resolver cross-checks the stamped `lane` against the worktree's actual branch (`main`→foundation, `module/<x>`→`<x>`); mismatch = HALT. Location and stamp mutually confirm.
- No `_boot/BOOTSTRAP.md` at the fixed path → HALT (do not guess; do not assume integrator/foundation).
- A module orc acts ONLY on its own `_boot/BOOTSTRAP.md` (`spine_write: DENY`), commits only to its own worktree branch, and never applies to the spine.
- `_boot/**` is lane-provisioning metadata, NOT module work-product → integration-EXCLUDED. The one shared post-commit hook resolves the committing LANE via the same resolver against the committing-worktree root (never trunk/cwd), so it stamps each lane's audit record with that lane's identity.

**(3) Merge-order:**
- The integrator merges module work into the spine in CHECKLIST dependency order; foundation changes land before the site work that depends on them. Gate per item, not per tier.

**(4) Integrator validation gate:**
- Disjointness is judged on TWO surfaces: code scope AND spine-write target. Fan out to parallel-validate subagents only when both are provably disjoint; otherwise serialize. Validation parallel, commit always serial. Subagents return results; the integrator unions the ledger in one append, applies migrations in dependency order, updates the DAG once. Default to serial whenever disjointness cannot be proven.

> **§13(4) ↔ §11 cross-ref:** §13(4) EXTENDS the §11 disjoint-scope test to TWO surfaces (code scope AND spine-write target). The §11 parallel-spawn pattern is otherwise unchanged.

**(5) Push-at-close — origin durability [amended 2026-06-25, chat-Architect ratified]:**
- Integrator duty = commit AND keep origin current. **"landed + sealed" means origin-durable, not local-only.** Root cause: the commit/seal/reap cadence had NO push step → origin fell behind the local trunk. The fix folds push INTO the close.
- The shared post-commit hook (`agents/post-commit-hook.sh`) performs a plain fast-forward `git push origin <branch>` at the close of every non-`[audit]` commit: **foundation** pushes `main` after the reap-seal; a **module** lane pushes its own `module/<x>` branch after the marker. Each sealed/marked unit is a clean fast-forwardable checkpoint.
- **NEVER `--force` in the cadence.** A non-fast-forward push failure is a STOP-and-surface event (history divergence = a merge/reconcile decision), not a retry and never a force.
- Push is **best-effort**: a landed commit cannot be unwound, so a failed push (network / non-ff) warns loud (does NOT fail the hook, does NOT unwind the commit) and is caught by the local-ahead-of-origin **drift surface** (`scripts/audit_issue_register.py` / standing probe flags `origin/main..main` > N at close) — never silently swallowed.
- The **terminal flush** (EOD / next-session start) seals AND pushes the last trailing unit (whose audit completes after its own commit's hook already ran).

---

## §14 — DISC-ORC-RUN-RELAY-FILE: durable end-of-run + on-idle relay (2026-07-06)

**Ratified:** operator-directed 2026-07-06 → chat-Architect ratified. **Rationale:** tmux panes are
ephemeral; reading-the-pane is a lossy, screenshot-mediated transport. Every orc-foundation turn ends
with a **DURABLE relay FILE** so the operator (and later an app surface) grabs a file, never the pane.

**TRIGGER — end of EVERY foundation run/turn, work OR idle. No turn ends without a written relay.**
No-fake-closure tie-in: the run-end file **IS the run's status-of-record**; a run with no relay file is
an **INCOMPLETE run** — same class as a payload written but never committed.
- **WORK turn** → full relay: `FROM/TO/RE` + status + any chat-bound relays + **evidence inline**
  (commit shas, receipt ids). Same format as the fenced paste-blocks.
- **IDLE turn** (nothing queued) → idle heartbeat: `FROM/TO/RE` + `STATUS: IDLE` + last-completed +
  what it's waiting on + `nothing queued`. Liveness signal — an idle orc is never silent (halt-loud
  analog: silent-idle is indistinguishable from stuck/dead).

**PATHS**
- `dispatch/LATEST.md` — ALWAYS the newest relay (stable path; the one place operator/app grabs).
- `dispatch/RELAY-TO-ARCHITECT-<UTC>-<slug>.md` — timestamped archive for history (work turns).

**MECHANICS (edge-triggered; COST-GUARD — no idle write-spam)**
- Exactly **ONE write per turn-end**. NOT a polling loop, NOT a re-fire while idle — one beat on
  *entering* idle, never a heartbeat loop.
- **Work turn:** write the timestamped archive + copy it to `LATEST.md`; **commit both with the run**
  (origin-durable, rides §13(5) push-at-close).
- **Idle beat (foundation's chosen mechanic):** update `dispatch/LATEST.md` **ONLY, worktree-local
  (uncommitted)** — swept into the next work-turn commit. No commit-per-beat (avoids a commit flood +
  idle-write-spam per COST-GUARD). The operator/app reads the working-tree `LATEST.md`, current even
  when uncommitted; origin-durability follows on the next work commit.
