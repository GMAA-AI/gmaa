# MECH-AUDIT — the post-commit code-Auditor: re-run, never trust; observe, never author

**Spec of record for MECH-AUDIT** (the ONLY document for this mechanism, ≤ 8 KB; `_index/mechanisms.tsv`
row `MECH-AUDIT`). Carries the E6b cost and off-switch text this mechanism requires. Prior text: git blob
`4f8286e8` (frame `git-blob` @ `612cc795`). Wiring: `agents/post-commit-hook.sh` (installed by
`scripts/install_post_commit_hook.sh`), role prompt `agents/audit-system-prompt.md`, probe roster
`agents/standing-probes.yaml`.

## §1 Identity and bounds (binding)
- Per commit a deterministic code pass (0 model calls); a **separate headless session** only on a path-trigger or
  daily (C′): `claude -p "<per-commit prompt>" --append-system-prompt
  "$(cat agents/audit-system-prompt.md)" --permission-mode bypassPermissions --output-format json --model "$AUDITOR_MODEL"`, backgrounded and
  disowned. The tier is an explicit `--model` from `AUDITOR_MODEL` (default set in the hook, nowhere else), never the account's user default. Its JSON goes to a temp file; `scripts/auditor-usage-record.sh` then writes one usage row to
  `ledger/auditor-usage.jsonl` and the result text to `ledger/audit-runs.log` (`agents/post-commit-hook.sh:384-386`). `bypassPermissions` is operator-bound (Fix A, 2026-05-25): the auditor needs
  live-surface Bash. Do not regress it to `acceptEdits`.
- **Writes only** `ledger/audit-findings.md` and `ledger/receipts.jsonl`, append-only. Never edits an artifact, never
  authors a fix, never closes work, never surfaces to the operator (findings route through the hub).
- **Re-runs, never trusts:** it invokes each cited probe itself and compares exit code + output hash. Reading the
  worker's captured output is record-keeping, not reproduction.

## §2 Per-commit protocol
1. Skip-guard: a commit whose subject starts `[audit]` triggers neither reap nor audit (no loop).
2. For each receipt this commit added: resolve `probe_path` (unresolvable → DIVERGED), re-run, hash, compare →
   `REPRODUCED` | `DIVERGED` | `WAIVED`. Emit a NEW receipt (`actor: code-Auditor`, `supersedes_receipt_id` = the
   worker receipt, `auditor_status`, `auditor_run_at_utc`, `auditor_notes`). Never edit a prior receipt.
3. Ring-0: re-run the static checks for the commit's own claims, with `file:line` evidence.
4. Standing probes: every `agents/standing-probes.yaml` entry not marked `exclude_from_auditor: true` (16 of 17 today).
   Emit a standing receipt only on FAIL outside its partial window / RUN_ERROR, a verdict change, a
   `cadence_emit_per_day` boundary, or a first-ever run. PASS on PASS emits nothing; the log line is the liveness.
5. Append one block to `ledger/audit-findings.md` naming the committing lane, ending `**Verdict for <sha>: …**`.

## §3 Reach and WAIVED
- **Can reach:** repo files, git history, re-runnable probes. **Cannot reach** (no credentials in its environment):
  the substrates `_index/substrates.tsv` declares beyond `git-spine`.
- `WAIVED` is an honest admission, a last resort, and names the unreached surface. A missing tool or env var the
  operator could provision is DIVERGED, not WAIVED.

## §4 Routing on verdicts
- `REPRODUCED` → the hub may merge / close. A REPRODUCED primary with a WAIVED sub-portion still closes, with the
  sub-portion recorded.
- `DIVERGED` → backward edge to IN_PROGRESS; the owning seat reworks. The divergence is the finding.
- `WAIVED` primary on a live-surface probe → **CLOSED-PROVISIONAL**, never plain CLOSED; independent verification is
  owed to the operator's spot audit. (The old 24-hour WAIVED→CLOSED rule is withdrawn: a fake-closure backdoor.)
- Standing `PASS` / `PARTIAL_FAIL_EXPECTED` route as REPRODUCED; `REGRESSION` / `RUN_ERROR` route as DIVERGED.
- A finding may carry a **DEMOTION CLAUSE** naming the condition under which it yields. The next audit resolves each
  open clause explicitly.

## §5 Sealing (reap-then-audit; single writer preserved)
- The auditor never commits. On finishing it writes `<git-common-dir>/audit-done/<sha>` (the lane).
- At each restart boundary `scripts/audit-seal.sh` (Stop hook) seals every completed foundation audit as ONE
  `[audit] seal (n=K) <shas>` commit, then pushes (MECH-AUDIT). A failed seal keeps its sentinels. A module
  lane's audit rides reap-at-merge. Attribution: an architect commit reaped onto the spine is charged to
  its git author, never to foundation as the reaping seat.
- One cure set per restart boundary.
- A run that never writes its sentinel is caught up by a later explicit audit, receipted `…-CATCHUP`.
- **So is a run that writes its sentinel with NO verdict** (`ISSUE-LLM-AUDITOR-VERDICTLESS-EXIT-2026-09-29`):
  its usage row carries `verdict: ABSENT` and `ledger/audit-runs.log` carries `LLM-AUDIT-NO-VERDICT: <sha>`. The next
  LLM run catches it up. Owed at landing: `0d81ec1e` (SET-0093) and `ec1a1a6b` (SET-0097).
  Also owed: `9920500a`, `a84713a9`, `cb284a5d`.

## §6 Cost and off switch (E6b)
- **Cost:** one headless model session per path-triggered or daily commit (C′). It runs keyless on the operator's Max plan (`.env`
  carries no API key), so the cost is plan quota plus wall-clock, not metered dollars. **Bar (E6b):** median ≤ 3 min,
  max ≤ 10 min per hub commit, measured by `probes/budget/probe_efficiency_budget.sh` from receipt time minus commit
  time. Status: RED (max 16.8 min at the baseline). **Tokens and $ per run: RECORDED** (SET-0067 recorder,
  `scripts/auditor-usage-record.sh`; rows in `ledger/auditor-usage.jsonl`, sealed with the audit since SET-0068).
  The $ bar is set from its first 20 rows; until 20 exist the bar is unset, not met.
- **Off switch: per-process only.** Exporting `AUDITOR_CMD` (`agents/post-commit-hook.sh:218`) off `PATH` skips
  only the model session; seal, doorbell and code audit still run. A test seam, not configuration: the skip is
  logged (stderr + `audit-runs.log`, `:396-417`) and the sentinel written (`:443`), but no catch-up follows. What is owed: a persistent, recorded switch that skips step §1's model session and nothing else. With the auditor off, the gate-tier checks
  still run on every commit — `pre-commit` (MECH-WRITE), the `commit-msg` creed scan, and the boot probes — so an
  adopter loses reproduction and standing-probe emission, not the write gates.

## §7 Operator verification (independence is operator-confirmed, not seat-asserted)
`diff .git/hooks/post-commit agents/post-commit-hook.sh` is empty (boot `HOOK-CHECK:` does NOT cover post-commit) · `tail
ledger/audit-runs.log` shows a run per commit · `ledger/audit-findings.md` carries a `Verdict for` block per commit ·
`grep -c '"actor": "code-Auditor"' ledger/receipts.jsonl` > 0 · `ps -ef | grep 'claude -p Audit commit'` shows the
run in its window · a probe re-run by hand matches the auditor's hash.

## §8 Enterprise lens
- **Server-side twin:** none. A CI job that runs the same audit on the pushed commit, holding its own credentials and
  writing to a ledger the seats cannot edit, is the twin (canon v1.6.6 candidate). Today the auditor runs on the
  committer's machine and its ledger lives in the same repo.
- **Identity source:** the lane is read from the committing worktree; the audit block and receipts carry it. Unsigned.
- **Role model:** Tier-3 observer. It cannot author, fix, close or escalate; the hub acts on its verdicts.
- **Install/upgrade path:** `scripts/install_post_commit_hook.sh`; hooks are shared across worktrees. Drift between the
  installed and canonical post-commit hook is checked only by hand (§7).
- **Harness binding:** Claude Code headless (`claude -p`, overridable via `AUDITOR_CMD`; an explicit `--model` from `AUDITOR_MODEL`, default in the hook) with an appended system
  prompt. It is the one mechanism in S that calls a model.

**Limit (verbatim):** *"S binds a seat that has not read it only to the extent its enforcer cannot be
bypassed by that seat. With local hooks (v1.6.5) that is an honest-operator property at n = 1; the server-side twin
(canon v1.6.6 candidate) is what makes it a guarantee."*

History: git log -- agents/auditor-contract.md · decision-log · _rulings/
