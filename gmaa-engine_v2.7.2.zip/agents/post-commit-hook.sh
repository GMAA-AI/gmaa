#!/usr/bin/env bash
# agents/post-commit-hook.sh — Slice-1 D1: lane-aware Auditor + GUARANTEED
# lane-stamped [audit] commit (reap-then-audit). Canonical source for
# .git/hooks/post-commit (installed via scripts/install_post_commit_hook.sh).
#
# Fires code-Auditor on every non-[audit] commit per agents/auditor-contract.md.
#
# D1 (chat-Architect RULING 2026-06-24): converts the separate-commit of the
# audit record from honor-system (A1/A2 gap) to GUARANTEED, while preserving
# single-writer (COORDINATION.md §13(1)) BY CONSTRUCTION:
#   - The audit record is produced ASYNC (backgrounded claude -p), so this commit
#     CANNOT commit its own audit synchronously. Instead, REAP-THEN-AUDIT:
#       (1) SEAL: NOT here any more (MECH-AUDIT). Completed foundation audits are
#           sealed ONCE per restart boundary by scripts/audit-seal.sh, run by the Stop
#           hook (scripts/seat-b6-stop.sh) before /exit; `audit-seal.sh manual` seals by
#           hand. FOUNDATION ONLY seals audits (sole spine/ledger committer). A module's
#           audit record rides reap-at-merge [C], committed by the integrator at merge.
#       (2) AUDIT: background the Auditor for THIS commit, lane-stamped; it writes
#           ledger/* + a completion sentinel, and NEVER self-commits.
#   - Unsealed foundation audits accumulate (as sentinels + ledger appends) until the
#     next restart boundary; a failed seal keeps them. Module-stream bound = merge cadence.
#
# Preserved from prior contract: [audit]-subject skip-guard (no audit loop);
# --permission-mode bypassPermissions (operator-bound Fix A 2026-05-25 — Auditor
# needs live-surface Bash; do NOT regress to acceptEdits); explicit PATH hardening
# (ISSUE-V2-INTEGRATOR-TRIGGER-LIVENESS ruling 1); conditional .env source (now
# keyless — .env carries no ANTHROPIC_API_KEY, so the Auditor runs Max-keyless).

set -u

REPO_ROOT="$(git rev-parse --show-toplevel)"
COMMIT_HASH="$(git rev-parse HEAD)"
COMMIT_SHORT="$(git rev-parse --short HEAD)"
COMMIT_SUBJECT="$(git log -1 --pretty=%s)"
CHANGED_FILES="$(git diff-tree --no-commit-id --name-only -r HEAD 2>/dev/null || echo '<initial commit; all files>')"
# Merge commit ([C] audit-at-merge): diff-tree shows nothing for merges, so audit the
# INCOMING change vs the first parent — this is the module work the integrator merged.
if git rev-parse -q --verify HEAD^2 >/dev/null 2>&1; then
    CHANGED_FILES="$(git diff --name-only HEAD^1 HEAD 2>/dev/null)"
fi

# === CREED-GATE BYPASS DETECTION (detection half;
#     cure text) ===
# commit-msg-hook.sh stamps `Creed-Gate: PASS <blob>` on every commit whose commit-msg run
# PASSED. A landed commit with no such trailer means commit-msg did NOT run for it
# (--no-verify / -n / -c core.hooksPath) — post-commit still fires under --no-verify, which is
# exactly why the check lives here. Detect-and-surface only: this commit ALREADY
# landed and cannot be unwound from here, so this block never blocks, never changes $? , and is
# defensively subshelled so it can never break the rest of this hook.
#
# SCOPE — does this apply to the [audit] seal commits? YES, untouched, no exemption: the boundary
# seal (scripts/audit-seal.sh) commits with no -n/--no-verify, so it runs through
# the installed commit-msg hook exactly like any other commit and picks up the trailer on PASS.
# There is no subject-prefix class here that skips commit-msg; the ONLY things that skip
# commit-msg are the flags this check exists to catch. (Module-lane MARKER commits below are
# likewise not exempted — they are plain `git commit`s too.)
(
    set +e
    _cgb_msg="$(git log -1 --format=%B HEAD 2>/dev/null)"
    if [[ "$_cgb_msg" != *"Creed-Gate: PASS"* ]]; then
        _cgb_log="$REPO_ROOT/.claude/creed-gate-bypass.log"
        mkdir -p "$(dirname "$_cgb_log")" 2>/dev/null
        _cgb_line="CREED-GATE-BYPASS: ${COMMIT_HASH} committed without the Creed-Gate trailer — the commit-msg gate did not run (--no-verify?)"
        echo "$_cgb_line" >&2
        printf '%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$_cgb_line" >> "$_cgb_log" 2>/dev/null
    fi
) || true

# === Skip-guard: [audit] commits trigger neither reap nor audit (no loop) ===
# Match commit SUBJECT prefix only (body-text matching caused false-skip 2026-05-25).
if [[ "$COMMIT_SUBJECT" =~ ^\[audit\] ]]; then
    exit 0
fi

# === Resolve the COMMITTING worktree's lane (D1 lane-aware; §13(2)) ===
# Same resolver the §0 cold-boot seat + D3 pre-commit consume; resolves THIS
# worktree's root, never trunk/cwd.
LANE="UNRESOLVED"
if [[ -x "$REPO_ROOT/scripts/resolve-lane.sh" ]]; then
    if LANE_LINE="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>/dev/null)"; then
        eval "$LANE_LINE"          # -> lane= role= version= spine_write= blob=
        LANE="${lane:-UNRESOLVED}"
    fi
fi
# Post-commit cannot unwind a landed commit; an unresolved lane does NOT block, but
# the audit record is stamped UNRESOLVED so the gap is loud, not silent.

# Completion sentinels live in the SHARED common git-dir (never tracked, shared by
# all worktrees), one file per audited SHA, content = the producing lane.
GIT_COMMON="$(git rev-parse --git-common-dir)"
case "$GIT_COMMON" in /*) : ;; *) GIT_COMMON="$REPO_ROOT/$GIT_COMMON" ;; esac
DONE_DIR="$GIT_COMMON/audit-done"
mkdir -p "$DONE_DIR"

# === Module lanes (audit-at-merge [C], architect ruling 2026-06-24): lightweight
#     lane MARKER ONLY — no reap, no auditor, NO module-side audit record. A module
#     commit is a PROPOSAL until merge; it is not audited until it becomes real on
#     the spine. The integrator re-audits incoming module commits AT MERGE
#     (scripts/reap_at_merge.sh) and emits the lane-stamped [audit] seal on main.
#     This keeps single-writer literal: nothing is produced cross-boundary to
#     transport or orphan. ===
if [[ "$LANE" != "foundation" ]]; then
    MARK_DIR="$GIT_COMMON/module-commits/$LANE"
    mkdir -p "$MARK_DIR"
    # TYPE the marker (architect RULING 3, 2026-06-24): a currency-sync commit is a spine->module
    # ADOPTION (it adopts the trunk; identity-preserve + rules re-stamp), NOT a module->main merge
    # candidate. Typing it kind=currency-sync-adoption lets any marker-driven merge-candidate scan
    # exclude it BY CONSTRUCTION (correctness via correct typing, not via cleanup — the gate does NOT
    # clean its own marker). NOTE: reap_at_merge.sh currently merges via rev-list (no marker scan), so
    # the kind is forward-correctness today; whether reap-at-merge should consume the kind is tracked
    # [C]-seam hygiene (surface for ratify before adding a marker-scan predicate).
    case "$COMMIT_SUBJECT" in
        currency-sync:*|currency:*) MARK_KIND="currency-sync-adoption" ;;
        *)                          MARK_KIND="module-work" ;;
    esac
    { printf 'kind=%s\n' "$MARK_KIND"; date -u +%Y-%m-%dT%H:%M:%SZ; } > "$MARK_DIR/$COMMIT_HASH" 2>/dev/null || true
    echo "[post-commit] lane=${LANE} ${COMMIT_SHORT} MARKED kind=${MARK_KIND} (audit-at-merge [C]: re-audited by integrator at merge; no module-side audit record)."
    # === PUSH-AT-CLOSE (module lane; §13(5) cadence fix 2026-06-25) ===
    # Keep the module branch origin-durable. Plain fast-forward; best-effort (a landed
    # commit cannot be unwound). NEVER --force (non-ff = STOP-and-surface, not retry).
    MBRANCH="$(git rev-parse --abbrev-ref HEAD 2>/dev/null)"
    if [[ -n "$MBRANCH" && "$MBRANCH" != "HEAD" ]]; then
        if env -u GIT_INDEX_FILE -u GIT_DIR -u GIT_WORK_TREE -u GIT_PREFIX git push origin "$MBRANCH" >/dev/null 2>&1; then
            echo "[post-commit] lane=${LANE} pushed ${MBRANCH} -> origin (module durability)."
        else
            echo "[post-commit] WARN lane=${LANE} push of ${MBRANCH} FAILED (commit is local-only; NOT unwound; do NOT --force). Drift surface will flag." >&2
        fi
    fi
    exit 0
fi

# === (1) REAP STEP — MOVED to the restart boundary (MECH-AUDIT) ===
# This hook no longer seals per commit. scripts/audit-seal.sh is the ONE seal writer: scripts/seat-b6-stop.sh
# runs it at the restart/shutdown boundary, before /exit, and it writes ONE `[audit] seal (n=K)` commit for every
# finished foundation sentinel (+ the lane's restart-ledger line). The audit itself still runs on EVERY commit
# (step 2 below). Sentinels accumulate in $DONE_DIR until that boundary; a failed seal KEEPS them (inv #5).
# Manual seal (e.g. an EOD flush without an exit): `bash scripts/audit-seal.sh manual`.
if [[ "$LANE" == "foundation" ]]; then

    # === (1b) PUSH-AT-CLOSE (foundation; §13(5) cadence fix 2026-06-25) ===
    # "landed + sealed" must mean origin-durable. Push the just-closed work commit
    # (+ any [audit] seal the reap just made) to origin as a plain fast-forward.
    # Best-effort: a landed commit cannot be unwound, so a failed push warns loud and
    # is caught by the local-ahead-of-origin drift surface. NEVER --force (a non-ff
    # push failure is a STOP-and-surface event — history divergence — not a retry).
    BRANCH="$(git rev-parse --abbrev-ref HEAD 2>/dev/null)"
    if [[ -n "$BRANCH" && "$BRANCH" != "HEAD" ]]; then
        if env -u GIT_INDEX_FILE -u GIT_DIR -u GIT_WORK_TREE -u GIT_PREFIX git push origin "$BRANCH" >/dev/null 2>&1; then
            echo "[post-commit] lane=foundation pushed ${BRANCH} -> origin (fast-forward; origin-durable)."
        else
            echo "[post-commit] WARN lane=foundation push of ${BRANCH} FAILED (commit is local-only; NOT unwound; do NOT --force). Drift surface will flag." >&2
        fi
    fi

    # === (1c) DOORBELL AUTO-FIRE — SPEC-DOORBELL v0.3 Ruling 2 (2026-07-01) ===
    # Judgment-free ENFORCEMENT of the producer-ring obligation (Ruling 1): for every
    # relay-inbox/<lane>/ path THIS commit touched, ring that lane so its first-action
    # INBOX-CHECK fires now (vs its next operator-spawned turn). The producer no longer
    # DECIDES whether to ring — the hook does it. Properties (architect refinement):
    #   - NON-BLOCKING: the commit already landed; this MUST NOT fail or hang the hook
    #     (subshell + set +e + `|| true`; the interactive R3 fail-loud path is separate).
    #   - SURFACE-UNRUNG-NEVER-SILENT: a lane that can't resolve to a live pane
    #     (not in tmux / session absent / ambiguous) OR is remote-control-active is
    #     recorded to ledger/doorbell.log — this IS the §23 "delays never loses" safety
    #     property operating VISIBLY (payload durable in git; the lane catches it via its
    #     obligatory INBOX-CHECK on its next turn; the unrung notice makes the deferred
    #     delivery visible so it is not forgotten).
    #   - RINGS ALL inbox writes (no "requires action" judgment — a redundant wake is a
    #     cheap no-op turn; INBOX-CHECK is idempotent) with per-lane dedupe.
    #   - Ruling 3: an EXPLICIT remote-control marker (tmux user-option @remote_control on
    #     the lane's session) SUPPRESSES+surfaces. MERE CLIENT-ATTACHMENT does NOT qualify
    #     — an attached-but-idle lane still needs its ring.
    (
        set +e
        DBELL="$REPO_ROOT/scripts/doorbell.sh"
        ULOG="$REPO_ROOT/ledger/doorbell.log"
        TS="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
        INBOX_LANES="$(printf '%s\n' "$CHANGED_FILES" \
            | sed -n 's#^_orchestration/relay-inbox/\([^/][^/]*\)/..*#\1#p' | sort -u)"
        for L in $INBOX_LANES; do
            [[ -n "$L" ]] || continue
            RC="$(tmux show-options -v -t "$L" @remote_control 2>/dev/null)"
            case "$RC" in
                1|on|true|yes)
                    printf 'unrung: %s (remote-control-active) %s %s\n' "$L" "$COMMIT_SHORT" "$TS" >> "$ULOG"
                    echo "[post-commit] doorbell auto-fire: SUPPRESSED ${L} (remote-control-active) -> ledger/doorbell.log." ;;
                *)
                    if RING_OUT="$("$DBELL" ring "$L" 2>&1)"; then
                        echo "[post-commit] doorbell auto-fire: rang ${L} (inbox-commit ${COMMIT_SHORT})."
                    else
                        REASON="$(printf '%s' "$RING_OUT" | tr '\n' ' ' | sed 's/  */ /g; s/^ *//; s/ *$//')"
                        printf 'unrung: %s (%s) %s %s\n' "$L" "${REASON:-ring-failed}" "$COMMIT_SHORT" "$TS" >> "$ULOG"
                        echo "[post-commit] doorbell auto-fire: UNRUNG ${L} -> ledger/doorbell.log (payload durable; next INBOX-CHECK catches it)."
                    fi ;;
            esac
        done
    ) || true
fi

# === (2) AUDIT STEP — code auditor FIRST (every commit, ZERO model calls), then the LLM
#     reproduction pass ONLY on a judgment-class path-trigger or the daily boundary.
#     Sentinel written after BOTH finish so the reap/seal machinery above (S1, :137-165) is
#     unchanged. Per the loop-cure ruling ("Model off the commit path; keep the per-commit
#     CODE auditor" — becomes step C') as amended (C' sequenced
#     FIRST). Canon S4 coverage is preserved by construction: scripts/code-auditor.sh
#     runs unconditionally, independent of agents/audit-system-prompt.md or AUDITOR_CMD being
#     present — those two gate ONLY the LLM half below, never the mandatory code half. ===

# Hooks run with a minimal env; set PATH explicitly so a minimal-env commit cannot
# silently SKIP either pass. $HOME-relative (portable across the operator's machines).
export PATH="$HOME/.npm-global/bin:$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"

mkdir -p "$REPO_ROOT/ledger"

# Auditor binary and tier. AUDITOR_CMD defaults to the real `claude`; it overrides the binary for
# control-logic tests only (the PATH-hardening above prioritises the real claude dirs, so a test cannot
# shadow it via PATH). AUDITOR_MODEL is the explicit --model on the invocation; this default is its one literal.
AUDITOR_CMD="${AUDITOR_CMD:-claude}"
AUDITOR_MODEL="${AUDITOR_MODEL:-opus}"
# === LLM_REASON — computed HERE (foreground, cheap, deterministic, 0 model calls) so the
#     synchronous final [post-commit] echo below can report it immediately; re-used unchanged
#     inside the backgrounded subshell to gate the claude -p spawn. Two triggers, either fires:
#       (a) path-trigger — the judgment-class surface: agents/, scripts/, contracts/, _index/, probes/
#           (probes/ is IN because a prior fail-open probe lived there), plus
#           the boot-law surfaces CLAUDE.md, disciplines.md, .claude/agents/*, .claude/settings.json, _boot/*
#           (`agents/*` is anchored at the path start, so .claude/agents/* is its own arm).
#       (b) daily — no LLM audit has run in the last 24h, read from the newest ts_utc in
#           ledger/auditor-usage.jsonl (event-driven per CLAUDE.md Discipline #2 — checked AT
#           commit time; no poller/cron/launchd job added).
#     R3 done-condition: a commit outside (a) with a fresh LLM audit inside 24h -> LLM_REASON=none
#     -> the claude -p block below never spawns -> 0 model-seconds on this commit.
LLM_TRIGGER_PATH=""
while IFS= read -r _cf; do
    [[ -z "$_cf" ]] && continue
    case "$_cf" in
        agents/*|scripts/*|contracts/*|_index/*|probes/*|CLAUDE.md|disciplines.md|.claude/agents/*|.claude/settings.json|_boot/*)
            LLM_TRIGGER_PATH="$_cf"
            break
            ;;
    esac
done <<< "$CHANGED_FILES"

LLM_REASON="none"
if [[ -n "$LLM_TRIGGER_PATH" ]]; then
    LLM_REASON="path-trigger:${LLM_TRIGGER_PATH}"
elif command -v python3 >/dev/null 2>&1; then
    LLM_DAILY_DECISION="$(python3 - "$REPO_ROOT/ledger/auditor-usage.jsonl" <<'PYEOF'
import sys, json, datetime
path = sys.argv[1]
last = None
try:
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except (ValueError, json.JSONDecodeError):
                continue
            ts = obj.get("ts_utc")
            if isinstance(ts, str):
                try:
                    dt = datetime.datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=datetime.timezone.utc)
                except ValueError:
                    continue
                if last is None or dt > last:
                    last = dt
except OSError:
    pass
if last is None:
    print("NEVER")
else:
    age = (datetime.datetime.now(datetime.timezone.utc) - last).total_seconds()
    print("STALE" if age >= 86400 else ("FRESH:" + str(int(age))))
PYEOF
)"
    if [[ "$LLM_DAILY_DECISION" == "NEVER" || "$LLM_DAILY_DECISION" == "STALE" ]]; then
        LLM_REASON="daily"
    fi
else
    # python3 unavailable: fail toward RUNNING the LLM pass (halt-loud-over-silent-degradation,
    # CLAUDE.md invariant #5) rather than silently losing daily coverage forever.
    LLM_REASON="daily"
fi

# The hook is installed ONCE in the shared .git/hooks, so it also runs in every linked lane
# worktree, and a lane that has not synced has NO scripts/code-auditor.sh. There, "LLM_REASON=none" would
# leave the commit with neither pass. Fail toward the pre-C' behaviour: run the LLM pass (inv #5).
if [[ "$LLM_REASON" == "none" && ! -f "$REPO_ROOT/scripts/code-auditor.sh" ]]; then
    LLM_REASON="code-auditor-absent"
fi
if [[ "$LLM_REASON" != "none" && "$AUDITOR_CMD" == "claude" ]] && ! { _origin_url="$(git -C "$REPO_ROOT" remote get-url origin 2>/dev/null)" && [[ "$_origin_url" =~ ^(https?://|ssh://|git@) ]]; }; then echo "post-commit: LLM pass SKIPPED (reason=no-lane-remote: fixture or replica) for ${COMMIT_SHORT}" >> "$REPO_ROOT/ledger/audit-runs.log"; LLM_REASON="none"; fi   # LANE-REMOTE GUARD: see the end of this file
# --- helper: the existing claude -p reproduction pass, unchanged in substance, only gated
#     differently (see (2b) below) and told what the code auditor already covered + why it fired.
#     Defined HERE, before the backgrounded subshell forks below, so the subshell (which inherits
#     the parent shell's functions at fork time) can call it. ---
_llm_audit_step() {
local REPO_ROOT="$1" COMMIT_HASH="$2" COMMIT_SHORT="$3" LANE="$4" CHANGED_FILES="$5" LLM_REASON="$6" AUDITOR_CMD="$7" AUDITOR_MODEL="$8"

local AUDIT_PROMPT
AUDIT_PROMPT=$(cat <<EOF
Audit commit ${COMMIT_HASH} (${COMMIT_SHORT}). Committing lane: ${LANE}.

LLM pass trigger reason: ${LLM_REASON} (judgment-class path-trigger, or the daily boundary — see
agents/post-commit-hook.sh (2) for the two conditions; MECH-AUDIT).

The deterministic code auditor (scripts/code-auditor.sh) ALREADY ran for this commit, before you
were spawned: receipt presence + file_state on ledger/receipts.jsonl, issues_register.md CLOSED/
RESOLVED-citation discipline, and the tier-selected standing-probe runlist (per
_index/probe-tiers.tsv). See the "## Code audit — ${COMMIT_SHORT}" block just appended to
ledger/audit-findings.md for what it ran, skipped, and found — do NOT re-run the same standing
probes it already ran with an unchanged result; if you want independent confirmation of any one
of them, say so and re-run that probe specifically rather than the whole runlist.

Changed files in this commit:
${CHANGED_FILES}

Read each changed file. For receipts added to ledger/receipts.jsonl in
this commit (compared to the prior commit), independently re-invoke
each receipt's probe_path; compare exit code + output hash; emit verdict
per agents/audit-system-prompt.md.

Compare against:
- contracts/ (the binding specs every work package verifies against)
- schema/ (work-package shape, receipt shape, state machine, verification rings)
- agents/ (role definitions; lane boundaries)
- docs/ (BUILD_ARCHITECTURE, EXECUTION_PLAN, UAT, FOUNDATION, PROTOCOL)
- dag/DAG.yaml (the work-package graph)
- ledger/audit-findings.md (prior findings — avoid duplicates; detect recurrences)

Per AUDITOR INCREMENTAL (schema/verification.md §8.1): audit this commit's
artifacts the moment they land; no batching per wave.

Per SELF-HEALING (schema/verification.md §8.3): on DIVERGED, append a
finding-and-receipt; do NOT author corrections (worker reworks on its
own branch); do NOT close any WP (orc merges on REPRODUCED).

Per WAIVED-with-notes (agents/auditor-contract.md §Interim-cover): for
Ring 2/3 probes against surfaces you cannot reach (the credentialed live surfaces of the project —
the substrates _index/substrates.tsv declares beyond git-spine) — you do NOT have those
credentials; record WAIVED with explicit notes naming the unreached
surface.

Per STANDING-PROBE runlist (agents/audit-system-prompt.md step 9 +
agents/standing-probes.yaml; architect rider 2026-05-26 ratifies
WP-V2-AUDITOR-STANDING-PROBES-WIRING): after per-receipt reproduction
work in steps 4-8, run each standing probe configured in
agents/standing-probes.yaml. Emit a Ring-2 standing-probe receipt ONLY
on (a) FAIL outside partial_fail_window / RUN_ERROR (regression);
(b) PASS<->FAIL state change vs prior receipt; (c) cadence_emit_per_day
boundary crossed; (d) wiring-init sentinel (first-ever standing-probe
receipt for that id). Otherwise PASS-on-PASS emits no receipt — the
ledger/audit-runs.log invocation entry is sufficient liveness.

Output:
- Append a per-commit finding block to ledger/audit-findings.md (note the
  committing lane=${LANE}).
- Emit auditor-emitted receipt(s) to ledger/receipts.jsonl (one per
  worker receipt audited; actor=code-Auditor; supersedes_receipt_id set).
- Emit standing-probe receipt(s) per the rule above (actor=code-Auditor;
  standing_probe_id set; supersedes_receipt_id=null).

Be specific: file:line evidence required.
Be non-redundant: check prior findings first.
Be conservative: WAIVED is honest admission; never silently skip.

Trigger context: post-commit ${COMMIT_SHORT} (lane=${LANE})
EOF
)

# Invoke headlessly with audit-only system prompt. Runs INSIDE the caller's already-backgrounded
# subshell (see (2a)/(2b) below) — no separate background/disown here; a nested `&` would detach
# from the outer subshell's own lifetime for no benefit and would race the sentinel write below.
# E6b usage RECORDER (CLAUDE.md #9): the run's JSON result goes to a temp file; the
#   recorder appends one row to ledger/auditor-usage.jsonl and the result text to audit-runs.log. The recorder
#   never fails the hook and never zero-fills an unreadable run. It runs BEFORE the caller writes the sentinel,
#   so the seal commit carries the row.
local RUNJSON T0 ARC
RUNJSON="$(mktemp "${TMPDIR:-/tmp}/auditor-run.XXXXXX")"; T0="$(date +%s)"
"$AUDITOR_CMD" -p "$AUDIT_PROMPT" \
    --append-system-prompt "$(cat "$REPO_ROOT/agents/audit-system-prompt.md")" \
    --permission-mode bypassPermissions --output-format json --model "$AUDITOR_MODEL" \
    > "$RUNJSON" 2>> "$REPO_ROOT/ledger/audit-runs.log"
ARC=$?
bash "$REPO_ROOT/scripts/auditor-usage-record.sh" "$RUNJSON" "$COMMIT_HASH" "$LANE" "$(( $(date +%s) - T0 ))" "$ARC" || true
rm -f "$RUNJSON"
}

# A TRIGGERED LLM pass that cannot run is surfaced LOUD on stderr in the foreground
# (inv #5), as the pre-C' hook did; the background log line alone would be a silent degradation.
if [[ "$LLM_REASON" != "none" ]]; then
    if [[ ! -f "$REPO_ROOT/agents/audit-system-prompt.md" ]]; then
        echo "post-commit: agents/audit-system-prompt.md MISSING; LLM pass SKIPPED (reason=${LLM_REASON}) for ${COMMIT_SHORT}; code audit still runs." >&2
    elif ! command -v "$AUDITOR_CMD" >/dev/null 2>&1; then
        echo "post-commit: auditor '$AUDITOR_CMD' not in PATH; LLM pass SKIPPED (reason=${LLM_REASON}) for ${COMMIT_SHORT}; code audit still runs." >&2
    fi
fi

# === (2a)/(2b) — background BOTH passes in one subshell; sentinel written after both finish
#     (whichever ran) so the reap/seal machinery above (S1, :137-165) is unchanged. ===
cd "$REPO_ROOT"
(
    set +e
    # --- (2a) CODE AUDITOR — every commit, 0 model calls, FIRST. ---
    if [[ -f "$REPO_ROOT/scripts/code-auditor.sh" ]]; then
        bash "$REPO_ROOT/scripts/code-auditor.sh" "$COMMIT_HASH" "$LANE" >> "$REPO_ROOT/ledger/audit-runs.log" 2>&1
    else
        echo "post-commit: scripts/code-auditor.sh MISSING; CODE audit pass SKIPPED for ${COMMIT_SHORT} (LLM pass, if triggered, is unaffected)." >> "$REPO_ROOT/ledger/audit-runs.log" 2>&1
    fi

    # --- (2b) LLM REPRODUCTION PASS — only when LLM_REASON != none. ---
    if [[ "$LLM_REASON" != "none" ]]; then
        if [[ ! -f "$REPO_ROOT/agents/audit-system-prompt.md" ]]; then
            echo "post-commit: agents/audit-system-prompt.md MISSING; LLM pass SKIPPED (reason=${LLM_REASON}) for ${COMMIT_SHORT}." >> "$REPO_ROOT/ledger/audit-runs.log" 2>&1
        elif ! command -v "$AUDITOR_CMD" >/dev/null 2>&1; then
            echo "post-commit: auditor '$AUDITOR_CMD' not in PATH; LLM pass SKIPPED (reason=${LLM_REASON}) for ${COMMIT_SHORT}." >> "$REPO_ROOT/ledger/audit-runs.log" 2>&1
        else
            # Source .env if present (gitignored). Keyless by design — carries no
            # ANTHROPIC_API_KEY (06-23 repoint retired anthropic-tool-versions), so the
            # Auditor runs on the Max subscription, not metered API.
            if [[ -f "$REPO_ROOT/.env" ]]; then
                set -a
                # shellcheck source=/dev/null
                source "$REPO_ROOT/.env"
                set +a
            fi
            _llm_audit_step "$REPO_ROOT" "$COMMIT_HASH" "$COMMIT_SHORT" "$LANE" "$CHANGED_FILES" "$LLM_REASON" "$AUDITOR_CMD" "$AUDITOR_MODEL"
        fi
    fi

    # Sentinel written after BOTH passes finish (whichever ran) -- licenses the NEXT foundation
    # commit's reap to seal this commit's audit, per S1 above. Written UNCONDITIONALLY: at least one
    # pass has run -- (2a) whenever scripts/code-auditor.sh exists, and where it does NOT (an unsynced
    # lane) LLM_REASON=code-auditor-absent forces (2b). ⚠ Corrected previously (auditor 9377873c,
    # noted): the old text said (2a) "always runs"; it does not in the absent branch. The one case with
    # NEITHER pass is the double fault code-auditor absent AND (2b) misconfigured, which is LOUD on
    # stderr (P7). The LLM half may still be skipped by LLM_REASON=none OR by a misconfiguration (missing
    # audit-system-prompt.md / AUDITOR_CMD). This is a coverage IMPROVEMENT over the prior hook,
    # which exited before ever reaching this line (and before writing any sentinel at all) when
    # AUDITOR_CMD/audit-system-prompt.md were missing -- that misconfiguration used to silently
    # stall sealing for the commit; now the code half discharges it regardless.
    echo "$LANE" > "$DONE_DIR/$COMMIT_HASH"
) &
disown 2>/dev/null || true

echo "[post-commit] lane=${LANE} code-auditor backgrounded for ${COMMIT_SHORT} (0 model calls); LLM_REASON=${LLM_REASON}. Audit lands async at ledger/* + sentinel."

exit 0

# LANE-REMOTE GUARD (one line at :293, after every LLM_REASON trigger, so it overrides them all). The REAL model pass
# runs only in a lane: a repo whose origin is a NETWORK remote (`git remote get-url origin` succeeds and matches
# ^(https?://|ssh://|git@)). Every other repo is a probe fixture or a replica (no origin, or the local-path origin that
# `git clone $R` and `git clone --shared` leave), and a commit there would otherwise spawn a real auditor on the committing
# seat's account. There the real pass is SKIPPED with one logged line, reason `no-lane-remote: fixture or replica`: loud
# and named, never silent. An unreadable or absent origin counts as not-a-lane and SKIPS. The code audit still runs.
# One exception: the caller set AUDITOR_CMD to something other than the default `claude` (:218). An override is a test
# stub by this hook's own contract, so probes that remove origin and assert on their stub's calls keep their behaviour.
# A caller that sets AUDITOR_CMD=claude explicitly gets the default binary and is treated as no override (it skips).
# Written here, after exit, so no cited line above moves.
