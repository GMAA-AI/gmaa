#!/usr/bin/env bash
# agents/pre-commit-hook.sh — Slice-1 D3 (module-DENY) + M6(i) (foundation set-coverage) spine gate.
#
# Installed via scripts/install_pre_commit_hook.sh into .git/hooks/pre-commit
# (git hooks aren't versioned; this is the canonical source).
#
# Enforces COORDINATION.md §13(1) single-writer PLUS canon §4 set-authorization:
#   - Module lane (`module/<x>`, spine_write: DENY) staging ANY spine-owned path -> REJECT (exit 1).
#     Module lanes commit only their own branch + PROPOSE spine changes via reap-at-merge.
#   - the execution lane (branch `exec`) may commit SOLELY under ledger/apply-receipts/** (its own carve-out).
#   - FOUNDATION may write the spine, but any AUTHORED-spine path it stages must be COVERED by a MEMBER
#     of a RATIFIED set at HEAD (M6(i); canon §4). STRUCTURAL coverage BY PATH, never a message tag.
#     A CLOSED operator-confirmed exemption allowlist bypasses coverage (genesis/provisioning/audit
#     seals/set-ledger/resume-pointer/orchestration-state pins — see set_exempt()).
#
# Identity comes from LOCATION via scripts/resolve-lane.sh — the SAME resolver the §0 cold-boot seat
# and the post-commit hook consume. The resolver resolves the COMMITTING worktree's own root
# (`git rev-parse --show-toplevel`), never trunk/cwd, and cross-checks the stamped lane against branch.
#
# FAIL-CLOSED: if the lane cannot be resolved (resolver exit != 0 — no _boot/BOOTSTRAP.md, unset lane,
# or stamp<->branch mismatch) the commit is REJECTED. Never default to foundation on an unresolved lane.
# The foundation set-gate is ALSO fail-closed: an unreadable / assembled-against-a-non-ancestor ratified
# packet is NEVER treated as ratified.
#
# Authority:
#   - D3 module-DENY + the execution-lane carve-out: chat-Architect Slice-1 build relay 2026-06-24.
#   - M6(i) foundation set-coverage: the closed exemption set (operator-confirmed) +
#     STRUCTURAL-coverage reconciliation, from the byte-grounded lift map. MERGE from GMAA frozen
#     7a179264 (build/releases/v2.5.4.2/work/agents/pre-commit-hook.sh, M6(i) block) — ADDITIVE: the
#     the execution-lane/exec carve-out + module-DENY gate are PRESERVED verbatim; the set-gate is inserted, not swapped.
# HARD PIN: committed + ENFORCED before ANY 2nd orc goes live (even same machine).

set -u

REPO_ROOT="$(git rev-parse --show-toplevel)"
# the one spine-ref resolver, found from THIS HOOK's own location only (0507 R2/R16), never from the work tree git names:
# installed (the hooks dir) -> the resolver the installer placed beside it; the source copy under agents/ -> its tree's
# scripts/spine-ref.sh. One position per location, no fallback chain.
_HOOK_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)"
if [[ "${_HOOK_DIR##*/}" == agents ]]; then SPINE_REF_SH="${_HOOK_DIR%/agents}/scripts/spine-ref.sh"; else SPINE_REF_SH="$_HOOK_DIR/spine-ref.sh"; fi
[[ -f "$SPINE_REF_SH" ]] || { echo "pre-commit REJECT: SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this hook only; 0507 R2) — fail-closed (inv #5)." >&2; exit 1; }
RESOLVER="$REPO_ROOT/scripts/resolve-lane.sh"; SPINE_REF="$(bash "$SPINE_REF_SH")" && [[ -n "$SPINE_REF" ]] || { echo "pre-commit REJECT: SPINE-REF-UNRESOLVED -- $SPINE_REF_SH unfilled (the one spine-ref resolver) — fail-closed (inv #5)." >&2; exit 1; }  # the ONE spine-ref resolver; every spine read below uses SPINE_REF, the trunk is its branch half

if [[ ! -x "$RESOLVER" ]]; then
    echo "pre-commit REJECT: lane resolver missing/not-executable at $RESOLVER (fail-closed)." >&2
    exit 1
fi

# Resolve lane from THIS (the committing) worktree. Fail-closed on any non-zero.
if ! LANE_LINE="$("$RESOLVER")"; then
    echo "pre-commit REJECT: lane UNRESOLVED (resolver exit != 0)." >&2
    echo "  Cannot prove spine-write authority; fail-closed (never default to foundation)." >&2
    echo "  Cause: missing _boot/BOOTSTRAP.md, unset lane, or stamp<->branch mismatch (see resolver stderr above)." >&2
    exit 1
fi

# The resolver emits one KEY=VALUE line, all values single-token (lane/role/
# spine_write from _boot frontmatter; blob = git hash). eval matches the §0
# cold-boot contract `eval "$(scripts/resolve-lane.sh)"`.
eval "$LANE_LINE"   # -> lane= role= version= spine_write= blob=
_SK="$REPO_ROOT/scripts/seat-keys.sh"; [[ -f "$_SK" ]] || { _SKD="$(mktemp -d "${TMPDIR:-/tmp}/seat-keys-hook.XXXXXX")"; _SK="$_SKD/seat-keys.sh"; git show "${SPINE_REF}":scripts/seat-keys.sh > "$_SK" 2>/dev/null; cp "$SPINE_REF_SH" "$_SKD/spine-ref.sh" 2>/dev/null; }; [[ -s "$_SK" ]] && bash "$_SK" hook-precommit "${lane:-}" "${spine_write:-}" || { echo "pre-commit REJECT: the seat-keys gate refused (signing setup, registry row, or an unsigned/unverifiable relay file; the SEAT-KEYS line above names it). Fail-closed." >&2; exit 1; }   # a spine copy of seat-keys.sh runs beside this hook's resolver (0507 R2); this note stays at the line's end
# --- Spine-owned path set (COORDINATION.md §13(1)) + membership helper. Defined BEFORE the lane
#     branches (P1.4 restructure) so BOTH the foundation set-coverage gate (M6(i)) and the module
#     DENY gate consume ONE list (no drift). ---
# --- LAZY loader for the single authorization-input predicate. ---
# ⛔ THE REGRESSION THIS FIXES: this block used to SOURCE the validator EAGERLY at
# load time and exit non-zero when absent. The installed pre-commit hook is SHARED by every worktree
# while the validator lives on `main`, so EVERY commit in EVERY non-main worktree fail-closed —
# including commits staging NO spine path, which would never parse a surfaces token. 5 of 7 worktrees
# were frozen. ***A fail-closed check must fire on the INPUT IT JUDGES, never on every caller that
# merely loads the file.*** Still fail-closed — but at the point of use, where the refusal is true.
# === DISC-CANONICAL-MUST-REACH-THE-EXECUTING-SURFACE — THE ENFORCER SELF-VERIFIES. ===
# The cures landed on the spine while the INSTALLED hook was still sha 9898bfd3 and the
# spine copy was 6c3a9970 — ***the spine said cured and the RUNNING enforcer was the old build.*** The
# installer only PRINTS a `diff` suggestion (install_pre_commit_hook.sh:74); nothing fires, so a stale
# enforcer recurs silently. A gate that cannot confirm it is the current build does not run.
# HALT rather than self-reinstall: a hook must not rewrite itself mid-commit (inv #5, fail-closed).
#
# Compares GIT BLOB IDS, deliberately: `git show … | shasum` would let a FAILED `git show` be hashed as
# EMPTY input (e3b0c442…) and read as a real-but-different value -> a FALSE stale-enforcer REJECT.
# That is DISC-CHILD-FAILURE-MUST-SURFACE; blob ids keep the child's exit status observable.
_selfcheck_canonical() {
    local running canon_ref canon_id running_id
    running="${BASH_SOURCE[0]:-$0}"
    [[ -r "$running" ]] || return 0                       # cannot read ourselves -> cannot prove drift
    canon_ref="${SPINE_REF}:agents/pre-commit-hook.sh"
    if ! canon_id="$(git rev-parse "$canon_ref" 2>/dev/null)" || [[ -z "$canon_id" ]]; then
        # DELIBERATE, surfaced not smuggled: do NOT fail-closed here. Blocking every commit in the fleet
        # on an unreadable canonical ref would recreate the 5-of-7 freeze this fix just cured.
        # Drift cannot be PROVEN when canonical cannot be read, and a guard must never turn
        # "cannot measure" into "everyone stops."
        echo "pre-commit WARN: cannot read $canon_ref — enforcer currency UNVERIFIED this fire (fetch, then re-check). Proceeding; drift is unproven, not disproven." >&2
        return 0
    fi
    if ! running_id="$(git hash-object "$running" 2>/dev/null)" || [[ -z "$running_id" ]]; then
        echo "pre-commit WARN: cannot hash the running enforcer ($running) — currency UNVERIFIED this fire." >&2
        return 0
    fi
    if [[ "$running_id" != "$canon_id" ]]; then
        echo "pre-commit REJECT: the INSTALLED enforcer is NOT the canonical build (DISC-CANONICAL-MUST-REACH-THE-EXECUTING-SURFACE)." >&2
        echo "  installed : ${running_id:0:16}  ($running)" >&2
        echo "  canonical : ${canon_id:0:16}  ($canon_ref)" >&2
        echo "  A gate that cannot confirm it is the current build does not run. Re-install, then retry:" >&2
        echo "    scripts/install_pre_commit_hook.sh" >&2
        exit 1
    fi
}
_selfcheck_canonical

# === RETIRED-TERMS GUARD — EVERY LANE, BLOCKS. ===========================
# A retired mechanism named on a BEHAVIOURAL (law) surface keeps it alive as a concept a seat must parse;
# every prior sweep cured the instance it was shown and nothing stopped re-entry. This makes re-entry
# impossible to commit. Literal match on a CLOSED list over a SCOPED path set — not judgment-class, so it
# BLOCKS (not judgment-class). No text escape: a legitimate need to name a retired
# term on a law surface is a TSV edit in a ratified set, never --no-verify, never an inline comment.
# The list is read from the SPINE (SPINE_REF) so every lane enforces the CURRENT list regardless of its
# own branch copy. ORDER (auditor finding, 2026-09-22: `git show :path` reads the INDEX,
# which on a lane is its own TRACKED copy — so the old staged-first order let a stale lane copy shadow the
# spine list): the staged copy is used ONLY when THIS commit changes the list; otherwise spine; then worktree;
# none = fail-closed.
_retired_terms_guard() {
    local tsv="" f pat by repl hits bad=0 sref="${SPINE_REF:-$(bash "$SPINE_REF_SH" 2>/dev/null)}"; [[ -n "$sref" ]] || { echo "pre-commit REJECT: RETIRED-TERMS list unreadable: SPINE-REF-UNRESOLVED -- scripts/spine-ref.sh missing or unfilled; an empty ref would read the index, never the spine (fail-closed, inv #5)." >&2; exit 1; }
    if git diff --cached --name-only 2>/dev/null | grep -qx 'contracts/RETIRED-TERMS.tsv'; then
        tsv="$(git show :contracts/RETIRED-TERMS.tsv 2>/dev/null)"
    fi
    [[ -n "$tsv" ]] \
      || tsv="$(git show "${sref}":contracts/RETIRED-TERMS.tsv 2>/dev/null)" \
      || tsv="$(cat "$REPO_ROOT/contracts/RETIRED-TERMS.tsv" 2>/dev/null)" \
      || { echo "pre-commit REJECT: RETIRED-TERMS list unreadable (staged-change, ${sref} and worktree all failed) — fail-closed (inv #5)." >&2; exit 1; }
    while IFS= read -r f; do
        case "$f" in
            contracts/RETIRED-TERMS.tsv) continue ;;
            CLAUDE.md|AGENTS.md|.claude/settings.json|.claude/agents/*|_boot/*|skill/*|contracts/*) ;;
            *) continue ;;
        esac
        while IFS=$'\t' read -r pat by repl; do
            [[ -z "$pat" || "$pat" == \#* ]] && continue
            hits="$(git show ":$f" 2>/dev/null | grep -niE -- "$pat" | cut -c1-110)"
            if [[ -n "$hits" ]]; then
                bad=1
                echo "pre-commit REJECT: RETIRED TERM on a law surface — $f (pattern '$pat', retired by $by)." >&2
                printf '%s\n' "$hits" | sed "s|^|    $f:|" >&2
                echo "  State the CURRENT model instead: $repl" >&2
            fi
        done <<< "$tsv"
    done < <(git diff --cached --name-only --diff-filter=ACMR)
    if [[ "$bad" -eq 1 ]]; then
        echo "  (contracts/RETIRED-TERMS.tsv. History belongs in records: _rulings/, decision-log. No --no-verify.)" >&2
        exit 1
    fi
}
_retired_terms_guard

# === SECRET-SCAN GUARD — EVERY LANE, BLOCKS. ============================
# A credential pasted into a relay or record is committed, pushed and reaped onto the spine. scripts/secret-scan.sh
# scans the ADDED lines of the staged change for well-known credential shapes. FAIL-CLOSED: any non-zero exit
# (1 = pattern matched, 2 = scanner error) or an unobtainable scanner REJECTS the commit. The scanner is taken from the
# worktree, else the spine (SPINE_REF), so a lane without the file is not frozen but never passes unscanned.
_secret_scan_guard() {
    local scanner="$REPO_ROOT/scripts/secret-scan.sh" tmp="" rc
    if [[ ! -r "$scanner" ]]; then
        tmp="$(mktemp "${TMPDIR:-/tmp}/secret-scan-hook.XXXXXX")" || { echo "pre-commit REJECT: cannot stage the secret scanner (fail-closed, inv #5)." >&2; exit 1; }
        if git show "${SPINE_REF}":scripts/secret-scan.sh > "$tmp" 2>/dev/null && [[ -s "$tmp" ]]; then
            scanner="$tmp"
        else
            rm -f "$tmp"
            echo "pre-commit REJECT: scripts/secret-scan.sh unreadable (worktree and ${SPINE_REF} both failed) — fail-closed (inv #5)." >&2
            exit 1
        fi
    fi
    bash "$scanner" --staged >&2
    rc=$?
    [[ -n "$tmp" ]] && rm -f "$tmp"
    if [[ "$rc" -ne 0 ]]; then
        echo "pre-commit REJECT: secret scan exit $rc (1 = credential pattern in the staged change, 2 = scanner error) — fail-closed (inv #5)." >&2
        exit 1
    fi
}
_secret_scan_guard

_load_surftok() {
    local f; f="$(git rev-parse --show-toplevel 2>/dev/null)/scripts/surfaces-token.sh"
    if [[ -r "$f" ]]; then . "$f"; return 0; fi
    echo "REFUSED: shared surfaces-token validator missing at $f (fail-closed; DISC-AUTHZ-INPUT-VALIDATED-AT-EARLIEST-WRITE — no private fallback predicate). Reached ONLY because a surfaces token had to be parsed here." >&2
    return 1
}

# The hub's handoff file is the declared engine-path table's `role:handoff` row (_index/engine-paths.tsv), read through the ONE
# lookup in scripts/declared-spine-paths.sh (--role). It is not typed here. FAIL-CLOSED (inv #5): an unreadable table or a
# table with no such row REJECTS with the named reason; no default path is assumed.
if ! HANDOFF_PATH="$("$REPO_ROOT/scripts/declared-spine-paths.sh" --role handoff)"; then
    echo "pre-commit REJECT: the role:handoff path cannot be resolved from _index/engine-paths.tsv (reason above) — fail-closed (inv #5); no default path is assumed." >&2
    exit 1
fi

SPINE_PATHS=(
    # --- §13(1) spine (enumerated) ---
    "ledger/"
    "dag/"
    "issues_register.md"
    "CHECKLIST.md"
    "contracts/"
    "_orchestration/STATE.md"
    "_orchestration/decision-log.md"
    # lane-provisioning manifest — REQUIRED in the set: R1 (adopt-from-trunk) resolves
    # the integration-trunk ref FROM this file at gate time; module-editable here would
    # make the adopt-check subvertible. (Added 2026-06-24 as a forced R1 dependency.)
    "_orchestration/lane-provisioning.md"
    # --- set-level authorization (canon §4): the pending-set ledger + the ratification packets +
    #     foundation's resume-state pointer are foundation-owned. A module lane staging PENDING-SET.md,
    #     _ratification/, or dispatch/LATEST.md is REJECTED; members reach the ledger ONLY via
    #     foundation's `scripts/pending-set.sh reap`. (P1.4 tail — kept BYTE-ALIGNED with
    #     scripts/ratify.sh SPINE_PREFIXES: our 16 census paths + these 3 set-gate paths.) ---
    "PENDING-SET.md"
    "_ratification/"
    "$HANDOFF_PATH"
    # --- "the one database" (architect ruling #3, 2026-06-24) ---
    "sql/"
    "migrations/"
    # --- shared substrate, foundation-owned (architect ruling 2026-06-24, §13(1)
    #     enumeration amended). DECISIVE: scripts/resolve-lane.sh + the hooks live
    #     under scripts//agents/ — a module-writable enforcement layer is a guard
    #     that could disable its own guard. skill/ inclusion makes the version-
    #     control home spine-protected the moment it exists (ITEM0). Carve-out
    #     unchanged: module-authored content here is a PROPOSAL via reap-at-merge,
    #     never a module spine-write. ---
    "agents/"
    "scripts/"
    "skill/"
    "src/"
    # --- agent PERSONA defs (architect ruling 2026-06-25, ISSUE-AGENT-DEF-FAILS-OPEN-ON-
    #     MISSING-DEF). The role-neutral `orc` def + team/worker defs are foundation-owned and
    #     role-neutral — there is NO lane-specific agent def; lane identity lives ONLY in
    #     _boot/CHARTER+BOOTSTRAP (per-branch, integration-excluded). Spine-protecting closes
    #     the module SELF-TAMPER surface (a module orc editing away its own authority class /
    #     DENY persona) AND makes currency-sync R1 adopt the def BYTE-IDENTICAL from trunk →
    #     canonical-from-trunk, non-divergeable. (.gitignore: `.claude/*` + `!.claude/agents/`
    #     keeps exactly this dir trackable.) ---
    ".claude/agents/"
    # --- shared safe permission allow-list (REMEDIATION v3 OP-5). Spine-protecting settings.json
    #     makes the auto-approver foundation-owned (a module cannot widen its own permissions) AND
    #     rides currency-sync R1 adopt-from-trunk BYTE-IDENTICAL, so every lane boots prompt-free on
    #     the same vetted set. settings.local.json stays gitignored/per-worktree (local additions). ---
    ".claude/settings.json"
)

# Helper: is a path under a spine-owned prefix/file?
is_spine() {
    local f="$1" sp
    for sp in "${SPINE_PATHS[@]}"; do
        case "$sp" in
            */) [[ "$f" == "$sp"* ]] && return 0 ;;
            *)  [[ "$f" == "$sp"  ]] && return 0 ;;
        esac
    done
    return 1
}

# Optional: append the adopter's DECLARED spine paths (HEAD-readback) to the base census — keeps both
# the foundation set-gate and the module-DENY gate protecting the same declared spine. scripts/declared-
# spine-paths.sh is P1.8 plumbing (absent now → skipped; -x-guarded → harmless no-op). Same optional
# contract scripts/ratify.sh already consumes.
if [[ -x "$REPO_ROOT/scripts/declared-spine-paths.sh" ]]; then
    while IFS= read -r dp; do [[ -n "$dp" ]] && SPINE_PATHS+=("$dp"); done < <("$REPO_ROOT/scripts/declared-spine-paths.sh" 2>/dev/null)
fi

# === FOUNDATION: set-coverage gate (M6(i); canon §4) ===
# Foundation = sole spine committer (§13(1)) — but any AUTHORED-spine path it stages must be covered by a
# MEMBER of a RATIFIED set at HEAD. Enforcement is STRUCTURAL — set-membership BY PATH, not a message tag:
# ratification is a property of the SET OF PATHS changed, not of commit text ("before ANY member
# commits/applies … evaluated against the set", canon §4). A well-formed message cannot forge it; a
# `[set SET-NNNN]` tag in the message stays a POST-COMMIT-VERIFIED convention, NEVER the gate (the structural-coverage
# §3: structural coverage replaces the forgeable citation model).
if [[ "${lane:-}" == "foundation" ]]; then
    # Exemptions BY PATH — the operator's CLOSED, confirmed allowlist ("yes", verbatim).
    # The 6 operator-facing bypasses map to these path patterns (GMAA byte-reference set_exempt):
    #   genesis + _boot/**  -> _boot/*                       [audit] seals + apply-receipts -> ledger/*
    #   PENDING-SET.md · _ratification/**                    dispatch/LATEST.md (resume-pointer)
    # PLUS the orchestration STATE PINS + comms (state/handoff pins, NOT authored spine — same nature as
    # dispatch/LATEST.md, which the operator ruled EXEMPT 2026-08-17): _orchestration/{STATE.md,
    # decision-log.md, lane-provisioning.md, relay-*}. These MUST bypass or the mechanism cannot bootstrap
    # (every foundation commit narrates decision-log.md; the ratify/reap commit writes it too). The arm
    # SURFACES additions, never widens silently; the operator may later rule others exempt (supersedes).
    # NOTE (forward-flag, decision-log f-368): CHECKLIST.md + issues_register.md + contracts/ were NOT
    # exempt (authored spine, per both the operator's 6 and the byte reference) → once the gate is LIVE,
    # a re-stamp/handoff commit touching CHECKLIST.md rides a set or is exempted; surfaced to architect.
    # ↑ RESOLVED 2026-08-26 (the forward-flag realized).
    #
    # ═══ CLASS BOUNDARY (the standing decision rule — do not re-raise this class) ═══
    # The set-authorization gate defends DESIGN/AUTHORIZATION landing on the trunk. The exemption
    # boundary is drawn by CONTENT-CLASS, made structurally checkable by PATH:
    #   • RECORD-KEEPING / TRACKING / NARRATION substrate (the mechanism's own books) → EXEMPT.
    #   • Any DESIGN or AUTHORIZATION surface (contracts/, sql/, migrations/, agents/, scripts/,
    #     skill/, src/, .claude/agents/**, .claude/settings.json) → RIDES a ratified set. A seat def
    #     IS an authorization surface; path-exempting it would let an authority rewrite bypass set
    #     authorization entirely — strictly worse than the M6(i) merge-path hole closed earlier.
    # issues_register.md is a HYPOTHESIS register (invariant #4) and CHECKLIST.md is the strategic
    # progress tracker: both are tracking/narration-class, architecturally IDENTICAL to the already-
    # exempt decision-log.md / dispatch/LATEST.md / ledger/*. REJECTED by the same ruling: a rolling
    # "standing maintenance set" (a set that keeps accepting members is a blank check that defeats
    # "the unit of authorization is the set, not the change").
    #
    # ⚠ GUARD — this exemption is for set-COVERAGE ONLY. It does NOT touch closure integrity: the
    # register's one authority-bearing operation (a Status flip claiming RESOLVED) is defended by an
    # INDEPENDENT standing control that remains fully in force — no-fake-closures (invariant #4:
    # grep'd closeout doc + probe evidence + delta lines machine-derived from git diff, never hand-
    # counted) plus the post-commit auditor. Set-coverage never defended closure; it still doesn't.
    #
    # SURFACED, never silent (arm discipline): landed per the class-boundary rule, recorded in
    # _orchestration/decision-log.md + reported to the operator. The operator retains SUPERSESSION and
    # may rule these back in or widen further (supersedes this comment).
    set_exempt() {
        case "$1" in
            ledger/*|_boot/*|PENDING-SET.md|_ratification/*) return 0 ;;
            _orchestration/STATE.md|_orchestration/decision-log.md|_orchestration/lane-provisioning.md) return 0 ;;
            _orchestration/relay-*|"$HANDOFF_PATH") return 0 ;;
            # record-keeping / tracking substrate (see CLASS BOUNDARY above)
            issues_register.md|CHECKLIST.md) return 0 ;;
        esac
        return 1
    }
    if git rev-parse --verify -q HEAD >/dev/null 2>&1; then
        F_STAGED="$(git diff --cached --name-only 2>/dev/null)"
    else
        F_STAGED="$(git diff --cached --name-only --root 2>/dev/null)"
    fi
    AUTHORED=()
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        is_spine "$f" || continue
        set_exempt "$f" && continue
        AUTHORED+=("$f")
    done <<< "$F_STAGED"
    # No authored-spine staged (only exempt/non-spine paths) → the set gate has nothing to cover; allow
    # (§13(1) foundation write). This is the normal narration/re-stamp/audit-seal path.
    if [[ ${#AUTHORED[@]} -eq 0 ]]; then exit 0; fi

    # Build the covered-path set from RATIFIED packets at HEAD. FAIL-CLOSED on unreadable/divergent
    # packets — an unreadable packet is NEVER treated as ratified. `- decision: RATIFIED` prefix-matches
    # BOTH merge states (RATIFIED · RATIFIED-WITH-SEQUENCE) and excludes AMENDED/HELD/REJECTED (5-state
    # taxonomy, C-RATIFICATION-PACKET §3). Parser aligns with scripts/ratify.sh's packet writer.
    # === COVERAGE IS CONSUMED ON LANDING, NEVER PERMANENT ===
    # INVARIANT: a ratified set authorizes its members' declared `surfaces:` ONLY for the change that
    # satisfies it, and ONLY until that set is CONSUMED (its change has LANDED). On consumption the
    # coverage LAPSES: the paths return to set-protected and any later change needs a NEW covering set.
    # NO PATH IS EVER PERMANENTLY AUTHORIZED BY A PAST SET. This restores the class-boundary rule (C) and closes
    # the "gate's own surface is unguarded" hole in one stroke (once SET-0006 is consumed it stops
    # covering scripts/ratify.sh, so gate maintenance rides a fresh set like any DESIGN surface).
    #
    # CONSUMPTION SIGNAL (architect's option (a) — reuses the existing status vocabulary): a member is
    # LANDED when its PENDING-SET.md row reads `committed` OR its row is GONE (rows are removed at the
    # apply/commit boundary — PENDING-SET's own APPLY LOG convention). A set ALL of whose members are
    # landed is CONSUMED. Any member still live (pending / evaluated / ratified-in) keeps it covering.
    #
    # FAIL-CLOSED: unreadable/ambiguous consumption state => treat as CONSUMED (do NOT cover). Never
    # treat an un-provable landing as "still live" — that is the direction that re-opens the blank check.
    set_consumed() {   # $1 = packet path ; exit 0 = CONSUMED (do NOT cover) ; 1 = LIVE (cover)
        local pk="$1" ids id row st live=0
        local pend="$REPO_ROOT/PENDING-SET.md"
        [[ -r "$pend" ]] || return 0                       # unreadable registry -> fail-closed
        ids="$(awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$pk" | sed -n 's/^- \([^ ]*\) ·.*/\1/p')"
        [[ -n "${ids//[[:space:]]/}" ]] || return 0         # no readable members -> fail-closed
        while IFS= read -r id; do
            [[ -z "${id//[[:space:]]/}" ]] && continue
            row="$(awk -F'|' -v want="$id" '{ i=$3; gsub(/^[ \t]+|[ \t]+$/,"",i); if (i==want) { s=$7; gsub(/^[ \t]+|[ \t]+$/,"",s); print s; exit } }' "$pend")"
            [[ -z "$row" ]] && continue                     # row GONE -> that member LANDED
            st="$row"
            case "$st" in
                committed*|*"= committed"*) ;;              # explicitly landed
                # VOID / SUPERSEDED (SET-0019 REQ-ARMING). A member marked
                # void-* will NEVER land by construction — its requirement was re-cut under a
                # successor set — so under the PREVIOUS vocabulary it kept its parent set LIVE
                # *forever*: the purest form of the "blank check" §2a exists to close. Measured
                # live: SET-0017 (rows 27/28/29 = void-superseded-by-SET-0018)
                # still returned rc=1 STILL COVERS long after SET-0018 superseded, applied and
                # sealed it. C-SET-AUTHORIZATION.md §2a FAIL-CLOSED already rules the outcome —
                # "an unreadable or ambiguous consumption state => treated as CONSUMED (does NOT
                # cover)" — and a change that can never land is the limiting case of un-provable
                # landing. This teaches the MECHANISM what the LAW already said; it does not
                # widen coverage, it withdraws it. DIRECTION (stated precisely -- rc 0 = CONSUMED
                # /does NOT cover/, rc 1 = LIVE /covers/): this arm can only ever WITHDRAW
                # coverage, never grant it. A token that FAILS to match falls through to the
                # pre-existing `*) live=1` arm and the set keeps covering -- i.e. a miss is a
                # FALSE NEGATIVE of this cure, leaving today's over-permissive behaviour
                # unchanged; it cannot authorize anything not already authorized. A wrong MATCH
                # withdraws coverage and REFUSES the commit -- loud, never silent.
                void*|*"= void"*) ;;                        # never lands -> CONSUMED per §2a FAIL-CLOSED
                *) live=1 ;;                                # still live -> set still covers
            esac
        done <<< "$ids"
        [[ $live -eq 1 ]] && return 1
        return 0
    }

    COVERED=()
    shopt -s nullglob
    for p in "$REPO_ROOT"/_ratification/SET-*.md; do
        grep -qE '^- decision: RATIFIED' "$p" || continue
        ahead="$(awk -F': ' '/^- HEAD sha at assembly:/ {print $2; exit}' "$p" | tr -d ' ')"
        if [[ -n "$ahead" && "$ahead" != "?" ]]; then
            # the set must have been assembled against THIS tree (assembly sha is an ancestor of HEAD)
            if ! git merge-base --is-ancestor "$ahead" HEAD 2>/dev/null; then
                echo "pre-commit REJECT: ratified packet $(basename "$p" .md) was assembled at '$ahead', NOT an ancestor of HEAD — assembled against a different tree (fail-closed; re-assemble)." >&2
                exit 1
            fi
        else
            echo "pre-commit REJECT: ratified packet $(basename "$p" .md) has no readable assembly HEAD sha (fail-closed; never treat an unreadable packet as ratified)." >&2
            exit 1
        fi
        # === ARMING — A PEN-FREE CLOSE IS RE-VERIFIED AT THE GATE HERE ====
        # A packet closed under the BUILD-CLASS standing class carries NO human name. Its entire
        # authorization is the claim "the mechanical predicate passed" — so this hook, the place where
        # that authorization is actually SPENT, re-runs the gate instead of trusting the stamp.
        #
        # WHY THIS EXISTS AND IS NOT BELT-AND-BRACES: a decision line is TEXT. `ratify --standing-class`
        # verifies at close, but nothing stops a later hand-edit (or a seat in a hurry) from typing a
        # standing-class stamp into a packet that never passed, and the human-pen path has a person's
        # name to answer for while this path has none. The predicate is also LIVE data: a set that was
        # genuinely build-class at close can stop being so when the predicate data moves beneath it.
        # Re-verifying at spend time is what makes "closed pen-free" a fact rather than a claim.
        #
        # FAIL-CLOSED: anything other than rc=0 ⇒ this packet COVERS NOTHING. It does not reject the
        # commit outright (a non-covering packet is not itself an offence) — the staged path simply
        # falls through to the standing "not covered by a RATIFIED set" REJECT below, which is the
        # correct, already-tested refusal. Loud on stderr either way: a silently non-covering packet
        # would be the worst of both worlds.
        if grep -qE '^- closed under: BUILD-CLASS STANDING-APPROVAL CLASS' "$p"; then
            if [[ ! -f "$REPO_ROOT/scripts/build-class-check.sh" ]]; then
                echo "pre-commit: packet $(basename "$p" .md) claims a BUILD-CLASS pen-free close but the gate script is MISSING — the claim is UNVERIFIABLE, so the packet covers NOTHING (fail-closed)." >&2
                continue
            fi
            if ! _bcout="$(bash "$REPO_ROOT/scripts/build-class-check.sh" "$p" 2>&1)"; then
                echo "pre-commit: packet $(basename "$p" .md) claims a BUILD-CLASS pen-free close, but the gate REFUSES it at HEAD — the packet covers NOTHING (fail-closed; a pen-free close is only as good as the predicate that authorized it)." >&2
                printf '%s\n' "$_bcout" | sed 's/^/    /' >&2
                continue
            fi
        fi

        # A CONSUMED set no longer covers anything. Checked AFTER the ancestor guard so a
        # divergent packet still hard-REJECTs (that check defends tree identity, not authorization life).
        if set_consumed "$p"; then continue; fi
        while IFS= read -r sfx; do
            [[ -z "${sfx// /}" ]] && continue
            # PARSER: never split a path on a comma inside a [...] annotation. Strip
            # bracketed annotations FIRST, then split. FAIL-CLOSED: a residual token carrying a space or
            # a bracket is MALFORMED and REJECTS the commit — it is the input to an authorization
            # decision, so an unparseable surfaces line must never silently widen or narrow coverage.
            # SAME predicate as the write-side callers (scripts/surfaces-token.sh).
            # The gate is now the BACKSTOP, not the first detector: a malformed token is refused at
            # `pending-set.sh member`/`reap` long before a pen can arm it here. Kept fail-closed.
            # Load the validator HERE, at the only place the hook parses a
            # surfaces token. A commit that stages no spine path never reaches this line.
            _load_surftok || exit 1
            _toks=""; _bad=""
            _toks="$(surfaces_token_parse "$sfx" 2>/tmp/.surftok.$$)" || _bad="$(cat /tmp/.surftok.$$)"
            rm -f "/tmp/.surftok.$$"
            if [[ -n "$_bad" ]]; then
                echo "pre-commit REJECT: malformed \`surfaces:\` token in $(basename "$p" .md) — a coverage path may not contain whitespace or brackets (fail-closed; DISC-AUTHZ-INPUT-VALIDATED-AT-EARLIEST-WRITE). Use one path per line or remove the annotation." >&2
                echo "$_bad" | sed 's/^MALFORMED-SURFACES-TOKEN: /  - /' >&2
                exit 1
            fi
            while IFS= read -r pp; do
                [[ -z "$pp" ]] && continue
                COVERED+=("$pp")
            done <<< "$_toks"
        done < <(awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' "$p" | sed -n 's/.*surfaces: //p')
    done

    # empty-array-safe under set -u (older bash): no ratified coverage → nothing is covered.
    path_covered() { local f="$1" c; [[ ${#COVERED[@]} -eq 0 ]] && return 1; for c in "${COVERED[@]}"; do [[ "$f" == "$c" ]] && return 0; done; return 1; }
    UNCOVERED=()
    for f in "${AUTHORED[@]}"; do path_covered "$f" || UNCOVERED+=("$f"); done
    if [[ ${#UNCOVERED[@]} -gt 0 ]]; then
        near="$(ls -1 "$REPO_ROOT"/_ratification/SET-*.md 2>/dev/null | tail -1 | xargs -r basename 2>/dev/null)"
        echo "pre-commit REJECT: foundation staged AUTHORED-spine path(s) NOT covered by a RATIFIED set at HEAD (canon §4 set authorization)." >&2
        for f in "${UNCOVERED[@]}"; do echo "    - $f   (nearest packet: ${near:-<none assembled>})" >&2; done
        echo "  Assemble → assess → ratify a set whose members' surfaces include these paths (scripts/ratify.sh), then commit." >&2
        exit 1
    fi
    exit 0
fi

# --- the apply-receipts-only lane (execution-apply-receipt-writer; RATIFIED A1-A3 2026-07-08) ---
# spine_write: apply-receipts-only (A3, declarative). ENFORCEMENT here, keyed on the stamp's DECLARED
# CLASS, never a lane NAME (a name pattern is false for most declared lanes and never auto-extends to
# a renamed or newly provisioned one; a declared class is true for all of them by construction): on
# the stamp's OWN `worktree_branch` ONLY, this lane may commit SOLELY under ledger/apply-receipts/**;
# every other path (incl. the rest of ledger/ and all spine paths) is DENIED. Single spine writer
# preserved; reaped-at-merge by foundation.
# NOTE (provisioning): the one-time _boot/ charter+bootstrap commit is a FOUNDATION provisioning
# act (foundation authors the charter per CHARTER-PRECEDES-BOOT), NOT this lane's runtime
# self-commit; its runtime commits are apply-receipts only, enforced below.
if [[ "${spine_write:-}" == "apply-receipts-only" ]]; then
    # The actual checked-out branch equalling the stamp's OWN worktree_branch is already enforced at
    # identity by the lane resolver's own stamp<->branch cross-check before this hook ever runs; this
    # is belt-and-suspenders against a future resolver regression, never a second name literal. Read
    # worktree_branch directly from THIS worktree's _boot/BOOTSTRAP.md front-matter (same sed-from-stamp
    # pattern agents/pre-merge-commit-hook.sh uses for _lane/_spine_write) rather than widening the
    # resolver's one-line interface, which stays unchanged: keying on the declared class does not
    # require a wider resolver line. Fail-closed if the stamp carries no worktree_branch.
    _worktree_branch="$(sed -n 's/^worktree_branch:[[:space:]]*//p' "$REPO_ROOT/_boot/BOOTSTRAP.md" 2>/dev/null | head -1)"
    if [[ -z "${_worktree_branch:-}" ]]; then
        echo "pre-commit REJECT: apply-receipts-only lane has no worktree_branch: stamped in _boot/BOOTSTRAP.md (fail-closed)." >&2
        exit 1
    fi
    if [[ "$(git rev-parse --abbrev-ref HEAD 2>/dev/null)" != "$_worktree_branch" ]]; then
        echo "pre-commit REJECT: an apply-receipts-only lane may commit ONLY on its stamped worktree_branch (${_worktree_branch}; got: $(git rev-parse --abbrev-ref HEAD 2>/dev/null))." >&2
        exit 1
    fi
    if git rev-parse --verify -q HEAD >/dev/null 2>&1; then
        E_STAGED="$(git diff --cached --name-only 2>/dev/null)"
    else
        E_STAGED="$(git diff --cached --name-only --root 2>/dev/null)"
    fi
    E_OUTSIDE=()
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        [[ "$f" == ledger/apply-receipts/* ]] && continue
        [[ "$f" == "ledger/restarts/${lane}.tsv" ]] && continue   # own-lane restart ledger
        E_OUTSIDE+=("$f")
    done <<< "$E_STAGED"
    if [[ ${#E_OUTSIDE[@]} -gt 0 ]]; then
        echo "pre-commit REJECT: an apply-receipts-only lane may commit ONLY under ledger/apply-receipts/** on its stamped worktree_branch (apply-receipts-only carve-out)." >&2
        for v in "${E_OUTSIDE[@]}"; do echo "    - $v" >&2; done
        exit 1
    fi
    exit 0
fi

# --- Module lane (spine_write: DENY): reject any staged edit to a spine path. ---
# Spine-owned set = COORDINATION.md §13(1); SPINE_PATHS + is_spine() are defined ONCE above (before the
# lane branches) and consumed by both the foundation set-gate (M6(i)) and this module DENY gate.

# The integration trunk is the branch half of the ONE spine-ref resolver's output (the one spine-ref resolver; SPINE_REF, resolved at
# the top of this hook); never a hardcoded name, never the lane map (circular at an adopter).
MERGE_HEAD_SHA="$(git rev-parse -q --verify MERGE_HEAD 2>/dev/null || true)"
TRUNK_BRANCH="${SPINE_REF#origin/}"
TRUNK_SHA="$(git rev-parse -q --verify "$TRUNK_BRANCH" 2>/dev/null || true)"

VIOLATIONS=()
if [[ -n "$MERGE_HEAD_SHA" && -n "$TRUNK_SHA" && "$MERGE_HEAD_SHA" == "$TRUNK_SHA" ]]; then
    # === R1 ADOPT-FROM-TRUNK (architect 2026-06-24) ===
    # A currency re-sync (merge ADOPTING the trunk) is allowed IFF the module contributes
    # NOTHING on spine paths: the index's spine MUST be BYTE-IDENTICAL to the trunk's spine.
    # Checked vs the TRUNK (not vs HEAD), so it catches divergence whether newly
    # conflict-resolved OR pre-existing in the module HEAD. Any spine path whose index blob
    # differs from the trunk = module-authored/conflict-resolved → REJECT.
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        [[ "$f" == "ledger/restarts/${lane}.tsv" ]] && continue   # own-lane restart ledger
        is_spine "$f" && VIOLATIONS+=("$f")
    done <<< "$(git diff --cached --name-only "$TRUNK_SHA" 2>/dev/null)"
    REJECT_WHY="DIVERGE from the integration trunk — a currency-sync must adopt the trunk's spine VERBATIM (module-authored/conflict-resolved)"
else
    # === Standard D3 === spine paths changed by THIS commit (vs HEAD; --root if no HEAD).
    if git rev-parse --verify -q HEAD >/dev/null 2>&1; then
        STAGED="$(git diff --cached --name-only 2>/dev/null)"
    else
        STAGED="$(git diff --cached --name-only --root 2>/dev/null)"
    fi
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        [[ "$f" == "ledger/restarts/${lane}.tsv" ]] && continue   # own-lane restart ledger
        is_spine "$f" && VIOLATIONS+=("$f")
    done <<< "$STAGED"
    REJECT_WHY="spine-owned — module lanes commit only their own branch + PROPOSE spine changes via reap-at-merge"
fi

if [[ ${#VIOLATIONS[@]} -gt 0 ]]; then
    echo "pre-commit REJECT: lane '${lane}' (spine_write: ${spine_write:-DENY}) — staged spine path(s) ${REJECT_WHY} (COORDINATION.md §13(1))." >&2
    echo "  Offending spine path(s):" >&2
    for v in "${VIOLATIONS[@]}"; do echo "    - $v" >&2; done
    exit 1
fi

exit 0
