#!/usr/bin/env bash
# agents/commit-msg-hook.sh — COMMIT-TIME GATE. Installed into the SHARED
# $GIT_COMMON_DIR/hooks/commit-msg by scripts/install_pre_commit_hook.sh, so ONE install gates every lane.
#
# WHAT IT DOES: runs `scripts/creed-scan.sh --staged --msg "$1"` on the OUTGOING commit — §GOVERNANCE-CHECK
# (structural), §PREMISE-CHECK at route-to-operator, and trigger→cite, on ADDED lines in the emitting set +
# the message. Exit 1 = REJECT. Judgment-class lines may carry `WAIVE:<class> <8+ word reason>`; every waiver
# is re-surfaced at the next boundary scan (layer two, unchanged).
#
# WHY commit-msg and not only pre-commit: commit BODIES are an emitting surface, and pre-commit cannot see
# the message. The index is fully available here, so the staged added lines are judged in the same fire.
#
# WHICH SCANNER BYTES RUN (the per-lane deployment problem, solved by construction — 0226 §1.4):
#   · every lane EXCEPT the integrator runs the SPINE copy (the spine ref, scripts/spine-ref.sh, :scripts/creed-scan.sh) — a lane whose
#     branch copy is stale still enforces the CURRENT rules (lanes read the spine).
#   · the integrator (spine_write=ALLOW) runs its INDEX copy — so a broken spine scanner can always be fixed by
#     the seat that owns it, instead of deadlocking every commit including the fix.
# FAIL-CLOSED: unresolved lane or unreadable scanner = REJECT, never a silent pass (DISC-CHILD-FAILURE-MUST-SURFACE).
set -u

MSG="${1:-}"
[ -r "$MSG" ] || { echo "commit-msg REJECT: no readable message file ('$MSG') — fail-closed (inv #5)." >&2; exit 1; }
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "commit-msg REJECT: not in a worktree." >&2; exit 1; }
# The spine ref is the ONE resolver's output (the one spine-ref resolver), found from THIS HOOK's own location only
# (0507 R2/R16), never from the work tree git names; no resolution is a REJECT by name, never a literal fallback (inv #5).
# installed (the hooks dir) -> the resolver the installer placed beside it; the source copy under agents/ -> its tree's
# scripts/spine-ref.sh. One position per location, no fallback chain.
_HOOK_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)"
if [ "${_HOOK_DIR##*/}" = agents ]; then SPINE_REF_SH="${_HOOK_DIR%/agents}/scripts/spine-ref.sh"; else SPINE_REF_SH="$_HOOK_DIR/spine-ref.sh"; fi
[ -f "$SPINE_REF_SH" ] || { echo "commit-msg REJECT: SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this hook only; 0507 R2) — fail-closed (inv #5)." >&2; exit 1; }
SPINE_REF="$(bash "$SPINE_REF_SH")" && [ -n "$SPINE_REF" ] || {
    echo "commit-msg REJECT: SPINE-REF-UNRESOLVED -- $SPINE_REF_SH unfilled (the one spine-ref resolver) — fail-closed (inv #5)." >&2; exit 1; }

# Enforcer currency self-check (same rule as pre-commit): a gate that cannot confirm it is the
# current build does not run. The spine ref not yet carrying this file (its own first landing) = WARN, proceed.
_running="${BASH_SOURCE[0]:-$0}"
if _canon="$(git rev-parse -q --verify "${SPINE_REF}:agents/commit-msg-hook.sh" 2>/dev/null)"; then
    if [ "$(git hash-object "$_running" 2>/dev/null)" != "$_canon" ]; then
        echo "commit-msg REJECT: the INSTALLED commit-msg hook is not the canonical build (${SPINE_REF}:agents/commit-msg-hook.sh)." >&2
        echo "  Re-install: scripts/install_pre_commit_hook.sh, then retry." >&2
        exit 1
    fi
else
    echo "commit-msg WARN: ${SPINE_REF} has no agents/commit-msg-hook.sh yet — currency unverified this fire." >&2
fi

LANE_LINE="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>/dev/null)" || {
    echo "commit-msg REJECT: lane UNRESOLVED — cannot pick the scanner source; fail-closed." >&2; exit 1; }
eval "$LANE_LINE"

# the scanner copy runs from a temp dir that carries THIS hook's resolver beside it (0507 R2: found beside the running script)
TD="$(mktemp -d "${TMPDIR:-/tmp}/creed-gate.XXXXXX")" || { echo "commit-msg REJECT: mktemp failed." >&2; exit 1; }
trap 'rm -rf "$TD"' EXIT
T="$TD/creed-scan.sh"
cp "$SPINE_REF_SH" "$TD/spine-ref.sh" || { echo "commit-msg REJECT: cannot place the resolver beside the scanner copy — fail-closed (inv #5)." >&2; exit 1; }
if [ "${spine_write:-DENY}" = "ALLOW" ]; then
    git show :scripts/creed-scan.sh > "$T" 2>/dev/null || cp "$REPO_ROOT/scripts/creed-scan.sh" "$T" 2>/dev/null
    _src="index"
else
    git show "${SPINE_REF}:scripts/creed-scan.sh" > "$T" 2>/dev/null
    _src="spine(${SPINE_REF})"
fi
[ -s "$T" ] || { echo "commit-msg REJECT: scanner unreadable from ${_src:-?} — fail-closed (inv #5)." >&2; exit 1; }

lane="${lane:-unknown}" bash "$T" --staged --msg "$MSG"
rc=$?
case "$rc" in
    0)
        # Detection half (G1 cure text): on every
        # PASS, stamp a `Creed-Gate: PASS <blob>` trailer so a commit whose commit-msg run was
        # skipped (--no-verify / -n / -c core.hooksPath) is detectable BY CONSTRUCTION at
        # post-commit — detect-and-surface, never a block; this branch cannot
        # change the exit code (still exit 0) or any existing output line.
        # <blob> cites the scanner bytes that actually ran this fire ($T — index copy or
        # spine copy per §1.4 above), not a path (DISC-A-NUMBER-CARRIES-ITS-FRAME).
        # --if-exists replace makes this idempotent: an amend that re-fires commit-msg on a
        # message already carrying a trailer gets the trailer REPLACED, never duplicated.
        _scanner_blob="$(git hash-object "$T" 2>/dev/null | cut -c1-8)"
        if [ -n "$_scanner_blob" ]; then
            git interpret-trailers --in-place --if-exists replace \
                --trailer "Creed-Gate: PASS ${_scanner_blob}" "$MSG" 2>/dev/null || true
        fi
        exit 0
        ;;
    1) exit 1 ;;
    *) echo "commit-msg REJECT: scanner (${_src}) exited $rc (unreadable input) — fail-closed, never a silent pass." >&2; exit 1 ;;
esac
