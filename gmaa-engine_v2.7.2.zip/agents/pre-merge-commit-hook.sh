#!/usr/bin/env bash
# agents/pre-merge-commit-hook.sh — SET-AUTH-IMPL-01 item 3 (C-SET-AUTHORIZATION §2: forced merge-path).
#
# FORCED MERGE-PATH. A module branch reaches the integration trunk (main/spine) ONLY via
# scripts/reap_at_merge.sh, which runs the M6(ii) NO-CHERRY-PICK set-membership gate BEFORE it
# computes the merge tree (a non-member branch never touches the index). A RAW `git merge <module>`
# on the trunk BYPASSES M6(ii) — "M6(ii) can't depend on the integrator remembering the script"
# (§2). This hook STRUCTURALLY PREVENTS that raw path.
#
# WHY THIS HOOK (git firing model — verified in the isolated self-test, not assumed; git 2.50.1):
#   - git invokes `pre-merge-commit` right before creating an AUTO-COMMITTING merge commit
#     (a clean `git merge` with no conflicts). This is the ONLY module→trunk route that skips
#     `pre-commit` (M6(i)), so it is the hole this hook closes.
#   - The sanctioned reap uses `git merge --no-ff --no-commit` — pre-merge-commit does NOT fire
#     (verified: git stops "before committing as requested"); the subsequent `git commit` runs
#     `pre-commit` (M6(i) set-coverage) instead. Belt-and-suspenders: reap_at_merge.sh also exports
#     REAP_AT_MERGE=1, so even a future reap that auto-commits is recognised as sanctioned here.
#   - A CONFLICTED raw merge stops; the integrator resolves + `git commit` → `pre-commit` (M6(i))
#     rejects the uncovered module paths. So pre-merge-commit + M6(i) gate every module→trunk route.
#
# ENFORCEMENT MODEL (fail-closed, NO message-based escape): on the trunk, EVERY merge is REJECTED
# unless it carries the sanctioned reap sentinel (REAP_AT_MERGE=1). There is deliberately NO
# allow-branch keyed on the merge source/message — gating on `.git/MERGE_MSG` would be FORGEABLE,
# the very thing M6(i)'s structural-coverage model rejects (structural, not a tag).
# A genuine trunk/remote divergence is reconciled by REBASE (the documented foundation lesson — the
# 9b2a710d incident), never a merge; a true emergency goes to the operator's door (canon §10): no git flag is a
# sanctioned way past this hook (the bypass class is denied inside the harness, MECH-WRITE). A normal `git pull` that FAST-FORWARDS creates no merge commit,
# so this hook never fires on it.
#
# Identity from LOCATION: the trunk is resolved by the one spine-ref resolver scripts/spine-ref.sh (the one spine-ref resolver;
# local bytes only, the TRUNK_BRANCH slot), with no fallback name: unresolvable = REJECT by name.
#
# ⛔ THE CLAUSE BELOW WAS FALSE AND IT WAS THE HOLE. Corrected in the SAME commit that closes it
# (a false safety property left in an enforcer is a known failure class — the next seat
# reading it would "restore" the hole). STRUCK, NOT DELETED, because it is what every reader has been
# told since this hook was written:
#   ~~Merges INTO a non-trunk branch (a module adopting the trunk = currency-sync) are NOT this hook's
#     concern — allowed here; the module-DENY / R1 adopt logic in pre-commit-hook.sh covers spine
#     contamination on commit.~~
# WHY IT IS FALSE, and the contradiction sat ONE PARAGRAPH from its own refutation: this header already
# states (correctly) that the auto-committing merge is the ONLY route that SKIPS pre-commit. So naming
# pre-commit as the module-side cover is self-refuting — pre-commit is precisely what that merge skips.
# MEASURED: on a clean `git merge origin/main` on `exec`, pre-commit NEVER FIRED. No
# authorization / R1-D3 / clean-tree / identity-preserve / rules-restamp check ran at all.
#
# Authority: C-SET-AUTHORIZATION §2 (forced merge-path) / SET-AUTH-IMPL-01 item 3 (M6(ii)).
# Installed via scripts/install_pre_commit_hook.sh into .git/hooks/pre-merge-commit (git hooks aren't
# versioned; this is the canonical source). Currency-verified at every boot by scripts/boot-check.sh.
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0

# The branch being merged INTO (the current branch). Detached HEAD → empty → not the trunk → allow.
CUR_BRANCH="$(git symbolic-ref --short -q HEAD 2>/dev/null || true)"

# The integration trunk is the branch half of the ONE spine-ref resolver's output (the one spine-ref resolver; the same source
# pre-commit uses). No fallback name: no resolution is a REJECT by name (inv #5), never a guessed trunk.
# Found from THIS HOOK's own location only (0507 R2/R16), never from the work tree git names: installed (the hooks dir)
# -> the resolver the installer placed beside it; the source copy under agents/ -> its tree's scripts/spine-ref.sh.
_HOOK_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)"
if [[ "${_HOOK_DIR##*/}" == agents ]]; then SPINE_REF_SH="${_HOOK_DIR%/agents}/scripts/spine-ref.sh"; else SPINE_REF_SH="$_HOOK_DIR/spine-ref.sh"; fi
[[ -f "$SPINE_REF_SH" ]] || { echo "pre-merge-commit REJECT: SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found from this hook's location only; 0507 R2) — fail-closed (inv #5)." >&2; exit 1; }
SPINE_REF="$(bash "$SPINE_REF_SH")" && [[ -n "$SPINE_REF" ]] || {
    echo "pre-merge-commit REJECT: SPINE-REF-UNRESOLVED -- $SPINE_REF_SH unfilled; the integration trunk cannot be resolved (the one spine-ref resolver) — fail-closed (inv #5)." >&2
    exit 1; }
TRUNK_BRANCH="${SPINE_REF#origin/}"

# ── MODULE SIDE (current branch != trunk) ────────────────────────────
# MIRRORS the trunk side rather than inventing a second shape: reject the auto-committing adopt-merge
# unless it carries the sanctioned sentinel, exactly as the trunk side does with REAP_AT_MERGE=1.
#
# ⛔ SENTINEL-ONLY, NEVER SOURCE-BASED, AND THAT IS A FINDING NOT A PREFERENCE: MERGE_HEAD is
# UNPOPULATED at pre-merge-commit time (git 2.50.1 — this hook's own KEY FINDING, git
# firing model). So a source/ref allow-list here is not merely awkward, it is IMPOSSIBLE — and were it
# possible it would be FORGEABLE. Do not "improve" this by keying on the merge source.
#
# WHY ONE MECHANISM FOR ALL LANES (§2): the harms differ in severity but the correct response is
# identical — never let the raw adopt happen. There is no lane on which a WEAKER response is wanted.
# Severity therefore lives in the MESSAGE, not in a second mechanism.
if [[ "$CUR_BRANCH" != "$TRUNK_BRANCH" ]]; then
    # Sanctioned currency-sync. scripts/lane_currency_gate.sh exports this. Belt-and-suspenders: the
    # gate uses `merge --no-commit` today and never trips this hook, so the sentinel is not
    # load-bearing YET — it is what stops a future auto-committing gate refactor from self-bricking.
    [[ "${LANE_CURRENCY_SYNC:-}" == "1" ]] && exit 0

    # Lane-aware SEVERITY in the message only, keyed on the stamp's DECLARED CLASS, never a lane NAME
    # (the same rule as pre-commit-hook.sh's apply-receipts-only carve-out). Resolved
    # from location, never from chat.
    _spine_write="$(sed -n 's/^spine_write:[[:space:]]*//p' "$REPO_ROOT/_boot/BOOTSTRAP.md" 2>/dev/null | head -1)"
    echo "pre-merge-commit REJECT: raw 'git merge' adopting the trunk into lane branch '$CUR_BRANCH' is FORBIDDEN (C-SET-AUTHORIZATION §2, forced merge-path)." >&2
    echo "  WHY: an auto-committing merge is the ONE route that SKIPS pre-commit — so NO authorization, R1-D3, clean-tree, identity-preserve or rules-restamp check runs. Measured, not theorised." >&2
    if [[ "${_spine_write:-}" == "apply-receipts-only" ]]; then
        echo "  ⛔ THIS LANE: a raw adopt here DESTROYS your charter (_boot/ identity). Recovery needs foundation's pen on a lane that can no longer boot. Do not force this." >&2
    else
        echo "  ⛔ THIS LANE: a raw adopt here is an UNAUDITED adopt — stale rules hash, no R1/D3, no identity-preserve." >&2
    fi
    echo "  ⭐ YOU ALMOST CERTAINLY DO NOT NEED THIS AT ALL: a lane is current by READING the spine, not by merging it — 'git show ${SPINE_REF}:<path>' (operator 2026-09-22). 'behind=N' is the single-writer invariant HOLDING, not a deficit." >&2
    echo "  If a sync is genuinely required: scripts/lane_currency_gate.sh (IDENTITY-PRESERVE, R1 adopt-from-trunk)." >&2
    echo "  True emergency: the operator's door (canon §10); no git flag is a sanctioned way past this hook — you will be loudly stuck, never silently bricked." >&2
    exit 1
fi

# On the trunk: the ONLY sanctioned merge is the reap path (scripts/reap_at_merge.sh sets this). Fail-closed.
[[ "${REAP_AT_MERGE:-}" == "1" ]] && exit 0

echo "pre-merge-commit REJECT: raw 'git merge' into the integration trunk '$TRUNK_BRANCH' is FORBIDDEN (C-SET-AUTHORIZATION §2, forced merge-path)." >&2
echo "  A raw merge bypasses the M6(ii) NO-CHERRY-PICK set-membership gate — a module branch reaches main ONLY inside a RATIFIED set naming its lane." >&2
echo "  Module → trunk:  scripts/reap_at_merge.sh <lane>   (any lane declared in _orchestration/lane-provisioning.md; assembles the receipt, runs M6(ii), merges as the integrator)." >&2
echo "  Divergent trunk: reconcile by REBASE, not a merge (the documented lesson). True emergency: the operator's door (canon §10); no git flag is a sanctioned way past this hook." >&2
exit 1
