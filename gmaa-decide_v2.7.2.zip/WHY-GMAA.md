# Why GMAA: what it is, what you get, and whether it fits
**Read this first, before the architecture document. Written for the person deciding, and for the chat session they ask to assess the fit.** Engine package v2.7 line · canon v1.6.9.

## What it is, in three sentences
GMAA (the Governed Multi-Agent Architecture) is a way to run several AI agent sessions, and the people who direct them, against one codebase without the result quietly falling apart. It is a written specification (the canon, free, CC BY 4.0) plus a runnable engine (this package: scripts, git hooks, probes, seat definitions, and the documents that stand it up). You adopt it by deciding a short set of things that only you can decide, running one command, and letting the writer seat build the rest from your roster.

## The problem it exists to solve
When more than one agent writes to the same project, each change can be correct on its own and the combination still broken, because nobody looked at the whole pending set as one thing. Agents also report "done" without evidence, drift from the identity they were given, degrade silently when a check fails, and lose everything they knew when their context ends. Ordinary code review does not catch any of this: it authorizes at the wrong unit (the single change) and trusts the agent's own account of its work.

## What GMAA does about it
Each of these is a mechanism in the package, not advice.
- **Authorization at the right unit.** Every change is still reviewed on its own, and then the complete pending set is assessed as a unit by an integrator seat and ratified by one named human (the apex ratifier) before any member lands. Both gates fire; neither replaces the other.
- **One writer.** Exactly one seat, foundation, commits to the trunk. Every other seat works in its own worktree on its own branch. A pre-commit hook, installed in git itself, is the boundary: it is structural, by path and by signature, not a convention.
- **Every seat signs.** Each writing seat has its own ed25519 key, kept outside every worktree. The hook refuses an unsigned or wrongly signed commit. A signature tells you which seat's configuration made a commit.
- **Identity from location, never from chat.** A seat reads who it is from a stamp in its own worktree at every boot. It cannot be talked into being a different seat, and it halts rather than guess.
- **An auditor after every commit.** A post-commit hook runs the standing probes and writes receipts and findings to a ledger that no seat but the writer can commit to, and the writer's commits are signed.
- **Nothing closes without evidence.** "Done", "passed" and "resolved" are hypotheses until a probe can re-run them. Absences are reported with their denominator. A refuted premise is retracted, not argued.
- **Halt loud.** A failed check names its reason and stops. There is no silent fallback and no degraded continue.
- **Memory is the record, not the session.** Every seat writes its handoff before it ends; the next session boots from the repository, not from a summary. Restarting is cheap by design.
- **Proof that the controls exist.** The probes carry planted-fault poles, and adoption ends with a seeded fault you plant yourself: the machinery must catch it. A clean first run proves nothing.
- **A cost brake.** A metered call is checked against the caps you set before it runs, and the check says UNREADABLE by name when it cannot read your usage, never "zero spent".

## What you get, in plain terms
A project where you can add agents without losing control of the trunk; where you can tell, from the record alone, who changed what, under which ratified set, and what the auditor saw; where an agent that is wrong stops instead of improvising; and where a new session, human or agent, picks up from the record in minutes.

## What it costs you
- **Nine decisions, yours alone:** what must always hold in your system (invariants), how your systems are reached (the auth paths), who ratifies complete change-sets (the apex ratifier), which seats exist and why (the roster, cut by one rule the cover gives), six values the engine reads (the slots), your project's token, which seat is the apex's, your project's own sections of the coordination protocol, and the roster of subagents each seat may spawn (four classes; the task picks the class). A chat session proposes and writes them down; it cannot make them for you.
- **A terminal session** on a Mac or on Ubuntu (on its own, or under WSL2 on Windows) with git, tmux, python3 with its `yaml` module (PyYAML), jq, perl, OpenSSH (the client only; no server is ever part of this) and a private git remote. The guide assumes you have never used a terminal. One command stands the writer seat up; the writer then provisions every other seat on your roster, one set each that it lands on your go.
- **Ceremony on every change.** Sets are assembled and ratified; commits are signed; closures carry evidence. This is the point, and it is also a cost. A one-person, one-agent weekend project does not need it.

## When it fits, and when it does not
**It fits** when more than one agent (or more than one person directing agents) will write to one codebase; when a wrong change has real consequences; when you need to be able to show, later, why something landed; when you already feel the "it was fine on its own" failure.
**It does not fit** when there will be one agent and one person and no stakes; when the project cannot run git, tmux and a shell; when nobody is willing to be the named ratifier; or when you want the agents to be unsupervised. GMAA makes supervision cheap and structural; it does not remove it. Judge both lists by the project as you plan to run it, not as it stands today.

## How adoption runs
Five phases, in order. The first two need nothing installed and nothing decided but one word.
1. **Decide.** Download the decision kit (`gmaa-decide_<version>.zip`, four files, beside the engine), paste its first file into a new chat session with the other three attached. The session proves it has read them, names the architect role it is taking, and ends with one of two answers: adopt, or do not adopt. Nothing is built.
2. **Your go.** You say "yes, adopt it", or you stop. Stopping is a valid result.
3. **The folder.** Create your project folder, lowercase, no spaces: its name is your project token, the word every seat's session will carry. Unzip the engine into `foundation/` inside it.
4. **The fills.** Paste the cover's Phase 4 line into the same session with the files it names attached. In conversation it settles your nine decisions and returns the files: `FOUNDATION.md`, `seats.yaml`, `COORDINATION.md`, `genesis.conf`, and one definition per subagent. You put them in `foundation/`.
5. **Genesis.** In `foundation/`: `bash genesis.sh`. It fills, checks, seeds, enrolls the writer, installs the hooks and launches it. The writer then provisions every other seat on your roster, one set each that it lands on your go, and you plant one fault to prove the controls catch it. Genesis is complete when every seat on the roster exists and the fault was caught.
`ADOPTION-COVER.md` is the full cover for the five phases; `GETTING-STARTED-LINUX-MAC.md` walks the terminal part from a blank machine; `FIRST-SET.md` walks the first unit of work after that.

## How seats are cut, and why
Seats are the architecture's unit of authority, and the roster is yours to rule on one rule. A seat is one agent session bound to one worktree, one role, one operator, one allow-list and one key; one session holds one seat, always, because credentials partition authority and only separate contexts partition cognition. The roles are a small fixed set. Three seats are required in every project: foundation, the sole writer, who judges, assembles and lands and never builds; the executor, foundation's right hand, who builds every set outside a lane's territory and runs every side effect within an allow-list, on its own branch; and the architect, who authors and rules and never commits to the trunk. Lanes take one module territory each, never the trunk; a designer authors view-layer work against a typed seam; and you, the operator, are a person, never a seat. The auditor is not a seat: it is the post-commit hook and its probes, which file and never fix. Seats are created by boundaries, never by workload: a seat must exist when its work must judge, authorize, accept or audit another seat's work, or when a distinct territory needs its own writer; it must not exist if its boundary cannot be stated in one sentence; throughput is answered by fan-out inside a seat, never by a new seat. The common first roster is the three required seats, the architect as a chat seat, and one lane per module territory.

## For the chat session asked to assess this
You have been given this file, the canon (`GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_9.md`) and `ADOPTION-COVER.md`, and possibly the project's own spec, with the paste file `00-PASTE-THIS.txt` as your instruction. Your job in this conversation is Phase 1 only: prove the reading, take a role (Product Architect if the project is itself a product whose governance you would custody; Solution Architect if you would be conforming one project to the framework), judge the fit, and end with adopt or do not adopt, with the reason. Do not implement anything, do not generate files, and do not assume the operator has said yes. "Do not adopt" is a correct outcome, not a failure.

## Where things are
- The canon: `GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_9.md` (in the zip; also at https://gmaa.ai/canon.html).
- The cover and the guide: `ADOPTION-COVER.md`, `GETTING-STARTED-LINUX-MAC.md`.
- The decision kit: `gmaa-decide_<version>.zip` beside the engine zip, four files, the first one the text to paste.
- What you fill and where: `SLOTS.md`. What genesis writes: `bash genesis.sh explain`.
- Licenses: the canon CC BY 4.0; the engine Apache 2.0 with the Commons Clause (`LICENSE.md`). Cite by version.
- Questions and field reports: arch@gmaa.ai. Every place you or the session had to guess is the most useful thing you can send.
