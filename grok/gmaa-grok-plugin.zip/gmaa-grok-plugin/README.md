# gmaa-grok plugin 2.5.6

Grok TUI harness for sealed engine `gmaa-engine_v2.5.6.zip` sha256 `ae2d946c9602b9888d3a6c7b265e800fb3d8eb0e1b9e33f472aa00c3233b612f`.

This plugin is not the spine. Companion zip: `gmaa-engine-grok_v2.5.6.zip`.

## Install

```
grok plugin install <path-to-this-folder> --trust
```

## Start here

`/gmaa-adopt` — ADOPTION-COVER four phases. Chat authors fills. Vanilla `grok` instantiates.

Spoken restart: `/restart` (or restart / I need to restart). Then `scripts/orc-restart.sh <lane> --force`.
