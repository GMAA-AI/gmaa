#!/usr/bin/env bash
# agents/commit-msg-hook.sh — provisioning subject-shape gate (pre-commit family).
# A commit that changes _boot/BOOTSTRAP.md lane: vs HEAD must carry:
#   provision: <lane> seat, per operator ruling <ref>
# Genesis (no HEAD, or no lane: change) is skipped.
set -u
MSGFILE="${1:-}"
[[ -n "$MSGFILE" && -f "$MSGFILE" ]] || exit 0
if ! git rev-parse --verify -q HEAD >/dev/null 2>&1; then
    exit 0
fi
if ! git diff --cached --name-only 2>/dev/null | grep -qx '_boot/BOOTSTRAP.md'; then
    exit 0
fi
if ! git cat-file -e HEAD:_boot/BOOTSTRAP.md 2>/dev/null; then
    exit 0
fi
OLD="$(git show HEAD:_boot/BOOTSTRAP.md 2>/dev/null | sed -n 's/^lane:[[:space:]]*//p' | head -1)"
NEW="$(sed -n 's/^lane:[[:space:]]*//p' _boot/BOOTSTRAP.md 2>/dev/null | head -1)"
if [[ -z "$NEW" || "$OLD" == "$NEW" ]]; then
    exit 0
fi
SUBJ="$(sed -n '1p' "$MSGFILE")"
case "$SUBJ" in
    "provision: $NEW seat, per operator ruling "*) exit 0 ;;
esac
echo "commit-msg REJECT: provisioning-shape — subject must be: provision: $NEW seat, per operator ruling <ref>" >&2
exit 1
