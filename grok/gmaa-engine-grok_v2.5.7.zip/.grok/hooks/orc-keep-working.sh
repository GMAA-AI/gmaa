#!/bin/bash
# Stop hook — prevents the orc seat from stopping when queued autonomous work exists.
set -euo pipefail
INPUT=$(cat)
STOP_ACTIVE=$(echo "$INPUT" | jq -r '.stop_hook_active // false')
[[ "$STOP_ACTIVE" == "true" ]] && exit 0

PROJ="${GROK_PROJECT_DIR:-$(pwd)}"
QUEUE="$PROJ/.grok/agent-memory/orc/autonomous_work_queue.md"

if [[ -s "$QUEUE" ]]; then
  NEXT_ITEM=$(head -1 "$QUEUE")
  jq -n --arg reason "Autonomous work queued: $NEXT_ITEM" '{
    decision: "block",
    reason: $reason
  }'
  exit 0
fi
exit 0
