# Getting Started: Linux and Mac
**Setting up on a Linux or Mac machine. A Windows and WSL guide ships in a future release.**

This walks you from a blank machine to a completed adoption, assuming you have never used a terminal. The adoption runs in four phases (see `ADOPTION-COVER.md`): assessment and design happen **in chat**, implementation happens **in Grok TUI**. If you **already have Grok TUI installed, skip straight to Step 5.**

## What you need before starting
- A Linux machine with a POSIX shell, or a Mac (macOS 13 or later)
- A xAI Grok account with a paid plan (Pro, Max, Team, or Enterprise). Sign up at grok.com if needed.
- All the files that came with this package (keep the engine zip as a zip)

## Step 1: Check whether Grok TUI is already installed
1. Open your terminal. **Linux:** open your terminal app. **Mac:** press **Cmd + Space**, type **Terminal**, press **Enter**.
2. Type exactly `grok --version` and press **Enter**.
3. If you see a version number (like `2.x.x`) you have it. **Skip to Step 5.**
4. If you see `command not found`, continue to Step 2.

## Step 2: Install Grok TUI
1. In the same terminal, copy and paste this single line, then press **Enter**:
   ```
   curl -fsSL https://x.ai/cli/install.sh | bash
   ```
2. Wait for it to finish (a minute or two on a normal connection). No password should be needed.
3. **Quit the terminal completely and reopen it.** This is required so it finds the new command.
4. Type `grok --version` and press **Enter**. A version number means success. If not, type `grok --version` and follow what it says, or see Troubleshooting.

**Also install tmux** (fleet sessions, needed when you operate after adopting). **Linux:** `sudo apt install tmux` (or your distro's package manager). **Mac:** `brew install tmux`. Confirm with `tmux -V` and `git --version`.

## Step 3: Sign in once
1. Type `grok` and press **Enter**.
2. First launch walks you through setup. Pick a theme (any), and when it asks about signing in, choose your **xAI Grok account**. A browser window opens; sign in and approve.
3. Type `/exit` and press **Enter**. The real launch comes later, and it is the operator's act, not the vanilla session's.

## Step 4: Create the project folder (Phase 0)
1. Create the folder your project will live in, at your code root. Name it **lowercase, with no spaces**. This becomes your git repository name. **This folder is the PARENT.** Vanilla instantiate creates `foundation/` inside it. Every further lane will be a sibling worktree `<folder>/<lane>` (folder equals lane; `main` is a branch, never a folder name).
2. Copy into that parent folder the engine zip, the plugin directory, `ADOPTION-COVER.md`, and (when you have them) the two fills. **Do not mkdir `foundation/` and do not unzip the engine.** Vanilla instantiate creates `foundation/` and places the engine there. The loose files beside the zip in the release (`README.md`, `LICENSE.md`, the specification PDF, `SHA256SUMS`) are the public face; copy `README.md` and `LICENSE.md` in beside the zip if you want them in the project folder. Every worktree later carries its own `scripts/` + `launch-orc.sh` (spine paths, propagated by currency-sync, never hand-copied); updates land on the spine by foundation then propagate per lane (`scripts/lane_currency_gate.sh` + per-lane HEAD readback).
3. Confirm the substrate floor from the parent (`grok --version`, `git --version`, `tmux -V`). After instantiate, `bash scripts/preflight.sh` from `foundation/` is the same check as a script (it provisions nothing and halts loud on any miss).

## Step 5: Run Phases 1 through 3 fills (choose your surface)  *(skip-to point if you already had Grok TUI)*
1. Read `ADOPTION-COVER.md` yourself first. It is one page, and it explains the four phases and which decisions are yours.
   **The chat path below is the recommended route.** The session that assesses and records your decisions stays separate from the one that implements them. (Work solely in the terminal? A Code-only alternative exists, described in the cover, but if you are unsure, use the chat path.) Continuing here:
2. In a chat session (a Grok project chat works well), upload the **architecture document** (`canon/` once the zip is opened by instantiate, or the spec PDF beside the zip), the **cover**, **`docs/ENGINE-MAP.md`** (inside the zip; or ask the chat to wait until the fills exist), and, if your project is already thought out, your project's spec. Ask:
   > *Read `GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1_PUBLIC.md`, `ADOPTION-COVER.md`, and `docs/ENGINE-MAP.md`. Is GMAA a good fit for this project? Assess only. Do not implement anything yet.*
3. The chat states which architect role it is assuming and gives you a fit assessment. **If you decide to adopt, say so explicitly.** Nothing proceeds until you do (Phase 2).
4. Work through your three decisions in conversation (invariants, auth paths, who ratifies), and have the chat write the decision-complete fill set: **`docs/FOUNDATION.md`**, **`seats.yaml`**, and the instantiation relay from `docs/INSTANTIATE-RELAY_skeleton.md`. Phase 3 closes only when one session reviews that set for joint coherence. Each executable fill carries an authored-against block.
5. **Download the three fills and drop them into the parent folder** from Step 4 (beside the zip). `seats.yaml` is intent, not authorization.

## Step 6: Vanilla instantiate — foundation only (Phase 4, first half)
1. In the terminal, type `cd ` (c, d, one space; do not press Enter), drag the **parent** folder onto the terminal window, and press **Enter**.
2. Start the instantiation in a **plain** Grok session (not the launcher): type `grok` and press **Enter**. The first instantiation uses vanilla Grok, because the launcher boots a seat that must already resolve its lane from the worktree, so on an un-instantiated project it would halt. Give the session:
   ```
   Read docs/FOUNDATION.md, seats.yaml, and ADOPTION-COVER.md.
   Instantiate this project per canon §12.
   Layout: this folder is the parent. Vanilla instantiate creates <parent>/foundation/
   (git init inside foundation/; engine files live there, checked out to main).
   Stand up the foundation lane only: git init, the foundation worktree and stamp,
   generated files, first commit, STOP.
   Do not create executor or any other lane. Do not launch anyone.
   Further seats.yaml rows are intent, not authorization.
   ```
3. It verifies the fills and stands up the **foundation** lane only (the writer). That worktree folder is named `foundation` and is checked out to `main` (folder equals lane; `main` is a branch, never a folder name). It generates the governance files and makes the **genesis commit**. Then it **stops**. Vanilla instantiate never launches. Launch is the operator's act.
4. If it halts naming a missing decision, that is it working correctly. Go settle the decision. Do not work around the halt.

## Step 6b: Remote before anything is treated as safe
Immediately after the genesis commit, **configure a git remote** (create the empty GitHub repository, `git remote add origin <url>`, and push). Until a remote exists, boot will name a WAIT: nothing here is origin-durable. Genesis may precede the remote; the remote must exist before you treat the work as origin-durable. Do not skip this step.

## Lane stand-up protocol (every lane after foundation)
Four parts; no seat holds two of them. **`seats.yaml` is intent, not authorization.**
1. The operator rules a lane into existence (boundary in one sentence).
2. Charter material precedes provisioning.
3. Foundation provisions and commits exactly one lane as one set (`scripts/seat-add.sh <lane> <ruling-ref>`).
4. The operator launches through the launcher (`./launch-orc.sh` from inside that lane folder; `grok --agent orc`) and verifies the header (`BOOT-ACK` and `BOOT-CHECK`).

Optional pattern beside that raw protocol: bind a lane mint to a named existing approval gate (`scripts/ratify.sh` / a SET-NNNN packet) so the provision commit rides a ratified set. Do not invent a second gate.

See `OPERATOR-GUIDE.md` for the operator's half (rulings, launches, the pre-spawn header check, launch provenance).

## Step 6c: Hooks, then the operator launches foundation
1. Make the launcher and scripts executable (once, before first launch): `chmod +x launch-orc.sh scripts/*.sh scripts/test/*.sh`
2. **Install the two git hooks** (once per repository; hooks are not versioned, so the package ships installers): `bash scripts/install_pre_commit_hook.sh && bash scripts/install_post_commit_hook.sh`. The pre-commit hook IS the spine-write boundary; the post-commit hook is the auditor. Without them there is no gate, only prose. The launcher halts if the pre-commit hook is missing.
3. **The operator** launches **foundation** with the launcher: from inside `foundation/`, run `./launch-orc.sh`. Watch for `BOOT-ACK: ...` and the `BOOT-CHECK: ...` line; that first turn is the only launch proof. Vanilla did not launch this seat.
4. Further lanes wait on an operator ruling, then `scripts/seat-add.sh`, then an operator launch. One-owner-per-surface (`COORDINATION.md` §1): a given file belongs to exactly one lane. Module lanes are single-writer to their own lane territory (own branch); they act only on their own `_boot/BOOTSTRAP.md` and never apply to the spine (`COORDINATION.md` §13(2); `AGENTS.md` seats).
5. **The `[set SET-NNNN]` message convention (advisory):** once the set-gate is live, a foundation commit covered by a ratified set MAY carry `[set SET-NNNN]` in its commit message so readers can trace coverage at a glance. It is a post-commit-verified CONVENTION, never the gate - enforcement is STRUCTURAL, by path, in the pre-commit hook (a well-formed message cannot forge coverage; AGENTS.md invariant #6).

## Step 7: The proof (do not skip)
Run the seeded-fault test (canon §12 step 8) with the agent. It plants a deliberate conflict, and the machinery must detect, name, hold, and recover it. **A clean run proves nothing.** Note what was seeded and whether it was caught.

## Upgrading (later)
Foundation runs the engine update; see `docs/ENGINE-UPDATE.md`.

## Step 8: Feedback (welcome)
`ADOPTION-COVER.md` lists what is most useful to send to arch@gmaa.ai, above all every place you or the AI had to guess.

## Troubleshooting
- **`command not found` after installing:** you did not reopen the terminal (Step 2.3). Or run `grok --version`.
- **`permission denied` running the launcher:** you skipped the chmod step; run `chmod +x launch-orc.sh scripts/*.sh scripts/test/*.sh`, then `./launch-orc.sh`.
- **`HALT: project-token resolution failed` or `not in a git worktree` on launch:** the folder is not an instantiated repository yet. The launcher only boots a seat that already resolves its lane from a committed `_boot/` stamp inside a git worktree. Finish Step 6 (vanilla instantiate) first. The operator launches; vanilla never does.
- **`HALT: pre-commit hook not installed`:** run the two installers in Step 6c.
- **BOOT-CHECK WAIT: no origin:** configure the remote (Step 6b). This is a named wait, not a halt. Nothing here is origin-durable until you do.
- **The launcher says the fills are not there yet:** this is not an error. Finish the chat phases and drop `docs/FOUNDATION.md` and `seats.yaml` in, or take the Code-only path in the cover.
- **Install seems blocked:** on company-managed Macs, security policy may interfere. Ask IT, or see the official docs.
- **Never want to touch a terminal?** The Grok TUI app includes Grok TUI without the terminal (grok.com/download). The chat phases already run in chat by design.
- Official install docs: https://x.ai/cli/install.sh
