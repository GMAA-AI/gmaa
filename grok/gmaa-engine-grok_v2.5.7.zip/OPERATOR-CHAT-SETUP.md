# SETTING UP THE CHAT SIDE: read this before your first chat session
*(One page. Skipping any step below produces the same symptom: your next session wakes up lost, with no idea who it is, what its job is, or what came before. That is not a model failure; it is a missing project or a missing bootstrap.)*

## 1 · One project per program
Create a **Grok project chat** for this adoption. The project is the chat seat's home (the equivalent of a worktree). All of its identity lives there, not in any single conversation.

## 2 · Project instructions = the seat's standing identity
Paste the provided project-instructions block into the project's **instructions** (Project → Instructions). Every session inside the project reads it automatically, every time. This is how a brand-new session knows who it is and what its job is without you re-explaining anything.

## 3 · Every session stays INSIDE the project
Always start chat sessions **from within the project**. A chat started outside the project has none of the instructions, none of the knowledge files, no memory scope. It is a stranger. If you catch yourself in a stray session, stop and restart inside the project.

## 4 · Don't mix surfaces
Cowork sessions and regular chat sessions are **different seats**. Keep this program's architect work in its chat project. Don't move its files or bootstraps into Cowork, and don't run its sessions there. One session, one seat, one surface.

## 5 · Bootstrap between sessions
Chat sessions don't share memory of specifics. Bridge them:
- **At session close:** ask the seat to write its session bootstrap (current state, open items, decisions). Save the file.
- **At the next session's start:** upload that bootstrap as the first message. The new session boots from it.
Session N's close feeds session N+1's boot. Skip the bootstrap and you get the lost-session symptom above.

## 6 · Keep the project's knowledge current
When documents change (registers, charters, key relays), update the copies in the project's knowledge files. Sessions read what's there. A stale copy quietly becomes a stale seat. Delete superseded versions so there's exactly one current copy of each.

**The whole rule in one line: one project per program · instructions pasted once · every session inside the project · surfaces never mixed · a bootstrap out at close and in at open · knowledge kept current.**

## 7 · Chat-architect adoption fills (gated boot-report)

The chat architect's adoption deliverables are `docs/FOUNDATION.md`, `seats.yaml`, and the instantiation relay (`docs/INSTANTIATE-RELAY_skeleton.md`). Every chat-architect boot report states, as a gated list: **which fills exist** and **which it still owes**. Phase 3 closes only on that complete set, reviewed together by one session for joint coherence. An owed fill is a named open item. The seat does not author product work while a listed fill is owed. Every executable artifact the seat authors carries an authored-against block; foundation refuses a file without one. See `docs/CHAT-SEAT-PROJECT-INSTRUCTIONS_skeleton.md`.

A chat surface is ungoverned context. Pin, refuse gate, set review, and the `scripts/sync_knowledge.sh` loop are the manual bridge; the structural cure is governed-context, design-stage, not solved here.

