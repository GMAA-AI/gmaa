<!-- skeleton -->
# INSTANTIATE RELAY / PROMPT — {{PROJECT_NAME}}

**Status:** shipped template. Chat authors a filled copy; foundation executes it only after
`scripts/verify_artifact_pin.sh` PASSes. Artifact without the authored-against block is not
executable.

authored-against:
  head: {{HEAD_SHA_OR_LITERAL_no repository exists}}
  date: {{YYYY-MM-DD}}
  ferried-snapshots: {{names and pins of ferried snapshots this artifact relied on}}

## Subordination (G1)

Canon governs. Then the engine contracts in this package. Then this relay. Observed script
behavior over stated instruction. Divergence is filed to the register; it is not silently
papered by the relay.

## Halt-on-unverifiable (G2)

Any mismatch, missing file, failed hash, or instruction that cannot be verified is a named
HALT. Do not guess. Do not invent a substitute step.

## Battery law (G3)

A green-only board on seeded-fault proofs is itself a HALT. Step 8 must be seen to fail on
a planted fault before a pass counts. Clean-only is vocabulary, not governance.

## Instantiation bound

Stand up the foundation lane only: git init, foundation worktree and stamp, generated files,
first commit, STOP. Do not create executor or any other lane. Do not launch anyone. Configure
a remote after genesis before treating the work as origin-durable. `seats.yaml` is intent, not
authorization.

## Lane-minting (G4)

The raw protocol remains four parts (operator ruling, charter precedes provisioning,
foundation `scripts/seat-add.sh` one lane one commit, operator launch plus header check).
An optional pattern beside that raw protocol: bind a lane mint to a named existing approval
gate (`scripts/ratify.sh` / a SET-NNNN packet) so the provision commit rides a ratified set.
Do not invent a second gate.

## Phase 3 fill set (F3)

Phase 3 closes only on the complete fill set (`docs/FOUNDATION.md` + `seats.yaml` + this
instantiation relay) reviewed as a set by one session for joint coherence.

## Foundation execution

First step of relay-consumption: `bash scripts/verify_artifact_pin.sh <this-file>`.
Mismatch prints both shas and HALTs. No pin refuses. Then execute only what the pin allowed.
