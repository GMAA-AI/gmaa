# The GMAA Engine Map

**How the engine implements the specification.** Engine package v2.5.6 · canon pin v1.6.1 · cite by version. Canonical home: gmaa.ai. Verification fingerprints for the release are on gmaa.ai/versions.html.

**Who this is for.** Anyone evaluating GMAA for a project, and anyone who has downloaded the engine and wants the map before the tree. The specification states the law; the engine is the machinery that enforces it. Reading the law alone answers "what must hold" but not "what runs, what fires it, and what it costs to operate," and an evaluation made on the law alone tends to overprice the discipline and misread designed absences as gaps. This document is the missing middle: every file in the release, grouped into ten functional areas, each anchored to its canon section, with the execution wiring that shows what invokes what and when.

**Three facts an evaluation can miss reading the specification alone.** First, the engine creates its own repository at instantiation: no prior version control is required, and an ungoverned workspace is the starting condition adoption is designed for, not a blocker to it. Second, empty substrate slots are a designed posture, not gaps: a project with no database, no API, and no side-effectful backend leaves the C-DB and C-GATE slots unfilled, and SLOTS.md is the inventory of exactly those decisions. Third, the discipline is wired, not manual: hooks fire at every commit, a guard fires on every shell call, probes run on schedule, and seat files are generated rather than maintained, so the recurring human act is one ratification decision per set, and that decision is the product rather than the overhead.

**Method.** The canon (v1.6.1, all sections) was read whole, then every one of the 102 files in the package plus the 4 loose release files beside the zip was inventoried and its header, purpose block, or full body read. Every file is assigned to exactly one functional area below; a coverage account at the foot proves nothing was orphaned. Where a file is machinery, the map states what invokes it and when it fires, because a gate is defined as much by its trigger as by its logic.

**The shape of the whole thing in one paragraph.** The canon states one correction: authorize the set, not the change, with an integrator agent assessing and an independent human ratifying. The engine implements that correction as ten cooperating layers: an identity layer that makes a seat something you derive rather than assert; a single-writer enforcement layer that makes the spine physically uncommittable by anyone but foundation; the set-authorization machinery itself, which is the thesis in executable form; a work lifecycle that moves a change from dispatch to independently audited closure; a merge and reap layer that keeps worktrees honest; a relay layer that keeps transport off the participants; a standing audit layer that probes invariants instead of asserting them; an instantiation and upgrade layer that turns the blank template into a project and keeps it upgradeable; the harness wiring that makes the runtime itself enforce the above; and the release integrity envelope around all of it.

---

## 1 The specification layer, the law everything below implements

**Canon anchor: the whole document.**

| File | Role |
|---|---|
| `canon/GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1_PUBLIC.md` | The specification, carried in-zip so every adopter holds the exact law their engine version conforms to. CC BY 4.0, licensed separately from the engine. Nothing executes it; everything below is checked against it, and the set assessment (§4, §10) can find a set in conflict with any part of it. |

The canon's own instantiation checklist (§12) is the adopter's entry point into it; section 9 below carries the files that walk it.

## 2 Identity and the seat lifecycle

**Canon anchors: §1.0 definitions, §1.1 seats and surfaces, §2 ONE-SESSION-ONE-SEAT, §7.1 Boot-0, §7.2 provisioning, §7.3 project-qualified identity.**

The design law of this area: identity comes from location, is derived on both sides of the spawn boundary, and the two derivations must agree or the seat halts. A hand-made folder cannot mint a seat because it has no committed stamp.

| File | What it is and what runs it |
|---|---|
| `_boot/BOOTSTRAP.md` | The stamp: project, lane, session name, branch, fixed at provisioning. Read at boot by the launcher and the resolver; never asserted at runtime. |
| `_boot/CHARTER-foundation.md`, `_boot/CHARTER-executor.md` | The two shipped seat charters, read at Boot-0 step 7, authored before the seat exists per charter-precedes-boot. |
| `scripts/resolve-lane.sh` | The shared identity resolver: lane = worktree folder name, cross-checked against the stamp, halt on mismatch. Consumed by cold-boot, the pre-commit hook, and the post-commit hook, so commit-time enforcement keys on the same identity boot does. |
| `scripts/resolve-project.sh` | The §7.3 project-token resolver: reads the stamped `project:` field, composes `{project}-{lane}` for the tmux namespace, never guesses. |
| `launch-orc.sh` | The one launcher, identical bytes in every worktree. Resolves lane from the stamp, refuses double-launch on the exact qualified session name, creates the named tmux session, sends the launch line, prints an observed-facts receipt. |
| `scripts/orc-up.sh` | The two-word operator wrapper over the launch path: fail-closed bootstrap check, named session at the lane worktree, `grok --agent orc`. |
| `scripts/orc-restart.sh` | The §7.4 remedy made cheap: checkpoint first, kill, orc-up. Restart over degraded continuation. |
| `scripts/boot-check.sh` | The boot-discipline presence and currency gate, one script for all lanes. Fired two ways: called from each lane's bootstrap, and wired into the harness `SessionStart` hook so presence is harness-enforced rather than agent willpower. |
| `scripts/seat-add.sh` | Foundation-only, resolver-gated provisioner: one lane per invocation, ruling-ref required, `seats.yaml` row verified at HEAD (intent, not authorization), creed block byte-checked against foundation, one `provision:` commit, never launches. Removal mirror deferred (seat-remove.sh not shipping). |
| `scripts/preflight.sh` | The substrate floor made testable: checks Grok TUI, git with auth, tmux, and that every shipped agent definition leads with loadable frontmatter. Reports and halts; provisions nothing, per the floor ruling. |
| `AGENTS.md` | The condensed hot operating surface every session loads: cold-boot identity, the B6 context lifecycle, the binding invariant shapes, seat topology, slot pointers. |

**The agent-definition roster (`.grok/agents/`), canon §1.0 "agent definition" and §1.3 subagent classes.** These are the qualifications a session loads to become a fit occupant:

| Definition | Class and boundary |
|---|---|
| `orc.md` | The role-neutral orchestrator seat definition; the folder it launches in resolves whether it is foundation (spine write ALLOW) or a module lane (DENY). The one definition that is a seat, not a subagent. |
| `architect.md` | The optional code-resident architect seat: reads everything at HEAD read-only, ratifies HOW-class, writes exactly one territory (its drop-zone), never commits, never executes mechanisms. |
| `build-worker.md` | Builder class: one work package per spawn, own branch, emits artifact plus probe plus receipt, closure deferred to the independent audit. |
| `dispatch-executor.md` | Advancing-executor class: runs dispatch files pass by pass, surfaces ratification checkpoints, never strategizes. |
| `docs-resolver.md` | Read-only prober for live external documentation; returns verbatim content with source citations, per discipline rule 3. |
| `general-purpose.md` | Bounded fan-out worker for foundation: authoring-only by default, never commits, halts loud on ambiguity. |
| `canvas-monitor.md` | Read-only drift monitor over canvas-surface outputs, spawned on a logged event, never modifies what it watches. |

One file in this area is deliberately absent: **`seats.yaml` is not shipped.** It is the adopter's roster and spine-path declaration, created at instantiation (SLOTS.md row 49), spine-owned and set-gated once it exists, and read at HEAD by the enforcement layer below.

## 3 Single-writer enforcement and spine protection

**Canon anchors: §1.1 single-writer invariant, §8 permission architecture, Appendix A wrong-authorization-unit and FIX-SURFACE-DIVERGENCE.**

This area answers one question mechanically: can anyone but foundation land bytes on the spine? The answer is layered so that no single bypass defeats it.

| File | What it is and what runs it |
|---|---|
| `scripts/spine-census.sh` | The single authoritative emitter of what counts as a protected spine path, one path per line. The v2.5.6 fix: every enforcement consumer reads its census from here, ending the hand-copied-census drift that let a merge-time gate miss the set-authorization machinery's own files. Consumers: the pre-commit hook, `reap_at_merge.sh`, `ratify.sh`, `probe_state_propagation.sh`, `probe_set_gate.sh`. |
| `scripts/declared-spine-paths.sh` | The adopter's extension of the census: reads `spine_paths:` from `seats.yaml` **at HEAD** (`git show HEAD:seats.yaml`), never the working tree, so a lane cannot forge its own roster to widen its own exemptions. |
| `agents/pre-commit-hook.sh` | The D3 hard gate, canonical source for `.git/hooks/pre-commit`: resolves the committing lane, reads the census plus declared paths, blocks a module or executor commit touching any of them, and carries the set-coverage check on foundation's own authored-spine commits. |
| `scripts/install_pre_commit_hook.sh` | Installs the above into `.git/hooks/`; the install is a checklist step, and its presence is what the boot and audit layers verify. |
| `scripts/guard-command-shape.sh` | The PreToolUse guard on every Bash call: tokenizes past git global flags and denies `--no-verify`, `-n`, `--force` and forced refspecs **wherever they sit in the command**, closing the flag-after-subcommand hole a prefix-matched deny cannot cover. Fail-closed, exit 2 blocks. |
| `.grok/settings.json` | The harness plane itself, §8 in file form: the shared safe allow-list, the deny list where deny beats allow, and the two hook wirings that make the runtime enforce the engine (`PreToolUse` to the shape guard, `SessionStart` to boot-check). Spine-protected, foundation-only edit. |
| `probes/foundation/probe_census_parity.sh` | The v2.5.6 Blocker 2 guard: behaviorally drives every registered enforcer's own membership test against the shared census, both assignment and case-table forms, fail-closed on an undriveable enforcer, so the census copies can never silently diverge again. |

## 4 Set-level authorization, the thesis in executable form

**Canon anchors: §4 pending-set ledger and apply-boundary set-evaluation, §10 ratification flow. Contracts: `C-SET-AUTHORIZATION.md`, `C-RATIFICATION-PACKET.md`, `COST-CAPS.md`.**

This is the machinery the whole architecture exists to carry: the set, not the change, is what gets authorized, with foundation assembling and assessing and the independent human ratifying.

| File | What it is and what runs it |
|---|---|
| `PENDING-SET.md` | The visible ledger, one row per change ratified but not yet committed, shipped as the empty schema with the maintenance law and the set-evaluation receipt line verbatim from origin. |
| `contracts/C-SET-AUTHORIZATION.md` | The governing model: the round-trip flow, the four enforced mechanisms (U4B conformance, footprint coverage §2.2, three-layer joint-edge coherence §2.3, cost brake §2.4), the member-as-manifest rule, the check-reference, the definition of done. Subordinate to the standing law by its own section L. |
| `contracts/C-RATIFICATION-PACKET.md` | The packet schema `ratify.sh assemble` writes and the operator's decision taxonomy reads. |
| `contracts/COST-CAPS.md` | The declared cost envelope the cost brake prices against, canon §1.3's ruled-not-assumed cost invariant. |
| `scripts/pending-set.sh` | The ledger instrument, five verbs: list, mint (foundation-only set identity), registry, member (module writes its entry to its own outbox), and the read paths every seat uses. M1 and M2 of the mechanism. |
| `scripts/ratify.sh` | The largest script in the engine (772 lines) and its heart: `assemble` reads the full ledger and every member entry, computes mechanical joint edges, writes the packet; `assess` records foundation's reasoning; `ratify` records the operator's single decision line. Foundation-only, resolver-gated. M3 through M5. |
| `scripts/cost-guard.sh` | The cost brake: reads the usage ledger, prices rows against the caps, closed exit-code set, unreadable ledger halts. |
| `_ratification/SET-NNNN.md`, `_ratification/criteria/MEMBER.md` | The packet template and the per-member criteria schema the assembler fills. |
| `export/EXPORT-set-authorization.md` | The methodology export: the thesis, enforcement, and first-execution method as a portable narrative, the one place the mechanism is written for reading rather than running. |

**Its dedicated enforcement, probed rather than asserted:**

| File | Claim it proves |
|---|---|
| `probes/foundation/probe_set_gate.sh` | Every foundation commit touching an authored-spine path since the last ratified packet is covered by a ratified set member or an enumerated exemption; the post-hoc mirror of the pre-commit coverage gate. |
| `probes/set-gate/probe_footprint_coverage_flip.sh` | `assemble` refuses a set that does not cover its requirement's declared footprint; flip-proven, meaning it is seen to fail before its pass counts. |
| `probes/set-gate/probe_semantic_hunt_flip.sh` | The semantic-hunt slot is unskippable: a merge decision refuses on a missing or incomplete hunt; the three-layer joint-edge gate's own guard. |
| `scripts/test/test_set_gate_seeded_fault.sh` | The 57-pole seeded-fault battery over the whole area: census drift in both forms, undriveable enforcers, ledger corruption in both verbs, guard bypass shapes with benign controls, the SLOTS bypass, positive controls. The engine's own acceptance evidence, run at every seal. |

## 5 The work lifecycle, dispatch to audited closure

**Canon anchors: §3 discipline rules, §4 receipts ledger. Schemas: the `schema/` directory whole.**

| File | Role |
|---|---|
| `schema/state-machine.md` | The work-package lifecycle with the no-fake-closures property as graph structure: there is no IN_PROGRESS to CLOSED edge; only an auditor-reproduced receipt closes. |
| `schema/work-package.md`, `schema/receipt.md` | The typed shapes of the unit of work and the proof it ran. |
| `schema/verification.md` | Verification and audit rules: Ring 0, WAIVED, spot-audit, bounded rework. |
| `schema/concurrency.md` | The concurrency rules under which lanes and workers overlap. |
| `dispatch/LATEST.md` | The live orchestrator pointer, spine-protected, so status is read from a file rather than a screenshot; ships as the skeleton. |
| `scripts/spawn_build_worker.sh` | The build-worker spawner: a backgrounded worker via `grok -p`, one bounded work package per spawn. |
| `scripts/receipt-ledger.py` | The receipt single-allocator and uniqueness verifier: fixes the same-second collision class in receipt ids; applied by foundation at reap, by workers at emit, and by the auditor at verify. |
| `scripts/validate_sprint_doc.py` | The sprint-doc section validator the dispatch track closes against. |
| `contracts/ref-impl/emit_receipt_ref.sh`, `apply_ref.sh`, `fire_ref.sh`, `refusal_test.sh` | The runnable neutral reference implementations: how a receipt is emitted, how an apply wraps, how a gate fires, and the refusal test proving mediation actually refuses. The adopter's copy-from surface for their own C-DB and C-GATE fills. |
| `contracts/C-DB.md`, `contracts/C-GATE.md` | The mediated side-effect slots: the database as a governed contract surface with the mediated-write-zero invariant, and the metered-execution gate slot. Shipped as slots; the adopter's substrate fills them. |
| `contracts/OPERATING-DISCIPLINE.md` | How work proceeds day to day, the contract form of canon §3. |
| `disciplines.md` | The standing disciplines and pattern library: PASS-0 premise verification, prior-art-first, halt-loud, cited by the boot creed's trigger-to-cite convention. |

## 6 Merge, reap, and lane currency

**Canon anchor: §7.2 retirement as the mirror event. Contract: `SPEC-REAPER.md`.**

| File | What it is and what runs it |
|---|---|
| `scripts/reap_at_merge.sh` | Audit-at-merge, the merge-time backstop: substrate guard reading the shared census, the forced-merge-path sentinel, receipt canonicalization via `receipt-ledger.py`, the five-state prefix-match. Run by foundation at every module or executor merge. |
| `scripts/reaper.sh` | The worktree-lifecycle garbage collector implementing SPEC-REAPER: reap-at-merge cleanup, stale-lock reaping, the force-remove guard. Fully lane-agnostic. |
| `scripts/lane_currency_gate.sh` | The spine-to-module mirror of reap: brings a module lane content-fresh with the trunk without letting it touch the spine. |
| `contracts/SPEC-REAPER.md` | The lifecycle contract the two scripts implement. |

## 7 Communication, relay, and escalation

**Canon anchor: §5 communication architecture: transport lives outside every participant. Contract: `SPEC-DOORBELL.md`. Protocol: `_knowledge/COORDINATION.md`.**

| File | What it is and what runs it |
|---|---|
| `scripts/inbox.sh` | The lane-resolved spine-inbox reader, the hub-and-spoke relay engine over `_orchestration/relay-inbox/<seat>/`. Every lane's first action each turn. |
| `scripts/doorbell.sh` | The SPEC-DOORBELL wrapper: tmux is the bell, the git inbox is the transport, payload never rides the bell, a dropped bell delays and never loses. Rung by foundation at dispatch. |
| `scripts/signal.sh` | The durable operator-to-integrator signal, born from a dropped GO typed into a mid-turn pane: directives become files. |
| `scripts/status.sh` | Observable state without attaching to a pane, the §7 observability property as a command. |
| `contracts/SPEC-DOORBELL.md` | The contract: an actionable payload committed but unrung is an incomplete output; the ring completes it. |
| `_knowledge/COORDINATION.md` | The full coordination protocol: hub-and-spoke, inbox and outbox, the integrator clauses, the module-to-foundation asymmetry invariant. |
| `_escalations/escalation-003.md` | The shipped worked example of a STOP-AND-SURFACE riding the escalation path, so an adopter's first conflict has a filed precedent to imitate. |

## 8 Standing audit and enforcement

**Canon anchor: §4 enforcement mechanisms: invariants are probed, not asserted, the component most governance frameworks lack.**

| File | What it is and what runs it |
|---|---|
| `agents/post-commit-hook.sh` | The D1 lane-aware reap-then-audit hook, canonical source for `.git/hooks/post-commit`: module marker and push, foundation reap plus push plus doorbell auto-fire, then the backgrounded auditor. Fires after every spine commit. |
| `scripts/install_post_commit_hook.sh` | Its installer. |
| `agents/auditor-contract.md`, `agents/audit-system-prompt.md` | The independent auditor: its contract (files, never fixes) and the system prompt the hook launches it with. |
| `agents/standing-probes.yaml` | The declared registry of nine standing probes with run_by and schedule: mediated-write-zero, orchestration-freshness, auditor-liveness, set-gate, state-propagation, the two set-gate flip probes, census-parity, discrimination-proof-neutral. An invariant's health is its streak here, not its prose. |
| `probes/discrimination_proof_neutral.sh` | Proves the probe harness itself distinguishes pass from fail with zero adopter infrastructure, so a green board is never vacuous. |
| `probes/foundation/probe_auditor_liveness.py` | Fail-never-warn liveness of the post-commit trigger itself: detection machinery checked from outside the participant. |
| `probes/foundation/probe_state_propagation.sh` | A foundation commit touching authored-spine paths must refresh the anti-stale HEAD pin, or a cold boot re-grounds stale. |
| `issues_register.md` | The single append-aware defect and named-wait record, first-class per canon §4, seeded empty. |
| `scripts/audit_issue_register.py` | The register's discipline tool: push-drift flagging for the best-effort push-at-close, plus register-shape enforcement. |
| `scripts/governance.sh` | Cite-before-raise: no settled decision is re-raised without citing the record, the §10 no-re-gating rule as a command. |
| `scripts/check_orchestration_freshness.sh` | The orchestration-freshness probe body over the local session-state surface and the decision log. |

## 9 Instantiation, adoption, and upgrade

**Canon anchors: §11 packaging and adoption, §12 instantiation checklist.**

| File | Role |
|---|---|
| `ADOPTION-COVER.md` | The read-first cover: what this is, what order to read in, both version axes on line 2. |
| `GETTING-STARTED-LINUX-MAC.md` | The adopter's walk from unzip to first launched seat on the supported floor. |
| `CHECKLIST.md` | The instantiation checklist in executable order, the §12 list as a working document. |
| `OPERATOR-GUIDE.md` | The operator-side companion: what the human at the apex does and answers. |
| `OPERATOR-CHAT-SETUP.md` | The chat-side setup page: project, bootstrap, and why a session wakes up lost without them. |
| `SLOTS.md` | The single inventory of every adopter slot, one row each, and the authority the upgrade classifier reads to tell a slot fill from an engine delta. |
| `docs/FOUNDATION.md` | The project rationale and invariants skeleton, shipped with authoring instructions for the adopting project's chat architect to fill. |
| `docs/CHAT-SEAT-PROJECT-INSTRUCTIONS_skeleton.md` | The chat-seat charter skeleton, the §1.1 chat-seat law instantiated per project. |
| `docs/FIELD-EVIDENCE_skeleton.md` | The conformed field-evidence log schema, canon §4, seeded per project. |
| `docs/BOOT-CHECK-PROPAGATION.md` | How the one boot-check script propagates to every lane's bootstrap by call, never by copy. |
| `docs/ENGINE-UPDATE.md` | The upgrade procedure: how an adopter takes a new engine version over their filled slots. |
| `scripts/engine-update-classify.sh` | The mechanical half of that upgrade: classifies every changed path as slot fill to preserve or engine delta to apply, with no model inside the classifier; judgment goes only to per-conflict rulings. |
| `scripts/test/test_engine_update_classify.sh` | Its seeded-fault battery. |
| `scripts/test/test_resolve_lane_seeded_fault.sh` | The identity resolver's seeded-fault battery, proving the halt paths halt. |
| `scripts/test/test_seat_add_seeded.sh` | Seeded-fault battery for seat-add.sh: non-foundation, absent roster, creed drift, two-lane, missing ruling-ref, plus a positive control. |
| `scripts/test/test_provisioning_shape_seeded.sh` | Seeded-fault battery for the provisioning-shape gate: two-lane sweep refused; clean single-lane passes. |
| `agents/commit-msg-hook.sh` | Provisioning subject-shape gate in the pre-commit family: `provision: <lane> seat, per operator ruling <ref>`. |
| `scripts/sync_knowledge.sh` | The tiered publish of decision-load-bearing surfaces for chat-seat project ingestion, the code end of the ferry. Wired (F4) from the foundation post-commit hook when a commit touches governance state; operator still closes with push + Sync now. |
| `scripts/verify_artifact_pin_parse.py` | Parser used by the pin gate (head, date, ferried-snapshots). |
| `scripts/verify_artifact_pin.sh` | State-pin gate: reads authored-against, compares to HEAD. Exact match proceeds; mismatch HALTs printing both shas; no pin refuses. Foundation first step of relay-consumption. |
| `scripts/test/test_verify_artifact_pin_seeded.sh` | Seeded-fault battery for the pin gate: stale HALT, absent refuse, current PASS; fail-before-pass. |
| `docs/INSTANTIATE-RELAY_skeleton.md` | Instantiation relay/prompt template: pin block, subordination, halt-on-unverifiable, battery law, optional lane-mint bound to ratify.sh. |
| `scripts/install_skills.sh` | Installs the in-repo skill home to the runtime's skill directory; ships the single generic code-build skill, adopters extend. |
| `scripts/rules_manifest.sh` | The scoped rules-manifest hash over the guard, resolver, and coordination clauses, so rule drift is detectable as a fingerprint change. |

## 10 Release integrity and the release envelope

The release is bigger than the package: four loose files ride beside the zip, and the README is the front door to all of it. The two layers verify each other in sequence, loose first, package second, which is why they are one area.

**In-zip integrity and hygiene:**

| File | Role |
|---|---|
| `MANIFEST.sha256` | The per-file fingerprint manifest, 101 rows; `sha256sum -c` inside the unzipped package is the adopter's second verify surface. |
| `CHANGELOG.md` | The versioned public account, additive framing in its own header, the in-place-rebuild promise on line 3. |
| `CITATION.cff` | The citation metadata, validated by its own schema validator, both axes carried. |
| `.gitattributes`, `.gitignore` | Line-ending and exclusion hygiene, including the local-only surfaces (`settings.local.json`, session state) the freshness probe expects gitignored. |

**The loose release layer, beside the zip:**

| File | Role |
|---|---|
| `README.md` | The front door and the map of the whole release. Every section of it is backed by something executable or fingerprinted, which is what separates it from marketing: the thesis restated in the additive form; the two-artifact two-license split; the release contents list; the substrate floor; the quick start; the two-axis verify rule; the license summary. Its section-by-section wiring is below. |
| `LICENSE.md` | The licensing envelope: the engine under Apache 2.0 with the Commons Clause, the `canon/` directory carved out under CC BY 4.0, the required notice. The carve-out line ("everything in this package except the canon/ directory") is a claim about the zip's own layout, and the layout honors it. |
| `GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1.pdf` | The canon in reading form, the same version the zip carries as `canon/..._PUBLIC.md`. Two renderings, one version; the in-zip markdown is the fingerprint-pinned copy the manifest and the citation law bind to. |
| `SHA256SUMS` | The first verify surface: four rows, the zip and the three documents above, checked before anything is unzipped. The zip's filename in row 1 is load-bearing, since `sha256sum -c` matches by name. |

**The README's sections, each mapped to what makes it true:**

| README section | Backed by |
|---|---|
| The correction | The additive-framing law verbatim: set-level authorization on top of per-change review, never instead of it. The same sentence the CHANGELOG header and every public surface carry; area 4 is its implementation. |
| Two artifacts, two licenses | `LICENSE.md` beside it and the canon's own CC BY line; the carve-out matches the zip layout. |
| What is in this release | The four loose files plus the zip, enumerated. The license text travels beside the zip and on the release page; verify the full set together. |
| Prerequisites, the substrate floor | `scripts/preflight.sh` is this section as a command: it checks exactly the floor stated here, reports, halts, and provisions nothing, per the floor ruling. |
| Quick start | Step 1 is `SHA256SUMS`; step 2 is `MANIFEST.sha256`; step 3 sets execute bits; step 4 is `launch-orc.sh`, area 2. |
| Verify | The two-axis citation law as procedure: package version and canon pin, both surfaces in order, fingerprints published at versions.html. |
| License summary | The one-paragraph restatement of `LICENSE.md`; the file governs, the summary points. |

The README carries no engine version label by design: it points at versions.html for the current version and fingerprints, so the file stays stable across releases while the fingerprints move where they are published.

---

## Execution wiring, the whole engine as a timeline

**At adoption:** `preflight.sh` clears the floor → `CHECKLIST.md` walks §12 → hooks installed (`install_pre_commit_hook.sh`, `install_post_commit_hook.sh`) → slots filled per `SLOTS.md` (including creating `seats.yaml`) → `docs/FOUNDATION.md` authored.

**At seat launch:** operator runs `orc-up.sh <lane>` → `launch-orc.sh` resolves the stamp, refuses double-launch, creates `{project}-{lane}` → `grok --agent orc` loads `orc.md` → `SessionStart` hook fires `boot-check.sh` → the session derives identity via `resolve-lane.sh`, reads its charter, reads `dispatch/LATEST.md`, checks its inbox.

**Per tool call:** the `PreToolUse` hook runs `guard-command-shape.sh` on every Bash invocation.

**Per change:** foundation dispatches into an inbox and rings `doorbell.sh` → the lane works on its branch → worker emits artifact plus receipt (`receipt-ledger.py` allocates) → probe runs → the post-commit hook's auditor reproduces → only then does the state machine allow CLOSED.

**Per commit:** `.git/hooks/pre-commit` (from `agents/pre-commit-hook.sh`) reads `spine-census.sh` plus `declared-spine-paths.sh` at HEAD and blocks non-writer spine writes and uncovered foundation writes; `.git/hooks/post-commit` reaps, pushes, and launches the auditor.

**Per set:** members enter `PENDING-SET.md` via `pending-set.sh` → `ratify.sh assemble` computes joint edges and writes the packet → `assess` records foundation's reasoning, `cost-guard.sh` prices it → the operator writes one decision line → `ratify.sh ratify` records it → foundation merges, `reap_at_merge.sh` backstops, pushes at close.

**Continuously:** the nine probes in `standing-probes.yaml` run on their schedules, ledgered; `audit_issue_register.py` flags push drift; the seeded-fault batteries re-prove the gates can fail at every release.

## Coverage account

**The release is 110 files: 106 in the sealed package plus 4 loose beside the zip.** In-package assignment: area 1 carries 1; area 2 carries 17 (10 identity files plus the 7 agent definitions); area 3 carries 7; area 4 carries 12; area 5 carries 14; area 6 carries 4; area 7 carries 7; area 8 carries 12; area 9 carries 21; area 10's in-zip table carries 4. Total 99, plus the 7 remaining: `PENDING-SET.md` counted in area 4, `AGENTS.md` and `disciplines.md` counted in areas 2 and 5, `dispatch/LATEST.md` in area 5, `issues_register.md` in area 8, `_escalations/escalation-003.md` in area 7, `export/EXPORT-set-authorization.md` in area 4. The 4 loose files (`README.md`, `LICENSE.md`, the canon PDF, `SHA256SUMS`) carry their own rows in area 10's loose-layer table. **Every file in the release appears exactly once above; none is unassigned.**

One absence is load-bearing and named: `seats.yaml` does not ship. It is created at instantiation, and the engine's enforcement reads it at HEAD from the moment it exists.

This map is re-derived from the tree at every engine version; nothing in it is maintained by hand against drift. GMAA · gmaa.ai · cite by version.
