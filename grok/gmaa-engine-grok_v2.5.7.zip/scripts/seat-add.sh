#!/usr/bin/env bash
# scripts/seat-add.sh — foundation-only, resolver-gated, one lane per invocation.
# Provisions exactly one ruled lane: stamp + creed-block identity + one commit.
# Never launches. Removal mirror (seat-remove.sh) is DEFERRED this revision;
# retirement, when it ships, follows canon §7.2.
#
# Usage: scripts/seat-add.sh <lane> <ruling-ref>
# Commit subject: provision: <lane> seat, per operator ruling <ref>
set -euo pipefail

die() { echo "seat-add REFUSED: $*" >&2; exit 2; }

if [[ $# -ne 2 ]]; then
  die "one lane per invocation; ruling-ref required. Usage: $0 <lane> <ruling-ref>. Batch refused. Missing ruling ref refused."
fi
NEWLANE="$1"
RULING_REF="$2"
if [[ "$NEWLANE" == *","* || "$NEWLANE" == *" "* || "$NEWLANE" == *$'\n'* ]]; then
  die "two-lane (or batch) invocation refused. One lane per invocation."
fi
if [[ -z "$NEWLANE" || -z "$RULING_REF" ]]; then
  die "missing ruling ref refused (or empty lane). Usage: $0 <lane> <ruling-ref>."
fi
if [[ "$NEWLANE" == "foundation" ]]; then
  die "foundation is created at genesis, not by seat-add."
fi
case "$NEWLANE" in
  *[^a-z0-9-]*|-*|"") die "lane must be lowercase [a-z0-9-] (folder-equals-lane)." ;;
esac

HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"

RESOLVER="$HERE/scripts/resolve-lane.sh"
[[ -x "$RESOLVER" ]] || die "resolver missing/not-executable (fail-closed)."
if ! LANE_LINE="$("$RESOLVER")"; then
  die "non-foundation caller refused (resolver failed)."
fi
eval "$LANE_LINE"
if [[ "${lane:-}" != "foundation" ]]; then
  die "non-foundation caller refused (resolved lane='${lane:-}'). Foundation-only."
fi

if ! git show HEAD:seats.yaml >/dev/null 2>&1; then
  die "absent roster row refused: seats.yaml is intent, not authorization. A seat is created by ruling; no ruling, no seat. No seats.yaml at HEAD."
fi
if ! git show HEAD:seats.yaml | awk -v L="$NEWLANE" '
  $0 ~ "^[[:space:]]*-[[:space:]]*" L "[[:space:]]$|^[[:space:]]*-[[:space:]]*" L "$" { found=1 }
  $0 ~ "lane:[[:space:]]*" L "[[:space:]]*$" { found=1 }
  END { exit found ? 0 : 1 }
'; then
  die "absent roster row refused: seats.yaml is intent, not authorization. A seat is created by ruling; no ruling, no seat. No HEAD row for lane '$NEWLANE'."
fi

BRANCH="$(git show HEAD:seats.yaml | awk -v L="$NEWLANE" '
  $0 ~ "lane:[[:space:]]*" L "[[:space:]]*$" { grab=1; next }
  grab && $0 ~ /^[[:space:]]*-[[:space:]]/ { grab=0 }
  grab && $0 ~ /branch:/ {
    s=$0; sub(/^[[:space:]]*branch:[[:space:]]*/, "", s); print s; exit
  }
')"
BRANCH="${BRANCH:-$NEWLANE}"

extract_creed() {
  # Byte-stable: from "## BOOT-CREED" through the line before "## Charter-precedes-boot"
  awk '
    /^## BOOT-CREED/ { p=1 }
    /^## Charter-precedes-boot/ { p=0 }
    p { print }
  ' "$1"
}

SRC_BOOT="$HERE/_boot/BOOTSTRAP.md"
[[ -f "$SRC_BOOT" ]] || die "foundation _boot/BOOTSTRAP.md missing."
CREED="$(extract_creed "$SRC_BOOT")"
[[ -n "$CREED" ]] || die "foundation creed block empty; cannot stamp."

PARENT="$(dirname "$HERE")"
TARGET="$PARENT/$NEWLANE"
if [[ -e "$TARGET/.git" || -d "$TARGET" ]]; then
  if [[ -f "$TARGET/_boot/BOOTSTRAP.md" ]]; then
    TCREED="$(extract_creed "$TARGET/_boot/BOOTSTRAP.md")"
    if [[ "$TCREED" != "$CREED" ]]; then
      die "creed-block drift refused: target creed is not byte-identical to foundation's."
    fi
    die "target worktree already exists at $TARGET."
  fi
  die "target path already exists at $TARGET."
fi

# Role / spine_write from roster when present
ROLE="$(git show HEAD:seats.yaml | awk -v L="$NEWLANE" '
  $0 ~ "lane:[[:space:]]*" L "[[:space:]]*$" { grab=1; next }
  grab && $0 ~ /^[[:space:]]*-[[:space:]]/ { grab=0 }
  grab && $0 ~ /role:/ {
    s=$0; sub(/^[[:space:]]*role:[[:space:]]*/, "", s); print s; exit
  }
')"
ROLE="${ROLE:-module-single-writer}"
SPINE="$(git show HEAD:seats.yaml | awk -v L="$NEWLANE" '
  $0 ~ "lane:[[:space:]]*" L "[[:space:]]*$" { grab=1; next }
  grab && $0 ~ /^[[:space:]]*-[[:space:]]/ { grab=0 }
  grab && $0 ~ /spine_write:/ {
    s=$0; sub(/^[[:space:]]*spine_write:[[:space:]]*/, "", s); print s; exit
  }
')"
SPINE="${SPINE:-DENY}"

git worktree add -b "$BRANCH" "$TARGET" >/dev/null

# Stamp BOOTSTRAP: keep foundation body, rewrite frontmatter + creed identity
python3 - "$SRC_BOOT" "$TARGET/_boot/BOOTSTRAP.md" "$NEWLANE" "$ROLE" "$BRANCH" "$SPINE" "$CREED" << 'PY'
import sys
src, dst, lane, role, branch, spine, creed = sys.argv[1:8]
text = open(src).read()
# rewrite frontmatter keys
import re
def setk(buf, k, v):
    return re.sub(r'(?m)^(' + re.escape(k) + r':)\s*.*$', r'\1 ' + v, buf, count=1)
text = setk(text, "lane", lane)
text = setk(text, "role", role)
text = setk(text, "worktree_branch", branch)
text = setk(text, "spine_write", spine)
text = setk(text, "bootstrap_version", lane + "-r1")
# title line
text = re.sub(r'(?m)^# .* lane bootstrap$', "# %s lane bootstrap" % lane, text, count=1)
# You are the {{LANE}} orc
text = re.sub(r'You are the \S+ orc', "You are the %s orc" % lane, text, count=1)
# CHARTER-{{LANE}}
text = re.sub(r'CHARTER-\S+\.md', "CHARTER-%s.md" % lane, text)
open(dst, "w").write(text)
PY

NEWCREED="$(extract_creed "$TARGET/_boot/BOOTSTRAP.md")"
if [[ "$NEWCREED" != "$CREED" ]]; then
  die "creed-block drift refused: stamped creed is not byte-identical to foundation's."
fi

CHARTER_SRC=""
if [[ -f "$HERE/_boot/CHARTER-$NEWLANE.md" ]]; then
  CHARTER_SRC="$HERE/_boot/CHARTER-$NEWLANE.md"
elif [[ -f "$HERE/_boot/CHARTER-executor.md" ]]; then
  CHARTER_SRC="$HERE/_boot/CHARTER-executor.md"
fi
if [[ -n "$CHARTER_SRC" ]]; then
  sed -e "s/CHARTER — executor/CHARTER — $NEWLANE/g" \
      -e "s/- \\*\\*lane:\\*\\* executor/- **lane:** $NEWLANE/g" \
      "$CHARTER_SRC" > "$TARGET/_boot/CHARTER-$NEWLANE.md"
fi

# Regenerated generated surface: lane-provisioning row
LP="$TARGET/_orchestration/lane-provisioning.md"
mkdir -p "$TARGET/_orchestration"
if [[ ! -f "$LP" ]]; then
  if [[ -f "$HERE/_orchestration/lane-provisioning.md" ]]; then
    cp "$HERE/_orchestration/lane-provisioning.md" "$LP"
  else
    printf '# lane-provisioning\n| lane | branch | bootstrap_version | blob | provisioned_utc |\n|---|---|---|---|---|\n' > "$LP"
  fi
fi
TS="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
if ! grep -q "| $NEWLANE |" "$LP" 2>/dev/null; then
  printf '| %s | %s | %s-r1 | pending | %s |\n' "$NEWLANE" "$BRANCH" "$NEWLANE" "$TS" >> "$LP"
fi

# One commit, never a launch
(
  cd "$TARGET"
  git add _boot/BOOTSTRAP.md
  [[ -f "_boot/CHARTER-$NEWLANE.md" ]] && git add "_boot/CHARTER-$NEWLANE.md"
  git add _orchestration/lane-provisioning.md
  git commit -m "provision: ${NEWLANE} seat, per operator ruling ${RULING_REF}

Ruling-ref: ${RULING_REF}
seats.yaml is intent, not authorization.
" 
)
echo "seat-add OK: provisioned $NEWLANE per operator ruling $RULING_REF (no launch)."
