#!/usr/bin/env bash
# Seeded-fault battery for scripts/verify_artifact_pin.sh (r2 F2).
# Poles: stale pin HALT; absent pin refuse; current pin PASS.
# Each fail-before-pass. Temp repo under /tmp; deleted after.
set -u
ENGINE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SBX="$(mktemp -d /tmp/gmaa-verify-pin-XXXXXX)"
trap 'rm -rf "$SBX"' EXIT
PASS=0; FAIL=0
ok(){ echo "  PASS $1"; PASS=$((PASS+1)); }
no(){ echo "  FAIL $1"; FAIL=$((FAIL+1)); }

seed_repo() {
  local d="$1"
  mkdir -p "$d"
  ( cd "$d"
    git init -q
    git symbolic-ref HEAD refs/heads/main
    git config user.email t@t; git config user.name t; git config commit.gpgsign false
    echo seed > README
    git add README
    git commit -q -m genesis --no-verify
  )
}

write_art() {
  local path="$1" head="$2" date="${3:-2026-08-23}" ferry="${4:-FOUNDATION.md@seed}"
  cat > "$path" << EOF
# test artifact
authored-against:
  head: $head
  date: $date
  ferried-snapshots: $ferry
body: x
EOF
}

# --- stale pin HALT (fail first) ---
D="$SBX/stale"
seed_repo "$D"
STALE="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
write_art "$D/relay.md" "$STALE"
LIVE="$(git -C "$D" rev-parse HEAD)"
out="$(bash "$ENGINE/scripts/verify_artifact_pin.sh" "$D/relay.md" 2>&1)"; rc=$?
if [[ $rc -ne 0 && "$out" == *"HALT"* && "$out" == *"$STALE"* && "$out" == *"$LIVE"* ]]; then
  ok "stale pin HALT (prints both shas; fail-before-pass)"
else
  no "stale pin: rc=$rc out=$out"
fi

# --- absent pin refuse ---
D="$SBX/absent"
seed_repo "$D"
printf '# no pin\nbody: x\n' > "$D/relay.md"
out="$(bash "$ENGINE/scripts/verify_artifact_pin.sh" "$D/relay.md" 2>&1)"; rc=$?
if [[ $rc -ne 0 && "$out" == *"REFUSED"* && "$out" == *"no authored-against"* ]]; then
  ok "absent pin refuse"
else
  no "absent pin: rc=$rc out=$out"
fi

# --- current pin PASS ---
D="$SBX/current"
seed_repo "$D"
LIVE="$(git -C "$D" rev-parse HEAD)"
write_art "$D/relay.md" "$LIVE"
out="$(bash "$ENGINE/scripts/verify_artifact_pin.sh" "$D/relay.md" 2>&1)"; rc=$?
if [[ $rc -eq 0 && "$out" == *"PASS"* && "$out" == *"$LIVE"* ]]; then
  ok "current pin PASS"
else
  no "current pin: rc=$rc out=$out"
fi

echo "test_verify_artifact_pin_seeded: $PASS pass / $FAIL fail"
[[ $FAIL -eq 0 ]]
