#!/usr/bin/env python3
"""Bidirectional ENGINE-MAP vs MANIFEST path parity (cheap).

Extracts backtick path-like tokens from docs/ENGINE-MAP.md and compares them
to MANIFEST.sha256 paths. Designed absence: seats.yaml.
ENGINE_MAP_PARITY_SEED=1 injects docs/SEEDED-ORPHAN-NOT-IN-TREE.md and must FAIL.
"""
from __future__ import print_function

import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
MAP_PATH = os.path.join(ROOT, "docs", "ENGINE-MAP.md")
MANIFEST_PATH = os.path.join(ROOT, "MANIFEST.sha256")

DESIGNED_ABSENCE = {
    "seats.yaml",
    "settings.local.json",  # local overlay, not shipped
    "MANIFEST.sha256",      # envelope file; hashes every other path, not itself
}
LOOSE_RELEASE = {
    "README.md",
    "LICENSE.md",
    "SHA256SUMS",
    "GROK-BOT.md",
    "GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1.pdf",
}
SKIP_PREFIXES = (".git/",)
SEED_ORPHAN = "docs/SEEDED-ORPHAN-NOT-IN-TREE.md"
EXT_RE = re.compile(r"\.[A-Za-z0-9]{1,8}$")
TICK_RE = re.compile(r"`([^`]+)`")


def load_manifest(path):
    paths = set()
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            paths.add(parts[1].strip())
    return paths


def is_path_like(tok):
    if not tok or any(c.isspace() for c in tok):
        return False
    if tok.startswith("-"):
        return False
    if tok.endswith("/"):
        return False
    if tok.endswith(":"):
        return False
    if tok.startswith("{") or tok.endswith("}"):
        return False
    if ":" in tok:
        return False
    if "..." in tok:
        return False
    if "/" in tok:
        return True
    if EXT_RE.search(tok):
        return True
    return False


def resolves(tok, manifest):
    if tok in DESIGNED_ABSENCE or tok in LOOSE_RELEASE:
        return True
    if tok.startswith(SKIP_PREFIXES):
        return True
    if tok in manifest:
        return True
    for m in manifest:
        if m == tok:
            return True
        if m.endswith("/" + tok):
            return True
        if os.path.basename(m) == tok:
            return True
    return False


def main():
    if not os.path.isfile(MAP_PATH):
        print("TEST-ERROR: missing", MAP_PATH, file=sys.stderr)
        return 2
    if not os.path.isfile(MANIFEST_PATH):
        print("TEST-ERROR: missing", MANIFEST_PATH, file=sys.stderr)
        return 2

    with open(MAP_PATH) as fh:
        text = fh.read()
    tokens = TICK_RE.findall(text)
    claimed = []
    seen = set()
    for tok in tokens:
        if not is_path_like(tok):
            continue
        if tok in seen:
            continue
        seen.add(tok)
        claimed.append(tok)

    if os.environ.get("ENGINE_MAP_PARITY_SEED") == "1":
        claimed.append(SEED_ORPHAN)

    manifest = load_manifest(MANIFEST_PATH)

    orphans = [t for t in claimed if not resolves(t, manifest)]

    # Reverse: every in-zip file whose basename or full path is cited is consistent.
    # Cheap reverse: MANIFEST paths that look like they should be mapped if cited
    # as a full-path token already covered above. Extra reverse check: if the map
    # cites a full relative path, the tree/manifest must have it; already in orphans.
    # Reverse extras: ignore (new files may land in MANIFEST before the map).

    fails = 0
    if orphans:
        print("FAIL: ENGINE-MAP path-like tokens not in MANIFEST (or allowlist):")
        for t in orphans:
            print("  -", t)
        fails += 1
    else:
        print("PASS: every ENGINE-MAP path-like token resolves to MANIFEST or designed absence")

    print("----")
    print("claimed=%d manifest=%d orphans=%d seed=%s" % (
        len(claimed), len(manifest), len(orphans),
        os.environ.get("ENGINE_MAP_PARITY_SEED", ""),
    ))
    if fails:
        print("ENGINE-MAP PARITY FAIL")
        return 1
    print("ENGINE-MAP PARITY PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
