#!/usr/bin/env bash
# Seeded-fault battery for the provisioning-shape gate (pre-commit family).
# Pole: two-lane sweep refused; clean single-lane passes. Fail-before-pass.
set -u
ENGINE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SBX="$(mktemp -d /tmp/gmaa-prov-shape-XXXXXX)"
trap 'rm -rf "$SBX"' EXIT
PASS=0; FAIL=0
ok(){ echo "  PASS $1"; PASS=$((PASS+1)); }
no(){ echo "  FAIL $1"; FAIL=$((FAIL+1)); }

newrepo() {
    local d="$1"
    mkdir -p "$d/scripts" "$d/agents" "$d/_boot" "$d/_orchestration"
    cp "$ENGINE/scripts/resolve-lane.sh" "$ENGINE/scripts/spine-census.sh" "$ENGINE/scripts/declared-spine-paths.sh" "$d/scripts/"
    cp "$ENGINE/agents/pre-commit-hook.sh" "$ENGINE/agents/commit-msg-hook.sh" "$d/agents/"
    chmod +x "$d/scripts/"*.sh "$d/agents/"*.sh
    printf -- '---\nlane: foundation\nrole: integrator\nspine_write: ALLOW\nbootstrap_version: t\n---\n# foundation lane bootstrap\n## BOOT-CREED\ncreed\n## Charter-precedes-boot\n.\n' > "$d/_boot/BOOTSTRAP.md"
    printf '# CHARTER — foundation\n' > "$d/_boot/CHARTER-foundation.md"
    printf '# lane-provisioning\n| lane | branch | bootstrap_version | blob | provisioned_utc |\n|---|---|---|---|---|\n| foundation | main | t | 0 | 2026 |\n' > "$d/_orchestration/lane-provisioning.md"
    ( cd "$d"
      git init -q; git symbolic-ref HEAD refs/heads/main
      git config user.email t@t; git config user.name t; git config commit.gpgsign false
      git add -A; git commit -q -m "genesis" --no-verify
      mkdir -p .git/hooks
      cp agents/pre-commit-hook.sh .git/hooks/pre-commit
      cp agents/commit-msg-hook.sh .git/hooks/commit-msg
      chmod +x .git/hooks/pre-commit .git/hooks/commit-msg
    )
}

# two-lane sweep
D="$SBX/sweep/foundation"
mkdir -p "$(dirname "$D")"
newrepo "$D"
printf '# CHARTER — alpha\n' > "$D/_boot/CHARTER-alpha.md"
printf '# CHARTER — beta\n' > "$D/_boot/CHARTER-beta.md"
( cd "$D"
  git add _boot/CHARTER-alpha.md _boot/CHARTER-beta.md
  out="$(git commit -m "provision: alpha seat, per operator ruling R-1" 2>&1)"; rc=$?
  if [[ $rc -ne 0 && "$out" == *"two-lane sweep refused"* ]]; then
    true
  else
    echo "SWEEP-OUT rc=$rc $out" > "$SBX/sweep.out"
    false
  fi
) && ok "two-lane sweep refused" || no "two-lane sweep not refused $(cat "$SBX/sweep.out" 2>/dev/null)"

# clean single-lane
D="$SBX/clean/foundation"
mkdir -p "$(dirname "$D")"
newrepo "$D"
( cd "$D" && git worktree add -q -b modlane "$(dirname "$D")/modlane" )
E="$(dirname "$D")/modlane"
# hooks are shared via common git dir
sed -i.bak 's/lane: foundation/lane: modlane/' "$E/_boot/BOOTSTRAP.md"
printf '# CHARTER — modlane\n' > "$E/_boot/CHARTER-modlane.md"
( cd "$E"
  git add _boot/BOOTSTRAP.md _boot/CHARTER-modlane.md
  out="$(git commit -m "provision: modlane seat, per operator ruling R-1" 2>&1)"; rc=$?
  if [[ $rc -eq 0 ]]; then true; else echo "$out" > "$SBX/clean.out"; false; fi
) && ok "clean single-lane passes" || no "clean single-lane failed $(cat "$SBX/clean.out" 2>/dev/null)"

echo "----"
echo "provisioning-shape battery: $PASS pass / $FAIL fail"
[[ $FAIL -eq 0 ]]
