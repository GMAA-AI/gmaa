#!/usr/bin/env bash
# Seeded-fault battery for scripts/seat-add.sh.
# Poles: non-foundation caller; absent roster row; creed-block drift; two-lane
# invocation; missing ruling ref; positive control. Each fail-before-pass.
set -u
ENGINE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SBX="$(mktemp -d /tmp/gmaa-seat-add-XXXXXX)"
trap 'rm -rf "$SBX"' EXIT
PASS=0; FAIL=0
ok(){ echo "  PASS $1"; PASS=$((PASS+1)); }
no(){ echo "  FAIL $1"; FAIL=$((FAIL+1)); }

seed_fnd() {
    local d="$1"
    mkdir -p "$d/scripts" "$d/_boot" "$d/_orchestration" "$d/docs"
    cp "$ENGINE/scripts/resolve-lane.sh" "$d/scripts/"
    cp "$ENGINE/scripts/seat-add.sh" "$d/scripts/"
    cp "$ENGINE/_boot/BOOTSTRAP.md" "$d/_boot/BOOTSTRAP.md"
    cp "$ENGINE/_boot/CHARTER-foundation.md" "$d/_boot/"
    cp "$ENGINE/_boot/CHARTER-executor.md" "$d/_boot/"
    chmod +x "$d/scripts/"*.sh
    # stamp as foundation
    python3 - "$d/_boot/BOOTSTRAP.md" << 'PY'
import re,sys
p=sys.argv[1]
t=open(p).read()
t=re.sub(r'(?m)^lane:\s*.*$','lane: foundation',t,count=1)
t=re.sub(r'(?m)^role:\s*.*$','role: integrator',t,count=1)
t=re.sub(r'(?m)^spine_write:\s*.*$','spine_write: ALLOW',t,count=1)
t=re.sub(r'(?m)^worktree_branch:\s*.*$','worktree_branch: main',t,count=1)
t=re.sub(r'(?m)^project:\s*.*$','project: seataddtest',t,count=1)
open(p,'w').write(t)
PY
    printf '%s\n' "seats:" "- lane: foundation" "  branch: main" "  role: integrator" "  spine_write: ALLOW" > "$d/seats.yaml"
    printf '# lane-provisioning\n| lane | branch | bootstrap_version | blob | provisioned_utc |\n|---|---|---|---|---|\n| foundation | main | foundation-r1 | 0 | 2026 |\n' > "$d/_orchestration/lane-provisioning.md"
    ( cd "$d"
      git init -q
      git symbolic-ref HEAD refs/heads/main
      git config user.email t@t; git config user.name t; git config commit.gpgsign false
      git add -A
      git commit -q -m "genesis: foundation" --no-verify
    )
}

# --- missing ruling ref (fail first) ---
D="$SBX/missing-ref/foundation"
mkdir -p "$(dirname "$D")"
seed_fnd "$D"
out="$(cd "$D" && bash scripts/seat-add.sh executor 2>&1)"; rc=$?
if [[ $rc -ne 0 && "$out" == *"ruling"* ]]; then ok "missing ruling ref refused (fail-before-pass)"; else no "missing ruling ref: rc=$rc out=$out"; fi

# --- two-lane invocation ---
D="$SBX/two-lane/foundation"
mkdir -p "$(dirname "$D")"
seed_fnd "$D"
out="$(cd "$D" && bash scripts/seat-add.sh executor,alpha R-1 2>&1)"; rc=$?
if [[ $rc -ne 0 && "$out" == *"Batch refused"* || "$out" == *"two-lane"* || "$out" == *"one lane"* ]]; then ok "two-lane invocation refused"; else no "two-lane: rc=$rc out=$out"; fi

# --- non-foundation caller ---
D="$SBX/nonfnd/foundation"
mkdir -p "$(dirname "$D")"
seed_fnd "$D"
# fake a module worktree with its own git? resolve-lane is folder-based. Create sibling module repo.
M="$SBX/nonfnd/modlane"
mkdir -p "$M/scripts" "$M/_boot"
cp "$ENGINE/scripts/resolve-lane.sh" "$ENGINE/scripts/seat-add.sh" "$M/scripts/"
chmod +x "$M/scripts/"*.sh
printf -- '---\nlane: modlane\nrole: module\nspine_write: DENY\nbootstrap_version: t\n---\n' > "$M/_boot/BOOTSTRAP.md"
( cd "$M" && git init -q && git config user.email t@t && git config user.name t && git config commit.gpgsign false && git add -A && git commit -q -m s --no-verify )
out="$(cd "$M" && bash scripts/seat-add.sh executor R-1 2>&1)"; rc=$?
if [[ $rc -ne 0 && "$out" == *"non-foundation"* ]]; then ok "non-foundation caller refused"; else no "non-foundation: rc=$rc out=$out"; fi

# --- absent roster row ---
D="$SBX/absent/foundation"
mkdir -p "$(dirname "$D")"
seed_fnd "$D"
out="$(cd "$D" && bash scripts/seat-add.sh executor R-1 2>&1)"; rc=$?
if [[ $rc -ne 0 && "$out" == *"intent, not authorization"* ]]; then ok "absent roster row refused"; else no "absent roster: rc=$rc out=$out"; fi

# --- creed-block drift ---
D="$SBX/drift/foundation"
mkdir -p "$(dirname "$D")"
seed_fnd "$D"
# add executor to roster then commit
printf '%s\n' "seats:" "- lane: foundation" "  branch: main" "  role: integrator" "  spine_write: ALLOW" "- lane: executor" "  branch: executor" "  role: module-single-writer" "  spine_write: DENY" > "$D/seats.yaml"
( cd "$D" && git add seats.yaml && git commit -q -m "roster executor" --no-verify )
mkdir -p "$SBX/drift/executor/_boot"
# pre-create target with drifted creed
python3 - "$D/_boot/BOOTSTRAP.md" "$SBX/drift/executor/_boot/BOOTSTRAP.md" << 'PY'
import sys
src,dst=sys.argv[1:3]
t=open(src).read().replace("A tool's reported result is not state.","DRIFTED creed line.")
open(dst,'w').write(t)
PY
touch "$SBX/drift/executor/.git"  # exists as file so seat-add sees target
out="$(cd "$D" && bash scripts/seat-add.sh executor R-1 2>&1)"; rc=$?
if [[ $rc -ne 0 && "$out" == *"creed-block drift"* ]]; then ok "creed-block drift refused"; else no "creed drift: rc=$rc out=$out"; fi
rm -rf "$SBX/drift/executor"

# --- positive control ---
D="$SBX/pos/foundation"
mkdir -p "$(dirname "$D")"
seed_fnd "$D"
printf '%s\n' "seats:" "- lane: foundation" "  branch: main" "  role: integrator" "  spine_write: ALLOW" "- lane: executor" "  branch: executor" "  role: module-single-writer" "  spine_write: DENY" > "$D/seats.yaml"
( cd "$D" && git add seats.yaml && git commit -q -m "roster executor" --no-verify )
out="$(cd "$D" && bash scripts/seat-add.sh executor R-TEST 2>&1)"; rc=$?
if [[ $rc -eq 0 && "$out" == *"seat-add OK"* ]]; then
  subj="$(git -C "$SBX/pos/executor" log -1 --format=%s)"
  if [[ "$subj" == "provision: executor seat, per operator ruling R-TEST" ]]; then
    ok "positive control passes"
  else
    no "positive control commit subject: $subj out=$out"
  fi
else
  no "positive control: rc=$rc out=$out"
fi

echo "----"
echo "seat-add battery: $PASS pass / $FAIL fail"
[[ $FAIL -eq 0 ]]
