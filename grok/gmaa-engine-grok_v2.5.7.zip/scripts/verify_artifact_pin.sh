#!/usr/bin/env bash
# scripts/verify_artifact_pin.sh — state-pin gate (genesis-hardening r2 F2).
# Foundation runs this BEFORE executing any ferried / chat-authored artifact.
# Usage: scripts/verify_artifact_pin.sh <artifact>
set -euo pipefail

die() { echo "verify_artifact_pin REFUSED: $*" >&2; exit 2; }
halt() { echo "verify_artifact_pin HALT: $*" >&2; exit 2; }

if [[ $# -ne 1 ]]; then
  die "usage: $0 <artifact>"
fi
ART="$1"
[[ -f "$ART" ]] || die "artifact not a file: $ART"

HERE="$(cd "$(dirname "$0")/.." && pwd)"
ART_DIR="$(cd "$(dirname "$ART")" && pwd)"
if git -C "$ART_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1 \
   && git -C "$ART_DIR" rev-parse --verify HEAD >/dev/null 2>&1; then
  LIVE="$(git -C "$ART_DIR" rev-parse HEAD)"
elif git -C "$HERE" rev-parse --is-inside-work-tree >/dev/null 2>&1 \
   && git -C "$HERE" rev-parse --verify HEAD >/dev/null 2>&1; then
  LIVE="$(git -C "$HERE" rev-parse HEAD)"
else
  LIVE="no repository exists"
fi

PARSE="$(dirname "$0")/verify_artifact_pin_parse.py"
[[ -f "$PARSE" ]] || die "parser missing: $PARSE"
eval "$(python3 "$PARSE" "$ART")"

if [[ "${found:-0}" != "1" ]]; then
  die "artifact has no authored-against block — not executable"
fi
if [[ -z "${pin_head:-}" ]]; then
  die "authored-against present but head missing — not executable"
fi
if [[ -z "${pin_date:-}" || -z "${pin_ferry:-}" ]]; then
  die "authored-against incomplete (need head, date, ferried-snapshots) — not executable"
fi

if [[ "$pin_head" == "$LIVE" ]]; then
  echo "verify_artifact_pin PASS: head=$pin_head date=$pin_date"
  exit 0
fi
halt "pin mismatch — authored-against head=$pin_head live HEAD=$LIVE"
