#!/usr/bin/env python3
import re, sys, shlex
text = open(sys.argv[1], encoding="utf-8", errors="replace").read()
idx = text.lower().find("authored-against")
if idx < 0:
    print("found=0")
    raise SystemExit(0)
chunk = text[idx:idx + 4000]

def grab(keys):
    for k in keys:
        m = re.search(r"(?im)^[ \t#/*-]*" + k + r"[ \t]*:[ \t]*(.+)$", chunk)
        if m:
            return m.group(1).strip().strip("`'\"")
    return ""

head = grab([r"head(?:\s+sha)?", r"HEAD"])
date = grab([r"date"])
ferry = grab([r"ferried[- ]snapshots(?:\s+relied\s+on)?", r"ferried_snapshots"])
print("found=1")
print("pin_head=" + shlex.quote(head))
print("pin_date=" + shlex.quote(date))
print("pin_ferry=" + shlex.quote(ferry))
