<!-- GENERICIZATION NOTE: genericized from origin CHECKLIST.md; all milestone items, domain-specific gates, instance-ISSUE refs, and sprint tracking stripped; generic header + §0 HEAD-absorb stub + empty milestone stubs retained as the operator-authority build-sequence tracker shape. Origin pin: a0929259. -->
<!-- skeleton -->
# CHECKLIST.md — {{PROJECT_NAME}} plan-progress tracker (canonical)

**What this is.** The strategic/milestone layer ABOVE the tactical issues-register + sprint docs.
**Mandatory session-start read for every seat** — see `AGENTS.md §7 (B6 context-lifecycle)` and `.grok/agents/orc.md` BOOT SEQUENCE.

**Distinction (preserve):**
- `issues_register.md` = defects/gaps (Open/Scheduled/Resolved/etc.) — TACTICAL
- sprint docs = sprint outcomes — TACTICAL
- **`CHECKLIST.md` = progress against the strategic plan's milestones** — STRATEGIC

**Refresh cadence:** at every iter/sprint close. Net-positive delta on plan milestones is the
signal of progress; defect-clearance alone is housekeeping.

**Last refresh:** <date>-r0
**absorbed_through_sha:** `<none — stamp a full commit sha on your first genuine absorb>` (DELIBERATE absorb stamp, ratified in your project as {{RULING}}: a seat writes this ONLY when it genuinely reads register+disciplines+CHECKLIST+rulings to that HEAD, NEVER as a side-effect of an edit. `scripts/boot-check.sh` computes currency = `git rev-list --count <this>..HEAD` over CHECKLIST/register/disciplines/_rulings/dispatch — this replaces the false-green `Last refresh` DATE trigger.)

---


---

## Adoption sequence (binding order — genesis, remote, then per-lane)

Re-sequenced to match GETTING-STARTED. Do not invert.

- [ ] Genesis complete: foundation-only vanilla instantiate (`git init`, foundation worktree and stamp, generated files, first commit). Vanilla never launches.
- [ ] Remote configured (before treating the repository as origin-durable).
- [ ] Lane `foundation` — operator ruling received. (Genesis is the writer; launch is the operator.)
- [ ] Lane `foundation` — charter material precedes provisioning.
- [ ] Lane `foundation` — foundation provisioned and committed as one set.
- [ ] Lane `foundation` — operator launched via launcher and verified header.
- [ ] Lane `<name>` — operator ruling received.
- [ ] Lane `<name>` — charter material precedes provisioning.
- [ ] Lane `<name>` — foundation provisioned and committed exactly one lane as one set (`scripts/seat-add.sh`).
- [ ] Lane `<name>` — operator launched via launcher and verified header.

`seats.yaml` is intent, not authorization. Duplicate the four per-lane rows for each further lane; each block begins with **operator ruling received.**

## §0 HEAD-absorb

> **Adopter instructions:** at every session start, a seat reads this section to orient itself to
> the current strategic state. Foundation updates this block at each refresh cadence with a
> one-paragraph summary of: (a) what was completed since the last refresh, (b) what is in-flight,
> (c) what is next on the sequence. Seats read HEAD-absorb first, then read the milestone sections
> that are relevant to the current task.

*(No absorb yet — initial skeleton.)*

---

## §1 — Phase 1: Foundation milestones

> **Adopter instructions:** enumerate the Phase 1 milestones as `[ ]` checkboxes. CHECKLIST
> sequence is **operator authority** — seats do not propose to skip items based on derived
> properties (gate cardinality, "MVP" reasoning, etc.). Every item exists because its analog
> either produced a defect or represents a real prerequisite for the next item.

- [ ] *(Milestone A — describe)*
- [ ] *(Milestone B — describe)*
- [ ] *(…)*

---

## §2 — Phase 2: Operate milestones

> **Adopter instructions:** enumerate Phase 2 milestones. Gate behind Phase 1 completion or
> named partial-completion conditions.

- [ ] *(Milestone A — describe)*
- [ ] *(…)*

---

## §3 — Phase 3+: Acceleration / Scale (forward queue)

> **Adopter instructions:** these are horizon milestones — intentionally high-level until
> Phase 2 is substantially complete. Do not sequence these in detail until Phase 2 has delivered
> its core milestones; premature sequencing of Phase 3 items causes scope-creep.

- [ ] *(Forward milestone — describe at a high level)*
- [ ] *(…)*

---

## Sequencing rule (binding — not a stub)

**CHECKLIST sequence is operator authority.** Seats do not propose to skip items based on:
- Gate cardinality satisfied ("the gate already passes, so the next item can be deferred")
- "MVP" reasoning ("this is a quality enhancement, not launch-blocking")
- Percentage of error coverage
- Any derived property that is not an explicit RESOLVED item in `issues_register.md`

The only legitimate scope contraction is RESOLVED-NO-OP with a full evidence chain (the iteration's
premise contradicts the spec, verified) — rare and documented separately. Recommend the next item
in CHECKLIST sequence without exception.
