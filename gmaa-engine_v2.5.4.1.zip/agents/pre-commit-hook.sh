#!/usr/bin/env bash
# agents/pre-commit-hook.sh — D3: spine_write HARD pre-commit gate.
#
# GENERICIZATION NOTE: mechanism byte-unchanged; this is the spine-write single-writer
# enforcement. The execution-lane carve-out keys on lane AND branch `executor` (folder-equals-lane
# convention: the executor worktree is folder `executor` on branch `executor`), moving with the
# resolve-lane.sh folder anchor. Ruling-number citations are rule-stated. The foundation
# resume-state pointer is spine-protected at `dispatch/LATEST.md` (the rest of dispatch/ stays
# module-writable for relays). `sql/`+`migrations/` are a commented C-DB-SLOT adopter stack
# (harmless no-op when absent; an adopter wiring a real database spine-protects them here).
# `foundation`/`main` are the base-census integrator + trunk (GENERIC-KEEP).
#
# Installed via scripts/install_pre_commit_hook.sh into .git/hooks/pre-commit
# (git hooks aren't versioned; this is the canonical source).
#
# Enforces COORDINATION.md §13(1) single-writer: ONLY the foundation lane
# may commit to spine-owned paths. A module lane (`module/<x>`, spine_write: DENY)
# that stages an edit to ANY spine-owned path is REJECTED (exit 1) at commit time.
# Module lanes commit only their own branch + PROPOSE spine changes; the
# integrator commits the spine.
#
# Identity comes from LOCATION via scripts/resolve-lane.sh — the SAME resolver the
# §0 cold-boot seat and the post-commit hook consume (one resolver, one
# consumption pattern). The resolver resolves the COMMITTING worktree's own root
# (`git rev-parse --show-toplevel`), never trunk/cwd, and cross-checks the stamped
# lane against the worktree FOLDER (folder-equals-lane).
#
# FAIL-CLOSED: if the lane cannot be resolved (resolver exit != 0 — no
# _boot/BOOTSTRAP.md, unset lane, or stamp<->folder mismatch) the commit is
# REJECTED. Never default to foundation on an unresolved lane.
#
# HARD PIN: committed + ENFORCED before ANY 2nd orc goes live (even same machine).

set -u

REPO_ROOT="$(git rev-parse --show-toplevel)"
RESOLVER="$REPO_ROOT/scripts/resolve-lane.sh"

if [[ ! -x "$RESOLVER" ]]; then
    echo "pre-commit REJECT: lane resolver missing/not-executable at $RESOLVER (fail-closed)." >&2
    exit 1
fi

# Resolve lane from THIS (the committing) worktree. Fail-closed on any non-zero.
if ! LANE_LINE="$("$RESOLVER")"; then
    echo "pre-commit REJECT: lane UNRESOLVED (resolver exit != 0)." >&2
    echo "  Cannot prove spine-write authority; fail-closed (never default to foundation)." >&2
    echo "  Cause: missing _boot/BOOTSTRAP.md, unset lane, or stamp<->folder mismatch (see resolver stderr above)." >&2
    exit 1
fi

# The resolver emits one KEY=VALUE line, all values single-token (lane/role/
# spine_write from _boot frontmatter; blob = git hash). eval matches the §0
# cold-boot contract `eval "$(scripts/resolve-lane.sh)"`.
eval "$LANE_LINE"   # -> lane= role= version= spine_write= blob= currency= subagent_model=

# Foundation = sole spine committer (§13(1)). ALLOW unconditionally.
if [[ "${lane:-}" == "foundation" ]]; then
    exit 0
fi

# --- executor (execution-apply-receipt-writer; the ratified single-writer carve-out) ---
# spine_write: apply-receipts-only (declarative). ENFORCEMENT here, keyed on lane AND branch
# (neither inferred from the other): on branch `executor` ONLY, the executor may commit SOLELY
# under ledger/apply-receipts/**; every other path (incl. the rest of ledger/ and all spine
# paths) is DENIED. Single spine writer preserved; reaped-at-merge by foundation.
# NOTE (provisioning): the one-time _boot/ charter+bootstrap commit is a FOUNDATION provisioning
# act done with --no-verify (foundation authors the charter per CHARTER-PRECEDES-BOOT), NOT an
# executor runtime self-commit; runtime executor commits are apply-receipts only, enforced below.
if [[ "${lane:-}" == "executor" ]]; then
    if [[ "$(git rev-parse --abbrev-ref HEAD 2>/dev/null)" != "executor" ]]; then
        echo "pre-commit REJECT: lane 'executor' carve-out is valid ONLY on branch executor (got: $(git rev-parse --abbrev-ref HEAD 2>/dev/null))." >&2
        exit 1
    fi
    if git rev-parse --verify -q HEAD >/dev/null 2>&1; then
        E_STAGED="$(git diff --cached --name-only 2>/dev/null)"
    else
        E_STAGED="$(git diff --cached --name-only --root 2>/dev/null)"
    fi
    E_OUTSIDE=()
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        [[ "$f" == ledger/apply-receipts/* ]] && continue
        E_OUTSIDE+=("$f")
    done <<< "$E_STAGED"
    if [[ ${#E_OUTSIDE[@]} -gt 0 ]]; then
        echo "pre-commit REJECT: lane 'executor' may commit ONLY under ledger/apply-receipts/** on branch executor (the ratified execution carve-out)." >&2
        for v in "${E_OUTSIDE[@]}"; do echo "    - $v" >&2; done
        exit 1
    fi
    exit 0
fi

# --- Module lane (spine_write: DENY): reject any staged edit to a spine path. ---
# Spine-owned set = COORDINATION.md §13(1).
SPINE_PATHS=(
    # --- §13(1) spine (enumerated) ---
    "ledger/"
    "dag/"
    "issues_register.md"
    "CHECKLIST.md"
    "contracts/"
    # foundation's resume-state pointer; the rest of dispatch/ stays module-writable
    # (relays) — ONLY the foundation resume pointer is spine-owned.
    "dispatch/LATEST.md"
    "_orchestration/decision-log.md"
    # lane-provisioning manifest — REQUIRED in the set: R1 (adopt-from-trunk) resolves
    # the integration-trunk ref FROM this file at gate time; module-editable here would
    # make the adopt-check subvertible.
    "_orchestration/lane-provisioning.md"
    # --- adopter DB stack (C-DB SLOT) — absent in the base engine (harmless no-op); an adopter
    #     that wires a real database spine-protects its migration/apply roots here. ---
    "sql/"
    "migrations/"
    # --- shared substrate, foundation-owned. DECISIVE: scripts/resolve-lane.sh + the hooks live
    #     under scripts//agents/ — a module-writable enforcement layer is a guard that could
    #     disable its own guard. skill/ inclusion makes the skill home spine-protected the moment
    #     it exists. Carve-out unchanged: module-authored content here is a PROPOSAL via
    #     reap-at-merge, never a module spine-write. ---
    "agents/"
    "scripts/"
    "skill/"
    # --- agent PERSONA defs. The role-neutral `orc` def + worker defs are foundation-owned and
    #     role-neutral — there is NO lane-specific agent def; lane identity lives ONLY in
    #     _boot/CHARTER+BOOTSTRAP (per-folder, integration-excluded). Spine-protecting closes the
    #     module SELF-TAMPER surface (a module orc editing away its own authority class / DENY
    #     persona) AND makes currency-sync R1 adopt the def BYTE-IDENTICAL from trunk →
    #     canonical-from-trunk, non-divergeable. (.gitignore: `.claude/*` + `!.claude/agents/`
    #     keeps exactly this dir trackable.) ---
    ".claude/agents/"
    # --- shared safe permission allow-list. Spine-protecting settings.json makes the auto-approver
    #     foundation-owned (a module cannot widen its own permissions) AND rides currency-sync R1
    #     adopt-from-trunk BYTE-IDENTICAL, so every lane boots prompt-free on the same vetted set.
    #     settings.local.json stays gitignored/per-worktree (local additions). ---
    ".claude/settings.json"
)

# Helper: is a path under a spine-owned prefix/file?
is_spine() {
    local f="$1" sp
    for sp in "${SPINE_PATHS[@]}"; do
        case "$sp" in
            */) [[ "$f" == "$sp"* ]] && return 0 ;;
            *)  [[ "$f" == "$sp"  ]] && return 0 ;;
        esac
    done
    return 1
}

# Resolve the integration-trunk ref at gate time from the spine manifest (do NOT hardcode
# 'main'; the manifest is itself spine-protected so this source cannot be subverted).
MERGE_HEAD_SHA="$(git rev-parse -q --verify MERGE_HEAD 2>/dev/null || true)"
TRUNK_BRANCH="$(awk -F'|' '$2 ~ /foundation/ {gsub(/[[:space:]]/,"",$3); print $3; exit}' "$REPO_ROOT/_orchestration/lane-provisioning.md" 2>/dev/null)"
TRUNK_SHA="$(git rev-parse -q --verify "$TRUNK_BRANCH" 2>/dev/null || true)"

VIOLATIONS=()
if [[ -n "$MERGE_HEAD_SHA" && -n "$TRUNK_SHA" && "$MERGE_HEAD_SHA" == "$TRUNK_SHA" ]]; then
    # === R1 ADOPT-FROM-TRUNK ===
    # A currency re-sync (merge ADOPTING the trunk) is allowed IFF the module contributes
    # NOTHING on spine paths: the index's spine MUST be BYTE-IDENTICAL to the trunk's spine.
    # Checked vs the TRUNK (not vs HEAD), so it catches divergence whether newly
    # conflict-resolved OR pre-existing in the module HEAD. Any spine path whose index blob
    # differs from the trunk = module-authored/conflict-resolved → REJECT.
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        is_spine "$f" && VIOLATIONS+=("$f")
    done <<< "$(git diff --cached --name-only "$TRUNK_SHA" 2>/dev/null)"
    REJECT_WHY="DIVERGE from the integration trunk — a currency-sync must adopt the trunk's spine VERBATIM (module-authored/conflict-resolved)"
else
    # === Standard D3 === spine paths changed by THIS commit (vs HEAD; --root if no HEAD).
    if git rev-parse --verify -q HEAD >/dev/null 2>&1; then
        STAGED="$(git diff --cached --name-only 2>/dev/null)"
    else
        STAGED="$(git diff --cached --name-only --root 2>/dev/null)"
    fi
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        is_spine "$f" && VIOLATIONS+=("$f")
    done <<< "$STAGED"
    REJECT_WHY="spine-owned — module lanes commit only their own branch + PROPOSE spine changes via reap-at-merge"
fi

if [[ ${#VIOLATIONS[@]} -gt 0 ]]; then
    echo "pre-commit REJECT: lane '${lane}' (spine_write: ${spine_write:-DENY}) — staged spine path(s) ${REJECT_WHY} (COORDINATION.md §13(1))." >&2
    echo "  Offending spine path(s):" >&2
    for v in "${VIOLATIONS[@]}"; do echo "    - $v" >&2; done
    exit 1
fi

exit 0
