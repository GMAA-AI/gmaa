# BOOT-CHECK propagation discipline (REQ-3)

How the boot-discipline enforcement gate reaches every lane, and stays reached. Ratified in your project as {{RULING}}.

## The gate's five parts
1. `scripts/boot-check.sh` — the presence + live-currency gate (emits the `BOOT-CHECK:` line).
2. `.claude/settings.json` `hooks.SessionStart` — the Tier-2 harness enforcer (auto-fires boot-check
   into every session's context, so PRESENCE is harness-enforced, not agent willpower).
3. `scripts/resolve-lane.sh` — the hardened currency arm (git-delta on `absorbed_through_sha`, replacing
   the false-green `Last refresh` date trigger).
4. The `absorbed_through_sha:` marker in the plan-tracker front-matter (`CHECKLIST.md`).
5. The `_boot/BOOTSTRAP.md` BOOT-CREED block (the boot STEP-2 call + the trigger→cite binding).

## Propagation rule (parts 1–4 are spine-tracked)
Parts 1–4 live on the spine and reach module lanes ONLY via currency-sync with a per-lane HEAD-readback.
**Landing a spine commit on the integrator is NOT landing it on the fleet.** After a governance change,
verify PER LANE: (a) the gate-commit is an ancestor of the lane's HEAD, (b) the pre-commit hook is
present, (c) `scripts/boot-check.sh` is present and executable. An unverified fan-out is a false-green of
exactly the class this gate exists to kill.

## BOOT-CREED (part 5) is integration-excluded
The `_boot/**` bootstrap is lane-provisioning metadata, not module work-product (see
`scripts/reap_at_merge.sh`, which restores the integrator's `_boot/**` after a merge). The BOOT-CREED
block is therefore NOT propagated by merge; it is placed per-lane at standup, when foundation authors
that lane's CHARTER + BOOTSTRAP.

## The .gitignore UNION guard
Currency-sync adopts the trunk version on a spine conflict — EXCEPT a lane's `.gitignore`, which UNION-
merges so a lane never loses its local ignores to a spine overwrite. Shipped via `.gitattributes`
(`.gitignore merge=union`).
