#!/bin/bash
# scripts/resolve-project.sh — project-token resolver for the tmux SESSION NAMESPACE.
# CONFORMS TO CANON §7.3 (v1.6.1, U-17): session identity is project-qualified `{project}-{lane}`.
# The project token is STAMPED AT PROVISIONING (a `project:` field in the _boot/BOOTSTRAP.md
# frontmatter, per the §7.2 stamp set) and NEVER asserted or guessed at launch. The token comes
# from the device-wide registry the cross-project channel uses (one registry, two consumers);
# stamping it here is the provisioning act that fixes it.
#
# Behavior (canon-exact):
#   stamped                 -> print the token; the launcher composes `<project>-<lane>`.
#   stamp present but EMPTY  -> HALT (exit 3): an unrecognized/malformed stamp must NOT degrade to
#                              bare-lane (halt-loud-over-silent-degradation; architect-225).
#   unstamped               -> LEGACY single-project form: print NOTHING (exit 10) with a LOUD
#                              WARNING on stderr; callers fall back to the bare lane name. On any
#                              device hosting two or more projects the stamp is MANDATORY — an
#                              unqualified name there is ambiguous by construction (§7.3) and the
#                              doorbell's exactly-one match will halt on it.
# NO directory-basename derivation: a token derived from an unstamped environment at launch is
# the assertion class §7.2 prohibits (identity fixed at creation, derived from the stamp at
# boot, never asserted) — and mis-derivation is a live failure mode, not a hypothetical.
set -u

WT_TOP="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "resolve-project: not in a git worktree" >&2; exit 3; }
BOOT="$WT_TOP/_boot/BOOTSTRAP.md"
[ -f "$BOOT" ] || { echo "resolve-project: missing $BOOT (charter-precedes-boot)" >&2; exit 3; }

# frontmatter-only read (between the first two '---'), same discipline as resolve-lane.sh.
# Separate the KEY-present test from the VALUE so a present-but-empty stamp HALTs (unrecognized)
# rather than silently degrading to LEGACY (architect-225: never degrade on a canon-conformant
# but malformed input).
HAS_KEY="$(awk '/^---[[:space:]]*$/{d++;next} d==1 && index($0,"project:")==1 {print "yes";exit}' "$BOOT")"
STAMP="$(awk '/^---[[:space:]]*$/{d++;next} d==1 && index($0,"project:")==1 {s=$0; sub("^project:[[:space:]]*","",s); print s; exit}' "$BOOT")"

if [ -n "$STAMP" ]; then
  echo "$STAMP"
  exit 0
fi

if [ "$HAS_KEY" = "yes" ]; then
  echo "HALT resolve-project: \`project:\` stamp present but EMPTY in _boot/BOOTSTRAP.md —" >&2
  echo "  an unrecognized stamp must not degrade to a bare lane name. Fix the stamp before launch." >&2
  exit 3
fi

echo "resolve-project: WARNING — no \`project:\` stamp in _boot/BOOTSTRAP.md; booting LEGACY" >&2
echo "  single-project session form (bare lane name). On a device hosting two or more" >&2
echo "  projects this is AMBIGUOUS BY CONSTRUCTION (canon §7.3) — stamp \`project: <token>\`" >&2
echo "  at provisioning before running a second project on this machine." >&2
exit 10
