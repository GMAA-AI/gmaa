#!/usr/bin/env bash
# scripts/reap_at_merge.sh <module-lane|executor> — audit-at-merge.
#
# GENERICIZATION NOTE: mechanism unchanged; the execution seat is `executor` (its branch is
# `executor`), site-lane examples → generic, project ruling-numbers → rule-stated,
# `STATE.md`→`LATEST.md`, and the SPINE_RE substrate guard genericized to the engine-core spine
# paths (adopters append their own substrate roots).
#
# Integrator-only (foundation). Merges module/<lane> into the spine and lets the
# foundation post-commit hook RE-AUDIT the incoming module work at the merge point,
# emitting the lane-stamped [audit] seal on main. Single-writer literal: the
# integrator is the only committer of both the merge commit and the audit seal; the
# module produced no audit record (only a lane marker, per the lightened module path).
#
# Architect ruling ([C] = audit-at-merge): "the Auditor receipt licenses merge-to-main,
# and C produces that receipt at the merge, by the integrator."
#
# INTEGRATION-EXCLUSION (COORDINATION.md §13(2)): `_boot/**` is lane-provisioning
# metadata, NOT module work-product. A module branch's `_boot/BOOTSTRAP.md` carries
# its own lane stamp; it must NEVER overwrite main's foundation stamp. This script
# restores main's `_boot/**` after the merge tree is computed, unconditionally
# (whether git conflicted on it or silently took the module side).
#
# HALT-LOUD: any merge conflict OUTSIDE `_boot/**` aborts (does not smooth a partial
# merge into a pass) — surface it, fix in-iter.
set -u

LANE_ARG="${1:?usage: reap_at_merge.sh <module-lane|executor>   (e.g. module-a, executor)}"
REPO_ROOT="$(git rev-parse --show-toplevel)"
cd "$REPO_ROOT" || { echo "HALT: cannot cd to repo root"; exit 1; }

# Assert integrator identity from LOCATION (must be the foundation worktree).
if ! LANE_LINE="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>&1)"; then
    echo "HALT: lane unresolved ($LANE_LINE) — reap-at-merge runs only on the foundation worktree."; exit 3
fi
eval "$LANE_LINE"
[[ "${lane:-}" == "foundation" ]] || { echo "HALT: reap-at-merge is integrator-only; this worktree is lane='${lane:-?}'."; exit 1; }
# Clean-tree precondition — but TOLERATE dirty ledger/: under reap-then-audit there is
# ALWAYS pending auditor output (the ≤1 trailing) until the next reap; the merge's OWN
# post-commit reap is what seals it, and the merge never touches ledger/. So block only
# on non-ledger uncommitted work.
DIRTY="$(git status --porcelain | cut -c4- | grep -v '^ledger/' || true)"
[[ -z "$DIRTY" ]] || { echo "HALT: working tree has non-ledger changes; refusing to merge."; echo "$DIRTY" | sed 's/^/  /'; exit 1; }

# executor (the execution seat): its branch is `executor`, NOT module/*, and its ONLY permitted
# spine output is ledger/apply-receipts/** (integration-INCLUDED — reaped here into the spine
# ledger; the ratified apply-receipts-only carve-out). Every other lane is module/<lane>.
if [[ "$LANE_ARG" == "executor" ]]; then
    BRANCH="executor"; IS_EXEC=1; WORK_KIND="apply-receipt"
else
    BRANCH="module/$LANE_ARG"; IS_EXEC=; WORK_KIND="module"
fi
git rev-parse --verify -q "$BRANCH" >/dev/null 2>&1 || { echo "HALT: no such branch $BRANCH"; exit 1; }
INCOMING="$(git rev-list --count "HEAD..$BRANCH")"
[[ "$INCOMING" -gt 0 ]] || { echo "nothing to merge: $BRANCH is not ahead of $(git rev-parse --abbrev-ref HEAD)."; exit 0; }

echo "reap-at-merge: $BRANCH ($INCOMING commit(s) ahead) -> $(git rev-parse --abbrev-ref HEAD)"
echo "incoming:"; git log --oneline "HEAD..$BRANCH" | sed 's/^/  /'

# Compute the merge tree without committing (so we can apply §13(2) exclusion first).
git merge --no-ff --no-commit "$BRANCH" >/dev/null 2>&1 || true   # may pause on conflicts

# §13(2) + ROUTING: integration-EXCLUDE _boot/** AND _orchestration/relay-outbox/** — make the
# index match MAIN's HEAD EXACTLY. A plain `git checkout HEAD -- <dir>` only restores both-side
# files; it does NOT drop the module's ADDED files (its CHARTER-<lane>.md, its outbox surfaces) →
# they would LEAK onto spine. exclude_to_head restores HEAD then unstages ONLY the additions
# (worktree untouched; identity-safe — NOT rm -rf), with a fail-closed identity guard.
exclude_to_head() {  # returns nonzero on identity-guard failure
    local ex f
    for ex in "$@"; do
        git checkout HEAD -- "$ex" 2>/dev/null || true
        while IFS= read -r f; do
            [[ -n "$f" ]] && git rm --cached --quiet --ignore-unmatch -- "$f" >/dev/null 2>&1 || true
        done < <(git diff --cached --name-only HEAD -- "$ex" 2>/dev/null)
    done
    git ls-files --cached -- _boot/BOOTSTRAP.md | grep -q .
}
exclude_to_head _boot _orchestration/relay-outbox || {
    echo "HALT: identity guard — _boot/BOOTSTRAP.md missing post-exclusion; aborting merge."
    git merge --abort 2>/dev/null || git reset --hard HEAD; exit 2; }

# HALT-LOUD on any conflict OUTSIDE the integration-excluded paths.
UNMERGED="$(git ls-files -u | awk '{print $4}' | sort -u | grep -vE '^(_boot/|_orchestration/relay-outbox/)' || true)"
if [[ -n "$UNMERGED" ]]; then
    echo "HALT: merge conflict OUTSIDE integration-excluded paths — needs ruling:"; echo "$UNMERGED" | sed 's/^/  - /'
    git merge --abort 2>/dev/null || git reset --hard HEAD
    exit 2
fi

# Sanity: staged merge must not introduce writes to spine/shared-substrate beyond the lane's
# authority class.
#  - module/<lane>: NO spine paths at all (D3 prevents them committing those; assert it).
#  - executor: ONLY ledger/apply-receipts/** is permitted (ratified carve-out); EVERY other spine
#    path — INCLUDING other ledger/ subpaths — HALTS (single-spine-writer preserved).
# ADOPTERS: append your substrate roots (e.g. |db/|migrations/|src/) to SPINE_RE below.
STAGED="$(git diff --cached --name-only)"
SPINE_RE='^(ledger/|issues_register.md|CHECKLIST.md|contracts/|_orchestration/decision-log.md|dispatch/LATEST.md|agents/|scripts/|\.claude/agents/)'
if [[ -n "${IS_EXEC:-}" ]]; then
    VIOL="$(echo "$STAGED" | grep -vE '^ledger/apply-receipts/' | grep -E "$SPINE_RE" || true)"
else
    VIOL="$(echo "$STAGED" | grep -E "$SPINE_RE" || true)"
fi
if [[ -n "$VIOL" ]]; then
    echo "HALT: incoming merge touches spine/shared-substrate paths beyond lane authority:"; echo "$VIOL" | sed 's/^/  - /'
    git merge --abort 2>/dev/null || git reset --hard HEAD
    exit 2
fi

# Commit the merge (foundation). NOT [audit]-subject -> the foundation post-commit
# hook fires: reap-then-audit re-audits this merge (merge-aware CHANGED_FILES = the
# incoming work vs first parent) and seals it on the next foundation reap / flush.
git commit -q --no-edit -m "merge $BRANCH: $INCOMING $WORK_KIND commit(s) — audit-at-merge [C] (integrator re-audits incoming work)"
MERGE_SHA="$(git rev-parse --short HEAD)"
echo "merged as $MERGE_SHA (main _boot preserved = foundation). Foundation post-commit auditor re-auditing incoming $WORK_KIND work; [audit] seal lands on next reap / terminal flush."
