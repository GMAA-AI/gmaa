#!/bin/bash
# preflight.sh — substrate-floor verification (v2.5.1)
# The engine states its prerequisites in README ("Prerequisites — the substrate floor"); this
# script is the check that makes the statement testable: Claude Code CLI, git (with GitHub auth),
# and tmux. It provisions NOTHING — it reports and halts loud, per the floor ruling: v1 targets
# adopters who clear this floor; the engine does not install it for them.
# It also asserts every shipped .claude/agents/*.md leads with YAML frontmatter (loadability): a def
# whose frontmatter does not lead binds nothing and silently falls back to the ungoverned default agent.
# Exit 0 = floor clear. Exit 1 = one or more items missing (each named on its own line).
# bash-3.2 compatible (macOS /bin/bash): no arrays, no mapfile.

set -u

FAIL=0

check() {
  # $1 = label · $2 = command to probe
  if OUT=$(eval "$2" 2>&1); then
    echo "PASS: $1 ($(echo "$OUT" | head -1))"
  else
    echo "FAIL: $1 — '$2' did not succeed. Install/configure it before Phase 0."
    FAIL=1
  fi
}

check "Claude Code CLI" "claude --version"
check "git"             "git --version"
check "tmux"            "tmux -V"

# GitHub auth: gh is the common path; a configured git credential helper also satisfies the floor.
if command -v gh >/dev/null 2>&1; then
  check "GitHub auth (gh)" "gh auth status"
else
  if git config --get credential.helper >/dev/null 2>&1; then
    echo "PASS: GitHub auth (git credential helper configured; gh CLI not installed — optional)"
  else
    echo "FAIL: GitHub auth — neither 'gh' CLI nor a git credential helper found. Configure GitHub access before Phase 0."
    FAIL=1
  fi
fi

# --- agent-def loadability (v2.5.3 Finding 2): YAML frontmatter MUST lead every .claude/agents/*.md,
# else `claude --agent <name>` parses no frontmatter and silently binds the default UNGOVERNED agent
# (no BOOT SEQUENCE, unrestricted tools). Assert line 1 == '---' for each shipped def.
if [ -d ".claude/agents" ]; then
  for def in .claude/agents/*.md; do
    [ -e "$def" ] || continue
    if [ "$(head -1 "$def")" = "---" ]; then
      echo "PASS: agent-def frontmatter leads ($def)"
    else
      echo "FAIL: agent-def '$def' — first line is not '---'; frontmatter will not parse and the seat"
      echo "      silently falls back to the ungoverned default agent. Move any note block below the closing '---'."
      FAIL=1
    fi
  done
fi

# --- adopter-entry completeness (v2.5.3 XP-14 / r5 loose layout): the adopter's assembled project
# folder MUST carry its entry set. The reader docs ship LOOSE beside the engine zip (integrity-tracked
# in the release SHA256SUMS); this is the completeness firewall (canon §13) at adopter time — assert
# the cover, at least one getting-started guide, and the CHANGELOG are PRESENT in the project folder.
# (The v2.5.0 reframe dropped these; they shipped missing through v2.5.2.) Run this in an ASSEMBLED
# folder (engine unzipped + the loose docs placed beside it), not the bare machinery tree.
have_cover=$([ -f "ADOPTION-COVER.md" ] && echo 1 || echo 0)
have_start=$(ls GETTING-STARTED-*.md >/dev/null 2>&1 && echo 1 || echo 0)
have_chlog=$([ -f "CHANGELOG.md" ] && echo 1 || echo 0)
for pair in "ADOPTION-COVER.md:$have_cover" "a GETTING-STARTED-* guide:$have_start" "CHANGELOG.md:$have_chlog"; do
  name="${pair%:*}"; cnt="${pair##*:}"
  if [ "$cnt" -ge 1 ]; then
    echo "PASS: adopter-entry present ($name)"
  else
    echo "FAIL: adopter-entry MISSING ($name) — the completeness firewall (canon §13) forbids an"
    echo "      assembled project without its adopter entry set. Place the loose docs beside the engine."
    FAIL=1
  fi
done

if [ "$FAIL" -eq 0 ]; then
  echo "FLOOR CLEAR: all substrate prerequisites respond."
  exit 0
else
  echo "FLOOR NOT CLEAR: fix the FAIL lines above, then re-run. (README: Prerequisites — the substrate floor.)"
  exit 1
fi
