#!/usr/bin/env bash
# scripts/boot-check.sh — boot-discipline PRESENCE + live-currency gate.
# Canonical, ALL-LANES (ratified in your project as {{RULING}}). ONE script; every lane's
# _boot/BOOTSTRAP.md adds only the CALL, never the logic. Also invoked by the harness
# SessionStart hook (settings.json) so PRESENCE is harness-enforced, not agent willpower.
#
# WHAT IT FIXES (the currency-false-green scar, ratified as {{RULING}}): the old resolve-lane
# STALE-BOOT nudge was a FALSE-GREEN — soft (non-fatal, stderr-swallowed by
# `eval "$(resolve-lane.sh)"`), plan-tracker-age-only, and keyed on a SELF-STAMPED DATE (one
# stamp bought a week of silence). Governance drifted through a surge because the nudge that
# should have caught it read green. This gate measures a *read* not an *edit*: currency = a
# live git-delta anchored on the DELIBERATE `absorbed_through_sha:` marker, and it EMITS a
# visible line with LIVE values so a stale state is self-evident on its face.
#
# TEETH: Tier 1 (this visible mandatory emit) + Tier 2 (harness inject via SessionStart).
# Tier 3 (hard-HALT on omission) is DEFERRED-on-recurrence — this gate is NON-FATAL.
set -uo pipefail
WT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
cd "$WT_ROOT" || exit 0
lane="$(sed -n 's/^lane:[[:space:]]*//p' _boot/BOOTSTRAP.md 2>/dev/null | head -1)"; lane="${lane:-unknown}"

# (1) disciplines §0 PRESENCE — surface the all-seats roster. Under the Tier-2 SessionStart
#     hook this stdout is injected into context, making `disciplines=§0-loaded` true-by-
#     construction (a standing guard), not a claim.
echo "── disciplines.md standing-discipline index — all-seats roster (load every boot; full text in §1) ──"
if ! grep -E '^### DISC-' disciplines.md 2>/dev/null; then
  echo "  ⚠ HALT-LOUD: disciplines.md DISC- roster not found — investigate before proceeding (do not silently degrade)."
fi

# (2) register open-count — a PRESENCE signal, INDICATIVE not authoritative. The register is a
#     HYPOTHESIS surface (the no-fake-closures invariant): the emit proves it's in-view; it does
#     NOT license routing on the raw count without a grep-closeout.
OPEN=$(grep -oiE '\*\*Status:\*\* *\**open' issues_register.md 2>/dev/null | wc -l | tr -d ' ')
[[ -z "$OPEN" ]] && OPEN="?"

# (3) plan-tracker currency — LIVE git-delta anchored on the DELIBERATE absorbed_through_sha.
#     NOT `git log -1 CHECKLIST.md` (which false-greens on any cosmetic edit).
ANCHOR=$(sed -n 's/^\*\*absorbed_through_sha:\*\*[[:space:]]*//p' CHECKLIST.md 2>/dev/null | grep -oE '[0-9a-f]{7,40}' | head -1)
if [[ -n "$ANCHOR" ]] && git cat-file -e "$ANCHOR" 2>/dev/null; then
  DELTA=$(git rev-list --count "${ANCHOR}..HEAD" -- CHECKLIST.md issues_register.md disciplines.md _rulings dispatch 2>/dev/null || echo "?")
  ANCHOR_SHOW="${ANCHOR:0:8}"
else
  DELTA="NO-ANCHOR"; ANCHOR_SHOW="unset"
fi
RELAYS=$(find dispatch -maxdepth 1 -name 'RELAY*.md' ! -name 'RELAY-TO-*' -newer CHECKLIST.md 2>/dev/null | wc -l | tr -d ' ')

# emit — LIVE values, never a fixed "OK". Absence of this line on a boot = protocol omission.
echo "BOOT-CHECK: lane=${lane} disciplines=§0-loaded register=${OPEN}-open(indicative;grep-closeout-before-routing) checklist-delta=${DELTA}-commits-since-${ANCHOR_SHOW} relays-newer=${RELAYS}"

# Non-fatal integrator nudge (stdout, NOT stderr — the old gate's fatal flaw): a real delta
# means a genuine absorb is owed. This is Tier 1/2 (visible); it never blocks boot.
if [[ "$DELTA" != "0" && "$DELTA" != "NO-ANCHOR" && "$DELTA" != "?" ]]; then
  echo "  ⇒ ${DELTA} unabsorbed commit(s) to CHECKLIST/register/disciplines/rulings/dispatch since your last DELIBERATE absorb (${ANCHOR_SHOW}). Integrator FIRST WP = re-absorb to HEAD, then re-stamp **absorbed_through_sha:** in CHECKLIST front-matter."
elif [[ "$DELTA" == "NO-ANCHOR" ]]; then
  echo "  ⇒ no absorbed_through_sha marker in CHECKLIST front-matter — stamp one on your next genuine absorb (a DELIBERATE act, never a side-effect of an edit)."
fi
exit 0
