# MECH-SEAT — seats: where they live, how they launch, who they are, how their worktrees end

**Spec of record for MECH-SEAT** (the ONLY document for this mechanism, ≤ 8 KB). It absorbs
SPEC-REAPER (MERGE, `_index/layers.tsv`). Architect authors; foundation builds. Prior blobs:
v0.1 `347dddce`, SPEC-REAPER `d31c5661`.

## §1 Registry of record
- **The lane table is `_orchestration/lane-provisioning.md`** (lane · branch · bootstrap_version · spine_write ·
  `git hash-object` of `_boot/BOOTSTRAP.md`). Foundation writes it; nothing else is a registry.
- **One seat = one lane = one worktree = one tmux session named `<project>-<lane>`**. `project:` is
  stamped in `_boot/BOOTSTRAP.md` at provisioning; `scripts/resolve-project.sh` HALTs if it is absent (no session is
  created; the doorbell
  falls back to the bare lane name only as a time-boxed transition, until no bare-named session remains). The hub is `foundation` on `main` (`spine_write: ALLOW`,
  sole spine writer). Every other lane writes only its own branch; the architect never writes the spine.
- **Charter precedes boot:** create worktree + branch → foundation commits `_boot/CHARTER-<lane>.md` +
  `_boot/BOOTSTRAP.md` → the operator launches. A seat reads its charter; it never authors its identity.

## §2 Launch (`<worktree>/launch-orc.sh`, launcher v3)
- **Lane:** the `lane:` line of `_boot/BOOTSTRAP.md` wins; the folder map (`folder_to_lane`) is the fallback. When both
  exist they must agree or the launcher HALTs (a lane with no folder-map entry resolves from `_boot` alone).
- **Command:** `claude --agent orc` for every lane; `claude --agent architect` plus a positional boot prompt for the
  architect. The launcher pins no seat's model: the
  architect follows its def's `model: opus` (operator, 2026-10-01: *"opus 5.5 or default"*), and
  BOOT-ACK prints the OBSERVED model.
- **Remote Control:** stamp `remote_control: true` adds `--remote-control <project>-<lane>`. The
  receipt says `requested <name> (configured)`, never "on".
- **Permission mode:** default = `settings.json`-governed; `--auto-mode` opts into the classifier.
- **Loop:** the session runs `exec bash scripts/seat-loop.sh --session <project>-<lane> [--auto-mode]`; re-resolved
  from the stamp at every launch, HALT on failure.

## §2a Restart and shutdown
- **Detect:** the statusLine writes `<session_id> <tokens|null> <pct|null> <utc> <window|null>` (`null` = unreported, not 0) to `.claude/context-pct`. The `Stop` hook
  reads its own session's line, injects the B6 line once per session per level (250K tokens: restart at the next
  boundary; 350K: no new WP), prints the pct beside them, and appends E11 (not scored). No mid-WP ceiling.
- **Exit:** the seat runs `scripts/seat-exit.sh restart|shutdown` after B6.1. It refuses (exit 2) outside tmux, on
  tracked changes (except an unstaged pure append to the auditor ledgers the hook seals), or when
  the stamp's `handoff:` surface has not moved since the session's boot sha. Untracked files never block; any
  created since boot print `UNTRACKED-SINCE-BOOT` at the next boot. It writes the intent (`when-idle` while
  own-session subagents are live) and sends no keystroke.
- **Fire:** `/exit` goes to its own pane at the first own-session `Stop`, or once from the watchdog at the
  deadline, once every own-session subagent has stopped or passed its cap + 2 min and `seat-exit.sh recheck`
  passes; otherwise `SEAT-EXIT-WAIT <check>`. A send the session outlives is `SEAT-EXIT-LOST`,
  re-sent at most 3 times per intent, then `SEAT-EXIT-GAVE-UP` asks for a manual `/exit`.
- **Subagents:** a session-keyed `SubagentStart`/`Stop` ledger. Past its wall-clock cap (35 min, or intent +
  5 min if sooner) a `PreToolUse` hook denies the subagent's tools. Leftover entries print `SUBAGENT-ABANDONED` at the next
  boot; `seat-exit.sh clear-subagent <agent_id>` drops one.
- **Relaunch:** default is stop. Only a fresh `restart` intent relaunches; a 4th restart in 30 min prints
  `SEAT-LOOP-HALT` and stops. `PreCompact auto` blocks with the B6.1 instruction; `manual` and
  subagents pass.
- **Stop from outside:** `scripts/seat-stop.sh <lane>` is the operator's tool and refuses inside a Claude Code
  session. Poles: `probes/governance/probe_seat_restart_poles.sh`, `probe_subagent_restart_poles.sh`.

## §3 Identity at boot (binding)
- `eval "$(scripts/resolve-lane.sh)"` reads `$WORKTREE/_boot/BOOTSTRAP.md`, checks the stamped lane against the
  branch, and prints `lane / role / version / spine_write / blob`. The seat emits
  `BOOT-ACK: lane=… version=… blob=…` (architect: `BOOT-ACK: @architect charter=<version>`). Foundation matches the
  ack against the registry row.
- **Resolver non-zero → HALT.** Never guess identity, assume the hub role, or act on another lane's
  bootstrap. No BOOT-ACK header on an architect spawn = the def did not load: close it, never proceed.
- Acceptance for a new seat is a live round trip, never "the artifact exists": spawn → BOOT-ACK → foundation
  commits to its inbox and rings → the seat consumes, acks in its outbox and rings → foundation reads it.

## §4 Worktree end-of-life (`scripts/reaper.sh`: `add` · `stamp` · `sweep` · `reap-at-merge` · `list`)
- **Invariants (violation = HALT):**
  1. **No silent data loss.** A worktree with uncommitted changes or unmerged/detached commits is never
     force-removed. Detect first; if present, HALT and surface. Never `git worktree remove --force`.
  2. **Locks are PID-gated, not age-gated.** A lock is stale only when its owner PID is dead (`kill -0`).
  3. **The normal path reaps only merged AND clean.**
  4. **Foundation only**, from `main`. No module lane reaps.
  5. **Idempotent and loud.** Every reap, no-op and HALT is logged. A status field alone is never evidence.
- **Owner stamp at create:** `reaper.sh add` writes `<git-common-dir>/worktrees/<name>/owner` (session PID + UTC).
  Ephemeral, never tracked. No stamp = unknown owner: HALT and surface, never swept on absence.
- **Reap at merge** is an explicit integrate step (`scripts/reap_at_merge.sh`), not a git hook: merged
  (`merge-base --is-ancestor`) + clean → `worktree remove`, `branch -d` (never `-D`), `worktree prune`.
- **Sweep** runs before `worktree add`: live PID → leave; dead PID → guard (invariant 1) → remove + prune.

## §5 Acceptance
AC1 a clean merged branch is reaped and logged · AC2 a dirty worktree HALTs and the dirt survives · AC3 a live-PID
lock is left, a dead-PID lock is swept · AC4 unmerged commits HALT · AC5 N ≥ 5 clean merged worktrees all reap and a
reused name then adds · AC6 a re-run is a logged no-op · AC7 a missing owner stamp HALTs · AC8 a new seat passes the
§3 round trip.

## §6 Enterprise lens
- **Server-side twin:** `scripts/spine-receive.sh`: per-lane protection at the spine host (no force push; a lane branch
  takes only its own lane's signed commits; `spine_write` re-checked). Built; armed only at the custody act (the spine account exists).
  Until then the local hook enforces `spine_write`.
- **Identity source:** the worktree's `_boot/BOOTSTRAP.md`, cross-checked against the branch and the registry blob.
  An unsigned local file, not an IdP claim.
- **Role model:** each charter's authority class (`integrator-spine-router`, `module-single-writer`,
  `execution-apply-receipt-writer`), plus the architect, a HOW-class seat that rules and never executes.
- **Install/upgrade path:** foundation provisions (§1), the operator launches; a lane adopts a changed def at its sync.
- **Harness binding:** agent defs (`orc.md`, `architect.md`) in tmux via `launch-orc.sh`; boot = def + `SessionStart`
  (`boot-check.sh`); lifecycle = statusLine, `Stop`, `PreCompact`, `PreToolUse`, `SubagentStart`/`Stop` (§2a).

**Limit (verbatim):** *"S binds a seat that has not read it only to the extent its enforcer cannot be
bypassed by that seat. With local hooks (v1.6.5) that is an honest-operator property at n = 1; the server-side twin
(canon v1.6.6 candidate) is what makes it a guarantee."*

GOVERNANCE-CHECK: seat-lifecycle answered@LAUNCH-CONTRACT §2a
