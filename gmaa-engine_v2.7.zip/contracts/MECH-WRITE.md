# MECH-WRITE — who may write where, and how a write reaches the trunk

**Spec of record for MECH-WRITE** (the ONLY document for this mechanism, ≤ 8 KB); written from the enforcer headers
(`agents/pre-commit-hook.sh`, `agents/pre-merge-commit-hook.sh`,
`scripts/greenlight-policy.sh`) and folding three disciplines (§6). The enforcers are the truth; this spec describes
them, and where the two disagree the code wins and this spec is the defect.

## §1 Single-writer map (binding; COORDINATION §13(1))
- **Spine paths** (`SPINE_PATHS`, `agents/pre-commit-hook.sh`): `ledger/` · `dag/` · `issues_register.md` ·
  `CHECKLIST.md` · `contracts/` · `_orchestration/{STATE.md,decision-log.md,lane-provisioning.md}` · `PENDING-SET.md` ·
  `_ratification/` · `dispatch/LATEST.md` · `sql/` · `migrations/` · `agents/` · `scripts/` · `skill/` · `src/` ·
  `.claude/agents/` · `.claude/settings.json`.
- **foundation** (`main`) is the sole spine writer. **Module lanes** (`spine_write: DENY`) commit only their own branch
  and PROPOSE spine changes through reap-at-merge. **The execution lane** (`exec`) may commit only
  `ledger/apply-receipts/**`. **architect** commits only its own `architect` branch.
- **Currency is a read, never a merge-state**: a lane reads the spine (`git show origin/main:…`);
  `behind=N` is the single-writer invariant holding, not a deficit.

## §2 The commit gate (`pre-commit`)
- **Lane from location**, via `scripts/resolve-lane.sh` on the committing worktree. Resolver non-zero → REJECT. Never
  default to foundation.
- **Module lane stages any spine path → REJECT.** The execution lane stages anything outside its carve-out → REJECT.
- **Foundation set coverage (M6(i), canon §4):** every AUTHORED spine path foundation stages must be covered BY PATH by a
  member of a RATIFIED set at HEAD (`- decision: RATIFIED…` in `_ratification/`). A message tag never covers anything.
  An unreadable packet, or one assembled against a non-ancestor, is never treated as ratified.
- **Exempt by content class** (`set_exempt()` — do not re-raise): record-keeping and narration substrate
  (`ledger/*`, `_boot/*`, `PENDING-SET.md`, `_ratification/*`, `_orchestration/{STATE,decision-log,lane-provisioning}.md`,
  `_orchestration/relay-*`, `dispatch/LATEST.md`, `issues_register.md`, `CHECKLIST.md`). Every DESIGN or AUTHORIZATION
  surface (`contracts/`, `sql/`, `migrations/`, `agents/`, `scripts/`, `skill/`, `src/`, seat defs, settings) rides a
  set. A rolling "standing maintenance set" is rejected: a set that keeps accepting members is a blank check.

## §3 The merge path
- A module branch reaches `main` only through `scripts/reap_at_merge.sh`, which runs the M6(ii) no-cherry-pick
  set-membership gate before it computes the merge tree, then merges `--no-ff --no-commit`.
- **`pre-merge-commit` refuses a raw auto-committing `git merge`** on the trunk (C-SET-AUTHORIZATION §2b). It is the one
  module→trunk route that skips `pre-commit`.

## §4 The tool gate (`PreToolUse` → `scripts/greenlight-policy.sh`)
- **Auto-approves a Bash call only when every segment is provably in policy.** Otherwise it is silent and the call
  falls through to the settings allow/ask/deny rules (a human prompt). A false prompt is safe; a false allow is the
  failure this hook must never produce.
- **Denies exactly one class**: hook bypass — `git commit --no-verify`/`-n` (including combined
  short flags), `git -c core.hooksPath`, `git config core.hooksPath`, `git push`/`merge --no-verify`.
- **Command shape** (CLAUDE.md §Command-shape law): no `cd` prefix; scratch files via the Write tool into `.tmp/`; one
  `scripts/*` invocation per call, with read-only post-filters only.

## §5 Not built (so no reader mistakes this for full coverage)
- The ARMED server-side twin (§8): `scripts/spine-receive.sh` is built, unarmed until the custody act. Until then all four
  gates are local.
- ~~`commit-msg` exit 3 PROCEEDS with a stamped trailer on non-`main` branches (refused by the auto-mode
  classifier).~~ Struck: cured at `agents/commit-msg-hook.sh:74`, which REJECTs every scanner
  rc other than 0 or 1.
- The completeness deny classes (the origin-scope deny classes of `completeness-classes.tsv`) in `greenlight-policy.sh` (held behind a separate ruling).

## §6 Folded disciplines (their text lives here now; `disciplines.md §1` keeps the history)
- **CANONICAL-MUST-REACH-THE-EXECUTING-SURFACE:** a spine-correct artifact is LANDED only when the copy that EXECUTES
  matches canonical, verified there by a check that fires. Instances: installed hook == canonical (boot `HOOK-CHECK:`),
  roster loaded at boot == spine, deployed code == committed. Spine-correct ≠ running-correct.
- **VERIFY-AT-THE-ENFORCERS-REFERENCE:** verify a property an enforcer decides (currency, equality, drift, coverage)
  against the EXACT reference that enforcer consults — never a proxy that happens to agree now (`HEAD` for an
  `origin/main`-keyed check; the local copy for a shared-installed hook).
- **CARVE-OUT-NEEDS-A-PROMOTION-PATH:** a write carve-out that lands durable artifacts outside canonical must define the
  route back in, or searches scoped to canonical return a confident wrong answer. The execution lane's route: the hub reads
  `origin/exec:ledger/apply-receipts/` every INBOX-CHECK (`scripts/inboxf.sh`).

## §7 Acceptance (proved only by a run)
W1 a module lane staging `contracts/x.md` is REJECTED · W2 the execution lane staging outside `ledger/apply-receipts/` is REJECTED ·
W3 foundation staging an uncovered `scripts/` path is REJECTED, and the same path covered by a ratified member PASSES ·
W4 an exempt-only commit PASSES · W5 an unresolvable lane is REJECTED · W6 a raw clean `git merge` of a module branch on
`main` is refused · W7 `git commit --no-verify` is denied by `greenlight-policy.sh`.

## §8 Enterprise lens
- **Server-side twin:** `scripts/spine-receive.sh`, the spine host's pre-receive check. It replays main's pre-commit hook
  (M6(i) coverage, the lane map) on every pushed commit; the lane comes from the pusher's key. Built; armed only at the custody act (the spine account exists).
  Until then a seat that uninstalls its local hook bypasses §2.
- **Identity source:** the committing worktree's `_boot/BOOTSTRAP.md`, cross-checked with its branch. Unsigned.
- **Role model:** writer classes by lane — spine writer, module single writer, apply-receipt writer, architect — and
  set RATIFICATION as the only authority that turns an authored spine path into a landable one.
- **Install/upgrade path:** `scripts/install_pre_commit_hook.sh` (hooks are shared across worktrees), and the boot
  `HOOK-CHECK:` line compares each installed hook with canonical. `greenlight-policy.sh` is wired in the tracked
  `.claude/settings.json`.
- **Harness binding:** git hooks (any client) plus a Claude Code `PreToolUse` hook for the tool gate.

**Limit (verbatim):** *"S binds a seat that has not read it only to the extent its enforcer cannot be
bypassed by that seat. With local hooks (v1.6.5) that is an honest-operator property at n = 1; the server-side twin
(canon v1.6.6 candidate) is what makes it a guarantee."*

History: git log -- contracts/MECH-WRITE.md agents/pre-commit-hook.sh · decision-log · _rulings/
