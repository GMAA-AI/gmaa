# FOUNDATION.md: your project's foundation (a fill)

**What this file is.** The decision-complete record of the choices only you can make, written in Phase 3 of `ADOPTION-COVER.md` and read in Phase 4 by the session that instantiates your project. Every section below names the canon step it fills. Replace each *(fill: ...)* prompt with your project's own answer. When this file is done, the implementing session must not need to ask you anything it answers.

**What this file is not.** It does not restate the architecture. The binding rules your project inherits are the canon's (`GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_8.md`, §3 among others) and the engine's `disciplines.md`. Where this file and the canon disagree, the canon governs and this file is corrected.

---

## 1 · Domain and invariants (canon §2; canon §12 step 1)

### 1.1 The domain
*(fill: what the project produces, who it serves, and the systems it touches.)*

### 1.2 The mediated-access rule
*(fill: which identity may write to which substrate, and through what mechanism; every other path is a violation.)*

### 1.3 Compliance rules
*(fill: each regulatory or platform rule that can stop the project on its own, and how a change is checked against it.)*

### 1.4 Domain invariants
*(fill: what must always hold in your system, each stated so a check can fail on it.)*

## 2 · Substrate and auth paths (canon §12 step 2)

*(fill: the substrate your seats work against, and its three auth paths:)*
- **Workload identity (read-only):** *(fill)*
- **Privileged human path:** *(fill)*
- **Scoped machine identities:** *(fill, or "none")*

## 3 · Apex ratifier and lane operators (canon §12 step 7)

- **Apex ratifier:** *(fill: the one named human who ratifies complete change-sets; this person's seat-key registry row is the only one marked `apex`.)*
- **Lane operators:** *(fill: who runs which seat, or "the apex ratifier runs every seat".)*
- **The operator and apex boundary, in writing:** *(fill: what a lane operator may ratify within the lane, and what only the apex ratifier may.)*

## 4 · Cost envelope (canon §1)

*(fill: the ruled cost envelope for subagent-heavy work, such as a model floor or batch limits, stated as an invariant with the receipts that show it holds.)* The engine's cost-cap slots are in `SLOTS.md`.

## 5 · Standing probes (canon §12 step 5)

*(fill: the least-privilege probe, which is mandatory, and each domain probe you add; each with a red pole it has been seen to fail on.)*

## 6 · Loop ceilings, interim

The engine reports three ratios at every boot and at every seal boundary, and prints a HALT line when one is breached; they are pressure, never a pass or fail of the ship gate: seals per worker commit at most **1/3**; cure sets per classed set at most **0.50**; restarts per lane per UTC day at most **6**. These are interim values. Re-set them from your own first seven days of record. They live in `probes/budget/probe_efficiency_budget.sh`, and changing them is an engine change that rides a ratified set like any other.

*(fill after your first seven days: the values you keep or set, with the record that supports them.)*

## 7 · Reference

*(fill: your project's own live documents, their paths, and what each governs. A new session looks here first.)*
