# FIELD-EVIDENCE, *(fill: your project's name)* (append-only; canon §4 "Field-evidence log")

Every project keeps an append-only log of thesis-relevant incidents. One entry per incident. Numbering is
project-prefixed: `<PREFIX>-E-nnn`, where `<PREFIX>` is your project's short prefix *(fill: it here)*. A PENDING entry is a claim, not evidence: ineligible for the canonical
ledger and for publication until its EVIDENCE resolves to receipts. Publication posture is per-entry and mandatory
(absent = internal).

| Field | Content |
|---|---|
| ID | `<PREFIX>-E-nnn` |
| DATE | ISO date |
| CLASS | Appendix A taxonomy class (canon) |
| INCIDENT | what happened, stated plainly |
| DETECTION | how it was caught (probe · auditor · operator · adopter report · seeded fault) |
| EVIDENCE | receipts: paths + shas + probe outputs; or `PENDING first HEAD` (greenfield convention) |
| LESSON / CURE | what changed, and where it landed (path + sha) |
| THESIS MAPPING | which invariant / mechanism it exercises |
| PUBLICATION | `internal` · `publishable` · `published:<ref>` |

---

## Entries

*(none yet)*
