#!/usr/bin/env bash
# agents/pre-push-hook.sh -- K4 at the push boundary: every commit a push carries must be signed by the key of the lane
# whose branch it lands on (the trunk branch: the trunk seat's key), judged at the spine's registry for a lane branch
# and at the pushed tip's registry for the trunk branch, so a commit
# made with `--no-gpg-sign` (invisible to pre-commit) is still refused. A push to a branch the lane map does not name is
# printed as SKIP-UNMAPPED, never silently passed. Installed by scripts/install_pre_commit_hook.sh. Fail-closed.
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 1
SK="$REPO_ROOT/scripts/seat-keys.sh"
# Spine fallback (the same form as agents/pre-commit-hook.sh's seat-keys line): a branch that does not carry the verb's
# script yet reads the trunk's copy. An empty or unreadable fallback REJECTs (fail-closed).
if [[ ! -f "$SK" ]]; then
    # the one spine-ref resolver, found from THIS HOOK's own location only (0507 R2/R16): installed (the hooks dir) -> the
    # resolver the installer placed beside it; the source copy under agents/ -> its tree's scripts/spine-ref.sh.
    _HOOK_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)"
    if [[ "${_HOOK_DIR##*/}" == agents ]]; then SPINE_REF_SH="${_HOOK_DIR%/agents}/scripts/spine-ref.sh"; else SPINE_REF_SH="$_HOOK_DIR/spine-ref.sh"; fi
    [[ -f "$SPINE_REF_SH" ]] || { echo "pre-push REJECT: SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found from this hook's location only; 0507 R2) (fail-closed)." >&2; exit 1; }
    SKD="$(mktemp -d "${TMPDIR:-/tmp}/seat-keys-push.XXXXXX")" || { echo "pre-push REJECT: mktemp failed for the seat-keys fallback (fail-closed)." >&2; exit 1; }
    trap 'rm -rf "$SKD"' EXIT
    SK="$SKD/seat-keys.sh"; cp "$SPINE_REF_SH" "$SKD/spine-ref.sh"   # the spine copy runs beside this hook's resolver (0507 R2)
    SPINE_REF="$(bash "$SPINE_REF_SH" 2>/dev/null)" && [[ -n "$SPINE_REF" ]] && git show "${SPINE_REF}":scripts/seat-keys.sh > "$SK" 2>/dev/null  # the ONE spine-ref resolver
    if [[ ! -s "$SK" ]]; then
        echo "pre-push REJECT: scripts/seat-keys.sh missing at $REPO_ROOT/scripts/seat-keys.sh and unreadable at the spine ref (${SPINE_REF:-SPINE-REF-UNRESOLVED}) (fail-closed)." >&2
        exit 1
    fi
fi
bash "$SK" verify-push "$@" || { echo "pre-push REJECT: the seat-keys gate refused this push (the SEAT-KEYS line above names it)." >&2; exit 1; }
