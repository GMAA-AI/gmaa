# Getting Started: Linux and Mac
**Setting up on a Linux or Mac machine. A Windows and WSL guide ships in a future release.**

This walks you from a blank machine to a completed adoption, assuming you have never used a terminal. The adoption runs in four phases (see `ADOPTION-COVER.md`): assessment and design happen **in chat**, implementation happens **in Claude Code**. If you **already have Claude Code installed, skip straight to Step 5.**

## What you need before starting
- A Linux machine with a POSIX shell, or a Mac (macOS 13 or later)
- A Claude account with a paid plan (Pro, Max, Team, or Enterprise). Sign up at claude.ai if needed.
- All the files that came with this package (unzip it somewhere you can find)

## Step 1: Check whether Claude Code is already installed
1. Open your terminal. **Linux:** open your terminal app. **Mac:** press **Cmd + Space**, type **Terminal**, press **Enter**.
2. Type exactly `claude --version` and press **Enter**.
3. If you see a version number of **2.1.302 or later**, you have it. **Skip to Step 5.** An older version: run `claude update`, then check again.
4. If you see `command not found`, continue to Step 2.

## Step 2: Install Claude Code and the tools the engine uses
1. In the same terminal, copy and paste this single line, then press **Enter**:
   ```
   curl -fsSL https://claude.ai/install.sh | bash
   ```
2. Wait for it to finish (a minute or two on a normal connection). No password should be needed.
3. **Quit the terminal completely and reopen it.** This is required so it finds the new command.
4. Type `claude --version` and press **Enter**. A version number means success. If not, type `claude doctor` and follow what it says, or see Troubleshooting.

**Also install the tools the engine runs on** (README, "Prerequisites"): tmux, git, python3, OpenSSH and perl. **Linux:** `sudo apt install tmux git python3 openssh-client perl unzip` (or your distro's package manager). **Mac:** `brew install tmux`; the others come with macOS or its developer tools. Confirm each one: `tmux -V`, `git --version`, `python3 --version`, `ssh -V`, `perl -v`.

## Step 3: Sign in once
1. Type `claude` and press **Enter**.
2. First launch walks you through setup. Pick a theme (any), and when it asks about signing in, choose your **Claude account**. A browser window opens; sign in and approve.
3. Type `/exit` and press **Enter**. The real launch comes later, in Phase 4.

## Step 4: Create the project folder (Phase 0)
1. Create the folder your project will live in, at your code root. Name it **lowercase, with no spaces**. This becomes your git repository name. **This folder is the PARENT:** the engine lives in `<folder>/foundation/` (created next), and every further lane will be a sibling worktree `<folder>/<lane>` (folder equals lane; `main` is a branch, never a folder name).
2. Create `foundation/` inside it and unzip the engine zip **into `foundation/`** with `unzip`. Use `unzip`, not a tool that drops file modes: the zip records which scripts are executable. Everything the engine needs travels in the zip: the canon (`GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_8.md`), `ADOPTION-COVER.md`, `CLAUDE.md`, the machinery. The loose files beside the zip in the release (`README.md`, `README.rtf`, `LICENSE.md`, `SHA256SUMS`) are the public face; copy `README.md` and `LICENSE.md` in beside the engine if you want them in the project folder.
3. From `foundation/`, confirm the package is intact: `sha256sum -c MANIFEST.sha256` (on a Mac, `shasum -a 256 -c MANIFEST.sha256`). Every line must report OK; if one does not, stop and report it.

## Step 5: Run Phases 1 through 3 (choose your surface)  *(skip-to point if you already had Claude Code)*
1. Read `ADOPTION-COVER.md` yourself first. It explains the four phases and which decisions are yours.
   **The chat path below is the recommended route.** The session that assesses and records your decisions stays separate from the one that implements them. (Work solely in the terminal? A Code-only alternative exists, described in the cover, but if you are unsure, use the chat path.) Continuing here:
2. In a chat session (a Claude project works well), upload the **architecture document** (`GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_8.md`), the **cover**, and, if your project is already thought out, your project's spec. Ask:
   > *Read `GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_8.md` and `ADOPTION-COVER.md`. Is GMAA a good fit for this project? Assess only. Do not implement anything yet.*
3. The chat states which architect role it is assuming and gives you a fit assessment. **If you decide to adopt, say so explicitly.** Nothing proceeds until you do (Phase 2).
4. Work through your three decisions in conversation (invariants, auth paths, who ratifies), and have the chat write your two decision-complete fills: **`docs/FOUNDATION.md`** and **`seats.yaml`** (give it `docs/SEATS_skeleton.yaml` from the zip as the shape). Each seat in `seats.yaml` names its operator, and exactly one seat, one the apex ratifier runs, carries `apex: true`; leave the public keys empty (they are made in Step 6, with each seat's `login` and `host`).
5. **Download `docs/FOUNDATION.md` and `seats.yaml` and drop them into the project folder** from Step 4.

## Step 6: Launch the implementation (Phase 4)
1. In the terminal, type `cd ` (c, d, one space; do not press Enter), drag the project folder onto the terminal window, and press **Enter**.
2. Start the instantiation in a **plain** Claude session (not the launcher): type `claude` and press **Enter**. The first instantiation uses plain Claude, because the launcher boots a seat that must already resolve its lane from the worktree, so on an un-instantiated project it would halt. Give the session:
   ```
   Read docs/FOUNDATION.md and seats.yaml and instantiate this project per canon §12.
   Layout: this folder is the parent; git init inside <parent>/foundation/ (the engine files
   live there, checked out to main); every further lane is a sibling worktree <parent>/<lane>
   via git worktree add. Add a git remote named origin and push main to it.
   ```
3. It verifies the fills and stands up the **foundation lane only**, and launches nothing. Foundation is the writer. Every further seat is provisioned later by an architect ruling that lands as a set you ratify (canon §2): never swept up from `seats.yaml` at genesis. It writes the governance files from your fills and stops there. The package ships no genesis generator, so your project starts in the declared **pre-genesis** condition (canon §12): `scripts/boot-check.sh` prints `STATE: PRE-GENESIS` at every boot, and that is expected (the cover, Phase 4, says what it means). If it halts naming a missing decision, that is it working correctly. Go settle the decision. Do not work around the halt.
4. **Enroll the seat keys before any hook is installed.** Follow `ADOPTION-COVER.md`, "Seat keys": generate foundation's key on its operator's machine with `bash scripts/seat-keys.sh keygen foundation`, write the printed public key with its `login` and `host` into foundation's `seats.yaml` entry (edit `seats.yaml` only). Run these commands in a second terminal window in `foundation/`, so the plain session from 6.2 stays open. Then ask that same session to write `_orchestration/seat-keys.tsv` from `seats.yaml`; if you closed it, start `claude` again in the same folder and ask the new session. Foundation commits the registry, check the apex row, bind the worktree with `bash scripts/seat-keys.sh setup-signing foundation`, and confirm with `bash scripts/seat-keys.sh confirm-lanes`.
5. **Install the two git hooks** (once per repository; hooks are not versioned, so the package ships installers): `bash scripts/install_pre_commit_hook.sh`, then `bash scripts/install_post_commit_hook.sh`. The pre-commit installer refuses until every writing seat is confirmed (step 4). The pre-commit hook IS the spine-write boundary; the post-commit hook is the auditor. Without them there is no gate, only prose. The launcher halts if the pre-commit hook is missing.
6. **Now** operate the seats with the launcher: from inside a lane's worktree folder, run `./launch-orc.sh` to boot that seat. Watch for the `BOOT-ACK: ...` line; that first turn is the launch proof.
7. **The `[set SET-NNNN]` message convention (advisory):** once the set gate is live, a foundation commit covered by a ratified set MAY carry `[set SET-NNNN]` in its commit message so readers can trace coverage at a glance. It is a convention checked after the commit, never the gate: enforcement is structural, by path, in the pre-commit hook, and a well-formed message cannot forge coverage.

## Step 7: The proof (do not skip)
Run the seeded-fault test (canon §12 step 8) with the agent. It plants a deliberate conflict, and the machinery must detect, name, hold, and recover it. **A clean run proves nothing.** Note what was seeded and whether it was caught.

## Upgrading (later)
Each engine release is a whole package; its `CHANGELOG.md` names what changed. In your project an engine update is a change like any other: it reaches `main` inside a set your apex ratifier ratifies.

## Step 8: Feedback (welcome)
`ADOPTION-COVER.md` lists what is most useful to send to arch@gmaa.ai, above all every place you or the AI had to guess.

## Troubleshooting
- **`command not found` after installing:** you did not reopen the terminal (Step 2.3). Or run `claude doctor`.
- **`permission denied` running the launcher or a script:** the files lost their modes when unzipped. Unzip again with `unzip` (Step 4.2), then `./launch-orc.sh`.
- **`HALT: no session created: ...` on launch:** the folder is not an instantiated lane yet. The launcher only boots a seat that resolves its lane from a committed `_boot/BOOTSTRAP.md` stamp inside a git worktree. Finish Step 6.2 (instantiation with a plain `claude` session) first. The text after the colon names what is missing.
- **The boot check prints `UNREADABLE ... Fetch, then re-run`:** the engine reads the spine at `origin/main`. Add the git remote named `origin` (Step 6.2), push `main` to it, run `git fetch origin`, and run the check again.
- **`HALT: no session created: pre-commit hook not installed`:** run the installers in Step 6.5.
- **The pre-commit installer refuses:** a writing seat is not confirmed yet. Finish Step 6.4, then run it again.
- **Install seems blocked:** on company-managed Macs, security policy may interfere. Ask IT, or see the official docs.
- **Never want to touch a terminal?** The Claude Desktop app includes Claude Code without the terminal (claude.com/download). The chat phases already run in chat by design.
- Official install docs: https://code.claude.com/docs/en/setup
