#!/usr/bin/env bash
# scripts/inboxf.sh — THE HUB READ. foundation's boundary instrument.
#
# WHY (SET-0026):
#   `scripts/inbox.sh` resolves EXACTLY ONE directory. For a module lane that is correct. For the HUB it is
#   a lie of omission: lane→hub delivery is outbox + reap, NEVER the spine inbox, and `relay-outbox/**` is
#   integration-EXCLUDED, so a module's payload exists ONLY on that lane's branch and NO spine-scoped read
#   can ever see it. MEASURED 2026-09-20: the hub read `empty` 10+ times while THREE lanes had written.
#   Every reading was TRUE AND USELESS, and the operator was the detector — twice.
#
# ⛔ TRUTHFUL-EMPTY IS THE POINT: an unresolvable source prints `(UNRESOLVED: <ref>)` and
#    NEVER collapses to empty. A hard resolution failure laundered into a clean wrong answer is worse than a
#    loud one — an empty result prompts a second look; a confident wrong one does not.

set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || {
    echo "inboxf.sh: HALT — not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2

# Resolve sibling libraries from THIS SCRIPT'S own directory, never from $REPO_ROOT: a script invoked
# against another worktree must still find ITS OWN libraries (the documented `cd <lane> && bash
# <main>/scripts/...` pattern). And FAIL LOUD — a missing library that degrades to "nothing is seen"
# silently resurrects every consumed message (DISC-CHILD-FAILURE-MUST-SURFACE).
_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_source_sibling() {
    local lib="$_SELF_DIR/$1"
    [[ -r "$lib" ]] || { echo "$(basename "$0"): HALT — required library missing/unreadable: $lib" >&2
                         echo "  Refusing to continue: without it the seen-state would silently read as EMPTY," >&2
                         echo "  which resurrects every consumed message as unread. Fail loud, never degrade." >&2
                         exit 5; }
    . "$lib"
}
_source_sibling lane-surface.sh
_source_sibling consume-core.sh   # ONE shared state machine

EVAL="$(scripts/resolve-lane.sh 2>/dev/null)" || {
    echo "inboxf.sh: HALT — lane unresolved (resolve-lane.sh non-zero)" >&2; exit 3; }
eval "$EVAL"
HUB_LANE="$lane"   # the hub's own stamped lane; loops below shadow $lane (window plan row 7)

# ── SELF-GUARD (pole 7) ─────────────────────────────
# The hub sweep belongs to the WRITER archetype only: `spine_write == ALLOW` (canon v1.6.5 §1.1). Every other
# class — DENY, apply-receipts-only, any future class — is REFUSED here with a named HALT, so a delegation
# bug in inbox.sh (the `!= DENY` defect that handed the execution lane the sweep) or a spoke typing this by hand can
# never run the hub's read. Operator, verbatim: "You do not run inboxf.sh you run inbox.sh and foundation
# runs inboxf.sh." Mirrors ratify.sh refusing assemble/assess/ratify outside the foundation worktree.
if [[ "${spine_write:-}" != "ALLOW" ]]; then
    echo "inboxf.sh: HALT — REFUSED: this is the HUB read and lane '${lane:-?}' has spine_write='${spine_write:-?}' (need ALLOW)." >&2
    echo "  Run scripts/inbox.sh — it reads relay-inbox/${lane:-<lane>}/. Only the spine_write=ALLOW seat runs inboxf.sh." >&2
    exit 6
fi

XP_DIR="${XP_DIR:-$HOME/Code/xp}"
# The XP addressee filter's project token is the STAMPED project (window plan row 7), read
# through scripts/resolve-project.sh, never a literal. Absent or malformed => XP_PROJECT empty => the filter is
# OPEN (every note SHOWN) and the report prints a named PROJECT-UNRESOLVED line. Never hides mail, never HALTs.
XP_PROJECT="$(bash "$_SELF_DIR/resolve-project.sh" 2>/dev/null)" || XP_PROJECT=""
XP_PROJECT="${XP_PROJECT#project=}"
core_init ".claude/inboxf-seen" "${INBOXF_SHOWN_FILE:-.claude/inboxf-shown}"   # INBOXF_SHOWN_FILE / INBOXF_SCREENED_FILE: write-side overrides for the Stop guard (unset = these paths)
cmd="${1:-check}"; core_consume_guard() { local s="${1%%$'\t'*}" n="${1#*$'\t'}" b sf rr; [[ "$s" == xp ]] && return 0; b="$(lane_branch "$s")" || return 0; sf="$(lane_surface "$s")" || return 0; git cat-file -e "origin/$b:${sf}${n}" 2>/dev/null || return 0; rr="$(core_relay_check "origin/$b" "${sf}${n}" "$s")" || { echo "inboxf.sh consume: $rr -- NOT consumed" >&2; return 1; }; }

# ── THE ROSTER IS READ HERE, IN THIS SHELL, OR THE CHECK HALTS (window plan row 3) ─────
# An unreadable lane manifest used to yield zero producer lanes, so no lane was named unresolved and this
# script printed `empty (all declared surfaces resolved)`: a failed read reported as a clean empty (canon s5).
# The sweep loops run `lane_producers` in a subshell, where a failure cannot reach us, so the load is done
# once here and a non-zero status HALTs with the reason. Never `empty`, never a default roster.
if [[ "$cmd" == check || "$cmd" == seed || "$cmd" == consume || "$cmd" == migrate ]]; then  # consume --all enumerates (row 2); migrate (row 17)
    if ! lane_manifest_load; then
        echo "INBOXF-CHECK: ${lane} UNREADABLE (lane manifest: ${LANE_MANIFEST_ERROR:-unknown}) — HALT, no surface was read"
        exit 3
    fi
fi

# ── XP ADDRESSEE FILTER (ISSUE-INBOXF-XP-SWEEP-HAS-NO-TO-FILTER) ──
# The ruling scopes the DMZ sweep to "messages whose TO header matches the seat/project". Without it the
# hub was shown ITS OWN OUTBOUND as inbound — caught by the instrument itself on its second live run.
#
# ⭐ FAIL-OPEN BY CONSTRUCTION, AND THAT IS THE WHOLE SAFETY ARGUMENT. A filter's dangerous direction is
#    UNDER-reporting — the silent-miss class this transport work exists to kill. So this filter can ONLY
#    remove mail that is EXPLICITLY addressed elsewhere:
#      · no parseable `TO:` header      -> SHOWN (never hidden by a parse failure)
#      · `TO:` mentions us              -> SHOWN
#      · `TO:` names someone else only  -> filtered
#    ⇒ the worst case of a filter bug is the OLD behaviour (over-report), never a hidden relay.
xp_addressed_to_us() {
    local f="$1" to
    to="$(grep -m1 -iE '^[*_[:space:]]*TO:' "$f" 2>/dev/null | tr 'A-Z' 'a-z')"
    [[ -z "$to" ]] && return 0                      # unparseable -> FAIL OPEN, show it
    # `operator` is NOT an addressee of the hub (window plan row 6; canon s5 fail-open must
    # not re-include the class it was built to drop): a `TO: ... operator` / "via operator" note is the hub's own
    # outbound or another program's ferry. Measured at the cure: 12 of 192 XP notes matched only that clause,
    # 7 written by foundation and 5 addressed to other seats; none named foundation.
    [[ -z "$XP_PROJECT" ]] && return 0             # no stamped project -> FAIL OPEN, show it
    case "$to" in
        *"$HUB_LANE"*|*"$XP_PROJECT"*|*"all lanes"*) return 0 ;;
    esac
    return 1
}

# ── SCREENED: ids judged NOT MAIL at the hub (an XP note addressed elsewhere; a receipt outside a message
# surface). Kept apart from the seen marker, which advances only on consume (consume-core.sh header). A screened
# id is never re-opened, so a check reads only new files (window plan row 15).
SCREENED="${INBOXF_SCREENED_FILE:-.claude/inboxf-screened}"
is_screened() { grep -qxF -- "$1" "$SCREENED" 2>/dev/null; }
screen()      { is_screened "$1" || printf '%s\n' "$1" >> "$SCREENED"; }

# ── MISFILED-MAIL detector (window plan row 14) ──────────────────────────────────────────────
# Where a lane's writable tree is wider than its message surface (`apply-receipts-only`: writes all of
# ledger/apply-receipts/, mail lives in relay/), every NEW file outside the surface is judged once:
#   name SURFACE-*/RETURN-*, or a `TO: … foundation` line in its first 8 lines  -> one MISFILED-MAIL line, every
#     check, until it is moved into the surface or consumed by explicit name (`consume <lane> <name>`)
#   anything else                                                                 -> SCREENED (a receipt, not mail)
# The two content rules were measured lossy as a SURFACE; here they only detect misplaced mail.
misfiled_scan() {  # prints MISFILED-MAIL lines; the count is the number of those lines
    local lane branch surface writable path name id
    while read -r lane; do
        [[ -n "$lane" ]] || continue
        branch="$(lane_branch "$lane")" || continue
        surface="$(lane_surface "$lane")" || continue
        writable="$(lane_writable "$lane")" || continue
        [[ "$writable" == "$surface" ]] && continue
        git rev-parse --verify --quiet "origin/$branch" >/dev/null || continue
        while read -r path; do
            [[ -n "$path" ]] || continue
            case "$path" in "$surface"*) continue ;; esac
            name="${path##*/}"
            case "$name" in .gitkeep|README.md|*.sig) continue ;; esac
            id="$(printf '%s\t%s' "$lane" "$name")"
            core_is_seen "$id" && continue
            is_screened "$id" && continue
            case "$name" in
                SURFACE-*|RETURN-*) printf 'MISFILED-MAIL: %s origin/%s:%s (mail outside %s; move it there, or consume %s %s)\n' "$lane" "$branch" "$path" "$surface" "$lane" "$name"; continue ;;
            esac
            if git show "origin/$branch:$path" 2>/dev/null | head -8 | grep -qiE '^[*_[:space:]]*TO:.*'"$HUB_LANE"; then
                printf 'MISFILED-MAIL: %s origin/%s:%s (mail outside %s; move it there, or consume %s %s)\n' "$lane" "$branch" "$path" "$surface" "$lane" "$name"
            else
                screen "$id"
            fi
        done < <(git ls-tree -r --name-only "origin/$branch" -- "$writable" 2>/dev/null)
    done < <(lane_producers)
}

# ── the pluggable source enumerator: the ONLY thing that differs from inbox.sh's front door ──────────────
core_enumerate() {
    local lane branch surface name
    while read -r lane; do
        [[ -n "$lane" ]] || continue
        branch="$(lane_branch "$lane")" || continue
        surface="$(lane_surface "$lane")" || continue
        git rev-parse --verify --quiet "origin/$branch" >/dev/null || continue
        # row 17: the item's CURRENT blob is noted for the shared core before its id is printed
        local mode type blob
        while IFS=$' \t' read -r mode type blob path; do
            [[ -n "$path" ]] || continue
            name="${path##*/}"
            case "$name" in .gitkeep|README.md|*.sig) continue ;; esac
            core_note_blob "$(printf '%s\t%s' "$lane" "$name")" "$blob"
            printf '%s\t%s\n' "$lane" "$name"
        done < <(git ls-tree -r "origin/$branch" -- "$surface" 2>/dev/null)
    done < <(lane_producers)
    if [[ -d "$XP_DIR" ]]; then
        # Row 15 (canon s5 + s7.4: inbox age is a read, not a full walk of every note on every turn): a note
        # already SEEN is skipped before its header is parsed. Only unseen notes are opened, so a check reads
        # the new mail, and a consumed note costs one marker lookup. A seen note was never pending anyway.
        # A note the filter rejects is SCREENED (recorded in SCREENED, never in the seen marker, which advances
        # only on consume), so it is not re-opened either.
        # row 17: a seen note is skipped only while its blob is unchanged. All notes are hashed
        # in ONE `git hash-object --stdin-paths` call and selected in ONE pass (core_select_noncurrent); only the
        # non-current notes are opened. A hash failure notes no blob for that note (name-only, as before row 17).
        local id files blobs nc f b
        files="$(find "$XP_DIR" -maxdepth 1 -type f -name '*.md' 2>/dev/null | sort)"
        if [[ -n "$files" ]]; then
            blobs="$(printf '%s\n' "$files" | git hash-object --stdin-paths 2>/dev/null)" || blobs=""
            if [[ -n "$blobs" ]] && [[ "$(printf '%s\n' "$blobs" | grep -c .)" -eq "$(printf '%s\n' "$files" | grep -c .)" ]]; then
                while IFS=$'\t' read -r f b; do
                    core_note_blob "$(printf 'xp\t%s' "${f##*/}")" "$b"
                done < <(paste <(printf '%s\n' "$files") <(printf '%s\n' "$blobs"))
            fi
            nc="$(printf '%s\n' "$files" | sed 's#.*/##; s#^#xp\t#' | core_select_noncurrent)"
            while IFS= read -r id; do
                [[ -n "$id" ]] || continue
                is_screened "$id" && continue
                f="$XP_DIR/${id#xp$'\t'}"
                if xp_addressed_to_us "$f"; then printf '%s\n' "$id"; else screen "$id"; fi
            done <<< "$nc"
        fi
    fi
}

# sweep_report <pending> <shown-file> — human-facing lines over ONE pending set, and the shown-snapshot
# written from EXACTLY the NEW lines printed (window plan row 1; canon s5: consume --all
# may mark only what the check displayed). The check used to print one sweep and snapshot a second one, so mail
# landing between the two could be marked seen without ever being printed.
sweep_report() {
    local pending="$1" shownf="$2" lane branch surface ref n
    while read -r lane; do
        [[ -n "$lane" ]] || continue
        branch="$(lane_branch "$lane")" || { printf 'LANE %-12s (UNRESOLVED: no branch declared)\n' "$lane"; continue; }
        surface="$(lane_surface "$lane")" || { printf 'LANE %-12s (UNRESOLVED: no surface for class)\n' "$lane"; continue; }
        ref="origin/$branch"
        if ! git rev-parse --verify --quiet "$ref" >/dev/null; then
            printf 'LANE %-12s (UNRESOLVED: %s)\n' "$lane" "$ref"; continue      # truthful-empty, never "(none)"
        fi
        n=0
        while IFS=$'\t' read -r src name; do
            [[ "$src" == "$lane" ]] || continue; if ! rr="$(core_relay_check "$ref" "${surface}${name}" "$lane")"; then printf 'REFUSED %-12s %s\n' "$lane" "${rr#REFUSED: }"; continue; fi
            printf 'NEW  %-12s %s:%s%s\n' "$lane" "$ref" "$surface" "$name"; n=$((n+1))
            amd="$(core_amended "$src"$'\t'"$name")" && printf 'AMENDED-AFTER-CONSUME: %s (%s)\n' "$name" "$amd"
            printf '%s\t%s\n' "$src" "$name" >> "$shownf"
        done <<< "$pending"
        [[ $n -eq 0 ]] && printf 'LANE %-12s empty (%s @ %s)\n' "$lane" "$surface" "$ref"
    done < <(lane_producers)

    if [[ ! -d "$XP_DIR" ]]; then
        printf 'XP   %-12s (UNRESOLVED: %s absent)\n' "-" "$XP_DIR"
    else
        [[ -z "$XP_PROJECT" ]] && printf 'XP   %-12s PROJECT-UNRESOLVED (no valid project: in _boot/BOOTSTRAP.md; addressee filter OPEN, every note shown)\n' "-"
        n=0
        while IFS=$'\t' read -r src name; do
            [[ "$src" == "xp" ]] || continue
            printf 'NEW  %-12s %s\n' "xp" "$name"; n=$((n+1))
            amd="$(core_amended "$src"$'\t'"$name")" && printf 'AMENDED-AFTER-CONSUME: %s (%s)\n' "$name" "$amd"
            printf '%s\t%s\n' "$src" "$name" >> "$shownf"
        done <<< "$pending"
        [[ $n -eq 0 ]] && printf 'XP   %-12s empty (%s, addressee-filtered fail-open)\n' "-" "$XP_DIR"
    fi
}

case "$cmd" in
  check)
      shownf="$(mktemp "${TMPDIR:-/tmp}/inboxf-shown.XXXXXX")" || { echo "INBOXF-CHECK: ${lane} UNREADABLE (mktemp failed) — HALT" ; exit 3; }
      pending="$(core_pending)"                # ONE sweep (row 1): the report and the snapshot share it
      out="$(sweep_report "$pending" "$shownf")"
      printf '%s\n' "$out"
      core_record_shown < "$shownf"            # snapshot EXACTLY the NEW lines displayed (bounds consume --all)
      rm -f "$shownf"
      mis="$(misfiled_scan)"
      [[ -n "$mis" ]] && printf '%s\n' "$mis"
      new="$(printf '%s\n' "$out" | grep -c '^NEW ' || true)"
      unres="$(printf '%s\n' "$out" | grep -c 'UNRESOLVED' || true)"
      misn="$(printf '%s\n' "$mis" | grep -c '^MISFILED-MAIL:' || true)"; refn="$(printf '%s\n' "$out" | grep -c '^REFUSED ' || true)"
      if [[ "$new" -eq 0 && "$unres" -eq 0 && "$misn" -eq 0 && "$refn" -eq 0 ]]; then
          echo "INBOXF-CHECK: ${lane} empty (all declared surfaces resolved)"
      elif [[ "$misn" -eq 0 && "$refn" -eq 0 ]]; then
          echo "INBOXF-CHECK: ${lane} ${new} new · ${unres} unresolved"
      else
          echo "INBOXF-CHECK: ${lane} ${new} new · ${unres} unresolved$([[ "$misn" -gt 0 ]] && echo " · ${misn} misfiled")$([[ "$refn" -gt 0 ]] && echo " · ${refn} refused-unverified")"
      fi
      ;;
  seed)
      n="$(core_seed_all)"
      echo "INBOXF-SEED: sealed ${n} pre-existing item(s) as seen — only post-cutover arrivals are NEW from here."
      ;;
  consume)
      shift
      core_take_premise "$@" || exit 2                     # PREMISE-CHECK: no premise, no consume
      set -- consume ${CORE_ARGS[@]+"${CORE_ARGS[@]}"}     # bash-3.2-safe empty-array expansion
      if [[ "${2:-}" == "--all" ]]; then
          n="$(core_consume_all)" || exit 2
          echo "INBOXF-CONSUMED: ${n} item(s) (bounded by the last check's shown-snapshot, never the live set)."
      elif [[ $# -ge 3 ]]; then
          # EXPLICIT <src> <name> — unambiguous, always accepted.
          core_consume_one "${2}"$'\t'"${3}" || exit 2; echo "INBOXF-CONSUMED: ${2}/${3}"
      elif [[ $# -eq 2 ]]; then
          # ── BARE <name> — INTERFACE PARITY WITH scripts/inbox.sh ──
          # WHY THIS EXISTS: `inbox.sh` delegates the WHOLE verb here, and the ruling promised "the shared
          # front-door behaviour is identical". It was not. `.claude/agents/orc.md:147` — inside the block
          # that file calls "the FIRST action of EVERY turn" — instructs the hub to run
          # `scripts/inbox.sh consume <name>`, and that exact documented command returned rc=2.
          # The marker advances ONLY on consume, so a seat following its own persona could not advance it.
          #
          # ⛔ RESOLVED AGAINST THE SHOWN-SNAPSHOT, AND FAIL-CLOSED ON AMBIGUITY. A bare name is ambiguous at
          # the hub by construction (two lanes may carry the same filename). Consuming the WRONG lane's copy
          # would mark genuinely unread work as read — silent, and the exact harm the shown-snapshot bound
          # was ratified to prevent (ISSUE-INBOX-CONSUME-ALL-SWALLOWS-UNREAD-2026-07-22). So: exactly one
          # match consumes; zero or many HALT LOUD with the remedy printed. Never guess, never take the first.
          _want="${2}"; _hits=()
          if [[ -f "$CORE_SHOWN" ]]; then
              while IFS= read -r _line; do
                  [[ -n "$_line" ]] || continue
                  [[ "${_line#*$'\t'}" == "$_want" ]] && _hits+=("$_line")
              done < "$CORE_SHOWN"
          fi
          case "${#_hits[@]}" in
            1) core_consume_one "${_hits[0]}" || exit 2
               echo "INBOXF-CONSUMED: ${_hits[0]%%$'\t'*}/${_want}  (resolved from the last check's shown-snapshot)" ;;
            0) echo "inboxf.sh consume: HALT — '${_want}' is not in the last check's shown-snapshot." >&2
               echo "  A bare name is resolved ONLY against what a prior check DISPLAYED — that bound is what stops an unread arrival being marked read." >&2
               echo "  Run \`scripts/inboxf.sh\` (check) first, or name the source explicitly: consume <src> <name>." >&2
               exit 2 ;;
            *) echo "inboxf.sh consume: HALT — '${_want}' is AMBIGUOUS across ${#_hits[@]} sources; refusing to guess." >&2
               for _h in "${_hits[@]}"; do echo "    consume ${_h%%$'\t'*} ${_want}" >&2; done
               exit 2 ;;
          esac
      else
          echo "usage: inboxf.sh consume {<name> | <src> <name> | --all} --premise holds@<ref>|refuted@<ref>" >&2; exit 2
      fi
      ;;
  migrate)
      # row 17 cutover (migration): every legacy seen line gets its item's CURRENT blob, so
      # nothing re-shows at cutover and the first amendment after it does. DISC-NO-INHERITED-COUNT: the count.
      core_enumerate >/dev/null
      echo "INBOXF-MIGRATE: seen-lines migrated $(core_migrate) of $(awk '!/\t[0-9a-f]{40}$/' "$CORE_MARKER" 2>/dev/null | sort -u | grep -c .) legacy line(s)"
      ;;
  *) echo "usage: inboxf.sh [check|seed|migrate|consume {<name>|<src> <name>|--all} --premise holds@<ref>|refuted@<ref>]" >&2; exit 2 ;;
esac
