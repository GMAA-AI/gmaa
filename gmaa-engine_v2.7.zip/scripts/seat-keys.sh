#!/bin/bash
# scripts/seat-keys.sh -- seat signing keys: registry -> allowed_signers, commit + relay verify, K5 registry probe.
# Authority: the seat-key contract K1-K6, and contract L (L2 needs the login/host/apex columns).
# Pre-genesis the registry is the K2 interim file seat-keys.tsv in the orchestration directory (origin instance data, never ships;
# declared compensating control under CONSTANTS s4, probed by the K5 registry probe).
#
# Verbs (every verb prints `SEAT-KEYS: <verb> PASS|FAIL|HALT <reason>`; rc 0 PASS, 1 FAIL, 2 HALT; never a silent pass):
#   allowed-signers [--ref R] [--registry F]            ssh allowed_signers on stdout (status line on stderr)
#   verify-commit <lane> <sha> [--ref R]                signed by <lane>'s registered key, judged at registry@R
#   sign-relay <file> --key <private-key>               detached ssh signature, namespace "relay", -> <file>.sig
#   verify-relay <file> <from-lane> [--ref R]           <file>.sig must verify as <from-lane> in namespace "relay"
#   check-registry [--ref R] [--apex]                   K5 registry probe (+ L's exactly-one-apex check)
#   leak-scan                                           no private-key header on any ref
#   keygen <lane>                                       ed25519 key outside every worktree; prints the registry row
#   relay-from <path>                                   FROM seat of a relay path (outbox dir; inbox = ALLOW lane; apply-receipts relay)
#   setup-signing <lane> [--key K]                      this worktree signs every commit with the lane's key (config --worktree); <lane> must be the lane this worktree resolves
#   confirm-lanes [--ref R]                             every writing lane has 1 registry row at R (default HEAD) + a setup-signing readback in its worktree
#   adopt-candidate <candidate-ref>                     the lane's own signed commit A, tree(A)=tree(C), parents(A)=parents(C); branch -> A, never C
#   hook-precommit <lane> <spine_write> [--ref R]       pre-commit K gate: signing key == registry row; staged relays signed + verified
#   verify-range <lane> <rev-args...> [--ref R]         every commit in the range is signed by <lane> (reap, pre-push)
#   verify-push                                         pre-push K gate over git's stdin ref lines
#   login-line                                          `- recorded-under-login: <acct> (uid <n>) @ <host>` from the process credential
#   login-tie [--registry F]                            the derived login must equal the single apex row's login (refusals named)
#   fixture-enroll <repo> <lane> [--apex]               FIXTURE-ONLY: enroll a throwaway repo's lane (HALT rc 2 on a lane remote, an unset/default key home); an inherited registry is replaced by a fresh `# fixture` one
# Judging ref R: registry, revocation list and lane map are read from R (git show R:path), so a lane cannot
# vouch for itself with its own copy. Default (no --ref) = the working-tree files of this repo.
# Env: SEAT_KEYS_HOME overrides the keygen directory (default $HOME/.config/{{SEAT_KEYS_DIR_NAME}}); poles use a temp dir.
# Env: SEAT_KEYS_REGISTRY_PATH / SEAT_KEYS_REVOKED_PATH / SEAT_KEYS_LANEMAP_PATH override the in-repo paths.
# Lane map parsed: _orchestration/lane-provisioning.md table rows (header line 10, rows lines 12-18 at base 0a4135ca):
#   col 1 = lane (a trailing "(...)" alias is stripped: "worker (exec)" -> worker), col 2 = branch. Every row is a
#   writing lane (K1: the trunk seat, each module lane, the execution lane, the architect lane). NOTE contracts/CONSTANTS.md has
#   no such table; the _orchestration/ file is the only one (two files share a basename elsewhere).
# Bash 3.2 safe: no associative arrays, no mapfile, no case inside $( ).

REG_PATH="${SEAT_KEYS_REGISTRY_PATH:-_orchestration/seat-keys.tsv}"
REV_PATH="${SEAT_KEYS_REVOKED_PATH:-_orchestration/seat-keys-revoked.txt}"
MAP_PATH="${SEAT_KEYS_LANEMAP_PATH:-_orchestration/lane-provisioning.md}"
NS_REGEX_PATTERN='-----BEGIN (OPENSSH|RSA|EC|DSA)? ?PRIVATE KEY-----'

VERB=""
OUT=1   # fd for status lines (allowed-signers moves it to 2)

say() { # say PASS|FAIL|HALT reason
  if [ "$OUT" = 2 ]; then echo "SEAT-KEYS: $VERB $1 $2" >&2; else echo "SEAT-KEYS: $VERB $1 $2"; fi
}
halt() { say HALT "$1"; exit 2; }
fail() { say FAIL "$1"; exit 1; }
pass() { say PASS "$1"; exit 0; }

TMP=$(mktemp -d "${TMPDIR:-/tmp}/seat-keys.XXXXXX") || { echo "SEAT-KEYS: init HALT mktemp failed"; exit 2; }
trap 'rm -rf "$TMP"' EXIT

TOP=$(git rev-parse --show-toplevel 2>/dev/null)

# fetch_file <path-in-repo> <dest> : from $REF if set, else working tree. HALT if absent.
fetch_file() {
  if [ "$REF" = INDEX ]; then
    git show ":$1" > "$2" 2>/dev/null || halt "cannot read $1 in the index (registry unreadable is never a pass)"
  elif [ -n "$REF" ]; then
    git show "$REF:$1" > "$2" 2>/dev/null || halt "cannot read $1 at ref $REF (registry unreadable is never a pass)"
  else
    [ -n "$TOP" ] || halt "not inside a git work tree"
    [ -f "$TOP/$1" ] || halt "missing $1 in working tree"
    cat "$TOP/$1" > "$2"
  fi
}

# load_registry : sets $TMP/reg (raw), $TMP/rows (normalized TSV: lane branch operator keytype+b64 login host apex),
# $TMP/bad (malformed-row diagnostics), $TMP/revoked (normalized keys, one per line)
load_registry() {
  if [ -n "$REGFILE" ]; then
    [ -f "$REGFILE" ] || halt "registry file $REGFILE not found"
    cat "$REGFILE" > "$TMP/reg"
  else
    fetch_file "$REG_PATH" "$TMP/reg"
  fi
  awk -F'\t' '
    /^[[:space:]]*#/ || /^[[:space:]]*$/ { next }
    {
      bad = ""
      if (NF != 7) bad = "expected 7 TAB columns, got " NF
      else {
        for (i = 1; i <= 7; i++) if ($i == "") bad = "empty column " i
        split($4, k, " ")
        if (k[1] != "ssh-ed25519" || k[2] == "") bad = "pubkey is not ssh-ed25519 <base64>"
        if ($7 != "apex" && $7 != "-") bad = "apex column must be apex or -"
        if ($1 ~ /[ \t]/) bad = "lane id has whitespace"
      }
      if (bad != "") { print "line " NR ": " bad > "'"$TMP"'/bad"; next }
      split($4, k, " ")
      printf "%s\t%s\t%s\t%s %s\t%s\t%s\t%s\n", $1, $2, $3, k[1], k[2], $5, $6, $7
    }' "$TMP/reg" > "$TMP/rows"
  : >> "$TMP/bad"
  fetch_file "$REV_PATH" "$TMP/revraw"
  awk '/^[[:space:]]*#/ || /^[[:space:]]*$/ { next } { print $1 " " $2 }' "$TMP/revraw" > "$TMP/revoked"
}

# load_lanes : $TMP/lanes (lane<TAB>branch) from the lane-provisioning table
load_lanes() {
  fetch_file "$MAP_PATH" "$TMP/map"
  awk -F'|' '
    /^\|/ {
      a = $2; b = $3
      gsub(/^[ \t]+|[ \t]+$/, "", a); gsub(/^[ \t]+|[ \t]+$/, "", b)
      if (a == "lane" || a ~ /^-+$/ || a == "") next
      sub(/[ \t]*\(.*\)$/, "", a)
      print a "\t" b
    }' "$TMP/map" > "$TMP/lanes"
  [ -s "$TMP/lanes" ] || halt "no lane rows parsed from $MAP_PATH (lane map unreadable is never a pass)"
}

# emit_allowed_plus_revoked <dest> : allowed_signers + every revoked key under the reserved principal REVOKED-KEY,
# used only to NAME a refusal (a revoked key whose row was already removed would otherwise read as unknown-key).
# REVOKED-KEY lines go FIRST: `ssh-keygen -Y find-principals` (OpenSSH 10.3, measured) prints only the FIRST matching
# principal, so a revoked key whose row is still enrolled would otherwise name the lane and read as bad-signature.
emit_allowed_plus_revoked() {
  awk '{ printf "REVOKED-KEY namespaces=\"git,relay\" %s\n", $0 }' "$TMP/revoked" > "$1"
  emit_allowed "$TMP/al.only"
  cat "$TMP/al.only" >> "$1"
}

emit_allowed() { # emit_allowed <dest> : allowed_signers from $TMP/rows
  awk -F'\t' '{ printf "%s namespaces=\"git,relay\" %s\n", $1, $4 }' "$TMP/rows" > "$1"
}

parse_ref_opts() { # sets REF REGFILE and leftover positionals in POS (space separated, no spaces in values assumed)
  REF=""; REGFILE=""; POS=""; APEX=0; KEY=""
  while [ $# -gt 0 ]; do
    if [ "$1" = "--ref" ]; then REF="$2"; shift 2
    elif [ "$1" = "--registry" ]; then REGFILE="$2"; shift 2
    elif [ "$1" = "--key" ]; then KEY="$2"; shift 2
    elif [ "$1" = "--apex" ]; then APEX=1; shift
    else POS="$POS $1"; shift; fi
  done
}

verb_allowed_signers() {
  OUT=2
  parse_ref_opts "$@"
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  [ -s "$TMP/rows" ] || halt "registry has 0 enrolled rows"
  emit_allowed "$TMP/al"
  cat "$TMP/al"
  pass "$(wc -l < "$TMP/al" | tr -d ' ') principals emitted"
}

# vc_prepare : $TMP/al (allowed_signers), $TMP/rev (revocation file), $TMP/rev0 (empty) from the loaded registry
vc_prepare() {
  emit_allowed "$TMP/al"
  cp "$TMP/revraw" "$TMP/rev"
  : > "$TMP/rev0"
}

# vc_check <lane> <sha> : 0 = signed by <lane>'s registered key; 1 = refused. VC_MSG carries the named reason.
vc_check() {
  VC_LANE="$1"; VC_SHA="$2"
  GV="git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile=$TMP/al -c gpg.ssh.revocationFile=$TMP/rev"
  LINE=$($GV log -1 --format='%G?|%GS|%GK' "$VC_SHA" 2>/dev/null)
  ST="${LINE%%|*}"; REST="${LINE#*|}"; PRIN="${REST%%|*}"
  if [ "$ST" = "G" ]; then
    $GV verify-commit "$VC_SHA" > /dev/null 2>&1 || { VC_MSG="git verify-commit rejected $VC_SHA despite status G"; return 1; }
    if [ "$PRIN" = "$VC_LANE" ]; then VC_MSG="$VC_SHA signed by $VC_LANE's registered key"; return 0; fi
    VC_MSG="wrong-lane: $VC_SHA signed by registered principal '$PRIN', not '$VC_LANE'"; return 1
  elif [ "$ST" = "N" ]; then VC_MSG="unsigned: $VC_SHA carries no signature"; return 1
  else
    emit_allowed_plus_revoked "$TMP/alr"
    LINE0=$(git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile="$TMP/alr" -c gpg.ssh.revocationFile="$TMP/rev0" log -1 --format='%G?|%GS' "$VC_SHA" 2>/dev/null)
    ST0="${LINE0%%|*}"; PRIN0="${LINE0#*|}"
    if [ "$PRIN0" = "REVOKED-KEY" ] || { [ "$ST" = "B" ] && [ "$ST0" = "G" ]; }; then
      VC_MSG="revoked: key that signed $VC_SHA is in the revocation list"; return 1
    fi
    if [ "$ST" = "U" ]; then VC_MSG="unknown-key: $VC_SHA signed by a key not in the registry (principal for '$VC_LANE' unmatched)"; return 1; fi
    VC_MSG="bad-signature: $VC_SHA status '$ST' (not verifiable)"; return 1
  fi
}

verb_verify_commit() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 2 ] || halt "usage: verify-commit <lane> <sha> [--ref R]"
  LANE="$1"; SHA="$2"
  git rev-parse --verify -q "$SHA^{commit}" > /dev/null || halt "commit $SHA not found"
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  vc_prepare
  if vc_check "$LANE" "$SHA"; then pass "$VC_MSG"; fi
  fail "$VC_MSG"
}

verb_sign_relay() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 1 ] || halt "usage: sign-relay <file> --key <private-key-path>"
  F="$1"
  [ -f "$F" ] || halt "relay file $F not found"
  [ -n "$KEY" ] && [ -f "$KEY" ] || halt "--key <private-key-path> missing or not a file"
  rm -f "$F.sig"
  ssh-keygen -Y sign -n relay -f "$KEY" "$F" > /dev/null 2>"$TMP/sign.err" || halt "ssh-keygen sign failed: $(head -1 "$TMP/sign.err")"
  [ -s "$F.sig" ] || halt "no signature written to $F.sig"
  pass "signed $F -> $F.sig (namespace relay)"
}

verb_verify_relay() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 2 ] || halt "usage: verify-relay <file> <from-lane> [--ref R]"
  F="$1"; LANE="$2"
  [ -f "$F" ] || halt "relay file $F not found"
  [ -f "$F.sig" ] || fail "unsigned: $F.sig missing"
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  emit_allowed "$TMP/al"
  cp "$TMP/revraw" "$TMP/rev"
  : > "$TMP/rev0"
  if ssh-keygen -Y verify -f "$TMP/al" -I "$LANE" -n relay -s "$F.sig" -r "$TMP/rev" < "$F" > /dev/null 2>&1; then
    pass "$F signed by $LANE (namespace relay)"
  fi
  emit_allowed_plus_revoked "$TMP/alr"
  WHOR=$(ssh-keygen -Y find-principals -f "$TMP/alr" -s "$F.sig" 2>/dev/null | tr '\n' ',')
  if echo ",$WHOR" | grep -q "REVOKED-KEY,"; then fail "revoked: key that signed $F is in the revocation list"; fi
  WHO=$(ssh-keygen -Y find-principals -f "$TMP/al" -s "$F.sig" 2>/dev/null | tr '\n' ',' | sed 's/,$//')
  if [ -z "$WHO" ]; then fail "unknown-key: signature on $F is not from any registered key"; fi
  if ! echo ",$WHO," | grep -q ",$LANE,"; then fail "wrong-lane: $F signed by '$WHO', not '$LANE'"; fi
  fail "bad-signature: $F does not verify for $LANE (tampered bytes or wrong namespace)"
}

verb_check_registry() {
  parse_ref_opts "$@"
  load_registry
  load_lanes
  NL=$(wc -l < "$TMP/lanes" | tr -d ' ')
  NR=$(wc -l < "$TMP/rows" | tr -d ' ')
  : > "$TMP/prob"
  if [ -s "$TMP/bad" ]; then sed 's/^/malformed-row: /' "$TMP/bad" >> "$TMP/prob"; fi
  # enrolled = lanes with exactly one row
  ENR=0
  while IFS="$(printf '\t')" read -r L B; do
    C=$(awk -F'\t' -v l="$L" '$1 == l { n++ } END { print n + 0 }' "$TMP/rows")
    if [ "$C" = "1" ]; then
      ENR=$((ENR + 1))
      RB=$(awk -F'\t' -v l="$L" '$1 == l { print $2 }' "$TMP/rows")
      [ "$RB" = "$B" ] || echo "branch-mismatch: lane $L registry branch '$RB' != lane map '$B'" >> "$TMP/prob"
    elif [ "$C" = "0" ]; then echo "missing-row: writing lane $L has no registry row" >> "$TMP/prob"
    else echo "multiple-rows: lane $L has $C rows" >> "$TMP/prob"; fi
  done < "$TMP/lanes"
  # every row maps to a live lane
  awk -F'\t' 'NR == FNR { live[$1] = 1; next } !($1 in live) { print "orphan-row: registry lane " $1 " is not in the lane map" }' "$TMP/lanes" "$TMP/rows" >> "$TMP/prob"
  # no two rows share a key
  awk -F'\t' '{ n[$4]++; w[$4] = w[$4] " " $1 } END { for (k in n) if (n[k] > 1) print "duplicate-key: lanes" w[k] " share one key" }' "$TMP/rows" >> "$TMP/prob"
  # an enrolled key must not be on the revocation list
  awk -F'\t' 'NR == FNR { r[$0] = 1; next } ($4 in r) { print "revoked-key-enrolled: lane " $1 " row carries a revoked key" }' "$TMP/revoked" "$TMP/rows" >> "$TMP/prob"
  if [ "$APEX" = 1 ]; then
    NA=$(awk -F'\t' '$7 == "apex" { n++ } END { print n + 0 }' "$TMP/rows")
    [ "$NA" = "1" ] || echo "apex-rows: $NA apex rows (need exactly 1)" >> "$TMP/prob"
  fi
  if [ "$NR" = "0" ] && [ ! -s "$TMP/bad" ]; then
    echo "0 of $NL writing lanes enrolled (registry has no data rows)" > "$TMP/prob.first"
    cat "$TMP/prob" >> "$TMP/prob.first"; mv "$TMP/prob.first" "$TMP/prob"
  fi
  if [ -s "$TMP/prob" ]; then
    sed 's/^/  - /' "$TMP/prob"
    fail "$ENR of $NL writing lanes enrolled; $(wc -l < "$TMP/prob" | tr -d ' ') problem(s): $(head -1 "$TMP/prob")"
  fi
  pass "$ENR of $NL writing lanes enrolled, one row each, no shared key, no orphan row$( [ "$APEX" = 1 ] && echo ', exactly one apex row')"
}

verb_leak_scan() {
  [ -n "$TOP" ] || halt "not inside a git work tree"
  # positive control of the pattern itself: a constructed header MUST match
  HDR=$(printf '%s%s' '-----BEGIN OPENSSH' ' PRIVATE KEY-----')
  echo "$HDR" | grep -E -q -e "$NS_REGEX_PATTERN" || halt "leak pattern failed its own positive control"
  REFS=$(git for-each-ref --format='%(refname)')
  [ -n "$REFS" ] || halt "no refs to scan"
  NREFS=$(echo "$REFS" | wc -l | tr -d ' ')
  git grep -I -l -E -e "$NS_REGEX_PATTERN" $REFS > "$TMP/hits" 2>"$TMP/gerr"
  RC=$?
  if [ "$RC" = 0 ]; then
    sed 's/^/  - /' "$TMP/hits"
    fail "private-key header in $(wc -l < "$TMP/hits" | tr -d ' ') place(s), first: $(head -1 "$TMP/hits")"
  elif [ "$RC" = 1 ]; then pass "0 private-key headers over $NREFS refs"
  else halt "git grep error rc=$RC: $(head -1 "$TMP/gerr")"; fi
}

verb_keygen() {
  [ $# -eq 1 ] || halt "usage: keygen <lane>"
  LANE="$1"
  DIR="${SEAT_KEYS_HOME:-$HOME/.config/{{SEAT_KEYS_DIR_NAME}}}"
  # refuse if the target is inside any git worktree (walk to the nearest existing ancestor)
  A="$DIR"
  while [ ! -d "$A" ] && [ "$A" != "/" ]; do A=$(dirname "$A"); done
  if git -C "$A" rev-parse --is-inside-work-tree > /dev/null 2>&1; then
    halt "refusing: $DIR is inside a git worktree ($(git -C "$A" rev-parse --show-toplevel)); keys live outside every worktree"
  fi
  mkdir -p "$DIR" && chmod 700 "$DIR" || halt "cannot create $DIR"
  [ ! -e "$DIR/$LANE" ] || halt "refusing to overwrite existing key $DIR/$LANE"
  ssh-keygen -q -t ed25519 -N '' -C "$LANE@seat" -f "$DIR/$LANE" > /dev/null || halt "ssh-keygen failed"
  BR="<branch>"
  if [ -n "$TOP" ] && [ -f "$TOP/$MAP_PATH" ]; then
    BR=$(awk -F'|' -v l="$LANE" '/^\|/ { a=$2; b=$3; gsub(/^[ \t]+|[ \t]+$/,"",a); gsub(/^[ \t]+|[ \t]+$/,"",b); sub(/[ \t]*\(.*\)$/,"",a); if (a==l) print b }' "$TOP/$MAP_PATH" | head -1)
    [ -n "$BR" ] || BR="<branch>"
  fi
  PUB=$(cut -d' ' -f1,2 "$DIR/$LANE.pub")
  echo "private key: $DIR/$LANE (never commit, relay or dispatch it)"
  echo "registry row to add (TAB-separated; fill <operator> <login> <host>; apex column = apex or -):"
  printf '%s\t%s\t<operator>\t%s\t<login>\t<host>\t-\n' "$LANE" "$BR" "$PUB"
  pass "key for $LANE written to $DIR"
}

# ---------------------------------------------------------------------------------------------------------------
# Wiring verbs: commit-signing setup, relay signing + verification at the hooks, push range check, login tie.
# Judging ref for the wiring (never the lane's own copy): the spine (SEAT_KEYS_JUDGE_REF, default the spine ref); the
# trunk seat judges at its INDEX (it is the sole writer of the registry, and its enrolling commit must be signable).
# the spine ref: SEAT_KEYS_JUDGE_REF if set (a replica/test knob), else the ONE resolver scripts/spine-ref.sh;
# no resolution is a HALT by name, never a literal fallback (inv #5).
JUDGE_REF_DEFAULT="${SEAT_KEYS_JUDGE_REF:-}"   # resolved on FIRST USE (judge_ref_need), so a verb that never reads the spine never needs the resolver
# the resolver is found BESIDE THIS SCRIPT only (0507 R2): never the work tree's copy (a forged GIT_WORK_TREE cannot supply it)
SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"
judge_ref_need() { [ -n "$JUDGE_REF_DEFAULT" ] && return 0; [ -f "$SPINE_REF_SH" ] || halt "SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2)"; JUDGE_REF_DEFAULT="$(bash "$SPINE_REF_SH" 2>/dev/null)"; [ -n "$JUDGE_REF_DEFAULT" ] || halt "SPINE-REF-UNRESOLVED: $SPINE_REF_SH unfilled and SEAT_KEYS_JUDGE_REF unset (the one spine-ref resolver)"; }
ZERO_SHA=0000000000000000000000000000000000000000

# load_lane_classes : $TMP/lcls (lane<TAB>spine_write class) from the lane-provisioning table (col 4)
load_lane_classes() {
  fetch_file "$MAP_PATH" "$TMP/map"
  awk -F'|' '
    /^\|/ {
      a = $2; c = $5
      gsub(/^[ \t]+|[ \t]+$/, "", a); gsub(/^[ \t]+|[ \t]+$/, "", c)
      if (a == "lane" || a ~ /^-+$/ || a == "") next
      sub(/[ \t]*\(.*\)$/, "", a)
      print a "\t" c
    }' "$TMP/map" > "$TMP/lcls"
  [ -s "$TMP/lcls" ] || halt "no lane classes parsed from $MAP_PATH (lane map unreadable is never a pass)"
}

# relay_from <path> : 0 = relay path, FROM lane in RF_FROM; 1 = not a relay path; 2 = FROM unresolvable (RF_ERR).
#   outbox/<dir>/**  FROM = <dir> (a lane writes its own outbox)
#   inbox/<dir>/**   FROM = the one lane of class ALLOW (the trunk seat writes every inbox)
#   the apply-receipts relay directory  FROM = the one lane of class apply-receipts-only
relay_from() {
  RF_P="$1"; RF_FROM=""; RF_ERR=""
  case "$RF_P" in
    *.sig|*/.gitkeep|*/README.md) return 1 ;;
    _orchestration/relay-outbox/*/*) RF_D="${RF_P#_orchestration/relay-outbox/}"; RF_FROM="${RF_D%%/*}"; return 0 ;;
    _orchestration/relay-inbox/*/*) RF_CLS=ALLOW ;;
    ledger/apply-receipts/relay/*) RF_CLS=apply-receipts-only ;;
    *) return 1 ;;
  esac
  [ -s "$TMP/lcls" ] || load_lane_classes
  RF_N=$(awk -F'\t' -v c="$RF_CLS" '$2 == c { n++ } END { print n + 0 }' "$TMP/lcls")
  if [ "$RF_N" != "1" ]; then RF_ERR="$RF_N lanes of class $RF_CLS in the lane map (need exactly 1 to name the FROM seat of $RF_P)"; return 2; fi
  RF_FROM=$(awk -F'\t' -v c="$RF_CLS" '$2 == c { print $1 }' "$TMP/lcls")
  return 0
}

verb_relay_from() {
  OUT=2
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 1 ] || halt "usage: relay-from <path> [--ref R]"
  relay_from "$1"; RC=$?
  if [ "$RC" = 0 ]; then echo "$RF_FROM"; pass "$1 is a relay path, FROM $RF_FROM"; fi
  if [ "$RC" = 2 ]; then halt "$RF_ERR"; fi
  fail "$1 is not a relay path"
}

# pub_of_signingkey <value> : the "ssh-ed25519 <b64>" behind a git user.signingkey value; empty if unreadable.
#   Forms (git-config user.signingKey, gpg.format=ssh): path to a private key, path to a public key, `key::<pub>`, or a
#   raw key beginning "ssh-" (deprecated form).
pub_of_signingkey() {
  PS_V="$1"
  case "$PS_V" in
    key::*) echo "${PS_V#key::}" | cut -d' ' -f1,2; return 0 ;;
    ssh-*)  echo "$PS_V" | cut -d' ' -f1,2; return 0 ;;
  esac
  [ -f "$PS_V" ] || return 0
  if head -c 4 "$PS_V" | grep -q '^ssh-'; then head -1 "$PS_V" | cut -d' ' -f1,2; return 0; fi
  ssh-keygen -y -f "$PS_V" 2>/dev/null | cut -d' ' -f1,2
}

# signing_key_file <value> : a file ssh-keygen -Y sign -f can use (the value itself if a path, else a temp pub file)
signing_key_file() {
  case "$1" in
    key::*) echo "${1#key::}" > "$TMP/sign.pub"; echo "$TMP/sign.pub" ;;
    ssh-*)  echo "$1" > "$TMP/sign.pub"; echo "$TMP/sign.pub" ;;
    *)      echo "$1" ;;
  esac
}

# registry_row_key <lane> : sets RK (pubkey of the lane's single row) and RKN (row count); needs load_registry
registry_row_key() {
  RKN=$(awk -F'\t' -v l="$1" '$1 == l { n++ } END { print n + 0 }' "$TMP/rows")
  RK=$(awk -F'\t' -v l="$1" '$1 == l { print $4; exit }' "$TMP/rows")
}

# vr_check <file> <from-lane> : verify-relay logic as a function; 0 = signed by <from-lane>; 1 = refused (VR_MSG).
#   Needs $TMP/al + $TMP/rev from vc_prepare. Same named reasons as verify-relay.
vr_check() {
  VR_F="$1"; VR_L="$2"
  [ -f "$VR_F.sig" ] || { VR_MSG="unsigned: $VR_F.sig missing"; return 1; }
  if ssh-keygen -Y verify -f "$TMP/al" -I "$VR_L" -n relay -s "$VR_F.sig" -r "$TMP/rev" < "$VR_F" > /dev/null 2>&1; then
    VR_MSG="$VR_F signed by $VR_L (namespace relay)"; return 0
  fi
  emit_allowed_plus_revoked "$TMP/alr"
  VR_WHOR=$(ssh-keygen -Y find-principals -f "$TMP/alr" -s "$VR_F.sig" 2>/dev/null | tr '\n' ',')
  if echo ",$VR_WHOR" | grep -q "REVOKED-KEY,"; then VR_MSG="revoked: key that signed $VR_F is in the revocation list"; return 1; fi
  VR_WHO=$(ssh-keygen -Y find-principals -f "$TMP/al" -s "$VR_F.sig" 2>/dev/null | tr '\n' ',' | sed 's/,$//')
  if [ -z "$VR_WHO" ]; then VR_MSG="unknown-key: signature on $VR_F is not from any registered key"; return 1; fi
  if ! echo ",$VR_WHO," | grep -q ",$VR_L,"; then VR_MSG="wrong-lane: $VR_F signed by '$VR_WHO', not '$VR_L'"; return 1; fi
  VR_MSG="bad-signature: $VR_F does not verify for $VR_L (tampered bytes or wrong namespace)"; return 1
}

# verb_setup_signing <lane> [--key <private-key>] : configure THIS worktree to sign every commit with its lane's key.
# Lane binding: <lane> must equal the lane THIS worktree resolves to (its own scripts/resolve-lane.sh over its own _boot
# stamp). A worktree stamped for one lane is never configured to sign as another; the refusal names both, and nothing
# is written. The binding runs after the registry-row check and before the first config write.
verb_setup_signing() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 1 ] || halt "usage: setup-signing <lane> [--key <private-key-path>]"
  SS_BIND=1   # always on for the verb; only fixture-enroll's in-process call (below) runs the apply unbound
  setup_signing_apply "$1"
}

# setup_signing_apply <lane> : the body of setup-signing. Reads KEY, TOP, REF, REGFILE, REG_PATH, REV_PATH, SS_BIND.
setup_signing_apply() {
  LANE="$1"
  [ -n "$TOP" ] || halt "not inside a git work tree"
  [ -n "$KEY" ] || KEY="${SEAT_KEYS_HOME:-$HOME/.config/{{SEAT_KEYS_DIR_NAME}}}/$LANE"
  [ -f "$KEY" ] || halt "private key $KEY not found (keygen $LANE first; the key lives outside every worktree)"
  KD=$(cd "$(dirname "$KEY")" && pwd) || halt "cannot resolve the key directory"
  if git -C "$KD" rev-parse --is-inside-work-tree > /dev/null 2>&1; then halt "refusing: $KEY is inside a git worktree; keys live outside every worktree"; fi
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  registry_row_key "$LANE"
  [ "$RKN" = "1" ] || halt "lane '$LANE' has $RKN registry rows (need exactly 1; enroll the lane before it can sign)"
  if [ "$SS_BIND" != 0 ]; then
    SS_RL="$TOP/scripts/resolve-lane.sh"
    [ -f "$SS_RL" ] || halt "lane-unresolved: $SS_RL not found; setup-signing binds <lane> to the lane this worktree resolves"
    SS_OUT=$(cd "$TOP" && bash "$SS_RL" 2> "$TMP/rl.err") || halt "lane-unresolved: resolve-lane.sh in $TOP exit $?: $(tail -1 "$TMP/rl.err")"
    SS_WL=$(printf '%s\n' "$SS_OUT" | awk '{ for (i = 1; i <= NF; i++) if (index($i, "lane=") == 1) { print substr($i, 6); exit } }')
    [ -n "$SS_WL" ] || halt "lane-unresolved: resolve-lane.sh in $TOP printed no lane= field"
    [ "$SS_WL" = "$LANE" ] || halt "lane-mismatch: asked to sign as '$LANE', but worktree $TOP resolves to lane '$SS_WL'; nothing written"
  fi
  MINE=$(pub_of_signingkey "$KEY")
  [ -n "$MINE" ] || halt "cannot read the public half of $KEY (ssh-keygen -y failed)"
  [ "$MINE" = "$RK" ] || halt "key-mismatch: $KEY is not lane '$LANE''s registered key (a lane signs only with its own key)"
  if grep -qxF "$MINE" "$TMP/revoked"; then halt "revoked: $KEY is on the revocation list"; fi
  echo probe > "$TMP/trial"
  ssh-keygen -Y sign -n relay -f "$KEY" "$TMP/trial" > /dev/null 2>"$TMP/trial.err" || halt "trial sign failed: $(head -1 "$TMP/trial.err")"
  git config extensions.worktreeConfig true || halt "cannot enable extensions.worktreeConfig"
  if [ "$(git config --local --get core.bare)" = true ] || git config --local --get core.worktree > /dev/null 2>&1; then
    halt "core.bare=true or core.worktree is set in the shared config; git-worktree(1) says move them to config.worktree before worktree-scoped config is safe"
  fi
  git config --worktree gpg.format ssh && git config --worktree user.signingkey "$KEY" && git config --worktree commit.gpgsign true || halt "git config --worktree failed"
  R1=$(git config --worktree --get gpg.format); R2=$(git config --worktree --get user.signingkey); R3=$(git config --worktree --type=bool --get commit.gpgsign)
  [ "$R1" = ssh ] && [ "$R2" = "$KEY" ] && [ "$R3" = true ] || halt "readback mismatch: gpg.format='$R1' user.signingkey='$R2' commit.gpgsign='$R3'"
  pass "worktree $TOP signs every commit as $LANE (gpg.format=ssh, user.signingkey=$KEY, commit.gpgsign=true; config.worktree)"
}

# replay_selector : 0 = this hook-precommit runs inside the spine host's per-commit replay of a pushed commit, so it is
#   VERIFY-ONLY. The selector is where the EXECUTING repository's git dir sits, which no env var or config key moves:
#   the git dir git is operating on must be exactly <W>/.git with <W> the work tree, <W> named spine-replay.*, and <W>'s
#   parent a BARE repository. Only scripts/spine-receive.sh makes that shape, inside the spine account's bare repo (a
#   mode-700 home, T0). Forged env (GIT_WORK_TREE, SEAT_KEYS_*) or config (core.bare, core.worktree) in a seat worktree
#   moves the work tree away from the git dir's parent or leaves the git dir under .git/worktrees/, so it still signs.
#   Forging GIT_DIR too points git at another repository, so that commit is not made in the seat's worktree at all.
#   Sets VO_BARE.
replay_selector() {
  VO_BARE=""
  GD=$(git rev-parse --absolute-git-dir 2>/dev/null) || return 1
  [ -n "$GD" ] && [ "$GD" = "$TOP/.git" ] || return 1
  case "$(basename "$TOP")" in spine-replay.*) ;; *) return 1 ;; esac
  VB=$(dirname "$TOP")
  [ "$(cd "$VB" 2>/dev/null && env -u GIT_DIR -u GIT_WORK_TREE -u GIT_COMMON_DIR git rev-parse --is-bare-repository 2>/dev/null)" = true ] || return 1
  VO_BARE="$VB"; return 0
}

# hook_verify_only : the K3 half the server can run (0489 R2/R3). No signing call, no signing-config demand: every
#   staged relay file must already carry a staged .sig that verifies as its FROM seat, judged at $REF. Exits.
hook_verify_only() {
  vc_prepare
  git diff --cached --name-only --diff-filter=ACMR > "$TMP/staged" 2>/dev/null || fail "cannot list the staged paths"
  NREL=0
  while IFS= read -r P; do
    [ -n "$P" ] || continue
    relay_from "$P"; RC=$?
    if [ "$RC" = 1 ]; then continue; fi
    if [ "$RC" = 2 ]; then fail "relay-from-unresolvable: $RF_ERR"; fi
    NREL=$((NREL + 1)); FROM="$RF_FROM"
    git show ":$P" > "$TMP/v.f" 2>/dev/null || fail "cannot read staged $P"
    git show ":$P.sig" > "$TMP/v.f.sig" 2>/dev/null || fail "relay-unsigned: $P has no $P.sig in the commit (FROM seat is $FROM)"
    if ! vr_check "$TMP/v.f" "$FROM"; then fail "relay-refused: $P (FROM $FROM) :: ${VR_MSG//$TMP\/v.f/$P}"; fi
  done < "$TMP/staged"
  pass "lane $LANE (replay inside bare $VO_BARE, judged at $REF): $NREL relay file(s) verified, none signed"
}

# verb_hook_precommit <lane> <spine_write> : the pre-commit K gate. K3(a): the commit WILL be signed with this lane's
# registered key. K3(b): every staged relay file carries a signature in namespace relay (own relay: signed here from the
# staged bytes, the .sig staged beside it; another seat's relay: its signature must already be staged and verify).
verb_hook_precommit() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 2 ] || halt "usage: hook-precommit <lane> <spine_write> [--ref R]"
  LANE="$1"; SW="$2"
  [ -n "$TOP" ] || halt "not inside a git work tree"
  [ -n "$LANE" ] || halt "lane is empty (the hook passes the resolved lane; an unresolved lane is never a pass)"
  VO=0; if replay_selector; then VO=1; VERB="hook-precommit VERIFY-ONLY"; fi
  if [ "$VO" = 1 ]; then [ -n "$REF" ] || { judge_ref_need; REF="$JUDGE_REF_DEFAULT"; }   # 0489 R6: principal inputs at the spine's current main
  elif [ -z "$REF" ]; then if [ "$SW" = ALLOW ]; then REF=INDEX; else judge_ref_need; REF="$JUDGE_REF_DEFAULT"; fi; fi
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  registry_row_key "$LANE"
  [ "$RKN" = "1" ] || fail "no-registry-row: lane '$LANE' has $RKN registry rows at $REF (enroll it first; zero rows refuses every commit by design)"
  if grep -qxF "$RK" "$TMP/revoked"; then fail "revoked: lane '$LANE''s registered key is on the revocation list at $REF"; fi
  [ "$VO" = 1 ] && hook_verify_only
  GF=$(git config --get gpg.format); CG=$(git config --type=bool --get commit.gpgsign 2>/dev/null); SK=$(git config --get user.signingkey)
  if [ "$GF" != ssh ] || [ "$CG" != true ] || [ -z "$SK" ]; then
    fail "signing-not-configured: gpg.format='${GF:-unset}' commit.gpgsign='${CG:-unset}' user.signingkey='${SK:-unset}' (run: scripts/seat-keys.sh setup-signing $LANE)"
  fi
  MINE=$(pub_of_signingkey "$SK")
  [ -n "$MINE" ] || fail "signing-key-unreadable: cannot read the public half of user.signingkey '$SK'"
  [ "$MINE" = "$RK" ] || fail "signing-key-mismatch: user.signingkey is not lane '$LANE''s registered key at $REF (a lane signs only with its own key)"
  vc_prepare
  git diff --cached --name-only --diff-filter=ACMR > "$TMP/staged" 2>/dev/null
  NREL=0
  while IFS= read -r P; do
    [ -n "$P" ] || continue
    relay_from "$P"; RC=$?
    if [ "$RC" = 1 ]; then continue; fi
    if [ "$RC" = 2 ]; then fail "relay-from-unresolvable: $RF_ERR"; fi
    NREL=$((NREL + 1)); FROM="$RF_FROM"
    if [ "$FROM" = "$LANE" ]; then
      git show ":$P" > "$TMP/rel.f" 2>/dev/null || fail "cannot read staged $P"
      rm -f "$TMP/rel.f.sig"
      SF=$(signing_key_file "$SK")
      ssh-keygen -Y sign -n relay -f "$SF" "$TMP/rel.f" > /dev/null 2>"$TMP/rel.err" || fail "relay-sign-failed: $P :: $(head -1 "$TMP/rel.err")"
      mkdir -p "$TOP/$(dirname "$P")" && cp "$TMP/rel.f.sig" "$TOP/$P.sig" && git -C "$TOP" add -- "$P.sig" || fail "relay-sign-failed: cannot stage $P.sig"
    fi
    git show ":$P" > "$TMP/v.f" 2>/dev/null || fail "cannot read staged $P"
    git show ":$P.sig" > "$TMP/v.f.sig" 2>/dev/null || fail "relay-unsigned: $P has no staged $P.sig (relay files carry a detached signature; FROM seat is $FROM)"
    if ! vr_check "$TMP/v.f" "$FROM"; then fail "relay-refused: $P (FROM $FROM) :: ${VR_MSG//$TMP\/v.f/$P}"; fi
  done < "$TMP/staged"
  pass "lane $LANE commit will be signed with its registered key; $NREL staged relay file(s) signed and verified"
}

# verb_verify_range <lane> <rev-args...> [--ref R] : every commit in the range is signed by <lane>'s key, judged at R.
verb_verify_range() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -ge 2 ] || halt "usage: verify-range <lane> <rev-args...> [--ref R]"
  LANE="$1"; shift
  if [ -z "$REF" ]; then judge_ref_need; REF="$JUDGE_REF_DEFAULT"; fi
  REVS=$(git rev-list "$@" 2>"$TMP/rl.err") || halt "bad range '$*': $(head -1 "$TMP/rl.err")"
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  vc_prepare
  N=0
  for SHA in $REVS; do
    vc_check "$LANE" "$SHA" || fail "$VC_MSG (commit $((N + 1)) of range '$*', judged at $REF)"
    N=$((N + 1))
  done
  pass "$N commit(s) in range '$*' signed by $LANE, judged at $REF"
}

# verb_verify_push : the pre-push K gate. stdin = git's `<local ref> <local sha> <remote ref> <remote sha>` lines.
# A push to a lane's branch carries only commits signed by that lane's key (commits already on the spine are
# excluded); a push to the trunk carries only commits signed by the trunk seat's key.
# Judging ref: a LANE branch is judged at the spine (JUDGE_REF_DEFAULT: registry, revocation list and lane map read
# there, never at the lane's own tip, so a lane cannot vouch for itself and a tip that predates the registry is still
# judgeable); the TRUNK is judged at its pushed tip (it is the registry's sole writer, and its enrolling push must pass).
# Range: `<tip> --not <remote tip> <spine>` with ONE --not (a second --not would toggle the spine back to positive).
verb_verify_push() {
  [ -n "$TOP" ] || halt "not inside a git work tree"
  NP=0; NS=0
  HAVE_J=0; judge_ref_need; git rev-parse --verify -q "$JUDGE_REF_DEFAULT" > /dev/null && HAVE_J=1
  while read -r LREF LSHA RREF RSHA; do
    [ -n "$LREF" ] || continue
    if [ "$LSHA" = "$ZERO_SHA" ]; then NS=$((NS + 1)); continue; fi
    case "$RREF" in refs/heads/*) BR="${RREF#refs/heads/}" ;; *) NS=$((NS + 1)); continue ;; esac
    # Which lane, and whether it is the trunk: read at the spine when it resolves, else at the pushed tip.
    if [ "$HAVE_J" = 1 ]; then REF="$JUDGE_REF_DEFAULT"; else REF="$LSHA"; fi
    REGFILE=""
    load_lanes
    PL=$(awk -F'\t' -v b="$BR" '$2 == b { print $1; exit }' "$TMP/lanes")
    if [ -z "$PL" ]; then echo "SEAT-KEYS: verify-push SKIP-UNMAPPED branch '$BR' is not a lane branch in the lane map at $REF (not gated)"; NS=$((NS + 1)); continue; fi
    load_lane_classes
    TL=$(awk -F'\t' '$2 == "ALLOW" { print $1; exit }' "$TMP/lcls")
    TRUNK=$(awk -F'\t' -v l="$TL" '$1 == l { print $2; exit }' "$TMP/lanes")
    if [ "$BR" = "$TRUNK" ]; then
      REF="$LSHA"; EXC=""
    else
      [ "$HAVE_J" = 1 ] || halt "push to lane branch $BR: judging ref $JUDGE_REF_DEFAULT does not resolve (a lane is judged at the spine; never a pass)"
      REF="$JUDGE_REF_DEFAULT"; EXC="$JUDGE_REF_DEFAULT"
    fi
    if [ "$RSHA" != "$ZERO_SHA" ]; then EXC="$RSHA $EXC"; fi
    REVS=$(git rev-list "$LSHA" --not $EXC 2>"$TMP/rl.err") || halt "bad push range for $BR: $(head -1 "$TMP/rl.err")"
    load_registry
    [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
    vc_prepare
    for SHA in $REVS; do
      vc_check "$PL" "$SHA" || fail "push to $BR refused: $VC_MSG (lane $PL, judged at $REF)"
      NP=$((NP + 1))
    done
  done
  pass "$NP pushed commit(s) signed by their lane's key; $NS ref(s) not gated (deleted, non-branch, or unmapped branch; each named above if unmapped)"
}

# --- L: the login tie --------------------------------------------------------------------------------------------
# derive_login : LG_ACCT (account of the EFFECTIVE uid), LG_EUID, LG_RUID, LG_HOST from the process credential only.
#   Never $USER / $LOGNAME / $HOME / argv. id(1) on this host: `-u` effective uid, `-un` its account name, `-ru` real uid;
#   an unmapped uid prints the NUMBER in place of the name (man id, -n), so an all-digit name is treated as unresolved.
derive_login() {
  LG_EUID=$(id -u 2>"$TMP/id.err") || halt "login unresolvable: id -u failed: $(head -1 "$TMP/id.err")"
  case "$LG_EUID" in ''|*[!0-9]*) halt "login unresolvable: id -u printed '$LG_EUID', not a uid" ;; esac
  LG_ACCT=$(id -un 2>"$TMP/id.err") || halt "login unresolvable: id -un failed: $(head -1 "$TMP/id.err")"
  if [ -z "$LG_ACCT" ]; then halt "login unresolvable: id -un printed nothing for uid $LG_EUID"; fi
  case "$LG_ACCT" in *[!0-9]*) : ;; *) halt "login unresolvable: uid $LG_EUID has no account name (id -un printed the number)" ;; esac
  case "$LG_ACCT" in *[[:space:]]*) halt "login unresolvable: account name '$LG_ACCT' carries whitespace" ;; esac
  LG_RUID=$(id -ru 2>"$TMP/id.err") || halt "login unresolvable: id -ru failed: $(head -1 "$TMP/id.err")"
  case "$LG_RUID" in ''|*[!0-9]*) halt "login unresolvable: id -ru printed '$LG_RUID', not a uid" ;; esac
  LG_HOST=$(hostname -s 2>"$TMP/id.err") || halt "login unresolvable: hostname -s failed: $(head -1 "$TMP/id.err")"
  [ -n "$LG_HOST" ] || halt "login unresolvable: hostname -s printed nothing"
}

verb_login_line() {
  OUT=2
  derive_login
  echo "- recorded-under-login: $LG_ACCT (uid $LG_EUID) @ $LG_HOST"
  pass "recorded $LG_ACCT (uid $LG_EUID) @ $LG_HOST"
}

verb_login_tie() {
  parse_ref_opts "$@"
  derive_login
  if [ "$LG_EUID" = 0 ]; then fail "elevated-uid0: effective uid is 0; the pen is never recorded under root"; fi
  if [ "${SUDO_USER+x}" = x ]; then fail "elevated-sudo-user: SUDO_USER is set; the pen is never recorded through sudo"; fi
  if [ "$LG_EUID" != "$LG_RUID" ]; then fail "elevated-euid-ne-ruid: effective uid $LG_EUID differs from real uid $LG_RUID"; fi
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  NA=$(awk -F'\t' '$7 == "apex" { n++ } END { print n + 0 }' "$TMP/rows")
  if [ "$NA" = "0" ]; then fail "no-apex-row: the registry has 0 apex rows (need exactly 1)"; fi
  if [ "$NA" != "1" ]; then fail "multiple-apex-rows: the registry has $NA apex rows (need exactly 1)"; fi
  AL=$(awk -F'\t' '$7 == "apex" { print $5; exit }' "$TMP/rows")
  if [ "$LG_ACCT" != "$AL" ]; then fail "login-mismatch: derived account '$LG_ACCT' is not the apex row's login '$AL'"; fi
  pass "derived login $LG_ACCT (uid $LG_EUID) @ $LG_HOST matches the apex row"
}

# --- fixture-enroll : scripted enrollment for a throwaway test repo (declared test substrate), NOT lane enrollment -----
# Admission is (a)-(c) or `SEAT-KEYS: fixture-enroll HALT <reason>` rc 2:
#   (a) the repo's `origin` is absent or is not a network remote (the non-lane predicate the post-commit hook uses, mirrored);
#   (b) it writes only the in-repo registry + revoked list (both resolved under <repo>); the one thing outside <repo> is the key;
#   (c) SEAT_KEYS_HOME is set, outside every git worktree (keygen refuses), and is not the default real key directory;
#   (d) the registry it leaves begins with `# fixture`: an inherited one is REPLACED (fresh registry + revoked), never appended to.
# Once admitted: keygen under SEAT_KEYS_HOME, one row `lane branch fixture pubkey login host apex|-` (login/host from the
# process credential on the apex row, `-` elsewhere), the repo's worktree signing config (setup-signing). Seed signing for
# relays: `sign-relay <file> --key $SEAT_KEYS_HOME/<lane>`. The branch column is the lane-map branch in <repo>, else <repo>'s current branch.
verb_fixture_enroll() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 2 ] || halt "usage: fixture-enroll <repo> <lane> [--apex]"
  FE_REPO="$1"; FE_LANE="$2"
  [ -d "$FE_REPO" ] || halt "repo $FE_REPO is not a directory"
  FE_TOP=$(git -C "$FE_REPO" rev-parse --show-toplevel 2>/dev/null) || halt "$FE_REPO is not a git work tree"
  FE_TOP=$(cd "$FE_TOP" && pwd -P)
  # (a) non-lane predicate: the same literal the post-commit hook carries
  if _fe_url="$(git -C "$FE_TOP" remote get-url origin 2>/dev/null)" && [[ "$_fe_url" =~ ^(https?://|ssh://|git@) ]]; then
    halt "refusing: origin '$_fe_url' is a network remote, so this is a lane, not a fixture; the live registry is written only by foundation's enrollment commit on the spine (one row per commit), never by a fixture verb"
  fi
  # (c) key home: set, not the default real directory (keygen's own refusal covers 'inside a worktree')
  [ -n "${SEAT_KEYS_HOME:-}" ] || halt "refusing: SEAT_KEYS_HOME is unset; a fixture never writes the real key directory"
  FE_HOME="${SEAT_KEYS_HOME%/}"; FE_DEF="${HOME%/}/.config/{{SEAT_KEYS_DIR_NAME}}"
  FE_HOMEP="$FE_HOME"; [ -d "$FE_HOME" ] && FE_HOMEP=$(cd "$FE_HOME" && pwd -P)
  FE_DEFP="$FE_DEF"; [ -d "$FE_DEF" ] && FE_DEFP=$(cd "$FE_DEF" && pwd -P)
  if [ "$FE_HOME" = "$FE_DEF" ] || [ "$FE_HOMEP" = "$FE_DEFP" ]; then halt "refusing: SEAT_KEYS_HOME is the default real key directory $FE_DEF; a fixture never writes it"; fi
  # (b) registry + revoked paths resolve under <repo>
  FE_REG="$REG_PATH"; FE_REV="$REV_PATH"
  case "$FE_REG" in "$FE_TOP"/*) FE_REG="${FE_REG#"$FE_TOP"/}" ;; esac
  case "$FE_REV" in "$FE_TOP"/*) FE_REV="${FE_REV#"$FE_TOP"/}" ;; esac
  case "$FE_REG$FE_REV" in /*|*..*) halt "refusing: registry/revoked path must resolve under $FE_TOP (got '$REG_PATH' / '$REV_PATH')" ;; esac
  case "$FE_LANE" in ''|*[[:space:]/]*) halt "lane id '$FE_LANE' is empty or carries whitespace or a slash" ;; esac
  # (d) (ruling 0484 R2(d), as re-cut by ruling 0485 R1) once admitted by (a)-(c), a registry that does not begin with
  # `# fixture` is inherited (e.g. a clone of the spine): it and the revoked file are REPLACED by fresh fixture files,
  # never appended to and never a HALT. A registry that already begins with `# fixture` (a second lane in one fixture)
  # is kept and gains its row under that header. The registry left behind ALWAYS begins with `# fixture`.
  FE_RF="$FE_TOP/$FE_REG"
  FE_FRESH=1
  if [ -f "$FE_RF" ] && [ "$(head -1 "$FE_RF")" = "# fixture" ]; then
    FE_FRESH=0
    if awk -F'\t' -v l="$FE_LANE" '!/^[[:space:]]*#/ && $1 == l { f = 1 } END { exit !f }' "$FE_RF"; then halt "lane '$FE_LANE' already has a row in $FE_REG"; fi
  fi
  derive_login
  # branch column
  FE_BR=""
  if [ -f "$FE_TOP/$MAP_PATH" ]; then
    FE_BR=$(awk -F'|' -v l="$FE_LANE" '/^\|/ { a=$2; b=$3; gsub(/^[ \t]+|[ \t]+$/,"",a); gsub(/^[ \t]+|[ \t]+$/,"",b); sub(/[ \t]*\(.*\)$/,"",a); if (a==l) print b }' "$FE_TOP/$MAP_PATH" | head -1)
  fi
  [ -n "$FE_BR" ] || FE_BR=$(git -C "$FE_TOP" symbolic-ref --short -q HEAD 2>/dev/null)
  [ -n "$FE_BR" ] || halt "cannot name a branch for lane '$FE_LANE' (no lane-map row, detached HEAD)"
  # key (keygen refuses a path inside a worktree and an existing key)
  FE_SELF="${BASH_SOURCE[0]}"
  SEAT_KEYS_HOME="$FE_HOME" bash "$FE_SELF" keygen "$FE_LANE" > "$TMP/fe.kg" 2>&1 || halt "keygen failed: $(tail -1 "$TMP/fe.kg")"
  FE_PUB=$(cut -d' ' -f1,2 "$FE_HOME/$FE_LANE.pub") || halt "cannot read the generated public key"
  FE_TABROW() { printf '%s\t%s\tfixture\t%s\t%s\t%s\t%s\n' "$FE_LANE" "$FE_BR" "$FE_PUB" "$1" "$2" "$3"; }
  mkdir -p "$(dirname "$FE_RF")"
  mkdir -p "$(dirname "$FE_TOP/$FE_REV")"
  if [ "$FE_FRESH" = 1 ]; then
    echo "# fixture" > "$FE_RF" || halt "cannot write $FE_REG"
    echo "# revoked fixture" > "$FE_TOP/$FE_REV" || halt "cannot write $FE_REV"
  elif [ ! -f "$FE_TOP/$FE_REV" ]; then
    echo "# revoked fixture" > "$FE_TOP/$FE_REV" || halt "cannot write $FE_REV"
  fi
  if [ "$APEX" = 1 ]; then FE_TABROW "$LG_ACCT" "$LG_HOST" apex >> "$FE_RF"; else FE_TABROW - - - >> "$FE_RF"; fi
  # the repo signs every commit as this lane (reads the registry just written)
  #   In-process and unbound: a fixture enrolls lanes that its own stamp does not name (a second lane in one fixture),
  #   which the lane-bound verb refuses. Admission (a)-(d) above already proved this is a fixture, not a lane.
  ( cd "$FE_TOP" || exit 2
    TOP="$FE_TOP"; REG_PATH="$FE_REG"; REV_PATH="$FE_REV"; KEY="$FE_HOME/$FE_LANE"; REF=""; REGFILE=""; SS_BIND=0
    TMP="$TMP/fe-ss"; mkdir -p "$TMP" || exit 2
    setup_signing_apply "$FE_LANE" ) > "$TMP/fe.ss" 2>&1 || halt "setup-signing failed: $(tail -1 "$TMP/fe.ss")"
  pass "fixture lane $FE_LANE enrolled in $FE_TOP/$FE_REG (header '# fixture'$( [ "$APEX" = 1 ] && echo ', apex row')); key $FE_HOME/$FE_LANE; worktree signs as $FE_LANE"
}

# verb_confirm_lanes [--ref R] : the per-lane confirmation record of the K4 install order (the installer arms K4 only
# when this passes). Every writing lane in the lane map at R (default HEAD) must have exactly one registry row at R,
# not revoked, AND a setup-signing readback in the worktree that has its branch checked out (`git worktree list`):
# config.worktree gpg.format=ssh, commit.gpgsign=true, and user.signingkey whose public half IS the lane's row key.
# One line per lane (CONFIRMED | UNCONFIRMED <lane> <step> <reason>); rc 0 only when every lane is confirmed.
verb_confirm_lanes() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 0 ] || halt "usage: confirm-lanes [--ref R]"
  [ -n "$TOP" ] || halt "not inside a git work tree"
  [ -n "$REF" ] || REF=HEAD
  load_lanes
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  git worktree list --porcelain > "$TMP/wt" 2>/dev/null || halt "git worktree list failed (the readback needs every worktree)"
  awk '/^worktree /{ w = substr($0, 10) } /^branch /{ b = $2; sub(/^refs\/heads\//, "", b); print b "\t" w }' "$TMP/wt" > "$TMP/wtb"
  CL_N=0; CL_U=0
  while IFS="$(printf '\t')" read -r CL_L CL_B; do
    [ -n "$CL_L" ] || continue
    CL_N=$((CL_N + 1))
    registry_row_key "$CL_L"
    if [ "$RKN" != "1" ]; then
      echo "SEAT-KEYS: confirm-lanes UNCONFIRMED $CL_L registry-row: $RKN rows at $REF (need exactly 1; keygen + the row commit)"; CL_U=$((CL_U + 1)); continue
    fi
    if grep -qxF "$RK" "$TMP/revoked"; then
      echo "SEAT-KEYS: confirm-lanes UNCONFIRMED $CL_L registry-row: the row key is on the revocation list at $REF"; CL_U=$((CL_U + 1)); continue
    fi
    CL_W=$(awk -F'\t' -v b="$CL_B" '$1 == b { print $2; exit }' "$TMP/wtb")
    if [ -z "$CL_W" ]; then
      echo "SEAT-KEYS: confirm-lanes UNCONFIRMED $CL_L setup-signing: no worktree has branch '$CL_B' checked out (git worktree list)"; CL_U=$((CL_U + 1)); continue
    fi
    CL_GF=$(git -C "$CL_W" config --worktree --get gpg.format < /dev/null 2>/dev/null)
    CL_CG=$(git -C "$CL_W" config --worktree --type=bool --get commit.gpgsign < /dev/null 2>/dev/null)
    CL_SK=$(git -C "$CL_W" config --worktree --get user.signingkey < /dev/null 2>/dev/null)
    if [ "$CL_GF" != ssh ] || [ "$CL_CG" != true ] || [ -z "$CL_SK" ]; then
      echo "SEAT-KEYS: confirm-lanes UNCONFIRMED $CL_L setup-signing: $CL_W reads gpg.format='${CL_GF:-unset}' commit.gpgsign='${CL_CG:-unset}' user.signingkey='${CL_SK:-unset}' (run: scripts/seat-keys.sh setup-signing $CL_L there)"; CL_U=$((CL_U + 1)); continue
    fi
    CL_MINE=$(pub_of_signingkey "$CL_SK" < /dev/null)
    if [ "$CL_MINE" != "$RK" ]; then
      echo "SEAT-KEYS: confirm-lanes UNCONFIRMED $CL_L setup-signing: $CL_W user.signingkey '$CL_SK' is $( [ -n "$CL_MINE" ] && echo "not the lane's row key at $REF" || echo "unreadable" )"; CL_U=$((CL_U + 1)); continue
    fi
    echo "SEAT-KEYS: confirm-lanes CONFIRMED $CL_L row@$REF + readback@$CL_W"
  done < "$TMP/lanes"
  [ "$CL_N" -gt 0 ] || halt "no writing lanes read from $MAP_PATH at $REF"
  if [ "$CL_U" -eq 0 ]; then pass "$CL_N of $CL_N writing lanes confirmed (registry row at $REF + setup-signing readback)"; fi
  fail "$CL_U of $CL_N writing lanes unconfirmed (each named above)"
}

# verb_adopt_candidate <candidate-ref> : the sync adopt under K4. Run inside the lane's worktree, on the lane's branch.
# C (the trunk's sync candidate) is verified first, judged at the spine (JUDGE_REF_DEFAULT), never at the lane's copy:
#   C sits at a ref named foundation/<lane>-sync-candidate-* ; C is signed by the trunk seat's registered key;
#   C has two parents, the first = this branch's tip, the second reachable from the spine; and C's tree differs from
#   the clean merge of its parents under _boot/ only.
# Then A is made with `commit-tree -S` (this worktree's signing key): tree(A)=tree(C), parents(A)=parents(C), C's message
# plus one trailer naming C. A must verify as this lane; the branch then advances to A by fast-forward, never to C.
verb_adopt_candidate() {
  parse_ref_opts "$@"
  set -- $POS
  [ $# -eq 1 ] || halt "usage: adopt-candidate <candidate-ref>"
  [ -n "$TOP" ] || halt "not inside a git work tree"
  AC_C=$(git rev-parse --verify -q "$1^{commit}") || halt "candidate '$1' is not a commit"
  AC_BR=$(git symbolic-ref -q --short HEAD) || halt "detached HEAD; adopt runs on the lane's branch"
  judge_ref_need; git rev-parse --verify -q "$JUDGE_REF_DEFAULT" > /dev/null || halt "judging ref $JUDGE_REF_DEFAULT does not resolve"
  REF="$JUDGE_REF_DEFAULT"; REGFILE=""
  load_lanes
  load_lane_classes
  AC_L=$(awk -F'\t' -v b="$AC_BR" '$2 == b { print $1; exit }' "$TMP/lanes")
  [ -n "$AC_L" ] || fail "branch '$AC_BR' is not a lane branch in the lane map at $REF"
  AC_TL=$(awk -F'\t' '$2 == "ALLOW" { print $1; exit }' "$TMP/lcls")
  [ -n "$AC_TL" ] || halt "no trunk (ALLOW) lane in the lane map at $REF"
  [ "$AC_L" != "$AC_TL" ] || fail "the trunk does not adopt a sync candidate (branch '$AC_BR')"
  # (1) a sync-candidate ref of THIS lane points at C
  AC_REFN=$(git for-each-ref --points-at "$AC_C" --format='%(refname)' refs/heads/foundation refs/remotes | grep -E "/foundation/$AC_L-sync-candidate-[^/]+$" | head -1)
  [ -n "$AC_REFN" ] || fail "not-a-candidate: no ref foundation/$AC_L-sync-candidate-* points at $AC_C"
  # (2) C is trunk-signed
  load_registry
  [ -s "$TMP/bad" ] && halt "malformed registry row: $(head -1 "$TMP/bad")"
  vc_prepare
  vc_check "$AC_TL" "$AC_C" || fail "candidate-not-trunk-signed: $VC_MSG"
  # (3) parents: exactly two; the first is this branch's tip; the second is reachable from the spine
  AC_P=$(git rev-list --parents -n 1 "$AC_C")
  set -- $AC_P
  [ $# -eq 3 ] || fail "candidate-shape: $AC_C has $(($# - 1)) parent(s), a sync candidate has exactly 2"
  AC_P1="$2"; AC_P2="$3"
  AC_TIP=$(git rev-parse "refs/heads/$AC_BR")
  [ "$AC_P1" = "$AC_TIP" ] || fail "stale-candidate: $AC_C's first parent $AC_P1 is not the tip of $AC_BR ($AC_TIP); foundation re-cuts"
  git merge-base --is-ancestor "$AC_P2" "$JUDGE_REF_DEFAULT" || fail "candidate-shape: $AC_C's second parent $AC_P2 is not reachable from $JUDGE_REF_DEFAULT"
  # (4) the tree is the clean merge of the parents, except under _boot/. Renames are OFF: with rename detection a move of a
  #   file from outside the boot dir into it lists only the destination, which the boot-dir filter drops, so a candidate
  #   could remove a path outside the boot dir unseen. --no-renames lists both sides (a delete and an add), and overrides
  #   any diff.renames config.
  AC_MT=$(git merge-tree --write-tree "$AC_P1" "$AC_P2" 2>/dev/null) || fail "candidate-shape: the parents of $AC_C do not merge cleanly (git merge-tree)"
  AC_MT=$(printf '%s\n' "$AC_MT" | head -1)
  AC_T=$(git rev-parse "$AC_C^{tree}")
  AC_OUT=$(git diff --no-renames --name-only "$AC_MT" "$AC_T" | grep -v '^_boot/' | head -3)
  [ -z "$AC_OUT" ] || fail "candidate-tree: $AC_C differs from the clean merge outside _boot/ (first: $(printf '%s' "$AC_OUT" | tr '\n' ' '))"
  # signing: this worktree signs as this lane
  AC_SK=$(git config --get user.signingkey)
  [ "$(git config --get gpg.format)" = ssh ] && [ -n "$AC_SK" ] || fail "signing-not-configured: run scripts/seat-keys.sh setup-signing $AC_L"
  registry_row_key "$AC_L"
  [ "$RKN" = "1" ] || fail "no-registry-row: lane '$AC_L' has $RKN registry rows at $REF"
  [ "$(pub_of_signingkey "$AC_SK")" = "$RK" ] || fail "signing-key-mismatch: user.signingkey is not lane '$AC_L''s registered key at $REF"
  # make A
  git log -1 --format=%B "$AC_C" > "$TMP/ac.msg" || halt "cannot read $AC_C's message"
  git interpret-trailers --in-place --trailer "Adopted-Sync-Candidate: $AC_C" "$TMP/ac.msg" || halt "cannot add the trailer"
  AC_A=$(git commit-tree -S "$AC_T" -p "$AC_P1" -p "$AC_P2" -F "$TMP/ac.msg" 2>"$TMP/ac.err") || fail "commit-tree failed: $(head -1 "$TMP/ac.err")"
  # A readback before the branch moves
  [ "$(git rev-parse "$AC_A^{tree}")" = "$AC_T" ] || halt "readback: tree(A) != tree(C)"
  [ "$(git rev-list --parents -n 1 "$AC_A" | cut -d' ' -f2-)" = "$AC_P1 $AC_P2" ] || halt "readback: parents(A) != parents(C)"
  vc_check "$AC_L" "$AC_A" || fail "readback: A=$AC_A does not verify as $AC_L: $VC_MSG (the branch is not moved)"
  git merge --ff-only -q "$AC_A" > "$TMP/ac.ff" 2>&1 || fail "fast-forward to A=$AC_A refused: $(head -1 "$TMP/ac.ff") (A exists; the branch is not moved)"
  [ "$(git rev-parse "refs/heads/$AC_BR")" = "$AC_A" ] || halt "readback: $AC_BR is not at A after the fast-forward"
  echo "SEAT-KEYS: adopt-candidate A=$AC_A C=$AC_C ref=$AC_REFN"
  pass "lane $AC_L adopted $AC_C as its own signed A=$AC_A on $AC_BR (tree $AC_T; parents $AC_P1 $AC_P2; C judged at $REF)"
}

VERB="${1:-}"
[ $# -gt 0 ] && shift
case "$VERB" in
  allowed-signers) verb_allowed_signers "$@" ;;
  verify-commit)   verb_verify_commit "$@" ;;
  sign-relay)      verb_sign_relay "$@" ;;
  verify-relay)    verb_verify_relay "$@" ;;
  check-registry)  verb_check_registry "$@" ;;
  leak-scan)       verb_leak_scan "$@" ;;
  keygen)          verb_keygen "$@" ;;
  relay-from)      verb_relay_from "$@" ;;
  setup-signing)   verb_setup_signing "$@" ;;
  confirm-lanes)   verb_confirm_lanes "$@" ;;
  adopt-candidate) verb_adopt_candidate "$@" ;;
  hook-precommit)  verb_hook_precommit "$@" ;;
  verify-range)    verb_verify_range "$@" ;;
  verify-push)     verb_verify_push "$@" ;;
  login-line)      verb_login_line "$@" ;;
  login-tie)       verb_login_tie "$@" ;;
  fixture-enroll)  verb_fixture_enroll "$@" ;;
  *) VERB="${VERB:-none}"; halt "unknown verb; use allowed-signers|verify-commit|sign-relay|verify-relay|check-registry|leak-scan|keygen|relay-from|setup-signing|confirm-lanes|adopt-candidate|hook-precommit|verify-range|verify-push|login-line|login-tie|fixture-enroll" ;;
esac
