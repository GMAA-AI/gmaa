#!/usr/bin/env bash
# scripts/status.sh — OP-3 (REMEDIATION v3): observable state WITHOUT attaching to a pane.
#
# Answers "what needs me right now" from one command: per-lane {head, last-outbox, inbox-pending,
# tmux-liveness} + the operator-custody queue. Read-only; zero network / API / SQL. bash 3.2-safe.
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "status.sh: not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2

# shellcheck source=scripts/lane-surface.sh
source "$REPO_ROOT/scripts/lane-surface.sh" || { echo "status.sh: scripts/lane-surface.sh unreadable" >&2; exit 2; }
# Load the manifest ONCE in this (parent) shell: lane_manifest_load's rows are then inherited by every
# per-lane $(...) subshell below (lane_branch/hsha/last_outbox), so the roster read happens once, not
# once per lane per column. Enumerate via the manifest — never a hard-coded lane list — so this stops
# silently omitting whichever lanes a hand-maintained string forgot (lanes are keyed on the declared
# class, never the name).
lane_manifest_load || { echo "status.sh: lane manifest unreadable (${LANE_MANIFEST_ERROR:-?})" >&2; exit 2; }
LANES="$(lane_roster)"

# The ONE seen-state engine (the same predicate inbox.sh and inboxf.sh use): an item is pending iff it is
# unseen, or amended after consume. Never re-implemented here, so this count cannot drift from inbox.sh.
# shellcheck source=scripts/consume-core.sh
source "$REPO_ROOT/scripts/consume-core.sh" || { echo "status.sh: scripts/consume-core.sh unreadable" >&2; exit 2; }
STATUS_TMP="$(mktemp -d "${TMPDIR:-/tmp}/status.XXXXXX")" || { echo "status.sh: no scratch dir" >&2; exit 2; }
trap 'rm -rf "$STATUS_TMP"' EXIT
INBOX_REF="${STATUS_INBOX_REF:-main}"   # the spine; STATUS_INBOX_REF and STATUS_WORKTREES are probe seams only

lane_worktree() { # lane_worktree <lane> -> the worktree path whose branch is the lane's, from git itself
  local lane="$1" branch want wt="" line
  if [[ "$(lane_class "$lane" 2>/dev/null)" == "ALLOW" ]]; then want="refs/heads/main"
  else branch="$(lane_branch "$lane" 2>/dev/null)" || return 1; want="refs/heads/${branch}"; fi
  while IFS= read -r line; do
    case "$line" in
      "worktree "*) wt="${line#worktree }" ;;
      "branch $want") printf '%s\n' "$wt"; return 0 ;;
    esac
  done < <(if [[ -n "${STATUS_WORKTREES:-}" ]]; then cat "$STATUS_WORKTREES"; else git worktree list --porcelain 2>/dev/null; fi)
  return 1
}

inbox_unconsumed() { # inbox_unconsumed <lane> -> "<count>\t<age>" | "UNREADABLE\tUNREADABLE"
  # UNCONSUMED = items in <spine>:_orchestration/relay-inbox/<lane>/ that the lane's own seen marker
  # (<its worktree>/.claude/inbox-seen) does not hold at their current blob. The marker advances only on
  # consume, which happens on ACT, so an item the lane is working on still counts.
  # AGE = the oldest such item, by the committer time (UTC) of the commit that landed it on the spine.
  local lane="$1" wt marker ids name oldest="" oldsha="-" csha ts now secs mode type blob path
  wt="$(lane_worktree "$lane")" || { printf 'UNREADABLE\tUNREADABLE\n'; return; }
  [[ -d "$wt" ]] || { printf 'UNREADABLE\tUNREADABLE\n'; return; }
  marker="$wt/.claude/inbox-seen"
  # An existing marker that cannot be read is UNREADABLE, never 0. An absent marker is the engine's
  # "nothing consumed yet" (consume-core.sh: the marker is born on the first consume), as inbox.sh reads it.
  if [[ -e "$marker" && ! -r "$marker" ]]; then printf 'UNREADABLE\tUNREADABLE\n'; return; fi
  CORE_MARKER="$marker"; CORE_BLOBS="$STATUS_TMP/blobs.$lane"; : > "$CORE_BLOBS"
  ids="$(while IFS=$' \t' read -r mode type blob path; do
           name="${path##*/}"; [[ -n "$name" && "$name" != .gitkeep ]] || continue
           core_note_blob "$name" "$blob"; printf '%s\n' "$name"
         done < <(git ls-tree "${INBOX_REF}:_orchestration/relay-inbox/${lane}/" 2>/dev/null))"
  [[ -n "$ids" ]] || { printf '0\t-\n'; return; }
  ids="$(printf '%s\n' "$ids" | core_select_noncurrent)"
  [[ -n "$ids" ]] || { printf '0\t-\n'; return; }
  now="$(date -u +%s)"
  while IFS= read -r name; do
    ts="$(git log --diff-filter=A -1 --format='%ct %H' "$INBOX_REF" -- "_orchestration/relay-inbox/${lane}/${name}" 2>/dev/null)"
    [[ -z "$ts" ]] && { printf '%s\tUNREADABLE\n' "$(printf '%s\n' "$ids" | grep -c .)"; return; }
    csha="${ts#* }"; ts="${ts%% *}"
    if [[ -z "$oldest" ]] || [[ "$ts" -lt "$oldest" ]]; then oldest="$ts"; oldsha="$csha"; fi
  done <<< "$ids"
  secs=$(( now - oldest ))
  if [[ -n "${STATUS_RAW_SECS:-}" ]]; then   # machine mode (--inbox-age-raw): the SAME age, in whole seconds
    printf '%s\t%s\t%s\n' "$(printf '%s\n' "$ids" | grep -c .)" "$secs" "$oldsha"; return
  elif [[ "$secs" -ge 86400 ]]; then age="$((secs/86400))d"
  elif [[ "$secs" -ge 3600 ]];  then age="$((secs/3600))h"
  elif [[ "$secs" -ge 60 ]];    then age="$((secs/60))m"
  else age="${secs}s"; fi
  printf '%s\t%s\n' "$(printf '%s\n' "$ids" | grep -c .)" "$age"
}

prompt_waiting() { # prompt_waiting <lane> -> the newest PROMPT-WAIT line, iff the session's transcript has
  # not moved since it was logged (a permission prompt still on screen); nothing otherwise.
  local lane="$1" wt log line utc sid epoch tr mt
  wt="$(lane_worktree "$lane")" || return 0
  log="$wt/.claude/prompt-wait.log"
  [[ -r "$log" ]] || return 0
  line="$(grep '^PROMPT-WAIT ' "$log" 2>/dev/null | tail -1)"
  [[ -n "$line" ]] || return 0
  utc="$(printf '%s\n' "$line" | awk '{print $2}')"; sid="$(printf '%s\n' "$line" | awk '{print $4}')"
  epoch="$(TZ=UTC date -j -f '%Y-%m-%dT%H:%M:%SZ' "$utc" +%s 2>/dev/null || date -u -d "$utc" +%s 2>/dev/null)"
  [[ -n "$epoch" ]] || { printf '  %s  (time unparsed)\n' "$line"; return 0; }
  # The lane's own config dir: resolved through the one mapping, run against that lane's
  # worktree; STATUS_TRANSCRIPTS stays the test seam ahead of it. A refused mapping is named, never defaulted.
  local cfg tdir
  if [[ -n "${STATUS_TRANSCRIPTS:-}" ]]; then tdir="$STATUS_TRANSCRIPTS"
  else
    cfg="$(bash "$REPO_ROOT/scripts/resolve-project.sh" --config-dir "$wt" 2>/dev/null)" \
      || { printf '  %s  (config dir unresolved: resolve-project.sh --config-dir refused %s)\n' "$line" "$wt"; return 0; }
    tdir="$cfg/projects"
  fi
  tr="$(ls -1 "$tdir"/*/"$sid".jsonl 2>/dev/null | head -1)"
  [[ -n "$tr" ]] || { printf '  %s  (transcript not found)\n' "$line"; return 0; }
  mt="$(stat -f %m "$tr" 2>/dev/null || stat -c %Y "$tr" 2>/dev/null)"
  # 2 s slack: the transcript row for the tool call that raised the prompt can land just after the hook.
  [[ -n "$mt" && "$mt" -le $(( epoch + 2 )) ]] && printf '  %s\n' "$line"
  return 0
}

hsha() { # short head sha for a lane
  local lane="$1" branch
  if [[ "$lane" == "foundation" ]]; then
    git rev-parse --short main 2>/dev/null || echo "(n/a)"
  else
    branch="$(lane_branch "$lane" 2>/dev/null)" || { echo "(n/a)"; return; }
    git rev-parse --short "refs/heads/${branch}" 2>/dev/null || echo "(n/a)"
  fi
}

last_outbox() { # newest outbox basename for a module/DENY-shaped lane (the apply-receipts-only lane's
  # real mail surface is ledger/apply-receipts/relay/, not this path; it truthfully reads "(none)" here)
  local lane="$1" branch
  [[ "$lane" == "foundation" ]] && { echo "(hub — no outbox)"; return; }
  branch="$(lane_branch "$lane" 2>/dev/null)" || { echo "(none)"; return; }
  git ls-tree --name-only "${branch}:_orchestration/relay-outbox/${lane}/" 2>/dev/null \
    | grep -v '^\.gitkeep$' | sort | tail -1 | sed 's/^$/(none)/' | grep . || echo "(none)"
}

tmux_state() { # live / DOWN / DUP! by case-insensitive session name
  local lane="$1" n
  n="$(tmux list-panes -a -F '#{session_name}' 2>/dev/null | awk -v L="$lane" 'tolower($0)==tolower(L)' | grep -c . 2>/dev/null)"
  n="${n:-0}"
  case "$n" in 1) echo "live";; 0) echo "DOWN";; *) echo "DUP!($n)";; esac
}

# Machine mode: `status.sh --inbox-age-raw` prints one `lane<TAB>count<TAB>age-seconds<TAB>delivery-sha` row per non-hub lane
# (count 0 -> `-`; UNREADABLE stays UNREADABLE; delivery-sha = the spine commit that landed the oldest unconsumed item,
# `-` when there is none) from the SAME inbox_unconsumed() above, then exits. No second age algorithm.
if [[ "${1:-}" == "--inbox-age-raw" ]]; then
  export STATUS_RAW_SECS=1
  for lane in $LANES; do
    [[ "$(lane_class "$lane" 2>/dev/null)" == "ALLOW" ]] && continue
    row="$(inbox_unconsumed "$lane")"
    [[ "$row" == *$'\t'*$'\t'* ]] || row="${row}"$'\t-'   # rows with no delivery commit (0 unconsumed, UNREADABLE) carry `-`
    printf '%s\t%s\n' "$lane" "$row"
  done
  exit 0
fi

echo "═══ STATUS $(date -u +%Y-%m-%dT%H:%M:%SZ) ═══ (live derive; snapshot = _orchestration/STATE-DIGEST.md)"
# INBOX-AGE (canon v1.6.5 §7.4(b) inbox-age liveness) is a SEPARATE trailing printf on the same line.
# INBOX = UNCONSUMED items (inbox_unconsumed above): consume happens on act, so an item in work still
# counts. UNREADABLE = the lane's worktree or seen marker could not be read (never shown as 0 or "-").
# HUB = the spine_write=ALLOW lane: its mail is the producer outboxes, read by scripts/inboxf.sh.
echo "INBOX = unconsumed relay-inbox items per the lane's own seen marker (consume is on act; an item in work counts)"
printf '%-12s %-9s %-6s %-10s %s' "LANE" "HEAD" "TMUX" "INBOX" "LAST-OUTBOX"
printf '  %s\n' "INBOX-AGE"
for lane in $LANES; do
  if [[ "$(lane_class "$lane" 2>/dev/null)" == "ALLOW" ]]; then ia="HUB	(inboxf.sh)"
  else ia="$(inbox_unconsumed "$lane")"; fi
  printf '%-12s %-9s %-6s %-10s %s' \
    "$lane" "$(hsha "$lane")" "$(tmux_state "$lane")" "${ia%%	*}" "$(last_outbox "$lane")"
  printf '  %s\n' "${ia#*	}"
done

echo
echo "─── PERMISSION PROMPTS WAITING (newest PROMPT-WAIT per lane whose transcript has not moved since) ───"
pw=""
for lane in $LANES; do l="$(prompt_waiting "$lane")"; [[ -n "$l" ]] && pw="$pw$l"$'\n'; done
if [[ -n "$pw" ]]; then printf '%s' "$pw"; else echo "  (none)"; fi

echo
echo "─── WAITING ON OPERATOR ───"
op_dir="_orchestration/relay-inbox/operator"
if [[ -d "$op_dir" ]]; then
  found=0
  # newest up to 5 operator-inbox files
  for f in $(ls -1t "$op_dir" 2>/dev/null | grep -v '^\.gitkeep$' | grep -v '^README' | head -5); do
    found=1
    pl="$(grep -m1 '^PAYLOAD:' "$op_dir/$f" 2>/dev/null | sed 's/^PAYLOAD:[[:space:]]*//')"
    printf '  • %s — %s\n' "$f" "${pl:-(see file)}"
  done
  [[ "$found" -eq 0 ]] && echo "  (no operator-inbox signals)"
else
  echo "  (operator inbox not present)"
fi
exit 0
