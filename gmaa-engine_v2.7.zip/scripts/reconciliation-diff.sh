#!/usr/bin/env bash
# reconciliation-diff.sh — canon §4's bidirectional transport-integrity check, ONE mechanism,
# THREE consumer surfaces. Member of SET-0007 / REQ-RECONCILIATION-DIFF.
#
# CANON §4:136 (verbatim): "Reconciliation diff (bidirectional transport integrity) — the
#   architect's cumulative session manifest is diffed against what actually landed at HEAD.
#   Detects both directions: rulings that never arrived AND demands for artifacts already present.
#   Governance traffic sits under the same evidence regime as worker output — by mechanism, not by
#   operator vigilance."
#
# CONTRACT: contracts/SPEC-DOORBELL.md §3–§4 (lands with this script in SET-0007).
# CRITERIA: _ratification/criteria/reconciliation-diff.md (AC1-AC8).
#
# EXIT CODES — closed set, and the closure is the point:
#   0  reconciled          both directions computed, no divergence
#   1  usage error         unknown surface / bad flag  (NEVER 0 — AC1)
#   2  divergence found    named under its own direction heading; HALT-LOUD, caller stops
#   3  unreadable side     a side could not be read. ABSENCE IS NEVER READ AS AGREEMENT.
#
# THE LOAD-BEARING RULE (AC5): a side that cannot be read exits 3, never 0. "I could not look"
#   and "I looked and they match" are different facts and this mechanism refuses to conflate them.
#   The same inversion the cost-guard encodes: reading nothing must never read as $0 spent.
#
# SELF-DECLARED LIMITS (AC3 of the contract member — a half-cure that lets itself
#   be mistaken for the cure is worse than none). THIS MECHANISM CANNOT SEE:
#   - semantic divergence: two sides whose bytes differ for equivalent reasons, or agree by accident;
#   - anything outside its declared surface paths (printed every run, before any count);
#   - whether a ruling was CORRECT — only whether it ARRIVED;
#   - drift in a tree it was not pointed at (--engine-root default is a guess, and says so).
#   It is a transport check, not a correctness check.
#
# CONTENT, NOT ANCESTRY (AC8): divergence is decided by comparing BYTES (git object ids), never by
#   counting commits. A side hand-delivered by content is RECONCILED even though its commit ancestry
#   differs forever — foundation's own governance probe had to be corrected on exactly this point.
set -uo pipefail

# ⚠ BASH 3.2 ONLY — NO `mapfile`, NO `readarray`, NO associative arrays. The host ships bash
#   3.2.57 (macOS). The first cut of this script used `mapfile` and it did NOT fail loudly: the
#   builtin was "command not found", the arrays came back unbound, and TWO surfaces reported
#   "0 divergence / exit 0" from NOTHING — a FALSE GREEN produced by a broken instrument, which is
#   the precise class this mechanism exists to detect. Caught by the seen-to-fail battery before
#   green, which is what the battery is for. Collections here are NEWLINE-DELIMITED STRINGS, and
#   every count is derived from the string so an empty read cannot masquerade as an empty result.
SELF="$(basename "$0")"
usage() {
  cat >&2 <<'USAGE'
usage: reconciliation-diff.sh --surface manifest|pending-set|origin-engine [--no-fetch] [--engine-root PATH]
  --surface       REQUIRED. one of: manifest | pending-set | origin-engine
  --no-fetch      do not fetch; the run is labelled AS-OF-LAST-FETCH and CANNOT exit 0
  --engine-root   filesystem root of the engine tree (origin-engine surface only)
exit: 0 reconciled · 1 usage · 2 divergence · 3 unreadable
USAGE
}

# need_val — cure for ISSUE-TRAILING-VALUE-FLAG-SPINS-FOREVER-IN-FIVE-SCRIPTS (SET-0083 shape,
# carried from scripts/creed-scan.sh need_val()/flag-swallow guard, auditor ac4caa28 O1 /
# 0e08e6a4 O2), with ONE HALF already present here: `shift 2 || { usage; exit 1; }` below already
# stops the missing-value hang (verified empirically — `--surface` / `--engine-root` as the LAST
# argument exits 1 within 1s, it does NOT spin; `shift 2` fails without shifting, `||` fires). What
# was missing is the OTHER SET-0083 half: a value-flag followed by ANOTHER flag was silently
# swallowed as this flag's "value" (only caught several lines later, indirectly, as an "unknown
# surface" — never NAMING the flag). Name it HERE, at the point of parse.
# DELIBERATE DEPARTURE from the SET-0083 "exit 3" literal (flagged for foundation/architect
# review): THIS FILE documents exit 3 as a CLOSED-SET, already-wired meaning — "unreadable side; …
# ABSENCE IS NEVER READ AS AGREEMENT" (line ~18/24) — distinct from exit 1 "usage error … NEVER 0".
# A malformed CLI is a usage error, same class as every other bad-flag path in this file, so this
# stays on exit 1 (via usage()), never 3 — the same conflation cost-guard.sh's own docstring warns
# against, applied to this file's own closed set.
need_val() { case "${2-}" in --*) echo "$SELF: $1 requires a value, got the flag '$2' instead" >&2; usage; exit 1 ;; esac; }

SURFACE=""; NO_FETCH=0; ENGINE_ROOT="${GMAA_ENGINE_ROOT:-$HOME/Code/gmaa}"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --surface)     need_val "--surface" "${2:-}"; SURFACE="${2:-}"; shift 2 || { usage; exit 1; } ;;
    --no-fetch)    NO_FETCH=1; shift ;;
    --engine-root) need_val "--engine-root" "${2:-}"; ENGINE_ROOT="${2:-}"; shift 2 || { usage; exit 1; } ;;
    -h|--help)     usage; exit 1 ;;
    *)             echo "$SELF: unknown argument '$1'" >&2; usage; exit 1 ;;
  esac
done
case "$SURFACE" in
  manifest|pending-set|origin-engine) : ;;
  "") echo "$SELF: --surface is REQUIRED" >&2; usage; exit 1 ;;
  *)  echo "$SELF: unknown surface '$SURFACE'" >&2; usage; exit 1 ;;
esac

SPINE_REF_SH="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" 2>/dev/null && pwd -P)/spine-ref.sh"   # beside this script only (0507 R2); resolved before the cd below
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "$SELF: HALT — not inside a git worktree (unreadable)" >&2; exit 3; }
cd "$REPO_ROOT" || { echo "$SELF: HALT — cannot cd to repo root (unreadable)" >&2; exit 3; }

# GOV_REF (the spine ref, never an inlined trunk literal), resolved BEFORE the fetch so the fetch reads only its remote
# (0507 R3). Same pattern as boot-check.sh GOV_REF: GOV_REF if set (a replica/test knob), else the ONE resolver
# scripts/spine-ref.sh found beside this script; no resolution is a HALT by name, never a literal fallback (inv #5).
GOV_REF="${GOV_REF:-}"
[ -n "$GOV_REF" ] || [ -f "$SPINE_REF_SH" ] || { echo "reconciliation-diff: HALT — SPINE-REF-ABSENT $SPINE_REF_SH (the one spine-ref resolver is found beside this script only; 0507 R2)" >&2; exit 3; }
[ -n "$GOV_REF" ] || GOV_REF="$(bash "$SPINE_REF_SH")" || { echo "reconciliation-diff: HALT — SPINE-REF-UNRESOLVED: $SPINE_REF_SH unfilled and GOV_REF unset (the one spine-ref resolver)" >&2; exit 3; }
# the one remote the spine ref names: the half before the slash (origin/<trunk> -> origin); a ref with no slash names none
SPINE_REMOTE=""; [[ "$GOV_REF" == */* ]] && SPINE_REMOTE="${GOV_REF%%/*}"

# --- freshness. A stale reference silently re-creates the very defect this detects one layer up
# (a named trap), so --no-fetch is LABELLED and is NOT allowed to report success.
STALE=0
if [[ "$NO_FETCH" -eq 1 ]]; then
  STALE=1
  FRESHNESS="AS-OF-LAST-FETCH (--no-fetch) — this run may understate divergence and CANNOT report reconciled"
elif [[ -z "$SPINE_REMOTE" ]]; then
  STALE=1
  FRESHNESS="AS-OF-LAST-FETCH (the spine ref '${GOV_REF}' names no remote; nothing fetched) — CANNOT report reconciled"
elif git fetch --quiet "$SPINE_REMOTE" 2>/dev/null; then
  FRESHNESS="FRESH (fetched remote ${SPINE_REMOTE} only, $(date -u +%Y-%m-%dT%H:%M:%SZ))"
else
  STALE=1
  FRESHNESS="AS-OF-LAST-FETCH (FETCH FAILED) — reference not trustworthy as current; CANNOT report reconciled"
fi

echo "=== RECONCILIATION DIFF — surface: $SURFACE ==="
echo "freshness: $FRESHNESS"

D1=""; D2=""; UNREADABLE=""

# oid <ref-or-path-expr>  → git object id, or the literal MISSING. Content, never ancestry.
oid() { git rev-parse -q --verify "$1" 2>/dev/null || echo MISSING; }
# add1/add2 <line> — append to a newline-delimited finding list (bash-3.2 safe).
add1() { D1="${D1}${1}"$'\n'; }
add2() { D2="${D2}${1}"$'\n'; }
# nlines <string> — count non-empty lines. Derived from the string, never tracked separately.
#   ⚠ Two traps deliberately avoided here, both previously paid for by this program:
#   (1) NO `${var//[...]/}` parameter substitution — on bash 3.2 that HANGS on a ~25KB string
#       (measured: the first cut of this function did not return in 60s on a 350-file listing).
#   (2) NO `grep -c … || echo 0` — the documented D-9 idiom, which emits "0\n0" because `grep -c`
#       prints 0 AND exits 1. Here the count is taken by assignment and grep's exit status is
#       simply not consulted, so an empty input yields exactly "0".
# SIGPIPE RACE CURE (auditor ce48fa49 F1): under `set -o pipefail`, `printf "$BIG" | grep -q …`
# is NON-DETERMINISTIC — grep -q exits at its first match, printf takes SIGPIPE (141), pipefail reports the
# pipeline FAILED, and the `||` branch fires on a MATCH. Every early-exit grep over a variable reads a
# here-string (`<<<`), never a pipe; a producer pipe is captured to a variable first.
nlines() { local n; n="$(printf '%s\n' "$1" | grep -c .)"; [ -z "$n" ] && n=0; printf '%s' "$n"; }

# GOV_REF was resolved above (before the fetch). When it does not resolve to an object (an adopter's fresh tree), fall
# back to HEAD AND SAY SO — a silent fallback would be the false-green this reconciler exists to catch.
GOV_REF_SRC="SPINE(${GOV_REF})"
if [[ "$(oid "$GOV_REF")" == MISSING ]]; then
  GOV_REF_SRC="LOCAL-FALLBACK(HEAD; ${GOV_REF} unresolvable)"; GOV_REF="HEAD"
fi
# Canon edition (§1.1): the ONE shared resolver governance.sh uses — never a pinned edition.
source "$(dirname "${BASH_SOURCE[0]}")/canon-core.sh" || { echo "reconciliation-diff: cannot source scripts/canon-core.sh" >&2; exit 3; }
# Outbox name grammar (§1.3): <YYYY-MM-DD>-NN-<topic> (def §4) — never a literal year.
OUTBOX_DATE_RE='[0-9]{4}-[0-9]{2}-[0-9]{2}'

echo "ref: ${GOV_REF_SRC}"   # §1.2: the frame is always printed — a fallback is never silent
case "$SURFACE" in

  # ---- SURFACE A: canon §4's own — the architect's outbox vs what landed on spine -------------
  manifest)
    echo "surface definition (paths/refs): origin/architect:_orchestration/relay-outbox/architect/  <->  ${GOV_REF}:_orchestration/relay-inbox/architect/"
    A_REF="origin/architect"; B_REF="$GOV_REF"
    if [[ "$(oid "$A_REF")" == MISSING || "$(oid "$B_REF")" == MISSING ]]; then
      UNREADABLE="a required ref is unreadable (architect=$(oid "$A_REF") main=$(oid "$B_REF"))"
    else
      OUTBOX="$(git ls-tree -r --name-only "$A_REF" -- _orchestration/relay-outbox/architect/ 2>/dev/null | sed 's#.*/##' | grep -v '^\.gitkeep$' || true)"
      INBOX="$(git ls-tree -r --name-only "$B_REF" -- _orchestration/relay-inbox/architect/ 2>/dev/null | sed 's#.*/##' | grep -v '^\.gitkeep$' || true)"
      n_out="$(nlines "$OUTBOX")"; n_in="$(nlines "$INBOX")"
      echo "denominator: outbox=$n_out inbox=$n_in"
      # A denominator of zero on BOTH sides is not agreement — it is a failed read (the mapfile
      # lesson wired in, so a broken enumeration can never present as a clean surface again).
      if [ "$n_out" -eq 0 ] && [ "$n_in" -eq 0 ]; then
        UNREADABLE="both sides enumerated ZERO files — a failed read, not agreement"
      else
        # DIRECTION 1 — produced but never landed (the ruling that never arrived).
        # Correspondence is by RELAY ORDINAL (architect-NNN ↔ the foundation reply citing it),
        # because the two directories use different filename conventions by design.
        for n in $(printf '%s\n' "$OUTBOX" | sed -nE "s/^${OUTBOX_DATE_RE}-([0-9]{2,3})-.*/\\1/p" | sort -u); do
          grep -q -- "-${n}-" <<<"$INBOX" || add1 "architect-$n produced, no foundation reply landed at spine"
        done
        # DIRECTION 2 — landed at the destination with no producer record (a demand for an artifact
        # already present). Reported, never suppressed, even where asymmetry is expected.
        for n in $(printf '%s\n' "$INBOX" | sed -n 's/.*-\([0-9]\{2,3\}\)-REAPED.*/\1/p' | sort -u); do
          grep -qE "^${OUTBOX_DATE_RE}-${n}-" <<<"$OUTBOX" || add2 "foundation reply cites architect-$n with no producer file in the outbox"
        done
      fi
    fi
    ;;

  # ---- SURFACE B: the pending-set consumer — the pending-set ledger vs the branches ------------------
  pending-set)
    echo "surface definition (paths/refs): PENDING-SET.md + _ratification/SET-*.md (${GOV_REF})  <->  _ratification/criteria/*.md"
    if [[ "$(oid "$GOV_REF")" == MISSING ]]; then
      UNREADABLE="${GOV_REF} is unreadable"
    else
      PACKETS="$(git ls-tree -r --name-only "$GOV_REF" -- _ratification/ 2>/dev/null | grep -E '_ratification/SET-[0-9]+\.md$' || true)"
      CRITERIA="$(git ls-tree -r --name-only "$GOV_REF" -- _ratification/criteria/ 2>/dev/null | grep -E '\.md$' || true)"
      n_pk="$(nlines "$PACKETS")"; n_cr="$(nlines "$CRITERIA")"
      echo "denominator: packets=$n_pk criteria-files=$n_cr"
      if [ "$n_pk" -eq 0 ] && [ "$n_cr" -eq 0 ]; then
        UNREADABLE="both sides enumerated ZERO files — a failed read, not agreement"
      else
        # DIRECTION 1 — a packet declares a member with no acceptance-criteria file: it cannot PASS.
        for p in $PACKETS; do
          [ -z "$p" ] && continue
          for m in $(git show "${GOV_REF}:$p" 2>/dev/null | awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m' | sed -n 's/^- \([a-zA-Z0-9._-]*\) .*/\1/p'); do
            grep -qE "/${m}\.md$" <<<"$CRITERIA" || add1 "$(basename "$p" .md) declares member '$m' with NO criteria file"
          done
        done
        # DIRECTION 2 — a criteria file with no packet declaring it (an artifact already present).
        for c in $CRITERIA; do
          [ -z "$c" ] && continue
          base="$(basename "$c" .md)"
          found=0
          for p in $PACKETS; do
            [ -z "$p" ] && continue
            _mem="$(git show "${GOV_REF}:$p" 2>/dev/null | awk '/^## MEMBERS/{m=1;next} /^## /{m=0} m')"; if grep -qE "^- ${base}( |$)" <<<"$_mem"; then found=1; break; fi
          done
          [ "$found" -eq 0 ] && add2 "criteria '$base' declared by NO packet"
        done
      fi
    fi
    ;;

  # ---- SURFACE C: origin <-> engine, the pair neither direction governs ----------------------
  origin-engine)
    O_CANON="$(canon_resolve "$GOV_REF")"
    echo "surface definition (paths/refs): ${GOV_REF}:${O_CANON:-<no canon at ${GOV_REF}>}  <->  \$ENGINE_ROOT canon + .claude/settings.json permission baseline"
    echo "engine root: $ENGINE_ROOT"
    if [[ ! -d "$ENGINE_ROOT" ]]; then
      UNREADABLE="engine root '$ENGINE_ROOT' is not a readable directory — absence is NOT agreement"
    elif [[ "$(oid "$GOV_REF")" == MISSING ]]; then
      UNREADABLE="${GOV_REF} is unreadable"
    else
      ENGINE_CANON=""; [[ -n "$O_CANON" ]] && ENGINE_CANON="$(find "$ENGINE_ROOT" -maxdepth 3 -name "${O_CANON%.md}*.md" 2>/dev/null | head -1)"
      if [[ -z "$ENGINE_CANON" ]]; then
        UNREADABLE="no ${O_CANON:-canon} edition found under '$ENGINE_ROOT' — cannot compare; absence is NOT agreement"
      else
        echo "denominator: 2 compared artifacts (canon body · permission baseline)"
        # CONTENT not ancestry (AC8): compare BYTES from line 4 (line 3 is the disclosure posture,
        # which differs BY DESIGN — internal CONFIDENTIAL vs public CC BY — and is not divergence).
        o_hash="$(git show "${GOV_REF}:${O_CANON}" 2>/dev/null | tail -n +4 | shasum | cut -d' ' -f1)"
        e_hash="$(tail -n +4 "$ENGINE_CANON" 2>/dev/null | shasum | cut -d' ' -f1)"
        if [[ -z "$o_hash" || -z "$e_hash" ]]; then
          UNREADABLE="a canon body could not be hashed (origin='${o_hash:-EMPTY}' engine='${e_hash:-EMPTY}')"
        elif [[ "$o_hash" != "$e_hash" ]]; then
          add1 "canon body diverges: origin=${o_hash:0:12} engine=${e_hash:0:12}"
        fi
        o_mode="$(git show "${GOV_REF}:.claude"/settings.json 2>/dev/null | sed -n 's/.*"defaultMode"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
        e_mode="$(find "$ENGINE_ROOT" -maxdepth 4 -name settings.json -path '*.claude*' 2>/dev/null | head -1 | xargs -r sed -n 's/.*"defaultMode"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
        if [[ -n "$o_mode" && -n "$e_mode" && "$o_mode" != "$e_mode" ]]; then
          add2 "permission baseline diverges: origin='$o_mode' engine='$e_mode' (engine behind origin)"
        fi
      fi
    fi
    ;;
esac

# --- UNREADABLE => 3, before anything can be mistaken for a clean result.
if [[ -n "$UNREADABLE" ]]; then
  echo ""
  echo "⛔ HALT — UNREADABLE SIDE: $UNREADABLE"
  echo "   Exit 3. A side that could not be read is NOT a side that agrees."
  exit 3
fi

# --- BOTH directions are ALWAYS named, including on clean runs (AC2). A report naming only one
#     direction is a FAILED run, not a clean one — the bidirectionality is the canon requirement.
echo ""
n_d1="$(nlines "$D1")"; n_d2="$(nlines "$D2")"
echo "DIRECTION 1 — produced/declared but NOT landed at the destination: $n_d1"
printf '%s' "$D1" | grep . | sed 's/^/  - /' || true
echo "DIRECTION 2 — present at the destination with NO producer record: $n_d2"
printf '%s' "$D2" | grep . | sed 's/^/  - /' || true

TOTAL=$(( n_d1 + n_d2 ))
echo ""
if [[ "$TOTAL" -gt 0 ]]; then
  echo "⛔ DIVERGENCE: $TOTAL item(s) across both directions on surface '$SURFACE'. Exit 2 — HALT-LOUD; the caller stops and never auto-continues."
  exit 2
fi
if [[ "$STALE" -eq 1 ]]; then
  # CONTRACT-CONFORMANCE FIX: this branch exited 2 (DIVERGENCE) and the contract
  # says 3. The contract is right and the implementation was wrong: NO divergence was found, so
  # claiming one is false. What actually happened is that the run COULD NOT SEE current state —
  # which is BLINDNESS, and blindness is exit 3. Caught by transcribing C-RECONCILIATION-DIFF §2
  # property 4 ("on fetch failure ... the run exits 3, not 0") and comparing it to these bytes —
  # a doc-vs-code divergence inside the very set built to detect doc-vs-code divergence.
  # NOTE the ordering that survives: a FOUND divergence still exits 2 above, even when stale,
  # because a positive finding is a finding regardless of freshness. Only the clean-but-blind
  # case becomes 3.
  echo "⚠ NO DIVERGENCE FOUND, but this run is $FRESHNESS."
  echo "   Exit 3 — a stale read is BLINDNESS, not agreement. It may not report 'reconciled'."
  echo "   Re-run with network to earn exit 0."
  exit 3
fi
echo "✅ RECONCILED — both directions computed, no divergence, reference fresh. Exit 0."
exit 0
