#!/bin/bash
# scripts/spine-receive.sh -- T2'/T3' server-side check on the spine account's bare repo (the pre-receive check and its GitHub mirror).
# ONE file, installed as BOTH hooks/pre-receive and hooks/post-receive (dispatch on the name it is run under), so the
# installed-hook readback is one blob compare against main:scripts/spine-receive.sh (0420 T4' Readback).
#
# Verbs (run as a hook, the verb is the hook name):
#   pre-receive    refuse-or-accept the whole push (githooks(5): non-zero exit => no ref is updated)
#   post-receive   mirror every accepted ref update to the `mirror` remote (GitHub), NEVER forced (0420 T3'). A refusal is said
#                  as MIRROR-DIVERGENCE (a [rejected] ref: history moved) or MIRROR-PUSH-FAILED (anything else: transport,
#                  unpacker, no remote), never the one for the other
#   install <bare> copy this file from <bare>'s own refs/heads/main into <bare>/hooks/{pre,post}-receive (spine account), and
#                  pin git's automatic maintenance OFF in <bare>'s own config (receive.autogc=false, maintenance.auto=false,
#                  gc.auto=0): receive-pack otherwise starts a detached `git maintenance run --auto` after every accepted push,
#                  and overlapping runs were measured to drop an accepted commit's objects. Idempotent.
#   readback <bare> PASS iff both installed hooks' git blob sha == <bare>'s main:scripts/spine-receive.sh blob sha AND the three
#                  keys read exactly false, false, 0 in <bare>'s own config (--local); anything else, unset included, is
#                  `readback FAIL <key> <got> != <want>`, exit 1
#   maintain <bare> the one scheduled maintenance job (run by the system scheduler as the spine account; never from a hook,
#                  never per push): a non-auto `git maintenance run` over commit-graph, loose-objects, incremental-repack.
#                  git takes the object-database lock; a run that finds it held exits 0 with a warning only, so this verb
#                  reads that warning and says `maintain LOCKED`, exit 3
#   plist <bare> <user> print the scheduler job for `maintain` (macOS launchd: one LaunchDaemon run as <user>, in the system
#                  domain; a per-user LaunchAgent, which `git maintenance start` writes, loads only into a GUI login session)
#
# pre-receive policy (0420 T2'; stdin `<old-oid> SP <new-oid> SP <ref-name>`, githooks(5), git 2.54.0):
#   - the pusher lane comes ONLY from SPINE_PUSHER, set by the spine account's forced command from the KEY's authorized_keys line;
#   - every trusted input (lane map, seat-key registry, revocation list, seat-keys.sh) is read from the spine's CURRENT
#     refs/heads/main (pre-update), never from the pushed tree and never from the pushed tip;
#   - refs: only refs/heads/*. main -> the trunk lane (the one ALLOW row); a lane-map branch -> that lane;
#     foundation/* -> the trunk lane (aux: sync candidates). Anything else (tags, unmapped branches) is REFUSED, named;
#   - per-lane branch protection: the pusher must be the ref's owning lane;
#   - main: no deletion, no non-fast-forward, the NEW TIP itself signed by the trunk key (closes the ff-to-a-lane-commit
#     bypass), K4 by parent position (first-parent line = trunk key; a merge's second parent = the
#     merged lane's key, the lane a RATIFIED set at the merge's first parent names, M6(ii) via scripts/set-membership.sh),
#     territory, and the check replay (0489 R1);
#   - a lane branch: no non-fast-forward; every commit new to the repo signed by that lane's key; territory; replay;
#   - foundation/*: no non-ff; trunk-signed; the sync-candidate predicate (0489 R7: one new commit, parents = a lane
#     tip and a main-reachable commit, tree differs from their clean merge under _boot/ only). No other unit runs.
#   "New to the repo" = `git rev-list <new> --not --all` at pre-receive time (refs not yet updated; quarantine objects
#   visible through the env receive-pack exports, git-receive-pack(1) QUARANTINE ENVIRONMENT). A commit already in
#   the repo was judged on its own ref at its first arrival.
# The hook never updates a ref (git-receive-pack(1): ref updates from pre-receive are rejected) and never self-updates:
# a new version of this file reaches the hooks only by `install`, run as the spine account (T0: no seat credential
# can reconfigure the enforcement point; foundation is a seat).
# Every refusal is one `SPINE-RECEIVE: REFUSED <ref> <reason>` line on stderr (forwarded to the pusher). Bash 3.2 safe.
set -u
ZERO=0000000000000000000000000000000000000000
MAP_PATH="_orchestration/lane-provisioning.md"
SELF_PATH="scripts/spine-receive.sh"
say()    { echo "SPINE-RECEIVE: $*" >&2; }
refuse() { say "REFUSED $*"; exit 1; }
halt()   { say "HALT $*"; exit 2; }
TMP=$(mktemp -d "${TMPDIR:-/tmp}/spine-receive.XXXXXX") || { echo "SPINE-RECEIVE: HALT mktemp failed" >&2; exit 2; }
trap 'rm -rf "$TMP"' EXIT

# load_trusted <main-sha> : $TMP/lanes (lane TAB branch TAB class), TRUNK, TRUNK_BR, $TMP/sk (seat-keys.sh at main)
load_trusted() {
  git show "$1:$MAP_PATH" > "$TMP/map" 2>/dev/null || halt "cannot read $MAP_PATH at main $1 (never a pass)"
  awk -F'|' '/^\|/ { a=$2; b=$3; c=$5; gsub(/^[ \t]+|[ \t]+$/,"",a); gsub(/^[ \t]+|[ \t]+$/,"",b); gsub(/^[ \t]+|[ \t]+$/,"",c)
    if (a=="lane" || a ~ /^-+$/ || a=="") next; sub(/[ \t]*\(.*\)$/,"",a); print a "\t" b "\t" c }' "$TMP/map" > "$TMP/lanes"
  [ -s "$TMP/lanes" ] || halt "no lane rows in $MAP_PATH at main $1"
  [ "$(awk -F'\t' '$3=="ALLOW"' "$TMP/lanes" | wc -l | tr -d ' ')" = 1 ] || halt "need exactly 1 ALLOW (trunk) row in the lane map at main $1"
  TRUNK=$(awk -F'\t' '$3=="ALLOW" { print $1 }' "$TMP/lanes"); TRUNK_BR=$(awk -F'\t' '$3=="ALLOW" { print $2 }' "$TMP/lanes")
  [ "$TRUNK_BR" = main ] || halt "the trunk lane's branch is '$TRUNK_BR', not main (this hook protects refs/heads/main)"
  git show "$1:scripts/seat-keys.sh" > "$TMP/sk" 2>/dev/null || halt "cannot read scripts/seat-keys.sh at main $1"
  git show "$1:scripts/set-membership.sh" > "$TMP/sm" 2>/dev/null || halt "cannot read scripts/set-membership.sh at main $1"
  . "$TMP/sm" || halt "cannot source scripts/set-membership.sh from main $1"
}
SK() { SEAT_KEYS_JUDGE_REF="$MAIN" bash "$TMP/sk" "$@" < /dev/null; }   # never let a child eat the hook's stdin
class_of() { awk -F'\t' -v l="$1" '$1==l { print $3; exit }' "$TMP/lanes"; }

# territory <sha> <owner> : 0 = every relay path the commit itself writes is in <owner>'s territory (SPEC-DOORBELL:63)
#   outbox/<d>/** only by lane <d>; relay-inbox/** only by the ALLOW lane; the apply-receipts relay dir only by the
#   apply-receipts-only lane. Merge commits: only the paths the merge result changes against EVERY parent (-c).
territory() {
  TS="$1"; TO="$2"; TC=$(class_of "$TO")
  NPAR=$(git rev-list --parents -n 1 "$TS" | awk '{ print NF - 1 }')
  if [ "$NPAR" = 0 ]; then git diff-tree --root -r --name-only --no-commit-id "$TS" > "$TMP/paths"
  elif [ "$NPAR" = 1 ]; then git diff-tree -r --name-only --no-commit-id "$TS" > "$TMP/paths"
  else git diff-tree -c -r --name-only --no-commit-id "$TS" > "$TMP/paths"; fi
  OUTBOX_DIR=_orchestration/relay-outbox   # a declared engine path (written by the pending-set verb)
  while IFS= read -r P; do
    case "$P" in
      "$OUTBOX_DIR"/*/*) D="${P#"$OUTBOX_DIR"/}"; D="${D%%/*}"
        [ "$D" = "$TO" ] || { TMSG="$TS writes $P: the outbox of '$D', not of '$TO'"; return 1; } ;;
      _orchestration/relay-inbox/*) [ "$TC" = ALLOW ] || { TMSG="$TS writes $P: only the trunk lane writes inboxes ('$TO' is $TC)"; return 1; } ;;
      ledger/apply-receipts/relay/*) [ "$TC" = apply-receipts-only ] || { TMSG="$TS writes $P: only the apply-receipts-only lane writes this relay dir ('$TO' is $TC)"; return 1; } ;;
    esac
  done < "$TMP/paths"
  return 0
}

# trunk_k4 <new> : 0489 R5 + R4/R6 on main. A commit on the FIRST-PARENT line of <new> must be signed by the trunk key.
#   A commit reachable only through a merge's SECOND parent must be signed by the key of the lane that merge brings in:
#   the one lane-map lane whose branch at the spine contains that parent. That lane must be a member of a RATIFIED set
#   at the merge's first parent (M6(ii), the shared function; the apply-receipts-only lane is exempt, as at the reap).
#   Every new commit must be covered by one of the two rules. Sets KMSG on refusal.
trunk_k4() {
  TN="$1"
  git rev-list --first-parent "$TN" --not --all > "$TMP/fp" 2>/dev/null || { KMSG="rev-list --first-parent failed"; return 1; }
  SK verify-range "$TRUNK" --first-parent "$TN" --not --all --ref "$MAIN" > "$TMP/k.fp" 2>&1 || { KMSG="K4 (first-parent line needs the trunk key): $(tail -1 "$TMP/k.fp")"; return 1; }
  cp "$TMP/fp" "$TMP/covered"
  while IFS= read -r M; do
    [ -n "$M" ] || continue
    set -- $(git rev-list --parents -n 1 "$M"); shift
    [ $# -le 1 ] && continue
    [ $# = 2 ] || { KMSG="$M has $# parents (an octopus merge is never a landing)"; return 1; }
    MP1="$1"; MP2="$2"; ML=""; MB=""; MNL=0
    while IFS="$(printf '\t')" read -r l b c; do
      [ "$b" = main ] && continue
      R=$(git rev-parse -q --verify "refs/heads/$b") || continue
      git merge-base --is-ancestor "$MP2" "$R" 2>/dev/null && { ML="$l"; MB="$b"; MNL=$((MNL + 1)); }
    done < "$TMP/lanes"
    [ "$MNL" = 1 ] || { KMSG="merge $M: its second parent $MP2 is on $MNL lane branch(es) at the spine, need exactly 1"; return 1; }
    if [ "$(class_of "$ML")" != apply-receipts-only ]; then
      m6ii_member "$ML" "$MB" "$MP1" > "$TMP/pkt" || { KMSG="merge $M: NO-CHERRY-PICK (lane $ML, packets read at first parent $MP1; named above)"; return 1; }
    fi
    SK verify-range "$ML" "$MP2" "^$MP1" --not --all --ref "$MAIN" > "$TMP/k.sp" 2>&1 || { KMSG="K4 (second parent of merge $M needs lane $ML's key): $(tail -1 "$TMP/k.sp")"; return 1; }
    git rev-list "$MP2" "^$MP1" --not --all >> "$TMP/covered"
  done < "$TMP/fp"
  sort -u "$TMP/covered" > "$TMP/cov.s"; sort -u "$TMP/new" > "$TMP/new.s"
  UNC=$(comm -23 "$TMP/new.s" "$TMP/cov.s" | head -1)
  [ -z "$UNC" ] || { KMSG="new commit $UNC is neither on the first-parent line nor inside a merge's second parent"; return 1; }
  return 0
}

# candidate_ok <sha> : 0489 R7, a foundation/* sync candidate. Exactly one new commit (the candidate); two parents, the
#   first the tip of a lane branch at the spine, the second reachable from current main; and its tree differs from the
#   clean merge of the two (git merge-tree --write-tree; a conflicted merge still writes a tree) under _boot/ only.
#   Sets CMSG on refusal.
candidate_ok() {
  CS="$1"
  [ "$(grep -c . "$TMP/new")" = 1 ] && [ "$(head -1 "$TMP/new")" = "$CS" ] || { CMSG="a candidate push carries exactly one new commit, the candidate $CS"; return 1; }
  set -- $(git rev-list --parents -n 1 "$CS"); shift
  [ $# = 2 ] || { CMSG="candidate $CS has $# parent(s), not 2"; return 1; }
  CP1="$1"; CP2="$2"; CLB=""
  while IFS="$(printf '\t')" read -r l b c; do
    [ "$b" = main ] && continue
    [ "$(git rev-parse -q --verify "refs/heads/$b")" = "$CP1" ] && CLB="$b"
  done < "$TMP/lanes"
  [ -n "$CLB" ] || { CMSG="candidate $CS: first parent $CP1 is not the tip of a lane branch at the spine"; return 1; }
  git merge-base --is-ancestor "$CP2" "$MAIN" 2>/dev/null || { CMSG="candidate $CS: second parent $CP2 is not reachable from current main $MAIN"; return 1; }
  git merge-tree --write-tree "$CP1" "$CP2" > "$TMP/mt" 2>/dev/null; MTRC=$?
  [ "$MTRC" -le 1 ] || { CMSG="candidate $CS: git merge-tree failed rc=$MTRC"; return 1; }
  CT=$(head -1 "$TMP/mt")
  git diff --name-only "$CT" "$CS" > "$TMP/cd" 2>/dev/null || { CMSG="candidate $CS: cannot diff against the clean merge $CT"; return 1; }
  OUT=$(grep -v '^_boot/' "$TMP/cd" | head -1)
  [ -z "$OUT" ] || { CMSG="candidate $CS: new content outside _boot/ ($OUT differs from the clean merge of $CP1 and $CP2); land it as a normal signed landing"; return 1; }
  return 0
}

# --- 0489 R1: the per-commit replay. Units run in ONE disposable repo $RB = <bare>/spine-replay.XXXXXX (made here, inside
#   the spine account's bare repo, so scripts/seat-keys.sh's replay_selector reads it as VERIFY-ONLY, R3). Its object
#   store is the bare repo's objects plus the quarantine (alternates), its origin/main = current main. Shape per commit:
#   WORK TREE = the bytes of current main (the judge: every unit's code, the lane map, the engine-paths table), plus a
#   RECORD overlay from the judged commit (_ratification/ and PENDING-SET.md: the packets the local hook reads, as at the
#   committer's tree, R6's rationale; _boot/BOOTSTRAP.md: cross-checked against SPINE_PUSHER's lane-map row first, never
#   trusted); INDEX = the judged commit; HEAD = its branch at its first parent; MERGE_HEAD = its second parent.
REPLAY_ENV="env -u GIT_DIR -u GIT_WORK_TREE -u GIT_INDEX_FILE -u GIT_OBJECT_DIRECTORY -u GIT_ALTERNATE_OBJECT_DIRECTORIES -u GIT_QUARANTINE_PATH -u GIT_COMMON_DIR -u GIT_PREFIX"
RB=""
# 0490 R3(b)/R4(b): the seven gate-data tables, judged at the spine's current main in the replay
GATE_TABLES="_index/engine-paths.tsv _index/authz-enforcers.tsv _index/greenlight-deny-classes.tsv _index/canon-class-triggers.tsv _index/canon-section-map.tsv _index/annotations.tsv _index/mechanisms.tsv"
RG() { $REPLAY_ENV git -C "$RB" "$@"; }
abspath() { (cd "$1" 2>/dev/null && pwd -P); }
boot_field() { awk -v k="$1" '/^---[[:space:]]*$/ { d++; next } d==1 && index($0, k":")==1 { s=$0; sub("^" k ":[[:space:]]*", "", s); print s; exit }' "$2"; }

replay_init() {
  [ -n "$RB" ] && return 0
  BARE=$(abspath "$(git rev-parse --git-dir)") || { RMSG="replay: cannot resolve the bare repo path"; return 1; }
  RB=$(mktemp -d "$BARE/spine-replay.XXXXXX") || { RB=""; RMSG="replay: mktemp inside $BARE failed"; return 1; }
  trap 'rm -rf "$TMP" "$RB" "$RB.ct"' EXIT
  $REPLAY_ENV git init -q "$RB" || { RMSG="replay: git init failed"; return 1; }
  { echo "$BARE/objects"
    for Q in "${GIT_QUARANTINE_PATH:-}" "${GIT_OBJECT_DIRECTORY:-}"; do [ -n "$Q" ] && abspath "$Q"; done
  } | awk '!seen[$0]++' > "$RB/.git/objects/info/alternates"
  RG config core.hooksPath /dev/null && RG config remote.origin.url "$BARE" \
    && RG update-ref refs/remotes/origin/main "$MAIN" || { RMSG="replay: cannot configure $RB"; return 1; }
  RG cat-file -e "$MAIN^{commit}" || { RMSG="replay: main $MAIN unreadable through the alternates"; return 1; }
  return 0
}

# unit_blob <path> : the blob the replay will run at <path> must be main's (P1); prints it, or sets RMSG and fails
unit_blob() {
  UB=$(git hash-object "$RB/$1" 2>/dev/null); UW=$(git rev-parse -q --verify "$MAIN:$1" 2>/dev/null)
  [ -n "$UB" ] && [ "$UB" = "$UW" ] || { RMSG="replay: unit $1 in the replay is blob '${UB:-none}', main:$1 is '${UW:-none}' (never run a gate the push supplied)"; return 1; }
  echo "$UB"
}

# replay <sha> <owner> <branch> : run units (i) pre-commit, (ii) creed-scan --staged, (iii) gen-governance-index check on
#   one commit, code from current main. Units (iv) M6(ii) and (v) K4 run in trunk_k4/verify-range, (vi) in territory().
#   Sets RMSG on refusal; prints one REPLAY receipt line (unit blob shas + the seat-keys mode) on stderr on success.
replay() {
  RS="$1"; RO="$2"; RBR="$3"; RMSG=""
  replay_init || return 1
  set -- $(git rev-list --parents -n 1 "$RS"); shift
  [ $# -ge 1 ] || { RMSG="replay: $RS is a root commit; a spine branch never takes a new root"; return 1; }
  [ $# -le 2 ] || { RMSG="replay: $RS has $# parents (an octopus merge is never replayed)"; return 1; }
  RP1="$1"; RP2="${2:-}"
  # the pushed stamp is cross-checked against the KEY's lane, never trusted (resolve-lane reads it in unit (i))
  git show "$RS:_boot/BOOTSTRAP.md" > "$TMP/rboot" 2>/dev/null || { RMSG="replay: $RS carries no _boot/BOOTSTRAP.md"; return 1; }
  BL=$(boot_field lane "$TMP/rboot"); BW=$(boot_field worktree_branch "$TMP/rboot"); BS=$(boot_field spine_write "$TMP/rboot")
  [ "$BL" = "$RO" ] && [ "$BW" = "$RBR" ] && [ "$BS" = "$(class_of "$RO")" ] || {
    RMSG="replay: the commit's _boot/BOOTSTRAP.md stamps lane='$BL' branch='$BW' spine_write='$BS'; the pusher's row at main says lane='$RO' branch='$RBR' spine_write='$(class_of "$RO")'"; return 1; }
  # work tree := main's bytes, then the record overlay from the judged commit
  rm -rf "$RB/_ratification" "$RB/PENDING-SET.md" "$RB/_boot"
  RG read-tree "$MAIN" && RG checkout-index -a -f || { RMSG="replay: cannot check out main $MAIN"; return 1; }
  for OV in _ratification PENDING-SET.md _boot/BOOTSTRAP.md; do
    rm -rf "${RB:?}/$OV"
    git cat-file -e "$RS:$OV" 2>/dev/null || continue
    RG checkout "$RS" -- "$OV" || { RMSG="replay: cannot overlay $OV from $RS"; return 1; }
  done
  # refs: HEAD = <branch> at the first parent; a lane's `main` = current main, or an adopt merge's main-reachable 2nd parent
  RG update-ref "refs/heads/$RBR" "$RP1" && RG symbolic-ref HEAD "refs/heads/$RBR" || { RMSG="replay: cannot set HEAD"; return 1; }
  if [ "$RBR" != main ]; then
    TM="$MAIN"; [ -n "$RP2" ] && git merge-base --is-ancestor "$RP2" "$MAIN" 2>/dev/null && TM="$RP2"
    RG update-ref refs/heads/main "$TM" || { RMSG="replay: cannot set main"; return 1; }
  fi
  rm -f "$RB/.git/MERGE_HEAD"; [ -n "$RP2" ] && echo "$RP2" > "$RB/.git/MERGE_HEAD"
  RG read-tree "$RS" || { RMSG="replay: cannot load $RS into the index"; return 1; }
  # (i) the pre-commit unit (M6(i) set-coverage, D3 module-DENY, the ratify gate, the G-2 secret scan, K3 VERIFY-ONLY)
  B1=$(unit_blob agents/pre-commit-hook.sh) || return 1
  BK=$(unit_blob scripts/seat-keys.sh) || return 1
  (cd "$RB" && $REPLAY_ENV SEAT_KEYS_JUDGE_REF="$MAIN" bash agents/pre-commit-hook.sh) > "$TMP/u1" 2>&1 < /dev/null || {
    RMSG="unit pre-commit (main blob $B1): $(grep -E 'REJECT|REFUSED|FAIL|HALT' "$TMP/u1" | head -1)"; return 1; }
  grep -q '^SEAT-KEYS: hook-precommit VERIFY-ONLY PASS ' "$TMP/u1" || {
    RMSG="unit pre-commit (main blob $B1): seat-keys (blob $BK) did not run VERIFY-ONLY (never a pass)"; return 1; }
  # (ii) creed-scan --staged, message re-created from the commit (MERGE_HEAD above re-creates the merge flag).
  #   0490 R4(b): the seven gate-data tables judge at CURRENT main, never the pushed commit's copies: main's blobs are
  #   re-staged into the replay index (a table absent at main is removed, so its gate reads it as unreadable, never
  #   as the push's copy). A push that changes a table is judged by the table before it.
  B2=$(unit_blob scripts/creed-scan.sh) || return 1
  for GT in $GATE_TABLES; do
    if GE=$(git ls-tree "$MAIN" -- "$GT" | awk -F'\t' '{ split($1, a, " "); print a[1] "," a[3] }') && [ -n "$GE" ]; then
      RG update-index --add --cacheinfo "$GE,$GT" || { RMSG="replay: cannot stage main:$GT"; return 1; }
    else RG update-index --force-remove -- "$GT" || { RMSG="replay: cannot drop $GT from the index"; return 1; }; fi
  done
  git log -1 --format=%B "$RS" > "$TMP/msg" 2>/dev/null || { RMSG="replay: cannot read $RS's message"; return 1; }
  (cd "$RB" && $REPLAY_ENV lane="$RO" bash scripts/creed-scan.sh --staged --msg "$TMP/msg") > "$TMP/u2" 2>&1 < /dev/null; U2=$?
  [ "$U2" = 0 ] || { RMSG="unit creed-scan (main blob $B2; gate tables judged from main:_index/canon-class-triggers.tsv, main:_index/canon-section-map.tsv, main:_index/annotations.tsv) rc=$U2: $( { grep -E 'BREACH' "$TMP/u2" | head -1; grep -v '^[[:space:]]*$' "$TMP/u2" | tail -1; } | head -1)"; return 1; }
  # (iii) gen-governance-index check judges a TREE: main's script, run in a checkout of the judged commit
  B3=$(unit_blob scripts/gen-governance-index.sh) || return 1
  cp "$RB/scripts/gen-governance-index.sh" "$TMP/ggi" || { RMSG="replay: cannot stage unit (iii)"; return 1; }
  CT="$RB.ct"; rm -rf "$CT"
  BC=$(unit_blob scripts/canon-core.sh) || return 1
  RG worktree add -q --detach "$CT" "$RS" > /dev/null 2>&1 || { RMSG="replay: cannot check out $RS for unit (iii)"; return 1; }
  # the unit sources $REPO_ROOT/scripts/canon-core.sh: pin it to main's bytes too (code, never the judged tree's copy)
  mkdir -p "$CT/scripts" && cp "$RB/scripts/canon-core.sh" "$CT/scripts/canon-core.sh" || { RMSG="replay: cannot pin canon-core.sh for unit (iii)"; return 1; }
  (cd "$CT" && $REPLAY_ENV bash "$TMP/ggi" check) > "$TMP/u3" 2>&1 < /dev/null; U3=$?
  RG worktree remove --force "$CT" > /dev/null 2>&1; rm -rf "$CT"
  [ "$U3" = 0 ] || { RMSG="unit gen-governance-index check (main blob $B3) rc=$U3: $(grep -E 'DRIFT|FATAL|absent' "$TMP/u3" | head -1)"; return 1; }
  say "REPLAY $RS lane $RO: pre-commit $B1 · seat-keys $BK VERIFY-ONLY · creed-scan $B2 (gate tables from main) · gen-governance-index $B3 + canon-core $BC (git blob sha1, each == main:<path> at $MAIN)"
  return 0
}

verb_pre_receive() {
  [ "$(git rev-parse --is-bare-repository 2>/dev/null)" = true ] || halt "not running in a bare repository"
  PUSHER="${SPINE_PUSHER:-}"
  [ -n "$PUSHER" ] || refuse "(all refs) no pusher identity: SPINE_PUSHER is unset, so the push carries no seat-key lane"
  MAIN=$(git rev-parse -q --verify refs/heads/main) || halt "the spine has no refs/heads/main (seed it at install, never by a push)"
  load_trusted "$MAIN"
  [ -n "$(class_of "$PUSHER")" ] || refuse "(all refs) pusher '$PUSHER' is not a lane in the lane map at main $MAIN"
  N=0
  while read -r OLD NEW REF; do
    [ -n "$REF" ] || continue
    N=$((N + 1))
    case "$REF" in refs/heads/*) BR="${REF#refs/heads/}" ;; *) refuse "$REF only branches are pushed to the spine (pusher $PUSHER)" ;; esac
    if [ "$BR" = main ]; then OWNER="$TRUNK"; KIND=trunk
    else
      OWNER=$(awk -F'\t' -v b="$BR" '$2==b && b!="main" { print $1; exit }' "$TMP/lanes"); KIND=lane
      if [ -z "$OWNER" ]; then
        case "$BR" in foundation/*) OWNER="$TRUNK"; KIND=trunk-aux ;; *) refuse "$REF is not a lane branch in the lane map at main $MAIN, nor foundation/*" ;; esac
      fi
    fi
    [ "$PUSHER" = "$OWNER" ] || refuse "$REF belongs to lane '$OWNER'; the pusher is '$PUSHER' (per-lane branch protection)"
    if [ "$NEW" = "$ZERO" ]; then
      [ "$KIND" = trunk ] && refuse "$REF deletion of main"
      say "ACCEPT-DELETE $REF by its owner $OWNER"; continue
    fi
    if [ "$OLD" != "$ZERO" ]; then
      git merge-base --is-ancestor "$OLD" "$NEW" 2>/dev/null || refuse "$REF non-fast-forward ($OLD is not an ancestor of $NEW)"
    fi
    SIGNER="$OWNER"; [ "$KIND" = trunk-aux ] && SIGNER="$TRUNK"
    if [ "$KIND" = trunk ]; then
      SK verify-commit "$TRUNK" "$NEW" --ref "$MAIN" > "$TMP/k.tip" 2>&1 || refuse "$REF the new main tip is not trunk-signed: $(tail -1 "$TMP/k.tip")"
    fi
    git rev-list "$NEW" --not --all > "$TMP/new" 2>"$TMP/rl.err" || halt "$REF rev-list failed: $(head -1 "$TMP/rl.err")"
    NC=$(grep -c . "$TMP/new")
    if [ "$KIND" = trunk-aux ]; then
      # 0489 R7: K4 (trunk key) + fast-forward or creation (above) + the candidate predicate. No other unit runs.
      SK verify-range "$TRUNK" "$NEW" --not --all --ref "$MAIN" > "$TMP/k.rng" 2>&1 || refuse "$REF K4: $(tail -1 "$TMP/k.rng")"
      candidate_ok "$NEW" || refuse "$REF $CMSG"
    else
      if [ "$KIND" = trunk ]; then trunk_k4 "$NEW" || refuse "$REF $KMSG"
      else SK verify-range "$OWNER" "$NEW" --not --all --ref "$MAIN" > "$TMP/k.rng" 2>&1 || refuse "$REF K4: $(tail -1 "$TMP/k.rng")"; fi
      while IFS= read -r S; do
        [ -n "$S" ] || continue
        territory "$S" "$OWNER" || refuse "$REF territory: $TMSG"
        replay "$S" "$OWNER" "$BR" || refuse "$REF $S: $RMSG"
      done < "$TMP/new"
    fi
    say "ACCEPT $REF $OLD..$NEW by $PUSHER: $NC new commit(s), signed by $SIGNER, judged at main $MAIN"
  done
  [ "$N" -gt 0 ] || refuse "(all refs) empty push"
  exit 0
}

verb_post_receive() {
  git remote get-url mirror > /dev/null 2>&1 || { say "MIRROR-PUSH-FAILED (all refs) no 'mirror' remote configured; nothing mirrored"; log_fail "no-mirror-remote" "-"; exit 0; }
  SPECS=""
  while read -r OLD NEW REF; do
    [ -n "$REF" ] || continue
    if [ "$NEW" = "$ZERO" ]; then SPECS="$SPECS :$REF"; else SPECS="$SPECS $NEW:$REF"; fi
  done
  [ -n "$SPECS" ] || exit 0
  # never --force, never --mirror: a ref someone moved on GitHub makes this push refuse (0420 T3', inv #5)
  if git push --porcelain mirror $SPECS > "$TMP/mirror.out" 2>&1; then say "MIRRORED$SPECS"; exit 0; fi
  # Two classes, each said and logged under its own name (inv #5: a transport failure is never called a divergence):
  #   MIRROR-DIVERGENCE   a porcelain ref line '!' whose status is [rejected]: the mirror's ref moved (non-fast-forward,
  #                       fetch first). The mirror was reached and refused the update on history.
  #   MIRROR-PUSH-FAILED  anything else: a '!' line whose status is [remote rejected] or [remote failure] (an unpacker
  #                       error, a remote hook), or no ref line at all (fatal: not a repository, unreachable, transport died).
  DETAIL=$(grep -E '^(remote: )?(fatal|error)' "$TMP/mirror.out" | grep -v 'failed to push some refs' | head -2 | tr '\n' ' ')
  [ -n "$DETAIL" ] || DETAIL=$(tail -1 "$TMP/mirror.out")
  grep '^!' "$TMP/mirror.out" > "$TMP/mirror.bang"
  : > "$TMP/mirror.div"; : > "$TMP/mirror.fail"
  while IFS= read -r L; do
    case "$L" in
      *'[rejected]'*) echo "$L" >> "$TMP/mirror.div"; say "MIRROR-DIVERGENCE $L" ;;
      *)              echo "$L" >> "$TMP/mirror.fail"; say "MIRROR-PUSH-FAILED $L :: $DETAIL" ;;
    esac
  done < "$TMP/mirror.bang"
  if [ ! -s "$TMP/mirror.bang" ]; then echo "(all refs)" > "$TMP/mirror.fail"; say "MIRROR-PUSH-FAILED (all refs) no ref was reported :: $DETAIL"; fi
  [ -s "$TMP/mirror.div" ] && log_div "push-refused" "$(tr '\n' ' ' < "$TMP/mirror.div")"
  [ -s "$TMP/mirror.fail" ] && log_fail "push-failed" "$(tr '\n' ' ' < "$TMP/mirror.fail")$DETAIL"
  exit 0   # githooks(5): post-receive cannot change the push outcome; either class is surfaced, never forced
}
log_div()  { printf '%s\tMIRROR-DIVERGENCE\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "$2" >> "$(git rev-parse --git-dir)/spine-mirror-divergence.log"; }
log_fail() { printf '%s\tMIRROR-PUSH-FAILED\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "$2" >> "$(git rev-parse --git-dir)/spine-mirror-push-failed.log"; }

verb_install() {
  B="${1:-}"; [ -n "$B" ] && [ "$(git -C "$B" rev-parse --is-bare-repository 2>/dev/null)" = true ] || halt "usage: install <bare-repo>"
  git -C "$B" show "refs/heads/main:$SELF_PATH" > "$TMP/self" 2>/dev/null || halt "cannot read $SELF_PATH at $B's main"
  for H in pre-receive post-receive; do cp "$TMP/self" "$B/hooks/$H" && chmod 0755 "$B/hooks/$H" || halt "cannot write $B/hooks/$H"; done
  while read -r K V; do git -C "$B" config --local "$K" "$V" || halt "cannot set $K=$V in $B's own config"; done <<EOF
$MAINT_PIN
EOF
  verb_readback "$B"
}

# the automatic-maintenance pin: key, then the exact value readback wants
MAINT_PIN="receive.autogc false
maintenance.auto false
gc.auto 0"

verb_readback() {
  B="${1:-}"; [ -n "$B" ] || halt "usage: readback <bare-repo>"
  WANT=$(git -C "$B" rev-parse -q --verify "refs/heads/main:$SELF_PATH") || { echo "SPINE-RECEIVE: readback FAIL no $SELF_PATH at main"; exit 1; }
  for H in pre-receive post-receive; do
    [ -f "$B/hooks/$H" ] || { echo "SPINE-RECEIVE: readback FAIL $H not installed"; exit 1; }
    GOT=$(git hash-object "$B/hooks/$H")
    [ "$GOT" = "$WANT" ] || { echo "SPINE-RECEIVE: readback FAIL $H blob $GOT != main:$SELF_PATH blob $WANT"; exit 1; }
  done
  PINS=""
  while read -r K V; do
    GOTV=$(git -C "$B" config --local --get "$K") || GOTV=unset
    [ "$GOTV" = "$V" ] || { echo "SPINE-RECEIVE: readback FAIL $K $GOTV != $V"; exit 1; }
    PINS="$PINS $K=$GOTV"
  done <<EOF
$MAINT_PIN
EOF
  echo "SPINE-RECEIVE: readback PASS pre-receive and post-receive blob $WANT == main:$SELF_PATH (git blob sha1);$PINS"
}

verb_maintain() {
  B="${1:-}"; [ -n "$B" ] && [ "$(git -C "$B" rev-parse --is-bare-repository 2>/dev/null)" = true ] || halt "usage: maintain <bare-repo>"
  LC_ALL=C git -C "$B" maintenance run --no-quiet --task=commit-graph --task=loose-objects --task=incremental-repack \
    > "$TMP/maint.out" 2> "$TMP/maint.err"; MRC=$?
  if grep -q "skipping maintenance" "$TMP/maint.err"; then
    echo "SPINE-RECEIVE: maintain LOCKED $(date -u +%Y-%m-%dT%H:%M:%SZ) another maintenance run holds $B's object-database lock; nothing ran"; exit 3
  fi
  [ "$MRC" = 0 ] || { echo "SPINE-RECEIVE: maintain FAIL $(date -u +%Y-%m-%dT%H:%M:%SZ) git maintenance run rc=$MRC: $(tail -1 "$TMP/maint.err")"; exit 1; }
  echo "SPINE-RECEIVE: maintain PASS $(date -u +%Y-%m-%dT%H:%M:%SZ) tasks commit-graph loose-objects incremental-repack"
}

# plist <bare> <user> : the scheduler job. It runs main's copy of this file (as install does), daily at 03:17 local time
#   (StartCalendarInterval: a run missed while the machine sleeps starts at wake); launchd never starts a second instance
#   of a running job, and git's lock covers anything else. Output and errors go to <bare>/spine-maintain.log.
MAINT_LABEL=local.spine-receive.maintain
verb_plist() {
  B="${1:-}"; U="${2:-}"; [ -n "$B" ] && [ -n "$U" ] || halt "usage: plist <bare-repo> <user>"
  case "$B$U" in *[!A-Za-z0-9/._-]*) halt "plist: the path and user must be [A-Za-z0-9/._-] only (they are written into XML)" ;; esac
  case "$B" in /*) ;; *) halt "plist: <bare-repo> must be an absolute path (launchd has no working directory)" ;; esac
  GITBIN=$(command -v git) || halt "plist: git is not on PATH"
  cat <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$MAINT_LABEL</string>
  <key>UserName</key><string>$U</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/sh</string><string>-c</string>
    <string>f=\$(mktemp) &amp;&amp; "\$1" -C "\$0" show refs/heads/main:$SELF_PATH &gt; "\$f" &amp;&amp; /bin/bash "\$f" maintain "\$0"; rc=\$?; rm -f "\$f"; exit \$rc</string>
    <string>$B</string><string>$GITBIN</string>
  </array>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>${GITBIN%/*}:/usr/bin:/bin:/usr/sbin:/sbin</string></dict>
  <key>StartCalendarInterval</key><dict><key>Hour</key><integer>3</integer><key>Minute</key><integer>17</integer></dict>
  <key>ProcessType</key><string>Background</string>
  <key>StandardOutPath</key><string>$B/spine-maintain.log</string>
  <key>StandardErrorPath</key><string>$B/spine-maintain.log</string>
</dict>
</plist>
EOF
}

case "$(basename "$0")" in
  pre-receive)  verb_pre_receive ;;
  post-receive) verb_post_receive ;;
  *) V="${1:-}"; shift || true
     case "$V" in
       pre-receive) verb_pre_receive ;; post-receive) verb_post_receive ;;
       install) verb_install "$@" ;; readback) verb_readback "$@" ;;
       maintain) verb_maintain "$@" ;; plist) verb_plist "$@" ;;
       *) halt "unknown verb '$V'; use pre-receive|post-receive|install <bare>|readback <bare>|maintain <bare>|plist <bare> <user>" ;;
     esac ;;
esac
