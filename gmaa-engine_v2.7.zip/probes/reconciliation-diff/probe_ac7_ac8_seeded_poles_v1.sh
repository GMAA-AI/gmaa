#!/usr/bin/env bash
# SET-0007 — the four outstanding acceptance poles.
#   AC7 needs 6 RED poles, one per direction per surface. THREE are already demonstrated RED on
#   LIVE data (manifest D1=80 · pending-set D2=2 · origin-engine D2=1). The three below are the
#   ones that cannot occur in the live tree and must therefore be SEEDED:
#     P1  manifest      DIRECTION 2   P2  pending-set  DIRECTION 1   P3  origin-engine DIRECTION 1
#   AC8 is the content-not-ancestry pole: byte-identical sides RECONCILE (exit 0) even with no
#   shared git history at all — the defect foundation's own governance probe had to be corrected on.
# DISC-PROBE-INPUT-PROVENANCE: every fixture is synthetic and isolated; a synthetic result proves
#   the synthetic case, which is exactly what a seen-to-fail pole requires.
set -uo pipefail
SRC="$(git rev-parse --show-toplevel)"
RD="$SRC/scripts/reconciliation-diff.sh"
# the fixture's spine ref is the ONE resolver's output of the tree under test (the one spine-ref resolver), never a literal;
# the resolver travels into each fixture (the reconciler resolves its default GOV_REF through it).
SR="$(bash "$SRC/scripts/spine-ref.sh")" && [ -n "$SR" ] \
  || { echo "UNREADABLE: SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled in the tree under test (the one spine-ref resolver)"; exit 3; }
P=0; F=0
ok(){ echo "  PASS  $1"; P=$((P+1)); }
no(){ echo "  FAIL  $1"; F=$((F+1)); }

newtree() {                     # $1 = dir; make an isolated repo whose origin/* point at itself
  git init -q "$1"; git -C "$1" config user.email a@b.c; git -C "$1" config user.name t
  # the spine ref's remote exists and is the repo itself, so the reconciler's one-remote fetch (0507 R3) reads FRESH
  git -C "$1" remote add "${SR%%/*}" "$1"
  mkdir -p "$1/scripts" && cp "$SRC/scripts/spine-ref.sh" "$1/scripts/spine-ref.sh"
}
seal() {                        # $1 = dir; commit + point the spine ref and origin/architect at HEAD
  git -C "$1" add -A >/dev/null 2>&1
  git -C "$1" commit -qm fixture >/dev/null 2>&1
  git -C "$1" update-ref "refs/remotes/$SR" HEAD
  git -C "$1" update-ref refs/remotes/origin/architect HEAD
}

# ---------- P1 · manifest DIRECTION 2 — a reply landed with NO producer file in the outbox -------
T1="$(mktemp -d)"; newtree "$T1"
mkdir -p "$T1/_orchestration/relay-outbox/architect" "$T1/_orchestration/relay-inbox/architect"
echo x > "$T1/_orchestration/relay-outbox/architect/2026-09-07-101-a-real-producer.md"
echo x > "$T1/_orchestration/relay-inbox/architect/2026-09-07-foundation-999-105-REAPED-orphan.md"
seal "$T1"
cp "$RD" "$T1/rd.sh"
cp "$SRC/scripts/canon-core.sh" "$T1/canon-core.sh"   # NOTE: shared resolver
cp "$SRC/scripts/spine-ref.sh" "$T1/spine-ref.sh"   # the spine-ref resolver travels with rd.sh (0507 R2: found beside the running script)
o="$(cd "$T1" && bash ./rd.sh --surface manifest --no-fetch 2>&1)"; r=$?
if [ "$r" -eq 2 ] && printf '%s' "$o" | grep -A3 -i 'DIRECTION 2' | grep -q 'architect-''105'; then
  ok "AC7-P1 manifest D2 seeded -> exit 2, named under DIRECTION 2"
else
  no "AC7-P1 manifest D2 (exit=$r)"; printf '%s\n' "$o" | grep -i -A2 'DIRECTION 2' | head -4
fi
rm -rf "$T1"

# ---------- P5 · manifest grammar is DATE-SHAPED, never a literal year ---
# A 2027-dated producer with NO reply must be NAMED under DIRECTION 1. Under the old `^2026-` grammar the
# name matched nothing, so the producer was INVISIBLE and the surface read clean — a false green.
T5="$(mktemp -d)"; newtree "$T5"
mkdir -p "$T5/_orchestration/relay-outbox/architect" "$T5/_orchestration/relay-inbox/architect"
echo x > "$T5/_orchestration/relay-outbox/architect/2027-01-01-201-a-future-year-producer.md"
echo x > "$T5/_orchestration/relay-inbox/architect/.gitkeep"
seal "$T5"
cp "$RD" "$T5/rd.sh"
cp "$SRC/scripts/canon-core.sh" "$T5/canon-core.sh"
cp "$SRC/scripts/spine-ref.sh" "$T5/spine-ref.sh"   # the spine-ref resolver travels with rd.sh (0507 R2: found beside the running script)
o="$(cd "$T5" && bash ./rd.sh --surface manifest --no-fetch 2>&1)"; r=$?
if [ "$r" -eq 2 ] && printf '%s' "$o" | grep -A3 -i 'DIRECTION 1' | grep -q 'architect-''201'; then
  ok "AC7-P5 manifest 2027-dated producer -> exit 2, named under DIRECTION 1 (grammar is date-shaped)"
else
  no "AC7-P5 manifest 2027-dated producer (exit=$r)"; printf '%s\n' "$o" | grep -i -A2 'DIRECTION 1' | head -4
fi
rm -rf "$T5"

# ---------- P2 · pending-set DIRECTION 1 — a packet declares a member with NO criteria file ------
T2="$(mktemp -d)"; newtree "$T2"
mkdir -p "$T2/_ratification/criteria"
printf '## MEMBERS\n- orphan-member · lane=foundation · main@abc · surfaces: scripts/<x>.sh\n\n## NEXT\n' > "$T2/_ratification/SET-0001.md"
echo "# unrelated" > "$T2/_ratification/criteria/something-else.md"
seal "$T2"
cp "$RD" "$T2/rd.sh"
cp "$SRC/scripts/canon-core.sh" "$T2/canon-core.sh"   # NOTE: shared resolver
cp "$SRC/scripts/spine-ref.sh" "$T2/spine-ref.sh"   # the spine-ref resolver travels with rd.sh (0507 R2: found beside the running script)
o="$(cd "$T2" && bash ./rd.sh --surface pending-set --no-fetch 2>&1)"; r=$?
if [ "$r" -eq 2 ] && printf '%s' "$o" | grep -A3 -i 'DIRECTION 1' | grep -q 'orphan-member'; then
  ok "AC7-P2 pending-set D1 seeded -> exit 2, named under DIRECTION 1"
else
  no "AC7-P2 pending-set D1 (exit=$r)"; printf '%s\n' "$o" | grep -i -A2 'DIRECTION 1' | head -4
fi
rm -rf "$T2"

# ---------- P3 · origin-engine DIRECTION 1 — canon BODY diverges --------------------------------
T3="$(mktemp -d)"; newtree "$T3"; E3="$(mktemp -d)"
printf '# Canon\n**v1.6.1**\n**CONFIDENTIAL**\nBODY-ORIGIN\n' > "$T3/GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1.md"
mkdir -p "$T3/.claude"; printf '{"defaultMode":"acceptEdits"}\n' > "$T3/.claude/settings.json"
seal "$T3"
printf '# Canon\n**v1.6.1**\n**CC BY 4.0**\nBODY-ENGINE-DIFFERENT\n' > "$E3/GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1.md"
mkdir -p "$E3/.claude"; printf '{"defaultMode":"acceptEdits"}\n' > "$E3/.claude/settings.json"
cp "$RD" "$T3/rd.sh"
cp "$SRC/scripts/canon-core.sh" "$T3/canon-core.sh"   # NOTE: shared resolver
cp "$SRC/scripts/spine-ref.sh" "$T3/spine-ref.sh"   # the spine-ref resolver travels with rd.sh (0507 R2: found beside the running script)
o="$(cd "$T3" && bash ./rd.sh --surface origin-engine --no-fetch --engine-root "$E3" 2>&1)"; r=$?
if [ "$r" -eq 2 ] && printf '%s' "$o" | grep -A3 -i 'DIRECTION 1' | grep -qi 'canon body diverges'; then
  ok "AC7-P3 origin-engine D1 seeded -> exit 2, named under DIRECTION 1"
else
  no "AC7-P3 origin-engine D1 (exit=$r)"; printf '%s\n' "$o" | grep -i -A2 'DIRECTION 1' | head -4
fi
rm -rf "$T3" "$E3"

# ---------- AC8 · CONTENT NOT ANCESTRY — identical bytes, ZERO shared history -> exit 0 ----------
T4="$(mktemp -d)"; newtree "$T4"; E4="$(mktemp -d)"; newtree "$E4"
BODY='# Canon
**v1.6.1**
POSTURE-LINE
IDENTICAL-BODY-LINE-1
IDENTICAL-BODY-LINE-2'
printf '%s\n' "$BODY" > "$T4/GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1.md"
mkdir -p "$T4/.claude"; printf '{"defaultMode":"acceptEdits"}\n' > "$T4/.claude/settings.json"
seal "$T4"
# engine: byte-identical from line 4 (line 3 posture differs BY DESIGN), and a wholly separate history
printf '%s\n' "$BODY" | sed '3s/.*/DIFFERENT-POSTURE-BY-DESIGN/' > "$E4/GOVERNED_MULTI_AGENT_ARCHITECTURE_v1_6_1.md"
mkdir -p "$E4/.claude"; printf '{"defaultMode":"acceptEdits"}\n' > "$E4/.claude/settings.json"
seal "$E4"
cp "$RD" "$T4/rd.sh"
cp "$SRC/scripts/canon-core.sh" "$T4/canon-core.sh"   # NOTE: shared resolver
cp "$SRC/scripts/spine-ref.sh" "$T4/spine-ref.sh"   # the spine-ref resolver travels with rd.sh (0507 R2: found beside the running script)
o="$(cd "$T4" && bash ./rd.sh --surface origin-engine --engine-root "$E4" 2>&1)"; r=$?
if [ "$r" -eq 0 ]; then
  ok "AC8 content-not-ancestry: identical bytes + ZERO shared history -> exit 0 (RECONCILED)"
else
  no "AC8 content-not-ancestry (exit=$r, expected 0)"; printf '%s\n' "$o" | tail -6
fi
rm -rf "$T4" "$E4"

echo "POLES: $P pass / $F fail"
[ "$F" -eq 0 ] || exit 1
