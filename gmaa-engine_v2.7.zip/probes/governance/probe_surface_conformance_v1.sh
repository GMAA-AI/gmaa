#!/usr/bin/env bash
# probe_surface_conformance_v1.sh — the SURFACE-CONFORMANCE probe (checks A1–A8).
# Canon v1.6.5 §4 :158 (WRITTEN-IS-NOT-WIRED's compensating control; the STATE-PRE-GENESIS row in
# contracts/CONSTANTS.md §4 names THIS path as its compensating control — boot-check.sh (4b) keys on it).
#
# WHAT IT MEASURES: for every git worktree (git worktree list × each worktree's _boot/BOOTSTRAP.md stamp,
# NEVER seats.yaml — A2), the ON-DISK bytes of every surface that is READ FROM THE WORKTREE (A4) against the
# reference that surface is supposed to carry (A3): lane worktrees → origin/main; the trunk worktree (main) →
# its own HEAD, with HEAD-vs-origin/main reported as UNPUSHED (info, never RED).
#
# THE PREDICATE (A1) is boot-check.sh's _hook_state generalised: git BLOB ids, never shasum of a git show that
# may have failed. CURRENT | DRIFT | ABSENT | NO-SOURCE, plus the two canon verdicts:
#   EXTERNAL     the reference tracks a symlink (mode 120000) and the worktree's link resolves OUTSIDE the
#                worktree root — "the trunk reference tracks the link, not its target" (canon :158)
#   RULES-STALE  _boot/BOOTSTRAP.md `rules_manifest:` ≠ the rules-manifest hash computed from the REFERENCE's
#                bytes by scripts/rules_manifest.sh (reused verbatim — the ratified rule-currency hash)
# and two info verdicts: SPINE-READ (disciplines.md — read from origin/main by boot-check/creed-scan-spine,
# so a branch copy is not an executing surface; still row-reported with both §0 roster counts, which
# satisfies that requirement by subsumption — A7) and UNPUSHED (trunk ahead of origin/main).
#
# SUBJECTS (A4; derived from the REFERENCE tree each run, denominator printed — never a hand list):
#   .claude/agents/* · .claude/settings.json · CLAUDE.md · scripts/*.sh · agents/*hook.sh · the CURRENT
#   canon (version-sort, _PUBLIC excluded — one rule shared with governance.sh) · contracts/*.md ·
#   every _knowledge/ entry (68 of 98 are mode 120000 at origin/main on 2026-09-23 — the built-in EXTERNAL
#   positive control) · disciplines.md (SPINE-READ) · _boot rules_manifest (RULES-STALE) · and ONE fleet
#   row per INSTALLED shared hook ($GIT_COMMON_DIR/hooks/{pre-commit,pre-merge-commit,commit-msg}).
#
# OUTPUT (A5): one `SURFACE-CONFORM: worktree=… lane=… ref=… subject=… worktree=<blob8> canonical=<blob8>
# verdict=…` row per measurement, RED rows first; a denominator line; `VERDICT: PASS` exit 0 iff no
# DRIFT|ABSENT|EXTERNAL|RULES-STALE row, else `VERDICT: FAIL` exit 1. The reference unreadable or
# `git worktree list` failing ⇒ `SURFACE-CONFORM: UNREADABLE …` exit 3 and NO VERDICT line
# (DISC-CHILD-FAILURE-MUST-SURFACE) — never a clean-looking pass.
#
# SUBSUMES probes/governance/probe_governance_fleet_divergence_v1.sh (A4, ruled): that probe compared
# BRANCH content (axis 1, closed as not-a-deficit) and hardcoded a canon four editions
# stale; it is retired to a pointer stub in the same set.
#
# Usage: probe_surface_conformance_v1.sh [--ref <spine-ref>] [--red-only] [--worktree <path>]...
#   --ref        reference for lane worktrees (default origin/main; SURFACE_REF env also honoured)
#   --red-only   print only RED rows + denominator + verdict (boot-check's view; the counts are unchanged)
#   --worktree   restrict to the named worktree path(s) (repeatable); default = every `git worktree list` entry
# Exit: 0 PASS · 1 FAIL · 3 UNREADABLE (no verdict). bash 3.2-safe (macOS /bin/bash).
set -u

REF="${SURFACE_REF:-}"; RED_ONLY=0; ONLY=()
while [ $# -gt 0 ]; do
  case "$1" in
    --ref) case "${2:-}" in ""|--*) echo "usage: $0: --ref needs a value" >&2; exit 1 ;; esac; REF="${2:-}"; shift 2 ;;
    --red-only) RED_ONLY=1; shift ;;
    --worktree) case "${2:-}" in ""|--*) echo "usage: $0: --worktree needs a value" >&2; exit 1 ;; esac; ONLY+=("$(cd "${2:-.}" 2>/dev/null && pwd -P)"); shift 2 ;;
    *) echo "usage: $0 [--ref <ref>] [--red-only] [--worktree <path>]..."; exit 1 ;;
  esac
done

unreadable() { echo "SURFACE-CONFORM: UNREADABLE — $* (exit 3; this is NOT a verdict — DISC-CHILD-FAILURE-MUST-SURFACE)"; exit 3; }

ANCHOR="$(git rev-parse --show-toplevel 2>/dev/null)" || unreadable "not inside a git worktree"
# the spine ref and the trunk name come from the ONE resolver (the one spine-ref resolver): REF defaults to its output (--ref and
# SURFACE_REF stay as replica knobs); the trunk worktree is the one on its branch half. Unresolvable = UNREADABLE, named.
SPINE_REF="$(bash "$ANCHOR/scripts/spine-ref.sh")" && [ -n "$SPINE_REF" ] || unreadable "SPINE-REF-UNRESOLVED: scripts/spine-ref.sh missing or unfilled (the one spine-ref resolver)"
TRUNK="${SPINE_REF#origin/}"
[ -n "$REF" ] || REF="$SPINE_REF"
REF_SHA="$(git -C "$ANCHOR" rev-parse -q --verify "${REF}^{commit}" 2>/dev/null)" || unreadable "reference '${REF}' cannot be read"
WT_LIST="$(git -C "$ANCHOR" worktree list --porcelain 2>/dev/null)" || unreadable "git worktree list failed"
[ -n "$WT_LIST" ] || unreadable "git worktree list returned nothing"
COMMON="$(cd "$ANCHOR" && cd "$(git rev-parse --git-common-dir)" && pwd -P)" || unreadable "git common dir unresolvable"
HOOKS_DIR="$(git -C "$ANCHOR" config core.hooksPath 2>/dev/null || true)"; [ -n "$HOOKS_DIR" ] || HOOKS_DIR="$COMMON/hooks"

TMP="$(mktemp -d "${TMPDIR:-/tmp}/surfconf.XXXXXX")" || unreadable "mktemp failed"
trap 'rm -rf "$TMP"' EXIT
RED="$TMP/red"; GREEN="$TMP/green"; : > "$RED"; : > "$GREEN"
NROWS=0; NWT=0; NSUBJ_REF=0; NSUBJ_HEAD=""

emit() {  # emit <wt-name> <lane> <ref-label> <subject> <wt-blob> <canon-blob> <verdict> [note]
  local line="SURFACE-CONFORM: worktree=$1 lane=$2 ref=$3 subject=$4 worktree=${5:0:8} canonical=${6:0:8} verdict=$7${8:+ ($8)}"
  NROWS=$((NROWS+1))
  case "$7" in DRIFT|ABSENT|EXTERNAL|RULES-STALE|UNREACHABLE) echo "$line" >> "$RED" ;; *) echo "$line" >> "$GREEN" ;; esac
}

# Subject set at a given commit (A4). One canon rule shared with governance.sh: anchored, _PUBLIC excluded, sort -V.
subjects_at() {  # subjects_at <sha>  → "<mode> <blob> <path>" lines
  local sha="$1" canon
  canon="$(git -C "$ANCHOR" ls-tree -r --name-only "$sha" 2>/dev/null | grep -E '^GOVERNED_MULTI_AGENT_ARCHITECTURE_v[0-9_]+\.md$' | sort -V | tail -1)"
  git -C "$ANCHOR" ls-tree -r "$sha" 2>/dev/null | awk -v canon="$canon" '
    { split($0, a, "\t"); split(a[1], m, " "); p = a[2]
      if (p ~ /^\.claude\/agents\/[^\/]+$/ || p == ".claude/settings.json" || p == "CLAUDE.md" ||
          p ~ /^scripts\/[^\/]+\.sh$/ || p ~ /^agents\/[^\/]*hook\.sh$/ || (canon != "" && p == canon) ||
          p ~ /^contracts\/[^\/]+\.md$/ || p ~ /^_knowledge\// )
        print m[1] " " m[3] " " p }'
}

# The rules-manifest hash as the REFERENCE would compute it: run the reference's own rules_manifest.sh over the
# reference's own four source files, in a non-git temp root (the script falls back to pwd outside a repo).
rules_hash_at() {  # rules_hash_at <sha>
  local d="$TMP/rm.$1" f
  [ -f "$TMP/rmhash.$1" ] && { cat "$TMP/rmhash.$1"; return; }
  mkdir -p "$d/scripts" "$d/agents" "$d/_knowledge"
  for f in scripts/rules_manifest.sh agents/pre-commit-hook.sh scripts/resolve-lane.sh _knowledge/COORDINATION.md; do
    git -C "$ANCHOR" show "$1:$f" > "$d/$f" 2>/dev/null || { echo ""; return; }
  done
  ( cd "$d" && GIT_CEILING_DIRECTORIES="$TMP" bash scripts/rules_manifest.sh 2>/dev/null ) > "$TMP/rmhash.$1"
  cat "$TMP/rmhash.$1"
}

# Layout-agnostic: the registry body is under §R on the spine and
# under §0 on a branch that predates the move; §0 is now a bullet-free stub, so counting both windows is exact.
roster_count() { awk '/^## §(0|R)([^0-9A-Za-z]|$)/{f=1;next} /^## /{f=0} f' | grep -c '^- \*\*'; }

# ── per-worktree measurement ─────────────────────────────────────────────────────────────────────────────
measure_worktree() {  # measure_worktree <path> <branch>
  local wt="$1" branch="$2" name lane rsha rlabel rows f mode blob p wblob tgt abs stamp canon_rm
  name="$(basename "$wt")"; case "$wt" in */.claude/worktrees/*) name="nested:$(basename "$wt" | cut -c1-14)";; esac
  NWT=$((NWT+1))
  # A2 keying: stamp ↔ branch through the P4 resolver (trunk's copy — the resolver IS a subject; the rule is not re-implemented here).
  if [ ! -f "$wt/_boot/BOOTSTRAP.md" ]; then
    emit "$name" "UNSTAMPED" "-" "_boot/BOOTSTRAP.md" "-" "-" "ABSENT" "no _boot stamp — identity unresolvable (A2)"; return
  fi
  lane="$(GIT_WORK_TREE="$wt" bash "$ANCHOR/scripts/resolve-lane.sh" 2>/dev/null | sed -n 's/^lane=\([^ ]*\) .*/\1/p' | head -1)"
  if [ -z "$lane" ]; then
    lane="$(awk '/^---/{d++;next} d==1 && /^lane:/{sub(/^lane:[[:space:]]*/,"");print;exit}' "$wt/_boot/BOOTSTRAP.md")"
    emit "$name" "${lane:-?}" "-" "_boot/BOOTSTRAP.md" "-" "-" "DRIFT" "stamp lane '${lane:-?}' does not resolve on branch '${branch}' (resolve-lane.sh LANE-MISMATCH)"
    lane="${lane:-?}!mismatch"
  fi
  # A3 reference by which surface reads it.
  if [ "$branch" = "$TRUNK" ]; then
    rsha="$(git -C "$wt" rev-parse HEAD 2>/dev/null)"; rlabel="HEAD"
    local ahead; ahead="$(git -C "$wt" rev-list --count "${REF_SHA}..HEAD" 2>/dev/null || echo 0)"
    [ "${ahead:-0}" -gt 0 ] && emit "$name" "$lane" "$rlabel" "HEAD..${REF}" "$(git -C "$wt" rev-parse --short=8 HEAD)" "${REF_SHA:0:8}" "UNPUSHED" "UNPUSHED ${ahead} — trunk ahead of ${REF}; info, never RED (A3)"
  else
    rsha="$REF_SHA"; rlabel="$REF"
  fi
  rows="$TMP/subj.$NWT"; subjects_at "$rsha" > "$rows"
  [ "$rlabel" = "$REF" ] && NSUBJ_REF="$(wc -l < "$rows" | tr -d ' ')"
  # the trunk worktree is measured at its own HEAD (A3), so a --worktree run over the trunk alone measured 0 subjects
  # at ${REF}; print the frame that WAS measured (window-plan row 16; DISC-A-NUMBER-CARRIES-ITS-FRAME)
  [ "$rlabel" = HEAD ] && NSUBJ_HEAD="$(wc -l < "$rows" | tr -d ' ') subjects at HEAD (${rsha:0:8})"
  # Regular-file subjects: hash in ONE batch per worktree.
  : > "$TMP/paths.$NWT"
  while read -r mode blob p; do
    [ "$mode" = "120000" ] && continue
    [ -f "$wt/$p" ] && [ ! -L "$wt/$p" ] && echo "$p" >> "$TMP/paths.$NWT"
  done < "$rows"
  ( cd "$wt" && git hash-object --stdin-paths < "$TMP/paths.$NWT" 2>/dev/null ) > "$TMP/hash.$NWT"
  paste -d' ' "$TMP/paths.$NWT" "$TMP/hash.$NWT" > "$TMP/ph.$NWT"
  while read -r mode blob p; do
    if [ "$mode" = "120000" ]; then
      if [ -L "$wt/$p" ]; then
        tgt="$(readlink "$wt/$p")"; case "$tgt" in /*) abs="$tgt";; *) abs="$(cd "$(dirname "$wt/$p")" 2>/dev/null && pwd -P)/$tgt";; esac
        wblob="$(printf '%s' "$tgt" | git hash-object --stdin)"
        case "$abs" in
          "$wt"/*) if [ "$wblob" = "$blob" ]; then emit "$name" "$lane" "$rlabel" "$p" "$wblob" "$blob" "CURRENT"; else emit "$name" "$lane" "$rlabel" "$p" "$wblob" "$blob" "DRIFT" "link target differs"; fi ;;
          *) emit "$name" "$lane" "$rlabel" "$p" "$wblob" "$blob" "EXTERNAL" "link resolves outside the worktree: ${tgt}" ;;
        esac
      elif [ -e "$wt/$p" ]; then emit "$name" "$lane" "$rlabel" "$p" "-" "$blob" "DRIFT" "reference is a symlink; worktree has a regular file"
      else emit "$name" "$lane" "$rlabel" "$p" "-" "$blob" "ABSENT"; fi
      continue
    fi
    if [ -L "$wt/$p" ]; then emit "$name" "$lane" "$rlabel" "$p" "-" "$blob" "DRIFT" "worktree has a symlink; reference is a regular file"; continue; fi
    wblob="$(awk -v p="$p" '$1==p{print $2; exit}' "$TMP/ph.$NWT")"
    if [ -z "$wblob" ]; then emit "$name" "$lane" "$rlabel" "$p" "-" "$blob" "ABSENT"
    elif [ "$wblob" = "$blob" ]; then emit "$name" "$lane" "$rlabel" "$p" "$wblob" "$blob" "CURRENT"
    else emit "$name" "$lane" "$rlabel" "$p" "$wblob" "$blob" "DRIFT"; fi
  done < "$rows"
  # disciplines.md — SPINE-READ (info), both roster counts named (A7).
  local dref dwt nref nwt
  dref="$(git -C "$ANCHOR" rev-parse -q --verify "${REF_SHA}:disciplines.md" 2>/dev/null)"
  if [ -n "$dref" ]; then
    nref="$(git -C "$ANCHOR" show "${REF_SHA}:disciplines.md" | roster_count)"
    if [ -f "$wt/disciplines.md" ]; then dwt="$(git hash-object "$wt/disciplines.md")"; nwt="$(roster_count < "$wt/disciplines.md")"; else dwt="-"; nwt=0; fi
    emit "$name" "$lane" "$REF" "disciplines.md" "$dwt" "$dref" "SPINE-READ" "roster worktree=${nwt} canonical=${nref}; boot-check + creed-scan-spine read ${REF}, so the branch copy is not an executing surface"
  else emit "$name" "$lane" "$REF" "disciplines.md" "-" "-" "NO-SOURCE"; fi
  # _boot rules_manifest — RULES-STALE (A1).
  stamp="$(awk '/^---/{d++;next} d==1 && /^rules_manifest:/{sub(/^rules_manifest:[[:space:]]*/,"");print;exit}' "$wt/_boot/BOOTSTRAP.md")"
  canon_rm="$(rules_hash_at "$rsha")"
  if [ -z "$canon_rm" ]; then emit "$name" "$lane" "$rlabel" "_boot/BOOTSTRAP.md#rules_manifest" "${stamp:--}" "-" "NO-SOURCE" "reference rules-manifest sources unreadable"
  elif [ -z "$stamp" ]; then emit "$name" "$lane" "$rlabel" "_boot/BOOTSTRAP.md#rules_manifest" "-" "$canon_rm" "NO-SOURCE" "no rules_manifest field in this stamp — nothing to compare (the trunk and exec stamps carry none)"
  elif [ "$stamp" = "$canon_rm" ]; then emit "$name" "$lane" "$rlabel" "_boot/BOOTSTRAP.md#rules_manifest" "$stamp" "$canon_rm" "CURRENT"
  else emit "$name" "$lane" "$rlabel" "_boot/BOOTSTRAP.md#rules_manifest" "$stamp" "$canon_rm" "RULES-STALE" "re-stamp via scripts/lane_currency_gate.sh"; fi
}

# ── iterate worktrees (porcelain: worktree / HEAD / branch|detached, blank-line separated) ──────────────
cur=""; br=""
while IFS= read -r l; do
  case "$l" in
    "worktree "*) cur="$(cd "${l#worktree }" 2>/dev/null && pwd -P)"; br="" ;;
    "branch "*) br="${l#branch refs/heads/}" ;;
    "detached") br="(detached)" ;;
    "") if [ -n "$cur" ]; then
          if [ ${#ONLY[@]} -eq 0 ] || printf '%s\n' "${ONLY[@]}" | grep -qxF "$cur"; then measure_worktree "$cur" "$br"; fi
        fi; cur="" ;;
  esac
done <<EOF
$WT_LIST

EOF
[ "$NWT" -gt 0 ] || unreadable "no worktree matched"

# ── ONE fleet row per installed shared hook (hooks are shared, not per-lane — reuse _hook_state exactly) ──
for pair in "pre-commit:agents/pre-commit-hook.sh" "pre-merge-commit:agents/pre-merge-commit-hook.sh" "commit-msg:agents/commit-msg-hook.sh"; do
  h="${pair%%:*}"; src="${pair#*:}"
  canon="$(git -C "$ANCHOR" rev-parse -q --verify "${REF_SHA}:${src}" 2>/dev/null)"
  if [ -z "$canon" ]; then emit "fleet" "shared" "$REF" "hooks/$h" "-" "-" "NO-SOURCE"
  elif [ ! -f "$HOOKS_DIR/$h" ]; then emit "fleet" "shared" "$REF" "hooks/$h" "-" "$canon" "ABSENT"
  else w="$(git hash-object "$HOOKS_DIR/$h")"; if [ "$w" = "$canon" ]; then emit "fleet" "shared" "$REF" "hooks/$h" "$w" "$canon" "CURRENT"; else emit "fleet" "shared" "$REF" "hooks/$h" "$w" "$canon" "DRIFT" "re-install: scripts/install_pre_commit_hook.sh"; fi; fi
done

# ── ONE spine-host row: the installed pre/post-receive hooks == ${REF}:scripts/spine-receive.sh (the spine host's hook readback) ──
# The spine home is mode 700 (T0, CUSTODY-ACT step 2), so a seat cannot hash the hooks itself: the row asks the forced
# command's read-only `spine-readback` verb, which runs the spine's own main copy of the hook source as the spine account.
# The account name is CUSTODY-ACT's literal. No such account on this host -> PENDING-CUSTODY (named, never CURRENT).
# Reached but not PASS -> DRIFT; not reachable -> UNREACHABLE (red: the enforcement point cannot be read back).
canon="$(git -C "$ANCHOR" rev-parse -q --verify "${REF_SHA}:scripts/spine-receive.sh" 2>/dev/null)"
if [ -z "$canon" ]; then emit "spine-host" "spine" "$REF" "hooks/pre+post-receive" "-" "-" "NO-SOURCE"
elif ! id -u spine > /dev/null 2>&1; then emit "spine-host" "spine" "$REF" "hooks/pre+post-receive" "-" "$canon" "PENDING-CUSTODY" "no spine account on this host: CUSTODY-ACT not performed"
else
  sro="$(ssh -o BatchMode=yes -o ConnectTimeout=5 spine@localhost spine-readback < /dev/null 2>&1)"; src=$?
  sw="$(printf '%s\n' "$sro" | sed -n 's/.*readback PASS .* blob \([0-9a-f]\{40\}\) == main.*/\1/p; s/.*readback FAIL [a-z-]* blob \([0-9a-f]\{40\}\) != .*/\1/p' | head -1)"
  if [ "$src" -eq 0 ] && printf '%s\n' "$sro" | grep -q 'readback PASS'; then
    if [ "$sw" = "$canon" ]; then emit "spine-host" "spine" "$REF" "hooks/pre+post-receive" "$sw" "$canon" "CURRENT"
    else emit "spine-host" "spine" "$REF" "hooks/pre+post-receive" "${sw:--}" "$canon" "DRIFT" "the spine's main differs from ${REF}: the mirror did not take a landing, see spine-mirror-divergence.log (refused on history) and spine-mirror-push-failed.log (transport)"; fi
  elif printf '%s\n' "$sro" | grep -q 'readback FAIL'; then emit "spine-host" "spine" "$REF" "hooks/pre+post-receive" "${sw:--}" "$canon" "DRIFT" "re-install as the spine account: spine-receive.sh install"
  else emit "spine-host" "spine" "$REF" "hooks/pre+post-receive" "-" "$canon" "UNREACHABLE" "spine-readback rc=$src: $(printf '%s' "$sro" | tail -1 | cut -c1-120)"; fi
fi

NRED="$(grep -c . "$RED" || true)"
cat "$RED"
[ "$RED_ONLY" -eq 1 ] || cat "$GREEN"
echo "SURFACE-CONFORM: ${NROWS} rows over ${NWT} worktrees × ${NSUBJ_REF} subjects at ${REF} (${REF_SHA:0:8})${NSUBJ_HEAD:+ · trunk ${NSUBJ_HEAD}} + rules/disciplines rows + 3 fleet hook rows + 1 spine-host row — RED=${NRED}"
if [ "${NRED:-0}" -eq 0 ]; then echo "VERDICT: PASS"; exit 0; fi
echo "VERDICT: FAIL (${NRED} of ${NROWS} rows RED: DRIFT|ABSENT|EXTERNAL|RULES-STALE|UNREACHABLE)"; exit 1
